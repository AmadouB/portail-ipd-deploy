#!/usr/bin/env node

/**
 * Script de deploiement automatique du Portail IPD vers Hostinger
 *
 * Usage:
 *   npm run deploy          → build + upload FTP
 *   npm run deploy:upload   → upload FTP uniquement (sans rebuild)
 *
 * Configuration: .env.deploy (voir le fichier pour les details)
 */

import { Client } from "basic-ftp";
import { readFileSync, writeFileSync, existsSync, readdirSync, statSync, mkdirSync } from "fs";
import { join, resolve, relative } from "path";
import { execSync } from "child_process";

// ─── Charger la config ───────────────────────────────────────────────
const ROOT = resolve(import.meta.dirname, "..");
const ENV_FILE = join(ROOT, ".env.deploy");
const OUT_DIR = join(ROOT, "out");
const HTACCESS_TEMPLATE = `# Portail IPD - Hostinger
RewriteEngine On

# Ne pas toucher aux fichiers/dossiers existants
RewriteCond %{REQUEST_FILENAME} -f [OR]
RewriteCond %{REQUEST_FILENAME} -d
RewriteRule ^ - [L]

# Fallback vers index.html pour les routes SPA
RewriteRule ^(.*)$ /index.html [L]
`;

function loadEnv() {
  if (!existsSync(ENV_FILE)) {
    console.error("\n\x1b[31m✗ Fichier .env.deploy introuvable !\x1b[0m");
    console.error("  Copiez le template et remplissez vos identifiants FTP :");
    console.error("  → Editez .env.deploy avec vos infos Hostinger\n");
    process.exit(1);
  }

  const env = {};
  const content = readFileSync(ENV_FILE, "utf-8");
  for (const line of content.split("\n")) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;
    const [key, ...rest] = trimmed.split("=");
    env[key.trim()] = rest.join("=").trim();
  }

  const required = ["FTP_HOST", "FTP_USER", "FTP_PASS"];
  for (const key of required) {
    if (!env[key] || env[key].includes("votre_")) {
      console.error(`\n\x1b[31m✗ ${key} non configure dans .env.deploy\x1b[0m`);
      console.error("  Editez .env.deploy avec vos identifiants Hostinger\n");
      process.exit(1);
    }
  }

  return {
    host: env.FTP_HOST,
    user: env.FTP_USER,
    pass: env.FTP_PASS,
    remote: env.FTP_REMOTE || "/public_html",
  };
}

// ─── Etape 1 : Build ────────────────────────────────────────────────
function buildProject() {
  console.log("\n\x1b[36m━━━ Etape 1/3 : Build statique ━━━\x1b[0m\n");

  try {
    execSync("npm run build", { cwd: ROOT, stdio: "inherit" });
    console.log("\n\x1b[32m✓ Build reussi\x1b[0m");
  } catch {
    console.error("\n\x1b[31m✗ Echec du build\x1b[0m");
    process.exit(1);
  }

  // S'assurer que le .htaccess est present dans out/
  const htaccessPath = join(OUT_DIR, ".htaccess");
  if (!existsSync(htaccessPath)) {
    writeFileSync(htaccessPath, HTACCESS_TEMPLATE);
    console.log("\x1b[32m✓ .htaccess cree\x1b[0m");
  }
}

// ─── Etape 1b : Traiter les modules exportes ────────────────────────
function processModulesExport() {
  const exportFile = join(ROOT, "modules-export.json");
  if (!existsSync(exportFile)) return;

  console.log("\n\x1b[36m━━━ Modules personnalises detectes ━━━\x1b[0m\n");

  let exportData;
  try {
    exportData = JSON.parse(readFileSync(exportFile, "utf-8"));
  } catch (err) {
    console.error(`\x1b[31m✗ Erreur lecture modules-export.json: ${err.message}\x1b[0m`);
    return;
  }

  const modules = exportData.modules || [];
  if (modules.length === 0) {
    console.log("  Aucun module a publier.\n");
    return;
  }

  // Create directories in out/
  const dataDir = join(OUT_DIR, "data");
  const uploadedDir = join(OUT_DIR, "modules", "uploaded");
  mkdirSync(dataDir, { recursive: true });
  mkdirSync(uploadedDir, { recursive: true });

  // Process each module
  const publishedModules = [];
  for (const mod of modules) {
    const cleanMod = { ...mod };
    delete cleanMod._hasHtmlContent;

    if (mod.htmlContent) {
      // Save HTML content as separate file
      const htmlFile = `${mod.id}.html`;
      const htmlPath = join(uploadedDir, htmlFile);
      writeFileSync(htmlPath, mod.htmlContent, "utf-8");
      console.log(`  \x1b[32m✓\x1b[0m ${mod.name} → /modules/uploaded/${htmlFile}`);

      // Replace htmlContent with externalUrl for the published config
      cleanMod.externalUrl = `/modules/uploaded/${htmlFile}`;
      cleanMod.htmlContent = undefined;
      cleanMod.htmlFileName = undefined;
      // Change route to use the standard modules viewer
      cleanMod.route = `/modules/view?id=${mod.id}`;
    } else {
      console.log(`  \x1b[32m✓\x1b[0m ${mod.name} (URL: ${mod.externalUrl || "n/a"})`);
    }

    publishedModules.push(cleanMod);
  }

  // Write the custom-modules.json
  const jsonPath = join(dataDir, "custom-modules.json");
  writeFileSync(jsonPath, JSON.stringify(publishedModules, null, 2), "utf-8");
  console.log(`\n  \x1b[32m✓ ${publishedModules.length} module(s) publies dans custom-modules.json\x1b[0m`);
  console.log("    Ces modules seront visibles par tous les utilisateurs.\n");
}

// ─── Etape 2 : Collecter les fichiers ───────────────────────────────
function collectFiles(dir, base = dir) {
  const files = [];
  const entries = readdirSync(dir, { withFileTypes: true });

  for (const entry of entries) {
    const fullPath = join(dir, entry.name);
    if (entry.isDirectory()) {
      files.push(...collectFiles(fullPath, base));
    } else {
      files.push({
        local: fullPath,
        remote: relative(base, fullPath),
      });
    }
  }

  return files;
}

// ─── Etape 3 : Upload FTP ───────────────────────────────────────────
async function uploadToHostinger(config, skipBuild = false) {
  if (!skipBuild) {
    buildProject();
  }

  // Process exported modules (from admin "Publier" button)
  processModulesExport();

  if (!existsSync(OUT_DIR)) {
    console.error("\n\x1b[31m✗ Dossier out/ introuvable. Lancez d'abord npm run build\x1b[0m");
    process.exit(1);
  }

  console.log("\n\x1b[36m━━━ Etape 2/3 : Connexion FTP ━━━\x1b[0m\n");
  console.log(`  Serveur : ${config.host}`);
  console.log(`  Chemin  : ${config.remote}`);

  const client = new Client();
  client.ftp.verbose = false;

  try {
    // Essayer d'abord FTPS, puis FTP simple si echec
    try {
      await client.access({
        host: config.host,
        user: config.user,
        password: config.pass,
        secure: true,
        secureOptions: { rejectUnauthorized: false },
      });
    } catch {
      console.log("  FTPS echoue, tentative en FTP simple...");
      await client.access({
        host: config.host,
        user: config.user,
        password: config.pass,
        secure: false,
      });
    }

    console.log("\x1b[32m✓ Connecte au serveur FTP\x1b[0m\n");
    console.log("\x1b[36m━━━ Etape 3/3 : Upload des fichiers ━━━\x1b[0m\n");

    // Collecter tous les fichiers
    const files = collectFiles(OUT_DIR);
    const total = files.length;
    let uploaded = 0;
    let errors = 0;

    console.log(`  ${total} fichiers a uploader...\n`);

    // Uploader le contenu du dossier out/ vers le remote
    await client.ensureDir(config.remote);
    await client.cd(config.remote);

    // Utiliser uploadFromDir pour un upload recursif efficace
    console.log("  Upload en cours (cela peut prendre quelques minutes)...\n");

    await client.uploadFromDir(OUT_DIR, config.remote);

    console.log(`\n\x1b[32m✓ Upload termine avec succes !\x1b[0m`);
    console.log(`\n\x1b[36m━━━ Deploiement termine ━━━\x1b[0m`);
    console.log(`\n  Votre portail est en ligne !\n`);

  } catch (err) {
    console.error(`\n\x1b[31m✗ Erreur FTP : ${err.message}\x1b[0m`);

    if (err.message.includes("Login") || err.message.includes("530")) {
      console.error("\n  → Verifiez vos identifiants dans .env.deploy");
      console.error("  → Dans hPanel > Fichiers > Comptes FTP\n");
    } else if (err.message.includes("ENOTFOUND") || err.message.includes("connect")) {
      console.error("\n  → Verifiez FTP_HOST dans .env.deploy");
      console.error("  → Essayez avec l'IP du serveur au lieu du domaine\n");
    } else if (err.message.includes("ETIMEDOUT")) {
      console.error("\n  → Le serveur ne repond pas. Verifiez :");
      console.error("    - Que le FTP est active sur Hostinger");
      console.error("    - Que votre IP n'est pas bloquee\n");
    }

    process.exit(1);
  } finally {
    client.close();
  }
}

// ─── Git : commit + push ─────────────────────────────────────────────
function gitPush() {
  console.log("\n\x1b[36m━━━ Git : commit & push ━━━\x1b[0m\n");

  try {
    const status = execSync("git status --porcelain", { cwd: ROOT, encoding: "utf-8" }).trim();
    if (!status) {
      console.log("  Aucun changement a committer.\n");
      return;
    }

    execSync("git add -A", { cwd: ROOT, stdio: "inherit" });
    const date = new Date().toLocaleString("fr-FR");
    execSync(`git commit -m "deploy: mise a jour ${date}"`, { cwd: ROOT, stdio: "inherit" });
    execSync("git push origin main", { cwd: ROOT, stdio: "inherit" });
    console.log("\n\x1b[32m✓ Code pousse sur GitHub\x1b[0m");
  } catch {
    console.log("  \x1b[33m⚠ Git push echoue (non bloquant)\x1b[0m\n");
  }
}

// ─── Main ────────────────────────────────────────────────────────────
const args = process.argv.slice(2);
const skipBuild = args.includes("--skip-build");
const withGit = args.includes("--git");

console.log("\x1b[36m");
console.log("  ╔══════════════════════════════════════╗");
console.log("  ║   Deploiement Portail IPD → Hostinger ║");
console.log("  ╚══════════════════════════════════════╝");
console.log("\x1b[0m");

const config = loadEnv();

if (withGit) {
  gitPush();
}

await uploadToHostinger(config, skipBuild);
