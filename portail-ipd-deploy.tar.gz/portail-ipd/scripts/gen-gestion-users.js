const fs = require("fs");
const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  Header, Footer, AlignmentType, LevelFormat,
  HeadingLevel, BorderStyle, WidthType, ShadingType,
  PageNumber, PageBreak,
} = require("docx");

// Colors
const PRIMARY = "0C4A6E";
const ACCENT = "06B6D4";
const DARK = "1E293B";
const GRAY = "64748B";
const LIGHT_BG = "F0F9FF";
const WHITE = "FFFFFF";
const GREEN = "065F46";
const GREEN_BG = "D1FAE5";
const AMBER = "92400E";
const AMBER_BG = "FEF3C7";
const RED = "991B1B";
const RED_BG = "FEE2E2";
const BLUE = "1E40AF";
const BLUE_BG = "DBEAFE";
const PURPLE = "5B21B6";
const PURPLE_BG = "EDE9FE";

const border = { style: BorderStyle.SINGLE, size: 1, color: "CBD5E1" };
const borders = { top: border, bottom: border, left: border, right: border };
const cellMargins = { top: 80, bottom: 80, left: 120, right: 120 };

function h1(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_1,
    spacing: { before: 360, after: 200 },
    children: [new TextRun({ text, bold: true, size: 32, font: "Arial", color: PRIMARY })],
  });
}
function h2(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_2,
    spacing: { before: 280, after: 160 },
    children: [new TextRun({ text, bold: true, size: 26, font: "Arial", color: PRIMARY })],
  });
}
function h3(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_3,
    spacing: { before: 200, after: 120 },
    children: [new TextRun({ text, bold: true, size: 23, font: "Arial", color: ACCENT })],
  });
}
function p(text, opts = {}) {
  return new Paragraph({
    spacing: { after: opts.after || 120 },
    alignment: opts.align || AlignmentType.LEFT,
    children: [new TextRun({ text, size: 22, font: "Arial", color: opts.color || DARK, bold: opts.bold, italics: opts.italic })],
  });
}
function bullet(text, ref = "b1", level = 0) {
  return new Paragraph({
    numbering: { reference: ref, level },
    spacing: { after: 80 },
    children: [new TextRun({ text, size: 22, font: "Arial", color: DARK })],
  });
}
function bulletBold(label, value, ref = "b1") {
  return new Paragraph({
    numbering: { reference: ref, level: 0 },
    spacing: { after: 80 },
    children: [
      new TextRun({ text: label + " : ", size: 22, font: "Arial", bold: true, color: DARK }),
      new TextRun({ text: value, size: 22, font: "Arial", color: DARK }),
    ],
  });
}
function spacer(h = 120) { return new Paragraph({ spacing: { after: h }, children: [] }); }
function alertBox(icon, text, bgColor, txtColor) {
  return new Paragraph({
    spacing: { after: 160, before: 80 },
    shading: { fill: bgColor, type: ShadingType.CLEAR },
    indent: { left: 200, right: 200 },
    children: [
      new TextRun({ text: icon + " ", size: 22, font: "Arial", bold: true, color: txtColor }),
      new TextRun({ text, size: 22, font: "Arial", color: txtColor }),
    ],
  });
}

function cell(text, opts = {}) {
  return new TableCell({
    borders,
    width: { size: opts.w || 1000, type: WidthType.DXA },
    shading: opts.hdr ? { fill: PRIMARY, type: ShadingType.CLEAR } : (opts.alt ? { fill: LIGHT_BG, type: ShadingType.CLEAR } : (opts.bg ? { fill: opts.bg, type: ShadingType.CLEAR } : undefined)),
    margins: cellMargins,
    verticalAlign: "center",
    children: [new Paragraph({
      alignment: opts.center ? AlignmentType.CENTER : AlignmentType.LEFT,
      children: [new TextRun({ text, size: 20, font: "Arial", bold: opts.hdr || opts.bold || false, color: opts.hdr ? WHITE : (opts.color || DARK) })],
    })],
  });
}

// ========== TABLES ==========

// Table 1: Users
const usersData = [
  ["USR-001", "Abdoulaye Sall", "a.sall@pasteur.sn", "Directeur G\u00e9n\u00e9ral", "Direction G\u00e9n\u00e9rale", "Admin G\u00e9n\u00e9ral"],
  ["USR-002", "Amadou Bao", "a.bao@pasteur.sn", "Responsable SEID", "Cellule SEID", "SEID"],
  ["USR-003", "Fatou Diagne", "f.diagne@pasteur.sn", "Charg\u00e9e CAS", "Gouvernance", "CAS"],
  ["USR-004", "Ndey Coumba", "n.coumba@pasteur.sn", "Dir. Sant\u00e9 Publique", "Sant\u00e9 Publique", "Dir. Sant\u00e9 Pub."],
  ["USR-005", "Moussa Ndiaye", "m.ndiaye@pasteur.sn", "Dir. Syst\u00e8mes Info", "DSI", "DSI"],
  ["USR-006", "Ibrahima Soc\u00e9 Fall", "ibrahima.fall@pasteur.sn", "Directeur G\u00e9n\u00e9ral", "Direction G\u00e9n\u00e9rale", "Utilisateur"],
  ["USR-007", "Sophie Diallo", "sophie.diallo@pasteur.sn", "Charg\u00e9e de projet", "Admin. et Finance", "Admin G\u00e9n\u00e9ral"],
  ["USR-008", "Fatoumata Niang", "fatoumata.niang@pasteur.sn", "Responsable RH", "Capital Humain", "Utilisateur"],
  ["USR-009", "SEID IPD", "seid@pasteur.sn", "Op\u00e9rateur SEID", "Cellule SEID", "Utilisateur"],
  ["USR-010", "Amadou Bao", "amadou@pasteur.sn", "Admin. Syst\u00e8me", "Direction G\u00e9n\u00e9rale", "Utilisateur"],
  ["USR-011", "Lamine Traor\u00e9", "lamine.traore@pasteur.sn", "Administrateur", "Direction G\u00e9n\u00e9rale", "Admin G\u00e9n\u00e9ral"],
];
const colW1 = [900, 1800, 2400, 1400, 1400, 1460];
const usersTable = new Table({
  width: { size: 9360, type: WidthType.DXA },
  columnWidths: colW1,
  rows: [
    new TableRow({ children: ["ID", "Nom complet", "Email", "Fonction", "D\u00e9partement", "R\u00f4le"].map((t, i) => cell(t, { hdr: true, w: colW1[i] })) }),
    ...usersData.map((row, ri) => new TableRow({
      children: row.map((t, ci) => cell(t, { w: colW1[ci], alt: ri % 2 === 0, color: ci === 5 && t === "Admin G\u00e9n\u00e9ral" ? GREEN : DARK, bold: ci === 5 && t === "Admin G\u00e9n\u00e9ral" })),
    })),
  ],
});

// Table 2: Roles
const rolesData = [
  ["Admin G\u00e9n\u00e9ral", "admin_general", "Tous", "Acc\u00e8s complet \u00e0 tous les modules et fonctions d\u2019administration"],
  ["CAS", "cas", "Gouvernance", "Consultation du Cockpit Strat\u00e9gique et SEID"],
  ["SEID", "seid", "Gouvernance", "Gestion SEID, consultation Cockpit et Surveillance"],
  ["DSI", "dsi", "Op\u00e9rations", "Administration technique du portail"],
  ["Dir. Production", "dir_production", "M\u00e9tiers", "Gestion de la production et consultation Cockpit"],
  ["Dir. Recherche", "dir_recherche", "M\u00e9tiers", "Gestion du Grant Office et consultation Cockpit"],
  ["Dir. Sant\u00e9 Publique", "dir_sante_publique", "M\u00e9tiers", "Gestion de la Surveillance et consultation Cockpit"],
  ["Dir. Partenariat", "dir_partenariat", "Partenariat", "Gestion Partenariat, Communication et consultation Cockpit"],
  ["DRH", "drh", "Op\u00e9rations", "Gestion des Ressources Humaines"],
  ["DAF", "daf", "Op\u00e9rations", "Gestion de la Finance et Logistique"],
  ["Utilisateur", "utilisateur", "Op\u00e9rations", "Acc\u00e8s limit\u00e9, aucun module par d\u00e9faut"],
];
const colW2 = [1600, 1600, 1360, 4800];
const rolesTable = new Table({
  width: { size: 9360, type: WidthType.DXA },
  columnWidths: colW2,
  rows: [
    new TableRow({ children: ["R\u00f4le", "Identifiant", "P\u00f4le", "Description"].map((t, i) => cell(t, { hdr: true, w: colW2[i] })) }),
    ...rolesData.map((row, ri) => new TableRow({
      children: row.map((t, ci) => cell(t, { w: colW2[ci], alt: ri % 2 === 0, bold: ci === 0 })),
    })),
  ],
});

// Table 3: Permissions matrix
const modules = ["IMS", "Suivi", "Cockpit", "SEID", "Surveillance", "Admin", "Production", "Grant Office", "RH", "Finance", "Partenariat", "Communication"];
const permMatrix = [
  ["Admin G\u00e9n\u00e9ral", "RWA", "RWA", "RWA", "RWA", "RWA", "RWA", "RW", "RW", "RW", "RW", "RW", "RW"],
  ["CAS",                     "\u2014", "\u2014", "R", "R", "\u2014", "\u2014", "\u2014", "\u2014", "\u2014", "\u2014", "\u2014", "\u2014"],
  ["SEID",                    "\u2014", "\u2014", "R", "RW", "R", "\u2014", "\u2014", "\u2014", "\u2014", "\u2014", "\u2014", "\u2014"],
  ["DSI",                     "\u2014", "\u2014", "\u2014", "\u2014", "\u2014", "RWA", "\u2014", "\u2014", "\u2014", "\u2014", "\u2014", "\u2014"],
  ["Dir. Production",         "\u2014", "\u2014", "R", "\u2014", "\u2014", "\u2014", "RW", "\u2014", "\u2014", "\u2014", "\u2014", "\u2014"],
  ["Dir. Recherche",          "\u2014", "\u2014", "R", "\u2014", "\u2014", "\u2014", "\u2014", "RW", "\u2014", "\u2014", "\u2014", "\u2014"],
  ["Dir. Sant\u00e9 Pub.",    "\u2014", "\u2014", "R", "\u2014", "RW", "\u2014", "\u2014", "\u2014", "\u2014", "\u2014", "\u2014", "\u2014"],
  ["Dir. Partenariat",        "\u2014", "\u2014", "R", "\u2014", "\u2014", "\u2014", "\u2014", "\u2014", "\u2014", "\u2014", "RW", "RW"],
  ["DRH",                     "\u2014", "\u2014", "\u2014", "\u2014", "\u2014", "\u2014", "\u2014", "\u2014", "RW", "\u2014", "\u2014", "\u2014"],
  ["DAF",                     "\u2014", "\u2014", "\u2014", "\u2014", "\u2014", "\u2014", "\u2014", "\u2014", "\u2014", "RW", "\u2014", "\u2014"],
  ["Utilisateur",             "\u2014", "\u2014", "\u2014", "\u2014", "\u2014", "\u2014", "\u2014", "\u2014", "\u2014", "\u2014", "\u2014", "\u2014"],
];

const mColW = [1200, ...modules.map(() => 680)];
const matrixTable = new Table({
  width: { size: 9360, type: WidthType.DXA },
  columnWidths: mColW,
  rows: [
    new TableRow({ children: ["R\u00f4le", ...modules].map((t, i) => cell(t, { hdr: true, w: mColW[i], center: i > 0 })) }),
    ...permMatrix.map((row, ri) => new TableRow({
      children: row.map((t, ci) => {
        let bg = undefined;
        let color = DARK;
        if (t === "RWA") { bg = GREEN_BG; color = GREEN; }
        else if (t === "RW") { bg = BLUE_BG; color = BLUE; }
        else if (t === "R") { bg = AMBER_BG; color = AMBER; }
        else if (t === "\u2014") { bg = undefined; color = "CBD5E1"; }
        return cell(t, { w: mColW[ci], center: ci > 0, bg, color, bold: ci === 0 || t === "RWA" });
      }),
    })),
  ],
});

// Table: Permission levels legend
const legendColW = [1200, 1600, 6560];
const legendTable = new Table({
  width: { size: 9360, type: WidthType.DXA },
  columnWidths: legendColW,
  rows: [
    new TableRow({ children: ["Code", "Niveau", "Description"].map((t, i) => cell(t, { hdr: true, w: legendColW[i] })) }),
    new TableRow({ children: [
      cell("R", { w: 1200, bg: AMBER_BG, color: AMBER, bold: true, center: true }),
      cell("Lecture", { w: 1600 }),
      cell("Consultation des donn\u00e9es et tableaux de bord sans modification possible", { w: 6560 }),
    ]}),
    new TableRow({ children: [
      cell("RW", { w: 1200, bg: BLUE_BG, color: BLUE, bold: true, center: true }),
      cell("Lecture / \u00c9criture", { w: 1600, alt: true }),
      cell("Consultation et modification des donn\u00e9es, saisie, mise \u00e0 jour des informations", { w: 6560, alt: true }),
    ]}),
    new TableRow({ children: [
      cell("RWA", { w: 1200, bg: GREEN_BG, color: GREEN, bold: true, center: true }),
      cell("Administration", { w: 1600 }),
      cell("Acc\u00e8s complet incluant la configuration, la gestion des param\u00e8tres et des utilisateurs du module", { w: 6560 }),
    ]}),
    new TableRow({ children: [
      cell("\u2014", { w: 1200, center: true, color: "CBD5E1" }),
      cell("Aucun acc\u00e8s", { w: 1600, alt: true }),
      cell("Le module n\u2019est pas accessible pour ce r\u00f4le", { w: 6560, alt: true }),
    ]}),
  ],
});

// Table: Admin responsibilities
const adminRespColW = [2800, 6560];
const adminRespTable = new Table({
  width: { size: 9360, type: WidthType.DXA },
  columnWidths: adminRespColW,
  rows: [
    new TableRow({ children: ["Responsabilit\u00e9", "D\u00e9tail"].map((t, i) => cell(t, { hdr: true, w: adminRespColW[i] })) }),
    ...([
      ["Gestion des comptes", "Cr\u00e9ation, modification, d\u00e9sactivation des comptes utilisateurs"],
      ["Attribution des r\u00f4les", "Assignation et modification des r\u00f4les selon les fonctions de l\u2019utilisateur"],
      ["Gestion des modules", "Activation, d\u00e9sactivation et configuration des modules du portail"],
      ["Publication de contenus", "Int\u00e9gration et publication de modules HTML personnalis\u00e9s"],
      ["Suivi des acc\u00e8s", "Consultation des journaux de connexion et d\u2019activit\u00e9"],
      ["S\u00e9curit\u00e9", "Application de la politique de mots de passe et gestion MFA"],
      ["Maintenance", "D\u00e9ploiement des mises \u00e0 jour et surveillance de la sant\u00e9 syst\u00e8me"],
    ]).map((row, ri) => new TableRow({
      children: [
        cell(row[0], { w: adminRespColW[0], alt: ri % 2 === 0, bold: true }),
        cell(row[1], { w: adminRespColW[1], alt: ri % 2 === 0 }),
      ],
    })),
  ],
});

// Table: Security policy
const secColW = [2800, 6560];
const secTable = new Table({
  width: { size: 9360, type: WidthType.DXA },
  columnWidths: secColW,
  rows: [
    new TableRow({ children: ["R\u00e8gle", "Description"].map((t, i) => cell(t, { hdr: true, w: secColW[i] })) }),
    ...([
      ["Authentification JWT", "Authentification JWT avec sessions stock\u00e9es en base de donn\u00e9es PostgreSQL. Cookies HttpOnly, Secure, SameSite=Strict"],
      ["Hachage bcrypt", "Tous les mots de passe sont hach\u00e9s avec bcrypt (10 rounds). Aucun mot de passe en clair dans le syst\u00e8me"],
      ["Mots de passe forts", "G\u00e9n\u00e9ration automatique au format IPD-XXXX-XXXX-XXXXXX. Affichage unique \u00e0 la cr\u00e9ation"],
      ["Anti brute-force", "Rate limiting c\u00f4t\u00e9 serveur : verrouillage apr\u00e8s 5 tentatives \u00e9chou\u00e9es pendant 15 minutes"],
      ["Sessions", "Expiration automatique apr\u00e8s 24h, fingerprint navigateur, v\u00e9rification p\u00e9riodique (60s)"],
      ["Journalisation", "Toutes les actions enregistr\u00e9es dans PostgreSQL (table audit_logs) : connexions, modifications, \u00e9v\u00e9nements de s\u00e9curit\u00e9"],
      ["MFA", "Authentification multi-facteurs recommand\u00e9e pour les administrateurs"],
      ["Confidentialit\u00e9", "Les identifiants sont strictement personnels et ne doivent pas \u00eatre partag\u00e9s"],
      ["Sandbox", "Modules HTML embarqu\u00e9s isol\u00e9s avec sandbox et referrerPolicy=no-referrer"],
    ]).map((row, ri) => new TableRow({
      children: [
        cell(row[0], { w: secColW[0], alt: ri % 2 === 0, bold: true }),
        cell(row[1], { w: secColW[1], alt: ri % 2 === 0 }),
      ],
    })),
  ],
});

const doc = new Document({
  styles: {
    default: { document: { run: { font: "Arial", size: 22, color: DARK } } },
    paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 32, bold: true, font: "Arial", color: PRIMARY },
        paragraph: { spacing: { before: 360, after: 200 }, outlineLevel: 0 } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 26, bold: true, font: "Arial", color: PRIMARY },
        paragraph: { spacing: { before: 280, after: 160 }, outlineLevel: 1 } },
      { id: "Heading3", name: "Heading 3", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 23, bold: true, font: "Arial", color: ACCENT },
        paragraph: { spacing: { before: 200, after: 120 }, outlineLevel: 2 } },
    ],
  },
  numbering: {
    config: [
      { reference: "b1", levels: [{ level: 0, format: LevelFormat.BULLET, text: "\u2022", alignment: AlignmentType.LEFT,
        style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
      { reference: "n1", levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT,
        style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
      { reference: "n2", levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT,
        style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
    ],
  },
  sections: [
    // ===== COVER =====
    {
      properties: { page: { size: { width: 12240, height: 15840 }, margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 } } },
      children: [
        spacer(1800),
        p("INSTITUT PASTEUR DE DAKAR", { align: AlignmentType.CENTER, color: GRAY, bold: true }),
        new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 80 }, border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: ACCENT, space: 8 } }, children: [] }),
        spacer(200),
        new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 120 }, children: [new TextRun({ text: "GESTION DES UTILISATEURS", size: 44, font: "Arial", bold: true, color: PRIMARY })] }),
        new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 120 }, children: [new TextRun({ text: "R\u00d4LES, RESPONSABILIT\u00c9S", size: 40, font: "Arial", bold: true, color: ACCENT })] }),
        new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 300 }, children: [new TextRun({ text: "ACC\u00c8S & PERMISSIONS", size: 40, font: "Arial", bold: true, color: ACCENT })] }),
        new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 80 }, border: { top: { style: BorderStyle.SINGLE, size: 6, color: ACCENT, space: 8 } }, children: [] }),
        spacer(100),
        p("Portail Int\u00e9gr\u00e9 de Cyber-Gouvernance", { align: AlignmentType.CENTER, bold: true }),
        spacer(600),
        p("Version 1.0 \u2014 Mars 2026", { align: AlignmentType.CENTER, color: GRAY }),
        p("Document confidentiel \u2014 Usage interne IPD", { align: AlignmentType.CENTER, color: GRAY, italic: true }),
      ],
    },
    // ===== CONTENT =====
    {
      properties: { page: { size: { width: 12240, height: 15840 }, margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 } } },
      headers: {
        default: new Header({ children: [new Paragraph({
          border: { bottom: { style: BorderStyle.SINGLE, size: 2, color: ACCENT, space: 4 } },
          children: [new TextRun({ text: "Gestion des utilisateurs \u2014 Portail IPD", size: 16, font: "Arial", color: GRAY, italics: true })],
        })] }),
      },
      footers: {
        default: new Footer({ children: [new Paragraph({
          alignment: AlignmentType.CENTER,
          border: { top: { style: BorderStyle.SINGLE, size: 2, color: ACCENT, space: 4 } },
          children: [
            new TextRun({ text: "Institut Pasteur de Dakar \u2014 Confidentiel \u2014 Page ", size: 16, font: "Arial", color: GRAY }),
            new TextRun({ children: [PageNumber.CURRENT], size: 16, font: "Arial", color: GRAY }),
          ],
        })] }),
      },
      children: [
        // ===== 1. INTRODUCTION =====
        h1("1. Introduction"),
        p("Ce document d\u00e9finit le cadre de gestion des utilisateurs du Portail Int\u00e9gr\u00e9 de Cyber-Gouvernance de l\u2019Institut Pasteur de Dakar. Il pr\u00e9cise les r\u00f4les, responsabilit\u00e9s, niveaux d\u2019acc\u00e8s et permissions attribu\u00e9s \u00e0 chaque cat\u00e9gorie d\u2019utilisateur."),
        p("Ce document s\u2019adresse aux administrateurs du portail et aux responsables de la s\u00e9curit\u00e9 des syst\u00e8mes d\u2019information de l\u2019IPD."),
        spacer(60),
        p("Architecture technique :", { bold: true }),
        bullet("Base de donn\u00e9es : PostgreSQL pour le stockage des utilisateurs, r\u00f4les, sessions et journaux d\u2019audit"),
        bullet("ORM : Prisma pour la gestion du sch\u00e9ma et les op\u00e9rations CRUD"),
        bullet("API : Next.js API Routes pour toutes les op\u00e9rations (GET, POST, PATCH, DELETE)"),
        bullet("S\u00e9curit\u00e9 : hachage bcrypt (10 rounds) des mots de passe, authentification JWT avec sessions en base"),
        spacer(60),
        p("Objectifs de ce document :", { bold: true }),
        bullet("D\u00e9finir la politique de gestion des identit\u00e9s et des acc\u00e8s"),
        bullet("\u00c9tablir la matrice des r\u00f4les et permissions par module"),
        bullet("Formaliser les responsabilit\u00e9s des administrateurs"),
        bullet("D\u00e9crire les proc\u00e9dures de gestion du cycle de vie des comptes"),
        bullet("Rappeler les r\u00e8gles de s\u00e9curit\u00e9 applicables"),

        new Paragraph({ children: [new PageBreak()] }),

        // ===== 2. ANNUAIRE UTILISATEURS =====
        h1("2. Annuaire des utilisateurs"),
        p("Le tableau ci-dessous pr\u00e9sente l\u2019ensemble des comptes utilisateurs actifs sur le portail, avec leur r\u00f4le et rattachement organisationnel."),
        spacer(80),
        usersTable,
        spacer(120),
        alertBox("\u2139", "Les administrateurs g\u00e9n\u00e9raux (Abdoulaye Sall, Sophie Diallo et Lamine Traor\u00e9) disposent d\u2019un acc\u00e8s complet \u00e0 l\u2019ensemble des modules et fonctions d\u2019administration du portail.", BLUE_BG, BLUE),

        h2("2.1 Cycle de vie des comptes"),
        p("Chaque compte utilisateur suit un cycle de vie structur\u00e9, g\u00e9r\u00e9 via les API Routes du portail :"),
        spacer(40),
        new Paragraph({
          numbering: { reference: "n1", level: 0 }, spacing: { after: 80 },
          children: [
            new TextRun({ text: "Cr\u00e9ation : ", size: 22, font: "Arial", bold: true, color: DARK }),
            new TextRun({ text: "Via API POST /api/users \u2014 L\u2019administrateur remplit le formulaire (email, r\u00f4le, d\u00e9partement). Un mot de passe fort est g\u00e9n\u00e9r\u00e9 automatiquement au format IPD-XXXX-XXXX-XXXXXX et hach\u00e9 avec bcrypt c\u00f4t\u00e9 serveur.", size: 22, font: "Arial", color: DARK }),
          ],
        }),
        new Paragraph({
          numbering: { reference: "n1", level: 0 }, spacing: { after: 80 },
          children: [
            new TextRun({ text: "Activation : ", size: 22, font: "Arial", bold: true, color: DARK }),
            new TextRun({ text: "Le mot de passe g\u00e9n\u00e9r\u00e9 est affich\u00e9 une seule fois \u00e0 l\u2019administrateur pour communication s\u00e9curis\u00e9e \u00e0 l\u2019utilisateur", size: 22, font: "Arial", color: DARK }),
          ],
        }),
        new Paragraph({
          numbering: { reference: "n1", level: 0 }, spacing: { after: 80 },
          children: [
            new TextRun({ text: "Modification : ", size: 22, font: "Arial", bold: true, color: DARK }),
            new TextRun({ text: "Changement de r\u00f4le ou d\u00e9partement via l\u2019interface. R\u00e9initialisation du mot de passe via API POST /api/users/:id/reset-password", size: 22, font: "Arial", color: DARK }),
          ],
        }),
        new Paragraph({
          numbering: { reference: "n1", level: 0 }, spacing: { after: 80 },
          children: [
            new TextRun({ text: "D\u00e9sactivation : ", size: 22, font: "Arial", bold: true, color: DARK }),
            new TextRun({ text: "Suspension de l\u2019acc\u00e8s via API PATCH /api/users/:id/toggle-active. Les sessions actives sont invalid\u00e9es imm\u00e9diatement.", size: 22, font: "Arial", color: DARK }),
          ],
        }),

        new Paragraph({ children: [new PageBreak()] }),

        // ===== 3. ROLES =====
        h1("3. D\u00e9finition des r\u00f4les"),
        p("Le portail utilise un syst\u00e8me de contr\u00f4le d\u2019acc\u00e8s bas\u00e9 sur les r\u00f4les (RBAC \u2014 Role-Based Access Control). Chaque utilisateur se voit attribuer un r\u00f4le unique d\u00e9terminant ses droits d\u2019acc\u00e8s."),
        spacer(80),
        rolesTable,
        spacer(120),

        h2("3.1 R\u00f4le Administrateur G\u00e9n\u00e9ral"),
        p("L\u2019Administrateur G\u00e9n\u00e9ral poss\u00e8de le niveau de privil\u00e8ge le plus \u00e9lev\u00e9 du portail. Il a acc\u00e8s \u00e0 l\u2019ensemble des modules avec les droits de lecture, \u00e9criture et administration."),
        spacer(60),
        p("Responsabilit\u00e9s de l\u2019Administrateur G\u00e9n\u00e9ral :", { bold: true }),
        spacer(40),
        adminRespTable,
        spacer(80),
        alertBox("\u26a0", "Il est recommand\u00e9 de limiter le nombre d\u2019administrateurs g\u00e9n\u00e9raux au strict minimum (2-3 personnes) pour des raisons de s\u00e9curit\u00e9.", AMBER_BG, AMBER),

        h2("3.2 R\u00f4les m\u00e9tiers"),
        p("Les r\u00f4les m\u00e9tiers sont sp\u00e9cifiques \u00e0 chaque direction ou fonction de l\u2019IPD. Ils accordent des droits cibl\u00e9s sur les modules relevant de leur p\u00e9rim\u00e8tre :"),
        spacer(40),
        bulletBold("CAS", "Cellule d\u2019Appui Strat\u00e9gique \u2014 Consultation des tableaux de bord de gouvernance"),
        bulletBold("SEID", "Suivi-\u00c9valuation \u2014 Gestion de l\u2019intelligence de donn\u00e9es et consultation"),
        bulletBold("DSI", "Direction des Syst\u00e8mes d\u2019Information \u2014 Administration technique"),
        bulletBold("Dir. Production", "Gestion de la production vaccinale"),
        bulletBold("Dir. Recherche", "Gestion du Grant Office et des projets de recherche"),
        bulletBold("Dir. Sant\u00e9 Publique", "Gestion de la Surveillance \u00c9pid\u00e9miologique"),
        bulletBold("Dir. Partenariat", "Gestion des partenariats et de la communication"),
        bulletBold("DRH", "Gestion des Ressources Humaines"),
        bulletBold("DAF", "Gestion de la Finance et de la Logistique"),

        h2("3.3 R\u00f4le Utilisateur"),
        p("Le r\u00f4le Utilisateur repr\u00e9sente le niveau d\u2019acc\u00e8s de base. Par d\u00e9faut, il ne dispose d\u2019aucun acc\u00e8s aux modules. L\u2019administrateur doit explicitement attribuer des acc\u00e8s selon les besoins op\u00e9rationnels."),

        new Paragraph({ children: [new PageBreak()] }),

        // ===== 4. PERMISSIONS =====
        h1("4. Matrice des permissions"),
        p("La matrice ci-dessous d\u00e9taille les niveaux d\u2019acc\u00e8s de chaque r\u00f4le pour chaque module du portail."),

        h2("4.1 L\u00e9gende des niveaux d\u2019acc\u00e8s"),
        spacer(40),
        legendTable,

        spacer(120),
        h2("4.2 Matrice compl\u00e8te R\u00f4les / Modules"),
        spacer(40),
        matrixTable,
        spacer(120),

        alertBox("\u2139", "L\u2019Administrateur G\u00e9n\u00e9ral a acc\u00e8s \u00e0 tous les modules y compris les modules personnalis\u00e9s ajout\u00e9s dynamiquement au portail.", BLUE_BG, BLUE),

        new Paragraph({ children: [new PageBreak()] }),

        // ===== 5. POLES =====
        h1("5. Organisation par p\u00f4les"),
        p("Les modules du portail sont organis\u00e9s en quatre p\u00f4les fonctionnels. Chaque r\u00f4le est rattach\u00e9 \u00e0 un ou plusieurs p\u00f4les."),
        spacer(80),

        h2("5.1 P\u00f4le Gouvernance"),
        bulletBold("Couleur", "Cyan (#06B6D4)"),
        bulletBold("Modules", "Cockpit Strat\u00e9gique, SEID Intelligence"),
        bulletBold("R\u00f4les concern\u00e9s", "Admin G\u00e9n\u00e9ral, CAS, SEID"),
        p("Ce p\u00f4le couvre le pilotage strat\u00e9gique de l\u2019IPD, les KPIs institutionnels et l\u2019intelligence de donn\u00e9es."),

        spacer(80),
        h2("5.2 P\u00f4le Fonctions M\u00e9tiers"),
        bulletBold("Couleur", "Vert (#10B981) / Violet (#8B5CF6)"),
        bulletBold("Modules", "IMS NextGen, Modules Suivi, Surveillance \u00c9pid\u00e9miologique, Production Vaccins, Grant Office"),
        bulletBold("R\u00f4les concern\u00e9s", "Admin G\u00e9n\u00e9ral, Dir. Production, Dir. Recherche, Dir. Sant\u00e9 Publique"),
        p("Ce p\u00f4le regroupe les activit\u00e9s de production, recherche, qualit\u00e9 et sant\u00e9 publique."),

        spacer(80),
        h2("5.3 P\u00f4le Op\u00e9rations"),
        bulletBold("Couleur", "Ambre (#F59E0B)"),
        bulletBold("Modules", "Administration Portail, Ressources Humaines, Finance & Logistique"),
        bulletBold("R\u00f4les concern\u00e9s", "Admin G\u00e9n\u00e9ral, DSI, DRH, DAF"),
        p("Ce p\u00f4le couvre les fonctions support : administration technique, RH et finances."),

        spacer(80),
        h2("5.4 P\u00f4le Partenariat"),
        bulletBold("Couleur", "Violet (#8B5CF6)"),
        bulletBold("Modules", "Mobilisation Ressources, Relations M\u00e9dias"),
        bulletBold("R\u00f4les concern\u00e9s", "Admin G\u00e9n\u00e9ral, Dir. Partenariat"),
        p("Ce p\u00f4le g\u00e8re les relations ext\u00e9rieures, partenariats et communication."),

        new Paragraph({ children: [new PageBreak()] }),

        // ===== 6. SECURITE =====
        h1("6. Politique de s\u00e9curit\u00e9"),
        p("La s\u00e9curit\u00e9 des acc\u00e8s au portail repose sur un ensemble de r\u00e8gles strictes visant \u00e0 prot\u00e9ger les donn\u00e9es de l\u2019IPD."),
        spacer(80),

        h2("6.1 R\u00e8gles de s\u00e9curit\u00e9"),
        spacer(40),
        secTable,
        spacer(120),

        h2("6.2 Bonnes pratiques"),
        bullet("Utiliser un mot de passe unique pour le portail IPD"),
        bullet("Activer l\u2019authentification multi-facteurs (MFA) lorsque disponible"),
        bullet("Se d\u00e9connecter syst\u00e9matiquement en fin de session"),
        bullet("Ne jamais acc\u00e9der au portail depuis un r\u00e9seau Wi-Fi public non s\u00e9curis\u00e9"),
        bullet("Signaler imm\u00e9diatement toute activit\u00e9 suspecte \u00e0 l\u2019administrateur"),
        bullet("Ne pas enregistrer les identifiants dans le navigateur sur un poste partag\u00e9"),
        spacer(80),
        alertBox("\u26a0", "Tout manquement aux r\u00e8gles de s\u00e9curit\u00e9 peut entra\u00eener la suspension imm\u00e9diate du compte utilisateur concern\u00e9.", RED_BG, RED),

        new Paragraph({ children: [new PageBreak()] }),

        // ===== 7. PROCEDURES =====
        h1("7. Proc\u00e9dures administratives"),

        h2("7.1 Cr\u00e9ation d\u2019un compte"),
        p("Workflow via l\u2019API du portail :", { bold: true }),
        new Paragraph({ numbering: { reference: "n2", level: 0 }, spacing: { after: 80 }, children: [new TextRun({ text: "L\u2019administrateur remplit le formulaire dans l\u2019interface (nom, email, r\u00f4le, d\u00e9partement)", size: 22, font: "Arial" })] }),
        new Paragraph({ numbering: { reference: "n2", level: 0 }, spacing: { after: 80 }, children: [new TextRun({ text: "Appel API POST /api/users avec les donn\u00e9es du formulaire", size: 22, font: "Arial" })] }),
        new Paragraph({ numbering: { reference: "n2", level: 0 }, spacing: { after: 80 }, children: [new TextRun({ text: "Le serveur g\u00e9n\u00e8re un mot de passe fort au format IPD-XXXX-XXXX-XXXXXX + hash bcrypt (10 rounds)", size: 22, font: "Arial" })] }),
        new Paragraph({ numbering: { reference: "n2", level: 0 }, spacing: { after: 80 }, children: [new TextRun({ text: "Le mot de passe en clair est affich\u00e9 une seule fois \u00e0 l\u2019administrateur (jamais stock\u00e9, seul le hash bcrypt est enregistr\u00e9)", size: 22, font: "Arial" })] }),
        new Paragraph({ numbering: { reference: "n2", level: 0 }, spacing: { after: 80 }, children: [new TextRun({ text: "L\u2019utilisateur est enregistr\u00e9 dans la base de donn\u00e9es PostgreSQL", size: 22, font: "Arial" })] }),
        new Paragraph({ numbering: { reference: "n2", level: 0 }, spacing: { after: 80 }, children: [new TextRun({ text: "Communication s\u00e9curis\u00e9e des identifiants \u00e0 l\u2019utilisateur", size: 22, font: "Arial" })] }),
        new Paragraph({ numbering: { reference: "n2", level: 0 }, spacing: { after: 80 }, children: [new TextRun({ text: "La cr\u00e9ation est journalis\u00e9e dans la table audit_logs de PostgreSQL", size: 22, font: "Arial" })] }),

        spacer(80),
        h2("7.2 Modification des droits"),
        bullet("Acc\u00e8s via l\u2019interface Administration > R\u00f4les"),
        bullet("Appels API PATCH /api/roles/:id pour modifier les permissions"),
        bullet("Les modifications sont imm\u00e9diatement appliqu\u00e9es dans la base de donn\u00e9es PostgreSQL"),
        bullet("Toute modification de r\u00f4le doit \u00eatre valid\u00e9e par le responsable hi\u00e9rarchique"),
        bullet("Un historique des modifications est conserv\u00e9 dans la table audit_logs"),

        spacer(80),
        h2("7.3 D\u00e9sactivation d\u2019un compte"),
        bullet("Toggle via API PATCH /api/users/:id/toggle-active"),
        bullet("Les sessions actives de l\u2019utilisateur sont invalid\u00e9es imm\u00e9diatement dans PostgreSQL"),
        bullet("Un audit trail est enregistr\u00e9 dans la table audit_logs"),
        bullet("D\u00e9part de l\u2019IPD : d\u00e9sactivation imm\u00e9diate le jour du d\u00e9part"),
        bullet("Changement de poste : mise \u00e0 jour du r\u00f4le ou d\u00e9sactivation selon le cas"),
        bullet("Suspicion de compromission : suspension imm\u00e9diate et enqu\u00eate"),

        new Paragraph({ children: [new PageBreak()] }),

        // ===== 8. CONTACTS =====
        h1("8. Contacts et support"),
        p("Pour toute demande relative \u00e0 la gestion des utilisateurs et des acc\u00e8s :"),
        spacer(80),
        bulletBold("Administrateurs portail", "Sophie Diallo (sophie.diallo@pasteur.sn), Lamine Traor\u00e9 (lamine.traore@pasteur.sn)"),
        bulletBold("Cellule SEID", "seid@pasteur.sn"),
        bulletBold("Support technique", "amadou@pasteur.sn"),
        spacer(200),
        new Paragraph({
          alignment: AlignmentType.CENTER,
          border: { top: { style: BorderStyle.SINGLE, size: 2, color: ACCENT, space: 8 } },
          spacing: { before: 200, after: 100 },
          children: [new TextRun({ text: "Institut Pasteur de Dakar", size: 22, font: "Arial", bold: true, color: PRIMARY })],
        }),
        new Paragraph({
          alignment: AlignmentType.CENTER, spacing: { after: 60 },
          children: [new TextRun({ text: "Portail Int\u00e9gr\u00e9 de Cyber-Gouvernance", size: 20, font: "Arial", color: GRAY })],
        }),
        new Paragraph({
          alignment: AlignmentType.CENTER,
          children: [new TextRun({ text: "Version 1.0 \u2014 Mars 2026 \u2014 Document confidentiel", size: 20, font: "Arial", color: GRAY })],
        }),
      ],
    },
  ],
});

const OUT = "/Users/amadou/Documents/IPD/portail-ipd/Gestion_Utilisateurs_Roles_Permissions_IPD.docx";
Packer.toBuffer(doc).then(buf => {
  fs.writeFileSync(OUT, buf);
  console.log("Document cree:", OUT, `(${(buf.length / 1024).toFixed(0)} Ko)`);
});
