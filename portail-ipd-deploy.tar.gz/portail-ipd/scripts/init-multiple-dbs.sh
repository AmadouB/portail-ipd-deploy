#!/bin/bash
# ══════════════════════════════════════════════════════════
# Init script PostgreSQL — crée les bases supplémentaires
# pour les apps multi-tenant du portail (hoshinflow, etc.)
#
# Exécuté UNE SEULE FOIS au premier démarrage du conteneur,
# quand /var/lib/postgresql/data/pgdata est vide.
# ══════════════════════════════════════════════════════════
set -e

echo "[init-multiple-dbs] Création des bases additionnelles..."

create_db_and_user() {
  local db=$1
  local user=$2
  local pwd=$3

  echo "  → Création utilisateur '$user' et base '$db'"
  psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" <<-EOSQL
    DO \$\$
    BEGIN
      IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = '$user') THEN
        CREATE ROLE $user WITH LOGIN PASSWORD '$pwd';
      END IF;
    END
    \$\$;
EOSQL

  if ! psql -tc "SELECT 1 FROM pg_database WHERE datname = '$db'" -U "$POSTGRES_USER" | grep -q 1; then
    psql -U "$POSTGRES_USER" -c "CREATE DATABASE $db OWNER $user;"
  fi

  psql -U "$POSTGRES_USER" -d "$db" -c "GRANT ALL ON SCHEMA public TO $user;"
  psql -U "$POSTGRES_USER" -d "$db" -c "ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO $user;"
  psql -U "$POSTGRES_USER" -d "$db" -c "ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON SEQUENCES TO $user;"
}

# ─── HoshinFlow ──────────────────────────────────
create_db_and_user "hoshinflow" "hoshinflow" "${HOSHINFLOW_DB_PASSWORD:-hoshinflow_pwd_2026}"

# ─── IMS Partnerships ────────────────────────────
create_db_and_user "partnerships" "partnerships" "${PARTNERSHIPS_DB_PASSWORD:-partnerships_pwd_2026}"

echo "[init-multiple-dbs] Terminé"
