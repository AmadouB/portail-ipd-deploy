#!/bin/bash
# ═══════════════════════════════════════════════════════════
#  SCRIPT D'INSTALLATION VPS — Portail IPD
#  Institut Pasteur de Dakar
# ═══════════════════════════════════════════════════════════
#
#  Prérequis : Ubuntu 22.04+ LTS, accès root/sudo
#
#  Usage :
#    chmod +x scripts/setup-vps.sh
#    sudo ./scripts/setup-vps.sh
#
# ═══════════════════════════════════════════════════════════

set -e

echo ""
echo "╔══════════════════════════════════════════════╗"
echo "║  Installation VPS — Portail IPD              ║"
echo "║  Institut Pasteur de Dakar                    ║"
echo "╚══════════════════════════════════════════════╝"
echo ""

# ─── 1. Mise à jour système ──────────────────────────────
echo "━━━ Étape 1/7 : Mise à jour du système ━━━"
apt update && apt upgrade -y
echo "✓ Système à jour"
echo ""

# ─── 2. Installation Node.js 20 LTS ─────────────────────
echo "━━━ Étape 2/7 : Installation Node.js 20 ━━━"
if ! command -v node &> /dev/null; then
    curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
    apt install -y nodejs
fi
echo "  Node.js : $(node --version)"
echo "  npm     : $(npm --version)"
echo "✓ Node.js installé"
echo ""

# ─── 3. Installation PostgreSQL 16 ──────────────────────
echo "━━━ Étape 3/7 : Installation PostgreSQL 16 ━━━"
if ! command -v psql &> /dev/null; then
    sh -c 'echo "deb http://apt.postgresql.org/pub/repos/apt $(lsb_release -cs)-pgdg main" > /etc/apt/sources.list.d/pgdg.list'
    wget --quiet -O - https://www.postgresql.org/media/keys/ACCC4CF8.asc | apt-key add -
    apt update
    apt install -y postgresql-16
fi
echo "  PostgreSQL : $(psql --version)"
echo "✓ PostgreSQL installé"
echo ""

# ─── 4. Configuration de la base de données ─────────────
echo "━━━ Étape 4/7 : Configuration base de données ━━━"
DB_USER="ipd_user"
DB_NAME="portail_ipd"
DB_PASS="IpdSecure2026!"

# Créer l'utilisateur et la base
sudo -u postgres psql -c "DO \$\$
BEGIN
   IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = '${DB_USER}') THEN
      CREATE ROLE ${DB_USER} WITH LOGIN PASSWORD '${DB_PASS}';
   END IF;
END
\$\$;" 2>/dev/null || true

sudo -u postgres psql -c "SELECT 1 FROM pg_database WHERE datname = '${DB_NAME}';" | grep -q 1 || \
    sudo -u postgres createdb -O ${DB_USER} ${DB_NAME}

sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE ${DB_NAME} TO ${DB_USER};"

echo "  Base     : ${DB_NAME}"
echo "  User     : ${DB_USER}"
echo "✓ Base de données configurée"
echo ""

# ─── 5. Installation PM2 ────────────────────────────────
echo "━━━ Étape 5/7 : Installation PM2 ━━━"
if ! command -v pm2 &> /dev/null; then
    npm install -g pm2
fi
echo "  PM2 : $(pm2 --version)"
echo "✓ PM2 installé"
echo ""

# ─── 6. Installation Nginx + Certbot ────────────────────
echo "━━━ Étape 6/7 : Installation Nginx + SSL ━━━"
if ! command -v nginx &> /dev/null; then
    apt install -y nginx
fi
if ! command -v certbot &> /dev/null; then
    apt install -y certbot python3-certbot-nginx
fi
echo "  Nginx   : $(nginx -v 2>&1 | cut -d'/' -f2)"
echo "✓ Nginx + Certbot installés"
echo ""

# ─── 7. Préparation du répertoire ───────────────────────
echo "━━━ Étape 7/7 : Préparation du répertoire ━━━"
APP_DIR="/var/www/portail-ipd"
mkdir -p ${APP_DIR}

echo "  Répertoire : ${APP_DIR}"
echo "✓ Répertoire prêt"
echo ""

# ─── Résumé ──────────────────────────────────────────────
echo "═══════════════════════════════════════════════"
echo "  ✅  INSTALLATION TERMINÉE"
echo "═══════════════════════════════════════════════"
echo ""
echo "  Prochaines étapes :"
echo ""
echo "  1. Copier le projet sur le VPS :"
echo "     rsync -avz --exclude=node_modules --exclude=.next \\"
echo "       . root@VOTRE_IP:${APP_DIR}/"
echo ""
echo "  2. Sur le VPS, créer le fichier .env :"
echo "     cat > ${APP_DIR}/.env << EOF"
echo "     DATABASE_URL=\"postgresql://${DB_USER}:${DB_PASS}@localhost:5432/${DB_NAME}\""
echo "     JWT_SECRET=\"$(openssl rand -hex 32)\""
echo "     JWT_EXPIRY=\"24h\""
echo "     EOF"
echo ""
echo "  3. Installer, migrer et démarrer :"
echo "     cd ${APP_DIR}"
echo "     npm ci"
echo "     npx prisma migrate deploy"
echo "     npx tsx prisma/seed.ts"
echo "     npm run build"
echo "     pm2 start ecosystem.config.cjs"
echo "     pm2 save && pm2 startup"
echo ""
echo "  4. Configurer Nginx :"
echo "     cp nginx/portail-ipd.conf /etc/nginx/sites-available/portail-ipd"
echo "     ln -s /etc/nginx/sites-available/portail-ipd /etc/nginx/sites-enabled/"
echo "     nginx -t && systemctl reload nginx"
echo ""
echo "  5. Obtenir le certificat SSL :"
echo "     certbot --nginx -d seid-pasteur.org -d www.seid-pasteur.org"
echo ""
echo "═══════════════════════════════════════════════"
