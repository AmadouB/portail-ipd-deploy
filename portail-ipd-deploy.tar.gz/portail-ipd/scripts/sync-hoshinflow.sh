#!/bin/bash
# ══════════════════════════════════════════════════════════
# Synchronise le code source HoshinFlow dans apps/hoshinflow/
# pour que docker-compose puisse le builder.
#
# Usage :
#   ./scripts/sync-hoshinflow.sh [SOURCE]
# Défaut: ../hoshinflow (sibling directory)
# ══════════════════════════════════════════════════════════
set -e

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PROJECT_DIR="$( cd "$SCRIPT_DIR/.." && pwd )"
SOURCE="${1:-${PROJECT_DIR}/../hoshinflow}"
TARGET="${PROJECT_DIR}/apps/hoshinflow"

if [ ! -d "$SOURCE" ]; then
  echo "[ERREUR] Source introuvable: $SOURCE"
  echo "Usage: $0 [chemin_vers_hoshinflow]"
  exit 1
fi

echo "[INFO] Source: $SOURCE"
echo "[INFO] Target: $TARGET"

mkdir -p "$TARGET"

rsync -a --delete \
  --exclude 'node_modules' \
  --exclude '.next' \
  --exclude 'out' \
  --exclude '.git' \
  --exclude '.env' \
  --exclude '.env.local' \
  --exclude 'prisma/dev.db' \
  --exclude 'prisma/dev.db-journal' \
  --exclude '.vercel' \
  --exclude '.DS_Store' \
  "$SOURCE/" "$TARGET/"

echo "[OK] HoshinFlow synchronisé dans $TARGET"
