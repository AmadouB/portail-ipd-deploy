const fs = require("fs");
const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  Header, Footer, AlignmentType, LevelFormat,
  HeadingLevel, BorderStyle, WidthType, ShadingType,
  PageNumber, PageBreak,
} = require("docx");

// ============ DESIGN TOKENS ============
const C = {
  PRIMARY: "0C4A6E", ACCENT: "06B6D4", DARK: "1E293B", GRAY: "64748B",
  LIGHT: "F0F9FF", WHITE: "FFFFFF", GREEN: "065F46", GREEN_BG: "D1FAE5",
  AMBER: "92400E", AMBER_BG: "FEF3C7", RED: "991B1B", RED_BG: "FEE2E2",
  CYAN_BG: "CFFAFE", CYAN: "0E7490",
};
const bdr = { style: BorderStyle.SINGLE, size: 1, color: "CBD5E1" };
const borders = { top: bdr, bottom: bdr, left: bdr, right: bdr };
const cm = { top: 80, bottom: 80, left: 120, right: 120 };

// ============ HELPERS ============
const h1 = (t) => new Paragraph({ heading: HeadingLevel.HEADING_1, spacing: { before: 400, after: 220 }, children: [new TextRun({ text: t, bold: true, size: 34, font: "Arial", color: C.PRIMARY })] });
const h2 = (t) => new Paragraph({ heading: HeadingLevel.HEADING_2, spacing: { before: 300, after: 180 }, children: [new TextRun({ text: t, bold: true, size: 28, font: "Arial", color: C.PRIMARY })] });
const h3 = (t) => new Paragraph({ heading: HeadingLevel.HEADING_3, spacing: { before: 220, after: 120 }, children: [new TextRun({ text: t, bold: true, size: 24, font: "Arial", color: C.ACCENT })] });
const pa = (t, o = {}) => new Paragraph({ spacing: { after: o.after || 120 }, alignment: o.align || AlignmentType.LEFT, children: [new TextRun({ text: t, size: 22, font: "Arial", color: o.color || C.DARK, bold: o.bold, italics: o.italic })] });
const bl = (t) => new Paragraph({ numbering: { reference: "b1", level: 0 }, spacing: { after: 70 }, children: [new TextRun({ text: t, size: 22, font: "Arial", color: C.DARK })] });
const bl2 = (t) => new Paragraph({ numbering: { reference: "b2", level: 0 }, spacing: { after: 70 }, indent: { left: 1080 }, children: [new TextRun({ text: t, size: 22, font: "Arial", color: C.DARK })] });
const nl = (t) => new Paragraph({ numbering: { reference: "n1", level: 0 }, spacing: { after: 80 }, children: [new TextRun({ text: t, size: 22, font: "Arial", color: C.DARK })] });
const bv = (l, v) => new Paragraph({ numbering: { reference: "b1", level: 0 }, spacing: { after: 70 }, children: [new TextRun({ text: l + " : ", size: 22, font: "Arial", bold: true, color: C.DARK }), new TextRun({ text: v, size: 22, font: "Arial", color: C.DARK })] });
const sp = (h = 120) => new Paragraph({ spacing: { after: h }, children: [] });
const pb = () => new Paragraph({ children: [new PageBreak()] });
const code = (t) => new Paragraph({ spacing: { after: 100, before: 80 }, shading: { fill: "1E293B", type: ShadingType.CLEAR }, indent: { left: 200, right: 200 }, children: [new TextRun({ text: "  " + t, size: 20, font: "Courier New", color: "06B6D4" })] });
const alert = (icon, text, bg, fg) => new Paragraph({ spacing: { after: 160, before: 80 }, shading: { fill: bg, type: ShadingType.CLEAR }, indent: { left: 200, right: 200 }, children: [new TextRun({ text: icon + " ", size: 22, font: "Arial", bold: true, color: fg }), new TextRun({ text, size: 22, font: "Arial", color: fg })] });

function cell(text, o = {}) {
  return new TableCell({
    borders, width: { size: o.w || 1000, type: WidthType.DXA },
    shading: o.hdr ? { fill: C.PRIMARY, type: ShadingType.CLEAR } : (o.alt ? { fill: C.LIGHT, type: ShadingType.CLEAR } : (o.bg ? { fill: o.bg, type: ShadingType.CLEAR } : undefined)),
    margins: cm, verticalAlign: "center", columnSpan: o.span,
    children: [new Paragraph({ alignment: o.ctr ? AlignmentType.CENTER : AlignmentType.LEFT, children: [new TextRun({ text, size: o.sz || 20, font: "Arial", bold: o.hdr || o.bold || false, color: o.hdr ? C.WHITE : (o.color || C.DARK) })] })],
  });
}

function mkTable(headers, rows, widths) {
  const W = widths.reduce((a, b) => a + b, 0);
  return new Table({
    width: { size: W, type: WidthType.DXA },
    columnWidths: widths,
    rows: [
      new TableRow({ children: headers.map((h, i) => cell(h, { hdr: true, w: widths[i], ctr: i > 0 && widths[i] < 2000 })) }),
      ...rows.map((row, ri) => new TableRow({ children: row.map((t, ci) => cell(t, { w: widths[ci], alt: ri % 2 === 0, ctr: ci > 0 && widths[ci] < 2000, bold: ci === 0 })) })),
    ],
  });
}

// ============ DOCUMENT ============
const doc = new Document({
  styles: {
    default: { document: { run: { font: "Arial", size: 22, color: C.DARK } } },
    paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true, run: { size: 34, bold: true, font: "Arial", color: C.PRIMARY }, paragraph: { spacing: { before: 400, after: 220 }, outlineLevel: 0 } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true, run: { size: 28, bold: true, font: "Arial", color: C.PRIMARY }, paragraph: { spacing: { before: 300, after: 180 }, outlineLevel: 1 } },
      { id: "Heading3", name: "Heading 3", basedOn: "Normal", next: "Normal", quickFormat: true, run: { size: 24, bold: true, font: "Arial", color: C.ACCENT }, paragraph: { spacing: { before: 220, after: 120 }, outlineLevel: 2 } },
    ],
  },
  numbering: { config: [
    { reference: "b1", levels: [{ level: 0, format: LevelFormat.BULLET, text: "\u2022", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
    { reference: "b2", levels: [{ level: 0, format: LevelFormat.BULLET, text: "\u25e6", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 1080, hanging: 360 } } } }] },
    { reference: "n1", levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
  ] },
  sections: [{
    properties: {
      page: {
        size: { width: 11906, height: 16838 },
        margin: { top: 1440, right: 1200, bottom: 1200, left: 1200 },
      },
    },
    headers: {
      default: new Header({
        children: [new Paragraph({
          alignment: AlignmentType.RIGHT,
          spacing: { after: 0 },
          border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: C.ACCENT, space: 1 } },
          children: [
            new TextRun({ text: "Guide de Deploiement VPS", size: 16, font: "Arial", color: C.GRAY, italics: true }),
            new TextRun({ text: "  |  Institut Pasteur de Dakar", size: 16, font: "Arial", color: C.ACCENT }),
          ],
        })],
      }),
    },
    footers: {
      default: new Footer({
        children: [new Paragraph({
          alignment: AlignmentType.CENTER,
          border: { top: { style: BorderStyle.SINGLE, size: 1, color: "CBD5E1", space: 1 } },
          children: [
            new TextRun({ text: "Portail IPD — Document confidentiel — Page ", size: 16, font: "Arial", color: C.GRAY }),
            new TextRun({ children: [PageNumber.CURRENT], size: 16, font: "Arial", color: C.ACCENT }),
          ],
        })],
      }),
    },
    children: [
      // ── PAGE DE GARDE ──
      sp(600),
      new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 200 }, children: [new TextRun({ text: "INSTITUT PASTEUR DE DAKAR", bold: true, size: 20, font: "Arial", color: C.ACCENT })] }),
      new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 100 }, children: [new TextRun({ text: "Portail Integre de Cyber-Gouvernance", size: 44, bold: true, font: "Arial", color: C.PRIMARY })] }),
      sp(100),
      new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 80 }, shading: { fill: C.ACCENT, type: ShadingType.CLEAR }, children: [new TextRun({ text: "   GUIDE DE DEPLOIEMENT VPS   ", size: 28, bold: true, font: "Arial", color: C.WHITE })] }),
      sp(300),
      mkTable(["Information", "Detail"], [
        ["Version", "2.0 — Architecture PostgreSQL"],
        ["Date", new Date().toLocaleDateString("fr-FR", { day: "2-digit", month: "long", year: "numeric" })],
        ["Auteur", "Cellule SEID — IPD"],
        ["Classification", "Confidentiel"],
        ["Statut", "Pret pour deploiement"],
      ], [3500, 5500]),
      pb(),

      // ── 1. PREREQUIS ──
      h1("1. Prerequis infrastructure"),
      pa("Ce guide decrit le deploiement du Portail IPD sur un serveur VPS Hostinger avec PostgreSQL, en remplacement de l'hebergement statique actuel."),
      sp(),
      h2("1.1 Specifications du serveur"),
      mkTable(["Composant", "Minimum requis", "Recommande"], [
        ["Systeme d'exploitation", "Ubuntu 22.04 LTS", "Ubuntu 24.04 LTS"],
        ["Processeur (vCPU)", "2 vCPU", "4 vCPU"],
        ["Memoire vive (RAM)", "4 Go", "8 Go"],
        ["Stockage SSD", "80 Go", "160 Go"],
        ["Bande passante", "1 To/mois", "Illimitee"],
        ["Acces", "SSH (root)", "SSH + cle publique"],
      ], [3000, 3000, 3000]),
      sp(),
      h2("1.2 Domaine et DNS"),
      bl("Domaine : seid-pasteur.org"),
      bl("Enregistrement DNS A pointant vers l'IP du VPS"),
      bl("Enregistrement AAAA (IPv6) si disponible"),
      bl("Propagation DNS : 24-48h maximum"),
      sp(),
      alert("\u26A0\uFE0F", "Assurez-vous que le domaine pointe vers l'IP du VPS avant de lancer le certificat SSL.", C.AMBER_BG, C.AMBER),
      pb(),

      // ── 2. ARCHITECTURE CIBLE ──
      h1("2. Architecture cible"),
      pa("Le portail utilise une architecture 3 tiers : Frontend React, API Routes Next.js et base de donnees PostgreSQL."),
      sp(),
      mkTable(["Composant", "Technologie", "Version"], [
        ["Systeme d'exploitation", "Ubuntu LTS", "22.04 / 24.04"],
        ["Runtime JavaScript", "Node.js LTS", "20.x"],
        ["Base de donnees", "PostgreSQL", "16"],
        ["ORM", "Prisma", "6.x"],
        ["Framework web", "Next.js (mode serveur)", "16.x"],
        ["Gestionnaire de processus", "PM2", "5.x"],
        ["Reverse proxy", "Nginx", "1.24+"],
        ["Certificat SSL", "Let's Encrypt (Certbot)", "Auto-renouvele"],
        ["Authentification", "JWT (jsonwebtoken)", "Tokens 24h"],
        ["Hachage mots de passe", "bcryptjs", "10 rounds"],
      ], [3200, 3200, 2600]),
      sp(),
      h2("2.1 Schema d'architecture"),
      pa("Navigateur → Nginx (443/SSL) → Next.js (3000) → PostgreSQL (5432)", { bold: true, color: C.ACCENT }),
      sp(),
      bl("Nginx recoit les requetes HTTPS et les transmet a Next.js (reverse proxy)"),
      bl("Next.js sert les pages React + traite les API Routes (/api/*)"),
      bl("Les API Routes interrogent PostgreSQL via Prisma ORM"),
      bl("PM2 maintient le processus Node.js en vie (auto-restart)"),
      pb(),

      // ── 3. ETAPE 1 — INSTALLATION ──
      h1("3. Etape 1 — Installation du serveur"),
      pa("Un script automatise l'installation de tous les composants necessaires."),
      sp(),
      h2("3.1 Connexion au VPS"),
      code("ssh root@IP_DU_VPS"),
      sp(),
      h2("3.2 Execution du script d'installation"),
      code("chmod +x scripts/setup-vps.sh"),
      code("sudo ./scripts/setup-vps.sh"),
      sp(),
      pa("Le script effectue les operations suivantes :"),
      nl("Mise a jour du systeme (apt update && apt upgrade)"),
      nl("Installation de Node.js 20 LTS via NodeSource"),
      nl("Installation de PostgreSQL 16 via le depot officiel"),
      nl("Creation de l'utilisateur ipd_user et de la base portail_ipd"),
      nl("Installation de PM2 (gestionnaire de processus)"),
      nl("Installation de Nginx et Certbot (SSL)"),
      nl("Creation du repertoire /var/www/portail-ipd"),
      sp(),
      alert("\u2705", "A la fin du script, tous les composants sont installes et la base de donnees est prete.", C.GREEN_BG, C.GREEN),
      pb(),

      // ── 4. ETAPE 2 — CONFIGURATION ──
      h1("4. Etape 2 — Configuration de l'environnement"),
      pa("Creer le fichier de variables d'environnement sur le serveur :"),
      sp(),
      code("cat > /var/www/portail-ipd/.env << EOF"),
      code('DATABASE_URL="postgresql://ipd_user:IpdSecure2026!@localhost:5432/portail_ipd"'),
      code('JWT_SECRET="VOTRE_CLE_SECRETE_64_CARACTERES"'),
      code('JWT_EXPIRY="24h"'),
      code("EOF"),
      sp(),
      h2("4.1 Generation de la cle JWT"),
      pa("Generer une cle secrete aleatoire de 64 caracteres :"),
      code("openssl rand -hex 32"),
      sp(),
      alert("\u26A0\uFE0F", "Ne JAMAIS partager le fichier .env ni le committer dans Git. Il contient les identifiants de la base de donnees et la cle JWT.", C.RED_BG, C.RED),
      sp(),
      h2("4.2 Variables d'environnement"),
      mkTable(["Variable", "Description", "Exemple"], [
        ["DATABASE_URL", "URL de connexion PostgreSQL", "postgresql://ipd_user:***@localhost:5432/portail_ipd"],
        ["JWT_SECRET", "Cle de signature des tokens JWT", "k8Xm2vP9qR7wL4n... (64 chars)"],
        ["JWT_EXPIRY", "Duree de validite des sessions", "24h"],
      ], [2500, 3500, 3000]),
      pb(),

      // ── 5. ETAPE 3 — DEPLOIEMENT ──
      h1("5. Etape 3 — Deploiement de l'application"),
      pa("Un script automatise le deploiement complet depuis votre machine locale :"),
      sp(),
      code("./scripts/deploy-vps.sh IP_DU_VPS"),
      sp(),
      pa("Le script execute les etapes suivantes :"),
      nl("Bascule automatique en mode serveur (supprime output: 'export')"),
      nl("Synchronisation des fichiers vers le VPS via rsync (exclut node_modules, .next, .git)"),
      nl("Installation des dependances sur le VPS (npm ci)"),
      nl("Generation du client Prisma (npx prisma generate)"),
      nl("Execution des migrations base de donnees (npx prisma migrate deploy)"),
      nl("Build de l'application Next.js (npm run build)"),
      nl("Demarrage/redemarrage via PM2 (pm2 start ecosystem.config.cjs)"),
      nl("Restauration automatique de la config statique en local"),
      sp(),
      h2("5.1 Premier deploiement — Seed de la base"),
      pa("Lors du premier deploiement, injecter les donnees initiales :"),
      code("ssh root@IP_DU_VPS"),
      code("cd /var/www/portail-ipd"),
      code("npx tsx prisma/seed.ts"),
      sp(),
      pa("Le seed insere :"),
      bl("11 utilisateurs avec hash bcrypt preserves"),
      bl("13 modules avec leurs KPI"),
      bl("11 roles avec poles et permissions RBAC"),
      bl("7 notifications initiales"),
      pb(),

      // ── 6. ETAPE 4 — NGINX + SSL ──
      h1("6. Etape 4 — Configuration Nginx et SSL"),
      sp(),
      h2("6.1 Copier la configuration Nginx"),
      code("cp /var/www/portail-ipd/nginx/portail-ipd.conf /etc/nginx/sites-available/portail-ipd"),
      code("ln -s /etc/nginx/sites-available/portail-ipd /etc/nginx/sites-enabled/"),
      code("nginx -t"),
      code("systemctl reload nginx"),
      sp(),
      h2("6.2 Obtenir le certificat SSL"),
      code("certbot --nginx -d seid-pasteur.org -d www.seid-pasteur.org"),
      sp(),
      pa("Certbot configure automatiquement :"),
      bl("Certificat SSL gratuit Let's Encrypt"),
      bl("Redirection HTTP vers HTTPS"),
      bl("Renouvellement automatique (cron integre)"),
      sp(),
      h2("6.3 Fonctionnalites Nginx"),
      bl("Reverse proxy vers Next.js (port 3000)"),
      bl("Headers de securite (X-Frame-Options, HSTS, XSS-Protection)"),
      bl("Cache des assets statiques (_next/static/ : 365 jours)"),
      bl("Cache des modules HTML embarques (7 jours)"),
      bl("Limite upload : 50 Mo"),
      bl("Logs : /var/log/nginx/portail-ipd.access.log"),
      pb(),

      // ── 7. ETAPE 5 — VERIFICATION ──
      h1("7. Etape 5 — Verification"),
      pa("Checklist de validation apres le deploiement :"),
      sp(),
      mkTable(["Verification", "Commande / Action", "Resultat attendu"], [
        ["Processus PM2", "pm2 status", "portail-ipd : online"],
        ["Port 3000", "curl http://localhost:3000", "HTML de la page login"],
        ["HTTPS", "https://seid-pasteur.org", "Page de connexion affichee"],
        ["Connexion admin", "sophie.diallo@pasteur.sn", "Acces au dashboard"],
        ["Dashboard", "Naviguer vers /dashboard", "Tous les modules affiches"],
        ["Admin utilisateurs", "Administration > Utilisateurs", "11 utilisateurs listes"],
        ["Admin roles", "Administration > Roles", "11 roles avec permissions"],
        ["Journal d'audit", "Administration > Audit", "Connexions journalisees"],
        ["PostgreSQL", "psql -U ipd_user -d portail_ipd -c 'SELECT count(*) FROM users'", "11 lignes"],
        ["Certificat SSL", "Verifier le cadenas navigateur", "Certificat valide"],
      ], [2500, 3500, 3000]),
      sp(),
      alert("\u2705", "Si toutes les verifications passent, le deploiement VPS est termine avec succes.", C.GREEN_BG, C.GREEN),
      pb(),

      // ── 8. MAINTENANCE ──
      h1("8. Maintenance et operations"),
      sp(),
      h2("8.1 Commandes PM2"),
      mkTable(["Commande", "Description"], [
        ["pm2 status", "Etat de l'application (online/stopped/errored)"],
        ["pm2 logs", "Logs en temps reel (stdout + stderr)"],
        ["pm2 logs --lines 100", "Derniers 100 lignes de logs"],
        ["pm2 restart portail-ipd", "Redemarrer l'application"],
        ["pm2 stop portail-ipd", "Arreter l'application"],
        ["pm2 monit", "Monitoring interactif (CPU, memoire)"],
        ["pm2 save", "Sauvegarder la configuration PM2"],
        ["pm2 startup", "Configurer le demarrage automatique au boot"],
      ], [4500, 4500]),
      sp(),
      h2("8.2 Sauvegarde de la base de donnees"),
      pa("Sauvegarde manuelle :"),
      code("pg_dump -U ipd_user portail_ipd > /var/backups/portail_ipd_$(date +%Y%m%d).sql"),
      sp(),
      pa("Sauvegarde automatique (crontab) :"),
      code("crontab -e"),
      code("0 2 * * * pg_dump -U ipd_user portail_ipd > /var/backups/portail_ipd_$(date +\\%Y\\%m\\%d).sql"),
      sp(),
      pa("Restauration :"),
      code("psql -U ipd_user portail_ipd < /var/backups/portail_ipd_20260326.sql"),
      sp(),
      h2("8.3 Mise a jour de l'application"),
      pa("Depuis votre machine locale :"),
      code("./scripts/deploy-vps.sh IP_DU_VPS"),
      pa("Le script synchronise les fichiers, rebuild et redemarre automatiquement."),
      pb(),

      // ── 9. SECURITE ──
      h1("9. Securite"),
      sp(),
      mkTable(["Mesure", "Detail", "Statut"], [
        ["PostgreSQL localhost", "Ecoute uniquement sur 127.0.0.1, pas d'acces externe", "Active"],
        ["Pare-feu UFW", "Ports ouverts : 22 (SSH), 80 (HTTP), 443 (HTTPS) uniquement", "A configurer"],
        ["SSL/TLS", "Certificat Let's Encrypt avec renouvellement automatique", "Active"],
        ["Hachage mots de passe", "bcrypt avec 10 rounds de salt", "Active"],
        ["Sessions JWT", "Tokens signes avec expiration 24h, cookies HttpOnly/Secure/SameSite=Strict", "Active"],
        ["Rate limiting", "5 tentatives max, blocage 15 min (table login_attempts)", "Active"],
        ["Audit", "Toutes les actions journalisees dans la table audit_logs", "Active"],
        ["Headers securite", "X-Frame-Options, HSTS, X-Content-Type-Options, X-XSS-Protection", "Active"],
        ["Sandbox iframe", "allow-scripts allow-same-origin + referrerPolicy=no-referrer", "Active"],
      ], [2800, 4700, 1500]),
      sp(),
      h2("9.1 Configuration du pare-feu UFW"),
      code("ufw allow 22/tcp"),
      code("ufw allow 80/tcp"),
      code("ufw allow 443/tcp"),
      code("ufw enable"),
      code("ufw status"),
      sp(),
      h2("9.2 Securisation SSH"),
      bl("Desactiver l'authentification par mot de passe (utiliser les cles SSH)"),
      bl("Changer le port SSH par defaut (optionnel)"),
      bl("Installer fail2ban pour bloquer les tentatives de brute-force SSH"),
      code("apt install fail2ban"),
      pb(),

      // ── 10. CONTACTS ──
      h1("10. Contacts et support"),
      sp(),
      mkTable(["Role", "Nom", "Email"], [
        ["Administrateur systeme", "Amadou Bao", "amadou@pasteur.sn"],
        ["Support technique SEID", "Cellule SEID", "seid@pasteur.sn"],
        ["Administrateur portail", "Sophie Diallo", "sophie.diallo@pasteur.sn"],
        ["Administrateur portail", "Lamine Traore", "lamine.traore@pasteur.sn"],
      ], [3000, 3000, 3000]),
      sp(300),
      new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 80 }, children: [new TextRun({ text: "— Fin du document —", size: 20, font: "Arial", color: C.GRAY, italics: true })] }),
    ],
  }],
});

// ============ EXPORT ============
const outPath = __dirname + "/../Guide_Deploiement_VPS_IPD.docx";
Packer.toBuffer(doc).then((buf) => {
  fs.writeFileSync(outPath, buf);
  console.log(`Guide VPS cree: ${outPath} (${Math.round(buf.length / 1024)} Ko)`);
});
