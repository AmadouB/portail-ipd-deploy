const fs = require("fs");
const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  Header, Footer, AlignmentType, LevelFormat, ExternalHyperlink,
  TableOfContents, HeadingLevel, BorderStyle, WidthType, ShadingType,
  PageNumber, PageBreak,
} = require("docx");

// Colors
const PRIMARY = "0C4A6E";    // Dark blue
const ACCENT = "06B6D4";     // Cyan
const DARK = "1E293B";
const GRAY = "64748B";
const LIGHT_BG = "F0F9FF";
const WHITE = "FFFFFF";

const border = { style: BorderStyle.SINGLE, size: 1, color: "CBD5E1" };
const borders = { top: border, bottom: border, left: border, right: border };
const noBorder = { style: BorderStyle.NONE, size: 0 };
const noBorders = { top: noBorder, bottom: noBorder, left: noBorder, right: noBorder };
const cellMargins = { top: 80, bottom: 80, left: 120, right: 120 };

function heading1(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_1,
    spacing: { before: 360, after: 200 },
    children: [new TextRun({ text, bold: true, size: 32, font: "Arial", color: PRIMARY })],
  });
}

function heading2(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_2,
    spacing: { before: 280, after: 160 },
    children: [new TextRun({ text, bold: true, size: 26, font: "Arial", color: PRIMARY })],
  });
}

function para(text, opts = {}) {
  return new Paragraph({
    spacing: { after: 120 },
    alignment: opts.align || AlignmentType.LEFT,
    children: [new TextRun({ text, size: 22, font: "Arial", color: opts.color || DARK, bold: opts.bold, italics: opts.italic })],
  });
}

function bulletItem(text, ref = "bullets", level = 0) {
  return new Paragraph({
    numbering: { reference: ref, level },
    spacing: { after: 80 },
    children: [new TextRun({ text, size: 22, font: "Arial", color: DARK })],
  });
}

function numberItem(text, ref = "numbers") {
  return new Paragraph({
    numbering: { reference: ref, level: 0 },
    spacing: { after: 80 },
    children: [new TextRun({ text, size: 22, font: "Arial", color: DARK })],
  });
}

function labelValue(label, value) {
  return new Paragraph({
    spacing: { after: 80 },
    numbering: { reference: "bullets", level: 0 },
    children: [
      new TextRun({ text: label + " : ", size: 22, font: "Arial", bold: true, color: DARK }),
      new TextRun({ text: value, size: 22, font: "Arial", color: DARK }),
    ],
  });
}

function spacer(h = 200) {
  return new Paragraph({ spacing: { after: h }, children: [] });
}

function makeCell(text, opts = {}) {
  return new TableCell({
    borders,
    width: { size: opts.width || 2340, type: WidthType.DXA },
    shading: opts.header ? { fill: PRIMARY, type: ShadingType.CLEAR } : (opts.altRow ? { fill: LIGHT_BG, type: ShadingType.CLEAR } : undefined),
    margins: cellMargins,
    verticalAlign: "center",
    children: [new Paragraph({
      children: [new TextRun({
        text,
        size: opts.header ? 20 : 20,
        font: "Arial",
        bold: opts.header || false,
        color: opts.header ? WHITE : DARK,
      })],
    })],
  });
}

// Users table data
const users = [
  ["Abdoulaye Sall", "a.sall@pasteur.sn", "Admin G\u00e9n\u00e9ral", "Direction G\u00e9n\u00e9rale"],
  ["Amadou Bao", "a.bao@pasteur.sn", "SEID", "Cellule SEID"],
  ["Fatou Diagne", "f.diagne@pasteur.sn", "CAS", "Gouvernance"],
  ["Ndey Coumba", "n.coumba@pasteur.sn", "Dir. Sant\u00e9 Publique", "Sant\u00e9 Publique"],
  ["Moussa Ndiaye", "m.ndiaye@pasteur.sn", "DSI", "Syst\u00e8mes d\u2019Information"],
  ["Ibrahima Soc\u00e9 Fall", "ibrahima.fall@pasteur.sn", "Utilisateur", "Direction G\u00e9n\u00e9rale"],
  ["Sophie Diallo", "sophie.diallo@pasteur.sn", "Admin G\u00e9n\u00e9ral", "Administration et Finance"],
  ["Fatoumata Niang", "fatoumata.niang@pasteur.sn", "Utilisateur", "Capital Humain"],
  ["SEID IPD", "seid@pasteur.sn", "Utilisateur", "Cellule SEID"],
  ["Amadou Bao", "amadou@pasteur.sn", "Utilisateur", "Direction G\u00e9n\u00e9rale"],
  ["Lamine Traor\u00e9", "lamine.traore@pasteur.sn", "Admin G\u00e9n\u00e9ral", "Direction G\u00e9n\u00e9rale"],
];

const usersTable = new Table({
  width: { size: 9360, type: WidthType.DXA },
  columnWidths: [2200, 2800, 2160, 2200],
  rows: [
    new TableRow({
      children: [
        makeCell("Nom", { header: true, width: 2200 }),
        makeCell("Email", { header: true, width: 2800 }),
        makeCell("R\u00f4le", { header: true, width: 2160 }),
        makeCell("D\u00e9partement", { header: true, width: 2200 }),
      ],
    }),
    ...users.map((u, i) => new TableRow({
      children: [
        makeCell(u[0], { width: 2200, altRow: i % 2 === 0 }),
        makeCell(u[1], { width: 2800, altRow: i % 2 === 0 }),
        makeCell(u[2], { width: 2160, altRow: i % 2 === 0 }),
        makeCell(u[3], { width: 2200, altRow: i % 2 === 0 }),
      ],
    })),
  ],
});

// Poles table
const poles = [
  ["Gouvernance", "Cyan (#06B6D4)", "Cockpit Strat\u00e9gique, SEID Intelligence"],
  ["Fonctions M\u00e9tiers", "Vert / Violet", "IMS NextGen, Modules Suivi, Surveillance \u00c9pid\u00e9miologique"],
  ["Op\u00e9rations", "Ambre (#F59E0B)", "Administration Portail, RH, Finance"],
  ["Partenariat", "Violet (#8B5CF6)", "Mobilisation Ressources, Relations M\u00e9dias"],
];

const polesTable = new Table({
  width: { size: 9360, type: WidthType.DXA },
  columnWidths: [2200, 2200, 4960],
  rows: [
    new TableRow({
      children: [
        makeCell("P\u00f4le", { header: true, width: 2200 }),
        makeCell("Couleur", { header: true, width: 2200 }),
        makeCell("Modules", { header: true, width: 4960 }),
      ],
    }),
    ...poles.map((p, i) => new TableRow({
      children: [
        makeCell(p[0], { width: 2200, altRow: i % 2 === 0 }),
        makeCell(p[1], { width: 2200, altRow: i % 2 === 0 }),
        makeCell(p[2], { width: 4960, altRow: i % 2 === 0 }),
      ],
    })),
  ],
});

// Roles table
const roles = [
  ["Administrateur G\u00e9n\u00e9ral", "Tous les modules", "Lecture, \u00c9criture, Administration"],
  ["Utilisateur", "Modules du p\u00f4le assign\u00e9", "Lecture seule"],
];

const rolesTable = new Table({
  width: { size: 9360, type: WidthType.DXA },
  columnWidths: [2800, 3280, 3280],
  rows: [
    new TableRow({
      children: [
        makeCell("R\u00f4le", { header: true, width: 2800 }),
        makeCell("Acc\u00e8s modules", { header: true, width: 3280 }),
        makeCell("Permissions", { header: true, width: 3280 }),
      ],
    }),
    ...roles.map((r, i) => new TableRow({
      children: [
        makeCell(r[0], { width: 2800, altRow: i % 2 === 0 }),
        makeCell(r[1], { width: 3280, altRow: i % 2 === 0 }),
        makeCell(r[2], { width: 3280, altRow: i % 2 === 0 }),
      ],
    })),
  ],
});

// Modules P1/P2 table
const futureModules = [
  ["Production Vaccins", "P1", "Suivi de la cha\u00eene de production, lots et conformit\u00e9 OMS/ARP"],
  ["Grant Office", "P1", "Gestion des subventions et projets de recherche"],
  ["Ressources Humaines", "P1", "Gestion des talents, recrutement, formations"],
  ["Finance & Logistique", "P1", "Comptabilit\u00e9, tr\u00e9sorerie, gestion budg\u00e9taire"],
  ["Mobilisation Ressources", "P2", "Cartographie des partenaires et pipeline"],
  ["Relations M\u00e9dias", "P2", "Gestion des \u00e9v\u00e9nements et relations presse"],
];

const futureTable = new Table({
  width: { size: 9360, type: WidthType.DXA },
  columnWidths: [2600, 760, 6000],
  rows: [
    new TableRow({
      children: [
        makeCell("Module", { header: true, width: 2600 }),
        makeCell("Priorit\u00e9", { header: true, width: 760 }),
        makeCell("Description", { header: true, width: 6000 }),
      ],
    }),
    ...futureModules.map((m, i) => new TableRow({
      children: [
        makeCell(m[0], { width: 2600, altRow: i % 2 === 0 }),
        makeCell(m[1], { width: 760, altRow: i % 2 === 0 }),
        makeCell(m[2], { width: 6000, altRow: i % 2 === 0 }),
      ],
    })),
  ],
});

const doc = new Document({
  styles: {
    default: {
      document: { run: { font: "Arial", size: 22, color: DARK } },
    },
    paragraphStyles: [
      {
        id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 32, bold: true, font: "Arial", color: PRIMARY },
        paragraph: { spacing: { before: 360, after: 200 }, outlineLevel: 0 },
      },
      {
        id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 26, bold: true, font: "Arial", color: PRIMARY },
        paragraph: { spacing: { before: 280, after: 160 }, outlineLevel: 1 },
      },
    ],
  },
  numbering: {
    config: [
      {
        reference: "bullets",
        levels: [{
          level: 0, format: LevelFormat.BULLET, text: "\u2022", alignment: AlignmentType.LEFT,
          style: { paragraph: { indent: { left: 720, hanging: 360 } } },
        }],
      },
      {
        reference: "numbers",
        levels: [{
          level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT,
          style: { paragraph: { indent: { left: 720, hanging: 360 } } },
        }],
      },
      {
        reference: "numbers2",
        levels: [{
          level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT,
          style: { paragraph: { indent: { left: 720, hanging: 360 } } },
        }],
      },
    ],
  },
  sections: [
    // COVER PAGE
    {
      properties: {
        page: {
          size: { width: 12240, height: 15840 },
          margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 },
        },
      },
      children: [
        spacer(2000),
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { after: 100 },
          children: [new TextRun({ text: "INSTITUT PASTEUR DE DAKAR", size: 28, font: "Arial", bold: true, color: GRAY })],
        }),
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { after: 80 },
          border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: ACCENT, space: 8 } },
          children: [],
        }),
        spacer(200),
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { after: 200 },
          children: [new TextRun({ text: "PORTAIL INT\u00c9GR\u00c9 DE", size: 44, font: "Arial", bold: true, color: PRIMARY })],
        }),
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { after: 300 },
          children: [new TextRun({ text: "CYBER-GOUVERNANCE", size: 44, font: "Arial", bold: true, color: ACCENT })],
        }),
        spacer(200),
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { after: 80 },
          border: { top: { style: BorderStyle.SINGLE, size: 6, color: ACCENT, space: 8 } },
          children: [],
        }),
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { after: 200 },
          children: [new TextRun({ text: "GUIDE D\u2019UTILISATEUR", size: 36, font: "Arial", bold: true, color: PRIMARY })],
        }),
        spacer(600),
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { after: 100 },
          children: [new TextRun({ text: "Version 1.0 \u2014 Mars 2026", size: 22, font: "Arial", color: GRAY })],
        }),
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { after: 100 },
          children: [new TextRun({ text: "https://seid-pasteur.org", size: 22, font: "Arial", color: ACCENT })],
        }),
        new Paragraph({
          alignment: AlignmentType.CENTER,
          children: [new TextRun({ text: "Document confidentiel \u2014 Usage interne IPD", size: 18, font: "Arial", italics: true, color: GRAY })],
        }),
      ],
    },
    // TABLE OF CONTENTS + CONTENT
    {
      properties: {
        page: {
          size: { width: 12240, height: 15840 },
          margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 },
        },
      },
      headers: {
        default: new Header({
          children: [new Paragraph({
            border: { bottom: { style: BorderStyle.SINGLE, size: 2, color: ACCENT, space: 4 } },
            children: [
              new TextRun({ text: "Guide d\u2019utilisateur \u2014 Portail IPD", size: 16, font: "Arial", color: GRAY, italics: true }),
            ],
          })],
        }),
      },
      footers: {
        default: new Footer({
          children: [new Paragraph({
            alignment: AlignmentType.CENTER,
            border: { top: { style: BorderStyle.SINGLE, size: 2, color: ACCENT, space: 4 } },
            children: [
              new TextRun({ text: "Institut Pasteur de Dakar \u2014 ", size: 16, font: "Arial", color: GRAY }),
              new TextRun({ text: "Page ", size: 16, font: "Arial", color: GRAY }),
              new TextRun({ children: [PageNumber.CURRENT], size: 16, font: "Arial", color: GRAY }),
            ],
          })],
        }),
      },
      children: [
        // TOC
        new Paragraph({
          spacing: { after: 300 },
          children: [new TextRun({ text: "TABLE DES MATI\u00c8RES", size: 32, font: "Arial", bold: true, color: PRIMARY })],
        }),
        new TableOfContents("Sommaire", { hyperlink: true, headingStyleRange: "1-2" }),

        new Paragraph({ children: [new PageBreak()] }),

        // 1. PRESENTATION
        heading1("1. Pr\u00e9sentation g\u00e9n\u00e9rale"),
        para("Le Portail Int\u00e9gr\u00e9 de Cyber-Gouvernance de l\u2019Institut Pasteur de Dakar est une plateforme centralis\u00e9e de pilotage strat\u00e9gique et op\u00e9rationnel. Il offre une vue unifi\u00e9e des activit\u00e9s de l\u2019IPD \u00e0 travers des modules sp\u00e9cialis\u00e9s couvrant la gouvernance, les fonctions m\u00e9tiers, les op\u00e9rations et les partenariats."),
        spacer(80),
        new Paragraph({
          spacing: { after: 120 },
          children: [new TextRun({ text: "Objectifs du portail :", size: 22, font: "Arial", bold: true, color: PRIMARY })],
        }),
        bulletItem("Centraliser le pilotage strat\u00e9gique et op\u00e9rationnel de l\u2019IPD"),
        bulletItem("Fournir des tableaux de bord en temps r\u00e9el pour chaque direction"),
        bulletItem("Renforcer la tra\u00e7abilit\u00e9 et la conformit\u00e9 r\u00e9glementaire"),
        bulletItem("Faciliter la coordination inter-services"),
        bulletItem("S\u00e9curiser l\u2019acc\u00e8s aux donn\u00e9es sensibles"),
        spacer(80),
        new Paragraph({
          spacing: { after: 120 },
          children: [
            new TextRun({ text: "URL d\u2019acc\u00e8s : ", size: 22, font: "Arial", bold: true, color: DARK }),
            new ExternalHyperlink({
              children: [new TextRun({ text: "https://seid-pasteur.org", size: 22, font: "Arial", color: ACCENT, underline: {} })],
              link: "https://seid-pasteur.org",
            }),
          ],
        }),

        new Paragraph({ children: [new PageBreak()] }),

        // 2. CONNEXION
        heading1("2. Connexion au portail"),
        para("Pour acc\u00e9der au portail, suivez les \u00e9tapes suivantes :"),
        spacer(40),
        numberItem("Ouvrir votre navigateur web (Chrome, Firefox, Edge ou Safari recommand\u00e9s)"),
        numberItem("Acc\u00e9der \u00e0 l\u2019adresse https://seid-pasteur.org"),
        numberItem("Saisir votre adresse email institutionnelle dans le champ \u00ab Adresse email \u00bb"),
        numberItem("Saisir votre mot de passe dans le champ \u00ab Mot de passe \u00bb"),
        numberItem("Cliquer sur le bouton \u00ab Se connecter \u00bb"),
        spacer(100),
        para("La page de connexion affiche une visualisation 3D interactive des diff\u00e9rentes entit\u00e9s de l\u2019IPD (Direction, Fonctions M\u00e9tiers, Fonctions Op\u00e9rationnelles) organis\u00e9es en orbites."),
        spacer(60),
        heading2("2.1 S\u00e9curit\u00e9 de la connexion"),
        para("Le portail utilise une authentification JWT (JSON Web Token) c\u00f4t\u00e9 serveur. Les sessions sont g\u00e9r\u00e9es dans la base de donn\u00e9es PostgreSQL avec une expiration automatique de 24 heures."),
        para("M\u00e9canismes de s\u00e9curit\u00e9 en place :", { bold: true }),
        bulletItem("Authentification JWT serveur : \u00e0 la connexion, un token JWT s\u00e9curis\u00e9 est g\u00e9n\u00e9r\u00e9 c\u00f4t\u00e9 serveur et transmis via un cookie HttpOnly, Secure, SameSite=Strict. Aucun token n\u2019est stock\u00e9 dans le localStorage."),
        bulletItem("Sessions en base de donn\u00e9es : chaque session est enregistr\u00e9e dans PostgreSQL avec v\u00e9rification automatique toutes les 60 secondes pour d\u00e9tecter toute invalidation ou expiration."),
        bulletItem("Hachage des mots de passe : vos mots de passe sont hach\u00e9s avec l\u2019algorithme bcrypt (10 rounds). Aucun mot de passe n\u2019est stock\u00e9 en clair."),
        bulletItem("Protection anti brute-force : apr\u00e8s 5 tentatives de connexion \u00e9chou\u00e9es, votre compte est temporairement verrouill\u00e9 pendant 15 minutes (rate limiting c\u00f4t\u00e9 serveur)."),
        bulletItem("Expiration de session : votre session expire automatiquement apr\u00e8s 24 heures. Vous serez redirig\u00e9 vers la page de connexion."),
        bulletItem("D\u00e9tection d\u2019anomalie : le syst\u00e8me v\u00e9rifie l\u2019empreinte de votre navigateur pour d\u00e9tecter toute tentative d\u2019usurpation de session."),
        bulletItem("Journalisation : toutes les connexions (r\u00e9ussies et \u00e9chou\u00e9es) sont enregistr\u00e9es dans la table audit_logs de PostgreSQL."),
        spacer(60),
        new Paragraph({
          spacing: { after: 120 },
          shading: { fill: "FEF3C7", type: ShadingType.CLEAR },
          indent: { left: 200, right: 200 },
          children: [
            new TextRun({ text: "\u26a0 Important : ", size: 22, font: "Arial", bold: true, color: "92400E" }),
            new TextRun({ text: "En cas d\u2019oubli de mot de passe, contactez l\u2019administrateur syst\u00e8me. Ne communiquez jamais vos identifiants \u00e0 un tiers. Apr\u00e8s 5 tentatives \u00e9chou\u00e9es, votre compte sera verrouill\u00e9 pendant 15 minutes.", size: 22, font: "Arial", color: "92400E" }),
          ],
        }),

        new Paragraph({ children: [new PageBreak()] }),

        // 3. COMPTES
        heading1("3. Comptes utilisateurs"),
        para("Le tableau ci-dessous r\u00e9pertorie les comptes actifs du portail :"),
        spacer(80),
        usersTable,
        spacer(120),
        new Paragraph({
          spacing: { after: 120 },
          shading: { fill: "DBEAFE", type: ShadingType.CLEAR },
          indent: { left: 200, right: 200 },
          children: [
            new TextRun({ text: "\u2139 Note : ", size: 22, font: "Arial", bold: true, color: "1E40AF" }),
            new TextRun({ text: "Les mots de passe forts sont g\u00e9n\u00e9r\u00e9s automatiquement au format IPD-XXXX-XXXX-XXXXXX et hach\u00e9s avec bcrypt (jamais stock\u00e9s en clair). Les administrateurs (Sophie Diallo, Lamine Traor\u00e9 et Abdoulaye Sall) disposent d\u2019un acc\u00e8s complet \u00e0 tous les modules.", size: 22, font: "Arial", color: "1E40AF" }),
          ],
        }),

        new Paragraph({ children: [new PageBreak()] }),

        // 4. DASHBOARD
        heading1("4. Tableau de bord principal"),
        para("Apr\u00e8s connexion, le tableau de bord affiche tous les modules accessibles sous forme de tuiles interactives. Chaque tuile pr\u00e9sente :"),
        spacer(40),
        bulletItem("Le nom et l\u2019ic\u00f4ne du module"),
        bulletItem("Une description courte de sa fonction"),
        bulletItem("Un indicateur KPI principal avec sa valeur actuelle"),
        bulletItem("La tendance (hausse, baisse ou stable)"),
        bulletItem("Un code couleur correspondant au p\u00f4le d\u2019appartenance"),
        spacer(120),
        heading2("4.1 Organisation par p\u00f4les"),
        para("Les modules sont organis\u00e9s en quatre p\u00f4les fonctionnels :"),
        spacer(80),
        polesTable,

        new Paragraph({ children: [new PageBreak()] }),

        // 5. MODULES ACTIFS
        heading1("5. Modules actifs"),
        para("Les modules suivants sont actuellement op\u00e9rationnels et accessibles depuis le tableau de bord."),

        spacer(80),
        heading2("5.1 IMS NextGen"),
        labelValue("Acc\u00e8s", "Fonctions M\u00e9tiers > IMS NextGen"),
        labelValue("Description", "Syst\u00e8me de Management Int\u00e9gr\u00e9 \u2014 Tableau de bord qualit\u00e9, production et conformit\u00e9 IPD"),
        labelValue("KPI", "Conformit\u00e9 IMS : 94,2%"),
        para("Fonctionnalit\u00e9s principales :", { bold: true }),
        bulletItem("Tableau de bord interactif avec navigation lat\u00e9rale"),
        bulletItem("Suivi qualit\u00e9 et indicateurs de production"),
        bulletItem("Graphiques de performance et suivi des risques"),
        bulletItem("Mode plein \u00e9cran pour une vue immersive"),

        spacer(80),
        heading2("5.2 Modules Suivi"),
        labelValue("Acc\u00e8s", "Fonctions M\u00e9tiers > Modules Suivi"),
        labelValue("Description", "Coordination et suivi int\u00e9gr\u00e9 des activit\u00e9s de production, qualit\u00e9 et conformit\u00e9 IMS/UVFJ"),
        labelValue("KPI", "Avancement global : 87,8%"),
        para("Onglet Coordination :", { bold: true }),
        bulletItem("Tableau de bord IMS UVFJ complet"),
        bulletItem("Suivi production, LCQ, CAPA OMS, Workshop ZAC"),
        bulletItem("Suivi Supply Chain et Finance"),
        bulletItem("Mode plein \u00e9cran disponible"),

        spacer(80),
        heading2("5.3 Cockpit Strat\u00e9gique"),
        labelValue("Acc\u00e8s", "Gouvernance > Cockpit Strat\u00e9gique"),
        labelValue("Description", "Pilotage global, KPIs strat\u00e9giques et indicateurs de performance institutionnelle"),
        labelValue("KPI", "Taux d\u2019ex\u00e9cution : 78%"),

        spacer(80),
        heading2("5.4 SEID \u2014 Intelligence"),
        labelValue("Acc\u00e8s", "Gouvernance > SEID Intelligence"),
        labelValue("Description", "Suivi-\u00c9valuation et Intelligence de Donn\u00e9es, Command Center et qualit\u00e9 des donn\u00e9es"),
        labelValue("KPI", "Sources actives : 24/28"),

        spacer(80),
        heading2("5.5 Surveillance \u00c9pid\u00e9miologique"),
        labelValue("Acc\u00e8s", "Fonctions M\u00e9tiers > Surveillance \u00c9pid\u00e9miologique"),
        labelValue("Description", "Veille sanitaire, alertes \u00e9pid\u00e9miques et suivi des pathologies en temps r\u00e9el"),
        labelValue("KPI", "Alertes actives : 3"),

        spacer(80),
        heading2("5.6 Administration Portail"),
        labelValue("Acc\u00e8s", "Op\u00e9rations > Administration Portail"),
        labelValue("Restriction", "R\u00e9serv\u00e9 aux administrateurs"),
        para("Fonctionnalit\u00e9s :", { bold: true }),
        bulletItem("Gestion des utilisateurs : cr\u00e9ation, modification, suppression, activation/d\u00e9sactivation"),
        bulletItem("Gestion des r\u00f4les et permissions (RBAC) avec matrice d\u00e9taill\u00e9e"),
        bulletItem("Gestion et publication de modules personnalis\u00e9s (HTML)"),
        bulletItem("Journal d\u2019audit en temps r\u00e9el : suivi des connexions, actions et \u00e9v\u00e9nements de s\u00e9curit\u00e9"),
        bulletItem("R\u00e9initialisation s\u00e9curis\u00e9e des mots de passe (g\u00e9n\u00e9ration forte + hachage bcrypt)"),
        bulletItem("Sant\u00e9 syst\u00e8me : \u00e9tat des services d\u2019infrastructure"),

        new Paragraph({ children: [new PageBreak()] }),

        // 6. MODULES EN DEV
        heading1("6. Modules en d\u00e9veloppement"),
        para("Les modules suivants sont en cours de d\u00e9veloppement et seront progressivement int\u00e9gr\u00e9s au portail :"),
        spacer(80),
        futureTable,

        new Paragraph({ children: [new PageBreak()] }),

        // 7. FONCTIONNALITES
        heading1("7. Fonctionnalit\u00e9s communes"),

        heading2("7.1 Navigation"),
        bulletItem("Cliquer sur une tuile module pour y acc\u00e9der"),
        bulletItem("Utiliser le bouton retour (fl\u00e8che) pour revenir au tableau de bord"),
        bulletItem("Les modules actifs sont mis en \u00e9vidence, les modules d\u00e9sactiv\u00e9s apparaissent gris\u00e9s"),

        spacer(80),
        heading2("7.2 Mode plein \u00e9cran"),
        bulletItem("Disponible dans les modules IMS NextGen et Modules Suivi"),
        bulletItem("Cliquer sur l\u2019ic\u00f4ne d\u2019agrandissement en haut \u00e0 droite"),
        bulletItem("Cliquer sur l\u2019ic\u00f4ne de r\u00e9duction ou sur l\u2019arri\u00e8re-plan pour quitter"),

        spacer(80),
        heading2("7.3 Responsive design"),
        para("Le portail s\u2019adapte automatiquement aux diff\u00e9rentes tailles d\u2019\u00e9cran :"),
        bulletItem("Desktop : affichage complet avec visualisation 3D"),
        bulletItem("Tablette : mise en page adapt\u00e9e"),
        bulletItem("Mobile : interface compacte et navigation simplifi\u00e9e"),

        spacer(80),
        heading2("7.4 D\u00e9connexion"),
        bulletItem("Cliquer sur l\u2019ic\u00f4ne utilisateur en haut \u00e0 droite"),
        bulletItem("S\u00e9lectionner \u00ab Se d\u00e9connecter \u00bb"),
        bulletItem("La session serveur est d\u00e9truite dans la base de donn\u00e9es PostgreSQL (appel API POST /api/auth/logout)"),
        bulletItem("Le token JWT est invalid\u00e9 c\u00f4t\u00e9 serveur et le cookie de session est supprim\u00e9"),
        bulletItem("Vous serez redirig\u00e9 vers la page de connexion"),
        bulletItem("La session expire \u00e9galement automatiquement apr\u00e8s 24 heures d\u2019inactivit\u00e9"),
        bulletItem("La d\u00e9connexion est journalis\u00e9e dans la table audit_logs de PostgreSQL"),

        new Paragraph({ children: [new PageBreak()] }),

        // 8. ROLES
        heading1("8. Gestion des r\u00f4les et permissions"),
        para("Le portail utilise un syst\u00e8me de contr\u00f4le d\u2019acc\u00e8s bas\u00e9 sur les r\u00f4les (RBAC) pour g\u00e9rer les permissions des utilisateurs. Les r\u00f4les sont stock\u00e9s dans la base de donn\u00e9es PostgreSQL et g\u00e9r\u00e9s via les API Routes du portail."),
        spacer(80),
        rolesTable,
        spacer(120),
        para("Gestion dynamique des r\u00f4les :", { bold: true }),
        bulletItem("Les permissions sont g\u00e9r\u00e9es via l\u2019API /api/roles/* (GET, POST, PATCH, DELETE)"),
        bulletItem("L\u2019administrateur peut modifier les r\u00f4les dynamiquement depuis l\u2019interface Administration > R\u00f4les"),
        bulletItem("Toute modification de r\u00f4le est imm\u00e9diatement appliqu\u00e9e dans la base de donn\u00e9es PostgreSQL"),
        bulletItem("Les changements sont journalis\u00e9s dans la table audit_logs"),
        spacer(80),
        para("Pour toute demande de modification de permissions, contactez l\u2019\u00e9quipe d\u2019administration."),

        new Paragraph({ children: [new PageBreak()] }),

        // 9. SUPPORT
        heading1("9. Support et contact"),
        para("Pour toute assistance technique ou fonctionnelle concernant le portail, contactez :"),
        spacer(80),
        labelValue("Cellule SEID", "seid@pasteur.sn"),
        labelValue("Support technique", "amadou@pasteur.sn"),
        spacer(200),
        new Paragraph({
          alignment: AlignmentType.CENTER,
          border: { top: { style: BorderStyle.SINGLE, size: 2, color: ACCENT, space: 8 } },
          spacing: { before: 200, after: 100 },
          children: [new TextRun({ text: "Institut Pasteur de Dakar", size: 22, font: "Arial", bold: true, color: PRIMARY })],
        }),
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { after: 60 },
          children: [new TextRun({ text: "Portail Int\u00e9gr\u00e9 de Cyber-Gouvernance", size: 20, font: "Arial", color: GRAY })],
        }),
        new Paragraph({
          alignment: AlignmentType.CENTER,
          children: [new TextRun({ text: "Version 1.0 \u2014 Mars 2026", size: 20, font: "Arial", color: GRAY })],
        }),
      ],
    },
  ],
});

const OUT = "/Users/amadou/Documents/IPD/portail-ipd/Guide_Utilisateur_Portail_IPD.docx";
Packer.toBuffer(doc).then(buf => {
  fs.writeFileSync(OUT, buf);
  console.log("Guide cree:", OUT, `(${(buf.length / 1024).toFixed(0)} Ko)`);
});
