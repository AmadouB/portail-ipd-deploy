const fs = require("fs");
const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  Header, Footer, AlignmentType, LevelFormat, ExternalHyperlink,
  TableOfContents, HeadingLevel, BorderStyle, WidthType, ShadingType,
  PageNumber, PageBreak,
} = require("docx");

// ============ DESIGN TOKENS ============
const C = {
  PRIMARY: "0C4A6E", ACCENT: "06B6D4", DARK: "1E293B", GRAY: "64748B", LIGHT: "F0F9FF", WHITE: "FFFFFF",
  GREEN: "065F46", GREEN_BG: "D1FAE5", AMBER: "92400E", AMBER_BG: "FEF3C7",
  RED: "991B1B", RED_BG: "FEE2E2", BLUE: "1E40AF", BLUE_BG: "DBEAFE",
  PURPLE: "5B21B6", PURPLE_BG: "EDE9FE", CYAN_BG: "CFFAFE", CYAN: "0E7490",
};
const bdr = { style: BorderStyle.SINGLE, size: 1, color: "CBD5E1" };
const borders = { top: bdr, bottom: bdr, left: bdr, right: bdr };
const cm = { top: 80, bottom: 80, left: 120, right: 120 };

// ============ HELPERS ============
const h1 = (t) => new Paragraph({ heading: HeadingLevel.HEADING_1, spacing: { before: 400, after: 220 }, children: [new TextRun({ text: t, bold: true, size: 34, font: "Arial", color: C.PRIMARY })] });
const h2 = (t) => new Paragraph({ heading: HeadingLevel.HEADING_2, spacing: { before: 300, after: 180 }, children: [new TextRun({ text: t, bold: true, size: 28, font: "Arial", color: C.PRIMARY })] });
const h3 = (t) => new Paragraph({ heading: HeadingLevel.HEADING_3, spacing: { before: 220, after: 120 }, children: [new TextRun({ text: t, bold: true, size: 24, font: "Arial", color: C.ACCENT })] });
const pa = (t, o = {}) => new Paragraph({ spacing: { after: o.after || 120 }, alignment: o.align || AlignmentType.LEFT, indent: o.indent ? { left: o.indent } : undefined, children: Array.isArray(t) ? t : [new TextRun({ text: t, size: 22, font: "Arial", color: o.color || C.DARK, bold: o.bold, italics: o.italic })] });
const bl = (t, ref = "b1") => new Paragraph({ numbering: { reference: ref, level: 0 }, spacing: { after: 70 }, children: [new TextRun({ text: t, size: 22, font: "Arial", color: C.DARK })] });
const bl2 = (t, ref = "b2") => new Paragraph({ numbering: { reference: ref, level: 0 }, spacing: { after: 70 }, indent: { left: 1080 }, children: [new TextRun({ text: t, size: 21, font: "Arial", color: C.DARK })] });
const bv = (l, v, ref = "b1") => new Paragraph({ numbering: { reference: ref, level: 0 }, spacing: { after: 70 }, children: [new TextRun({ text: l + " : ", size: 22, font: "Arial", bold: true, color: C.DARK }), new TextRun({ text: v, size: 22, font: "Arial", color: C.DARK })] });
const nl = (t, ref = "n1") => new Paragraph({ numbering: { reference: ref, level: 0 }, spacing: { after: 80 }, children: Array.isArray(t) ? t : [new TextRun({ text: t, size: 22, font: "Arial", color: C.DARK })] });
const sp = (h = 120) => new Paragraph({ spacing: { after: h }, children: [] });
const pb = () => new Paragraph({ children: [new PageBreak()] });
const alert = (icon, text, bg, fg) => new Paragraph({ spacing: { after: 160, before: 80 }, shading: { fill: bg, type: ShadingType.CLEAR }, indent: { left: 200, right: 200 }, children: [new TextRun({ text: icon + " ", size: 22, font: "Arial", bold: true, color: fg }), new TextRun({ text, size: 22, font: "Arial", color: fg })] });
const subtitle = (t) => pa(t, { bold: true, color: C.PRIMARY, after: 100 });

function cell(text, o = {}) {
  return new TableCell({
    borders, width: { size: o.w || 1000, type: WidthType.DXA },
    shading: o.hdr ? { fill: C.PRIMARY, type: ShadingType.CLEAR } : (o.alt ? { fill: C.LIGHT, type: ShadingType.CLEAR } : (o.bg ? { fill: o.bg, type: ShadingType.CLEAR } : undefined)),
    margins: cm, verticalAlign: "center",
    columnSpan: o.span,
    children: [new Paragraph({ alignment: o.ctr ? AlignmentType.CENTER : AlignmentType.LEFT, children: [new TextRun({ text, size: o.sz || 20, font: "Arial", bold: o.hdr || o.bold || false, color: o.hdr ? C.WHITE : (o.color || C.DARK) })] })],
  });
}

function mkTable(headers, rows, widths) {
  const W = widths.reduce((a, b) => a + b, 0);
  return new Table({
    width: { size: W, type: WidthType.DXA },
    columnWidths: widths,
    rows: [
      new TableRow({ children: headers.map((h, i) => cell(h, { hdr: true, w: widths[i], ctr: i > 0 && widths[i] < 1500 })) }),
      ...rows.map((row, ri) => new TableRow({ children: row.map((t, ci) => {
        const isStatus = typeof t === "string" && ["Actif", "P0", "RWA", "Oui"].includes(t);
        const isInactive = typeof t === "string" && ["Inactif", "P1", "P2", "Non", "\u2014"].includes(t);
        return cell(t, {
          w: widths[ci], alt: ri % 2 === 0,
          ctr: ci > 0 && widths[ci] < 1500,
          color: isStatus ? C.GREEN : (isInactive ? C.GRAY : C.DARK),
          bold: ci === 0 || isStatus,
          bg: isStatus ? C.GREEN_BG : (isInactive && t === "\u2014" ? undefined : undefined),
        });
      }) })),
    ],
  });
}

// ============ DOCUMENT ============
const doc = new Document({
  styles: {
    default: { document: { run: { font: "Arial", size: 22, color: C.DARK } } },
    paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true, run: { size: 34, bold: true, font: "Arial", color: C.PRIMARY }, paragraph: { spacing: { before: 400, after: 220 }, outlineLevel: 0 } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true, run: { size: 28, bold: true, font: "Arial", color: C.PRIMARY }, paragraph: { spacing: { before: 300, after: 180 }, outlineLevel: 1 } },
      { id: "Heading3", name: "Heading 3", basedOn: "Normal", next: "Normal", quickFormat: true, run: { size: 24, bold: true, font: "Arial", color: C.ACCENT }, paragraph: { spacing: { before: 220, after: 120 }, outlineLevel: 2 } },
    ],
  },
  numbering: { config: [
    { reference: "b1", levels: [{ level: 0, format: LevelFormat.BULLET, text: "\u2022", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
    { reference: "b2", levels: [{ level: 0, format: LevelFormat.BULLET, text: "\u25e6", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 1080, hanging: 360 } } } }] },
    { reference: "n1", levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
    { reference: "n2", levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
    { reference: "n3", levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
    { reference: "n4", levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
    { reference: "n5", levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
  ] },
  sections: [
    // ======================== COVER ========================
    {
      properties: { page: { size: { width: 12240, height: 15840 }, margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 } } },
      children: [
        sp(1400),
        pa("INSTITUT PASTEUR DE DAKAR", { align: AlignmentType.CENTER, color: C.GRAY, bold: true }),
        new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 60 }, border: { bottom: { style: BorderStyle.SINGLE, size: 8, color: C.ACCENT, space: 10 } }, children: [] }),
        sp(300),
        new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 80 }, children: [new TextRun({ text: "CAHIER DES CHARGES", size: 52, font: "Arial", bold: true, color: C.PRIMARY })] }),
        sp(60),
        new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 120 }, children: [new TextRun({ text: "PORTAIL INT\u00c9GR\u00c9 DE", size: 40, font: "Arial", bold: true, color: C.ACCENT })] }),
        new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 200 }, children: [new TextRun({ text: "CYBER-GOUVERNANCE", size: 40, font: "Arial", bold: true, color: C.ACCENT })] }),
        sp(100),
        new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 60 }, border: { top: { style: BorderStyle.SINGLE, size: 8, color: C.ACCENT, space: 10 } }, children: [] }),
        sp(80),
        pa("Plateforme centralis\u00e9e de pilotage strat\u00e9gique et op\u00e9rationnel", { align: AlignmentType.CENTER, italic: true, color: C.GRAY }),
        sp(600),
        // Info table
        new Table({
          width: { size: 5400, type: WidthType.DXA },
          columnWidths: [2200, 3200],
          rows: [
            ["Version", "1.0"],
            ["Date", "Mars 2026"],
            ["URL", "https://seid-pasteur.org"],
            ["Classification", "Confidentiel \u2014 Usage interne"],
            ["R\u00e9dacteur", "Cellule SEID / IPD"],
          ].map(([k, v]) => new TableRow({ children: [
            cell(k, { w: 2200, bold: true, bg: C.LIGHT }),
            cell(v, { w: 3200 }),
          ] })),
        }),
      ],
    },
    // ======================== CONTENT ========================
    {
      properties: { page: { size: { width: 12240, height: 15840 }, margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 } } },
      headers: { default: new Header({ children: [new Paragraph({ border: { bottom: { style: BorderStyle.SINGLE, size: 2, color: C.ACCENT, space: 4 } }, children: [new TextRun({ text: "Cahier des charges \u2014 Portail Int\u00e9gr\u00e9 de Cyber-Gouvernance \u2014 IPD", size: 16, font: "Arial", color: C.GRAY, italics: true })] })] }) },
      footers: { default: new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER, border: { top: { style: BorderStyle.SINGLE, size: 2, color: C.ACCENT, space: 4 } }, children: [new TextRun({ text: "Institut Pasteur de Dakar \u2014 Confidentiel \u2014 Page ", size: 16, font: "Arial", color: C.GRAY }), new TextRun({ children: [PageNumber.CURRENT], size: 16, font: "Arial", color: C.GRAY })] })] }) },
      children: [

        // ===== TABLE DES MATIÈRES =====
        new Paragraph({ spacing: { after: 300 }, children: [new TextRun({ text: "TABLE DES MATI\u00c8RES", size: 34, font: "Arial", bold: true, color: C.PRIMARY })] }),
        new TableOfContents("Sommaire", { hyperlink: true, headingStyleRange: "1-3" }),
        pb(),

        // ================================================================
        // 1. CONTEXTE ET PRÉSENTATION GÉNÉRALE
        // ================================================================
        h1("1. Contexte et pr\u00e9sentation g\u00e9n\u00e9rale"),

        h2("1.1 Pr\u00e9sentation de l\u2019Institut Pasteur de Dakar"),
        pa("L\u2019Institut Pasteur de Dakar (IPD) est un \u00e9tablissement de sant\u00e9 publique et de recherche biom\u00e9dicale de r\u00e9f\u00e9rence en Afrique de l\u2019Ouest. Fond\u00e9 en 1896, il est l\u2019un des quatre producteurs mondiaux de vaccins contre la fi\u00e8vre jaune pr\u00e9qualifi\u00e9s par l\u2019OMS."),
        pa("L\u2019IPD est organis\u00e9 autour de quatre p\u00f4les fonctionnels majeurs :"),
        bl("Gouvernance et Strat\u00e9gie : Direction G\u00e9n\u00e9rale, Cellule d\u2019Appui Strat\u00e9gique (CAS), Cellule SEID"),
        bl("Fonctions M\u00e9tiers : Production vaccinale, Recherche, Sant\u00e9 Publique, Qualit\u00e9"),
        bl("Fonctions Op\u00e9rationnelles : DSI, RH, Finance, Logistique"),
        bl("Partenariat et Communication : Mobilisation de ressources, Relations m\u00e9dias"),

        sp(80),
        h2("1.2 Contexte du projet"),
        pa("Dans un contexte de transformation num\u00e9rique et de renforcement de la gouvernance institutionnelle, l\u2019IPD a initi\u00e9 le d\u00e9veloppement d\u2019un Portail Int\u00e9gr\u00e9 de Cyber-Gouvernance. Ce portail r\u00e9pond au besoin de disposer d\u2019une plateforme unifi\u00e9e centralisant l\u2019ensemble des tableaux de bord, indicateurs de performance et outils de pilotage des diff\u00e9rentes directions."),
        pa("Les enjeux identifi\u00e9s sont les suivants :"),
        bl("Fragmentation des syst\u00e8mes d\u2019information existants"),
        bl("Manque de visibilit\u00e9 transversale sur les activit\u00e9s de l\u2019institut"),
        bl("N\u00e9cessit\u00e9 de renforcer la conformit\u00e9 r\u00e9glementaire (OMS, ARP)"),
        bl("Besoin de s\u00e9curiser les acc\u00e8s aux donn\u00e9es strat\u00e9giques"),
        bl("Exigence de tra\u00e7abilit\u00e9 des d\u00e9cisions et des actions"),

        sp(80),
        h2("1.3 Objectifs du portail"),
        pa("Le Portail Int\u00e9gr\u00e9 de Cyber-Gouvernance a pour objectifs :"),
        sp(40),
        mkTable(
          ["N\u00b0", "Objectif", "Description"],
          [
            ["OBJ-1", "Centralisation", "Unifier le pilotage strat\u00e9gique et op\u00e9rationnel de l\u2019ensemble des directions de l\u2019IPD dans une interface unique"],
            ["OBJ-2", "Temps r\u00e9el", "Fournir des tableaux de bord dynamiques avec des indicateurs KPI actualis\u00e9s en temps r\u00e9el"],
            ["OBJ-3", "Conformit\u00e9", "Renforcer la tra\u00e7abilit\u00e9 et la conformit\u00e9 r\u00e9glementaire vis-\u00e0-vis des normes OMS et ARP"],
            ["OBJ-4", "Coordination", "Faciliter la coordination inter-services et la circulation de l\u2019information"],
            ["OBJ-5", "S\u00e9curit\u00e9", "S\u00e9curiser l\u2019acc\u00e8s aux donn\u00e9es sensibles par un syst\u00e8me RBAC granulaire"],
            ["OBJ-6", "Modularit\u00e9", "Permettre l\u2019ajout dynamique de nouveaux modules sans red\u00e9ploiement complet"],
          ],
          [700, 1600, 7060],
        ),

        sp(80),
        h2("1.4 P\u00e9rim\u00e8tre fonctionnel"),
        pa("Le portail couvre les domaines fonctionnels suivants, organis\u00e9s en 12 modules r\u00e9partis sur 4 p\u00f4les :"),
        sp(40),
        mkTable(
          ["P\u00f4le", "Couleur", "Modules", "Priorit\u00e9"],
          [
            ["Gouvernance", "Cyan #06B6D4", "Cockpit Strat\u00e9gique, SEID Intelligence", "P0"],
            ["Fonctions M\u00e9tiers", "Vert/Violet", "IMS NextGen, Modules Suivi, Surveillance \u00c9pid\u00e9miologique, Production Vaccins, Grant Office", "P0 / P1"],
            ["Op\u00e9rations", "Ambre #F59E0B", "Administration Portail, Ressources Humaines, Finance & Logistique", "P0 / P1"],
            ["Partenariat", "Violet #8B5CF6", "Mobilisation Ressources, Relations M\u00e9dias", "P2"],
          ],
          [1600, 1400, 4760, 1600],
        ),

        pb(),

        // ================================================================
        // 2. ARCHITECTURE TECHNIQUE
        // ================================================================
        h1("2. Architecture technique"),

        h2("2.1 Stack technologique"),
        pa("Le portail repose sur une architecture moderne et performante :"),
        sp(40),
        mkTable(
          ["Composant", "Technologie", "Version", "R\u00f4le"],
          [
            ["Framework", "Next.js", "16.1.6", "Framework React avec rendu serveur (SSR + API Routes)"],
            ["Librairie UI", "React", "19.2.3", "Biblioth\u00e8que de composants r\u00e9actifs"],
            ["Langage", "TypeScript", "5.x", "Typage statique pour la fiabilit\u00e9 du code"],
            ["Base de donn\u00e9es", "PostgreSQL", "16", "SGBD relationnel principal (donn\u00e9es persistantes)"],
            ["ORM", "Prisma", "6", "Acc\u00e8s donn\u00e9es typ\u00e9, migrations automatiques"],
            ["Authentification", "jsonwebtoken", "9.x", "G\u00e9n\u00e9ration et v\u00e9rification de tokens JWT"],
            ["API", "API Routes Next.js", "\u2014", "Endpoints REST c\u00f4t\u00e9 serveur (17 routes)"],
            ["CSS", "Tailwind CSS", "4.x", "Syst\u00e8me de classes utilitaires pour le design"],
            ["\u00c9tat global", "Zustand", "5.0.11", "Gestion d\u2019\u00e9tat l\u00e9g\u00e8re et performante"],
            ["Animations", "Framer Motion", "12.36", "Animations fluides et transitions"],
            ["Graphiques", "Recharts", "3.8.0", "Visualisation de donn\u00e9es (barres, lignes, radars)"],
            ["Cartographie", "React Leaflet", "5.0.0", "Cartes interactives (surveillance \u00e9pid\u00e9miologique)"],
            ["Ic\u00f4nes", "Lucide React", "0.577", "Biblioth\u00e8que d\u2019ic\u00f4nes SVG"],
            ["Composants UI", "Shadcn / Base UI", "1.3.0", "Composants accessibles et personnalisables"],
          ],
          [1600, 1800, 1000, 4960],
        ),

        sp(100),
        h2("2.2 Architecture applicative"),
        pa("Le portail utilise Next.js en mode serveur (API Routes + SSR) avec une architecture 3 tiers :"),
        sp(40),
        mkTable(
          ["Couche", "Emplacement", "Fonction"],
          [
            ["Pr\u00e9sentation", "src/app/, src/components/", "Pages, composants UI, layouts r\u00e9actifs"],
            ["API (Backend)", "src/app/api/", "17 API Routes Next.js (REST, authentification JWT)"],
            ["\u00c9tat", "src/stores/", "6 stores Zustand avec appels API (sauf theme-store)"],
            ["ORM", "prisma/, src/lib/db.ts", "Prisma ORM pour l\u2019acc\u00e8s aux donn\u00e9es PostgreSQL"],
            ["Auth", "src/lib/auth/", "JWT (g\u00e9n\u00e9ration, v\u00e9rification), middleware d\u2019authentification"],
            ["M\u00e9tier", "src/lib/rbac.ts", "Contr\u00f4le d\u2019acc\u00e8s RBAC, fonctions de permission"],
            ["Types", "src/types/", "D\u00e9finitions TypeScript des mod\u00e8les"],
            ["Statique", "public/", "Fichiers HTML embarqu\u00e9s, images"],
          ],
          [1600, 2800, 4960],
        ),
        sp(60),
        pa("Flux de donn\u00e9es : Frontend React \u2192 API Routes Next.js \u2192 Prisma ORM \u2192 PostgreSQL"),

        sp(100),
        h2("2.3 Mode de d\u00e9ploiement"),
        pa("Le portail est d\u00e9ploy\u00e9 en mode serveur Node.js sur un VPS d\u00e9di\u00e9. Cette approche permet l\u2019utilisation des API Routes et de la base de donn\u00e9es PostgreSQL :"),
        bl("Serveur Node.js 20 avec PM2 pour la gestion de processus"),
        bl("PostgreSQL 16 install\u00e9 sur le m\u00eame serveur"),
        bl("Nginx en reverse proxy avec terminaison SSL (Let\u2019s Encrypt)"),
        bl("D\u00e9ploiement via SSH/rsync (remplace FTP)"),
        sp(40),
        subtitle("Param\u00e8tres de build :"),
        bl("next build \u2014 Build serveur standard (SSR + API Routes)"),
        bl("next start \u2014 D\u00e9marrage du serveur de production (port 3000)"),
        bl("PM2 pour le redemarrage automatique et la supervision"),
        sp(40),
        subtitle("Infrastructure actuelle :"),
        bv("Type", "VPS (Ubuntu 22.04 LTS)"),
        bv("Runtime", "Node.js 20 + PM2"),
        bv("Base de donn\u00e9es", "PostgreSQL 16"),
        bv("Reverse proxy", "Nginx avec SSL Let\u2019s Encrypt"),
        bv("D\u00e9ploiement", "SSH / rsync"),
        bv("Domaine", "seid-pasteur.org"),

        pb(),

        // ================================================================
        // 3. DESIGN SYSTEM ET INTERFACE
        // ================================================================
        h1("3. Design system et interface utilisateur"),

        h2("3.1 Identit\u00e9 visuelle"),
        pa("Le portail adopte un design moderne de type \u00ab Dark Glassmorphism \u00bb, inspir\u00e9 des interfaces de Command Center. Les choix visuels refl\u00e8tent le professionnalisme et la rigueur scientifique de l\u2019IPD."),
        sp(40),
        subtitle("Palette de couleurs :"),
        sp(40),
        mkTable(
          ["Couleur", "Code hexad\u00e9cimal", "Usage"],
          [
            ["Cyan", "#06B6D4", "P\u00f4le Gouvernance, accents primaires, liens"],
            ["\u00c9meraude", "#10B981", "P\u00f4le M\u00e9tiers, indicateurs positifs"],
            ["Ambre", "#F59E0B", "P\u00f4le Op\u00e9rations, alertes mod\u00e9r\u00e9es"],
            ["Violet", "#8B5CF6", "P\u00f4le Partenariat, IMS NextGen"],
            ["Rouge", "#EF4444", "Alertes critiques, erreurs"],
            ["Bleu IPD", "#0089D0", "Module Suivi, accent secondaire"],
            ["Fond principal", "#0a0e1a \u2192 #0f1629", "D\u00e9grad\u00e9 sombre de fond"],
            ["Verre (glass)", "rgba(255,255,255,0.03)", "Panneaux en glassmorphism"],
          ],
          [1600, 2000, 5760],
        ),

        sp(100),
        subtitle("Effets visuels :"),
        bl("Glassmorphism : panneaux semi-transparents avec backdrop-filter: blur(20px)"),
        bl("Glow effects : bordures lumineuses anim\u00e9es (cyan, \u00e9meraude, ambre, violet)"),
        bl("Animations Framer Motion : transitions fluides, apparitions progressives"),
        bl("Texte n\u00e9on : effet lumineux sur les titres cl\u00e9s"),
        bl("Particules : \u00e9toiles scintillantes sur la page de connexion"),

        sp(100),
        h2("3.2 Composants UI"),
        pa("Le portail utilise une biblioth\u00e8que de 28 composants r\u00e9utilisables :"),
        sp(40),
        mkTable(
          ["Cat\u00e9gorie", "Composants", "Description"],
          [
            ["Layout", "PortalSidebar, PortalHeader, NotificationCenter", "Navigation lat\u00e9rale responsive, barre sup\u00e9rieure, panneau de notifications"],
            ["Shared", "GlassPanel, KpiCard, AnimatedNumber, StatusBadge", "Panneaux vitr\u00e9s, cartes KPI anim\u00e9es, badges d\u2019\u00e9tat"],
            ["Dashboard", "ModuleTile", "Tuile de module avec ic\u00f4ne, KPI, tendance et contr\u00f4le d\u2019acc\u00e8s"],
            ["Admin", "UserManager, ModuleManager, RoleManager", "Gestion CRUD des utilisateurs, modules et r\u00f4les"],
            ["Surveillance", "SenegalMap, SenegalMapLeaflet", "Carte interactive du S\u00e9n\u00e9gal avec alertes r\u00e9gionales"],
            ["Login", "IpdOrbital3D", "Visualisation 3D orbitale des entit\u00e9s IPD"],
            ["UI (Shadcn)", "Button, Card, Dialog, Input, Table, Tabs, Tooltip, etc.", "13 composants de base accessibles et th\u00e9m\u00e9s"],
          ],
          [1600, 3200, 4560],
        ),

        sp(100),
        h2("3.3 Responsive design"),
        pa("Le portail s\u2019adapte \u00e0 trois breakpoints :"),
        sp(40),
        mkTable(
          ["Device", "Breakpoint", "Adaptations"],
          [
            ["Desktop", "\u2265 1024px", "Layout complet : sidebar + contenu, visualisation 3D pleine taille, 3 colonnes de tuiles"],
            ["Tablette", "768 \u2013 1023px", "Sidebar r\u00e9tractable, 2 colonnes de tuiles, 3D r\u00e9duite"],
            ["Mobile", "< 768px", "Navigation hamburger, 1 colonne, 3D compacte au-dessus du formulaire"],
          ],
          [1400, 1400, 6560],
        ),

        pb(),

        // ================================================================
        // 4. PAGE DE CONNEXION
        // ================================================================
        h1("4. Page de connexion"),

        h2("4.1 Layout et structure"),
        pa("La page de connexion est le point d\u2019entr\u00e9e du portail. Elle pr\u00e9sente un design immersif en deux panneaux :"),
        sp(40),
        subtitle("Panneau gauche (60% \u2014 Desktop) :"),
        bl("Visualisation 3D orbitale interactive des entit\u00e9s de l\u2019IPD"),
        bl("Description du portail et de ses objectifs (5 items avec ic\u00f4nes)"),
        bl("L\u00e9gende des p\u00f4les avec codes couleur"),
        sp(40),
        subtitle("Panneau droit (40% \u2014 Desktop) :"),
        bl("Logo et titre de l\u2019institut"),
        bl("Formulaire de connexion (email + mot de passe)"),
        bl("Bouton d\u2019affichage/masquage du mot de passe (ic\u00f4ne \u0153il)"),
        bl("Gestion des erreurs avec messages en rouge"),
        bl("Indicateur de chargement (spinner)"),

        sp(80),
        h2("4.2 Visualisation 3D orbitale"),
        pa("Le composant IpdOrbital3D est une visualisation Canvas 2D avec projection 3D perspective affichant l\u2019organigramme de l\u2019IPD sous forme d\u2019orbites concentriques :"),
        sp(40),
        mkTable(
          ["Orbite", "Couleur", "Entit\u00e9s repr\u00e9sent\u00e9es"],
          [
            ["1 \u2014 Direction", "Ambre (#F59E0B)", "Direction G\u00e9n\u00e9rale, Cabinet DG"],
            ["2 \u2014 Fonctions M\u00e9tiers", "Cyan (#06B6D4)", "Production, Recherche, Sant\u00e9 Publique, Qualit\u00e9, M\u00e9dical"],
            ["3 \u2014 Fonctions Op\u00e9rationnelles", "Violet (#8B5CF6)", "DSI, RH, Finance, Communication, Partenariat"],
          ],
          [2200, 2000, 5160],
        ),
        sp(60),
        subtitle("Caract\u00e9ristiques techniques :"),
        bl("Rendu Canvas HTML5 avec projection perspective 3D"),
        bl("Rotation continue anim\u00e9e des orbites"),
        bl("Tri par profondeur (depth sorting) des n\u0153uds"),
        bl("Effet de parallaxe au mouvement de la souris"),
        bl("Particules \u00e9toil\u00e9es scintillantes en arri\u00e8re-plan"),
        bl("N\u0153ud central IPD avec halo pulsant"),
        bl("D\u00e9tection de survol avec mise en \u00e9vidence"),
        bl("Rendu adapt\u00e9 au DPI (devicePixelRatio) avec ResizeObserver"),

        sp(80),
        h2("4.3 Processus d\u2019authentification"),
        pa("L\u2019authentification suit le flux suivant :"),
        sp(40),
        nl("L\u2019utilisateur saisit son adresse email et son mot de passe", "n2"),
        nl("Le syst\u00e8me effectue une comparaison insensible \u00e0 la casse de l\u2019email", "n2"),
        nl("V\u00e9rification du mot de passe (correspondance exacte)", "n2"),
        nl("V\u00e9rification que le compte est actif (isActive: true)", "n2"),
        nl("G\u00e9n\u00e9ration d\u2019un token de session stock\u00e9 en localStorage et cookie", "n2"),
        nl("Expiration de session : 24 heures", "n2"),
        nl("Redirection vers le tableau de bord (/dashboard)", "n2"),
        sp(60),
        alert("\u26a0", "La comparaison des emails est insensible \u00e0 la casse (case-insensitive) pour \u00e9viter les erreurs de saisie des utilisateurs.", C.AMBER_BG, C.AMBER),

        pb(),

        // ================================================================
        // 5. TABLEAU DE BORD
        // ================================================================
        h1("5. Tableau de bord principal"),

        h2("5.1 Vue d\u2019ensemble"),
        pa("Apr\u00e8s connexion, l\u2019utilisateur acc\u00e8de au tableau de bord principal qui affiche une vue personnalis\u00e9e selon son r\u00f4le et ses permissions."),
        sp(40),
        subtitle("Composants du tableau de bord :"),
        bl("Message d\u2019accueil personnalis\u00e9 (Bonjour/Bon apr\u00e8s-midi/Bonsoir + pr\u00e9nom)"),
        bl("Informations utilisateur : d\u00e9partement, nombre de modules accessibles"),
        bl("Grille de modules actifs : tuiles cliquables avec KPI"),
        bl("Section modules \u00e0 venir : tuiles gris\u00e9es avec ic\u00f4ne cadenas"),

        sp(80),
        h2("5.2 Tuile de module"),
        pa("Chaque tuile de module affiche les informations suivantes :"),
        sp(40),
        mkTable(
          ["\u00c9l\u00e9ment", "Description", "Exemple"],
          [
            ["Ic\u00f4ne", "Ic\u00f4ne Lucide repr\u00e9sentant le module", "Gauge, Shield, BarChart3"],
            ["Nom", "Titre du module", "IMS NextGen"],
            ["Description", "Description courte de la fonction", "Syst\u00e8me de Management Int\u00e9gr\u00e9"],
            ["KPI Label", "Libell\u00e9 de l\u2019indicateur principal", "Conformit\u00e9 IMS"],
            ["KPI Value", "Valeur actuelle de l\u2019indicateur", "94,2%"],
            ["Tendance", "Fl\u00e8che indiquant l\u2019\u00e9volution", "\u2191 (hausse), \u2193 (baisse), \u2014 (stable)"],
            ["Couleur", "Code couleur du p\u00f4le d\u2019appartenance", "#8b5cf6 (violet)"],
            ["Badge priorit\u00e9", "Niveau de priorit\u00e9 du module", "P0, P1, P2"],
          ],
          [1600, 4560, 3200],
        ),

        pb(),

        // ================================================================
        // 6. MODULES DÉTAILLÉS
        // ================================================================
        h1("6. Sp\u00e9cifications d\u00e9taill\u00e9es des modules"),

        // --- 6.1 IMS ---
        h2("6.1 IMS NextGen"),
        sp(40),
        mkTable(
          ["Propri\u00e9t\u00e9", "Valeur"],
          [
            ["Identifiant", "ims"],
            ["P\u00f4le", "Fonctions M\u00e9tiers"],
            ["Priorit\u00e9", "P0 \u2014 Op\u00e9rationnel"],
            ["Route", "/metiers/ims"],
            ["Couleur", "#8B5CF6 (Violet)"],
            ["KPI", "Conformit\u00e9 IMS : 94,2% (\u2191)"],
            ["Type", "React + iframe HTML"],
          ],
          [2400, 6960],
        ),
        sp(60),
        pa("Le module IMS NextGen est le Syst\u00e8me de Management Int\u00e9gr\u00e9 de l\u2019IPD. Il embarque un tableau de bord complet de suivi qualit\u00e9, production et conformit\u00e9."),
        sp(40),
        subtitle("Fonctionnalit\u00e9s :"),
        bl("Tableau de bord interactif avec navigation lat\u00e9rale (sidebar)"),
        bl("KPIs de production : doses produites, rendement, efficacit\u00e9"),
        bl("Indicateurs qualit\u00e9 : conformit\u00e9 lots, tests LCQ, CAPA"),
        bl("Suivi des risques avec matrice de criticit\u00e9"),
        bl("Graphiques Chart.js dynamiques (barres, lignes, jauges)"),
        bl("Mode plein \u00e9cran avec bouton d\u00e9di\u00e9"),
        sp(40),
        subtitle("Int\u00e9gration technique :"),
        bl("Fichier source : public/modules/ims-nextgen.html"),
        bl("Rendu via iframe avec sandbox=\"allow-scripts allow-same-origin\""),
        bl("D\u00e9pendances CDN : Tailwind CSS, Chart.js 4"),

        sp(100),
        // --- 6.2 Suivi ---
        h2("6.2 Modules Suivi"),
        sp(40),
        mkTable(
          ["Propri\u00e9t\u00e9", "Valeur"],
          [
            ["Identifiant", "suivi"],
            ["P\u00f4le", "Fonctions M\u00e9tiers"],
            ["Priorit\u00e9", "P0 \u2014 Op\u00e9rationnel"],
            ["Route", "/metiers/suivi"],
            ["Couleur", "#0089D0 (Bleu IPD)"],
            ["KPI", "Avancement global : 87,8% (\u2191)"],
            ["Type", "React + iframe HTML"],
          ],
          [2400, 6960],
        ),
        sp(60),
        pa("Le module Suivi assure la coordination et le suivi int\u00e9gr\u00e9 des activit\u00e9s de production, qualit\u00e9 et conformit\u00e9 IMS/UVFJ."),
        sp(40),
        subtitle("Onglet Coordination :"),
        bl("Tableau de bord IMS UVFJ complet et interactif"),
        bl("Sections : Production, LCQ (Laboratoire Contr\u00f4le Qualit\u00e9), CAPA OMS"),
        bl("Sections : Workshop ZAC, Supply Chain, Finance"),
        bl("Jauges de progression, graphiques, tableaux de donn\u00e9es"),
        bl("Interface avec sidebar de navigation int\u00e9gr\u00e9e"),
        sp(40),
        subtitle("Int\u00e9gration technique :"),
        bl("Fichier source : public/modules/suivi-coordination.html (814 lignes)"),
        bl("Interface \u00e0 onglets extensible (pr\u00e9vu pour ajout de nouveaux onglets)"),

        sp(100),
        // --- 6.3 Cockpit ---
        h2("6.3 Cockpit Strat\u00e9gique"),
        sp(40),
        mkTable(
          ["Propri\u00e9t\u00e9", "Valeur"],
          [
            ["Identifiant", "cockpit"],
            ["P\u00f4le", "Gouvernance"],
            ["Priorit\u00e9", "P0 \u2014 Op\u00e9rationnel"],
            ["Route", "/gouvernance/cockpit"],
            ["Couleur", "#06B6D4 (Cyan)"],
            ["KPI", "Taux d\u2019ex\u00e9cution : 78% (\u2191)"],
            ["Type", "React natif"],
          ],
          [2400, 6960],
        ),
        sp(60),
        subtitle("Composants du Cockpit :"),
        bl("Grille de 6 KPI anim\u00e9s : Budget, Conformit\u00e9, Projets, Effectif, Publications, Alertes"),
        bl("Graphique en barres : Budget par p\u00f4le (allocation vs consommation)"),
        bl("Graphique de tendance : \u00e9volution mensuelle (Octobre \u2192 Mars)"),
        bl("Matrice de performance par p\u00f4le : KPI, projets, satisfaction, conformit\u00e9"),
        bl("8 indicateurs strat\u00e9giques avec cibles et valeurs actuelles"),
        bl("Visualisations Recharts (BarChart, LineChart, RadarChart)"),

        sp(100),
        // --- 6.4 SEID ---
        h2("6.4 SEID \u2014 Intelligence de Donn\u00e9es"),
        sp(40),
        mkTable(
          ["Propri\u00e9t\u00e9", "Valeur"],
          [
            ["Identifiant", "seid"],
            ["P\u00f4le", "Gouvernance"],
            ["Priorit\u00e9", "P0 \u2014 Op\u00e9rationnel"],
            ["Route", "/gouvernance/seid"],
            ["Couleur", "#06B6D4 (Cyan)"],
            ["KPI", "Sources actives : 24/28 (stable)"],
            ["Type", "React natif"],
          ],
          [2400, 6960],
        ),
        sp(60),
        subtitle("Fonctionnalit\u00e9s :"),
        bl("Statistiques rapides : 14 applications surveill\u00e9es (online, d\u00e9grad\u00e9, offline)"),
        bl("Taux de disponibilit\u00e9 moyen (uptime) par application"),
        bl("M\u00e9triques de qualit\u00e9 des donn\u00e9es : compl\u00e9tude, fra\u00eecheur, coh\u00e9rence"),
        bl("Tableau d\u2019\u00e9valuation avec statuts et progression"),
        bl("Matrice KPI par d\u00e9partement"),

        sp(100),
        // --- 6.5 Surveillance ---
        h2("6.5 Surveillance \u00c9pid\u00e9miologique"),
        sp(40),
        mkTable(
          ["Propri\u00e9t\u00e9", "Valeur"],
          [
            ["Identifiant", "surveillance"],
            ["P\u00f4le", "Fonctions M\u00e9tiers"],
            ["Priorit\u00e9", "P0 \u2014 Op\u00e9rationnel"],
            ["Route", "/metiers/surveillance"],
            ["Couleur", "#10B981 (\u00c9meraude)"],
            ["KPI", "Alertes actives : 3 (\u2191)"],
            ["Type", "React natif + Leaflet"],
          ],
          [2400, 6960],
        ),
        sp(60),
        subtitle("Fonctionnalit\u00e9s :"),
        bl("Cartes KPI : cas surveill\u00e9s, maladies suivies, alertes, taux de r\u00e9ponse"),
        bl("Fil d\u2019alertes en temps r\u00e9el (Dengue, Paludisme, M\u00e9ningite, COVID-19)"),
        bl("Carte interactive du S\u00e9n\u00e9gal (React Leaflet) avec marqueurs r\u00e9gionaux"),
        bl("Niveaux d\u2019alerte : vigilance, pr\u00e9-alerte, alerte, urgence"),
        bl("Graphique de tendance \u00e9pid\u00e9miologique par maladie"),
        bl("R\u00e9partition r\u00e9gionale des cas"),

        sp(100),
        // --- 6.6 Admin ---
        h2("6.6 Administration du Portail"),
        sp(40),
        mkTable(
          ["Propri\u00e9t\u00e9", "Valeur"],
          [
            ["Identifiant", "admin"],
            ["P\u00f4le", "Op\u00e9rations"],
            ["Priorit\u00e9", "P0 \u2014 Op\u00e9rationnel"],
            ["Route", "/operations/admin"],
            ["Couleur", "#F59E0B (Ambre)"],
            ["KPI", "Utilisateurs actifs : 142 (\u2191)"],
            ["Acc\u00e8s", "R\u00e9serv\u00e9 aux administrateurs (admin_general, dsi)"],
          ],
          [2400, 6960],
        ),
        sp(60),
        subtitle("5 onglets de gestion :"),
        sp(40),
        mkTable(
          ["Onglet", "Fonction", "Composant"],
          [
            ["Utilisateurs", "CRUD complet des comptes (cr\u00e9ation, modification, activation, r\u00e9initialisation mot de passe)", "UserManager"],
            ["Modules", "Gestion des modules (activation, configuration, publication HTML)", "ModuleManager"],
            ["R\u00f4les", "Matrice de permissions \u00e9ditable par r\u00f4le et module", "RoleManager"],
            ["Audit", "Journal des actions (connexions, modifications, exports)", "AuditTab"],
            ["Sant\u00e9 syst\u00e8me", "\u00c9tat des services (API, BDD, auth, backup)", "SystemTab"],
          ],
          [1600, 4960, 2800],
        ),

        pb(),

        // ================================================================
        // 7. MODULES EN DÉVELOPPEMENT
        // ================================================================
        h1("7. Modules en d\u00e9veloppement (P1 / P2)"),
        pa("Les modules suivants sont planifi\u00e9s pour les phases ult\u00e9rieures du projet :"),
        sp(40),
        mkTable(
          ["Module", "Identifiant", "P\u00f4le", "Priorit\u00e9", "Description"],
          [
            ["Production Vaccins", "production", "M\u00e9tiers", "P1", "Suivi de la cha\u00eene de production, gestion des lots, conformit\u00e9 OMS/ARP"],
            ["Grant Office", "grant_office", "M\u00e9tiers", "P1", "Gestion des subventions, projets de recherche, portefeuille scientifique"],
            ["Ressources Humaines", "rh", "Op\u00e9rations", "P1", "Gestion des talents, recrutement, formations, \u00e9valuations"],
            ["Finance & Logistique", "finance", "Op\u00e9rations", "P1", "Comptabilit\u00e9, tr\u00e9sorerie, budget, approvisionnement"],
            ["Mobilisation Ressources", "partenariat", "Partenariat", "P2", "Cartographie partenaires, engagements, pipeline"],
            ["Relations M\u00e9dias", "communication", "Partenariat", "P2", "\u00c9v\u00e9nements, relations presse, veille m\u00e9diatique"],
          ],
          [1800, 1200, 1200, 700, 4460],
        ),

        pb(),

        // ================================================================
        // 8. GESTION DES IDENTITÉS
        // ================================================================
        h1("8. Gestion des identit\u00e9s et acc\u00e8s (IAM)"),

        h2("8.1 Mod\u00e8le de donn\u00e9es utilisateur"),
        pa("Chaque utilisateur est d\u00e9fini par le mod\u00e8le TypeScript suivant :"),
        sp(40),
        mkTable(
          ["Champ", "Type", "Description"],
          [
            ["id", "string", "Identifiant unique (ex: USR-007)"],
            ["email", "string", "Adresse email institutionnelle (@pasteur.sn)"],
            ["password", "string", "Mot de passe (hach\u00e9 en production)"],
            ["firstName", "string", "Pr\u00e9nom"],
            ["lastName", "string", "Nom de famille"],
            ["role", "RoleName", "R\u00f4le attribu\u00e9 (11 r\u00f4les possibles)"],
            ["pole", "Pole | \"tous\"", "P\u00f4le de rattachement"],
            ["department", "string", "D\u00e9partement"],
            ["title", "string", "Fonction/titre"],
            ["isActive", "boolean", "Compte actif ou d\u00e9sactiv\u00e9"],
            ["mfaEnabled", "boolean", "Authentification multi-facteurs"],
            ["lastLogin", "string (ISO)", "Date de derni\u00e8re connexion"],
          ],
          [1600, 1800, 5960],
        ),

        sp(100),
        h2("8.2 Syst\u00e8me RBAC (Role-Based Access Control)"),
        pa("Le portail impl\u00e9mente un contr\u00f4le d\u2019acc\u00e8s bas\u00e9 sur les r\u00f4les avec 11 r\u00f4les pr\u00e9d\u00e9finis et 3 niveaux de permission :"),
        sp(40),
        mkTable(
          ["Permission", "Code", "Description"],
          [
            ["Lecture", "read", "Consultation des donn\u00e9es et tableaux de bord"],
            ["\u00c9criture", "write", "Modification, saisie et mise \u00e0 jour des donn\u00e9es"],
            ["Administration", "admin", "Configuration du module, gestion des param\u00e8tres"],
          ],
          [1800, 1200, 6360],
        ),

        sp(80),
        subtitle("Fonctions RBAC impl\u00e9ment\u00e9es :"),
        sp(40),
        mkTable(
          ["Fonction", "Signature", "Description"],
          [
            ["hasModuleAccess", "hasModuleAccess(role, moduleId): boolean", "V\u00e9rifie si un r\u00f4le a acc\u00e8s \u00e0 un module"],
            ["getModulePermissions", "getModulePermissions(role, moduleId): Permission[]", "Retourne les permissions d\u2019un r\u00f4le pour un module"],
            ["canWrite", "canWrite(role, moduleId): boolean", "V\u00e9rifie le droit d\u2019\u00e9criture"],
            ["getAccessibleModules", "getAccessibleModules(role): ModuleId[]", "Liste les modules accessibles pour un r\u00f4le"],
            ["getAccessiblePoles", "getAccessiblePoles(role): Pole[]", "Liste les p\u00f4les accessibles"],
          ],
          [2200, 4160, 3000],
        ),

        sp(100),
        h2("8.3 Matrice compl\u00e8te des permissions"),
        pa("R = Lecture | RW = Lecture/\u00c9criture | RWA = Administration | \u2014 = Aucun acc\u00e8s"),
        sp(40),
        (() => {
          const mods = ["IMS", "Suivi", "Cockpit", "SEID", "Surv.", "Admin", "Prod.", "Grant", "RH", "Finance", "Part.", "Com."];
          const data = [
            ["Admin G\u00e9n.", "RWA","RWA","RWA","RWA","RWA","RWA","RW","RW","RW","RW","RW","RW"],
            ["CAS","\u2014","\u2014","R","R","\u2014","\u2014","\u2014","\u2014","\u2014","\u2014","\u2014","\u2014"],
            ["SEID","\u2014","\u2014","R","RW","R","\u2014","\u2014","\u2014","\u2014","\u2014","\u2014","\u2014"],
            ["DSI","\u2014","\u2014","\u2014","\u2014","\u2014","RWA","\u2014","\u2014","\u2014","\u2014","\u2014","\u2014"],
            ["Dir. Prod.","\u2014","\u2014","R","\u2014","\u2014","\u2014","RW","\u2014","\u2014","\u2014","\u2014","\u2014"],
            ["Dir. Rech.","\u2014","\u2014","R","\u2014","\u2014","\u2014","\u2014","RW","\u2014","\u2014","\u2014","\u2014"],
            ["Dir. SP","\u2014","\u2014","R","\u2014","RW","\u2014","\u2014","\u2014","\u2014","\u2014","\u2014","\u2014"],
            ["Dir. Part.","\u2014","\u2014","R","\u2014","\u2014","\u2014","\u2014","\u2014","\u2014","\u2014","RW","RW"],
            ["DRH","\u2014","\u2014","\u2014","\u2014","\u2014","\u2014","\u2014","\u2014","RW","\u2014","\u2014","\u2014"],
            ["DAF","\u2014","\u2014","\u2014","\u2014","\u2014","\u2014","\u2014","\u2014","\u2014","RW","\u2014","\u2014"],
            ["Utilisateur","\u2014","\u2014","\u2014","\u2014","\u2014","\u2014","\u2014","\u2014","\u2014","\u2014","\u2014","\u2014"],
          ];
          const ws = [1100, ...mods.map(() => 640)];
          return new Table({
            width: { size: 9360, type: WidthType.DXA },
            columnWidths: ws,
            rows: [
              new TableRow({ children: ["R\u00f4le", ...mods].map((t, i) => cell(t, { hdr: true, w: ws[i], ctr: i > 0, sz: 16 })) }),
              ...data.map((row, ri) => new TableRow({ children: row.map((t, ci) => {
                let bg, color;
                if (t === "RWA") { bg = C.GREEN_BG; color = C.GREEN; }
                else if (t === "RW") { bg = C.BLUE_BG; color = C.BLUE; }
                else if (t === "R") { bg = C.AMBER_BG; color = C.AMBER; }
                else { color = "CBD5E1"; }
                return cell(t, { w: ws[ci], ctr: ci > 0, bg, color, bold: ci === 0 || t === "RWA", sz: 16 });
              }) })),
            ],
          });
        })(),

        pb(),

        // ================================================================
        // 9. GESTION D'ÉTAT
        // ================================================================
        h1("9. Gestion d\u2019\u00e9tat et persistance"),

        h2("9.1 Architecture des stores"),
        pa("Le portail utilise 6 stores Zustand. Depuis la migration PostgreSQL, les stores communiquent avec le backend via les API Routes (sauf le theme-store qui reste en localStorage) :"),
        sp(40),
        mkTable(
          ["Store", "Fichier", "Fonction", "Persistance"],
          [
            ["Auth Store", "auth-store.ts", "Session utilisateur, token, authentification", "Appels API /api/auth/*"],
            ["Module Store", "module-store.ts", "Liste des modules, configuration, activation", "Appels API /api/modules/*"],
            ["User Store", "user-store.ts", "Gestion des utilisateurs (admin)", "Appels API /api/users/*"],
            ["Role Store", "role-store.ts", "R\u00f4les et matrice de permissions", "Appels API /api/roles/*"],
            ["Notification Store", "notification-store.ts", "Notifications et alertes", "Appels API /api/notifications/*"],
            ["Theme Store", "theme-store.ts", "Th\u00e8me (dark/light), plein \u00e9cran", "localStorage (pr\u00e9f\u00e9rence UI)"],
          ],
          [1800, 1800, 3360, 2400],
        ),

        sp(100),
        h2("9.2 Client API centralis\u00e9"),
        pa("Les stores communiquent avec le backend via un client API centralis\u00e9 (src/lib/api-client.ts) qui g\u00e8re :"),
        sp(40),
        bl("Envoi automatique du token JWT via les cookies HTTP-only"),
        bl("Gestion des erreurs HTTP (401 \u2192 redirection login, 403 \u2192 acc\u00e8s refus\u00e9)"),
        bl("S\u00e9rialisation/d\u00e9s\u00e9rialisation JSON des requ\u00eates et r\u00e9ponses"),
        bl("Fonctions g\u00e9n\u00e9riques : apiGet, apiPost, apiPut, apiDelete"),
        sp(60),
        pa("Les modules HTML personnalis\u00e9s sont d\u00e9sormais stock\u00e9s en base de donn\u00e9es (champ html_content de la table modules) et servis directement via les API Routes."),

        pb(),

        // ================================================================
        // 10. BASE DE DONNÉES ET STOCKAGE
        // ================================================================
        h1("10. Base de donn\u00e9es et stockage"),

        h2("10.1 Base de donn\u00e9es PostgreSQL"),
        pa("Le portail utilise PostgreSQL 16 comme SGBD principal, avec Prisma 6 comme ORM. L\u2019ensemble des donn\u00e9es (utilisateurs, modules, r\u00f4les, permissions, sessions, audit) est persist\u00e9 en base de donn\u00e9es relationnelle."),
        sp(40),
        mkTable(
          ["Composant", "Technologie", "D\u00e9tail"],
          [
            ["SGBD", "PostgreSQL 16", "Base relationnelle ACID, support JSON natif, extensions"],
            ["ORM", "Prisma 6", "Sch\u00e9ma d\u00e9claratif, migrations automatiques, client typ\u00e9 TypeScript"],
            ["Sch\u00e9ma", "prisma/schema.prisma", "10 tables avec relations, index, contraintes d\u2019unicit\u00e9"],
            ["Migrations", "prisma/migrations/", "Versionn\u00e9es et appliqu\u00e9es via prisma migrate deploy"],
            ["Seed", "prisma/seed.ts", "Migration des donn\u00e9es initiales (utilisateurs, modules, r\u00f4les)"],
            ["Client", "src/lib/db.ts", "Instance Prisma singleton (PrismaClient)"],
          ],
          [1800, 2200, 5360],
        ),

        sp(100),
        h2("10.2 Sch\u00e9ma de la base de donn\u00e9es"),
        pa("La base de donn\u00e9es comporte 10 tables interconnect\u00e9es :"),
        sp(40),
        mkTable(
          ["Table", "Colonnes principales", "Description"],
          [
            ["users", "id, email, password (bcrypt), first_name, last_name, role, pole, department, title, avatar, is_active, last_login, mfa_enabled, created_at, updated_at", "Comptes utilisateurs avec authentification"],
            ["sessions", "id, user_id, token (JWT), fingerprint, ip_address, expires_at, created_at", "Sessions actives avec empreinte et expiration"],
            ["modules", "id, name, description, pole, icon, route, priority, type, color, kpi_*, enabled, external_url, html_content, html_file_name, created_at, updated_at", "Configuration des modules du portail"],
            ["roles", "id, label", "R\u00f4les disponibles dans le syst\u00e8me"],
            ["role_poles", "id, role_id, pole", "P\u00f4les accessibles par r\u00f4le"],
            ["role_permissions", "id, role_id, module_id, permission", "Permissions par r\u00f4le et par module (read/write/admin)"],
            ["notifications", "id, type, title, message, module_id, severity, created_at, action_url", "Notifications syst\u00e8me et alertes"],
            ["user_notifications", "id, user_id, notification_id, read, read_at", "Statut de lecture par utilisateur"],
            ["audit_logs", "id, user_id, user_name, action, module, detail, ip_address, timestamp", "Journal d\u2019audit avec IP r\u00e9elle"],
            ["login_attempts", "id, email, count, first_attempt, locked_until", "Protection anti brute-force c\u00f4t\u00e9 serveur"],
          ],
          [1800, 4360, 3200],
        ),

        sp(100),
        h2("10.3 API Routes"),
        pa("Le portail expose 17 endpoints REST via les API Routes de Next.js :"),
        sp(40),
        mkTable(
          ["M\u00e9thode", "Chemin", "Description"],
          [
            ["POST", "/api/auth/login", "Authentification (email + mot de passe), retourne JWT"],
            ["POST", "/api/auth/logout", "D\u00e9connexion, suppression de la session"],
            ["GET", "/api/auth/me", "R\u00e9cup\u00e9rer l\u2019utilisateur connect\u00e9 (via JWT)"],
            ["GET", "/api/users", "Lister tous les utilisateurs (admin)"],
            ["POST", "/api/users", "Cr\u00e9er un utilisateur (admin)"],
            ["PUT", "/api/users/[id]", "Modifier un utilisateur (admin)"],
            ["GET", "/api/modules", "Lister tous les modules"],
            ["POST", "/api/modules", "Cr\u00e9er un module (admin)"],
            ["PUT", "/api/modules/[id]", "Modifier un module (admin)"],
            ["DELETE", "/api/modules/[id]", "Supprimer un module (admin)"],
            ["GET", "/api/roles", "Lister les r\u00f4les et permissions"],
            ["PUT", "/api/roles", "Mettre \u00e0 jour les permissions (admin)"],
            ["GET", "/api/notifications", "R\u00e9cup\u00e9rer les notifications de l\u2019utilisateur"],
            ["PUT", "/api/notifications/[id]", "Marquer une notification comme lue"],
            ["PUT", "/api/notifications/read-all", "Marquer toutes les notifications comme lues"],
            ["GET", "/api/audit", "Consulter le journal d\u2019audit (admin)"],
            ["POST", "/api/audit", "Enregistrer une entr\u00e9e d\u2019audit"],
          ],
          [1000, 3000, 5360],
        ),

        sp(100),
        h2("10.4 Script de migration (Seed)"),
        pa("Le fichier prisma/seed.ts migre les donn\u00e9es initiales vers PostgreSQL :"),
        sp(40),
        bl("11 utilisateurs avec mots de passe hach\u00e9s bcrypt (hash pr\u00e9serv\u00e9s depuis les mock data)"),
        bl("13 modules avec configuration compl\u00e8te (KPIs, routes, couleurs, contenu HTML)"),
        bl("11 r\u00f4les avec permissions granulaires par module"),
        bl("7 notifications syst\u00e8me avec associations utilisateurs"),
        sp(40),
        alert("\u2705", "Le seed est idempotent : il utilise upsert pour \u00e9viter les doublons lors de re-ex\u00e9cutions.", C.GREEN_BG, C.GREEN),

        sp(100),
        h2("10.5 S\u00e9curit\u00e9 de la base de donn\u00e9es"),
        pa("Les mesures de s\u00e9curit\u00e9 suivantes sont appliqu\u00e9es au niveau de la base de donn\u00e9es :"),
        sp(40),
        bl("Hachage bcrypt des mots de passe (10 rounds de salage) stock\u00e9s en base"),
        bl("Sessions JWT avec expiration automatique \u00e0 24 heures (table sessions)"),
        bl("Rate limiting c\u00f4t\u00e9 serveur via la table login_attempts (5 tentatives / 15 min)"),
        bl("Journalisation compl\u00e8te dans audit_logs avec adresse IP r\u00e9elle du client"),
        bl("Connexion PostgreSQL via variable d\u2019environnement DATABASE_URL (jamais en dur)"),
        bl("Instance Prisma singleton pour \u00e9viter les fuites de connexions"),

        pb(),

        // ================================================================
        // 11. SÉCURITÉ
        // ================================================================
        h1("11. Exigences de s\u00e9curit\u00e9 et protection des donn\u00e9es"),

        pa("Le portail IPD impl\u00e9mente un ensemble complet de mesures de s\u00e9curit\u00e9 couvrant l\u2019authentification, l\u2019autorisation, la protection des donn\u00e9es, la journalisation et la d\u00e9fense contre les attaques par force brute."),

        h2("11.1 Authentification s\u00e9curis\u00e9e"),
        h3("Hachage des mots de passe (bcrypt)"),
        bl("Tous les mots de passe sont hach\u00e9s avec bcrypt (10 rounds de salage)"),
        bl("Aucun mot de passe en clair dans le code source ni dans le stockage client"),
        bl("Biblioth\u00e8que utilis\u00e9e : bcryptjs (version JavaScript pure, compatible navigateur)"),
        bl("V\u00e9rification asynchrone via bcrypt.compare() lors de chaque authentification"),
        bl("Migration transparente des mots de passe legacy (plain-text) vers bcrypt"),

        sp(60),
        h3("Validation de complexit\u00e9 des mots de passe"),
        bl("Longueur minimale : 12 caract\u00e8res"),
        bl("Au moins 1 lettre majuscule (A-Z)"),
        bl("Au moins 1 lettre minuscule (a-z)"),
        bl("Au moins 1 chiffre (0-9)"),
        bl("Au moins 1 caract\u00e8re sp\u00e9cial (!@#$%&*...)"),
        bl("G\u00e9n\u00e9ration automatique de mots de passe forts (format IPD-XXXX-XXXX-XXXXXX)"),
        bl("Validation en temps r\u00e9el avec messages d\u2019erreur d\u00e9taill\u00e9s"),

        sp(60),
        h3("Gestion de session (JWT server-side)"),
        bl("Authentification server-side via API Route /api/auth/login"),
        bl("Token JWT sign\u00e9 c\u00f4t\u00e9 serveur (jsonwebtoken) avec cl\u00e9 secr\u00e8te (JWT_SECRET)"),
        bl("Session persist\u00e9e en base de donn\u00e9es (table sessions) avec expiration 24 heures"),
        bl("Empreinte de session (fingerprint) bas\u00e9e sur le user-agent"),
        bl("V\u00e9rification du JWT \u00e0 chaque requ\u00eate API via middleware d\u2019authentification"),
        bl("D\u00e9connexion via API /api/auth/logout (suppression de la session en base)"),
        bl("Cookie HttpOnly avec attributs de s\u00e9curit\u00e9 : SameSite=Strict"),
        bl("Comparaison email insensible \u00e0 la casse lors de l\u2019authentification"),

        sp(80),
        h2("11.2 Protection anti brute-force (Rate Limiting)"),
        bl("Compteur de tentatives \u00e9chou\u00e9es par adresse email (table login_attempts en base)"),
        bl("Verrouillage automatique apr\u00e8s 5 tentatives \u00e9chou\u00e9es"),
        bl("Dur\u00e9e de blocage : 15 minutes (champ locked_until en base de donn\u00e9es)"),
        bl("Affichage d\u2019un message de verrouillage avec le temps restant sur la page de connexion"),
        bl("R\u00e9initialisation automatique du compteur apr\u00e8s connexion r\u00e9ussie"),
        bl("Journalisation de chaque tentative bloqu\u00e9e dans le journal d\u2019audit (table audit_logs)"),
        bl("Persistance c\u00f4t\u00e9 serveur (PostgreSQL) \u2014 le rate limiting ne peut pas \u00eatre contourn\u00e9 c\u00f4t\u00e9 client"),
        alert("\u26a0\ufe0f", "Le verrouillage emp\u00eache toute tentative de connexion pendant la dur\u00e9e du blocage, m\u00eame avec les identifiants corrects.", C.AMBER_BG, C.AMBER),

        sp(80),
        h2("11.3 Autorisation (RBAC)"),
        bl("Syst\u00e8me RBAC complet avec 11 r\u00f4les pr\u00e9d\u00e9finis et 3 niveaux de permission (read, write, admin)"),
        bl("Contr\u00f4le d\u2019acc\u00e8s v\u00e9rifi\u00e9 c\u00f4t\u00e9 client sur toutes les routes prot\u00e9g\u00e9es"),
        bl("Admin g\u00e9n\u00e9ral : acc\u00e8s automatique \u00e0 tous les modules y compris dynamiques"),
        bl("R\u00f4le utilisateur : aucun acc\u00e8s par d\u00e9faut (principe du moindre privil\u00e8ge)"),
        bl("Gestion dynamique des r\u00f4les et permissions via l\u2019interface admin"),

        sp(80),
        h2("11.4 Journalisation et audit"),
        h3("Syst\u00e8me d\u2019audit int\u00e9gr\u00e9"),
        bl("Journalisation automatique de toutes les actions critiques dans PostgreSQL (table audit_logs)"),
        bl("Stockage permanent en base de donn\u00e9es (pas de rotation, historique complet)"),
        bl("Chaque entr\u00e9e contient : ID, user_id, user_name, action, module, d\u00e9tail, adresse IP, timestamp"),
        sp(60),
        h3("\u00c9v\u00e9nements journalis\u00e9s"),
        bl("Connexion r\u00e9ussie (login) avec identification de l\u2019utilisateur"),
        bl("Tentative de connexion \u00e9chou\u00e9e avec l\u2019email utilis\u00e9"),
        bl("Verrouillage de compte apr\u00e8s 5 tentatives"),
        bl("D\u00e9connexion (logout)"),
        bl("Cr\u00e9ation, modification et suppression d\u2019utilisateurs"),
        bl("R\u00e9initialisation de mots de passe"),
        bl("Activation/d\u00e9sactivation de modules"),
        sp(60),
        h3("Interface d\u2019audit"),
        bl("Onglet \u00ab Journal d\u2019Audit \u00bb dans le panneau d\u2019administration"),
        bl("Affichage en temps r\u00e9el avec bouton Actualiser"),
        bl("Historique complet avec horodatage, utilisateur, action et d\u00e9tail"),
        bl("Code couleur par type d\u2019action (login, create, update, delete)"),

        sp(80),
        h2("11.5 Protection des contenus embarqu\u00e9s"),
        bl("Sandbox iframe renforc\u00e9 pour les modules HTML : allow-scripts allow-same-origin"),
        bl("Politique de r\u00e9f\u00e9rence : referrerPolicy=\u201cno-referrer\u201d pour \u00e9viter les fuites d\u2019URL"),
        bl("D\u00e9ploiement HTTPS obligatoire en production"),
        bl("Isolation des modules HTML embarqu\u00e9s via le m\u00e9canisme sandbox du navigateur"),

        sp(80),
        h2("11.6 Fichiers de s\u00e9curit\u00e9"),
        mkTable(
          ["Fichier", "R\u00f4le", "Localisation"],
          [
            ["password.ts", "Hachage bcrypt, v\u00e9rification, validation complexit\u00e9, g\u00e9n\u00e9ration forte", "src/lib/security/"],
            ["rate-limiter.ts", "Protection anti brute-force c\u00f4t\u00e9 serveur (table login_attempts)", "src/lib/security/"],
            ["audit.ts", "Journalisation des actions en base PostgreSQL (table audit_logs)", "src/lib/security/"],
            ["jwt.ts", "G\u00e9n\u00e9ration et v\u00e9rification des tokens JWT", "src/lib/auth/"],
            ["middleware.ts", "Middleware d\u2019authentification pour les API Routes", "src/lib/auth/"],
          ],
          [2500, 5000, 2500],
        ),

        sp(80),
        h2("11.7 Recommandations d\u2019\u00e9volution"),
        bl("Mise en place d\u2019un WAF (Web Application Firewall)"),
        bl("Ajout d\u2019un CAPTCHA apr\u00e8s tentatives \u00e9chou\u00e9es"),
        bl("Int\u00e9gration SSO avec l\u2019annuaire de l\u2019IPD (LDAP/Active Directory)"),
        bl("Impl\u00e9mentation de l\u2019authentification multi-facteurs (MFA/2FA)"),
        bl("Mise en place de sauvegardes automatiques PostgreSQL (pg_dump)"),
        bl("Chiffrement des colonnes sensibles en base (pgcrypto)"),

        pb(),

        // ================================================================
        // 12. STRUCTURE DES FICHIERS
        // ================================================================
        h1("12. Structure du projet"),

        h2("12.1 Arborescence des sources"),
        pa("Le projet est organis\u00e9 selon la convention Next.js App Router :"),
        sp(40),
        mkTable(
          ["R\u00e9pertoire", "Contenu", "Fichiers"],
          [
            ["prisma/", "Sch\u00e9ma BDD et migrations", "schema.prisma, seed.ts, migrations/"],
            ["src/app/(auth)/", "Page de connexion", "login/page.tsx"],
            ["src/app/(portal)/", "Pages prot\u00e9g\u00e9es du portail", "layout.tsx, dashboard, gouvernance, metiers, operations, modules"],
            ["src/app/api/", "API Routes (17 endpoints)", "auth/, users/, modules/, roles/, notifications/, audit/"],
            ["src/components/", "Composants r\u00e9utilisables", "28 composants (admin, dashboard, layout, login, shared, surveillance, ui)"],
            ["src/lib/auth/", "Authentification JWT", "jwt.ts, middleware.ts"],
            ["src/lib/db.ts", "Client Prisma singleton", "Instance PrismaClient"],
            ["src/lib/api-client.ts", "Client API frontal", "apiGet, apiPost, apiPut, apiDelete"],
            ["src/lib/", "Logique m\u00e9tier", "rbac.ts, utils.ts"],
            ["src/stores/", "Stores Zustand", "6 stores (auth, modules, users, roles, notifications, theme)"],
            ["src/types/", "D\u00e9finitions TypeScript", "index.ts (14 types/interfaces)"],
            ["public/", "Fichiers statiques", "modules/ (HTML), images"],
            ["scripts/", "Scripts utilitaires", "gen-guide.js, gen-gestion-users.js, gen-cahier-charges.js"],
          ],
          [2000, 3960, 3400],
        ),

        sp(100),
        h2("12.2 Pages et routes (25 pages + 17 API Routes)"),
        sp(40),
        subtitle("Pages frontend :"),
        sp(40),
        mkTable(
          ["Route", "Type", "Description"],
          [
            ["/login", "SSR", "Page de connexion avec visualisation 3D"],
            ["/dashboard", "SSR", "Tableau de bord principal avec tuiles modules"],
            ["/metiers/ims", "SSR", "Module IMS NextGen (iframe)"],
            ["/metiers/suivi", "SSR", "Module Suivi Coordination (iframe)"],
            ["/metiers/surveillance", "SSR", "Surveillance \u00e9pid\u00e9miologique (carte + alertes)"],
            ["/gouvernance/cockpit", "SSR", "Cockpit Strat\u00e9gique (KPIs + graphiques)"],
            ["/gouvernance/seid", "SSR", "SEID Intelligence (applications + qualit\u00e9 donn\u00e9es)"],
            ["/operations/admin", "SSR", "Administration (utilisateurs, modules, r\u00f4les, audit)"],
            ["/modules/[id]", "SSR", "Pages dynamiques pour chaque module (12 routes)"],
            ["/modules/view", "SSR", "Visionneuse de modules personnalis\u00e9s"],
          ],
          [2200, 1200, 5960],
        ),
        sp(60),
        pa("Les 17 API Routes sont d\u00e9taill\u00e9es dans la section 10.3."),

        pb(),

        // ================================================================
        // 13. LIVRABLES ET PLANNING
        // ================================================================
        h1("13. Livrables et planning"),

        h2("13.1 Phase 1 \u2014 P0 (Livr\u00e9)"),
        pa("Modules op\u00e9rationnels et d\u00e9ploy\u00e9s en production :"),
        sp(40),
        mkTable(
          ["Livrable", "Statut", "Date"],
          [
            ["Page de connexion avec visualisation 3D", "Livr\u00e9", "Mars 2026"],
            ["Tableau de bord principal", "Livr\u00e9", "Mars 2026"],
            ["Module IMS NextGen", "Livr\u00e9", "Mars 2026"],
            ["Module Suivi Coordination", "Livr\u00e9", "Mars 2026"],
            ["Cockpit Strat\u00e9gique", "Livr\u00e9", "Mars 2026"],
            ["SEID Intelligence", "Livr\u00e9", "Mars 2026"],
            ["Surveillance \u00c9pid\u00e9miologique", "Livr\u00e9", "Mars 2026"],
            ["Administration Portail", "Livr\u00e9", "Mars 2026"],
            ["Syst\u00e8me RBAC complet", "Livr\u00e9", "Mars 2026"],
            ["Migration PostgreSQL + Prisma + API Routes", "Livr\u00e9", "Mars 2026"],
            ["D\u00e9ploiement VPS (Node.js + PostgreSQL + Nginx)", "Livr\u00e9", "Mars 2026"],
          ],
          [4200, 1200, 3960],
        ),

        sp(100),
        h2("13.2 Phase 2 \u2014 P1 (Planifi\u00e9)"),
        mkTable(
          ["Livrable", "Statut", "Estimation"],
          [
            ["Module Production Vaccins", "Planifi\u00e9", "T2 2026"],
            ["Module Grant Office", "Planifi\u00e9", "T2 2026"],
            ["Module Ressources Humaines", "Planifi\u00e9", "T3 2026"],
            ["Module Finance & Logistique", "Planifi\u00e9", "T3 2026"],
            ["Backend API (authentification server-side)", "Planifi\u00e9", "T3 2026"],
            ["Int\u00e9gration SSO / LDAP", "Planifi\u00e9", "T3 2026"],
          ],
          [4200, 1200, 3960],
        ),

        sp(100),
        h2("13.3 Phase 3 \u2014 P2 (Futur)"),
        mkTable(
          ["Livrable", "Statut", "Estimation"],
          [
            ["Module Mobilisation Ressources", "Planifi\u00e9", "T4 2026"],
            ["Module Relations M\u00e9dias", "Planifi\u00e9", "T4 2026"],
            ["Application mobile (PWA)", "Planifi\u00e9", "2027"],
            ["Int\u00e9gration BI avanc\u00e9e", "Planifi\u00e9", "2027"],
          ],
          [4200, 1200, 3960],
        ),

        pb(),

        // ================================================================
        // 14. ANNEXES
        // ================================================================
        h1("14. Annexes"),

        h2("14.1 D\u00e9pendances compl\u00e8tes du projet"),
        sp(40),
        mkTable(
          ["Package", "Version", "Licence", "Usage"],
          [
            ["next", "16.1.6", "MIT", "Framework React SSR + API Routes"],
            ["react / react-dom", "19.2.3", "MIT", "Librairie UI"],
            ["typescript", "5.x", "Apache-2.0", "Typage statique"],
            ["@prisma/client", "6.x", "Apache-2.0", "Client ORM pour PostgreSQL"],
            ["prisma", "6.x", "Apache-2.0", "CLI ORM (migrations, seed, studio)"],
            ["jsonwebtoken", "9.x", "MIT", "G\u00e9n\u00e9ration et v\u00e9rification JWT"],
            ["cookie", "1.x", "MIT", "Parsing et serialisation des cookies"],
            ["tsx", "4.x", "MIT", "Ex\u00e9cution TypeScript (seed script)"],
            ["tailwindcss", "4.x", "MIT", "CSS utilitaire"],
            ["zustand", "5.0.11", "MIT", "Gestion d\u2019\u00e9tat"],
            ["framer-motion", "12.36.0", "MIT", "Animations"],
            ["recharts", "3.8.0", "MIT", "Graphiques"],
            ["react-leaflet", "5.0.0", "Hippocratic", "Cartographie"],
            ["leaflet", "1.9.4", "BSD-2", "Moteur de carte"],
            ["lucide-react", "0.577.0", "ISC", "Ic\u00f4nes SVG"],
            ["date-fns", "4.1.0", "MIT", "Manipulation de dates"],
            ["cmdk", "1.1.1", "MIT", "Command palette"],
            ["chart.js", "4.x (CDN)", "MIT", "Graphiques modules HTML"],
          ],
          [2000, 1200, 1600, 4560],
        ),

        sp(100),
        h2("14.2 Glossaire"),
        sp(40),
        mkTable(
          ["Terme", "D\u00e9finition"],
          [
            ["RBAC", "Role-Based Access Control \u2014 Contr\u00f4le d\u2019acc\u00e8s bas\u00e9 sur les r\u00f4les"],
            ["JWT", "JSON Web Token \u2014 Standard de jeton d\u2019authentification"],
            ["ORM", "Object-Relational Mapping \u2014 Couche d\u2019abstraction base de donn\u00e9es"],
            ["SSR", "Server-Side Rendering \u2014 Rendu c\u00f4t\u00e9 serveur"],
            ["SSG", "Static Site Generation \u2014 G\u00e9n\u00e9ration de site statique"],
            ["KPI", "Key Performance Indicator \u2014 Indicateur cl\u00e9 de performance"],
            ["MFA", "Multi-Factor Authentication \u2014 Authentification multi-facteurs"],
            ["IMS", "Integrated Management System \u2014 Syst\u00e8me de Management Int\u00e9gr\u00e9"],
            ["UVFJ", "Unit\u00e9 de Vaccin contre la Fi\u00e8vre Jaune"],
            ["LCQ", "Laboratoire de Contr\u00f4le Qualit\u00e9"],
            ["CAPA", "Corrective And Preventive Actions \u2014 Actions correctives et pr\u00e9ventives"],
            ["OMS", "Organisation Mondiale de la Sant\u00e9"],
            ["ARP", "Autorit\u00e9 de R\u00e9glementation Pharmaceutique"],
            ["SEID", "Suivi-\u00c9valuation et Intelligence de Donn\u00e9es"],
            ["CAS", "Cellule d\u2019Appui Strat\u00e9gique"],
            ["DSI", "Direction des Syst\u00e8mes d\u2019Information"],
            ["DRH", "Direction des Ressources Humaines"],
            ["DAF", "Direction Administrative et Financi\u00e8re"],
          ],
          [1600, 7760],
        ),

        sp(200),
        // --- Footer ---
        new Paragraph({
          alignment: AlignmentType.CENTER,
          border: { top: { style: BorderStyle.SINGLE, size: 4, color: C.ACCENT, space: 10 } },
          spacing: { before: 200, after: 100 },
          children: [new TextRun({ text: "Institut Pasteur de Dakar", size: 24, font: "Arial", bold: true, color: C.PRIMARY })],
        }),
        new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 60 }, children: [new TextRun({ text: "Portail Int\u00e9gr\u00e9 de Cyber-Gouvernance", size: 20, font: "Arial", color: C.GRAY })] }),
        new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 60 }, children: [new TextRun({ text: "Cahier des charges \u2014 Version 1.0 \u2014 Mars 2026", size: 20, font: "Arial", color: C.GRAY })] }),
        new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: "Document confidentiel \u2014 Reproduction interdite sans autorisation", size: 18, font: "Arial", italics: true, color: C.GRAY })] }),
      ],
    },
  ],
});

const OUT = "/Users/amadou/Documents/IPD/portail-ipd/Cahier_des_Charges_Portail_IPD.docx";
Packer.toBuffer(doc).then(buf => {
  fs.writeFileSync(OUT, buf);
  console.log("Cahier des charges cree:", OUT, `(${(buf.length / 1024).toFixed(0)} Ko)`);
});
