#!/bin/bash
# ═══════════════════════════════════════════════════════════
#  SCRIPT DE DÉPLOIEMENT VPS — Portail IPD
# ═══════════════════════════════════════════════════════════
#
#  Usage :
#    ./scripts/deploy-vps.sh [IP_DU_VPS]
#
#  Exemple :
#    ./scripts/deploy-vps.sh 185.200.100.50
#
# ═══════════════════════════════════════════════════════════

set -e

VPS_IP="${1:-VOTRE_IP_VPS}"
VPS_USER="root"
APP_DIR="/var/www/portail-ipd"

if [ "$VPS_IP" = "VOTRE_IP_VPS" ]; then
    echo ""
    echo "  ⚠️  Usage : ./scripts/deploy-vps.sh IP_DU_VPS"
    echo "  Exemple : ./scripts/deploy-vps.sh 185.200.100.50"
    echo ""
    exit 1
fi

echo ""
echo "╔══════════════════════════════════════════════╗"
echo "║  Déploiement VPS — Portail IPD               ║"
echo "║  Serveur : ${VPS_IP}                         "
echo "╚══════════════════════════════════════════════╝"
echo ""

# ─── 1. Basculer en mode serveur ────────────────────────
echo "━━━ Étape 1/5 : Configuration mode serveur ━━━"

# Sauvegarder la config statique
cp next.config.ts next.config.ts.static

# Basculer en mode serveur
cat > next.config.ts << 'NEXTCONF'
import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Mode serveur (API Routes + SSR + PostgreSQL)
};

export default nextConfig;
NEXTCONF

# Restaurer les API routes si nécessaire
if [ -d "src/app/_api_server" ]; then
    mv src/app/_api_server src/app/api
fi

echo "✓ Mode serveur activé"
echo ""

# ─── 2. Synchronisation des fichiers ────────────────────
echo "━━━ Étape 2/5 : Upload vers VPS ━━━"
rsync -avz --progress \
    --exclude=node_modules \
    --exclude=.next \
    --exclude=out \
    --exclude=.git \
    --exclude=.env \
    --exclude=next.config.ts.static \
    . ${VPS_USER}@${VPS_IP}:${APP_DIR}/

echo "✓ Fichiers synchronisés"
echo ""

# ─── 3. Installation et build sur le VPS ────────────────
echo "━━━ Étape 3/5 : Build sur le VPS ━━━"
ssh ${VPS_USER}@${VPS_IP} << REMOTE
    set -e
    cd ${APP_DIR}

    echo "  → npm ci..."
    npm ci --production=false

    echo "  → Prisma generate..."
    npx prisma generate

    echo "  → Prisma migrate..."
    npx prisma migrate deploy

    echo "  → Build Next.js..."
    npm run build

    echo "✓ Build terminé"
REMOTE
echo ""

# ─── 4. Redémarrage PM2 ─────────────────────────────────
echo "━━━ Étape 4/5 : Redémarrage application ━━━"
ssh ${VPS_USER}@${VPS_IP} << REMOTE
    cd ${APP_DIR}
    pm2 delete portail-ipd 2>/dev/null || true
    pm2 start ecosystem.config.cjs
    pm2 save
    echo "✓ Application redémarrée"
REMOTE
echo ""

# ─── 5. Restaurer la config statique locale ─────────────
echo "━━━ Étape 5/5 : Restauration config locale ━━━"
mv next.config.ts.static next.config.ts
echo "✓ Config statique Hostinger restaurée"
echo ""

# ─── Résumé ──────────────────────────────────────────────
echo "═══════════════════════════════════════════════"
echo "  ✅  DÉPLOIEMENT VPS TERMINÉ"
echo "═══════════════════════════════════════════════"
echo ""
echo "  Portail accessible sur :"
echo "    → https://seid-pasteur.org"
echo "    → http://${VPS_IP}:3000 (direct)"
echo ""
echo "  Commandes utiles sur le VPS :"
echo "    pm2 status         — État de l'application"
echo "    pm2 logs           — Logs en temps réel"
echo "    pm2 restart all    — Redémarrer"
echo "    pm2 monit          — Monitoring"
echo ""
echo "═══════════════════════════════════════════════"
