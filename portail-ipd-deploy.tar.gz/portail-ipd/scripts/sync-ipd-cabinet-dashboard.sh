#!/bin/bash
# ══════════════════════════════════════════════════════════
# Synchronise le code source IPD Cabinet Dashboard
# (plateforme PMO Cabinet AG) dans apps/ipd-cabinet-dashboard/
# pour que docker-compose puisse le builder.
#
# Usage :
#   ./scripts/sync-ipd-cabinet-dashboard.sh [SOURCE]
# Défaut : ../ipd-pmo-platform (sibling du dossier portail-ipd)
# ══════════════════════════════════════════════════════════
set -e

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PROJECT_DIR="$( cd "$SCRIPT_DIR/.." && pwd )"
SOURCE="${1:-${PROJECT_DIR}/../../ipd-pmo-platform}"
TARGET="${PROJECT_DIR}/apps/ipd-cabinet-dashboard"

if [ ! -d "$SOURCE" ]; then
  echo "[ERREUR] Source introuvable: $SOURCE"
  echo "Usage: $0 [chemin_vers_ipd-pmo-platform]"
  exit 1
fi

echo "[INFO] Source: $SOURCE"
echo "[INFO] Target: $TARGET"

mkdir -p "$TARGET"

rsync -a --delete \
  --exclude 'node_modules' \
  --exclude '.next' \
  --exclude 'out' \
  --exclude '.git' \
  --exclude '.env' \
  --exclude '.env.local' \
  --exclude '.vercel' \
  --exclude '.DS_Store' \
  "$SOURCE/" "$TARGET/"

echo "[OK] IPD Cabinet Dashboard synchronisé dans $TARGET"
