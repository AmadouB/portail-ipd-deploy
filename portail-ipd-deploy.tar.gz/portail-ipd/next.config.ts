import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Mode statique pour Hostinger — décommenter pour build statique
  // output: "export",
  // Mode standalone pour Docker / VPS — build optimise
  output: "standalone",
  trailingSlash: true,
  images: { unoptimized: true },
};

export default nextConfig;
