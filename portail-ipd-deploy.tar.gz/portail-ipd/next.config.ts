import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Mode statique pour Hostinger — décommenter pour build statique
  // output: "export",
  // Mode standalone pour Docker / VPS — build optimise
  output: "standalone",
  trailingSlash: true,
  images: { unoptimized: true },
  // basePath pour multi-app sur même serveur (ex: /portail)
  // Defini via NEXT_BASE_PATH a la construction Docker
  basePath: process.env.NEXT_BASE_PATH || "",
  assetPrefix: process.env.NEXT_BASE_PATH || undefined,
};

export default nextConfig;
