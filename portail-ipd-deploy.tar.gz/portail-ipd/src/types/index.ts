export type Pole = "gouvernance" | "metiers" | "partenariat" | "operations";

export type RoleName =
  | "admin_general"
  | "cas"
  | "seid"
  | "dsi"
  | "dir_production"
  | "dir_recherche"
  | "dir_sante_publique"
  | "dir_partenariat"
  | "drh"
  | "daf"
  | "utilisateur"
  | (string & {});

export type ModuleId =
  | "cockpit"
  | "seid"
  | "surveillance"
  | "admin"
  | "production"
  | "grant_office"
  | "rh"
  | "finance"
  | "partenariat"
  | "communication"
  | (string & {});

export type Permission = "read" | "write" | "admin";

export interface User {
  id: string;
  email: string;
  password: string;
  firstName: string;
  lastName: string;
  role: RoleName;
  pole: Pole | "tous";
  department: string;
  title: string;
  avatar?: string;
  isActive: boolean;
  lastLogin?: string;
  mfaEnabled: boolean;
}

export interface UserSession {
  user: Omit<User, "password">;
  token: string;
  expiresAt: string;
}

export interface ModuleConfig {
  id: ModuleId;
  name: string;
  description: string;
  pole: Pole;
  icon: string;
  route: string;
  priority: "P0" | "P1" | "P2";
  type: "react" | "html" | "iframe";
  color: string;
  kpiLabel?: string;
  kpiValue?: string | number;
  kpiTrend?: "up" | "down" | "stable";
  enabled: boolean;
  externalUrl?: string;
  htmlContent?: string;
  htmlFileName?: string;
}

export interface Notification {
  id: string;
  type: "alert" | "validation" | "system" | "info";
  title: string;
  message: string;
  module?: ModuleId;
  severity: "low" | "medium" | "high" | "critical";
  read: boolean;
  createdAt: string;
  actionUrl?: string;
}

export interface AuditLog {
  id: string;
  userId: string;
  userName: string;
  action: "login" | "logout" | "view" | "create" | "update" | "delete" | "export";
  module: ModuleId | "auth" | "system";
  detail: string;
  ipAddress: string;
  timestamp: string;
}

export interface KpiData {
  label: string;
  value: number;
  previousValue?: number;
  unit?: string;
  trend?: "up" | "down" | "stable";
  color?: string;
}

export interface ChartDataPoint {
  name: string;
  [key: string]: string | number;
}

export const POLE_CONFIG: Record<Pole, { label: string; color: string; icon: string }> = {
  gouvernance: { label: "Gouvernance & Strategie", color: "#06b6d4", icon: "Shield" },
  metiers: { label: "Fonctions Metiers", color: "#10b981", icon: "FlaskConical" },
  partenariat: { label: "Partenariat", color: "#8b5cf6", icon: "Handshake" },
  operations: { label: "Fonctions Operationnelles", color: "#f59e0b", icon: "Settings" },
};
