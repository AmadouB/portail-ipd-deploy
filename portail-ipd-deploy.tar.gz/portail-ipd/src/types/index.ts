export type Pole = "gouvernance" | "metiers" | "partenariat" | "operations";

/**
 * Roles globaux IPD (convention partagee entre toutes les apps).
 * Hierarchie d'acces : admin_general > ag > directeur > chef_service > utilisateur
 *
 * - admin_general : Administrateur du portail (configure tout, gere les users)
 * - ag            : Administrateur General / Direction Generale (voit tout en lecture)
 * - directeur     : Chef de direction (voit son pole entier)
 * - chef_service  : Chef de service (voit + edite son service)
 * - utilisateur   : Voit son service en lecture seule
 *
 * Roles legacy (compatibilite) : cas, seid, dsi, dir_*, drh, daf
 */
export type RoleName =
  | "admin_general"
  | "ag"
  | "directeur"
  | "chef_service"
  | "utilisateur"
  // ── Roles legacy (a migrer progressivement vers les 5 ci-dessus) ──
  | "cas"
  | "seid"
  | "dsi"
  | "dir_production"
  | "dir_recherche"
  | "dir_sante_publique"
  | "dir_partenariat"
  | "drh"
  | "daf"
  | (string & {});

/** Helpers pour verifier les roles dans la logique applicative. */
export const GLOBAL_ADMIN_ROLES: RoleName[] = ["admin_general", "ag"];
export const DIRECTION_ROLES: RoleName[] = ["directeur", "dir_production", "dir_recherche", "dir_sante_publique", "dir_partenariat"];

export function isGlobalAdmin(role: string | undefined | null): boolean {
  return role != null && (GLOBAL_ADMIN_ROLES as string[]).includes(role);
}

export function isDirectionLevel(role: string | undefined | null): boolean {
  return role != null && (DIRECTION_ROLES as string[]).includes(role);
}

export type ModuleId =
  | "cockpit"
  | "seid"
  | "surveillance"
  | "admin"
  | "production"
  | "grant_office"
  | "rh"
  | "finance"
  | "partenariat"
  | "communication"
  | (string & {});

export type Permission = "read" | "write" | "admin";

export interface User {
  id: string;
  email: string;
  password: string;
  firstName: string;
  lastName: string;
  role: RoleName;
  pole: Pole | "tous";
  department: string;          // Service / cellule (ex: "DAF", "Cellule SEID")
  direction?: string | null;   // Direction de rattachement (ex: "DG", "DRO")
  title: string;               // Fonction (ex: "Chargee de projet")
  phone?: string | null;       // Numero professionnel
  avatar?: string;
  isActive: boolean;
  lastLogin?: string;
  mfaEnabled: boolean;
}

export interface UserSession {
  user: Omit<User, "password">;
  token: string;
  expiresAt: string;
}

export interface ModuleConfig {
  id: ModuleId;
  name: string;
  description: string;
  pole: Pole;
  icon: string;
  route: string;
  priority: "P0" | "P1" | "P2";
  type: "react" | "html" | "iframe";
  color: string;
  kpiLabel?: string;
  kpiValue?: string | number;
  kpiTrend?: "up" | "down" | "stable";
  enabled: boolean;
  externalUrl?: string;
  htmlContent?: string;
  htmlFileName?: string;
}

export interface Notification {
  id: string;
  type: "alert" | "validation" | "system" | "info";
  title: string;
  message: string;
  module?: ModuleId;
  severity: "low" | "medium" | "high" | "critical";
  read: boolean;
  createdAt: string;
  actionUrl?: string;
}

export interface AuditLog {
  id: string;
  userId: string;
  userName: string;
  action: "login" | "logout" | "view" | "create" | "update" | "delete" | "export";
  module: ModuleId | "auth" | "system";
  detail: string;
  ipAddress: string;
  timestamp: string;
}

export interface KpiData {
  label: string;
  value: number;
  previousValue?: number;
  unit?: string;
  trend?: "up" | "down" | "stable";
  color?: string;
}

export interface ChartDataPoint {
  name: string;
  [key: string]: string | number;
}

export const POLE_CONFIG: Record<Pole, { label: string; color: string; icon: string }> = {
  gouvernance: { label: "Gouvernance & Strategie", color: "#06b6d4", icon: "Shield" },
  metiers: { label: "Fonctions Metiers", color: "#10b981", icon: "FlaskConical" },
  partenariat: { label: "Partenariat", color: "#8b5cf6", icon: "Handshake" },
  operations: { label: "Fonctions Operationnelles", color: "#f59e0b", icon: "Settings" },
};
