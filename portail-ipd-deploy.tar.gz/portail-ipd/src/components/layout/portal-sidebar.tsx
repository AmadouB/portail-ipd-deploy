"use client";

import { usePathname } from "next/navigation";
import Link from "next/link";
import { cn } from "@/lib/utils";
import { useAuthStore } from "@/stores/auth-store";
import { useModuleStore } from "@/stores/module-store";
import { hasModuleAccess } from "@/lib/rbac";
import { type ModuleId, POLE_CONFIG } from "@/types";
import {
  LayoutDashboard,
  Shield,
  BarChart3,
  Activity,
  Settings,
  FlaskConical,
  Handshake,
  ChevronLeft,
  ChevronRight,
  Menu,
  X,
  ClipboardCheck,
  Gauge,
  Target,
  Building2,
} from "lucide-react";
import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";

const ICON_MAP: Record<string, React.ReactNode> = {
  ClipboardCheck: <ClipboardCheck className="h-5 w-5" />,
  Target: <Target className="h-5 w-5" />,
  Handshake: <Handshake className="h-5 w-5" />,
  Gauge: <Gauge className="h-5 w-5" />,
  Building2: <Building2 className="h-5 w-5" />,
  Settings: <Settings className="h-5 w-5" />,
  Shield: <Shield className="h-5 w-5" />,
  BarChart3: <BarChart3 className="h-5 w-5" />,
  Activity: <Activity className="h-5 w-5" />,
  FlaskConical: <FlaskConical className="h-5 w-5" />,
};

interface NavItem {
  id: string;
  label: string;
  icon: React.ReactNode;
  href: string;
  pole?: "gouvernance" | "metiers" | "partenariat" | "operations";
  color?: string;
}

const POLE_ICONS: Record<string, React.ReactNode> = {
  gouvernance: <Shield className="h-4 w-4" />,
  metiers: <FlaskConical className="h-4 w-4" />,
  partenariat: <Handshake className="h-4 w-4" />,
  operations: <Settings className="h-4 w-4" />,
};

export function PortalSidebar() {
  const pathname = usePathname();
  const session = useAuthStore((s) => s.session);
  const modules = useModuleStore((s) => s.modules);
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const check = () => setIsMobile(window.innerWidth < 768);
    check();
    window.addEventListener("resize", check);
    return () => window.removeEventListener("resize", check);
  }, []);

  useEffect(() => {
    setMobileOpen(false);
  }, [pathname]);

  if (!session) return null;

  const role = session.user.role;

  // Build nav items from modules
  const dashboardItem: NavItem = {
    id: "dashboard",
    label: "Modules",
    icon: <LayoutDashboard className="h-5 w-5" />,
    href: "/dashboard",
  };

  const moduleItems: NavItem[] = modules
    .filter((m) => m.enabled)
    .filter((m) => m.id === "admin" || hasModuleAccess(role, m.id as ModuleId))
    .map((m) => ({
      id: m.id,
      label: m.name,
      icon: ICON_MAP[m.icon] || <Settings className="h-5 w-5" />,
      href: m.route,
      pole: m.pole as NavItem["pole"],
      color: m.color,
    }));

  const allItems = [dashboardItem, ...moduleItems];

  // Group by pole
  const grouped = allItems.reduce<Record<string, NavItem[]>>((acc, item) => {
    const key = item.pole || "general";
    if (!acc[key]) acc[key] = [];
    acc[key].push(item);
    return acc;
  }, {});

  // Mobile
  if (isMobile) {
    return (
      <>
        <button
          onClick={() => setMobileOpen(true)}
          className="fixed top-4 left-4 z-50 p-2 rounded-lg glass md:hidden"
        >
          <Menu className="h-5 w-5 text-white/80" />
        </button>

        <AnimatePresence>
          {mobileOpen && (
            <>
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="fixed inset-0 bg-black/60 z-50"
                onClick={() => setMobileOpen(false)}
              />
              <motion.aside
                initial={{ x: -280 }}
                animate={{ x: 0 }}
                exit={{ x: -280 }}
                transition={{ duration: 0.3, ease: "easeInOut" }}
                className="fixed left-0 top-0 h-screen w-[260px] flex flex-col border-r z-50 transition-colors duration-300"
                style={{ backgroundColor: "var(--surface-bg)", borderColor: "var(--surface-border)" }}
              >
                <div className="flex items-center justify-between px-4 h-16 border-b">
                  <div className="flex items-center gap-3">
                    <div className="flex-shrink-0 w-9 h-9 rounded-lg bg-cyan-500/20 flex items-center justify-center">
                      <Shield className="h-5 w-5 text-cyan-400" />
                    </div>
                    <div>
                      <p className="font-semibold text-sm">Portail IPD</p>
                      <p className="text-[10px] text-muted-foreground">Cyber-Gouvernance</p>
                    </div>
                  </div>
                  <button onClick={() => setMobileOpen(false)} className="p-1.5 rounded-lg hover:bg-[var(--surface-hover)]">
                    <X className="h-4 w-4" style={{ color: "var(--surface-text-secondary)" }} />
                  </button>
                </div>

                <SidebarNav grouped={grouped} pathname={pathname} collapsed={false} />
              </motion.aside>
            </>
          )}
        </AnimatePresence>
      </>
    );
  }

  // Desktop
  return (
    <motion.aside
      animate={{ width: collapsed ? 72 : 260 }}
      transition={{ duration: 0.3, ease: "easeInOut" }}
      className="h-screen sticky top-0 flex flex-col border-r hidden md:flex transition-colors duration-300"
      style={{ backgroundColor: "var(--surface-bg)", borderColor: "var(--surface-border)" }}
    >
      <div className="flex items-center gap-3 px-4 h-16 border-b">
        <div className="flex-shrink-0 w-9 h-9 rounded-lg bg-cyan-500/20 flex items-center justify-center">
          <Shield className="h-5 w-5 text-cyan-400" />
        </div>
        <AnimatePresence>
          {!collapsed && (
            <motion.div
              initial={{ opacity: 0, width: 0 }}
              animate={{ opacity: 1, width: "auto" }}
              exit={{ opacity: 0, width: 0 }}
              className="overflow-hidden whitespace-nowrap"
            >
              <p className="font-semibold text-sm">Portail IPD</p>
              <p className="text-[10px] text-muted-foreground">Cyber-Gouvernance</p>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <SidebarNav grouped={grouped} pathname={pathname} collapsed={collapsed} />

      <div className="border-t p-3">
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="w-full flex items-center justify-center h-9 rounded-lg hover:bg-[var(--surface-hover)] transition-colors text-muted-foreground"
        >
          {collapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
        </button>
      </div>
    </motion.aside>
  );
}

function SidebarNav({
  grouped,
  pathname,
  collapsed,
}: {
  grouped: Record<string, NavItem[]>;
  pathname: string;
  collapsed: boolean;
}) {
  return (
    <nav className="flex-1 overflow-y-auto py-4 px-3 space-y-6">
      {grouped.general?.map((item) => (
        <NavLink key={item.id} item={item} active={pathname === item.href || (item.href !== "/dashboard" && pathname.startsWith(item.href))} collapsed={collapsed} accentColor="#22d3ee" />
      ))}

      {(["gouvernance", "metiers", "partenariat", "operations"] as const).map((pole) => {
        const items = grouped[pole];
        if (!items?.length) return null;
        const config = POLE_CONFIG[pole];

        return (
          <div key={pole}>
            {!collapsed && (
              <div className="flex items-center gap-2 px-3 mb-2">
                <div className="text-xs" style={{ color: config.color }}>
                  {POLE_ICONS[pole]}
                </div>
                <span className="text-[10px] font-semibold uppercase tracking-wider" style={{ color: config.color }}>
                  {config.label}
                </span>
              </div>
            )}
            {collapsed && (
              <div className="w-8 h-px mx-auto mb-2" style={{ backgroundColor: config.color }} />
            )}
            <div className="space-y-1">
              {items.map((item) => (
                <NavLink
                  key={item.id}
                  item={item}
                  active={pathname === item.href || pathname.startsWith(item.href)}
                  collapsed={collapsed}
                  accentColor={item.color || config.color}
                />
              ))}
            </div>
          </div>
        );
      })}
    </nav>
  );
}

function NavLink({
  item,
  active,
  collapsed,
  accentColor,
}: {
  item: NavItem;
  active: boolean;
  collapsed: boolean;
  accentColor?: string;
}) {
  return (
    <Link
      href={item.href}
      className={cn(
        "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all duration-200 relative group",
        active
          ? "bg-[var(--accent)] font-medium"
          : "hover:bg-[var(--surface-hover)]"
      )}
      style={{
        color: active ? "var(--surface-text)" : "var(--surface-text-secondary)",
      }}
    >
      {active && accentColor && (
        <div
          className="absolute left-0 top-1/2 -translate-y-1/2 w-[3px] h-5 rounded-r-full"
          style={{ backgroundColor: accentColor }}
        />
      )}
      <div style={{ color: active ? accentColor : undefined }}>{item.icon}</div>
      <AnimatePresence>
        {!collapsed && (
          <motion.span
            initial={{ opacity: 0, width: 0 }}
            animate={{ opacity: 1, width: "auto" }}
            exit={{ opacity: 0, width: 0 }}
            className="overflow-hidden whitespace-nowrap"
          >
            {item.label}
          </motion.span>
        )}
      </AnimatePresence>
    </Link>
  );
}
