"use client";

import { useAuthStore } from "@/stores/auth-store";
import { useThemeStore } from "@/stores/theme-store";
import { NotificationCenter } from "./notification-center";
import { Search, LogOut, User, Sun, Moon, Maximize, Minimize } from "lucide-react";
import { useState, useRef, useEffect } from "react";
import { POLE_CONFIG } from "@/types";

export function PortalHeader() {
  const session = useAuthStore((s) => s.session);
  const logout = useAuthStore((s) => s.logout);
  const { theme, toggleTheme, isFullscreen, toggleFullscreen } = useThemeStore();
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  // Sync fullscreen state with browser events
  useEffect(() => {
    const handleFsChange = () => {
      useThemeStore.setState({ isFullscreen: !!document.fullscreenElement });
    };
    document.addEventListener("fullscreenchange", handleFsChange);
    return () => document.removeEventListener("fullscreenchange", handleFsChange);
  }, []);

  useEffect(() => {
    function handleClick(e: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) setUserMenuOpen(false);
    }
    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, []);

  if (!session) return null;

  const user = session.user;
  const poleConfig = user.pole !== "tous" ? POLE_CONFIG[user.pole] : null;
  const initials = `${user.firstName[0]}${user.lastName[0]}`;

  return (
    <header
      className="h-16 border-b flex items-center justify-between px-4 md:px-6 backdrop-blur-xl sticky top-0 z-40 transition-colors duration-300"
      style={{
        backgroundColor: "var(--surface-header)",
        borderColor: "var(--surface-border)",
      }}
    >
      {/* Search */}
      <div className="flex items-center gap-3 flex-1 max-w-md ml-10 md:ml-0">
        <div className="relative w-full">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4" style={{ color: "var(--surface-text-muted)" }} />
          <input
            type="text"
            placeholder="Rechercher modules, donnees, utilisateurs..."
            className="w-full pl-10 pr-4 py-2 rounded-lg text-sm focus:outline-none transition-colors duration-300"
            style={{
              backgroundColor: "var(--surface-input-bg)",
              border: "1px solid var(--surface-input-border)",
              color: "var(--surface-input-text)",
            }}
          />
          <kbd
            className="absolute right-3 top-1/2 -translate-y-1/2 text-[10px] px-1.5 py-0.5 rounded"
            style={{ color: "var(--surface-kbd-text)", backgroundColor: "var(--surface-kbd)" }}
          >
            /
          </kbd>
        </div>
      </div>

      {/* Right side */}
      <div className="flex items-center gap-1 md:gap-2">
        {/* Theme toggle */}
        <button
          onClick={toggleTheme}
          className="p-2 rounded-lg transition-colors duration-200 hover:bg-[var(--surface-hover)]"
          title={theme === "dark" ? "Mode clair" : "Mode sombre"}
        >
          {theme === "dark" ? (
            <Sun className="h-[18px] w-[18px]" style={{ color: "var(--surface-text-secondary)" }} />
          ) : (
            <Moon className="h-[18px] w-[18px]" style={{ color: "var(--surface-text-secondary)" }} />
          )}
        </button>

        {/* Fullscreen toggle */}
        <button
          onClick={toggleFullscreen}
          className="p-2 rounded-lg transition-colors duration-200 hover:bg-[var(--surface-hover)] hidden sm:flex"
          title={isFullscreen ? "Quitter le plein ecran" : "Plein ecran"}
        >
          {isFullscreen ? (
            <Minimize className="h-[18px] w-[18px]" style={{ color: "var(--surface-text-secondary)" }} />
          ) : (
            <Maximize className="h-[18px] w-[18px]" style={{ color: "var(--surface-text-secondary)" }} />
          )}
        </button>

        <NotificationCenter />

        {/* User menu */}
        <div className="relative" ref={menuRef}>
          <button
            onClick={() => setUserMenuOpen(!userMenuOpen)}
            className="flex items-center gap-3 px-3 py-1.5 rounded-lg transition-colors hover:bg-[var(--surface-hover)]"
          >
            <div
              className="h-8 w-8 rounded-lg flex items-center justify-center text-sm font-semibold"
              style={{ backgroundColor: "var(--surface-avatar-bg)", color: "var(--surface-avatar-text)" }}
            >
              {initials}
            </div>
            <div className="text-left hidden sm:block">
              <p className="text-sm font-medium" style={{ color: "var(--surface-text)" }}>{user.firstName} {user.lastName}</p>
              <p className="text-[10px]" style={{ color: "var(--surface-text-muted)" }}>{user.title}</p>
            </div>
          </button>

          {userMenuOpen && (
            <div
              className="absolute right-0 top-12 w-64 glass rounded-xl shadow-2xl z-50 overflow-hidden"
            >
              <div className="px-4 py-3" style={{ borderBottom: "1px solid var(--surface-border)" }}>
                <p className="font-medium text-sm" style={{ color: "var(--surface-text)" }}>{user.firstName} {user.lastName}</p>
                <p className="text-xs" style={{ color: "var(--surface-text-muted)" }}>{user.email}</p>
                {poleConfig && (
                  <div className="mt-2 flex items-center gap-2">
                    <div className="h-2 w-2 rounded-full" style={{ backgroundColor: poleConfig.color }} />
                    <span className="text-[10px] font-medium" style={{ color: poleConfig.color }}>
                      {poleConfig.label}
                    </span>
                  </div>
                )}
              </div>
              <div className="py-1">
                <button className="w-full flex items-center gap-3 px-4 py-2.5 text-sm transition-colors hover:bg-[var(--surface-hover)]" style={{ color: "var(--surface-text-secondary)" }}>
                  <User className="h-4 w-4" />
                  Mon profil
                </button>
                <button
                  onClick={logout}
                  className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-red-500 hover:bg-red-500/10 transition-colors"
                >
                  <LogOut className="h-4 w-4" />
                  Deconnexion
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
