"use client";

import { useState } from "react";
import { useModuleStore } from "@/stores/module-store";
import { type ModuleConfig, type Pole, POLE_CONFIG } from "@/types";
import { GlassPanel } from "@/components/shared/glass-panel";
import { StatusBadge } from "@/components/shared/status-badge";
import { cn } from "@/lib/utils";
import {
  Plus, Pencil, Trash2, X, Save, ToggleLeft, ToggleRight,
  ExternalLink, Code, Globe, Boxes, Upload, FileCode, Check,
  Shield, BarChart3, Activity, Settings, FlaskConical,
  BookOpen, Users, Wallet, Handshake, Megaphone, Factory,
  Layers, Cpu, Database, FileText, Map, Bell, Heart,
  Briefcase, GraduationCap, Microscope, Building,
  Download, Rocket,
} from "lucide-react";

const AVAILABLE_ICONS: { value: string; icon: React.ReactNode; label: string }[] = [
  { value: "Shield", icon: <Shield className="h-4 w-4" />, label: "Bouclier" },
  { value: "BarChart3", icon: <BarChart3 className="h-4 w-4" />, label: "Graphique" },
  { value: "Activity", icon: <Activity className="h-4 w-4" />, label: "Activite" },
  { value: "Settings", icon: <Settings className="h-4 w-4" />, label: "Parametres" },
  { value: "FlaskConical", icon: <FlaskConical className="h-4 w-4" />, label: "Recherche" },
  { value: "BookOpen", icon: <BookOpen className="h-4 w-4" />, label: "Livre" },
  { value: "Users", icon: <Users className="h-4 w-4" />, label: "Utilisateurs" },
  { value: "Wallet", icon: <Wallet className="h-4 w-4" />, label: "Finance" },
  { value: "Handshake", icon: <Handshake className="h-4 w-4" />, label: "Partenariat" },
  { value: "Megaphone", icon: <Megaphone className="h-4 w-4" />, label: "Communication" },
  { value: "Factory", icon: <Factory className="h-4 w-4" />, label: "Production" },
  { value: "Layers", icon: <Layers className="h-4 w-4" />, label: "Couches" },
  { value: "Cpu", icon: <Cpu className="h-4 w-4" />, label: "Systeme" },
  { value: "Database", icon: <Database className="h-4 w-4" />, label: "Base donnees" },
  { value: "FileText", icon: <FileText className="h-4 w-4" />, label: "Document" },
  { value: "Map", icon: <Map className="h-4 w-4" />, label: "Carte" },
  { value: "Bell", icon: <Bell className="h-4 w-4" />, label: "Notifications" },
  { value: "Heart", icon: <Heart className="h-4 w-4" />, label: "Sante" },
  { value: "Briefcase", icon: <Briefcase className="h-4 w-4" />, label: "Business" },
  { value: "GraduationCap", icon: <GraduationCap className="h-4 w-4" />, label: "Formation" },
  { value: "Microscope", icon: <Microscope className="h-4 w-4" />, label: "Labo" },
  { value: "Building", icon: <Building className="h-4 w-4" />, label: "Batiment" },
];

const TYPE_OPTIONS = [
  { value: "react" as const, label: "Application React", icon: <Code className="h-4 w-4" />, description: "Module React integre nativement" },
  { value: "html" as const, label: "Plateforme HTML", icon: <Globe className="h-4 w-4" />, description: "Site HTML statique en iframe" },
  { value: "iframe" as const, label: "Application Externe", icon: <ExternalLink className="h-4 w-4" />, description: "Application externe en iframe securise" },
];

type HtmlSource = "url" | "upload";

interface ModuleFormData {
  name: string;
  description: string;
  pole: Pole;
  icon: string;
  route: string;
  priority: "P0" | "P1" | "P2";
  type: "react" | "html" | "iframe";
  color: string;
  kpiLabel: string;
  kpiValue: string;
  kpiTrend: "up" | "down" | "stable";
  enabled: boolean;
  externalUrl: string;
  htmlContent: string;
  htmlFileName: string;
  htmlSource: HtmlSource;
}

const EMPTY_FORM: ModuleFormData = {
  name: "",
  description: "",
  pole: "gouvernance",
  icon: "Layers",
  route: "",
  priority: "P1",
  type: "react",
  color: "#06b6d4",
  kpiLabel: "",
  kpiValue: "",
  kpiTrend: "stable",
  enabled: true,
  externalUrl: "",
  htmlContent: "",
  htmlFileName: "",
  htmlSource: "url",
};

export function ModuleManager() {
  const { modules, addModule, updateModule, deleteModule, toggleModule } = useModuleStore();
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState<ModuleFormData>(EMPTY_FORM);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [publishStatus, setPublishStatus] = useState<"idle" | "done">("idle");

  /** Export custom modules for deployment — makes them visible to all users */
  const handlePublish = () => {
    // Find custom modules (those with htmlContent or not in MODULES built-in list)
    const builtInIds = new Set(["cockpit", "seid", "surveillance", "admin", "production",
      "grant_office", "rh", "finance", "partenariat", "communication", "suivi"]);
    const customModules = modules.filter(
      (m) => !builtInIds.has(m.id) && (m.htmlContent || m.externalUrl || m.type === "html" || m.type === "iframe")
    );

    if (customModules.length === 0) {
      alert("Aucun module personnalise a publier.\nLes modules integres sont deja visibles par tous.");
      return;
    }

    const exportData = {
      exportedAt: new Date().toISOString(),
      modules: customModules.map((m) => ({
        ...m,
        // Mark which ones have HTML content for the deploy script
        _hasHtmlContent: !!m.htmlContent,
      })),
    };

    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "modules-export.json";
    a.click();
    URL.revokeObjectURL(url);

    setPublishStatus("done");
    setTimeout(() => setPublishStatus("idle"), 5000);
  };

  const openAddForm = () => {
    setForm(EMPTY_FORM);
    setEditingId(null);
    setShowForm(true);
  };

  const openEditForm = (mod: ModuleConfig) => {
    setForm({
      name: mod.name,
      description: mod.description,
      pole: mod.pole,
      icon: mod.icon,
      route: mod.route,
      priority: mod.priority,
      type: mod.type,
      color: mod.color,
      kpiLabel: mod.kpiLabel || "",
      kpiValue: String(mod.kpiValue || ""),
      kpiTrend: mod.kpiTrend || "stable",
      enabled: mod.enabled,
      externalUrl: mod.externalUrl || "",
      htmlContent: mod.htmlContent || "",
      htmlFileName: mod.htmlFileName || "",
      htmlSource: mod.htmlContent ? "upload" : "url",
    });
    setEditingId(mod.id);
    setShowForm(true);
  };

  const handleFileUpload = (file: File) => {
    if (!file.name.match(/\.(html?|htm)$/i)) return;
    const reader = new FileReader();
    reader.onload = (e) => {
      const content = e.target?.result as string;
      setForm((prev) => ({
        ...prev,
        htmlContent: content,
        htmlFileName: file.name,
        externalUrl: "",
      }));
    };
    reader.readAsText(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files[0];
    if (file) handleFileUpload(file);
  };

  const handleSave = () => {
    const id = editingId || form.name.toLowerCase().replace(/\s+/g, "_").replace(/[^a-z0-9_]/g, "");
    const isUpload = form.type === "html" && form.htmlSource === "upload" && form.htmlContent;
    const moduleData: ModuleConfig = {
      id,
      name: form.name,
      description: form.description,
      pole: form.pole,
      icon: form.icon,
      route: form.type !== "react" ? `/modules/view?id=${id}` : form.route,
      priority: form.priority,
      type: form.type,
      color: form.color || POLE_CONFIG[form.pole].color,
      kpiLabel: form.kpiLabel || undefined,
      kpiValue: form.kpiValue || undefined,
      kpiTrend: form.kpiTrend,
      enabled: form.enabled,
      externalUrl: isUpload ? undefined : (form.type !== "react" ? form.externalUrl : undefined),
      htmlContent: isUpload ? form.htmlContent : undefined,
      htmlFileName: isUpload ? form.htmlFileName : undefined,
    };

    if (editingId) {
      updateModule(editingId, moduleData);
    } else {
      addModule(moduleData);
    }

    setShowForm(false);
    setEditingId(null);
  };

  const handleDelete = (id: string) => {
    deleteModule(id);
    setDeleteConfirm(null);
  };

  const updateField = <K extends keyof ModuleFormData>(field: K, value: ModuleFormData[K]) => {
    setForm((prev) => {
      const next = { ...prev, [field]: value };
      // Auto-set color from pole when pole changes
      if (field === "pole") {
        next.color = POLE_CONFIG[value as Pole].color;
      }
      return next;
    });
  };

  const enabledModules = modules.filter((m) => m.enabled);
  const disabledModules = modules.filter((m) => !m.enabled);

  return (
    <div className="space-y-6">
      {/* Header + Add button */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <h3 className="font-semibold flex items-center gap-2">
          <Boxes className="h-4 w-4 text-amber-400" />
          Gestion des Modules ({modules.length})
        </h3>
        <div className="flex items-center gap-2">
          <button
            onClick={handlePublish}
            className={cn(
              "flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors",
              publishStatus === "done"
                ? "bg-emerald-600 text-white"
                : "bg-white/5 border border-white/10 text-white/70 hover:text-white hover:border-cyan-500/30 hover:bg-cyan-500/5"
            )}
          >
            {publishStatus === "done" ? (
              <>
                <Check className="h-4 w-4" />
                Exporte !
              </>
            ) : (
              <>
                <Rocket className="h-4 w-4" />
                Publier les modules
              </>
            )}
          </button>
          <button
            onClick={openAddForm}
            className="flex items-center gap-2 px-4 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-sm font-medium transition-colors"
          >
            <Plus className="h-4 w-4" />
            Ajouter un module
          </button>
        </div>
      </div>

      {/* Publish instructions */}
      {publishStatus === "done" && (
        <div className="p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-xs text-emerald-400 space-y-1">
          <p className="font-semibold flex items-center gap-1.5">
            <Download className="h-3.5 w-3.5" />
            Fichier modules-export.json telecharge
          </p>
          <p className="text-emerald-400/80">
            Pour rendre les modules visibles par tous les utilisateurs :
          </p>
          <ol className="list-decimal list-inside text-emerald-400/70 space-y-0.5 ml-1">
            <li>Placez le fichier dans le dossier du projet portail-ipd</li>
            <li>Lancez la commande : <code className="font-mono bg-emerald-500/10 px-1.5 py-0.5 rounded">npm run deploy</code></li>
          </ol>
        </div>
      )}

      {/* Active Modules */}
      <GlassPanel animate={false}>
        <h4 className="text-sm font-semibold mb-3 text-emerald-400">Modules actifs ({enabledModules.length})</h4>
        <div className="space-y-2">
          {enabledModules.map((mod) => (
            <ModuleRow
              key={mod.id}
              mod={mod}
              onEdit={() => openEditForm(mod)}
              onDelete={() => setDeleteConfirm(mod.id)}
              onToggle={() => toggleModule(mod.id)}
              deleteConfirm={deleteConfirm === mod.id}
              onDeleteCancel={() => setDeleteConfirm(null)}
              onDeleteConfirm={() => handleDelete(mod.id)}
            />
          ))}
          {enabledModules.length === 0 && (
            <p className="text-sm text-muted-foreground py-4 text-center">Aucun module actif</p>
          )}
        </div>
      </GlassPanel>

      {/* Disabled Modules */}
      <GlassPanel animate={false}>
        <h4 className="text-sm font-semibold mb-3 text-muted-foreground">Modules a venir ({disabledModules.length})</h4>
        <div className="space-y-2">
          {disabledModules.map((mod) => (
            <ModuleRow
              key={mod.id}
              mod={mod}
              onEdit={() => openEditForm(mod)}
              onDelete={() => setDeleteConfirm(mod.id)}
              onToggle={() => toggleModule(mod.id)}
              deleteConfirm={deleteConfirm === mod.id}
              onDeleteCancel={() => setDeleteConfirm(null)}
              onDeleteConfirm={() => handleDelete(mod.id)}
            />
          ))}
          {disabledModules.length === 0 && (
            <p className="text-sm text-muted-foreground py-4 text-center">Aucun module en attente</p>
          )}
        </div>
      </GlassPanel>

      {/* Modal Form */}
      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setShowForm(false)} />
          <div className="relative w-full max-w-2xl max-h-[90vh] overflow-y-auto glass rounded-2xl border border-white/10 shadow-2xl">
            {/* Form Header */}
            <div className="flex items-center justify-between px-6 py-4 border-b border-white/[0.06] sticky top-0 bg-[#0a0e1a]/95 backdrop-blur-xl rounded-t-2xl z-10">
              <h3 className="font-semibold text-lg">
                {editingId ? "Modifier le module" : "Ajouter un nouveau module"}
              </h3>
              <button onClick={() => setShowForm(false)} className="p-2 rounded-lg hover:bg-white/5">
                <X className="h-5 w-5 text-white/60" />
              </button>
            </div>

            {/* Form Body */}
            <div className="px-6 py-5 space-y-5">
              {/* Name + Priority */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="md:col-span-2">
                  <label className="block text-xs text-muted-foreground mb-1.5">Nom du module *</label>
                  <input
                    value={form.name}
                    onChange={(e) => updateField("name", e.target.value)}
                    className="w-full px-3 py-2.5 rounded-lg bg-white/5 border border-white/10 text-sm focus:outline-none focus:border-cyan-500/50 transition-colors"
                    placeholder="Ex: Gestion des Laboratoires"
                  />
                </div>
                <div>
                  <label className="block text-xs text-muted-foreground mb-1.5">Priorite</label>
                  <select
                    value={form.priority}
                    onChange={(e) => updateField("priority", e.target.value as "P0" | "P1" | "P2")}
                    className="w-full px-3 py-2.5 rounded-lg bg-white/5 border border-white/10 text-sm focus:outline-none focus:border-cyan-500/50 transition-colors"
                  >
                    <option value="P0">P0 - Critique</option>
                    <option value="P1">P1 - Haute</option>
                    <option value="P2">P2 - Moyenne</option>
                  </select>
                </div>
              </div>

              {/* Description */}
              <div>
                <label className="block text-xs text-muted-foreground mb-1.5">Description</label>
                <textarea
                  value={form.description}
                  onChange={(e) => updateField("description", e.target.value)}
                  rows={2}
                  className="w-full px-3 py-2.5 rounded-lg bg-white/5 border border-white/10 text-sm focus:outline-none focus:border-cyan-500/50 transition-colors resize-none"
                  placeholder="Description du module..."
                />
              </div>

              {/* Type de plateforme */}
              <div>
                <label className="block text-xs text-muted-foreground mb-2">Type de plateforme *</label>
                <div className="grid grid-cols-3 gap-3">
                  {TYPE_OPTIONS.map((opt) => (
                    <button
                      key={opt.value}
                      onClick={() => updateField("type", opt.value)}
                      className={cn(
                        "p-3 rounded-xl border text-left transition-all",
                        form.type === opt.value
                          ? "border-cyan-500/50 bg-cyan-500/10"
                          : "border-white/10 bg-white/[0.02] hover:bg-white/[0.04]"
                      )}
                    >
                      <div className={cn("mb-1.5", form.type === opt.value ? "text-cyan-400" : "text-white/60")}>
                        {opt.icon}
                      </div>
                      <p className="text-xs font-medium">{opt.label}</p>
                      <p className="text-[10px] text-muted-foreground mt-0.5">{opt.description}</p>
                    </button>
                  ))}
                </div>
              </div>

              {/* HTML type: URL or Upload toggle */}
              {form.type === "html" && (
                <div className="space-y-3">
                  <label className="block text-xs text-muted-foreground mb-1">Source du contenu HTML *</label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => setForm((p) => ({ ...p, htmlSource: "url" }))}
                      className={cn(
                        "flex items-center gap-2 p-3 rounded-xl border text-left transition-all",
                        form.htmlSource === "url"
                          ? "border-cyan-500/50 bg-cyan-500/10"
                          : "border-white/10 bg-white/[0.02] hover:bg-white/[0.04]"
                      )}
                    >
                      <Globe className={cn("h-4 w-4", form.htmlSource === "url" ? "text-cyan-400" : "text-white/60")} />
                      <div>
                        <p className="text-xs font-medium">URL externe</p>
                        <p className="text-[10px] text-muted-foreground">Lien vers un site</p>
                      </div>
                    </button>
                    <button
                      onClick={() => setForm((p) => ({ ...p, htmlSource: "upload" }))}
                      className={cn(
                        "flex items-center gap-2 p-3 rounded-xl border text-left transition-all",
                        form.htmlSource === "upload"
                          ? "border-emerald-500/50 bg-emerald-500/10"
                          : "border-white/10 bg-white/[0.02] hover:bg-white/[0.04]"
                      )}
                    >
                      <Upload className={cn("h-4 w-4", form.htmlSource === "upload" ? "text-emerald-400" : "text-white/60")} />
                      <div>
                        <p className="text-xs font-medium">Charger un fichier</p>
                        <p className="text-[10px] text-muted-foreground">Upload .html</p>
                      </div>
                    </button>
                  </div>

                  {form.htmlSource === "url" ? (
                    <div>
                      <input
                        value={form.externalUrl}
                        onChange={(e) => updateField("externalUrl", e.target.value)}
                        className="w-full px-3 py-2.5 rounded-lg bg-white/5 border border-white/10 text-sm focus:outline-none focus:border-cyan-500/50 transition-colors font-mono"
                        placeholder="https://app.pasteur.sn/labo/"
                      />
                      <p className="text-[10px] text-muted-foreground mt-1">
                        L&apos;application HTML sera chargee dans un iframe securise
                      </p>
                    </div>
                  ) : (
                    <div>
                      {/* Drag & drop zone */}
                      <div
                        onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
                        onDragLeave={() => setIsDragging(false)}
                        onDrop={handleDrop}
                        className={cn(
                          "relative flex flex-col items-center justify-center gap-3 p-6 rounded-xl border-2 border-dashed transition-all cursor-pointer",
                          isDragging
                            ? "border-emerald-400 bg-emerald-500/10"
                            : form.htmlContent
                            ? "border-emerald-500/30 bg-emerald-500/5"
                            : "border-white/10 bg-white/[0.02] hover:border-white/20"
                        )}
                        onClick={() => document.getElementById("html-file-input")?.click()}
                      >
                        <input
                          id="html-file-input"
                          type="file"
                          accept=".html,.htm"
                          className="hidden"
                          onChange={(e) => {
                            const file = e.target.files?.[0];
                            if (file) handleFileUpload(file);
                          }}
                        />

                        {form.htmlContent ? (
                          <>
                            <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-emerald-500/10 border border-emerald-500/20">
                              <FileCode className="h-5 w-5 text-emerald-400" />
                              <div>
                                <p className="text-sm font-medium text-emerald-400">{form.htmlFileName}</p>
                                <p className="text-[10px] text-muted-foreground">
                                  {(form.htmlContent.length / 1024).toFixed(1)} Ko
                                </p>
                              </div>
                              <Check className="h-4 w-4 text-emerald-400 ml-2" />
                            </div>
                            <p className="text-[10px] text-muted-foreground">
                              Cliquez ou glissez pour remplacer le fichier
                            </p>
                          </>
                        ) : (
                          <>
                            <div className="p-3 rounded-xl bg-white/5">
                              <Upload className="h-6 w-6 text-white/40" />
                            </div>
                            <div className="text-center">
                              <p className="text-sm font-medium">
                                Glissez un fichier HTML ici
                              </p>
                              <p className="text-[10px] text-muted-foreground mt-1">
                                ou cliquez pour parcourir &middot; Formats : .html, .htm
                              </p>
                            </div>
                          </>
                        )}
                      </div>
                      <p className="text-[10px] text-muted-foreground mt-1.5">
                        Le fichier HTML sera stocke et affiche directement dans le portail sans serveur externe
                      </p>
                    </div>
                  )}
                </div>
              )}

              {/* External URL (for iframe type only) */}
              {form.type === "iframe" && (
                <div>
                  <label className="block text-xs text-muted-foreground mb-1.5">
                    URL de la plateforme externe *
                  </label>
                  <input
                    value={form.externalUrl}
                    onChange={(e) => updateField("externalUrl", e.target.value)}
                    className="w-full px-3 py-2.5 rounded-lg bg-white/5 border border-white/10 text-sm focus:outline-none focus:border-cyan-500/50 transition-colors font-mono"
                    placeholder="https://external-platform.com/app"
                  />
                  <p className="text-[10px] text-muted-foreground mt-1">
                    L&apos;application externe sera integree dans un iframe sandbox avec validation stricte de l&apos;origine
                  </p>
                </div>
              )}

              {/* Route (for react type) */}
              {form.type === "react" && (
                <div>
                  <label className="block text-xs text-muted-foreground mb-1.5">Route interne *</label>
                  <input
                    value={form.route}
                    onChange={(e) => updateField("route", e.target.value)}
                    className="w-full px-3 py-2.5 rounded-lg bg-white/5 border border-white/10 text-sm focus:outline-none focus:border-cyan-500/50 transition-colors font-mono"
                    placeholder="/metiers/laboratoire"
                  />
                </div>
              )}

              {/* Pole + Icon */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs text-muted-foreground mb-1.5">Pole *</label>
                  <select
                    value={form.pole}
                    onChange={(e) => updateField("pole", e.target.value as Pole)}
                    className="w-full px-3 py-2.5 rounded-lg bg-white/5 border border-white/10 text-sm focus:outline-none focus:border-cyan-500/50 transition-colors"
                  >
                    {Object.entries(POLE_CONFIG).map(([key, cfg]) => (
                      <option key={key} value={key}>{cfg.label}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs text-muted-foreground mb-1.5">Icone</label>
                  <div className="flex flex-wrap gap-1.5 p-2 rounded-lg bg-white/[0.02] border border-white/10 max-h-24 overflow-y-auto">
                    {AVAILABLE_ICONS.map((ic) => (
                      <button
                        key={ic.value}
                        onClick={() => updateField("icon", ic.value)}
                        title={ic.label}
                        className={cn(
                          "p-1.5 rounded-lg transition-all",
                          form.icon === ic.value
                            ? "bg-cyan-500/20 text-cyan-400"
                            : "text-white/40 hover:text-white/70 hover:bg-white/5"
                        )}
                      >
                        {ic.icon}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* KPIs */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs text-muted-foreground mb-1.5">Label KPI (optionnel)</label>
                  <input
                    value={form.kpiLabel}
                    onChange={(e) => updateField("kpiLabel", e.target.value)}
                    className="w-full px-3 py-2.5 rounded-lg bg-white/5 border border-white/10 text-sm focus:outline-none focus:border-cyan-500/50 transition-colors"
                    placeholder="Ex: Projets actifs"
                  />
                </div>
                <div>
                  <label className="block text-xs text-muted-foreground mb-1.5">Valeur KPI</label>
                  <input
                    value={form.kpiValue}
                    onChange={(e) => updateField("kpiValue", e.target.value)}
                    className="w-full px-3 py-2.5 rounded-lg bg-white/5 border border-white/10 text-sm focus:outline-none focus:border-cyan-500/50 transition-colors"
                    placeholder="Ex: 42"
                  />
                </div>
                <div>
                  <label className="block text-xs text-muted-foreground mb-1.5">Tendance</label>
                  <select
                    value={form.kpiTrend}
                    onChange={(e) => updateField("kpiTrend", e.target.value as "up" | "down" | "stable")}
                    className="w-full px-3 py-2.5 rounded-lg bg-white/5 border border-white/10 text-sm focus:outline-none focus:border-cyan-500/50 transition-colors"
                  >
                    <option value="up">En hausse</option>
                    <option value="down">En baisse</option>
                    <option value="stable">Stable</option>
                  </select>
                </div>
              </div>

              {/* Enabled toggle */}
              <div className="flex items-center justify-between p-3 rounded-lg bg-white/[0.02] border border-white/[0.06]">
                <div>
                  <p className="text-sm font-medium">Activer le module</p>
                  <p className="text-[10px] text-muted-foreground">Le module sera visible et accessible sur le tableau de bord</p>
                </div>
                <button
                  onClick={() => updateField("enabled", !form.enabled)}
                  className="flex-shrink-0"
                >
                  {form.enabled ? (
                    <ToggleRight className="h-8 w-8 text-emerald-400" />
                  ) : (
                    <ToggleLeft className="h-8 w-8 text-white/30" />
                  )}
                </button>
              </div>
            </div>

            {/* Form Footer */}
            <div className="flex items-center justify-end gap-3 px-6 py-4 border-t border-white/[0.06] sticky bottom-0 bg-[#0a0e1a]/95 backdrop-blur-xl rounded-b-2xl">
              <button
                onClick={() => setShowForm(false)}
                className="px-4 py-2 rounded-lg text-sm text-white/60 hover:text-white hover:bg-white/5 transition-colors"
              >
                Annuler
              </button>
              <button
                onClick={handleSave}
                disabled={!form.name.trim()}
                className="flex items-center gap-2 px-5 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-sm font-medium transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
              >
                <Save className="h-4 w-4" />
                {editingId ? "Enregistrer" : "Ajouter"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function ModuleRow({
  mod,
  onEdit,
  onDelete,
  onToggle,
  deleteConfirm,
  onDeleteCancel,
  onDeleteConfirm,
}: {
  mod: ModuleConfig;
  onEdit: () => void;
  onDelete: () => void;
  onToggle: () => void;
  deleteConfirm: boolean;
  onDeleteCancel: () => void;
  onDeleteConfirm: () => void;
}) {
  const poleConfig = POLE_CONFIG[mod.pole];
  const typeLabel = mod.type === "react" ? "React" : mod.type === "html" ? "HTML" : "Externe";

  return (
    <div className="flex items-center gap-3 p-3 rounded-lg bg-white/[0.02] hover:bg-white/[0.04] transition-colors group">
      {/* Icon */}
      <div
        className="flex-shrink-0 w-10 h-10 rounded-xl flex items-center justify-center"
        style={{ backgroundColor: `${mod.color}15` }}
      >
        <div style={{ color: mod.color }}>
          {AVAILABLE_ICONS.find((i) => i.value === mod.icon)?.icon || <Layers className="h-5 w-5" />}
        </div>
      </div>

      {/* Info */}
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <span className="text-sm font-medium truncate">{mod.name}</span>
          <span
            className="text-[10px] px-1.5 py-0.5 rounded-full font-medium"
            style={{ backgroundColor: `${mod.color}15`, color: mod.color }}
          >
            {mod.priority}
          </span>
          <span className={cn(
            "text-[10px] px-1.5 py-0.5 rounded-full",
            mod.type === "react" ? "bg-blue-500/10 text-blue-400"
              : mod.type === "html" ? "bg-amber-500/10 text-amber-400"
              : "bg-purple-500/10 text-purple-400"
          )}>
            {typeLabel}
          </span>
        </div>
        <div className="flex items-center gap-2 text-[10px] text-muted-foreground mt-0.5">
          <div className="h-1.5 w-1.5 rounded-full" style={{ backgroundColor: poleConfig.color }} />
          <span>{poleConfig.label}</span>
          {mod.htmlContent ? (
            <>
              <span>&middot;</span>
              <span className="flex items-center gap-1 text-emerald-400">
                <Upload className="h-2.5 w-2.5" />
                {mod.htmlFileName || "fichier.html"}
              </span>
            </>
          ) : mod.externalUrl ? (
            <>
              <span>&middot;</span>
              <span className="font-mono truncate max-w-[200px]">{mod.externalUrl}</span>
            </>
          ) : null}
        </div>
      </div>

      {/* KPI */}
      {mod.kpiLabel && (
        <div className="text-right hidden sm:block">
          <p className="text-xs text-muted-foreground">{mod.kpiLabel}</p>
          <p className="text-sm font-bold" style={{ color: mod.color }}>{mod.kpiValue}</p>
        </div>
      )}

      {/* Actions */}
      {deleteConfirm ? (
        <div className="flex items-center gap-1.5">
          <span className="text-xs text-red-400 mr-1">Supprimer ?</span>
          <button
            onClick={onDeleteConfirm}
            className="px-2.5 py-1 rounded-lg bg-red-500/20 text-red-400 text-xs font-medium hover:bg-red-500/30 transition-colors"
          >
            Oui
          </button>
          <button
            onClick={onDeleteCancel}
            className="px-2.5 py-1 rounded-lg bg-white/5 text-white/60 text-xs hover:bg-white/10 transition-colors"
          >
            Non
          </button>
        </div>
      ) : (
        <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
          <button
            onClick={onToggle}
            title={mod.enabled ? "Desactiver" : "Activer"}
            className="p-1.5 rounded-lg hover:bg-white/5 transition-colors"
          >
            {mod.enabled ? (
              <ToggleRight className="h-4 w-4 text-emerald-400" />
            ) : (
              <ToggleLeft className="h-4 w-4 text-white/30" />
            )}
          </button>
          <button
            onClick={onEdit}
            title="Modifier"
            className="p-1.5 rounded-lg hover:bg-white/5 text-white/40 hover:text-cyan-400 transition-colors"
          >
            <Pencil className="h-4 w-4" />
          </button>
          <button
            onClick={onDelete}
            title="Supprimer"
            className="p-1.5 rounded-lg hover:bg-red-500/10 text-white/40 hover:text-red-400 transition-colors"
          >
            <Trash2 className="h-4 w-4" />
          </button>
        </div>
      )}
    </div>
  );
}
