"use client";

import { useState } from "react";
import { useRoleStore, type RoleConfig } from "@/stores/role-store";
import { useModuleStore } from "@/stores/module-store";
import { type Pole, type Permission, type ModuleId, POLE_CONFIG } from "@/types";
import { GlassPanel } from "@/components/shared/glass-panel";
import { cn } from "@/lib/utils";
import {
  Plus, Pencil, Trash2, X, Save, Shield,
  ChevronDown, ChevronRight,
} from "lucide-react";

interface RoleFormData {
  id: string;
  label: string;
  poles: (Pole | "tous")[];
}

const EMPTY_FORM: RoleFormData = {
  id: "",
  label: "",
  poles: ["operations"],
};

export function RoleManager() {
  const { roles, addRole, updateRole, deleteRole, setModulePermission, removeModulePermission } = useRoleStore();
  const { modules } = useModuleStore();
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState<RoleFormData>(EMPTY_FORM);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const [expandedRole, setExpandedRole] = useState<string | null>(null);

  const allModuleIds = [...new Set(modules.map((m) => m.id))];

  const openAddForm = () => {
    setForm(EMPTY_FORM);
    setEditingId(null);
    setShowForm(true);
  };

  const openEditForm = (role: RoleConfig) => {
    setForm({
      id: role.id,
      label: role.label,
      poles: [...role.poles],
    });
    setEditingId(role.id);
    setShowForm(true);
  };

  const handleSave = () => {
    if (editingId) {
      updateRole(editingId, { label: form.label, poles: form.poles });
    } else {
      const roleId = form.id || form.label.toLowerCase().replace(/\s+/g, "_").replace(/[^a-z0-9_]/g, "");
      addRole({
        id: roleId,
        label: form.label,
        poles: form.poles,
        modules: {},
      });
    }
    setShowForm(false);
    setEditingId(null);
  };

  const handleDelete = (id: string) => {
    deleteRole(id);
    setDeleteConfirm(null);
    if (expandedRole === id) setExpandedRole(null);
  };

  const togglePole = (pole: Pole | "tous") => {
    setForm((prev) => {
      if (pole === "tous") {
        return { ...prev, poles: ["tous"] };
      }
      const withoutTous = prev.poles.filter((p) => p !== "tous");
      if (withoutTous.includes(pole)) {
        const filtered = withoutTous.filter((p) => p !== pole);
        return { ...prev, poles: filtered.length > 0 ? filtered : ["operations"] };
      }
      return { ...prev, poles: [...withoutTous, pole] };
    });
  };

  const cyclePermission = (roleId: string, moduleId: ModuleId, currentPerms: Permission[]) => {
    const hasRead = currentPerms.includes("read");
    const hasWrite = currentPerms.includes("write");
    const hasAdmin = currentPerms.includes("admin");

    if (!hasRead && !hasWrite && !hasAdmin) {
      // none -> read
      setModulePermission(roleId, moduleId, ["read"]);
    } else if (hasRead && !hasWrite && !hasAdmin) {
      // read -> read+write
      setModulePermission(roleId, moduleId, ["read", "write"]);
    } else if (hasRead && hasWrite && !hasAdmin) {
      // read+write -> read+write+admin
      setModulePermission(roleId, moduleId, ["read", "write", "admin"]);
    } else {
      // admin -> none
      removeModulePermission(roleId, moduleId);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h3 className="font-semibold flex items-center gap-2">
          <Shield className="h-4 w-4 text-amber-400" />
          Gestion des Roles ({roles.length})
        </h3>
        <button
          onClick={openAddForm}
          className="flex items-center gap-2 px-4 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-sm font-medium transition-colors"
        >
          <Plus className="h-4 w-4" />
          Ajouter un role
        </button>
      </div>

      {/* Roles List */}
      <GlassPanel animate={false}>
        <h4 className="text-sm font-semibold mb-3 flex items-center gap-2">
          <Shield className="h-3.5 w-3.5 text-amber-400" />
          Matrice des Permissions
          <span className="text-[10px] text-muted-foreground font-normal ml-2">
            Cliquez sur un role pour editer ses permissions &middot; Cliquez sur une cellule pour changer le niveau
          </span>
        </h4>

        <div className="space-y-1">
          {roles.map((role) => {
            const isExpanded = expandedRole === role.id;
            const moduleCount = Object.keys(role.modules).filter(
              (m) => (role.modules[m as ModuleId]?.length ?? 0) > 0
            ).length;

            return (
              <div key={role.id} className="rounded-xl overflow-hidden">
                {/* Role Header Row */}
                <div className="flex items-center gap-3 p-3 bg-white/[0.02] hover:bg-white/[0.04] transition-colors group">
                  <button
                    onClick={() => setExpandedRole(isExpanded ? null : role.id)}
                    className="p-1 rounded hover:bg-white/5 transition-colors"
                  >
                    {isExpanded ? (
                      <ChevronDown className="h-4 w-4 text-white/60" />
                    ) : (
                      <ChevronRight className="h-4 w-4 text-white/40" />
                    )}
                  </button>

                  <div className="flex-1 min-w-0 cursor-pointer" onClick={() => setExpandedRole(isExpanded ? null : role.id)}>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium">{role.label}</span>
                      <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-white/5 text-muted-foreground font-mono">
                        {role.id}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 mt-0.5">
                      {role.poles.map((p) => (
                        <span key={p} className="text-[10px] text-muted-foreground flex items-center gap-1">
                          {p === "tous" ? (
                            <span className="text-cyan-400">Tous les poles</span>
                          ) : (
                            <>
                              <span className="h-1.5 w-1.5 rounded-full inline-block" style={{ backgroundColor: POLE_CONFIG[p].color }} />
                              {POLE_CONFIG[p].label}
                            </>
                          )}
                        </span>
                      ))}
                      <span className="text-[10px] text-muted-foreground">&middot; {moduleCount} module{moduleCount !== 1 ? "s" : ""}</span>
                    </div>
                  </div>

                  {/* Actions */}
                  {deleteConfirm === role.id ? (
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs text-red-400 mr-1">Supprimer ?</span>
                      <button
                        onClick={() => handleDelete(role.id)}
                        className="px-2.5 py-1 rounded-lg bg-red-500/20 text-red-400 text-xs font-medium hover:bg-red-500/30 transition-colors"
                      >
                        Oui
                      </button>
                      <button
                        onClick={() => setDeleteConfirm(null)}
                        className="px-2.5 py-1 rounded-lg bg-white/5 text-white/60 text-xs hover:bg-white/10 transition-colors"
                      >
                        Non
                      </button>
                    </div>
                  ) : (
                    <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button
                        onClick={() => openEditForm(role)}
                        title="Modifier"
                        className="p-1.5 rounded-lg hover:bg-white/5 text-white/40 hover:text-cyan-400 transition-colors"
                      >
                        <Pencil className="h-4 w-4" />
                      </button>
                      <button
                        onClick={() => setDeleteConfirm(role.id)}
                        title="Supprimer"
                        className="p-1.5 rounded-lg hover:bg-red-500/10 text-white/40 hover:text-red-400 transition-colors"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  )}
                </div>

                {/* Expanded Permissions Grid */}
                {isExpanded && (
                  <div className="px-4 pb-3 bg-white/[0.01] border-t border-white/[0.04]">
                    <div className="pt-3 overflow-x-auto">
                      <div className="grid gap-2" style={{ gridTemplateColumns: `repeat(${Math.min(allModuleIds.length, 5)}, minmax(120px, 1fr))` }}>
                        {allModuleIds.map((modId) => {
                          const mod = modules.find((m) => m.id === modId);
                          const perms = role.modules[modId] ?? [];
                          const hasRead = perms.includes("read");
                          const hasWrite = perms.includes("write");
                          const hasAdmin = perms.includes("admin");

                          let permLabel = "—";
                          let permColor = "text-zinc-600 bg-white/[0.02] border-white/[0.04]";
                          if (hasAdmin) {
                            permLabel = "Admin";
                            permColor = "text-amber-400 bg-amber-500/10 border-amber-500/20";
                          } else if (hasWrite) {
                            permLabel = "Lecture / Ecriture";
                            permColor = "text-cyan-400 bg-cyan-500/10 border-cyan-500/20";
                          } else if (hasRead) {
                            permLabel = "Lecture seule";
                            permColor = "text-emerald-400 bg-emerald-500/10 border-emerald-500/20";
                          }

                          return (
                            <button
                              key={modId}
                              onClick={() => cyclePermission(role.id, modId, perms)}
                              className={cn(
                                "p-2.5 rounded-lg border text-left transition-all hover:scale-[1.02]",
                                permColor
                              )}
                              title="Cliquer pour changer le niveau de permission"
                            >
                              <p className="text-[10px] text-muted-foreground truncate mb-1">
                                {mod?.name || modId}
                              </p>
                              <p className="text-xs font-medium">{permLabel}</p>
                            </button>
                          );
                        })}
                      </div>
                      <p className="text-[10px] text-muted-foreground mt-2">
                        Cycle : — &rarr; Lecture &rarr; Lecture/Ecriture &rarr; Admin &rarr; —
                      </p>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </GlassPanel>

      {/* Modal Form */}
      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setShowForm(false)} />
          <div className="relative w-full max-w-lg glass rounded-2xl border border-white/10 shadow-2xl">
            {/* Form Header */}
            <div className="flex items-center justify-between px-6 py-4 border-b border-white/[0.06]">
              <h3 className="font-semibold text-lg">
                {editingId ? "Modifier le role" : "Ajouter un nouveau role"}
              </h3>
              <button onClick={() => setShowForm(false)} className="p-2 rounded-lg hover:bg-white/5">
                <X className="h-5 w-5 text-white/60" />
              </button>
            </div>

            {/* Form Body */}
            <div className="px-6 py-5 space-y-5">
              {/* Label */}
              <div>
                <label className="block text-xs text-muted-foreground mb-1.5">Nom du role *</label>
                <input
                  value={form.label}
                  onChange={(e) => setForm((prev) => ({ ...prev, label: e.target.value }))}
                  className="w-full px-3 py-2.5 rounded-lg bg-white/5 border border-white/10 text-sm focus:outline-none focus:border-cyan-500/50 transition-colors"
                  placeholder="Ex: Responsable Qualite"
                />
              </div>

              {/* ID (only for new) */}
              {!editingId && (
                <div>
                  <label className="block text-xs text-muted-foreground mb-1.5">Identifiant technique</label>
                  <input
                    value={form.id}
                    onChange={(e) => setForm((prev) => ({ ...prev, id: e.target.value }))}
                    className="w-full px-3 py-2.5 rounded-lg bg-white/5 border border-white/10 text-sm focus:outline-none focus:border-cyan-500/50 transition-colors font-mono"
                    placeholder="Auto-genere si vide (ex: resp_qualite)"
                  />
                </div>
              )}

              {/* Poles */}
              <div>
                <label className="block text-xs text-muted-foreground mb-2">Poles associes *</label>
                <div className="flex flex-wrap gap-2">
                  <button
                    onClick={() => togglePole("tous")}
                    className={cn(
                      "px-3 py-1.5 rounded-lg text-xs font-medium border transition-all",
                      form.poles.includes("tous")
                        ? "border-cyan-500/50 bg-cyan-500/10 text-cyan-400"
                        : "border-white/10 bg-white/[0.02] text-white/50 hover:bg-white/[0.04]"
                    )}
                  >
                    Tous les poles
                  </button>
                  {Object.entries(POLE_CONFIG).map(([key, cfg]) => (
                    <button
                      key={key}
                      onClick={() => togglePole(key as Pole)}
                      className={cn(
                        "px-3 py-1.5 rounded-lg text-xs font-medium border transition-all flex items-center gap-1.5",
                        form.poles.includes(key as Pole) && !form.poles.includes("tous")
                          ? "border-cyan-500/50 bg-cyan-500/10 text-cyan-400"
                          : "border-white/10 bg-white/[0.02] text-white/50 hover:bg-white/[0.04]"
                      )}
                    >
                      <span className="h-2 w-2 rounded-full" style={{ backgroundColor: cfg.color }} />
                      {cfg.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Form Footer */}
            <div className="flex items-center justify-end gap-3 px-6 py-4 border-t border-white/[0.06]">
              <button
                onClick={() => setShowForm(false)}
                className="px-4 py-2 rounded-lg text-sm text-white/60 hover:text-white hover:bg-white/5 transition-colors"
              >
                Annuler
              </button>
              <button
                onClick={handleSave}
                disabled={!form.label.trim()}
                className="flex items-center gap-2 px-5 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-sm font-medium transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
              >
                <Save className="h-4 w-4" />
                {editingId ? "Enregistrer" : "Ajouter"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
