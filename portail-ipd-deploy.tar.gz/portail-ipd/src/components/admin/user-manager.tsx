"use client";

import { useState } from "react";
import { useUserStore, type AdminUser } from "@/stores/user-store";
import { useAuthStore } from "@/stores/auth-store";
import { useRoleStore } from "@/stores/role-store";
import { type Pole, type RoleName, POLE_CONFIG } from "@/types";
import { GlassPanel } from "@/components/shared/glass-panel";
import { cn } from "@/lib/utils";
import { hashPassword, generateStrongPassword } from "@/lib/security/password";
import { logAuditAction } from "@/lib/security/audit";
import {
  Plus, Pencil, Trash2, X, Save, Users,
  CheckCircle, XCircle, ToggleLeft, ToggleRight,
  Mail, Building, Briefcase, KeyRound, Copy, Check, RefreshCw, ShieldAlert,
} from "lucide-react";

interface UserFormData {
  firstName: string;
  lastName: string;
  email: string;
  role: RoleName;
  pole: Pole | "tous";
  department: string;          // Service / cellule
  direction: string;           // Direction de rattachement
  title: string;               // Fonction
  phone: string;
  isActive: boolean;
  mfaEnabled: boolean;
}

const EMPTY_FORM: UserFormData = {
  firstName: "",
  lastName: "",
  email: "",
  role: "utilisateur",
  pole: "operations",
  department: "",
  direction: "",
  title: "",
  phone: "",
  isActive: true,
  mfaEnabled: false,
};

export function UserManager() {
  const { users, addUser, updateUser, deleteUser, toggleUserActive, resetPassword } = useUserStore();
  const { roles } = useRoleStore();
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState<UserFormData>(EMPTY_FORM);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);

  // Credentials modal state
  const [credentialsModal, setCredentialsModal] = useState<{
    show: boolean;
    type: "created" | "reset";
    userName: string;
    email: string;
    password: string;
  } | null>(null);

  const openAddForm = () => {
    setForm(EMPTY_FORM);
    setEditingId(null);
    setShowForm(true);
  };

  const openEditForm = (user: AdminUser) => {
    setForm({
      firstName: user.firstName,
      lastName: user.lastName,
      email: user.email,
      role: user.role,
      pole: user.pole,
      department: user.department,
      direction: (user as { direction?: string | null }).direction ?? "",
      title: user.title,
      phone: (user as { phone?: string | null }).phone ?? "",
      isActive: user.isActive,
      mfaEnabled: user.mfaEnabled,
    });
    setEditingId(user.id);
    setShowForm(true);
  };

  const handleSave = async () => {
    const session = useAuthStore.getState().session;
    const adminName = session ? `${session.user.firstName} ${session.user.lastName}` : "Admin";
    const adminId = session?.user.id || "unknown";

    if (editingId) {
      await updateUser(editingId, { ...form });
      logAuditAction(adminId, adminName, "update", "admin", `Modification utilisateur: ${form.firstName} ${form.lastName}`);
      setShowForm(false);
      setEditingId(null);
    } else {
      const plainPassword = generateStrongPassword();
      const hash = await hashPassword(plainPassword);
      const newUser: AdminUser = { id: `usr-${Date.now()}`, ...form };
      addUser(newUser, hash);
      logAuditAction(adminId, adminName, "create", "admin", `Creation utilisateur: ${form.firstName} ${form.lastName} (${form.email})`);
      setShowForm(false);
      setEditingId(null);

      setCredentialsModal({
        show: true,
        type: "created",
        userName: `${form.firstName} ${form.lastName}`,
        email: form.email,
        password: plainPassword,
      });
    }
  };

  const handleResetPassword = async (user: AdminUser) => {
    const result = await resetPassword(user.id);
    const session = useAuthStore.getState().session;
    const adminName = session ? `${session.user.firstName} ${session.user.lastName}` : "Admin";
    logAuditAction(session?.user.id || "unknown", adminName, "update", "admin", `Reinitialisation mot de passe: ${user.firstName} ${user.lastName}`);
    setCredentialsModal({
      show: true,
      type: "reset",
      userName: `${user.firstName} ${user.lastName}`,
      email: user.email,
      password: result.plainPassword,
    });
  };

  const handleDelete = (id: string) => {
    deleteUser(id);
    setDeleteConfirm(null);
  };

  const updateField = <K extends keyof UserFormData>(field: K, value: UserFormData[K]) => {
    setForm((prev) => ({ ...prev, [field]: value }));
  };

  const activeUsers = users.filter((u) => u.isActive);
  const inactiveUsers = users.filter((u) => !u.isActive);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h3 className="font-semibold flex items-center gap-2">
          <Users className="h-4 w-4 text-amber-400" />
          Gestion des Utilisateurs ({users.length})
        </h3>
        <button
          onClick={openAddForm}
          className="flex items-center gap-2 px-4 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-sm font-medium transition-colors"
        >
          <Plus className="h-4 w-4" />
          Ajouter un utilisateur
        </button>
      </div>

      {/* Active Users */}
      <GlassPanel animate={false}>
        <h4 className="text-sm font-semibold mb-3 text-emerald-400">
          Utilisateurs actifs ({activeUsers.length})
        </h4>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr style={{ borderBottom: "1px solid var(--surface-border)" }}>
                <th className="text-left py-3 text-xs text-muted-foreground font-medium">Utilisateur</th>
                <th className="text-left py-3 text-xs text-muted-foreground font-medium">Role</th>
                <th className="text-left py-3 text-xs text-muted-foreground font-medium">Pole</th>
                <th className="text-left py-3 text-xs text-muted-foreground font-medium hidden md:table-cell">Departement</th>
                <th className="text-center py-3 text-xs text-muted-foreground font-medium hidden sm:table-cell">MFA</th>
                <th className="text-right py-3 text-xs text-muted-foreground font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {activeUsers.map((user) => (
                <UserRow
                  key={user.id}
                  user={user}
                  roles={roles}
                  onEdit={() => openEditForm(user)}
                  onDelete={() => setDeleteConfirm(user.id)}
                  onToggle={() => toggleUserActive(user.id)}
                  onResetPassword={() => handleResetPassword(user)}
                  deleteConfirm={deleteConfirm === user.id}
                  onDeleteCancel={() => setDeleteConfirm(null)}
                  onDeleteConfirm={() => handleDelete(user.id)}
                />
              ))}
              {activeUsers.length === 0 && (
                <tr>
                  <td colSpan={6} className="text-center py-8 text-muted-foreground text-sm">
                    Aucun utilisateur actif
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </GlassPanel>

      {/* Inactive Users */}
      {inactiveUsers.length > 0 && (
        <GlassPanel animate={false}>
          <h4 className="text-sm font-semibold mb-3 text-muted-foreground">
            Utilisateurs inactifs ({inactiveUsers.length})
          </h4>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr style={{ borderBottom: "1px solid var(--surface-border)" }}>
                  <th className="text-left py-3 text-xs text-muted-foreground font-medium">Utilisateur</th>
                  <th className="text-left py-3 text-xs text-muted-foreground font-medium">Role</th>
                  <th className="text-left py-3 text-xs text-muted-foreground font-medium">Pole</th>
                  <th className="text-left py-3 text-xs text-muted-foreground font-medium hidden md:table-cell">Departement</th>
                  <th className="text-center py-3 text-xs text-muted-foreground font-medium hidden sm:table-cell">MFA</th>
                  <th className="text-right py-3 text-xs text-muted-foreground font-medium">Actions</th>
                </tr>
              </thead>
              <tbody>
                {inactiveUsers.map((user) => (
                  <UserRow
                    key={user.id}
                    user={user}
                    roles={roles}
                    onEdit={() => openEditForm(user)}
                    onDelete={() => setDeleteConfirm(user.id)}
                    onToggle={() => toggleUserActive(user.id)}
                    onResetPassword={() => handleResetPassword(user)}
                    deleteConfirm={deleteConfirm === user.id}
                    onDeleteCancel={() => setDeleteConfirm(null)}
                    onDeleteConfirm={() => handleDelete(user.id)}
                  />
                ))}
              </tbody>
            </table>
          </div>
        </GlassPanel>
      )}

      {/* Modal: User Form */}
      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setShowForm(false)} />
          <div
            className="relative w-full max-w-2xl max-h-[90vh] overflow-y-auto glass rounded-2xl shadow-2xl"
            style={{ border: "1px solid var(--surface-border)" }}
          >
            {/* Form Header */}
            <div
              className="flex items-center justify-between px-6 py-4 sticky top-0 backdrop-blur-xl rounded-t-2xl z-10"
              style={{
                borderBottom: "1px solid var(--surface-border)",
                backgroundColor: "var(--surface-header)",
              }}
            >
              <h3 className="font-semibold text-lg">
                {editingId ? "Modifier l'utilisateur" : "Ajouter un nouvel utilisateur"}
              </h3>
              <button
                onClick={() => setShowForm(false)}
                className="p-2 rounded-lg hover:bg-[var(--surface-hover)] transition-colors"
              >
                <X className="h-5 w-5" style={{ color: "var(--surface-text-secondary)" }} />
              </button>
            </div>

            {/* Form Body */}
            <div className="px-6 py-5 space-y-5">
              {/* Info banner for new users */}
              {!editingId && (
                <div className="flex items-start gap-3 p-3 rounded-lg bg-cyan-500/10 border border-cyan-500/20">
                  <KeyRound className="h-5 w-5 text-cyan-400 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-cyan-400">Mot de passe automatique</p>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      Un mot de passe temporaire sera genere automatiquement et affiche apres la creation du compte.
                    </p>
                  </div>
                </div>
              )}

              {/* Nom + Prenom */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs text-muted-foreground mb-1.5">Prenom *</label>
                  <input
                    value={form.firstName}
                    onChange={(e) => updateField("firstName", e.target.value)}
                    className="w-full px-3 py-2.5 rounded-lg text-sm focus:outline-none focus:border-cyan-500/50 transition-colors"
                    style={{
                      backgroundColor: "var(--surface-input-bg)",
                      border: "1px solid var(--surface-input-border)",
                      color: "var(--surface-input-text)",
                    }}
                    placeholder="Ex: Amadou"
                  />
                </div>
                <div>
                  <label className="block text-xs text-muted-foreground mb-1.5">Nom *</label>
                  <input
                    value={form.lastName}
                    onChange={(e) => updateField("lastName", e.target.value)}
                    className="w-full px-3 py-2.5 rounded-lg text-sm focus:outline-none focus:border-cyan-500/50 transition-colors"
                    style={{
                      backgroundColor: "var(--surface-input-bg)",
                      border: "1px solid var(--surface-input-border)",
                      color: "var(--surface-input-text)",
                    }}
                    placeholder="Ex: Diallo"
                  />
                </div>
              </div>

              {/* Email */}
              <div>
                <label className="block text-xs text-muted-foreground mb-1.5">
                  <Mail className="h-3 w-3 inline mr-1" />
                  Adresse e-mail *
                </label>
                <input
                  value={form.email}
                  onChange={(e) => updateField("email", e.target.value)}
                  type="email"
                  className="w-full px-3 py-2.5 rounded-lg text-sm focus:outline-none focus:border-cyan-500/50 transition-colors font-mono"
                  style={{
                    backgroundColor: "var(--surface-input-bg)",
                    border: "1px solid var(--surface-input-border)",
                    color: "var(--surface-input-text)",
                  }}
                  placeholder="prenom.nom@pasteur.sn"
                />
              </div>

              {/* Role + Pole */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs text-muted-foreground mb-1.5">Role *</label>
                  <select
                    value={form.role}
                    onChange={(e) => updateField("role", e.target.value as RoleName)}
                    className="w-full px-3 py-2.5 rounded-lg text-sm focus:outline-none focus:border-cyan-500/50 transition-colors"
                    style={{
                      backgroundColor: "var(--surface-input-bg)",
                      border: "1px solid var(--surface-input-border)",
                      color: "var(--surface-input-text)",
                    }}
                  >
                    {roles.map((r) => (
                      <option key={r.id} value={r.id}>{r.label}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs text-muted-foreground mb-1.5">Pole *</label>
                  <select
                    value={form.pole}
                    onChange={(e) => updateField("pole", e.target.value as Pole | "tous")}
                    className="w-full px-3 py-2.5 rounded-lg text-sm focus:outline-none focus:border-cyan-500/50 transition-colors"
                    style={{
                      backgroundColor: "var(--surface-input-bg)",
                      border: "1px solid var(--surface-input-border)",
                      color: "var(--surface-input-text)",
                    }}
                  >
                    <option value="tous">Tous les poles</option>
                    {Object.entries(POLE_CONFIG).map(([key, cfg]) => (
                      <option key={key} value={key}>{cfg.label}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Service + Direction */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs text-muted-foreground mb-1.5">
                    <Building className="h-3 w-3 inline mr-1" />
                    Service / Cellule
                  </label>
                  <input
                    value={form.department}
                    onChange={(e) => updateField("department", e.target.value)}
                    className="w-full px-3 py-2.5 rounded-lg text-sm focus:outline-none focus:border-cyan-500/50 transition-colors"
                    style={{
                      backgroundColor: "var(--surface-input-bg)",
                      border: "1px solid var(--surface-input-border)",
                      color: "var(--surface-input-text)",
                    }}
                    placeholder="Ex: DAF, DRH, Cellule SEID"
                  />
                </div>
                <div>
                  <label className="block text-xs text-muted-foreground mb-1.5">
                    <Building className="h-3 w-3 inline mr-1" />
                    Direction de rattachement
                  </label>
                  <input
                    value={form.direction}
                    onChange={(e) => updateField("direction", e.target.value)}
                    className="w-full px-3 py-2.5 rounded-lg text-sm focus:outline-none focus:border-cyan-500/50 transition-colors"
                    style={{
                      backgroundColor: "var(--surface-input-bg)",
                      border: "1px solid var(--surface-input-border)",
                      color: "var(--surface-input-text)",
                    }}
                    placeholder="Ex: DG, DRO, DPC"
                  />
                </div>
              </div>

              {/* Fonction + Telephone */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs text-muted-foreground mb-1.5">
                    <Briefcase className="h-3 w-3 inline mr-1" />
                    Fonction / Titre
                  </label>
                  <input
                    value={form.title}
                    onChange={(e) => updateField("title", e.target.value)}
                    className="w-full px-3 py-2.5 rounded-lg text-sm focus:outline-none focus:border-cyan-500/50 transition-colors"
                    style={{
                      backgroundColor: "var(--surface-input-bg)",
                      border: "1px solid var(--surface-input-border)",
                      color: "var(--surface-input-text)",
                    }}
                    placeholder="Ex: Chargee de projet, Directeur"
                  />
                </div>
                <div>
                  <label className="block text-xs text-muted-foreground mb-1.5">
                    Telephone professionnel
                  </label>
                  <input
                    value={form.phone}
                    onChange={(e) => updateField("phone", e.target.value)}
                    className="w-full px-3 py-2.5 rounded-lg text-sm focus:outline-none focus:border-cyan-500/50 transition-colors"
                    style={{
                      backgroundColor: "var(--surface-input-bg)",
                      border: "1px solid var(--surface-input-border)",
                      color: "var(--surface-input-text)",
                    }}
                    placeholder="+221 33 XX XX XX"
                  />
                </div>
              </div>

              {/* Toggles: Active + MFA */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div
                  className="flex items-center justify-between p-3 rounded-lg"
                  style={{
                    backgroundColor: "var(--surface-input-bg)",
                    border: "1px solid var(--surface-border)",
                  }}
                >
                  <div>
                    <p className="text-sm font-medium">Compte actif</p>
                    <p className="text-[10px] text-muted-foreground">L&apos;utilisateur peut se connecter</p>
                  </div>
                  <button onClick={() => updateField("isActive", !form.isActive)} className="flex-shrink-0">
                    {form.isActive ? (
                      <ToggleRight className="h-8 w-8 text-emerald-400" />
                    ) : (
                      <ToggleLeft className="h-8 w-8 text-muted-foreground" />
                    )}
                  </button>
                </div>
                <div
                  className="flex items-center justify-between p-3 rounded-lg"
                  style={{
                    backgroundColor: "var(--surface-input-bg)",
                    border: "1px solid var(--surface-border)",
                  }}
                >
                  <div>
                    <p className="text-sm font-medium">MFA active</p>
                    <p className="text-[10px] text-muted-foreground">Authentification multi-facteurs</p>
                  </div>
                  <button onClick={() => updateField("mfaEnabled", !form.mfaEnabled)} className="flex-shrink-0">
                    {form.mfaEnabled ? (
                      <ToggleRight className="h-8 w-8 text-emerald-400" />
                    ) : (
                      <ToggleLeft className="h-8 w-8 text-muted-foreground" />
                    )}
                  </button>
                </div>
              </div>
            </div>

            {/* Form Footer */}
            <div
              className="flex items-center justify-end gap-3 px-6 py-4 sticky bottom-0 backdrop-blur-xl rounded-b-2xl"
              style={{
                borderTop: "1px solid var(--surface-border)",
                backgroundColor: "var(--surface-header)",
              }}
            >
              <button
                onClick={() => setShowForm(false)}
                className="px-4 py-2 rounded-lg text-sm hover:bg-[var(--surface-hover)] transition-colors"
                style={{ color: "var(--surface-text-secondary)" }}
              >
                Annuler
              </button>
              <button
                onClick={handleSave}
                disabled={!form.firstName.trim() || !form.lastName.trim() || !form.email.trim()}
                className="flex items-center gap-2 px-5 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-sm font-medium transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
              >
                <Save className="h-4 w-4" />
                {editingId ? "Enregistrer" : "Creer le compte"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Credentials Display */}
      {credentialsModal?.show && (
        <CredentialsModal
          type={credentialsModal.type}
          userName={credentialsModal.userName}
          email={credentialsModal.email}
          password={credentialsModal.password}
          onClose={() => setCredentialsModal(null)}
        />
      )}
    </div>
  );
}

/** Modal that shows generated/reset credentials */
function CredentialsModal({
  type,
  userName,
  email,
  password,
  onClose,
}: {
  type: "created" | "reset";
  userName: string;
  email: string;
  password: string;
  onClose: () => void;
}) {
  const [copied, setCopied] = useState<"email" | "password" | "all" | null>(null);

  const copyToClipboard = async (text: string, field: "email" | "password" | "all") => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(field);
      setTimeout(() => setCopied(null), 2000);
    } catch {
      // Fallback
    }
  };

  const copyAll = () => {
    const text = `Identifiants ${userName}\nEmail: ${email}\nMot de passe: ${password}`;
    copyToClipboard(text, "all");
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={onClose} />
      <div
        className="relative w-full max-w-md glass rounded-2xl shadow-2xl overflow-hidden"
        style={{ border: "1px solid var(--surface-border)" }}
      >
        {/* Header */}
        <div
          className="px-6 py-4 text-center"
          style={{
            borderBottom: "1px solid var(--surface-border)",
            backgroundColor: type === "created" ? "rgba(6, 182, 212, 0.08)" : "rgba(245, 158, 11, 0.08)",
          }}
        >
          <div
            className="inline-flex items-center justify-center w-12 h-12 rounded-xl mb-3"
            style={{
              backgroundColor: type === "created" ? "rgba(6, 182, 212, 0.15)" : "rgba(245, 158, 11, 0.15)",
            }}
          >
            <KeyRound
              className="h-6 w-6"
              style={{ color: type === "created" ? "#06b6d4" : "#f59e0b" }}
            />
          </div>
          <h3 className="font-semibold text-lg">
            {type === "created" ? "Compte cree avec succes" : "Mot de passe reinitialise"}
          </h3>
          <p className="text-xs text-muted-foreground mt-1">
            {type === "created"
              ? `Le compte de ${userName} a ete cree. Voici ses identifiants de connexion.`
              : `Le mot de passe de ${userName} a ete reinitialise.`}
          </p>
        </div>

        {/* Credentials */}
        <div className="px-6 py-5 space-y-4">
          {/* Warning */}
          <div className="flex items-start gap-2 p-3 rounded-lg bg-amber-500/10 border border-amber-500/20">
            <span className="text-amber-400 text-sm mt-0.5">&#9888;</span>
            <p className="text-xs text-amber-300/80">
              Ces identifiants ne seront affiches qu&apos;une seule fois. Copiez-les et transmettez-les de maniere securisee a l&apos;utilisateur.
            </p>
          </div>

          {/* Email field */}
          <div>
            <label className="block text-xs text-muted-foreground mb-1.5">Adresse e-mail</label>
            <div
              className="flex items-center gap-2 px-3 py-2.5 rounded-lg font-mono text-sm"
              style={{
                backgroundColor: "var(--surface-input-bg)",
                border: "1px solid var(--surface-border)",
              }}
            >
              <Mail className="h-4 w-4 text-muted-foreground flex-shrink-0" />
              <span className="flex-1 select-all">{email}</span>
              <button
                onClick={() => copyToClipboard(email, "email")}
                className="p-1 rounded hover:bg-[var(--surface-hover)] transition-colors flex-shrink-0"
                title="Copier"
              >
                {copied === "email" ? (
                  <Check className="h-4 w-4 text-emerald-400" />
                ) : (
                  <Copy className="h-4 w-4 text-muted-foreground" />
                )}
              </button>
            </div>
          </div>

          {/* Password field */}
          <div>
            <label className="block text-xs text-muted-foreground mb-1.5">Mot de passe temporaire</label>
            <div
              className="flex items-center gap-2 px-3 py-2.5 rounded-lg font-mono text-sm"
              style={{
                backgroundColor: "var(--surface-input-bg)",
                border: "1px solid var(--surface-border)",
              }}
            >
              <KeyRound className="h-4 w-4 text-cyan-400 flex-shrink-0" />
              <span className="flex-1 select-all text-cyan-400 font-bold tracking-wide">{password}</span>
              <button
                onClick={() => copyToClipboard(password, "password")}
                className="p-1 rounded hover:bg-[var(--surface-hover)] transition-colors flex-shrink-0"
                title="Copier"
              >
                {copied === "password" ? (
                  <Check className="h-4 w-4 text-emerald-400" />
                ) : (
                  <Copy className="h-4 w-4 text-muted-foreground" />
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div
          className="flex items-center justify-between px-6 py-4"
          style={{ borderTop: "1px solid var(--surface-border)" }}
        >
          <button
            onClick={copyAll}
            className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm hover:bg-[var(--surface-hover)] transition-colors"
            style={{ color: "var(--surface-text-secondary)" }}
          >
            {copied === "all" ? (
              <>
                <Check className="h-4 w-4 text-emerald-400" />
                <span className="text-emerald-400">Copie !</span>
              </>
            ) : (
              <>
                <Copy className="h-4 w-4" />
                Tout copier
              </>
            )}
          </button>
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-sm font-medium transition-colors"
          >
            Compris
          </button>
        </div>
      </div>
    </div>
  );
}

function UserRow({
  user,
  roles,
  onEdit,
  onDelete,
  onToggle,
  onResetPassword,
  deleteConfirm,
  onDeleteCancel,
  onDeleteConfirm,
}: {
  user: AdminUser;
  roles: { id: string; label: string }[];
  onEdit: () => void;
  onDelete: () => void;
  onToggle: () => void;
  onResetPassword: () => void;
  deleteConfirm: boolean;
  onDeleteCancel: () => void;
  onDeleteConfirm: () => void;
}) {
  const poleConfig = user.pole !== "tous" ? POLE_CONFIG[user.pole] : null;
  const roleLabel = roles.find((r) => r.id === user.role)?.label || user.role;

  return (
    <tr
      className="hover:bg-[var(--surface-hover)] transition-colors group"
      style={{ borderBottom: "1px solid var(--surface-border)" }}
    >
      <td className="py-3">
        <div className="flex items-center gap-3">
          <div className="h-8 w-8 rounded-lg bg-cyan-500/20 flex items-center justify-center text-xs font-bold text-cyan-400 flex-shrink-0">
            {user.firstName[0]}{user.lastName[0]}
          </div>
          <div className="min-w-0">
            <p className="font-medium text-sm truncate">{user.firstName} {user.lastName}</p>
            <p className="text-[10px] text-muted-foreground truncate">{user.email}</p>
          </div>
        </div>
      </td>
      <td className="py-3">
        <span
          className="text-xs px-2 py-1 rounded-full"
          style={{ backgroundColor: "var(--surface-hover)" }}
        >
          {roleLabel}
        </span>
      </td>
      <td className="py-3">
        {poleConfig ? (
          <div className="flex items-center gap-1.5">
            <div className="h-2 w-2 rounded-full flex-shrink-0" style={{ backgroundColor: poleConfig.color }} />
            <span className="text-xs">{poleConfig.label}</span>
          </div>
        ) : (
          <span className="text-xs text-cyan-400">Tous les poles</span>
        )}
      </td>
      <td className="py-3 text-xs text-muted-foreground hidden md:table-cell">{user.department}</td>
      <td className="py-3 text-center hidden sm:table-cell">
        {user.mfaEnabled ? (
          <CheckCircle className="h-4 w-4 text-emerald-400 mx-auto" />
        ) : (
          <XCircle className="h-4 w-4 text-zinc-500 mx-auto" />
        )}
      </td>
      <td className="py-3">
        {deleteConfirm ? (
          <div className="flex items-center justify-end gap-1.5">
            <span className="text-xs text-red-400 mr-1">Supprimer ?</span>
            <button
              onClick={onDeleteConfirm}
              className="px-2.5 py-1 rounded-lg bg-red-500/20 text-red-400 text-xs font-medium hover:bg-red-500/30 transition-colors"
            >
              Oui
            </button>
            <button
              onClick={onDeleteCancel}
              className="px-2.5 py-1 rounded-lg text-xs hover:bg-[var(--surface-hover)] transition-colors"
              style={{ color: "var(--surface-text-secondary)" }}
            >
              Non
            </button>
          </div>
        ) : (
          <div className="flex items-center justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
            <button
              onClick={onResetPassword}
              title="Reinitialiser mot de passe"
              className="p-1.5 rounded-lg hover:bg-[var(--surface-hover)] transition-colors text-muted-foreground hover:text-amber-400"
            >
              <RefreshCw className="h-4 w-4" />
            </button>
            <button
              onClick={onToggle}
              title={user.isActive ? "Desactiver" : "Activer"}
              className="p-1.5 rounded-lg hover:bg-[var(--surface-hover)] transition-colors"
            >
              {user.isActive ? (
                <ToggleRight className="h-4 w-4 text-emerald-400" />
              ) : (
                <ToggleLeft className="h-4 w-4 text-muted-foreground" />
              )}
            </button>
            <button
              onClick={onEdit}
              title="Modifier"
              className="p-1.5 rounded-lg hover:bg-[var(--surface-hover)] text-muted-foreground hover:text-cyan-400 transition-colors"
            >
              <Pencil className="h-4 w-4" />
            </button>
            <button
              onClick={onDelete}
              title="Supprimer"
              className="p-1.5 rounded-lg hover:bg-red-500/10 text-muted-foreground hover:text-red-400 transition-colors"
            >
              <Trash2 className="h-4 w-4" />
            </button>
          </div>
        )}
      </td>
    </tr>
  );
}
