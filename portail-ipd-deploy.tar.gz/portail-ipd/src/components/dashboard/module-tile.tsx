"use client";

import Link from "next/link";
import { cn } from "@/lib/utils";
import { type ModuleConfig, POLE_CONFIG } from "@/types";
import { MODULES } from "@/lib/data/mock-modules";
import { motion } from "framer-motion";
import {
  Shield, BarChart3, Activity, Settings, FlaskConical,
  BookOpen, Users, Wallet, Handshake, Megaphone, Lock,
  TrendingUp, TrendingDown, Minus, Factory, ClipboardCheck, Gauge,
  FolderKanban, Target, Building2,
} from "lucide-react";

const ICON_MAP: Record<string, React.ReactNode> = {
  Gauge: <Gauge className="h-6 w-6" />,
  ClipboardCheck: <ClipboardCheck className="h-6 w-6" />,
  Shield: <Shield className="h-6 w-6" />,
  BarChart3: <BarChart3 className="h-6 w-6" />,
  Activity: <Activity className="h-6 w-6" />,
  Settings: <Settings className="h-6 w-6" />,
  FlaskConical: <FlaskConical className="h-6 w-6" />,
  BookOpen: <BookOpen className="h-6 w-6" />,
  Users: <Users className="h-6 w-6" />,
  Wallet: <Wallet className="h-6 w-6" />,
  Handshake: <Handshake className="h-6 w-6" />,
  Megaphone: <Megaphone className="h-6 w-6" />,
  Factory: <Factory className="h-6 w-6" />,
  FolderKanban: <FolderKanban className="h-6 w-6" />,
  Target: <Target className="h-6 w-6" />,
  Building2: <Building2 className="h-6 w-6" />,
};

const trendIcons = {
  up: <TrendingUp className="h-3 w-3 text-emerald-400" />,
  down: <TrendingDown className="h-3 w-3 text-red-400" />,
  stable: <Minus className="h-3 w-3 text-zinc-400" />,
};

interface ModuleTileProps {
  module: ModuleConfig;
  index: number;
  accessible: boolean;
}

export function ModuleTile({ module, index, accessible }: ModuleTileProps) {
  const poleConfig = POLE_CONFIG[module.pole];
  const isDisabled = !module.enabled || !accessible;

  const content = (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: index * 0.08 }}
      className={cn(
        "glass rounded-2xl p-5 transition-all duration-300 relative overflow-hidden group h-full",
        isDisabled
          ? "opacity-40 cursor-not-allowed"
          : "glass-hover cursor-pointer hover:scale-[1.02]"
      )}
      style={{
        boxShadow: !isDisabled ? `0 0 20px ${module.color}10, 0 0 60px ${module.color}05` : undefined,
      }}
    >
      {/* Top accent line */}
      <div
        className="absolute top-0 left-0 right-0 h-[2px] opacity-60"
        style={{ backgroundColor: module.color }}
      />

      {/* Icon & Priority */}
      <div className="flex items-start justify-between mb-4">
        <div
          className="p-3 rounded-xl transition-transform duration-300 group-hover:scale-110"
          style={{ backgroundColor: `${module.color}15` }}
        >
          <div style={{ color: module.color }}>{ICON_MAP[module.icon] || <Shield className="h-6 w-6" />}</div>
        </div>
        <div className="flex items-center gap-2">
          <span
            className="text-[10px] font-semibold px-2 py-0.5 rounded-full"
            style={{ backgroundColor: `${module.color}15`, color: module.color }}
          >
            {module.priority}
          </span>
          {isDisabled && <Lock className="h-3.5 w-3.5 text-white/20" />}
        </div>
      </div>

      {/* Title & Description */}
      <h3 className="font-semibold text-sm mb-1">{module.name}</h3>
      <p className="text-xs text-muted-foreground line-clamp-2 mb-4">{module.description}</p>

      {/* KPI */}
      {module.kpiLabel && (
        <div className="flex items-center justify-between pt-3 border-t border-white/[0.06]">
          <span className="text-[10px] text-muted-foreground">{module.kpiLabel}</span>
          <div className="flex items-center gap-1.5">
            <span className="text-sm font-bold" style={{ color: module.color }}>
              {module.kpiValue}
            </span>
            {module.kpiTrend && trendIcons[module.kpiTrend]}
          </div>
        </div>
      )}

      {/* Pole badge */}
      <div className="mt-3 flex items-center gap-1.5">
        <div className="h-1.5 w-1.5 rounded-full" style={{ backgroundColor: poleConfig.color }} />
        <span className="text-[9px] text-muted-foreground uppercase tracking-wider">
          {poleConfig.label}
        </span>
      </div>
    </motion.div>
  );

  if (isDisabled) return content;

  // Modules pre-generes (statiques) vs modules dynamiques (via viewer)
  const isBuiltIn = MODULES.some((m) => m.id === module.id);
  const isIframeModule = module.type !== "react" && (module.externalUrl || module.htmlContent);

  const href = isIframeModule
    ? isBuiltIn
      ? `/modules/${module.id}`
      : `/modules/view?id=${module.id}`
    : module.route;

  return <Link href={href}>{content}</Link>;
}
