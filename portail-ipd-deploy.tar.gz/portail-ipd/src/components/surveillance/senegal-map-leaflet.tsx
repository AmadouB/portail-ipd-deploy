"use client";

import { MapContainer, TileLayer, CircleMarker, Popup, Tooltip, useMap } from "react-leaflet";
import { type RegionData } from "@/lib/data/mock-surveillance";
import { alertLevelColors, alertLevelLabels } from "./senegal-map";
import "leaflet/dist/leaflet.css";

/** Center of Senegal */
const SENEGAL_CENTER: [number, number] = [14.4974, -14.4524];
const SENEGAL_ZOOM = 7;

/** Calculate marker radius based on case count */
function getRadius(cases: number): number {
  if (cases === 0) return 5;
  return Math.max(6, Math.min(25, Math.sqrt(cases) * 2));
}

/** Custom hook to set max bounds */
function MapBounds() {
  const map = useMap();
  map.setMaxBounds([
    [11.5, -18.5],
    [17.0, -11.0],
  ]);
  return null;
}

interface SenegalMapLeafletProps {
  regions: RegionData[];
}

export function SenegalMapLeaflet({ regions }: SenegalMapLeafletProps) {
  return (
    <div className="h-full w-full relative">
      <MapContainer
        center={SENEGAL_CENTER}
        zoom={SENEGAL_ZOOM}
        minZoom={6}
        maxZoom={12}
        scrollWheelZoom={true}
        zoomControl={true}
        attributionControl={false}
        className="h-full w-full rounded-xl"
        style={{ background: "#0a0f1a" }}
      >
        <MapBounds />

        {/* Tile layer - dark style */}
        <TileLayer
          url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> &copy; <a href="https://carto.com/">CARTO</a>'
        />

        {/* Region markers */}
        {regions.map((region) => {
          const color = alertLevelColors[region.alertLevel];
          const radius = getRadius(region.cases);

          return (
            <CircleMarker
              key={region.code}
              center={[region.lat, region.lng]}
              radius={radius}
              pathOptions={{
                color: color,
                fillColor: color,
                fillOpacity: 0.35,
                weight: 2,
                opacity: 0.8,
              }}
            >
              {/* Tooltip on hover */}
              <Tooltip
                direction="top"
                offset={[0, -radius]}
                className="leaflet-tooltip-custom"
              >
                <div style={{ fontFamily: "inherit" }}>
                  <strong>{region.name}</strong>
                  <br />
                  {region.cases} cas actifs
                </div>
              </Tooltip>

              {/* Popup on click */}
              <Popup className="leaflet-popup-custom">
                <div style={{ minWidth: 160, fontFamily: "inherit" }}>
                  <h4 style={{ margin: "0 0 6px", fontSize: 14, fontWeight: 700 }}>
                    {region.name}
                  </h4>
                  <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 8 }}>
                    <span
                      style={{
                        display: "inline-block",
                        width: 8,
                        height: 8,
                        borderRadius: "50%",
                        backgroundColor: color,
                      }}
                    />
                    <span style={{ fontSize: 12, color: color, fontWeight: 600 }}>
                      {alertLevelLabels[region.alertLevel]}
                    </span>
                  </div>
                  <table style={{ fontSize: 12, width: "100%", borderCollapse: "collapse" }}>
                    <tbody>
                      <tr>
                        <td style={{ padding: "2px 0", color: "#9ca3af" }}>Cas actifs</td>
                        <td style={{ padding: "2px 0", textAlign: "right", fontWeight: 700 }}>{region.cases}</td>
                      </tr>
                      <tr>
                        <td style={{ padding: "2px 0", color: "#9ca3af" }}>Code region</td>
                        <td style={{ padding: "2px 0", textAlign: "right", fontWeight: 500 }}>{region.code}</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </Popup>
            </CircleMarker>
          );
        })}
      </MapContainer>

      {/* Legend overlay */}
      <div className="absolute bottom-3 right-3 z-[1000] flex flex-col gap-1.5 text-[10px] bg-black/70 rounded-lg px-3 py-2 backdrop-blur-sm border border-white/10">
        <span className="text-[9px] text-muted-foreground uppercase tracking-wider font-semibold mb-0.5">
          Niveau d&apos;alerte
        </span>
        {(["none", "low", "medium", "high", "critical"] as const).map((level) => (
          <div key={level} className="flex items-center gap-2">
            <div
              className="h-2.5 w-2.5 rounded-full"
              style={{ backgroundColor: alertLevelColors[level] }}
            />
            <span className="text-white/70">{alertLevelLabels[level]}</span>
          </div>
        ))}
      </div>

      {/* Attribution */}
      <div className="absolute bottom-1 left-1 z-[1000] text-[8px] text-white/30">
        OpenStreetMap &middot; CARTO
      </div>
    </div>
  );
}
