"use client";

import { useEffect, useState } from "react";
import { type RegionData } from "@/lib/data/mock-surveillance";

const alertLevelColors: Record<string, string> = {
  none: "#6b7280",
  low: "#06b6d4",
  medium: "#f59e0b",
  high: "#f97316",
  critical: "#ef4444",
};

const alertLevelLabels: Record<string, string> = {
  none: "Normal",
  low: "Faible",
  medium: "Moyen",
  high: "Eleve",
  critical: "Critique",
};

interface SenegalMapProps {
  regions: RegionData[];
}

export function SenegalMap({ regions }: SenegalMapProps) {
  const [MapComponent, setMapComponent] = useState<React.ComponentType<SenegalMapProps> | null>(null);

  useEffect(() => {
    // Dynamic import to avoid SSR issues with Leaflet
    import("./senegal-map-leaflet").then((mod) => {
      setMapComponent(() => mod.SenegalMapLeaflet);
    });
  }, []);

  if (!MapComponent) {
    return (
      <div className="h-full flex items-center justify-center text-muted-foreground">
        <div className="flex flex-col items-center gap-3">
          <div className="h-8 w-8 border-2 border-cyan-500/30 border-t-cyan-500 rounded-full animate-spin" />
          <span className="text-xs">Chargement de la carte...</span>
        </div>
      </div>
    );
  }

  return <MapComponent regions={regions} />;
}

export { alertLevelColors, alertLevelLabels };
