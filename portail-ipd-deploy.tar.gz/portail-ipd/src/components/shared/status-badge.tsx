import { cn } from "@/lib/utils";

interface StatusBadgeProps {
  status: "online" | "offline" | "warning" | "critical" | "active" | "inactive";
  label?: string;
  className?: string;
  pulse?: boolean;
}

const statusConfig = {
  online: { color: "bg-emerald-500", text: "text-emerald-400", label: "En ligne" },
  offline: { color: "bg-zinc-500", text: "text-zinc-400", label: "Hors ligne" },
  warning: { color: "bg-amber-500", text: "text-amber-400", label: "Attention" },
  critical: { color: "bg-red-500", text: "text-red-400", label: "Critique" },
  active: { color: "bg-cyan-500", text: "text-cyan-400", label: "Actif" },
  inactive: { color: "bg-zinc-500", text: "text-zinc-400", label: "Inactif" },
};

export function StatusBadge({ status, label, className, pulse = true }: StatusBadgeProps) {
  const config = statusConfig[status];

  return (
    <div className={cn("flex items-center gap-2", className)}>
      <div className="relative">
        <div className={cn("h-2 w-2 rounded-full", config.color)} />
        {pulse && (status === "online" || status === "active") && (
          <div className={cn("absolute inset-0 h-2 w-2 rounded-full pulse-dot", config.color)} />
        )}
      </div>
      <span className={cn("text-xs font-medium", config.text)}>
        {label || config.label}
      </span>
    </div>
  );
}
