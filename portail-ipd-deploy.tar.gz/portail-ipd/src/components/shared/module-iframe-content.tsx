"use client";

import { useModuleStore } from "@/stores/module-store";
import { useRouter } from "next/navigation";
import { GlassPanel } from "@/components/shared/glass-panel";
import { ArrowLeft, ExternalLink, Globe, AlertTriangle, FileCode } from "lucide-react";
import { motion } from "framer-motion";

export function ModuleIframeContent({ moduleId }: { moduleId: string }) {
  const router = useRouter();
  const modules = useModuleStore((s) => s.modules);

  const module = modules.find((m) => m.id === moduleId);

  const hasContent = module && (module.externalUrl || module.htmlContent);

  if (!module || !hasContent) {
    return (
      <div className="max-w-2xl mx-auto mt-20">
        <GlassPanel>
          <div className="flex flex-col items-center gap-4 py-8">
            <AlertTriangle className="h-12 w-12 text-amber-400" />
            <h2 className="text-lg font-semibold">Module introuvable</h2>
            <p className="text-sm text-muted-foreground text-center">
              Ce module n&apos;existe pas ou n&apos;a pas de contenu configuré.
            </p>
            <button
              onClick={() => router.push("/dashboard")}
              className="flex items-center gap-2 px-4 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-sm font-medium transition-colors"
            >
              <ArrowLeft className="h-4 w-4" />
              Retour au tableau de bord
            </button>
          </div>
        </GlassPanel>
      </div>
    );
  }

  const isUploadedHtml = !!module.htmlContent;

  return (
    <div className="h-[calc(100vh-5rem)] flex flex-col gap-4">
      {/* Header bar */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-center justify-between flex-shrink-0"
      >
        <div className="flex items-center gap-3">
          <button
            onClick={() => router.push("/dashboard")}
            className="p-2 rounded-lg hover:bg-white/5 transition-colors"
          >
            <ArrowLeft className="h-5 w-5 text-white/60" />
          </button>
          <div
            className="p-2.5 rounded-xl"
            style={{ backgroundColor: `${module.color}15` }}
          >
            {isUploadedHtml ? (
              <FileCode className="h-5 w-5" style={{ color: module.color }} />
            ) : (
              <Globe className="h-5 w-5" style={{ color: module.color }} />
            )}
          </div>
          <div>
            <h1 className="text-lg font-bold">{module.name}</h1>
            <p className="text-xs text-muted-foreground">
              {isUploadedHtml
                ? `Fichier HTML uploadé · ${module.htmlFileName || "document.html"}`
                : `${module.type === "html" ? "Plateforme HTML" : "Application externe"} · ${module.externalUrl}`}
            </p>
          </div>
        </div>

        {!isUploadedHtml && module.externalUrl && (
          <a
            href={module.externalUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs text-white/60 hover:text-white hover:bg-white/5 transition-colors"
          >
            <ExternalLink className="h-3.5 w-3.5" />
            Ouvrir dans un nouvel onglet
          </a>
        )}
      </motion.div>

      {/* Iframe container */}
      <div className="flex-1 rounded-xl overflow-hidden border border-white/[0.06] bg-white">
        {isUploadedHtml ? (
          <iframe
            srcDoc={module.htmlContent}
            title={module.name}
            className="w-full h-full border-0"
            sandbox="allow-scripts allow-same-origin allow-forms allow-popups"
          />
        ) : (
          <iframe
            src={module.externalUrl}
            title={module.name}
            className="w-full h-full border-0"
            sandbox="allow-scripts allow-same-origin allow-forms allow-popups"
            allow="clipboard-read; clipboard-write"
          />
        )}
      </div>
    </div>
  );
}
