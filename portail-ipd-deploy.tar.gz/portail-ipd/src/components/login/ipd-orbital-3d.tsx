"use client";

import { useEffect, useRef } from "react";

/* ------------------------------------------------------------------ */
/*  IPD Organisational data (from Organigramme Cible)                 */
/* ------------------------------------------------------------------ */

const ORBITS = [
  { rx: 0.22, ry: 0.16, tilt: 22, speed: 0.35, color: "#f59e0b" },   // Direction
  { rx: 0.39, ry: 0.27, tilt: -14, speed: 0.20, color: "#06b6d4" },  // Fonctions Métiers
  { rx: 0.48, ry: 0.37, tilt: 9, speed: 0.12, color: "#a78bfa" },    // Fonctions Opérationnelles
];

interface Entity {
  name: string;
  orbit: number;
  startAngle: number;
}

const ENTITIES: Entity[] = [
  // Orbit 0 — Direction
  { name: "Conseil de\nFondation", orbit: 0, startAngle: 0 },
  { name: "Administrateur\nGénéral", orbit: 0, startAngle: Math.PI },

  // Orbit 1 — Fonctions Métiers
  { name: "Production\nIndustrielle", orbit: 1, startAngle: 0 },
  { name: "Recherche &\nInnovation", orbit: 1, startAngle: Math.PI * 0.5 },
  { name: "Santé\nPublique", orbit: 1, startAngle: Math.PI },
  { name: "Direction\nCommerciale", orbit: 1, startAngle: Math.PI * 1.5 },

  // Orbit 2 — Fonctions Opérationnelles & Transversal
  { name: "Administration\n& Finance", orbit: 2, startAngle: 0 },
  { name: "Capital\nHumain", orbit: 2, startAngle: Math.PI / 3 },
  { name: "Informatique\n& Cybersécurité", orbit: 2, startAngle: (2 * Math.PI) / 3 },
  { name: "Partenariat", orbit: 2, startAngle: Math.PI },
  { name: "Cellule d'Appui\nStratégique", orbit: 2, startAngle: (4 * Math.PI) / 3 },
  { name: "Chaîne\nd'Approvisionnement", orbit: 2, startAngle: (5 * Math.PI) / 3 },
];

/* ------------------------------------------------------------------ */
/*  Helpers                                                            */
/* ------------------------------------------------------------------ */

function hexToRgb(hex: string): string {
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);
  return `${r}, ${g}, ${b}`;
}

interface Particle {
  x: number;
  y: number;
  r: number;
  phase: number;
  twinkleSpeed: number;
}

function createParticles(w: number, h: number, count: number): Particle[] {
  const particles: Particle[] = [];
  for (let i = 0; i < count; i++) {
    particles.push({
      x: Math.random() * w,
      y: Math.random() * h,
      r: Math.random() * 1.4 + 0.3,
      phase: Math.random() * Math.PI * 2,
      twinkleSpeed: Math.random() * 0.8 + 0.3,
    });
  }
  return particles;
}

/* ------------------------------------------------------------------ */
/*  Component                                                          */
/* ------------------------------------------------------------------ */

export function IpdOrbital3D() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const mouseRef = useRef({ x: 0, y: 0 });

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let particles: Particle[] = [];
    let animId = 0;
    const perspective = 500;

    /* --- Resize ---------------------------------------------------- */
    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      const dpr = window.devicePixelRatio || 1;
      canvas.width = rect.width * dpr;
      canvas.height = rect.height * dpr;
      particles = createParticles(rect.width, rect.height, 60);
    };

    const observer = new ResizeObserver(resize);
    observer.observe(canvas);
    resize();

    /* --- Draw ------------------------------------------------------ */
    const draw = () => {
      const dpr = window.devicePixelRatio || 1;
      const w = canvas.width / dpr;
      const h = canvas.height / dpr;
      const cx = w / 2;
      const cy = h / 2;
      const t = Date.now() * 0.001;
      const minDim = Math.min(w, h);
      const mx = mouseRef.current.x * 20;
      const my = mouseRef.current.y * 12;

      // Reset transform & clear
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

      /* Particles (twinkling stars) */
      particles.forEach((p) => {
        const alpha = 0.15 + Math.abs(Math.sin(t * p.twinkleSpeed + p.phase)) * 0.45;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(255, 255, 255, ${alpha})`;
        ctx.fill();
      });

      /* --- 3D helpers ---------------------------------------------- */
      const getPos = (orbitIdx: number, angle: number) => {
        const o = ORBITS[orbitIdx];
        const rx = o.rx * minDim;
        const ry = o.ry * minDim;
        const tiltRad = (o.tilt * Math.PI) / 180;
        const x3 = rx * Math.cos(angle);
        const y3raw = ry * Math.sin(angle);
        const y3 = y3raw * Math.cos(tiltRad);
        const z3 = y3raw * Math.sin(tiltRad);
        const s = perspective / (perspective + z3);
        return { x: cx + x3 * s + mx, y: cy + y3 * s + my, z: z3, s };
      };

      /* Collect drawable items for depth sorting */
      type DrawItem = { z: number; fn: () => void };
      const items: DrawItem[] = [];

      /* --- Orbital paths ------------------------------------------- */
      ORBITS.forEach((o) => {
        const rx = o.rx * minDim;
        const ry = o.ry * minDim;
        const tiltRad = (o.tilt * Math.PI) / 180;
        const segs = 150;
        for (let s = 0; s < segs; s++) {
          const a1 = (s / segs) * Math.PI * 2;
          const a2 = ((s + 1) / segs) * Math.PI * 2;

          const x1 = rx * Math.cos(a1);
          const y1r = ry * Math.sin(a1);
          const z1 = y1r * Math.sin(tiltRad);
          const y1 = y1r * Math.cos(tiltRad);
          const s1 = perspective / (perspective + z1);

          const x2 = rx * Math.cos(a2);
          const y2r = ry * Math.sin(a2);
          const z2 = y2r * Math.sin(tiltRad);
          const y2 = y2r * Math.cos(tiltRad);
          const s2 = perspective / (perspective + z2);

          const avgZ = (z1 + z2) / 2;
          const alpha = 0.06 + 0.14 * ((avgZ + perspective) / (2 * perspective));

          items.push({
            z: avgZ - 2000,
            fn: () => {
              ctx.beginPath();
              ctx.moveTo(cx + x1 * s1 + mx, cy + y1 * s1 + my);
              ctx.lineTo(cx + x2 * s2 + mx, cy + y2 * s2 + my);
              ctx.strokeStyle = `rgba(${hexToRgb(o.color)}, ${alpha})`;
              ctx.lineWidth = 1;
              ctx.stroke();
            },
          });
        }
      });

      /* --- Connection lines & Entity nodes ------------------------- */
      ENTITIES.forEach((entity) => {
        const o = ORBITS[entity.orbit];
        const angle = entity.startAngle + t * o.speed;
        const pos = getPos(entity.orbit, angle);
        const nodeR = (3.5 + entity.orbit * 2) * pos.s;
        const alpha = 0.35 + 0.65 * pos.s;
        const rgb = hexToRgb(o.color);

        // Connection line (behind entities)
        items.push({
          z: pos.z - 500,
          fn: () => {
            const grad = ctx.createLinearGradient(cx + mx, cy + my, pos.x, pos.y);
            grad.addColorStop(0, `rgba(${rgb}, 0.01)`);
            grad.addColorStop(1, `rgba(${rgb}, ${alpha * 0.12})`);
            ctx.beginPath();
            ctx.moveTo(cx + mx, cy + my);
            ctx.lineTo(pos.x, pos.y);
            ctx.strokeStyle = grad;
            ctx.lineWidth = 0.6;
            ctx.stroke();
          },
        });

        // Entity node + label
        items.push({
          z: pos.z,
          fn: () => {
            // Hover detection
            const mousePx = {
              x: (mouseRef.current.x + 0.5) * w,
              y: (mouseRef.current.y + 0.5) * h,
            };
            const dist = Math.hypot(pos.x - mousePx.x, pos.y - mousePx.y);
            const isHover = dist < nodeR + 18;
            const hoverBoost = isHover ? 1.5 : 1;

            // Glow
            ctx.save();
            ctx.shadowBlur = (isHover ? 25 : 12) * pos.s;
            ctx.shadowColor = o.color;

            // Filled node
            ctx.beginPath();
            ctx.arc(pos.x, pos.y, nodeR * hoverBoost, 0, Math.PI * 2);
            ctx.fillStyle = `rgba(${rgb}, ${alpha * 0.7})`;
            ctx.fill();
            ctx.strokeStyle = `rgba(${rgb}, ${alpha})`;
            ctx.lineWidth = 1.5 * pos.s;
            ctx.stroke();
            ctx.restore();

            // Label
            const fontSize = Math.max(7, (isHover ? 11 : 9.5) * pos.s);
            ctx.font = `${isHover ? "600" : "400"} ${fontSize}px -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif`;
            ctx.textAlign = "center";
            ctx.fillStyle = `rgba(255, 255, 255, ${alpha * (isHover ? 1 : 0.85)})`;
            const lines = entity.name.split("\n");
            lines.forEach((line, li) => {
              ctx.fillText(
                line,
                pos.x,
                pos.y + nodeR * hoverBoost + 10 * pos.s + li * (fontSize + 1)
              );
            });
          },
        });
      });

      /* --- Central core (IPD) -------------------------------------- */
      items.push({
        z: 0,
        fn: () => {
          const pulse = 1 + Math.sin(t * 1.8) * 0.06;
          const coreR = 20 * pulse;

          // Outer glow halo
          const haloGrad = ctx.createRadialGradient(
            cx + mx, cy + my, coreR * 0.3,
            cx + mx, cy + my, coreR * 3.5
          );
          haloGrad.addColorStop(0, "rgba(6, 182, 212, 0.12)");
          haloGrad.addColorStop(0.5, "rgba(6, 182, 212, 0.04)");
          haloGrad.addColorStop(1, "rgba(6, 182, 212, 0)");
          ctx.beginPath();
          ctx.arc(cx + mx, cy + my, coreR * 3.5, 0, Math.PI * 2);
          ctx.fillStyle = haloGrad;
          ctx.fill();

          // Core sphere gradient
          ctx.save();
          ctx.shadowBlur = 30;
          ctx.shadowColor = "#06b6d4";
          const coreGrad = ctx.createRadialGradient(
            cx + mx - 4, cy + my - 4, 2,
            cx + mx, cy + my, coreR
          );
          coreGrad.addColorStop(0, "#a5f3fc");
          coreGrad.addColorStop(0.4, "#22d3ee");
          coreGrad.addColorStop(0.8, "#0891b2");
          coreGrad.addColorStop(1, "#164e63");
          ctx.beginPath();
          ctx.arc(cx + mx, cy + my, coreR, 0, Math.PI * 2);
          ctx.fillStyle = coreGrad;
          ctx.fill();

          // Bright ring
          ctx.strokeStyle = "rgba(165, 243, 252, 0.5)";
          ctx.lineWidth = 1.5;
          ctx.stroke();
          ctx.restore();

          // "IPD" label
          ctx.font = 'bold 13px -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif';
          ctx.textAlign = "center";
          ctx.textBaseline = "middle";
          ctx.fillStyle = "#ffffff";
          ctx.fillText("IPD", cx + mx, cy + my);
        },
      });

      /* --- Render sorted ------------------------------------------- */
      items.sort((a, b) => a.z - b.z);
      items.forEach((item) => item.fn());

      animId = requestAnimationFrame(draw);
    };

    animId = requestAnimationFrame(draw);

    return () => {
      observer.disconnect();
      cancelAnimationFrame(animId);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="w-full h-full cursor-default"
      onMouseMove={(e) => {
        const rect = e.currentTarget.getBoundingClientRect();
        mouseRef.current = {
          x: (e.clientX - rect.left) / rect.width - 0.5,
          y: (e.clientY - rect.top) / rect.height - 0.5,
        };
      }}
      onMouseLeave={() => {
        mouseRef.current = { x: 0, y: 0 };
      }}
    />
  );
}
