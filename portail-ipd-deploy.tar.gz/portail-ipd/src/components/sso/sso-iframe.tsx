"use client";

import { useEffect, useState } from "react";
import { useAuthStore } from "@/stores/auth-store";
import { generateSsoToken } from "@/lib/sso/token";

interface SsoIframeProps {
  /** Base URL of the embedded app (e.g. https://hoshinflow.vercel.app) */
  appUrl: string;
  /** Title for the iframe */
  title: string;
  /** SSO endpoint path on the target app (default: /api/auth/sso) */
  ssoPath?: string;
}

/**
 * Iframe wrapper that automatically passes an SSO token
 * to the embedded application for seamless authentication.
 */
export function SsoIframe({ appUrl, title, ssoPath = "/api/auth/sso" }: SsoIframeProps) {
  const session = useAuthStore((s) => s.session);
  const [iframeSrc, setIframeSrc] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!session?.user) return;

    async function buildSsoUrl() {
      try {
        const token = await generateSsoToken({
          email: session!.user.email,
          firstName: session!.user.firstName,
          lastName: session!.user.lastName,
          role: session!.user.role,
        });

        // Build SSO URL: app.com/api/auth/sso?token=xxx&redirect=/dashboard
        const baseUrl = appUrl.replace(/\/+$/, "");
        const ssoUrl = `${baseUrl}${ssoPath}?token=${encodeURIComponent(token)}&redirect=/dashboard`;
        setIframeSrc(ssoUrl);
      } catch {
        setError("Erreur de génération du token SSO");
        // Fallback: load app without SSO
        setIframeSrc(appUrl);
      }
    }

    buildSsoUrl();
  }, [session, appUrl, ssoPath]);

  if (error) {
    return (
      <div className="-m-6 h-[calc(100vh-4rem)] flex flex-col">
        <div className="bg-amber-500/10 border-b border-amber-500/20 px-4 py-2 text-xs text-amber-400">
          {error} — chargement sans authentification automatique
        </div>
        <iframe
          src={appUrl}
          className="w-full flex-1 border-0"
          title={title}
        />
      </div>
    );
  }

  if (!iframeSrc) {
    return (
      <div className="-m-6 h-[calc(100vh-4rem)] flex items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <div className="h-8 w-8 border-2 border-cyan-500/30 border-t-cyan-500 rounded-full animate-spin" />
          <p className="text-sm text-muted-foreground">Connexion à {title}...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="-m-6 h-[calc(100vh-4rem)]">
      <iframe
        src={iframeSrc}
        className="w-full h-full border-0"
        title={title}
      />
    </div>
  );
}
