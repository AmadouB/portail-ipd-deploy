import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { verifyToken, type JwtPayload } from "./jwt";

/** User object returned by getAuthenticatedUser (password excluded). */
export type AuthenticatedUser = {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  role: string;
  pole: string;
  department: string;
  title: string;
  avatar: string | null;
  isActive: boolean;
  lastLogin: Date | null;
  mfaEnabled: boolean;
  createdAt: Date;
  updatedAt: Date;
};

export interface AuthContext {
  user: AuthenticatedUser;
  session: { id: string; expiresAt: Date };
  payload: JwtPayload;
}

/**
 * Extract and validate the authenticated user from a request.
 * Checks Authorization header first, then ipd_token cookie.
 * Returns null if no valid auth is found.
 */
export async function getAuthenticatedUser(
  req: NextRequest
): Promise<AuthContext | null> {
  // 1. Extract token
  let token: string | null = null;

  const authHeader = req.headers.get("authorization");
  if (authHeader?.startsWith("Bearer ")) {
    token = authHeader.slice(7);
  }

  if (!token) {
    token = req.cookies.get("ipd_token")?.value ?? null;
  }

  if (!token) return null;

  // 2. Verify JWT
  const payload = verifyToken(token);
  if (!payload) return null;

  // 3. Check session exists and is not expired
  const session = await prisma.session.findUnique({
    where: { id: payload.sessionId },
  });

  if (!session || session.expiresAt < new Date()) {
    return null;
  }

  // 4. Fetch user (excluding password)
  const user = await prisma.user.findUnique({
    where: { id: payload.userId },
    select: {
      id: true,
      email: true,
      firstName: true,
      lastName: true,
      role: true,
      pole: true,
      department: true,
      title: true,
      avatar: true,
      isActive: true,
      lastLogin: true,
      mfaEnabled: true,
      createdAt: true,
      updatedAt: true,
    },
  });

  if (!user || !user.isActive) return null;

  return {
    user,
    session: { id: session.id, expiresAt: session.expiresAt },
    payload,
  };
}

/**
 * Return a 401 Unauthorized JSON response.
 */
export function unauthorized(message = "Non autorise"): NextResponse {
  return NextResponse.json({ error: message }, { status: 401 });
}

/**
 * Return a 403 Forbidden JSON response.
 */
export function forbidden(message = "Acces interdit"): NextResponse {
  return NextResponse.json({ error: message }, { status: 403 });
}

/**
 * Extract the client IP address from request headers.
 */
export function getClientIp(req: NextRequest): string {
  return (
    req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ??
    req.headers.get("x-real-ip") ??
    "unknown"
  );
}
