import jwt from "jsonwebtoken";

export interface JwtPayload {
  userId: string;
  sessionId: string;
  email: string;
  role: string;
}

function getSecret(): string {
  const secret = process.env.JWT_SECRET;
  if (!secret) {
    throw new Error("JWT_SECRET environment variable is not set");
  }
  return secret;
}

function getExpiry(): string {
  return process.env.JWT_EXPIRY ?? "8h";
}

/**
 * Sign a JWT token with the given payload.
 */
export function signToken(payload: JwtPayload): string {
  return jwt.sign(payload as object, getSecret(), {
    expiresIn: getExpiry() as jwt.SignOptions["expiresIn"],
  });
}

/**
 * Verify and decode a JWT token.
 * Returns the payload if valid, or null if invalid/expired.
 */
export function verifyToken(token: string): JwtPayload | null {
  try {
    const decoded = jwt.verify(token, getSecret()) as JwtPayload;
    return decoded;
  } catch {
    return null;
  }
}
