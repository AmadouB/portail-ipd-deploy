/**
 * SSO Token Generator — Client-side compatible (HMAC-SHA256 via Web Crypto)
 *
 * Generates signed tokens for seamless authentication across
 * all apps embedded in the portal (HoshinFlow, DRO, etc.).
 *
 * Token format: base64url(payload).base64url(signature)
 * Payload: { email, name, role, iat, exp }
 */

const SSO_SECRET = "ipd-sso-shared-secret-2026-k8Xm2v";
const TOKEN_EXPIRY_SECONDS = 300; // 5 minutes — one-time use

interface SsoPayload {
  email: string;
  name: string;
  role: string;
  iat: number;
  exp: number;
}

function base64UrlEncode(data: string): string {
  if (typeof window !== "undefined") {
    return btoa(data).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
  }
  return Buffer.from(data).toString("base64url");
}

function base64UrlDecode(str: string): string {
  const padded = str.replace(/-/g, "+").replace(/_/g, "/");
  if (typeof window !== "undefined") {
    return atob(padded);
  }
  return Buffer.from(padded, "base64url").toString();
}

async function getKey(): Promise<CryptoKey> {
  const encoder = new TextEncoder();
  return crypto.subtle.importKey(
    "raw",
    encoder.encode(SSO_SECRET),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign", "verify"]
  );
}

async function sign(data: string): Promise<string> {
  const key = await getKey();
  const encoder = new TextEncoder();
  const signature = await crypto.subtle.sign("HMAC", key, encoder.encode(data));
  const bytes = new Uint8Array(signature);
  let binary = "";
  bytes.forEach((b) => (binary += String.fromCharCode(b)));
  return base64UrlEncode(binary);
}

/**
 * Generate a signed SSO token for embedding in iframe URLs.
 */
export async function generateSsoToken(user: {
  email: string;
  firstName: string;
  lastName: string;
  role: string;
}): Promise<string> {
  const now = Math.floor(Date.now() / 1000);
  const payload: SsoPayload = {
    email: user.email,
    name: `${user.firstName} ${user.lastName}`,
    role: user.role,
    iat: now,
    exp: now + TOKEN_EXPIRY_SECONDS,
  };

  const payloadStr = base64UrlEncode(JSON.stringify(payload));
  const sig = await sign(payloadStr);
  return `${payloadStr}.${sig}`;
}

/**
 * Verify an SSO token and return the payload if valid.
 * Used server-side by embedded apps.
 */
export async function verifySsoToken(token: string): Promise<SsoPayload | null> {
  try {
    const [payloadStr, sig] = token.split(".");
    if (!payloadStr || !sig) return null;

    const key = await getKey();
    const encoder = new TextEncoder();
    const sigBytes = Uint8Array.from(
      base64UrlDecode(sig),
      (c) => c.charCodeAt(0)
    );
    const valid = await crypto.subtle.verify(
      "HMAC",
      key,
      sigBytes,
      encoder.encode(payloadStr)
    );
    if (!valid) return null;

    const payload: SsoPayload = JSON.parse(base64UrlDecode(payloadStr));

    // Check expiration
    const now = Math.floor(Date.now() / 1000);
    if (payload.exp < now) return null;

    return payload;
  } catch {
    return null;
  }
}
