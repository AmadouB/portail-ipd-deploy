/**
 * SSO Token Generator — Client-side compatible (HMAC-SHA256 via Web Crypto)
 *
 * Genere des tokens signes pour l'authentification unique entre toutes
 * les apps integrees au portail (HoshinFlow, AFM, IMS, Partnerships, etc.).
 *
 * Token format: base64url(payload).base64url(signature)
 *
 * Payload v2 (enrichi) :
 *   email      → identifiant unique
 *   name       → "Prenom Nom"
 *   role       → admin_general | ag | directeur | chef_service | utilisateur
 *   service    → service / cellule (ex: "DAF", "Cellule SEID")
 *   pole       → grand pole (gouvernance, metiers, partenariat, operations)
 *   direction  → direction de rattachement (ex: "DG", "DRO")
 *   fonction   → titre exact (ex: "Chargee de projet")
 *   iat / exp  → timestamps
 *
 * Convention RBAC partagee :
 *   - admin_general / ag → voient TOUT dans toutes les apps
 *   - directeur          → voit son pole entier
 *   - chef_service       → voit + edite son service
 *   - utilisateur        → voit son service en lecture seule
 */

const SSO_SECRET = "ipd-sso-shared-secret-2026-k8Xm2v";
const TOKEN_EXPIRY_SECONDS = 300; // 5 minutes — one-time use

export interface SsoPayload {
  email: string;
  name: string;
  role: string;
  service?: string;        // ex: "DAF", "Cellule SEID"
  pole?: string;           // ex: "operations", "gouvernance"
  direction?: string;      // ex: "DG", "DRO", "DPC"
  fonction?: string;       // ex: "Chargee de projet"
  iat: number;
  exp: number;
}

function base64UrlEncode(data: string): string {
  if (typeof window !== "undefined") {
    return btoa(data).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
  }
  return Buffer.from(data).toString("base64url");
}

function base64UrlDecode(str: string): string {
  const padded = str.replace(/-/g, "+").replace(/_/g, "/");
  if (typeof window !== "undefined") {
    return atob(padded);
  }
  return Buffer.from(padded, "base64url").toString();
}

async function getKey(): Promise<CryptoKey> {
  const encoder = new TextEncoder();
  return crypto.subtle.importKey(
    "raw",
    encoder.encode(SSO_SECRET),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign", "verify"]
  );
}

async function sign(data: string): Promise<string> {
  const key = await getKey();
  const encoder = new TextEncoder();
  const signature = await crypto.subtle.sign("HMAC", key, encoder.encode(data));
  const bytes = new Uint8Array(signature);
  let binary = "";
  bytes.forEach((b) => (binary += String.fromCharCode(b)));
  return base64UrlEncode(binary);
}

/**
 * Generate a signed SSO token for embedding in iframe URLs.
 * Inclut le contexte organisationnel (service, pole, direction, fonction)
 * pour permettre aux apps cibles d'appliquer leur RBAC.
 */
export async function generateSsoToken(user: {
  email: string;
  firstName: string;
  lastName: string;
  role: string;
  department?: string | null;   // service / cellule
  pole?: string | null;
  direction?: string | null;
  title?: string | null;        // fonction
}): Promise<string> {
  const now = Math.floor(Date.now() / 1000);
  const payload: SsoPayload = {
    email: user.email,
    name: `${user.firstName} ${user.lastName}`,
    role: user.role,
    service: user.department ?? undefined,
    pole: user.pole ?? undefined,
    direction: user.direction ?? undefined,
    fonction: user.title ?? undefined,
    iat: now,
    exp: now + TOKEN_EXPIRY_SECONDS,
  };

  const payloadStr = base64UrlEncode(JSON.stringify(payload));
  const sig = await sign(payloadStr);
  return `${payloadStr}.${sig}`;
}

/**
 * Verify an SSO token and return the payload if valid.
 * Used server-side by embedded apps.
 */
export async function verifySsoToken(token: string): Promise<SsoPayload | null> {
  try {
    const [payloadStr, sig] = token.split(".");
    if (!payloadStr || !sig) return null;

    const key = await getKey();
    const encoder = new TextEncoder();
    const sigBytes = Uint8Array.from(
      base64UrlDecode(sig),
      (c) => c.charCodeAt(0)
    );
    const valid = await crypto.subtle.verify(
      "HMAC",
      key,
      sigBytes,
      encoder.encode(payloadStr)
    );
    if (!valid) return null;

    const payload: SsoPayload = JSON.parse(base64UrlDecode(payloadStr));

    // Check expiration
    const now = Math.floor(Date.now() / 1000);
    if (payload.exp < now) return null;

    return payload;
  } catch {
    return null;
  }
}
