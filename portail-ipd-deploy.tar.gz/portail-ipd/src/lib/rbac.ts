import { type RoleName, type ModuleId, type Permission, type Pole } from "@/types";

type ModulePermissions = Partial<Record<ModuleId, Permission[]>>;

export const ROLE_PERMISSIONS: Record<RoleName, { poles: (Pole | "tous")[]; modules: ModulePermissions }> = {
  admin_general: {
    poles: ["tous"],
    modules: {
      coordination: ["read", "write", "admin"],
      hoshin: ["read", "write", "admin"],
      partenariat: ["read", "write", "admin"],
      ims: ["read", "write", "admin"],
      direction_pole: ["read", "write", "admin"],
      admin: ["read", "write", "admin"],
    },
  },
  cas: {
    poles: ["gouvernance"],
    modules: {
      coordination: ["read"],
      hoshin: ["read"],
      direction_pole: ["read"],
    },
  },
  seid: {
    poles: ["gouvernance"],
    modules: {
      coordination: ["read"],
      hoshin: ["read"],
    },
  },
  dsi: {
    poles: ["operations"],
    modules: {
      admin: ["read", "write", "admin"],
    },
  },
  dir_production: {
    poles: ["metiers"],
    modules: {
      coordination: ["read"],
      ims: ["read", "write"],
      direction_pole: ["read"],
    },
  },
  dir_recherche: {
    poles: ["metiers"],
    modules: {
      coordination: ["read"],
      direction_pole: ["read"],
    },
  },
  dir_sante_publique: {
    poles: ["metiers"],
    modules: {
      coordination: ["read"],
      direction_pole: ["read"],
    },
  },
  dir_partenariat: {
    poles: ["partenariat"],
    modules: {
      coordination: ["read"],
      partenariat: ["read", "write"],
      direction_pole: ["read"],
    },
  },
  drh: {
    poles: ["operations"],
    modules: {
      coordination: ["read"],
      direction_pole: ["read"],
    },
  },
  daf: {
    poles: ["operations"],
    modules: {
      coordination: ["read"],
      direction_pole: ["read"],
    },
  },
  utilisateur: {
    poles: ["tous"],
    modules: {
      coordination: ["read"],
      hoshin: ["read"],
      partenariat: ["read"],
      ims: ["read"],
      direction_pole: ["read"],
    },
  },
};

export function hasModuleAccess(role: RoleName, moduleId: ModuleId): boolean {
  const perms = ROLE_PERMISSIONS[role];
  // Admin general has access to all modules, including dynamically added ones
  if (perms.poles.includes("tous")) return true;
  return !!perms.modules[moduleId] && perms.modules[moduleId]!.length > 0;
}

export function getModulePermissions(role: RoleName, moduleId: ModuleId): Permission[] {
  return ROLE_PERMISSIONS[role]?.modules[moduleId] ?? [];
}

export function canWrite(role: RoleName, moduleId: ModuleId): boolean {
  const perms = getModulePermissions(role, moduleId);
  return perms.includes("write") || perms.includes("admin");
}

export function getAccessibleModules(role: RoleName): ModuleId[] {
  const perms = ROLE_PERMISSIONS[role];
  return Object.keys(perms.modules).filter(
    (m) => perms.modules[m as ModuleId]!.length > 0
  ) as ModuleId[];
}

export function getAccessiblePoles(role: RoleName): (Pole | "tous")[] {
  return ROLE_PERMISSIONS[role].poles;
}
