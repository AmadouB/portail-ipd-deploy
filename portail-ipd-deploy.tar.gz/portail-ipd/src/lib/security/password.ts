import bcrypt from "bcryptjs";

const SALT_ROUNDS = 10;

/** Hash a plain-text password using bcrypt */
export async function hashPassword(plain: string): Promise<string> {
  return bcrypt.hash(plain, SALT_ROUNDS);
}

/** Verify a plain-text password against a bcrypt hash */
export async function verifyPassword(plain: string, hash: string): Promise<boolean> {
  return bcrypt.compare(plain, hash);
}

/** Password complexity validation rules */
export interface PasswordValidation {
  valid: boolean;
  errors: string[];
}

export function validatePasswordComplexity(password: string): PasswordValidation {
  const errors: string[] = [];

  if (password.length < 12) {
    errors.push("Le mot de passe doit contenir au moins 12 caractères");
  }
  if (!/[A-Z]/.test(password)) {
    errors.push("Le mot de passe doit contenir au moins une majuscule");
  }
  if (!/[a-z]/.test(password)) {
    errors.push("Le mot de passe doit contenir au moins une minuscule");
  }
  if (!/[0-9]/.test(password)) {
    errors.push("Le mot de passe doit contenir au moins un chiffre");
  }
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(password)) {
    errors.push("Le mot de passe doit contenir au moins un caractère spécial (!@#$%&*...)");
  }

  return { valid: errors.length === 0, errors };
}

/** Generate a strong random password that meets complexity requirements */
export function generateStrongPassword(): string {
  const upper = "ABCDEFGHJKLMNPQRSTUVWXYZ";
  const lower = "abcdefghjkmnpqrstuvwxyz";
  const digits = "23456789";
  const special = "@#$%&*!?";
  const all = upper + lower + digits + special;

  const pick = (chars: string) => chars[Math.floor(Math.random() * chars.length)];

  // Guarantee at least one of each required type
  const required = [pick(upper), pick(lower), pick(digits), pick(special)];

  // Fill remaining 10 chars randomly
  const rest = Array.from({ length: 10 }, () => pick(all));

  // Shuffle all together
  const combined = [...required, ...rest];
  for (let i = combined.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [combined[i], combined[j]] = [combined[j], combined[i]];
  }

  // Format: IPD-XXXX-XXXX-XXXX (14 chars in 3 blocks)
  const raw = combined.join("");
  return `IPD-${raw.slice(0, 4)}-${raw.slice(4, 8)}-${raw.slice(8, 14)}`;
}
