import { type AuditLog, type ModuleId } from "@/types";

const STORAGE_KEY = "ipd_audit_log";
const MAX_ENTRIES = 500;

type AuditAction = AuditLog["action"];

/** Log an action to the audit trail */
export function logAuditAction(
  userId: string,
  userName: string,
  action: AuditAction,
  module: ModuleId | "auth" | "system",
  detail: string,
): void {
  if (typeof window === "undefined") return;

  const entry: AuditLog = {
    id: `log-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    userId,
    userName,
    action,
    module,
    detail,
    ipAddress: "client-side",
    timestamp: new Date().toISOString(),
  };

  try {
    const logs = getAuditLogs();
    logs.unshift(entry);

    // Rotation: keep only the last MAX_ENTRIES
    if (logs.length > MAX_ENTRIES) {
      logs.length = MAX_ENTRIES;
    }

    localStorage.setItem(STORAGE_KEY, JSON.stringify(logs));
  } catch { /* ignore storage errors */ }
}

/** Retrieve all audit logs from localStorage */
export function getAuditLogs(): AuditLog[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

/** Clear all audit logs */
export function clearAuditLogs(): void {
  if (typeof window === "undefined") return;
  localStorage.removeItem(STORAGE_KEY);
}

/** Helper to log auth events */
export function logAuthEvent(
  userId: string,
  userName: string,
  action: "login" | "logout",
  detail: string,
): void {
  logAuditAction(userId, userName, action, "auth", detail);
}

/** Helper to log failed login attempts */
export function logFailedLogin(email: string): void {
  logAuditAction("unknown", email, "login", "auth", `Tentative de connexion échouée pour ${email}`);
}

/** Helper to log lockout events */
export function logLockout(email: string): void {
  logAuditAction("unknown", email, "login", "auth", `Compte verrouillé après 5 tentatives : ${email}`);
}
