const STORAGE_KEY = "ipd_login_attempts";
const MAX_ATTEMPTS = 5;
const LOCKOUT_DURATION_MS = 15 * 60 * 1000; // 15 minutes

interface AttemptRecord {
  count: number;
  firstAttempt: number;
  lockedUntil: number | null;
}

function getAttempts(): Record<string, AttemptRecord> {
  if (typeof window === "undefined") return {};
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

function saveAttempts(attempts: Record<string, AttemptRecord>) {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(attempts));
  } catch { /* ignore */ }
}

/** Check if an email is currently locked out */
export function isLockedOut(email: string): { locked: boolean; remainingMs: number } {
  const key = email.toLowerCase();
  const attempts = getAttempts();
  const record = attempts[key];

  if (!record?.lockedUntil) return { locked: false, remainingMs: 0 };

  const now = Date.now();
  if (now >= record.lockedUntil) {
    // Lockout expired — clear record
    delete attempts[key];
    saveAttempts(attempts);
    return { locked: false, remainingMs: 0 };
  }

  return { locked: true, remainingMs: record.lockedUntil - now };
}

/** Record a failed login attempt. Returns true if account is now locked. */
export function recordFailedAttempt(email: string): boolean {
  const key = email.toLowerCase();
  const attempts = getAttempts();
  const now = Date.now();

  let record = attempts[key];

  if (!record) {
    record = { count: 1, firstAttempt: now, lockedUntil: null };
  } else if (record.lockedUntil && now < record.lockedUntil) {
    // Already locked — ignore
    return true;
  } else {
    // Reset if old attempts (> lockout window)
    if (now - record.firstAttempt > LOCKOUT_DURATION_MS) {
      record = { count: 1, firstAttempt: now, lockedUntil: null };
    } else {
      record.count++;
    }
  }

  if (record.count >= MAX_ATTEMPTS) {
    record.lockedUntil = now + LOCKOUT_DURATION_MS;
  }

  attempts[key] = record;
  saveAttempts(attempts);

  return record.count >= MAX_ATTEMPTS;
}

/** Clear attempts after successful login */
export function clearAttempts(email: string) {
  const key = email.toLowerCase();
  const attempts = getAttempts();
  delete attempts[key];
  saveAttempts(attempts);
}

/** Format remaining lockout time for display */
export function formatRemainingTime(ms: number): string {
  const minutes = Math.ceil(ms / 60000);
  if (minutes <= 1) return "moins d\u2019une minute";
  return `${minutes} minutes`;
}
