/**
 * Frontend API client for communicating with Next.js API routes.
 * Automatically includes the Authorization header from the stored token.
 */

const TOKEN_KEY = "ipd_token";

export class ApiError extends Error {
  constructor(
    public status: number,
    message: string,
    public data?: Record<string, unknown>
  ) {
    super(message);
    this.name = "ApiError";
  }
}

function getToken(): string | null {
  if (typeof window === "undefined") return null;
  return localStorage.getItem(TOKEN_KEY);
}

export function setToken(token: string): void {
  if (typeof window === "undefined") return;
  localStorage.setItem(TOKEN_KEY, token);
}

export function clearToken(): void {
  if (typeof window === "undefined") return;
  localStorage.removeItem(TOKEN_KEY);
}

async function request<T>(
  method: string,
  url: string,
  body?: unknown,
  options?: RequestInit
): Promise<T> {
  const headers: Record<string, string> = {
    "Content-Type": "application/json",
    ...((options?.headers as Record<string, string>) ?? {}),
  };

  const token = getToken();
  if (token) {
    headers["Authorization"] = `Bearer ${token}`;
  }

  const res = await fetch(url, {
    method,
    headers,
    body: body != null ? JSON.stringify(body) : undefined,
    credentials: "include",
    ...options,
  });

  // Handle empty responses (204 No Content)
  if (res.status === 204) {
    return undefined as T;
  }

  const data = await res.json();

  if (!res.ok) {
    throw new ApiError(res.status, data.error ?? "Une erreur est survenue", data);
  }

  return data as T;
}

export const api = {
  get<T>(url: string, options?: RequestInit): Promise<T> {
    return request<T>("GET", url, undefined, options);
  },

  post<T>(url: string, body?: unknown, options?: RequestInit): Promise<T> {
    return request<T>("POST", url, body, options);
  },

  patch<T>(url: string, body?: unknown, options?: RequestInit): Promise<T> {
    return request<T>("PATCH", url, body, options);
  },

  put<T>(url: string, body?: unknown, options?: RequestInit): Promise<T> {
    return request<T>("PUT", url, body, options);
  },

  delete<T>(url: string, body?: unknown, options?: RequestInit): Promise<T> {
    return request<T>("DELETE", url, body, options);
  },
};
