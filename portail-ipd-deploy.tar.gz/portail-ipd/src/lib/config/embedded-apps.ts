/**
 * Configuration des applications embarquées dans le portail.
 * Permet de basculer entre URLs Vercel (public) et JumpServer (VPN).
 */

const APPS = {
  hoshinflow: {
    vercel: "https://hoshinflow.vercel.app",
    jumpserver: "http://10.99.1.10",
  },
  dro: {
    vercel: "https://frontend-sage-two-66.vercel.app",
    jumpserver: null, // pas encore déployé sur JumpServer
  },
} as const;

type AppName = keyof typeof APPS;

/**
 * Detect if we're running on the VPN (internal network).
 * On the JumpServer, the portal will be served from an internal IP.
 */
function isInternalNetwork(): boolean {
  if (typeof window === "undefined") return false;
  const hostname = window.location.hostname;
  return (
    hostname.startsWith("10.") ||
    hostname.startsWith("192.168.") ||
    hostname.startsWith("172.") ||
    hostname.endsWith(".ipd.local")
  );
}

/**
 * Get the URL for an embedded app, auto-selecting Vercel or JumpServer.
 */
export function getAppUrl(app: AppName): string {
  const config = APPS[app];
  if (isInternalNetwork() && config.jumpserver) {
    return config.jumpserver;
  }
  return config.vercel;
}
