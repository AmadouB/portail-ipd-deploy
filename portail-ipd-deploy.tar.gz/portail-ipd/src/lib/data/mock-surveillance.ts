export interface EpidemicAlert {
  id: string;
  disease: string;
  region: string;
  level: "vigilance" | "pre_alerte" | "alerte" | "urgence";
  cases: number;
  casesLastWeek: number;
  deaths: number;
  date: string;
  message: string;
}

export interface DiseaseData {
  disease: string;
  totalCases: number;
  activeCases: number;
  recovered: number;
  deaths: number;
  trend: "up" | "down" | "stable";
  weeklyData: { week: string; cases: number }[];
}

export interface RegionData {
  name: string;
  code: string;
  cases: number;
  alertLevel: "none" | "low" | "medium" | "high" | "critical";
  x: number;
  y: number;
  lat: number;
  lng: number;
}

export const EPIDEMIC_ALERTS: EpidemicAlert[] = [
  {
    id: "ea-01",
    disease: "Dengue",
    region: "Dakar",
    level: "alerte",
    cases: 156,
    casesLastWeek: 127,
    deaths: 2,
    date: "2026-03-15T08:00:00Z",
    message: "Augmentation significative des cas de dengue dans la region de Dakar. Renforcement de la surveillance entomologique recommande.",
  },
  {
    id: "ea-02",
    disease: "Paludisme",
    region: "Kedougou",
    level: "pre_alerte",
    cases: 89,
    casesLastWeek: 72,
    deaths: 1,
    date: "2026-03-14T14:00:00Z",
    message: "Hausse saisonniere des cas de paludisme observee. Les equipes de terrain sont mobilisees.",
  },
  {
    id: "ea-03",
    disease: "Meningite",
    region: "Saint-Louis",
    level: "vigilance",
    cases: 12,
    casesLastWeek: 8,
    deaths: 0,
    date: "2026-03-14T10:00:00Z",
    message: "Quelques cas de meningite rapportes. Situation sous surveillance rapprochee.",
  },
  {
    id: "ea-04",
    disease: "COVID-19",
    region: "National",
    level: "vigilance",
    cases: 34,
    casesLastWeek: 41,
    deaths: 0,
    date: "2026-03-13T16:00:00Z",
    message: "Situation COVID-19 stable. Poursuite de la surveillance genomique des variants.",
  },
];

export const DISEASES_DATA: DiseaseData[] = [
  {
    disease: "Dengue",
    totalCases: 1245,
    activeCases: 156,
    recovered: 1082,
    deaths: 7,
    trend: "up",
    weeklyData: [
      { week: "S6", cases: 45 }, { week: "S7", cases: 52 }, { week: "S8", cases: 78 },
      { week: "S9", cases: 95 }, { week: "S10", cases: 127 }, { week: "S11", cases: 156 },
    ],
  },
  {
    disease: "Paludisme",
    totalCases: 3420,
    activeCases: 89,
    recovered: 3298,
    deaths: 33,
    trend: "up",
    weeklyData: [
      { week: "S6", cases: 62 }, { week: "S7", cases: 58 }, { week: "S8", cases: 55 },
      { week: "S9", cases: 64 }, { week: "S10", cases: 72 }, { week: "S11", cases: 89 },
    ],
  },
  {
    disease: "Meningite",
    totalCases: 87,
    activeCases: 12,
    recovered: 72,
    deaths: 3,
    trend: "stable",
    weeklyData: [
      { week: "S6", cases: 5 }, { week: "S7", cases: 8 }, { week: "S8", cases: 6 },
      { week: "S9", cases: 10 }, { week: "S10", cases: 8 }, { week: "S11", cases: 12 },
    ],
  },
  {
    disease: "COVID-19",
    totalCases: 12560,
    activeCases: 34,
    recovered: 12380,
    deaths: 146,
    trend: "down",
    weeklyData: [
      { week: "S6", cases: 78 }, { week: "S7", cases: 65 }, { week: "S8", cases: 52 },
      { week: "S9", cases: 48 }, { week: "S10", cases: 41 }, { week: "S11", cases: 34 },
    ],
  },
];

export const REGIONS_DATA: RegionData[] = [
  { name: "Dakar", code: "DK", cases: 156, alertLevel: "high", x: 17, y: 30, lat: 14.7167, lng: -17.4677 },
  { name: "Thies", code: "TH", cases: 42, alertLevel: "medium", x: 23, y: 32, lat: 14.7886, lng: -16.9260 },
  { name: "Saint-Louis", code: "SL", cases: 28, alertLevel: "medium", x: 25, y: 15, lat: 16.0326, lng: -16.4881 },
  { name: "Ziguinchor", code: "ZG", cases: 18, alertLevel: "low", x: 20, y: 60, lat: 12.5681, lng: -16.2719 },
  { name: "Kaolack", code: "KL", cases: 35, alertLevel: "medium", x: 30, y: 40, lat: 14.1652, lng: -16.0756 },
  { name: "Kedougou", code: "KD", cases: 89, alertLevel: "high", x: 55, y: 55, lat: 12.5605, lng: -12.1747 },
  { name: "Tambacounda", code: "TC", cases: 22, alertLevel: "low", x: 50, y: 42, lat: 13.7709, lng: -13.6673 },
  { name: "Matam", code: "MT", cases: 15, alertLevel: "low", x: 48, y: 20, lat: 15.6559, lng: -13.2554 },
  { name: "Fatick", code: "FK", cases: 12, alertLevel: "low", x: 28, y: 42, lat: 14.3390, lng: -16.4111 },
  { name: "Diourbel", code: "DB", cases: 20, alertLevel: "low", x: 28, y: 30, lat: 14.6549, lng: -16.2314 },
  { name: "Louga", code: "LG", cases: 8, alertLevel: "none", x: 27, y: 20, lat: 15.6166, lng: -16.2237 },
  { name: "Kolda", code: "KA", cases: 25, alertLevel: "low", x: 38, y: 58, lat: 12.8835, lng: -14.9501 },
  { name: "Sedhiou", code: "SD", cases: 10, alertLevel: "none", x: 30, y: 58, lat: 12.7081, lng: -15.5569 },
  { name: "Kaffrine", code: "KF", cases: 14, alertLevel: "low", x: 38, y: 38, lat: 14.1058, lng: -15.5505 },
];

export const SURVEILLANCE_KPIS = [
  { label: "Cas actifs totaux", value: 291, previousValue: 248, trend: "up" as const, color: "#ef4444" },
  { label: "Alertes en cours", value: 3, previousValue: 2, trend: "up" as const, color: "#f59e0b" },
  { label: "Regions surveillees", value: 14, previousValue: 14, trend: "stable" as const, color: "#06b6d4" },
  { label: "Taux de reactivite", value: 97, previousValue: 95, unit: "%", trend: "up" as const, color: "#10b981" },
];
