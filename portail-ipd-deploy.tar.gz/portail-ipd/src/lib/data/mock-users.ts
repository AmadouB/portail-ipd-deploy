import { type User } from "@/types";
import { verifyPassword } from "@/lib/security/password";

// All passwords are pre-hashed with bcrypt (10 rounds)
// Original passwords are NEVER stored in source code
export const MOCK_USERS: User[] = [
  {
    id: "usr-001",
    email: "ibrahima.fall@pasteur.sn",
    password: "$2b$10$7kqZ5hV.7RlaW27mCWZAO.zeQeWN1TKXo6i0RkUBG3fu46s1Sd2Pm",
    firstName: "Ibrahima",
    lastName: "Soce Fall",
    role: "admin_general",
    pole: "tous",
    department: "Direction Generale",
    title: "Directeur General",
    isActive: true,
    lastLogin: "",
    mfaEnabled: true,
  },
  {
    id: "usr-002",
    email: "sophie.diallo@pasteur.sn",
    password: "$2b$10$YBiuLIHbDQQyBrTex412B.je7Yoh1LdG6ZqtaO5QhB8j6hWfYp2Dy",
    firstName: "Sophie",
    lastName: "Diallo",
    role: "admin_general",
    pole: "tous",
    department: "Administration et Finance",
    title: "Chargee de projet",
    isActive: true,
    lastLogin: "",
    mfaEnabled: false,
  },
  {
    id: "usr-003",
    email: "fatoumata.niang@pasteur.sn",
    password: "$2b$10$UBY1xnTY4XtQmB0/zkqZleSHg8y75XjkcRVJEvOnSB6kPVa1nGsZO",
    firstName: "Fatoumata",
    lastName: "Niang",
    role: "utilisateur",
    pole: "tous",
    department: "Capital Humain",
    title: "Responsable RH",
    isActive: true,
    lastLogin: "",
    mfaEnabled: false,
  },
  {
    id: "usr-004",
    email: "seid@pasteur.sn",
    password: "$2b$10$xfX1PF/R2OuFUIkxotH74uAEClBGibD9M5.Am97Iz0O.ktKKp0u/S",
    firstName: "SEID",
    lastName: "IPD",
    role: "utilisateur",
    pole: "tous",
    department: "Cellule SEID",
    title: "Operateur SEID",
    isActive: true,
    lastLogin: "",
    mfaEnabled: false,
  },
  {
    id: "usr-005",
    email: "lamine.traore@pasteur.sn",
    password: "$2b$10$W.kfS6C9ysV5YLa.YaWHv.1hRNnjP0qLa3HNhzOgXTNQOvxe..iFO",
    firstName: "Lamine",
    lastName: "Traore",
    role: "admin_general",
    pole: "tous",
    department: "Direction Generale",
    title: "Administrateur",
    isActive: true,
    lastLogin: "",
    mfaEnabled: false,
  },
];

/** Authenticate user with bcrypt hash verification (async) */
export async function authenticateUser(email: string, password: string): Promise<User | null> {
  const user = MOCK_USERS.find(
    (u) => u.email.toLowerCase() === email.toLowerCase() && u.isActive
  );
  if (!user) return null;

  const match = await verifyPassword(password, user.password);
  return match ? user : null;
}
