import { type KpiData, type ChartDataPoint } from "@/types";

export const COCKPIT_KPIS: KpiData[] = [
  { label: "Budget Global Execute", value: 78, previousValue: 71, unit: "%", trend: "up", color: "#06b6d4" },
  { label: "Taux de Conformite", value: 94, previousValue: 91, unit: "%", trend: "up", color: "#10b981" },
  { label: "Projets Actifs", value: 42, previousValue: 38, trend: "up", color: "#8b5cf6" },
  { label: "Effectif Total", value: 487, previousValue: 472, trend: "up", color: "#f59e0b" },
  { label: "Publications", value: 23, previousValue: 19, trend: "up", color: "#ec4899" },
  { label: "Alertes Critiques", value: 2, previousValue: 5, trend: "down", color: "#ef4444" },
];

export const BUDGET_BY_POLE: ChartDataPoint[] = [
  { name: "Gouvernance", alloue: 2500, consomme: 1875, taux: 75 },
  { name: "Metiers", alloue: 8500, consomme: 7225, taux: 85 },
  { name: "Partenariat", alloue: 1200, consomme: 780, taux: 65 },
  { name: "Operations", alloue: 3800, consomme: 2850, taux: 75 },
];

export const PERFORMANCE_POLES = [
  { pole: "Gouvernance", kpiAtteints: 85, projetsATerme: 90, satisfaction: 88, conformite: 95 },
  { pole: "Metiers", kpiAtteints: 78, projetsATerme: 72, satisfaction: 82, conformite: 94 },
  { pole: "Partenariat", kpiAtteints: 70, projetsATerme: 80, satisfaction: 75, conformite: 88 },
  { pole: "Operations", kpiAtteints: 82, projetsATerme: 85, satisfaction: 80, conformite: 92 },
];

export const STRATEGIC_INDICATORS = [
  { id: "ind-01", label: "Production vaccins Fievre Jaune", target: 15000000, current: 11250000, unit: "doses", status: "on_track" as const },
  { id: "ind-02", label: "Certification OMS site Diamniadio", target: 100, current: 72, unit: "%", status: "on_track" as const },
  { id: "ind-03", label: "Digitalisation processus internes", target: 100, current: 45, unit: "%", status: "at_risk" as const },
  { id: "ind-04", label: "Taux couverture partenariats", target: 50, current: 34, unit: "partenaires", status: "on_track" as const },
  { id: "ind-05", label: "Formation personnel (heures/ETP)", target: 40, current: 28, unit: "h/ETP", status: "on_track" as const },
  { id: "ind-06", label: "Revenu diversifie (hors vaccins)", target: 30, current: 18, unit: "%", status: "at_risk" as const },
  { id: "ind-07", label: "Indice satisfaction collaborateurs", target: 80, current: 76, unit: "%", status: "on_track" as const },
  { id: "ind-08", label: "Delai moyen recrutement", target: 45, current: 52, unit: "jours", status: "delayed" as const },
];

export const MONTHLY_TREND: ChartDataPoint[] = [
  { name: "Oct", budget: 58, conformite: 88, projets: 32 },
  { name: "Nov", budget: 63, conformite: 90, projets: 35 },
  { name: "Dec", budget: 67, conformite: 89, projets: 36 },
  { name: "Jan", budget: 70, conformite: 91, projets: 38 },
  { name: "Fev", budget: 74, conformite: 93, projets: 40 },
  { name: "Mar", budget: 78, conformite: 94, projets: 42 },
];
