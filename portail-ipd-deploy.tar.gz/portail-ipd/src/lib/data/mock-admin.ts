import { type AuditLog } from "@/types";
import { MOCK_USERS } from "./mock-users";

export const ADMIN_USERS = MOCK_USERS.map(({ password, ...u }) => u);

export const AUDIT_LOGS: AuditLog[] = [
  { id: "log-001", userId: "usr-001", userName: "Amadou Sall", action: "login", module: "auth", detail: "Connexion reussie", ipAddress: "192.168.1.10", timestamp: "2026-03-15T08:30:00Z" },
  { id: "log-002", userId: "usr-002", userName: "Amadou Bao", action: "view", module: "seid", detail: "Consultation Command Center", ipAddress: "192.168.1.25", timestamp: "2026-03-15T09:15:00Z" },
  { id: "log-003", userId: "usr-004", userName: "Ndeye Coumba Toure", action: "view", module: "surveillance", detail: "Consultation alertes epidemiologiques", ipAddress: "192.168.1.42", timestamp: "2026-03-15T07:45:00Z" },
  { id: "log-004", userId: "usr-005", userName: "Moussa Ndiaye", action: "update", module: "admin", detail: "Modification droits utilisateur usr-006", ipAddress: "192.168.1.15", timestamp: "2026-03-15T08:00:00Z" },
  { id: "log-005", userId: "usr-001", userName: "Amadou Sall", action: "view", module: "cockpit", detail: "Consultation cockpit strategique", ipAddress: "192.168.1.10", timestamp: "2026-03-15T08:35:00Z" },
  { id: "log-006", userId: "usr-003", userName: "Fatou Diagne", action: "export", module: "cockpit", detail: "Export rapport indicateurs Q1", ipAddress: "192.168.1.30", timestamp: "2026-03-14T16:20:00Z" },
  { id: "log-007", userId: "usr-002", userName: "Amadou Bao", action: "create", module: "seid", detail: "Creation nouvelle evaluation SEID-2026-Q1", ipAddress: "192.168.1.25", timestamp: "2026-03-14T14:00:00Z" },
  { id: "log-008", userId: "usr-005", userName: "Moussa Ndiaye", action: "update", module: "system", detail: "Mise a jour certificat SSL", ipAddress: "192.168.1.15", timestamp: "2026-03-14T11:30:00Z" },
  { id: "log-009", userId: "usr-006", userName: "Ibrahima Fall", action: "login", module: "auth", detail: "Connexion reussie", ipAddress: "192.168.1.55", timestamp: "2026-03-14T16:30:00Z" },
  { id: "log-010", userId: "usr-004", userName: "Ndeye Coumba Toure", action: "view", module: "surveillance", detail: "Consultation carte epidemiologique", ipAddress: "192.168.1.42", timestamp: "2026-03-14T10:00:00Z" },
  { id: "log-011", userId: "usr-001", userName: "Amadou Sall", action: "logout", module: "auth", detail: "Deconnexion", ipAddress: "192.168.1.10", timestamp: "2026-03-14T18:00:00Z" },
  { id: "log-012", userId: "usr-005", userName: "Moussa Ndiaye", action: "view", module: "admin", detail: "Consultation journal d'audit", ipAddress: "192.168.1.15", timestamp: "2026-03-14T09:00:00Z" },
];

export const SYSTEM_SERVICES = [
  { name: "API Gateway", status: "online" as const, uptime: 99.97, cpu: 12, memory: 34, responseTime: 45 },
  { name: "PostgreSQL", status: "online" as const, uptime: 99.99, cpu: 28, memory: 62, responseTime: 8 },
  { name: "Redis Cache", status: "online" as const, uptime: 99.99, cpu: 5, memory: 18, responseTime: 2 },
  { name: "Keycloak Auth", status: "online" as const, uptime: 99.95, cpu: 15, memory: 45, responseTime: 120 },
  { name: "ELK Stack", status: "online" as const, uptime: 99.90, cpu: 35, memory: 72, responseTime: 200 },
  { name: "MinIO Storage", status: "online" as const, uptime: 99.98, cpu: 8, memory: 22, responseTime: 15 },
];
