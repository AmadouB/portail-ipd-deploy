export interface AppStatus {
  id: string;
  name: string;
  domain: string;
  status: "online" | "offline" | "degraded";
  uptime: number;
  lastSync: string;
  dataFlow: number;
  technology: string;
}

export interface DataQualityMetric {
  source: string;
  completeness: number;
  freshness: number;
  consistency: number;
  overall: number;
}

export interface EvaluationItem {
  id: string;
  title: string;
  department: string;
  progress: number;
  dueDate: string;
  status: "en_cours" | "planifie" | "termine" | "en_retard";
}

export const APP_STATUS: AppStatus[] = [
  { id: "app-01", name: "LIMS Laboratoire", domain: "Recherche", status: "online", uptime: 99.8, lastSync: "2026-03-15T10:00:00Z", dataFlow: 1250, technology: "React" },
  { id: "app-02", name: "ERP Production", domain: "Production", status: "online", uptime: 99.5, lastSync: "2026-03-15T09:55:00Z", dataFlow: 3400, technology: "Legacy" },
  { id: "app-03", name: "SIRH KWAME", domain: "RH", status: "online", uptime: 98.9, lastSync: "2026-03-15T09:30:00Z", dataFlow: 890, technology: "React" },
  { id: "app-04", name: "Comptabilite SAGE", domain: "Finance", status: "online", uptime: 99.2, lastSync: "2026-03-15T08:00:00Z", dataFlow: 2100, technology: "Legacy" },
  { id: "app-05", name: "CRM Partenaires", domain: "Partenariat", status: "online", uptime: 97.8, lastSync: "2026-03-15T10:05:00Z", dataFlow: 450, technology: "React" },
  { id: "app-06", name: "DPC Surveillance", domain: "Sante Publique", status: "online", uptime: 99.9, lastSync: "2026-03-15T10:10:00Z", dataFlow: 5600, technology: "React" },
  { id: "app-07", name: "Grant Management", domain: "Recherche", status: "online", uptime: 99.1, lastSync: "2026-03-15T09:45:00Z", dataFlow: 780, technology: "React" },
  { id: "app-08", name: "IMS Qualite", domain: "Production", status: "degraded", uptime: 94.5, lastSync: "2026-03-15T07:00:00Z", dataFlow: 320, technology: "HTML" },
  { id: "app-09", name: "Formation LMS", domain: "RH", status: "online", uptime: 98.2, lastSync: "2026-03-15T08:30:00Z", dataFlow: 150, technology: "HTML" },
  { id: "app-10", name: "Portail Fournisseurs", domain: "Logistique", status: "online", uptime: 97.5, lastSync: "2026-03-15T09:00:00Z", dataFlow: 670, technology: "HTML" },
  { id: "app-11", name: "Gestion Stocks", domain: "Logistique", status: "online", uptime: 98.8, lastSync: "2026-03-15T10:00:00Z", dataFlow: 1800, technology: "Legacy" },
  { id: "app-12", name: "Documentation GED", domain: "Transversal", status: "offline", uptime: 0, lastSync: "2026-03-14T22:00:00Z", dataFlow: 0, technology: "HTML" },
  { id: "app-13", name: "Bioinformatique", domain: "Recherche", status: "online", uptime: 99.7, lastSync: "2026-03-15T10:08:00Z", dataFlow: 4200, technology: "Python" },
  { id: "app-14", name: "Biobanque LIMS", domain: "Recherche", status: "online", uptime: 99.4, lastSync: "2026-03-15T09:50:00Z", dataFlow: 920, technology: "React" },
];

export const DATA_QUALITY: DataQualityMetric[] = [
  { source: "Production", completeness: 96, freshness: 98, consistency: 92, overall: 95 },
  { source: "Recherche", completeness: 88, freshness: 85, consistency: 90, overall: 88 },
  { source: "RH", completeness: 92, freshness: 78, consistency: 94, overall: 88 },
  { source: "Finance", completeness: 99, freshness: 95, consistency: 97, overall: 97 },
  { source: "Sante Publique", completeness: 94, freshness: 99, consistency: 91, overall: 95 },
  { source: "Logistique", completeness: 85, freshness: 82, consistency: 86, overall: 84 },
];

export const EVALUATIONS: EvaluationItem[] = [
  { id: "eval-01", title: "Evaluation Contrat de Performance Q1", department: "SEID", progress: 75, dueDate: "2026-03-31", status: "en_cours" },
  { id: "eval-02", title: "Audit conformite OMS site Diamniadio", department: "Production", progress: 45, dueDate: "2026-04-15", status: "en_cours" },
  { id: "eval-03", title: "Revue annuelle securite SI", department: "DSI", progress: 100, dueDate: "2026-02-28", status: "termine" },
  { id: "eval-04", title: "Evaluation impact programme Madiba", department: "Recherche", progress: 20, dueDate: "2026-05-30", status: "planifie" },
  { id: "eval-05", title: "Audit acces et droits trimestriel", department: "DSI", progress: 10, dueDate: "2026-03-25", status: "en_retard" },
  { id: "eval-06", title: "Bilan formation annuel 2025", department: "RH", progress: 90, dueDate: "2026-03-20", status: "en_cours" },
];

export const KPI_MATRIX = [
  { department: "Production", kpis: [{ label: "Rendement", value: 92, target: 95 }, { label: "Conformite", value: 98, target: 100 }, { label: "Delai", value: 85, target: 90 }] },
  { department: "Recherche", kpis: [{ label: "Publications", value: 78, target: 80 }, { label: "Grants", value: 85, target: 90 }, { label: "Impact", value: 72, target: 75 }] },
  { department: "Sante Pub.", kpis: [{ label: "Couverture", value: 94, target: 95 }, { label: "Reactivite", value: 97, target: 98 }, { label: "Detection", value: 91, target: 95 }] },
  { department: "RH", kpis: [{ label: "Retention", value: 88, target: 90 }, { label: "Formation", value: 70, target: 85 }, { label: "Satisfaction", value: 76, target: 80 }] },
  { department: "Finance", kpis: [{ label: "Execution", value: 78, target: 85 }, { label: "Recouvrement", value: 92, target: 95 }, { label: "Reporting", value: 95, target: 95 }] },
  { department: "DSI", kpis: [{ label: "Disponibilite", value: 99, target: 99.5 }, { label: "Incidents", value: 85, target: 90 }, { label: "Projets", value: 80, target: 85 }] },
];
