"use client";

import { create } from "zustand";
import { type Notification } from "@/types";

interface NotificationState {
  notifications: Notification[];
  unreadCount: number;
  setNotifications: (notifications: Notification[]) => void;
  loadNotifications: () => void;
  markAsRead: (id: string) => void;
  markAllAsRead: () => void;
}

export const useNotificationStore = create<NotificationState>((set, get) => ({
  notifications: [],
  unreadCount: 0,

  setNotifications: (notifications) =>
    set({ notifications, unreadCount: notifications.filter((n) => !n.read).length }),

  loadNotifications: async () => {
    try {
      const res = await fetch("/api/notifications");
      if (res.ok) {
        const notifications = await res.json();
        set({ notifications, unreadCount: notifications.filter((n: Notification) => !n.read).length });
        return;
      }
    } catch { /* API not available */ }
    // Fallback: load mock notifications if API unavailable
    try {
      const { MOCK_NOTIFICATIONS } = await import("@/lib/data/mock-notifications");
      set({ notifications: MOCK_NOTIFICATIONS, unreadCount: MOCK_NOTIFICATIONS.filter((n) => !n.read).length });
    } catch { /* ignore */ }
  },

  markAsRead: (id) => {
    fetch(`/api/notifications/${id}/read`, { method: "PATCH" }).catch(() => {});
    const notifications = get().notifications.map((n) => (n.id === id ? { ...n, read: true } : n));
    set({ notifications, unreadCount: notifications.filter((n) => !n.read).length });
  },

  markAllAsRead: () => {
    fetch("/api/notifications/read-all", { method: "POST" }).catch(() => {});
    const notifications = get().notifications.map((n) => ({ ...n, read: true }));
    set({ notifications, unreadCount: 0 });
  },
}));
