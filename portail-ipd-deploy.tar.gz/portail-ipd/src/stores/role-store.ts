"use client";

import { create } from "zustand";
import { type RoleName, type ModuleId, type Permission, type Pole } from "@/types";
import { ROLE_PERMISSIONS } from "@/lib/rbac";

export interface RoleConfig {
  id: RoleName;
  label: string;
  poles: (Pole | "tous")[];
  modules: Record<string, Permission[]>;
}

interface RoleStore {
  roles: RoleConfig[];
  loadRoles: () => void;
  addRole: (role: RoleConfig) => void;
  updateRole: (id: string, updates: Partial<RoleConfig>) => void;
  deleteRole: (id: string) => void;
  setModulePermission: (roleId: string, moduleId: string, permissions: Permission[]) => void;
  removeModulePermission: (roleId: string, moduleId: string) => void;
}

const initialRoles: RoleConfig[] = Object.entries(ROLE_PERMISSIONS).map(([id, config]) => ({
  id: id as RoleName,
  label: {
    admin_general: "Administrateur General", cas: "Cellule Appui Strategique",
    seid: "SEID - Consultant", dsi: "Direction SI", dir_production: "Direction Production",
    dir_recherche: "Direction Recherche", dir_sante_publique: "Direction Sante Publique",
    dir_partenariat: "Direction Partenariat", drh: "Direction RH",
    daf: "Direction Administrative et Financiere", utilisateur: "Utilisateur",
  }[id] || id,
  poles: config.poles,
  modules: config.modules as Record<string, Permission[]>,
}));

export const useRoleStore = create<RoleStore>((set, get) => ({
  roles: initialRoles,

  loadRoles: () => { /* Roles already loaded from static RBAC */ },

  addRole: (role) => set((state) => ({ roles: [...state.roles, role] })),

  updateRole: (id, updates) =>
    set((state) => ({ roles: state.roles.map((r) => (r.id === id ? { ...r, ...updates } : r)) })),

  deleteRole: (id) =>
    set((state) => ({ roles: state.roles.filter((r) => r.id !== id) })),

  setModulePermission: (roleId, moduleId, permissions) =>
    set((state) => ({
      roles: state.roles.map((r) =>
        r.id === roleId ? { ...r, modules: { ...r.modules, [moduleId]: permissions } } : r
      ),
    })),

  removeModulePermission: (roleId, moduleId) =>
    set((state) => ({
      roles: state.roles.map((r) => {
        if (r.id !== roleId) return r;
        const { [moduleId]: _, ...rest } = r.modules;
        return { ...r, modules: rest };
      }),
    })),
}));
