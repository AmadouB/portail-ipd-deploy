"use client";

import { create } from "zustand";
import { type ModuleConfig } from "@/types";
import { MODULES } from "@/lib/data/mock-modules";

interface ModuleStore {
  modules: ModuleConfig[];
  _initialized: boolean;
  _publishedLoaded: boolean;
  loadModules: () => void;
  addModule: (module: ModuleConfig) => void;
  updateModule: (id: string, updates: Partial<ModuleConfig>) => void;
  deleteModule: (id: string) => void;
  toggleModule: (id: string) => void;
}

function persistModules(modules: ModuleConfig[]) {
  if (typeof window === "undefined") return;
  try { localStorage.setItem("ipd_modules", JSON.stringify(modules)); } catch {}
}

function loadFromStorage(): ModuleConfig[] | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = localStorage.getItem("ipd_modules");
    return raw ? JSON.parse(raw) : null;
  } catch { return null; }
}

async function fetchPublished(): Promise<ModuleConfig[]> {
  try {
    const res = await fetch("/data/custom-modules.json");
    if (res.ok) return await res.json();
  } catch {}
  return [];
}

export const useModuleStore = create<ModuleStore>((set, get) => ({
  modules: MODULES,
  _initialized: false,
  _publishedLoaded: false,

  loadModules: () => {
    if (get()._initialized) return;
    const stored = loadFromStorage();
    if (stored) set({ modules: stored, _initialized: true });
    else set({ _initialized: true });

    if (!get()._publishedLoaded) {
      fetchPublished().then((published) => {
        if (published.length > 0) {
          set((state) => {
            const existingIds = new Set(state.modules.map((m) => m.id));
            const newModules = published.filter((m) => !existingIds.has(m.id));
            if (newModules.length > 0) {
              const merged = [...state.modules, ...newModules];
              persistModules(merged);
              return { modules: merged, _publishedLoaded: true };
            }
            return { _publishedLoaded: true };
          });
        } else {
          set({ _publishedLoaded: true });
        }
      });
    }
  },

  addModule: (module) => {
    set((state) => { const m = [...state.modules, module]; persistModules(m); return { modules: m }; });
  },
  updateModule: (id, updates) => {
    set((state) => { const m = state.modules.map((mod) => (mod.id === id ? { ...mod, ...updates } : mod)); persistModules(m); return { modules: m }; });
  },
  deleteModule: (id) => {
    set((state) => { const m = state.modules.filter((mod) => mod.id !== id); persistModules(m); return { modules: m }; });
  },
  toggleModule: (id) => {
    set((state) => { const m = state.modules.map((mod) => (mod.id === id ? { ...mod, enabled: !mod.enabled } : mod)); persistModules(m); return { modules: m }; });
  },
}));
