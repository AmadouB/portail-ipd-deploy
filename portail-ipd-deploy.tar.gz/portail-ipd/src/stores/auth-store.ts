"use client";

import { create } from "zustand";
import { type UserSession } from "@/types";
import { authenticateUser } from "@/lib/data/mock-users";
import { isLockedOut, recordFailedAttempt, clearAttempts, formatRemainingTime } from "@/lib/security/rate-limiter";
import { logAuthEvent, logFailedLogin, logLockout } from "@/lib/security/audit";

/** Generate a simple session fingerprint */
function getSessionFingerprint(): string {
  if (typeof window === "undefined") return "";
  const ua = navigator.userAgent || "";
  const screen = `${window.screen.width}x${window.screen.height}`;
  const raw = `${ua}|${screen}`;
  let hash = 0;
  for (let i = 0; i < raw.length; i++) {
    hash = ((hash << 5) - hash + raw.charCodeAt(i)) | 0;
  }
  return hash.toString(36);
}

/** Try server API login, return null if API unavailable */
async function tryApiLogin(email: string, password: string): Promise<{ token: string; session: UserSession } | null> {
  try {
    const res = await fetch("/api/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    });
    if (res.ok) return await res.json();
    if (res.status === 401 || res.status === 423) {
      const data = await res.json().catch(() => null);
      if (data?.lockout) return null; // Will fall through to client-side
      throw { status: res.status, data };
    }
    return null; // API error, fall through to client-side
  } catch (err) {
    // Network error or API not available — use client-side auth
    if (err && typeof err === "object" && "status" in err) throw err;
    return null;
  }
}

interface AuthState {
  session: UserSession | null;
  isLoading: boolean;
  lockoutMessage: string | null;
  login: (email: string, password: string) => Promise<boolean>;
  logout: () => void;
  loadSession: () => void;
  checkSessionValidity: () => void;
}

export const useAuthStore = create<AuthState>((set, get) => ({
  session: null,
  isLoading: true,
  lockoutMessage: null,

  login: async (email: string, password: string) => {
    try {
      set({ lockoutMessage: null });

      // 1) Try server API first (PostgreSQL mode)
      try {
        const apiResult = await tryApiLogin(email, password);
        if (apiResult) {
          localStorage.setItem("ipd_token", apiResult.token);
          localStorage.setItem("ipd_session", JSON.stringify(apiResult.session));
          document.cookie = `ipd_token=${apiResult.token}; path=/; max-age=86400; SameSite=Strict`;
          set({ session: apiResult.session });
          return true;
        }
      } catch (apiErr: unknown) {
        // API returned a specific error (401/423)
        if (apiErr && typeof apiErr === "object" && "status" in apiErr) {
          const err = apiErr as { status: number; data?: { message?: string; lockout?: boolean } };
          if (err.status === 423 || err.data?.lockout) {
            set({ lockoutMessage: err.data?.message || "Compte temporairement verrouille." });
          }
          return false;
        }
      }

      // 2) Fallback: Client-side auth (static export / Hostinger mode)
      const lockStatus = isLockedOut(email);
      if (lockStatus.locked) {
        const remaining = formatRemainingTime(lockStatus.remainingMs);
        set({ lockoutMessage: `Compte temporairement verrouille. Reessayez dans ${remaining}.` });
        return false;
      }

      const mockUser = await authenticateUser(email, password);
      if (mockUser) {
        const { password: _, ...safeUser } = mockUser;
        const fingerprint = getSessionFingerprint();
        const token = `ipd_${mockUser.id}_${Date.now()}_${fingerprint}`;
        const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString();
        const session: UserSession = { user: safeUser, token, expiresAt };
        localStorage.setItem("ipd_session", JSON.stringify(session));
        document.cookie = `ipd_token=${token}; path=/; max-age=86400; SameSite=Strict`;
        set({ session });
        clearAttempts(email);
        logAuthEvent(mockUser.id, `${mockUser.firstName} ${mockUser.lastName}`, "login", "Connexion reussie");
        return true;
      }

      // Failed
      logFailedLogin(email);
      const nowLocked = recordFailedAttempt(email);
      if (nowLocked) {
        logLockout(email);
        const lock = isLockedOut(email);
        set({ lockoutMessage: `Trop de tentatives echouees. Compte verrouille pendant ${formatRemainingTime(lock.remainingMs)}.` });
      }
      return false;
    } catch (err) {
      console.error("[IPD Auth] Login error:", err);
      return false;
    }
  },

  logout: () => {
    const session = get().session;
    if (session) {
      logAuthEvent(session.user.id, `${session.user.firstName} ${session.user.lastName}`, "logout", "Deconnexion");
    }
    // Try API logout (best effort)
    fetch("/api/auth/logout", { method: "POST" }).catch(() => {});
    localStorage.removeItem("ipd_session");
    localStorage.removeItem("ipd_token");
    document.cookie = "ipd_token=; path=/; max-age=0";
    set({ session: null, lockoutMessage: null });
    window.location.href = "/login";
  },

  loadSession: () => {
    try {
      const stored = localStorage.getItem("ipd_session");
      if (stored) {
        const session: UserSession = JSON.parse(stored);
        if (new Date(session.expiresAt) > new Date()) {
          set({ session, isLoading: false });
          return;
        }
        localStorage.removeItem("ipd_session");
      }
    } catch { /* ignore */ }
    set({ session: null, isLoading: false });
  },

  checkSessionValidity: () => {
    const session = get().session;
    if (!session) return;
    if (new Date(session.expiresAt) <= new Date()) {
      localStorage.removeItem("ipd_session");
      document.cookie = "ipd_token=; path=/; max-age=0";
      set({ session: null });
      window.location.href = "/login";
    }
  },
}));
