"use client";

import { create } from "zustand";
import { type User } from "@/types";
import { MOCK_USERS } from "@/lib/data/mock-users";
import { hashPassword, verifyPassword, generateStrongPassword } from "@/lib/security/password";

export type AdminUser = Omit<User, "password">;

interface UserStore {
  users: AdminUser[];
  passwordHashes: Record<string, string>;
  _initialized: boolean;
  addUser: (user: AdminUser, passwordHash: string) => void;
  updateUser: (id: string, updates: Partial<AdminUser>) => void;
  deleteUser: (id: string) => void;
  toggleUserActive: (id: string) => void;
  resetPassword: (id: string) => Promise<{ plainPassword: string; hash: string }>;
  setPasswordHash: (id: string, hash: string) => void;
  authenticate: (email: string, password: string) => Promise<AdminUser | null>;
  loadUsers: () => void;
}

const mockUsers: AdminUser[] = MOCK_USERS.map(({ password, ...u }) => u);
const mockHashes: Record<string, string> = {};
for (const u of MOCK_USERS) {
  mockHashes[u.id] = u.password;
}

function persistToStorage(users: AdminUser[], passwordHashes: Record<string, string>) {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem("ipd_users", JSON.stringify(users));
    localStorage.setItem("ipd_password_hashes", JSON.stringify(passwordHashes));
    localStorage.removeItem("ipd_passwords");
  } catch { /* ignore */ }
}

function loadFromStorage(): { users: AdminUser[]; passwordHashes: Record<string, string> } | null {
  if (typeof window === "undefined") return null;
  try {
    const usersStr = localStorage.getItem("ipd_users");
    const hashStr = localStorage.getItem("ipd_password_hashes") || localStorage.getItem("ipd_passwords");
    if (usersStr && hashStr) {
      return { users: JSON.parse(usersStr), passwordHashes: JSON.parse(hashStr) };
    }
  } catch { /* ignore */ }
  return null;
}

function ensureInitialized(set: (s: Partial<UserStore>) => void, get: () => UserStore) {
  if (get()._initialized) return;
  const stored = loadFromStorage();
  if (stored) {
    set({ users: stored.users, passwordHashes: stored.passwordHashes, _initialized: true });
  } else {
    set({ _initialized: true });
  }
}

export const useUserStore = create<UserStore>((set, get) => ({
  users: mockUsers,
  passwordHashes: mockHashes,
  _initialized: false,

  loadUsers: () => { ensureInitialized(set, get); },

  addUser: (user, passwordHash) => {
    ensureInitialized(set, get);
    set((state) => {
      const newUsers = [...state.users, user];
      const newHashes = { ...state.passwordHashes, [user.id]: passwordHash };
      persistToStorage(newUsers, newHashes);
      return { users: newUsers, passwordHashes: newHashes };
    });
  },

  updateUser: (id, updates) => {
    ensureInitialized(set, get);
    set((state) => {
      const newUsers = state.users.map((u) => (u.id === id ? { ...u, ...updates } : u));
      persistToStorage(newUsers, state.passwordHashes);
      return { users: newUsers };
    });
  },

  deleteUser: (id) => {
    ensureInitialized(set, get);
    set((state) => {
      const { [id]: _, ...restHashes } = state.passwordHashes;
      const newUsers = state.users.filter((u) => u.id !== id);
      persistToStorage(newUsers, restHashes);
      return { users: newUsers, passwordHashes: restHashes };
    });
  },

  toggleUserActive: (id) => {
    ensureInitialized(set, get);
    set((state) => {
      const newUsers = state.users.map((u) => (u.id === id ? { ...u, isActive: !u.isActive } : u));
      persistToStorage(newUsers, state.passwordHashes);
      return { users: newUsers };
    });
  },

  resetPassword: async (id) => {
    ensureInitialized(set, get);
    const plainPassword = generateStrongPassword();
    const hash = await hashPassword(plainPassword);
    set((state) => {
      const newHashes = { ...state.passwordHashes, [id]: hash };
      persistToStorage(state.users, newHashes);
      return { passwordHashes: newHashes };
    });
    return { plainPassword, hash };
  },

  setPasswordHash: (id, hash) => {
    ensureInitialized(set, get);
    set((state) => {
      const newHashes = { ...state.passwordHashes, [id]: hash };
      persistToStorage(state.users, newHashes);
      return { passwordHashes: newHashes };
    });
  },

  authenticate: async (email, password) => {
    const stored = loadFromStorage();
    const users = stored ? stored.users : get().users;
    const hashes = stored ? stored.passwordHashes : get().passwordHashes;
    if (stored && !get()._initialized) {
      set({ users: stored.users, passwordHashes: stored.passwordHashes, _initialized: true });
    }
    const user = users.find((u) => u.email.toLowerCase() === email.toLowerCase() && u.isActive);
    if (!user) return null;
    const storedHash = hashes[user.id];
    if (!storedHash) return null;
    if (storedHash.startsWith("$2b$") || storedHash.startsWith("$2a$")) {
      const match = await verifyPassword(password, storedHash);
      return match ? user : null;
    }
    if (storedHash === password) return user;
    return null;
  },
}));
