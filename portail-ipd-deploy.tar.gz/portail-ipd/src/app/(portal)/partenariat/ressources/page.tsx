"use client";

export default function PartenariatsPage() {
  return (
    <div className="-m-6 h-[calc(100vh-4rem)]">
      <iframe
        src="/modules/partenariat.html"
        className="w-full h-full border-0"
        title="Plateforme de Gestion des Partenariats"
      />
    </div>
  );
}
