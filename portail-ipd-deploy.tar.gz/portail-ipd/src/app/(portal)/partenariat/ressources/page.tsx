"use client";

/**
 * Module Partenariats : pointe vers l'app IMS Partnerships deployee.
 * URL absolue (resolue contre l'origine) car l'app est sur le meme serveur
 * mais en dehors du basePath /portail.
 */
export default function PartenariatsPage() {
  return (
    <div className="-m-6 h-[calc(100vh-4rem)]">
      <iframe
        src="/partnerships"
        className="w-full h-full border-0"
        title="IMS Partnerships - Plateforme de gestion des partenariats"
      />
    </div>
  );
}
