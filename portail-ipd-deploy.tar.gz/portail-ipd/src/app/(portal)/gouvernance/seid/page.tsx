"use client";

import { GlassPanel } from "@/components/shared/glass-panel";
import { StatusBadge } from "@/components/shared/status-badge";
import { APP_STATUS, DATA_QUALITY, EVALUATIONS, KPI_MATRIX } from "@/lib/data/mock-seid";
import { BarChart3, Server, Database, ClipboardCheck, Activity, Wifi, WifiOff } from "lucide-react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell,
} from "recharts";

const statusColors = {
  en_cours: { bg: "bg-cyan-500/10", text: "text-cyan-400", label: "En cours" },
  planifie: { bg: "bg-blue-500/10", text: "text-blue-400", label: "Planifie" },
  termine: { bg: "bg-emerald-500/10", text: "text-emerald-400", label: "Termine" },
  en_retard: { bg: "bg-red-500/10", text: "text-red-400", label: "En retard" },
};

function getQualityColor(val: number): string {
  if (val >= 95) return "#10b981";
  if (val >= 85) return "#06b6d4";
  if (val >= 70) return "#f59e0b";
  return "#ef4444";
}

export default function SEIDPage() {
  const onlineCount = APP_STATUS.filter((a) => a.status === "online").length;
  const degradedCount = APP_STATUS.filter((a) => a.status === "degraded").length;
  const offlineCount = APP_STATUS.filter((a) => a.status === "offline").length;
  const avgUptime = (APP_STATUS.reduce((s, a) => s + a.uptime, 0) / APP_STATUS.length).toFixed(1);

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="flex items-center gap-4">
        <div className="p-3 rounded-xl bg-cyan-500/10">
          <BarChart3 className="h-6 w-6 text-cyan-400" />
        </div>
        <div>
          <h1 className="text-2xl font-bold">SEID - Command Center</h1>
          <p className="text-sm text-muted-foreground">Suivi-Evaluation & Intelligence de Donnees</p>
        </div>
      </motion.div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <GlassPanel glow="cyan" delay={0.1} className="text-center">
          <Server className="h-5 w-5 text-cyan-400 mx-auto mb-2" />
          <p className="text-3xl font-bold">{onlineCount}</p>
          <p className="text-xs text-muted-foreground">Applications en ligne</p>
        </GlassPanel>
        <GlassPanel glow="amber" delay={0.15} className="text-center">
          <Activity className="h-5 w-5 text-amber-400 mx-auto mb-2" />
          <p className="text-3xl font-bold">{degradedCount}</p>
          <p className="text-xs text-muted-foreground">Degradees</p>
        </GlassPanel>
        <GlassPanel glow="red" delay={0.2} className="text-center">
          <WifiOff className="h-5 w-5 text-red-400 mx-auto mb-2" />
          <p className="text-3xl font-bold">{offlineCount}</p>
          <p className="text-xs text-muted-foreground">Hors ligne</p>
        </GlassPanel>
        <GlassPanel glow="emerald" delay={0.25} className="text-center">
          <Wifi className="h-5 w-5 text-emerald-400 mx-auto mb-2" />
          <p className="text-3xl font-bold">{avgUptime}%</p>
          <p className="text-xs text-muted-foreground">Uptime moyen</p>
        </GlassPanel>
      </div>

      {/* Application Status Grid + Data Quality */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* App Status */}
        <GlassPanel delay={0.3} className="lg:col-span-2">
          <h3 className="font-semibold mb-4 flex items-center gap-2">
            <Server className="h-4 w-4 text-cyan-400" />
            Statut des Applications ({APP_STATUS.length})
          </h3>
          <div className="space-y-2 max-h-96 overflow-y-auto pr-2">
            {APP_STATUS.map((app) => (
              <div key={app.id} className="flex items-center gap-3 p-2.5 rounded-lg bg-white/[0.02] hover:bg-white/[0.04] transition-colors">
                <StatusBadge status={app.status === "degraded" ? "warning" : app.status} />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{app.name}</p>
                  <p className="text-[10px] text-muted-foreground">{app.domain} &middot; {app.technology}</p>
                </div>
                <div className="text-right">
                  <p className="text-xs font-mono">{app.uptime}%</p>
                  <p className="text-[10px] text-muted-foreground">{app.dataFlow.toLocaleString()} rec/j</p>
                </div>
              </div>
            ))}
          </div>
        </GlassPanel>

        {/* Data Quality */}
        <GlassPanel delay={0.4}>
          <h3 className="font-semibold mb-4 flex items-center gap-2">
            <Database className="h-4 w-4 text-emerald-400" />
            Qualite des Donnees
          </h3>
          <div className="h-56 mb-4">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={DATA_QUALITY} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
                <XAxis type="number" domain={[0, 100]} tick={{ fill: "rgba(255,255,255,0.5)", fontSize: 10 }} />
                <YAxis dataKey="source" type="category" tick={{ fill: "rgba(255,255,255,0.5)", fontSize: 11 }} width={80} />
                <Tooltip contentStyle={{ backgroundColor: "#111827", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 8 }} />
                <Bar dataKey="overall" name="Score global" radius={[0, 4, 4, 0]}>
                  {DATA_QUALITY.map((entry, i) => (
                    <Cell key={i} fill={getQualityColor(entry.overall)} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
          <div className="space-y-2">
            {DATA_QUALITY.map((dq) => (
              <div key={dq.source} className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground">{dq.source}</span>
                <div className="flex items-center gap-3">
                  <span title="Completude">{dq.completeness}%</span>
                  <span title="Fraicheur">{dq.freshness}%</span>
                  <span title="Coherence">{dq.consistency}%</span>
                </div>
              </div>
            ))}
          </div>
        </GlassPanel>
      </div>

      {/* Evaluations + KPI Matrix */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Evaluations */}
        <GlassPanel delay={0.5}>
          <h3 className="font-semibold mb-4 flex items-center gap-2">
            <ClipboardCheck className="h-4 w-4 text-purple-400" />
            Evaluations en cours
          </h3>
          <div className="space-y-3">
            {EVALUATIONS.map((ev) => {
              const cfg = statusColors[ev.status];
              return (
                <div key={ev.id} className="p-3 rounded-lg bg-white/[0.02]">
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-sm font-medium">{ev.title}</p>
                    <span className={cn("text-[10px] px-2 py-0.5 rounded-full", cfg.bg, cfg.text)}>
                      {cfg.label}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-xs text-muted-foreground mb-2">
                    <span>{ev.department}</span>
                    <span>Echeance: {new Date(ev.dueDate).toLocaleDateString("fr-FR")}</span>
                  </div>
                  <div className="h-1.5 bg-white/5 rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all duration-700"
                      style={{
                        width: `${ev.progress}%`,
                        backgroundColor: ev.progress >= 75 ? "#10b981" : ev.progress >= 40 ? "#06b6d4" : "#f59e0b",
                      }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </GlassPanel>

        {/* KPI Matrix */}
        <GlassPanel delay={0.6}>
          <h3 className="font-semibold mb-4">Matrice KPIs par Departement</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-white/[0.06]">
                  <th className="text-left py-2 text-xs text-muted-foreground font-medium">Dept.</th>
                  {KPI_MATRIX[0]?.kpis.map((_, i) => (
                    <th key={i} className="text-center py-2 text-xs text-muted-foreground font-medium">
                      KPI {i + 1}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {KPI_MATRIX.map((row) => (
                  <tr key={row.department} className="border-b border-white/[0.03] hover:bg-white/[0.02]">
                    <td className="py-2.5 text-xs font-medium">{row.department}</td>
                    {row.kpis.map((kpi, i) => {
                      const pct = Math.round((kpi.value / kpi.target) * 100);
                      return (
                        <td key={i} className="text-center py-2.5">
                          <div className="inline-flex flex-col items-center">
                            <span
                              className="text-xs font-bold"
                              style={{ color: getQualityColor(pct) }}
                            >
                              {kpi.value}
                            </span>
                            <span className="text-[9px] text-muted-foreground">/{kpi.target}</span>
                          </div>
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </GlassPanel>
      </div>
    </div>
  );
}
