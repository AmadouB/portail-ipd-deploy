"use client";

import { SsoIframe } from "@/components/sso/sso-iframe";

export default function HoshinPage() {
  return (
    <SsoIframe
      appUrl="https://hoshinflow.vercel.app"
      title="HoshinFlow - Deploiement Strategique"
    />
  );
}
