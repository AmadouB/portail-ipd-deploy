"use client";

import { SsoIframe } from "@/components/sso/sso-iframe";

/**
 * URL de HoshinFlow :
 * - Sur SRV-SEID (interne) : /hoshinflow (meme serveur, meme origine)
 * - Fallback Vercel public  : https://hoshinflow.vercel.app
 *
 * On detecte automatiquement : si on est sur le meme domaine que SRV-SEID,
 * on utilise le chemin relatif (meilleur SSO, pas de probleme de cookies tiers).
 */
function getHoshinflowUrl(): string {
  if (typeof window === "undefined") return "/hoshinflow";
  const host = window.location.hostname;
  // Detection reseau interne IPD ou .ipd.local
  if (host.startsWith("10.") || host.startsWith("192.168.") || host.endsWith(".ipd.local")) {
    return "/hoshinflow";
  }
  // En public (Hostinger, prod externe), utiliser Vercel
  return "https://hoshinflow.vercel.app";
}

export default function HoshinPage() {
  return (
    <SsoIframe
      appUrl={getHoshinflowUrl()}
      title="HoshinFlow - Deploiement Strategique"
    />
  );
}
