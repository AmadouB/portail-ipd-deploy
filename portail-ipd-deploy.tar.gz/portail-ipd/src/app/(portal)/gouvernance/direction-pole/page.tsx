"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import {
  ArrowLeft, Building2, FlaskConical, Microscope, Syringe,
  TestTubes, BookOpen, HeartPulse, Brain, Users, Hammer,
  ShieldCheck, Stethoscope, ExternalLink,
} from "lucide-react";

interface Service {
  id: string;
  name: string;
  fullName: string;
  icon: React.ReactNode;
  color: string;
  href?: string;
  external?: boolean;
}

const SERVICES: Service[] = [
  {
    id: "dpc",
    name: "DPC",
    fullName: "Direction de la Production et du Controle",
    icon: <ShieldCheck className="h-6 w-6" />,
    color: "#06b6d4",
  },
  {
    id: "dro",
    name: "DRO",
    fullName: "Direction de la Recherche et des Operations",
    icon: <Microscope className="h-6 w-6" />,
    color: "#8b5cf6",
    href: "https://frontend-sage-two-66.vercel.app",
    external: true,
  },
  {
    id: "vaccinopole",
    name: "Vaccinopole",
    fullName: "Pole de production vaccinale",
    icon: <Syringe className="h-6 w-6" />,
    color: "#10b981",
  },
  {
    id: "diatropix",
    name: "Diatropix",
    fullName: "Plateforme de diagnostic et recherche tropicale",
    icon: <TestTubes className="h-6 w-6" />,
    color: "#f43f5e",
  },
  {
    id: "grant_office",
    name: "Grant Office",
    fullName: "Bureau de gestion des subventions et financements",
    icon: <BookOpen className="h-6 w-6" />,
    color: "#f59e0b",
  },
  {
    id: "care",
    name: "CARE",
    fullName: "Centre d'Appui a la Recherche et aux Etudes",
    icon: <HeartPulse className="h-6 w-6" />,
    color: "#ec4899",
  },
  {
    id: "senior_adviser",
    name: "Senior Adviser for Biotechnology",
    fullName: "Conseiller principal en biotechnologie",
    icon: <Brain className="h-6 w-6" />,
    color: "#a855f7",
  },
  {
    id: "vrc",
    name: "Vaccine Research Center",
    fullName: "Centre de recherche vaccinale",
    icon: <FlaskConical className="h-6 w-6" />,
    color: "#14b8a6",
  },
  {
    id: "dch",
    name: "DCH",
    fullName: "Direction du Capital Humain",
    icon: <Users className="h-6 w-6" />,
    color: "#0ea5e9",
  },
  {
    id: "madiba",
    name: "MADIBA Workforce Initiative",
    fullName: "Initiative MADIBA pour le developpement des competences",
    icon: <Users className="h-6 w-6" />,
    color: "#22c55e",
  },
  {
    id: "dsp",
    name: "DSP",
    fullName: "Direction de la Sante Publique",
    icon: <Stethoscope className="h-6 w-6" />,
    color: "#ef4444",
  },
];

export default function DirectionPolePage() {
  return (
    <div className="max-w-6xl mx-auto space-y-8">
      {/* Header */}
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
        <Link href="/dashboard" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-white transition-colors">
          <ArrowLeft className="h-4 w-4" />
          Retour au tableau de bord
        </Link>
        <div className="flex items-center gap-4">
          <div className="p-3 rounded-xl" style={{ backgroundColor: "#f59e0b15" }}>
            <Building2 className="h-8 w-8" style={{ color: "#f59e0b" }} />
          </div>
          <div>
            <h1 className="text-2xl font-bold">Direction / Pole</h1>
            <p className="text-sm text-muted-foreground">{SERVICES.length} directions et poles de l&apos;IPD</p>
          </div>
        </div>
      </motion.div>

      {/* Services Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {SERVICES.map((service, index) => {
          const CardContent = (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
              className="group relative rounded-2xl border border-white/10 bg-white/[0.02] backdrop-blur-sm p-5 hover:bg-white/[0.05] hover:border-white/20 transition-all duration-300 cursor-pointer"
            >
              <div className="flex items-start gap-4">
                <div
                  className="p-2.5 rounded-xl shrink-0 transition-transform group-hover:scale-110"
                  style={{ backgroundColor: `${service.color}15` }}
                >
                  <div style={{ color: service.color }}>{service.icon}</div>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <h3 className="font-bold text-sm truncate">{service.name}</h3>
                    {service.external && (
                      <ExternalLink className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{service.fullName}</p>
                </div>
              </div>
              {!service.href && (
                <div className="mt-3 flex items-center gap-1.5 text-[10px] text-muted-foreground/50">
                  <Hammer className="h-3 w-3" />
                  <span>Bientot disponible</span>
                </div>
              )}
              {service.href && (
                <div className="mt-3 flex items-center gap-1.5 text-[10px]" style={{ color: service.color }}>
                  <div className="h-1.5 w-1.5 rounded-full animate-pulse" style={{ backgroundColor: service.color }} />
                  <span>Actif</span>
                </div>
              )}
            </motion.div>
          );

          if (service.href && service.external) {
            return (
              <a key={service.id} href={service.href} target="_blank" rel="noopener noreferrer">
                {CardContent}
              </a>
            );
          }

          if (service.href) {
            return (
              <Link key={service.id} href={service.href}>
                {CardContent}
              </Link>
            );
          }

          return <div key={service.id}>{CardContent}</div>;
        })}
      </div>
    </div>
  );
}
