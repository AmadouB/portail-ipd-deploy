"use client";

import { useEffect, useState } from "react";

/**
 * Module Coordination : iframe vers le HTML statique du portail.
 * Avec basePath /portail, on doit prefixer le chemin pour que nginx route correctement.
 */
export default function CoordinationPage() {
  const [src, setSrc] = useState("/modules/coordination.html");

  useEffect(() => {
    // Detecter le basePath actif et prefixer
    const basePath = (window as any).__NEXT_DATA__?.basePath ?? "";
    setSrc(`${basePath}/modules/coordination.html`);
  }, []);

  return (
    <div className="-m-6 h-[calc(100vh-4rem)]">
      <iframe
        src={src}
        className="w-full h-full border-0"
        title="Coordination IMS UVFJ"
      />
    </div>
  );
}
