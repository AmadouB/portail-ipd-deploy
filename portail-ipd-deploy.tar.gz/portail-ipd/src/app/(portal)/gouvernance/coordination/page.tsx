"use client";

export default function CoordinationPage() {
  return (
    <div className="-m-6 h-[calc(100vh-4rem)]">
      <iframe
        src="/modules/coordination.html"
        className="w-full h-full border-0"
        title="Coordination IMS UVFJ"
      />
    </div>
  );
}
