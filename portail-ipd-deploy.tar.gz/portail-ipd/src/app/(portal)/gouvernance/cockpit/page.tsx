"use client";

import { GlassPanel } from "@/components/shared/glass-panel";
import { KpiCard } from "@/components/shared/kpi-card";
import { COCKPIT_KPIS, BUDGET_BY_POLE, STRATEGIC_INDICATORS, MONTHLY_TREND, PERFORMANCE_POLES } from "@/lib/data/mock-cockpit";
import { Shield, Target, TrendingUp, AlertTriangle, CheckCircle, Clock } from "lucide-react";
import { motion } from "framer-motion";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  LineChart, Line, RadarChart, Radar, PolarGrid, PolarAngleAxis, PolarRadiusAxis,
  Legend,
} from "recharts";

const statusConfig = {
  on_track: { label: "En bonne voie", icon: <CheckCircle className="h-4 w-4" />, color: "text-emerald-400", bg: "bg-emerald-500/10" },
  at_risk: { label: "A risque", icon: <AlertTriangle className="h-4 w-4" />, color: "text-amber-400", bg: "bg-amber-500/10" },
  delayed: { label: "En retard", icon: <Clock className="h-4 w-4" />, color: "text-red-400", bg: "bg-red-500/10" },
};

export default function CockpitPage() {
  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="flex items-center gap-4">
        <div className="p-3 rounded-xl bg-cyan-500/10">
          <Shield className="h-6 w-6 text-cyan-400" />
        </div>
        <div>
          <h1 className="text-2xl font-bold">Cockpit Strategique</h1>
          <p className="text-sm text-muted-foreground">Vue d&apos;ensemble de la performance institutionnelle</p>
        </div>
      </motion.div>

      {/* KPIs */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        {COCKPIT_KPIS.map((kpi, i) => (
          <KpiCard
            key={kpi.label}
            label={kpi.label}
            value={kpi.value}
            previousValue={kpi.previousValue}
            unit={kpi.unit}
            trend={kpi.trend}
            color={kpi.color}
            delay={i * 0.1}
            icon={<Target className="h-4 w-4" />}
            glow={i === 0 ? "cyan" : "none"}
          />
        ))}
      </div>

      {/* Charts row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Budget by Pole */}
        <GlassPanel delay={0.3}>
          <h3 className="font-semibold mb-4 flex items-center gap-2">
            <TrendingUp className="h-4 w-4 text-cyan-400" />
            Execution Budgetaire par Pole
          </h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={BUDGET_BY_POLE}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
                <XAxis dataKey="name" tick={{ fill: "rgba(255,255,255,0.5)", fontSize: 12 }} />
                <YAxis tick={{ fill: "rgba(255,255,255,0.5)", fontSize: 12 }} />
                <Tooltip
                  contentStyle={{ backgroundColor: "#111827", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 8 }}
                  labelStyle={{ color: "rgba(255,255,255,0.9)" }}
                />
                <Bar dataKey="alloue" fill="#06b6d4" opacity={0.3} name="Alloue (M FCFA)" radius={[4, 4, 0, 0]} />
                <Bar dataKey="consomme" fill="#06b6d4" name="Consomme (M FCFA)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </GlassPanel>

        {/* Trend line chart */}
        <GlassPanel delay={0.4}>
          <h3 className="font-semibold mb-4 flex items-center gap-2">
            <TrendingUp className="h-4 w-4 text-emerald-400" />
            Tendance sur 6 mois
          </h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={MONTHLY_TREND}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
                <XAxis dataKey="name" tick={{ fill: "rgba(255,255,255,0.5)", fontSize: 12 }} />
                <YAxis tick={{ fill: "rgba(255,255,255,0.5)", fontSize: 12 }} />
                <Tooltip contentStyle={{ backgroundColor: "#111827", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 8 }} />
                <Line type="monotone" dataKey="budget" stroke="#06b6d4" strokeWidth={2} dot={{ fill: "#06b6d4" }} name="Budget (%)" />
                <Line type="monotone" dataKey="conformite" stroke="#10b981" strokeWidth={2} dot={{ fill: "#10b981" }} name="Conformite (%)" />
                <Line type="monotone" dataKey="projets" stroke="#8b5cf6" strokeWidth={2} dot={{ fill: "#8b5cf6" }} name="Projets" />
                <Legend />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </GlassPanel>
      </div>

      {/* Performance radar + Strategic indicators */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Radar */}
        <GlassPanel delay={0.5}>
          <h3 className="font-semibold mb-4">Performance par Pole</h3>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart data={PERFORMANCE_POLES}>
                <PolarGrid stroke="rgba(255,255,255,0.1)" />
                <PolarAngleAxis dataKey="pole" tick={{ fill: "rgba(255,255,255,0.6)", fontSize: 11 }} />
                <PolarRadiusAxis tick={{ fill: "rgba(255,255,255,0.3)", fontSize: 10 }} domain={[0, 100]} />
                <Radar name="KPIs atteints" dataKey="kpiAtteints" stroke="#06b6d4" fill="#06b6d4" fillOpacity={0.2} />
                <Radar name="Satisfaction" dataKey="satisfaction" stroke="#10b981" fill="#10b981" fillOpacity={0.1} />
                <Legend />
              </RadarChart>
            </ResponsiveContainer>
          </div>
        </GlassPanel>

        {/* Strategic Indicators */}
        <GlassPanel delay={0.6} className="lg:col-span-2">
          <h3 className="font-semibold mb-4 flex items-center gap-2">
            <Target className="h-4 w-4 text-purple-400" />
            Indicateurs du Contrat de Performance
          </h3>
          <div className="space-y-3">
            {STRATEGIC_INDICATORS.map((ind) => {
              const progress = Math.round((ind.current / ind.target) * 100);
              const cfg = statusConfig[ind.status];
              return (
                <div key={ind.id} className="flex items-center gap-4 p-3 rounded-lg bg-white/[0.02] hover:bg-white/[0.04] transition-colors">
                  <div className={`p-1.5 rounded-lg ${cfg.bg}`}>
                    <div className={cfg.color}>{cfg.icon}</div>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm font-medium truncate">{ind.label}</span>
                      <span className="text-xs text-muted-foreground ml-2">
                        {ind.current.toLocaleString("fr-FR")}/{ind.target.toLocaleString("fr-FR")} {ind.unit}
                      </span>
                    </div>
                    <div className="h-1.5 bg-white/5 rounded-full overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all duration-1000"
                        style={{
                          width: `${Math.min(progress, 100)}%`,
                          backgroundColor: progress >= 80 ? "#10b981" : progress >= 50 ? "#f59e0b" : "#ef4444",
                        }}
                      />
                    </div>
                  </div>
                  <span className="text-sm font-bold w-12 text-right">{progress}%</span>
                </div>
              );
            })}
          </div>
        </GlassPanel>
      </div>
    </div>
  );
}
