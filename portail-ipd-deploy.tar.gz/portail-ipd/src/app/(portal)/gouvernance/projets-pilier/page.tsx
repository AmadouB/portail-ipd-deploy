"use client";

import { motion } from "framer-motion";
import { ArrowLeft, BarChart3, Hammer } from "lucide-react";
import Link from "next/link";

export default function ProjetsPilierPage() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div className="flex items-center gap-4">
          <Link
            href="/dashboard"
            className="p-2 rounded-lg glass glass-hover transition-colors"
          >
            <ArrowLeft className="h-4 w-4 text-muted-foreground" />
          </Link>
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl" style={{ backgroundColor: "#06b6d415" }}>
              <BarChart3 className="h-6 w-6" style={{ color: "#06b6d4" }} />
            </div>
            <div>
              <h1 className="text-xl font-bold">Projets par Pilier</h1>
              <p className="text-xs text-muted-foreground">
                Vue d&apos;ensemble des projets par pilier strategique
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-[10px] font-semibold px-2.5 py-1 rounded-full bg-[#06b6d4]/10 text-[#06b6d4]">
            P0
          </span>
          <span className="text-[10px] px-2.5 py-1 rounded-full bg-emerald-500/10 text-emerald-400">
            Gouvernance
          </span>
        </div>
      </div>

      {/* Placeholder Content */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className="glass rounded-2xl p-12 flex flex-col items-center justify-center min-h-[400px] text-center"
      >
        <div className="p-4 rounded-2xl bg-white/5 mb-6">
          <Hammer className="h-10 w-10 text-muted-foreground" />
        </div>
        <h2 className="text-lg font-semibold mb-2">Module en cours de developpement</h2>
        <p className="text-sm text-muted-foreground max-w-md">
          Ce module est en cours de developpement. Les fonctionnalites seront disponibles prochainement.
        </p>
      </motion.div>
    </div>
  );
}
