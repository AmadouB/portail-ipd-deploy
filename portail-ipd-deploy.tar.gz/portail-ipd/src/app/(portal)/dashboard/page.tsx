"use client";

import { useAuthStore } from "@/stores/auth-store";
import { useModuleStore } from "@/stores/module-store";
import { hasModuleAccess } from "@/lib/rbac";
import { ModuleTile } from "@/components/dashboard/module-tile";
import { type ModuleId } from "@/types";
import { motion } from "framer-motion";
import { LayoutDashboard } from "lucide-react";

/** Ordered module IDs for the dashboard */
const MODULE_ORDER = [
  "coordination",
  "hoshin",
  "partenariat",
  "ims",
  "direction_pole",
  "admin",
];

export default function DashboardPage() {
  const session = useAuthStore((s) => s.session);
  const modules = useModuleStore((s) => s.modules);

  if (!session) return null;

  const user = session.user;
  const role = user.role;

  const enabledModules = modules.filter((m) => m.enabled);
  const accessibleCount = enabledModules.filter((m) =>
    hasModuleAccess(role, m.id as ModuleId)
  ).length;

  const now = new Date();
  const greeting = now.getHours() < 12 ? "Bonjour" : now.getHours() < 18 ? "Bon apres-midi" : "Bonsoir";

  // Order modules according to MODULE_ORDER
  const orderedModules = MODULE_ORDER
    .map((id) => enabledModules.find((m) => m.id === id))
    .filter(Boolean) as typeof enabledModules;

  return (
    <div className="max-w-7xl mx-auto space-y-8">
      {/* Welcome */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-center gap-4"
      >
        <div className="p-3 rounded-xl bg-cyan-500/10">
          <LayoutDashboard className="h-6 w-6 text-cyan-400" />
        </div>
        <div>
          <h1 className="text-2xl font-bold">
            {greeting}, {user.firstName}
          </h1>
          <p className="text-sm text-muted-foreground">
            {accessibleCount} modules accessibles &middot; {user.department}
          </p>
        </div>
      </motion.div>

      {/* Modules */}
      <div>
        <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
          <div className="h-1 w-6 rounded-full bg-cyan-500" />
          Modules
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {orderedModules.map((module, index) => (
            <ModuleTile
              key={module.id}
              module={module}
              index={index}
              accessible={hasModuleAccess(role, module.id as ModuleId)}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
