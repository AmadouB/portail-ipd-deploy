"use client";

import { GlassPanel } from "@/components/shared/glass-panel";
import { StatusBadge } from "@/components/shared/status-badge";
import { SYSTEM_SERVICES } from "@/lib/data/mock-admin";
import { type ModuleId, POLE_CONFIG } from "@/types";
import { ModuleManager } from "@/components/admin/module-manager";
import { UserManager } from "@/components/admin/user-manager";
import { RoleManager } from "@/components/admin/role-manager";
import { getAuditLogs } from "@/lib/security/audit";
import { Settings, Users, Shield, FileText, Server, Boxes, RefreshCw } from "lucide-react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { useState } from "react";

const actionColors: Record<string, string> = {
  login: "text-cyan-400",
  logout: "text-zinc-400",
  view: "text-blue-400",
  create: "text-emerald-400",
  update: "text-amber-400",
  delete: "text-red-400",
  export: "text-purple-400",
};

export default function AdminPage() {
  const [activeTab, setActiveTab] = useState<"users" | "roles" | "modules" | "audit" | "system">("users");

  const tabs = [
    { id: "users" as const, label: "Utilisateurs", icon: <Users className="h-4 w-4" /> },
    { id: "modules" as const, label: "Modules", icon: <Boxes className="h-4 w-4" /> },
    { id: "roles" as const, label: "Matrice Roles", icon: <Shield className="h-4 w-4" /> },
    { id: "audit" as const, label: "Journal d'Audit", icon: <FileText className="h-4 w-4" /> },
    { id: "system" as const, label: "Sante Systeme", icon: <Server className="h-4 w-4" /> },
  ];

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="flex items-center gap-4">
        <div className="p-3 rounded-xl bg-amber-500/10">
          <Settings className="h-6 w-6 text-amber-400" />
        </div>
        <div>
          <h1 className="text-2xl font-bold">Administration du Portail</h1>
          <p className="text-sm text-muted-foreground">Gestion des utilisateurs, roles, audit et infrastructure</p>
        </div>
      </motion.div>

      {/* Tabs */}
      <div className="flex gap-2 border-b pb-px" style={{ borderColor: "var(--surface-border)" }}>
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={cn(
              "flex items-center gap-2 px-4 py-2.5 text-sm font-medium rounded-t-lg transition-all",
              activeTab === tab.id
                ? "text-amber-400 border-b-2 border-amber-400"
                : "text-muted-foreground hover:bg-[var(--surface-hover)]"
            )}
            style={activeTab === tab.id ? { backgroundColor: "var(--surface-hover)" } : undefined}
          >
            {tab.icon}
            {tab.label}
          </button>
        ))}
      </div>

      {/* Content */}
      {activeTab === "users" && <UserManager />}
      {activeTab === "modules" && <ModuleManager />}
      {activeTab === "roles" && <RoleManager />}
      {activeTab === "audit" && <AuditTab />}
      {activeTab === "system" && <SystemTab />}
    </div>
  );
}

function AuditTab() {
  const [logs, setLogs] = useState(getAuditLogs());
  const refreshLogs = () => setLogs(getAuditLogs());
  return (
    <GlassPanel delay={0.2}>
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-semibold flex items-center gap-2">
          <FileText className="h-4 w-4 text-amber-400" />
          Journal d&apos;Audit ({logs.length} entrees)
        </h3>
        <button onClick={refreshLogs} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs hover:bg-[var(--surface-hover)] transition-colors text-muted-foreground">
          <RefreshCw className="h-3 w-3" />
          Actualiser
        </button>
      </div>
      {logs.length === 0 && (
        <p className="text-center py-8 text-muted-foreground text-sm">
          Aucune action enregistree. Les connexions et actions seront journalisees automatiquement.
        </p>
      )}
      <div className="space-y-2">
        {logs.map((log) => (
          <div key={log.id} className="flex items-center gap-4 p-3 rounded-lg transition-colors text-sm hover:bg-[var(--surface-hover)]" style={{ backgroundColor: "var(--surface-input-bg)" }}>
            <div className="w-20 text-xs text-muted-foreground">
              {new Date(log.timestamp).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}
              <br />
              <span className="text-[10px]">{new Date(log.timestamp).toLocaleDateString("fr-FR")}</span>
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <span className="font-medium">{log.userName}</span>
                <span className={cn("text-xs font-mono", actionColors[log.action])}>
                  {log.action.toUpperCase()}
                </span>
                <span className="text-xs text-muted-foreground px-1.5 py-0.5 rounded" style={{ backgroundColor: "var(--surface-hover)" }}>
                  {log.module}
                </span>
              </div>
              <p className="text-xs text-muted-foreground truncate">{log.detail}</p>
            </div>
            <span className="text-xs text-muted-foreground font-mono">{log.ipAddress}</span>
          </div>
        ))}
      </div>
    </GlassPanel>
  );
}

function SystemTab() {
  return (
    <div className="space-y-6">
      <GlassPanel delay={0.2}>
        <h3 className="font-semibold mb-4 flex items-center gap-2">
          <Server className="h-4 w-4 text-amber-400" />
          Services Infrastructure
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {SYSTEM_SERVICES.map((svc) => (
            <div key={svc.name} className="p-4 rounded-xl border" style={{ backgroundColor: "var(--surface-input-bg)", borderColor: "var(--surface-border)" }}>
              <div className="flex items-center justify-between mb-3">
                <span className="font-medium text-sm">{svc.name}</span>
                <StatusBadge status={svc.status} />
              </div>
              <div className="grid grid-cols-2 gap-y-2 text-xs">
                <div>
                  <p className="text-muted-foreground">Uptime</p>
                  <p className="font-mono text-emerald-400">{svc.uptime}%</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Response</p>
                  <p className="font-mono">{svc.responseTime}ms</p>
                </div>
                <div>
                  <p className="text-muted-foreground">CPU</p>
                  <div className="flex items-center gap-2">
                    <div className="flex-1 h-1.5 rounded-full overflow-hidden" style={{ backgroundColor: "var(--surface-hover)" }}>
                      <div className="h-full rounded-full bg-cyan-500" style={{ width: `${svc.cpu}%` }} />
                    </div>
                    <span className="font-mono text-[10px]">{svc.cpu}%</span>
                  </div>
                </div>
                <div>
                  <p className="text-muted-foreground">Memoire</p>
                  <div className="flex items-center gap-2">
                    <div className="flex-1 h-1.5 rounded-full overflow-hidden" style={{ backgroundColor: "var(--surface-hover)" }}>
                      <div
                        className="h-full rounded-full"
                        style={{
                          width: `${svc.memory}%`,
                          backgroundColor: svc.memory > 80 ? "#ef4444" : svc.memory > 60 ? "#f59e0b" : "#10b981",
                        }}
                      />
                    </div>
                    <span className="font-mono text-[10px]">{svc.memory}%</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </GlassPanel>
    </div>
  );
}
