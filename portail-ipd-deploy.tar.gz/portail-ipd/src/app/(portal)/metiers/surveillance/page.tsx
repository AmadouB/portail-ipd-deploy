"use client";

import { GlassPanel } from "@/components/shared/glass-panel";
import { KpiCard } from "@/components/shared/kpi-card";
import {
  EPIDEMIC_ALERTS, DISEASES_DATA, REGIONS_DATA, SURVEILLANCE_KPIS,
} from "@/lib/data/mock-surveillance";
import { SenegalMap } from "@/components/surveillance/senegal-map";
import { Activity, AlertTriangle, MapPin, TrendingUp, TrendingDown, Minus, Heart } from "lucide-react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { formatDistanceToNow } from "date-fns";
import { fr } from "date-fns/locale";
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend,
} from "recharts";

const levelConfig = {
  vigilance: { label: "Vigilance", color: "#06b6d4", bg: "bg-cyan-500/10", text: "text-cyan-400" },
  pre_alerte: { label: "Pre-alerte", color: "#f59e0b", bg: "bg-amber-500/10", text: "text-amber-400" },
  alerte: { label: "Alerte", color: "#f97316", bg: "bg-orange-500/10", text: "text-orange-400" },
  urgence: { label: "Urgence", color: "#ef4444", bg: "bg-red-500/10", text: "text-red-400" },
};


const trendIcons = {
  up: <TrendingUp className="h-3.5 w-3.5 text-red-400" />,
  down: <TrendingDown className="h-3.5 w-3.5 text-emerald-400" />,
  stable: <Minus className="h-3.5 w-3.5 text-zinc-400" />,
};

const diseaseColors = ["#06b6d4", "#f59e0b", "#8b5cf6", "#10b981"];

export default function SurveillancePage() {
  // Merge weekly data for chart
  const weeks = DISEASES_DATA[0].weeklyData.map((w) => w.week);
  const chartData = weeks.map((week) => {
    const point: Record<string, string | number> = { name: week };
    DISEASES_DATA.forEach((d) => {
      const weekData = d.weeklyData.find((w) => w.week === week);
      point[d.disease] = weekData?.cases || 0;
    });
    return point;
  });

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="flex items-center gap-4">
        <div className="p-3 rounded-xl bg-emerald-500/10">
          <Activity className="h-6 w-6 text-emerald-400" />
        </div>
        <div>
          <h1 className="text-2xl font-bold">Surveillance Epidemiologique</h1>
          <p className="text-sm text-muted-foreground">Centre de veille sanitaire et alertes en temps reel</p>
        </div>
      </motion.div>

      {/* KPIs */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {SURVEILLANCE_KPIS.map((kpi, i) => (
          <KpiCard
            key={kpi.label}
            label={kpi.label}
            value={kpi.value}
            previousValue={kpi.previousValue}
            unit={kpi.unit}
            trend={kpi.trend}
            color={kpi.color}
            delay={i * 0.1}
            icon={<Heart className="h-4 w-4" />}
          />
        ))}
      </div>

      {/* Alerts + Map */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Alert Feed */}
        <GlassPanel delay={0.3} className="lg:col-span-1">
          <h3 className="font-semibold mb-4 flex items-center gap-2">
            <AlertTriangle className="h-4 w-4 text-amber-400" />
            Alertes Actives ({EPIDEMIC_ALERTS.length})
          </h3>
          <div className="space-y-3">
            {EPIDEMIC_ALERTS.map((alert) => {
              const cfg = levelConfig[alert.level];
              const change = ((alert.cases - alert.casesLastWeek) / alert.casesLastWeek * 100).toFixed(0);
              return (
                <div key={alert.id} className="p-3 rounded-lg bg-white/[0.02] border-l-2 hover:bg-white/[0.04] transition-colors" style={{ borderLeftColor: cfg.color }}>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm font-semibold">{alert.disease}</span>
                    <span className={cn("text-[10px] px-2 py-0.5 rounded-full font-medium", cfg.bg, cfg.text)}>
                      {cfg.label}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-muted-foreground mb-1">
                    <MapPin className="h-3 w-3" />
                    {alert.region}
                    <span>&middot;</span>
                    <span>{alert.cases} cas (+{change}%)</span>
                  </div>
                  <p className="text-[11px] text-muted-foreground line-clamp-2">{alert.message}</p>
                  <p className="text-[10px] text-muted-foreground mt-1">
                    {formatDistanceToNow(new Date(alert.date), { addSuffix: true, locale: fr })}
                  </p>
                </div>
              );
            })}
          </div>
        </GlassPanel>

        {/* Map Leaflet */}
        <GlassPanel delay={0.4} className="lg:col-span-2">
          <h3 className="font-semibold mb-4 flex items-center gap-2">
            <MapPin className="h-4 w-4 text-cyan-400" />
            Carte de Surveillance - Senegal
          </h3>
          <div className="relative h-[420px] rounded-xl overflow-hidden border border-white/[0.06]">
            <SenegalMap regions={REGIONS_DATA} />
          </div>
        </GlassPanel>
      </div>

      {/* Disease trends + Disease cards */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Weekly trends */}
        <GlassPanel delay={0.5}>
          <h3 className="font-semibold mb-4 flex items-center gap-2">
            <TrendingUp className="h-4 w-4 text-cyan-400" />
            Evolution hebdomadaire des cas
          </h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
                <XAxis dataKey="name" tick={{ fill: "rgba(255,255,255,0.5)", fontSize: 12 }} />
                <YAxis tick={{ fill: "rgba(255,255,255,0.5)", fontSize: 12 }} />
                <Tooltip contentStyle={{ backgroundColor: "#111827", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 8 }} />
                {DISEASES_DATA.map((d, i) => (
                  <Line key={d.disease} type="monotone" dataKey={d.disease} stroke={diseaseColors[i]} strokeWidth={2} dot={{ fill: diseaseColors[i], r: 3 }} />
                ))}
                <Legend />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </GlassPanel>

        {/* Disease cards */}
        <div className="grid grid-cols-2 gap-4">
          {DISEASES_DATA.map((disease, i) => (
            <GlassPanel key={disease.disease} delay={0.5 + i * 0.1} className="flex flex-col">
              <div className="flex items-center justify-between mb-3">
                <h4 className="text-sm font-semibold">{disease.disease}</h4>
                {trendIcons[disease.trend]}
              </div>
              <div className="space-y-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Cas actifs</span>
                  <span className="font-bold" style={{ color: diseaseColors[i] }}>{disease.activeCases}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Total cumule</span>
                  <span>{disease.totalCases.toLocaleString("fr-FR")}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Gueris</span>
                  <span className="text-emerald-400">{disease.recovered.toLocaleString("fr-FR")}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Deces</span>
                  <span className="text-red-400">{disease.deaths}</span>
                </div>
              </div>
              <div className="mt-auto pt-3 border-t border-white/[0.06]">
                <div className="h-1 bg-white/5 rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full"
                    style={{
                      width: `${(disease.recovered / disease.totalCases) * 100}%`,
                      backgroundColor: "#10b981",
                    }}
                  />
                </div>
                <p className="text-[10px] text-muted-foreground mt-1">
                  {((disease.recovered / disease.totalCases) * 100).toFixed(1)}% taux de guerison
                </p>
              </div>
            </GlassPanel>
          ))}
        </div>
      </div>
    </div>
  );
}
