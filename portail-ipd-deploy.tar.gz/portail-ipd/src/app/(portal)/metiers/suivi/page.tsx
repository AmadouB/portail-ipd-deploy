"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import {
  ClipboardCheck,
  LayoutDashboard,
  ArrowLeft,
  Maximize2,
  Minimize2,
} from "lucide-react";
import Link from "next/link";

const TABS = [
  {
    id: "coordination",
    label: "Coordination",
    icon: <LayoutDashboard className="h-4 w-4" />,
    description: "Tableau de bord IMS UVFJ - Suivi integre production, qualite et conformite",
  },
] as const;

type TabId = (typeof TABS)[number]["id"];

export default function SuiviPage() {
  const [activeTab, setActiveTab] = useState<TabId>("coordination");
  const [isFullscreen, setIsFullscreen] = useState(false);

  const activeTabConfig = TABS.find((t) => t.id === activeTab)!;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div className="flex items-center gap-4">
          <Link
            href="/dashboard"
            className="p-2 rounded-lg glass glass-hover transition-colors"
          >
            <ArrowLeft className="h-4 w-4 text-muted-foreground" />
          </Link>
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl" style={{ backgroundColor: "#0089D015" }}>
              <ClipboardCheck className="h-6 w-6" style={{ color: "#0089D0" }} />
            </div>
            <div>
              <h1 className="text-xl font-bold">Modules Suivi</h1>
              <p className="text-xs text-muted-foreground">
                Coordination et suivi integre des activites IPD
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-[10px] font-semibold px-2.5 py-1 rounded-full bg-[#0089D0]/10 text-[#0089D0]">
            P0
          </span>
          <span className="text-[10px] px-2.5 py-1 rounded-full bg-emerald-500/10 text-emerald-400">
            Fonctions Metiers
          </span>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 flex-wrap">
        {TABS.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 ${
              activeTab === tab.id
                ? "glass text-[#0089D0] border border-[#0089D0]/30 shadow-[0_0_15px_rgba(0,137,208,0.1)]"
                : "text-muted-foreground hover:text-white hover:bg-white/5"
            }`}
          >
            {tab.icon}
            {tab.label}
          </button>
        ))}

        {/* Fullscreen toggle */}
        <button
          onClick={() => setIsFullscreen(!isFullscreen)}
          className="ml-auto p-2.5 rounded-xl glass glass-hover text-muted-foreground hover:text-white transition-colors"
          title={isFullscreen ? "Reduire" : "Plein ecran"}
        >
          {isFullscreen ? (
            <Minimize2 className="h-4 w-4" />
          ) : (
            <Maximize2 className="h-4 w-4" />
          )}
        </button>
      </div>

      {/* Tab description */}
      <motion.p
        key={activeTab}
        initial={{ opacity: 0, y: -5 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-xs text-muted-foreground"
      >
        {activeTabConfig.description}
      </motion.p>

      {/* Content */}
      <motion.div
        key={`content-${activeTab}`}
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className={`glass rounded-2xl overflow-hidden transition-all duration-300 ${
          isFullscreen
            ? "fixed inset-4 z-50 rounded-2xl"
            : ""
        }`}
      >
        {/* Fullscreen close button */}
        {isFullscreen && (
          <button
            onClick={() => setIsFullscreen(false)}
            className="absolute top-3 right-3 z-10 p-2 rounded-lg bg-black/60 backdrop-blur-sm text-white/70 hover:text-white transition-colors border border-white/10"
          >
            <Minimize2 className="h-4 w-4" />
          </button>
        )}

        {activeTab === "coordination" && (
          <iframe
            src="/modules/suivi-coordination.html"
            className={`w-full border-0 ${
              isFullscreen ? "h-full" : "h-[calc(100vh-280px)] min-h-[600px]"
            }`}
            title="Coordination IMS UVFJ"
            sandbox="allow-scripts allow-same-origin"
            referrerPolicy="no-referrer"
          />
        )}
      </motion.div>

      {/* Fullscreen backdrop */}
      {isFullscreen && (
        <div
          className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40"
          onClick={() => setIsFullscreen(false)}
        />
      )}
    </div>
  );
}
