"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import {
  Gauge,
  LayoutDashboard,
  ArrowLeft,
  Maximize2,
  Minimize2,
} from "lucide-react";
import Link from "next/link";

export default function ImsPage() {
  const [isFullscreen, setIsFullscreen] = useState(false);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div className="flex items-center gap-4">
          <Link
            href="/dashboard"
            className="p-2 rounded-lg glass glass-hover transition-colors"
          >
            <ArrowLeft className="h-4 w-4 text-muted-foreground" />
          </Link>
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl" style={{ backgroundColor: "#8b5cf615" }}>
              <Gauge className="h-6 w-6" style={{ color: "#8b5cf6" }} />
            </div>
            <div>
              <h1 className="text-xl font-bold">IMS NextGen</h1>
              <p className="text-xs text-muted-foreground">
                Systeme de Management Integre - Institut Pasteur de Dakar
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-[10px] font-semibold px-2.5 py-1 rounded-full bg-[#8b5cf6]/10 text-[#8b5cf6]">
            P0
          </span>
          <span className="text-[10px] px-2.5 py-1 rounded-full bg-emerald-500/10 text-emerald-400">
            Fonctions Metiers
          </span>
          <button
            onClick={() => setIsFullscreen(!isFullscreen)}
            className="p-2.5 rounded-xl glass glass-hover text-muted-foreground hover:text-white transition-colors"
            title={isFullscreen ? "Reduire" : "Plein ecran"}
          >
            {isFullscreen ? (
              <Minimize2 className="h-4 w-4" />
            ) : (
              <Maximize2 className="h-4 w-4" />
            )}
          </button>
        </div>
      </div>

      {/* Content */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className={`glass rounded-2xl overflow-hidden transition-all duration-300 ${
          isFullscreen ? "fixed inset-4 z-50 rounded-2xl" : ""
        }`}
      >
        {isFullscreen && (
          <button
            onClick={() => setIsFullscreen(false)}
            className="absolute top-3 right-3 z-10 p-2 rounded-lg bg-black/60 backdrop-blur-sm text-white/70 hover:text-white transition-colors border border-white/10"
          >
            <Minimize2 className="h-4 w-4" />
          </button>
        )}

        <iframe
          src="/modules/ims-nextgen.html"
          className={`w-full border-0 ${
            isFullscreen ? "h-full" : "h-[calc(100vh-200px)] min-h-[600px]"
          }`}
          title="IMS NextGen Dashboard"
          sandbox="allow-scripts allow-same-origin"
          referrerPolicy="no-referrer"
        />
      </motion.div>

      {isFullscreen && (
        <div
          className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40"
          onClick={() => setIsFullscreen(false)}
        />
      )}
    </div>
  );
}
