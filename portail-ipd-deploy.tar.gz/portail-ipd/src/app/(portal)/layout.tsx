"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { useAuthStore } from "@/stores/auth-store";
import { useNotificationStore } from "@/stores/notification-store";
import { useThemeStore } from "@/stores/theme-store";
import { useUserStore } from "@/stores/user-store";
import { useModuleStore } from "@/stores/module-store";
import { PortalSidebar } from "@/components/layout/portal-sidebar";
import { PortalHeader } from "@/components/layout/portal-header";

export default function PortalLayout({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const { session, isLoading, loadSession, checkSessionValidity } = useAuthStore();
  const loadNotifications = useNotificationStore((s) => s.loadNotifications);
  const loadTheme = useThemeStore((s) => s.loadTheme);
  const loadUsers = useUserStore((s) => s.loadUsers);
  const loadModules = useModuleStore((s) => s.loadModules);

  useEffect(() => {
    loadSession();
    loadTheme();
    loadUsers();
    loadModules();
  }, [loadSession, loadTheme, loadUsers, loadModules]);

  // Periodic session validity check (every 60 seconds)
  useEffect(() => {
    const interval = setInterval(() => {
      checkSessionValidity();
    }, 60_000);
    return () => clearInterval(interval);
  }, [checkSessionValidity]);

  useEffect(() => {
    if (!isLoading && !session) {
      router.push("/login");
    }
  }, [isLoading, session, router]);

  useEffect(() => {
    loadNotifications();
  }, [loadNotifications]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="h-10 w-10 border-2 border-cyan-500/30 border-t-cyan-500 rounded-full animate-spin" />
          <p className="text-sm text-muted-foreground">Chargement du portail...</p>
        </div>
      </div>
    );
  }

  if (!session) return null;

  return (
    <div className="flex min-h-screen">
      <PortalSidebar />
      <div className="flex-1 flex flex-col min-w-0">
        <PortalHeader />
        <main className="flex-1 p-6 overflow-auto">
          {children}
        </main>
      </div>
    </div>
  );
}
