"use client";

import { useSearchParams } from "next/navigation";
import { Suspense } from "react";
import { ModuleIframeContent } from "@/components/shared/module-iframe-content";

function ModuleViewer() {
  const searchParams = useSearchParams();
  const moduleId = searchParams.get("id") || "";

  return <ModuleIframeContent moduleId={moduleId} />;
}

export default function ModuleViewPage() {
  return (
    <Suspense fallback={<div className="flex items-center justify-center h-64 text-muted-foreground">Chargement du module...</div>}>
      <ModuleViewer />
    </Suspense>
  );
}
