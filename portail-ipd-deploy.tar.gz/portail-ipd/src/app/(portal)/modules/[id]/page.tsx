import { MODULES } from "@/lib/data/mock-modules";
import { ModuleIframeContent } from "@/components/shared/module-iframe-content";

// Required for static export — pre-render all known module IDs
export function generateStaticParams() {
  return MODULES.map((m) => ({ id: m.id }));
}

export default async function ModuleIframePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  return <ModuleIframeContent moduleId={id} />;
}
