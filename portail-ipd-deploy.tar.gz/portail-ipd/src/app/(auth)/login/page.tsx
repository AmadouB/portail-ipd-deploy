"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useAuthStore } from "@/stores/auth-store";
import {
  Shield,
  Eye,
  EyeOff,
  LogIn,
  Target,
  Activity,
  Lock,
  BarChart3,
  Handshake,
} from "lucide-react";
import { motion } from "framer-motion";
import { IpdOrbital3D } from "@/components/login/ipd-orbital-3d";

const OBJECTIVES = [
  {
    icon: Target,
    text: "Pilotage strategique et aide a la decision en temps reel",
    color: "#f59e0b",
  },
  {
    icon: Activity,
    text: "Surveillance epidemiologique et reponse aux urgences sanitaires",
    color: "#10b981",
  },
  {
    icon: Lock,
    text: "Cybersecurite et conformite aux standards internationaux",
    color: "#06b6d4",
  },
  {
    icon: BarChart3,
    text: "Gestion integree des ressources humaines et operationnelles",
    color: "#8b5cf6",
  },
  {
    icon: Handshake,
    text: "Coordination des partenariats et projets de recherche",
    color: "#ec4899",
  },
];

const LEGEND = [
  { label: "Direction", color: "#f59e0b" },
  { label: "Fonctions Metiers", color: "#06b6d4" },
  { label: "Fonctions Operationnelles", color: "#a78bfa" },
];

export default function LoginPage() {
  const router = useRouter();
  const login = useAuthStore((s) => s.login);
  const lockoutMessage = useAuthStore((s) => s.lockoutMessage);

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    const success = await login(email, password);
    if (success) {
      router.push("/dashboard");
    } else if (!lockoutMessage) {
      setError("Identifiants invalides. Verifiez votre email et mot de passe.");
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen flex flex-col lg:flex-row bg-grid relative overflow-hidden">
      {/* Ambient glow effects */}
      <div className="absolute top-1/4 -left-32 w-96 h-96 bg-cyan-500/10 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-1/4 -right-32 w-96 h-96 bg-purple-500/10 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-cyan-500/[0.03] rounded-full blur-[200px] pointer-events-none" />

      {/* ============================================================ */}
      {/* LEFT PANEL — 3D Visualization + Description (desktop)         */}
      {/* ============================================================ */}
      <div className="hidden lg:flex lg:w-3/5 flex-col items-center justify-center p-8 xl:p-12 relative z-10">
        <div className="w-full max-w-2xl">
          {/* 3D Orbital Canvas */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1, ease: "easeOut" }}
            className="relative h-[420px] xl:h-[460px] rounded-2xl overflow-hidden"
          >
            <IpdOrbital3D />
            {/* Legend overlay */}
            <div className="absolute bottom-3 left-3 flex items-center gap-4 text-[10px] bg-black/40 rounded-lg px-3 py-1.5 backdrop-blur-sm border border-white/10">
              {LEGEND.map((item) => (
                <div key={item.label} className="flex items-center gap-1.5">
                  <div
                    className="h-2 w-2 rounded-full"
                    style={{ backgroundColor: item.color }}
                  />
                  <span className="text-white/60">{item.label}</span>
                </div>
              ))}
            </div>
          </motion.div>

          {/* Description */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.4 }}
            className="mt-5 glass rounded-2xl p-6 glow-border"
          >
            <h2 className="text-base font-bold text-white mb-2">
              Plateforme de Cyber-Gouvernance Integree
            </h2>
            <p className="text-xs text-muted-foreground leading-relaxed mb-4">
              Le Portail IPD centralise le pilotage strategique et operationnel de
              l&apos;Institut Pasteur de Dakar. Cette plateforme securisee unifie
              les fonctions metiers, operationnelles et transversales pour une
              gouvernance optimale de l&apos;ensemble des entites de l&apos;institut.
            </p>

            {/* Objectives */}
            <div className="space-y-2">
              {OBJECTIVES.map((obj, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.6 + i * 0.1 }}
                  className="flex items-center gap-3"
                >
                  <div
                    className="flex-shrink-0 w-6 h-6 rounded-md flex items-center justify-center"
                    style={{ backgroundColor: `${obj.color}15` }}
                  >
                    <obj.icon
                      className="h-3.5 w-3.5"
                      style={{ color: obj.color }}
                    />
                  </div>
                  <span className="text-xs text-white/70">{obj.text}</span>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>

      {/* ============================================================ */}
      {/* RIGHT PANEL — Login Form                                      */}
      {/* ============================================================ */}
      <div className="w-full lg:w-2/5 flex items-center justify-center p-4 sm:p-6 lg:p-8 relative z-10 min-h-screen lg:min-h-0">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
          className="w-full max-w-md"
        >
          {/* Logo & Title */}
          <div className="text-center mb-8">
            <motion.div
              initial={{ scale: 0.5, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.5 }}
              className="inline-flex items-center justify-center w-16 h-16 rounded-2xl glass glow-cyan mb-4"
            >
              <Shield className="h-8 w-8 text-cyan-400" />
            </motion.div>
            <h1 className="text-2xl font-bold neon-text">Portail IPD</h1>
            <p className="text-sm text-muted-foreground mt-1">
              Cyber-Gouvernance Integree
            </p>
          </div>

          {/* Mobile: compact 3D + description (hidden on desktop) */}
          <div className="lg:hidden mb-6">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8 }}
              className="relative h-[220px] rounded-xl overflow-hidden mb-4"
            >
              <IpdOrbital3D />
              {/* Legend */}
              <div className="absolute bottom-2 left-2 flex items-center gap-3 text-[9px] bg-black/40 rounded-md px-2 py-1 backdrop-blur-sm border border-white/10">
                {LEGEND.map((item) => (
                  <div key={item.label} className="flex items-center gap-1">
                    <div
                      className="h-1.5 w-1.5 rounded-full"
                      style={{ backgroundColor: item.color }}
                    />
                    <span className="text-white/50">{item.label}</span>
                  </div>
                ))}
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.3 }}
              className="glass rounded-xl p-4 mb-4"
            >
              <p className="text-[11px] text-muted-foreground leading-relaxed">
                Le Portail IPD centralise le pilotage strategique et operationnel
                de l&apos;Institut Pasteur de Dakar, unifiant les fonctions metiers,
                operationnelles et transversales pour une gouvernance optimale.
              </p>
            </motion.div>
          </div>

          {/* Login Form */}
          <div className="glass rounded-2xl p-8 glow-border">
            <form onSubmit={handleSubmit} className="space-y-5 relative z-10">
              <div>
                <label className="block text-sm font-medium text-muted-foreground mb-2">
                  Adresse email
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder:text-white/30 focus:outline-none focus:border-cyan-500/50 focus:ring-1 focus:ring-cyan-500/30 transition-all relative z-10"
                  placeholder="prenom.nom@pasteur.sn"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-muted-foreground mb-2">
                  Mot de passe
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder:text-white/30 focus:outline-none focus:border-cyan-500/50 focus:ring-1 focus:ring-cyan-500/30 transition-all pr-12 relative z-10"
                    placeholder="Entrez votre mot de passe"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-white/40 hover:text-white/70 transition-colors z-20"
                  >
                    {showPassword ? (
                      <EyeOff className="h-5 w-5" />
                    ) : (
                      <Eye className="h-5 w-5" />
                    )}
                  </button>
                </div>
              </div>

              {lockoutMessage && (
                <motion.div
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="text-sm text-amber-400 bg-amber-500/10 rounded-lg px-3 py-2 border border-amber-500/20"
                >
                  <div className="flex items-center gap-2">
                    <Lock className="h-4 w-4 flex-shrink-0" />
                    <span>{lockoutMessage}</span>
                  </div>
                </motion.div>
              )}

              {error && !lockoutMessage && (
                <motion.p
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="text-sm text-red-400 bg-red-500/10 rounded-lg px-3 py-2"
                >
                  {error}
                </motion.p>
              )}

              <button
                type="submit"
                disabled={loading}
                className="w-full py-3 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-medium transition-all duration-200 flex items-center justify-center gap-2 disabled:opacity-50 relative z-10"
              >
                {loading ? (
                  <div className="h-5 w-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                  <>
                    <LogIn className="h-5 w-5" />
                    Se connecter
                  </>
                )}
              </button>
            </form>
          </div>

          <p className="text-center text-xs text-muted-foreground mt-6">
            Institut Pasteur de Dakar &mdash; Portail Confidentiel
          </p>
        </motion.div>
      </div>
    </div>
  );
}
