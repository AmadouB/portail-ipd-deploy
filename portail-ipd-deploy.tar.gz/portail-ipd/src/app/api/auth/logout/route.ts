import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import {
  getAuthenticatedUser,
  getClientIp,
  unauthorized,
} from "@/lib/auth/middleware";

export async function POST(req: NextRequest) {
  try {
    const auth = await getAuthenticatedUser(req);

    if (!auth) {
      return unauthorized("Session invalide");
    }

    const ip = getClientIp(req);

    // Delete the session
    await prisma.session.delete({
      where: { id: auth.session.id },
    }).catch(() => {
      // Session may already be deleted; ignore
    });

    // Audit log
    await prisma.auditLog.create({
      data: {
        userId: auth.user.id,
        userName: `${auth.user.firstName} ${auth.user.lastName}`,
        action: "LOGOUT",
        module: "auth",
        detail: `Deconnexion depuis ${ip}`,
        ipAddress: ip,
      },
    });

    // Clear cookie
    const response = NextResponse.json({ success: true });
    response.cookies.set("ipd_token", "", {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      path: "/",
      maxAge: 0,
    });

    return response;
  } catch (error) {
    console.error("Logout error:", error);
    return NextResponse.json(
      { error: "Erreur interne du serveur" },
      { status: 500 }
    );
  }
}
