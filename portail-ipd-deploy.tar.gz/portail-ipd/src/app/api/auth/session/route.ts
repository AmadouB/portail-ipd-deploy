import { NextRequest, NextResponse } from "next/server";
import { getAuthenticatedUser, unauthorized } from "@/lib/auth/middleware";

export async function GET(req: NextRequest) {
  try {
    const auth = await getAuthenticatedUser(req);

    if (!auth) {
      return unauthorized("Session invalide ou expiree");
    }

    return NextResponse.json({
      user: auth.user,
      expiresAt: auth.session.expiresAt.toISOString(),
    });
  } catch (error) {
    console.error("Session check error:", error);
    return NextResponse.json(
      { error: "Erreur interne du serveur" },
      { status: 500 }
    );
  }
}
