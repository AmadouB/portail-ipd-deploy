import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { signToken } from "@/lib/auth/jwt";
import { getClientIp } from "@/lib/auth/middleware";
import { verifyPassword } from "@/lib/security/password";

const MAX_ATTEMPTS = 5;
const LOCKOUT_MINUTES = 15;
const ATTEMPT_WINDOW_MINUTES = 15;

export async function POST(req: NextRequest) {
  try {
    const { email, password } = await req.json();

    if (!email || !password) {
      return NextResponse.json(
        { error: "Email et mot de passe requis" },
        { status: 400 }
      );
    }

    const normalizedEmail = email.toLowerCase().trim();
    const ip = getClientIp(req);

    // ── Rate limiting ──────────────────────────────────────────
    const attempt = await prisma.loginAttempt.findUnique({
      where: { email: normalizedEmail },
    });

    if (attempt) {
      // Check if currently locked out
      if (attempt.lockedUntil && attempt.lockedUntil > new Date()) {
        const remainingMs = attempt.lockedUntil.getTime() - Date.now();
        const remainingMin = Math.ceil(remainingMs / 60000);
        return NextResponse.json(
          {
            error: `Compte verrouille. Reessayez dans ${remainingMin} minute(s).`,
            lockedUntil: attempt.lockedUntil.toISOString(),
            remainingMinutes: remainingMin,
          },
          { status: 429 }
        );
      }

      // Reset counter if window has expired
      const windowExpiry = new Date(
        attempt.firstAttempt.getTime() + ATTEMPT_WINDOW_MINUTES * 60000
      );
      if (windowExpiry < new Date()) {
        await prisma.loginAttempt.delete({
          where: { email: normalizedEmail },
        });
      }
    }

    // ── Find user ──────────────────────────────────────────────
    const user = await prisma.user.findFirst({
      where: { email: { equals: normalizedEmail, mode: "insensitive" } },
    });

    if (!user || !user.isActive) {
      await recordFailedAttempt(normalizedEmail);
      return NextResponse.json(
        { error: "Email ou mot de passe incorrect" },
        { status: 401 }
      );
    }

    // ── Verify password ────────────────────────────────────────
    const valid = await verifyPassword(password, user.password);

    if (!valid) {
      const lockInfo = await recordFailedAttempt(normalizedEmail);
      return NextResponse.json(
        {
          error: "Email ou mot de passe incorrect",
          ...(lockInfo.locked
            ? {
                lockedUntil: lockInfo.lockedUntil?.toISOString(),
                remainingMinutes: LOCKOUT_MINUTES,
              }
            : {
                attemptsRemaining: MAX_ATTEMPTS - lockInfo.count,
              }),
        },
        { status: 401 }
      );
    }

    // ── Success: clear attempts ────────────────────────────────
    await prisma.loginAttempt.deleteMany({
      where: { email: normalizedEmail },
    });

    // ── Create session ─────────────────────────────────────────
    const expiresAt = new Date();
    const expiryHours = parseInt(process.env.JWT_EXPIRY ?? "8", 10) || 8;
    expiresAt.setHours(expiresAt.getHours() + expiryHours);

    const session = await prisma.session.create({
      data: {
        userId: user.id,
        token: crypto.randomUUID(),
        ipAddress: ip,
        expiresAt,
      },
    });

    // ── Sign JWT ───────────────────────────────────────────────
    const token = signToken({
      userId: user.id,
      sessionId: session.id,
      email: user.email,
      role: user.role,
    });

    // ── Update last login ──────────────────────────────────────
    await prisma.user.update({
      where: { id: user.id },
      data: { lastLogin: new Date() },
    });

    // ── Audit log ──────────────────────────────────────────────
    await prisma.auditLog.create({
      data: {
        userId: user.id,
        userName: `${user.firstName} ${user.lastName}`,
        action: "LOGIN",
        module: "auth",
        detail: `Connexion reussie depuis ${ip}`,
        ipAddress: ip,
      },
    });

    // ── Build response with HttpOnly cookie ────────────────────
    const { password: _pw, ...userWithoutPassword } = user;

    const response = NextResponse.json({
      user: userWithoutPassword,
      token,
      expiresAt: expiresAt.toISOString(),
    });

    response.cookies.set("ipd_token", token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      path: "/",
      maxAge: expiryHours * 3600,
    });

    return response;
  } catch (error) {
    console.error("Login error:", error);
    return NextResponse.json(
      { error: "Erreur interne du serveur" },
      { status: 500 }
    );
  }
}

// ── Helpers ──────────────────────────────────────────────────────

async function recordFailedAttempt(email: string) {
  const now = new Date();

  const existing = await prisma.loginAttempt.findUnique({
    where: { email },
  });

  if (!existing) {
    const created = await prisma.loginAttempt.create({
      data: {
        email,
        count: 1,
        firstAttempt: now,
      },
    });
    return { count: created.count, locked: false, lockedUntil: null };
  }

  const newCount = existing.count + 1;
  const locked = newCount >= MAX_ATTEMPTS;
  const lockedUntil = locked
    ? new Date(now.getTime() + LOCKOUT_MINUTES * 60000)
    : null;

  await prisma.loginAttempt.update({
    where: { email },
    data: {
      count: newCount,
      lockedUntil,
    },
  });

  return { count: newCount, locked, lockedUntil };
}
