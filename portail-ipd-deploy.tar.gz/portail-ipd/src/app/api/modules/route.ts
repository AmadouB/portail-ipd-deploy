import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import {
  getAuthenticatedUser,
  getClientIp,
  unauthorized,
  forbidden,
} from "@/lib/auth/middleware";

/**
 * GET /api/modules — List all modules (public, RBAC filtering done client-side).
 */
export async function GET() {
  try {
    const modules = await prisma.module.findMany({
      orderBy: { priority: "asc" },
    });

    return NextResponse.json(modules);
  } catch (error) {
    console.error("GET /api/modules error:", error);
    return NextResponse.json(
      { error: "Erreur interne du serveur" },
      { status: 500 }
    );
  }
}

/**
 * POST /api/modules — Create a module (admin only).
 */
export async function POST(req: NextRequest) {
  try {
    const auth = await getAuthenticatedUser(req);
    if (!auth) return unauthorized();
    if (auth.user.role !== "admin_general") return forbidden();

    const body = await req.json();
    const {
      id,
      name,
      description,
      pole,
      icon,
      route,
      priority,
      type,
      color,
    } = body;

    if (!id || !name || !description || !pole || !icon || !route || !priority || !type || !color) {
      return NextResponse.json(
        { error: "Tous les champs obligatoires doivent etre renseignes" },
        { status: 400 }
      );
    }

    // Check for duplicate ID
    const existing = await prisma.module.findUnique({ where: { id } });
    if (existing) {
      return NextResponse.json(
        { error: "Un module avec cet identifiant existe deja" },
        { status: 409 }
      );
    }

    const mod = await prisma.module.create({
      data: {
        id,
        name,
        description,
        pole,
        icon,
        route,
        priority,
        type,
        color,
        kpiLabel: body.kpiLabel ?? null,
        kpiValue: body.kpiValue ?? null,
        kpiTrend: body.kpiTrend ?? null,
        enabled: body.enabled ?? true,
        externalUrl: body.externalUrl ?? null,
        htmlContent: body.htmlContent ?? null,
        htmlFileName: body.htmlFileName ?? null,
      },
    });

    const ip = getClientIp(req);

    await prisma.auditLog.create({
      data: {
        userId: auth.user.id,
        userName: `${auth.user.firstName} ${auth.user.lastName}`,
        action: "CREATE_MODULE",
        module: "modules",
        detail: `Module cree: ${mod.name} (${mod.id})`,
        ipAddress: ip,
      },
    });

    return NextResponse.json(mod, { status: 201 });
  } catch (error) {
    console.error("POST /api/modules error:", error);
    return NextResponse.json(
      { error: "Erreur interne du serveur" },
      { status: 500 }
    );
  }
}
