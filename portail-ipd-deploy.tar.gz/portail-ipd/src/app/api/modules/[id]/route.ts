import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import {
  getAuthenticatedUser,
  getClientIp,
  unauthorized,
  forbidden,
} from "@/lib/auth/middleware";

type RouteParams = { params: Promise<{ id: string }> };

/**
 * GET /api/modules/:id — Get a single module.
 */
export async function GET(_req: NextRequest, { params }: RouteParams) {
  try {
    const { id } = await params;

    const mod = await prisma.module.findUnique({ where: { id } });
    if (!mod) {
      return NextResponse.json(
        { error: "Module introuvable" },
        { status: 404 }
      );
    }

    return NextResponse.json(mod);
  } catch (error) {
    console.error("GET /api/modules/[id] error:", error);
    return NextResponse.json(
      { error: "Erreur interne du serveur" },
      { status: 500 }
    );
  }
}

/**
 * PATCH /api/modules/:id — Update module fields. Admin only.
 */
export async function PATCH(req: NextRequest, { params }: RouteParams) {
  try {
    const auth = await getAuthenticatedUser(req);
    if (!auth) return unauthorized();
    if (auth.user.role !== "admin_general") return forbidden();

    const { id } = await params;
    const body = await req.json();

    const allowedFields = [
      "name",
      "description",
      "pole",
      "icon",
      "route",
      "priority",
      "type",
      "color",
      "kpiLabel",
      "kpiValue",
      "kpiTrend",
      "enabled",
      "externalUrl",
      "htmlContent",
      "htmlFileName",
    ] as const;

    const data: Record<string, unknown> = {};
    for (const field of allowedFields) {
      if (body[field] !== undefined) {
        data[field] = body[field];
      }
    }

    if (Object.keys(data).length === 0) {
      return NextResponse.json(
        { error: "Aucun champ a mettre a jour" },
        { status: 400 }
      );
    }

    const mod = await prisma.module.update({
      where: { id },
      data,
    });

    const ip = getClientIp(req);

    await prisma.auditLog.create({
      data: {
        userId: auth.user.id,
        userName: `${auth.user.firstName} ${auth.user.lastName}`,
        action: "UPDATE_MODULE",
        module: "modules",
        detail: `Module modifie: ${mod.name} (champs: ${Object.keys(data).join(", ")})`,
        ipAddress: ip,
      },
    });

    return NextResponse.json(mod);
  } catch (error) {
    console.error("PATCH /api/modules/[id] error:", error);
    return NextResponse.json(
      { error: "Erreur interne du serveur" },
      { status: 500 }
    );
  }
}

/**
 * DELETE /api/modules/:id — Delete a module. Admin only.
 */
export async function DELETE(req: NextRequest, { params }: RouteParams) {
  try {
    const auth = await getAuthenticatedUser(req);
    if (!auth) return unauthorized();
    if (auth.user.role !== "admin_general") return forbidden();

    const { id } = await params;

    const mod = await prisma.module.findUnique({ where: { id } });
    if (!mod) {
      return NextResponse.json(
        { error: "Module introuvable" },
        { status: 404 }
      );
    }

    await prisma.module.delete({ where: { id } });

    const ip = getClientIp(req);

    await prisma.auditLog.create({
      data: {
        userId: auth.user.id,
        userName: `${auth.user.firstName} ${auth.user.lastName}`,
        action: "DELETE_MODULE",
        module: "modules",
        detail: `Module supprime: ${mod.name} (${mod.id})`,
        ipAddress: ip,
      },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("DELETE /api/modules/[id] error:", error);
    return NextResponse.json(
      { error: "Erreur interne du serveur" },
      { status: 500 }
    );
  }
}
