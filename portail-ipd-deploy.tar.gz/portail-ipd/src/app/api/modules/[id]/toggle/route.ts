import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import {
  getAuthenticatedUser,
  getClientIp,
  unauthorized,
  forbidden,
} from "@/lib/auth/middleware";

type RouteParams = { params: Promise<{ id: string }> };

/**
 * PATCH /api/modules/:id/toggle — Toggle module enabled state.
 */
export async function PATCH(req: NextRequest, { params }: RouteParams) {
  try {
    const auth = await getAuthenticatedUser(req);
    if (!auth) return unauthorized();
    if (auth.user.role !== "admin_general") return forbidden();

    const { id } = await params;

    const mod = await prisma.module.findUnique({ where: { id } });
    if (!mod) {
      return NextResponse.json(
        { error: "Module introuvable" },
        { status: 404 }
      );
    }

    const updated = await prisma.module.update({
      where: { id },
      data: { enabled: !mod.enabled },
    });

    const ip = getClientIp(req);

    await prisma.auditLog.create({
      data: {
        userId: auth.user.id,
        userName: `${auth.user.firstName} ${auth.user.lastName}`,
        action: updated.enabled ? "ENABLE_MODULE" : "DISABLE_MODULE",
        module: "modules",
        detail: `Module ${updated.enabled ? "active" : "desactive"}: ${updated.name}`,
        ipAddress: ip,
      },
    });

    return NextResponse.json(updated);
  } catch (error) {
    console.error("PATCH /api/modules/[id]/toggle error:", error);
    return NextResponse.json(
      { error: "Erreur interne du serveur" },
      { status: 500 }
    );
  }
}
