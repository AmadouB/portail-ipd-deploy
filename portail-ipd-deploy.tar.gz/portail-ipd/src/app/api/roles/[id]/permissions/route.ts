import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import {
  getAuthenticatedUser,
  getClientIp,
  unauthorized,
  forbidden,
} from "@/lib/auth/middleware";

type RouteParams = { params: Promise<{ id: string }> };

/**
 * PUT /api/roles/:id/permissions — Set (replace) all permissions for a role.
 * Body: { permissions: [{ moduleId, permission }] }
 */
export async function PUT(req: NextRequest, { params }: RouteParams) {
  try {
    const auth = await getAuthenticatedUser(req);
    if (!auth) return unauthorized();
    if (auth.user.role !== "admin_general") return forbidden();

    const { id } = await params;
    const body = await req.json();
    const { permissions } = body as {
      permissions: Array<{ moduleId: string; permission: string }>;
    };

    const existing = await prisma.role.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json(
        { error: "Role introuvable" },
        { status: 404 }
      );
    }

    if (!Array.isArray(permissions)) {
      return NextResponse.json(
        { error: "Le champ permissions doit etre un tableau" },
        { status: 400 }
      );
    }

    // Replace all permissions: delete existing, then create new ones
    await prisma.$transaction([
      prisma.rolePermission.deleteMany({ where: { roleId: id } }),
      prisma.rolePermission.createMany({
        data: permissions.map((p) => ({
          roleId: id,
          moduleId: p.moduleId,
          permission: p.permission,
        })),
      }),
    ]);

    const role = await prisma.role.findUnique({
      where: { id },
      include: { poles: true, permissions: true },
    });

    const ip = getClientIp(req);

    await prisma.auditLog.create({
      data: {
        userId: auth.user.id,
        userName: `${auth.user.firstName} ${auth.user.lastName}`,
        action: "SET_PERMISSIONS",
        module: "roles",
        detail: `Permissions mises a jour pour le role: ${existing.label} (${permissions.length} permission(s))`,
        ipAddress: ip,
      },
    });

    return NextResponse.json(role);
  } catch (error) {
    console.error("PUT /api/roles/[id]/permissions error:", error);
    return NextResponse.json(
      { error: "Erreur interne du serveur" },
      { status: 500 }
    );
  }
}

/**
 * DELETE /api/roles/:id/permissions — Remove specific permissions from a role.
 * Body: { permissions: [{ moduleId, permission }] }
 */
export async function DELETE(req: NextRequest, { params }: RouteParams) {
  try {
    const auth = await getAuthenticatedUser(req);
    if (!auth) return unauthorized();
    if (auth.user.role !== "admin_general") return forbidden();

    const { id } = await params;
    const body = await req.json();
    const { permissions } = body as {
      permissions: Array<{ moduleId: string; permission: string }>;
    };

    const existing = await prisma.role.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json(
        { error: "Role introuvable" },
        { status: 404 }
      );
    }

    if (!Array.isArray(permissions) || permissions.length === 0) {
      return NextResponse.json(
        { error: "Le champ permissions doit etre un tableau non vide" },
        { status: 400 }
      );
    }

    // Delete each specified permission
    for (const p of permissions) {
      await prisma.rolePermission.deleteMany({
        where: {
          roleId: id,
          moduleId: p.moduleId,
          permission: p.permission,
        },
      });
    }

    const role = await prisma.role.findUnique({
      where: { id },
      include: { poles: true, permissions: true },
    });

    const ip = getClientIp(req);

    await prisma.auditLog.create({
      data: {
        userId: auth.user.id,
        userName: `${auth.user.firstName} ${auth.user.lastName}`,
        action: "REMOVE_PERMISSIONS",
        module: "roles",
        detail: `Permissions supprimees du role: ${existing.label} (${permissions.length} permission(s))`,
        ipAddress: ip,
      },
    });

    return NextResponse.json(role);
  } catch (error) {
    console.error("DELETE /api/roles/[id]/permissions error:", error);
    return NextResponse.json(
      { error: "Erreur interne du serveur" },
      { status: 500 }
    );
  }
}
