import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import {
  getAuthenticatedUser,
  getClientIp,
  unauthorized,
  forbidden,
} from "@/lib/auth/middleware";

type RouteParams = { params: Promise<{ id: string }> };

/**
 * PATCH /api/roles/:id — Update role label and/or poles. Admin only.
 */
export async function PATCH(req: NextRequest, { params }: RouteParams) {
  try {
    const auth = await getAuthenticatedUser(req);
    if (!auth) return unauthorized();
    if (auth.user.role !== "admin_general") return forbidden();

    const { id } = await params;
    const body = await req.json();

    const existing = await prisma.role.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json(
        { error: "Role introuvable" },
        { status: 404 }
      );
    }

    // Update label if provided
    if (body.label) {
      await prisma.role.update({
        where: { id },
        data: { label: body.label },
      });
    }

    // Replace poles if provided
    if (Array.isArray(body.poles)) {
      await prisma.rolePole.deleteMany({ where: { roleId: id } });
      if (body.poles.length > 0) {
        await prisma.rolePole.createMany({
          data: (body.poles as string[]).map((pole) => ({
            roleId: id,
            pole,
          })),
        });
      }
    }

    const role = await prisma.role.findUnique({
      where: { id },
      include: { poles: true, permissions: true },
    });

    const ip = getClientIp(req);

    await prisma.auditLog.create({
      data: {
        userId: auth.user.id,
        userName: `${auth.user.firstName} ${auth.user.lastName}`,
        action: "UPDATE_ROLE",
        module: "roles",
        detail: `Role modifie: ${role!.label} (${role!.id})`,
        ipAddress: ip,
      },
    });

    return NextResponse.json(role);
  } catch (error) {
    console.error("PATCH /api/roles/[id] error:", error);
    return NextResponse.json(
      { error: "Erreur interne du serveur" },
      { status: 500 }
    );
  }
}

/**
 * DELETE /api/roles/:id — Delete a role. Admin only.
 */
export async function DELETE(req: NextRequest, { params }: RouteParams) {
  try {
    const auth = await getAuthenticatedUser(req);
    if (!auth) return unauthorized();
    if (auth.user.role !== "admin_general") return forbidden();

    const { id } = await params;

    const existing = await prisma.role.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json(
        { error: "Role introuvable" },
        { status: 404 }
      );
    }

    // Check if any user is using this role
    const usersWithRole = await prisma.user.count({ where: { role: id } });
    if (usersWithRole > 0) {
      return NextResponse.json(
        {
          error: `Impossible de supprimer ce role: ${usersWithRole} utilisateur(s) l'utilisent encore`,
        },
        { status: 400 }
      );
    }

    await prisma.role.delete({ where: { id } });

    const ip = getClientIp(req);

    await prisma.auditLog.create({
      data: {
        userId: auth.user.id,
        userName: `${auth.user.firstName} ${auth.user.lastName}`,
        action: "DELETE_ROLE",
        module: "roles",
        detail: `Role supprime: ${existing.label} (${existing.id})`,
        ipAddress: ip,
      },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("DELETE /api/roles/[id] error:", error);
    return NextResponse.json(
      { error: "Erreur interne du serveur" },
      { status: 500 }
    );
  }
}
