import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import {
  getAuthenticatedUser,
  getClientIp,
  unauthorized,
  forbidden,
} from "@/lib/auth/middleware";

/**
 * GET /api/roles — List all roles with poles and permissions.
 */
export async function GET(req: NextRequest) {
  try {
    const auth = await getAuthenticatedUser(req);
    if (!auth) return unauthorized();

    const roles = await prisma.role.findMany({
      include: {
        poles: true,
        permissions: true,
      },
      orderBy: { id: "asc" },
    });

    return NextResponse.json(roles);
  } catch (error) {
    console.error("GET /api/roles error:", error);
    return NextResponse.json(
      { error: "Erreur interne du serveur" },
      { status: 500 }
    );
  }
}

/**
 * POST /api/roles — Create a new role with poles and permissions. Admin only.
 */
export async function POST(req: NextRequest) {
  try {
    const auth = await getAuthenticatedUser(req);
    if (!auth) return unauthorized();
    if (auth.user.role !== "admin_general") return forbidden();

    const body = await req.json();
    const { id, label, poles, permissions } = body as {
      id: string;
      label: string;
      poles?: string[];
      permissions?: Array<{ moduleId: string; permission: string }>;
    };

    if (!id || !label) {
      return NextResponse.json(
        { error: "ID et label sont requis" },
        { status: 400 }
      );
    }

    // Check for duplicate ID
    const existing = await prisma.role.findUnique({ where: { id } });
    if (existing) {
      return NextResponse.json(
        { error: "Un role avec cet identifiant existe deja" },
        { status: 409 }
      );
    }

    const role = await prisma.role.create({
      data: {
        id,
        label,
        poles: poles?.length
          ? {
              create: poles.map((pole) => ({ pole })),
            }
          : undefined,
        permissions: permissions?.length
          ? {
              create: permissions.map((p) => ({
                moduleId: p.moduleId,
                permission: p.permission,
              })),
            }
          : undefined,
      },
      include: {
        poles: true,
        permissions: true,
      },
    });

    const ip = getClientIp(req);

    await prisma.auditLog.create({
      data: {
        userId: auth.user.id,
        userName: `${auth.user.firstName} ${auth.user.lastName}`,
        action: "CREATE_ROLE",
        module: "roles",
        detail: `Role cree: ${role.label} (${role.id})`,
        ipAddress: ip,
      },
    });

    return NextResponse.json(role, { status: 201 });
  } catch (error) {
    console.error("POST /api/roles error:", error);
    return NextResponse.json(
      { error: "Erreur interne du serveur" },
      { status: 500 }
    );
  }
}
