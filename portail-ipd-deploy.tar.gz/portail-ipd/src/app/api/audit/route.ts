import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import {
  getAuthenticatedUser,
  unauthorized,
  forbidden,
} from "@/lib/auth/middleware";

/**
 * GET /api/audit — Return audit logs (admin only), paginated, with filters.
 *
 * Query params:
 *   page     - Page number (default: 1)
 *   limit    - Items per page (default: 50, max: 200)
 *   action   - Filter by action type
 *   module   - Filter by module name
 *   userId   - Filter by user ID
 *   from     - Filter from date (ISO string)
 *   to       - Filter to date (ISO string)
 *   search   - Free-text search in detail field
 */
export async function GET(req: NextRequest) {
  try {
    const auth = await getAuthenticatedUser(req);
    if (!auth) return unauthorized();
    if (auth.user.role !== "admin_general") return forbidden();

    const { searchParams } = new URL(req.url);

    const page = Math.max(1, parseInt(searchParams.get("page") ?? "1", 10));
    const limit = Math.min(
      200,
      Math.max(1, parseInt(searchParams.get("limit") ?? "50", 10))
    );
    const skip = (page - 1) * limit;

    // Build filters
    const where: Record<string, unknown> = {};

    const action = searchParams.get("action");
    if (action) where.action = action;

    const module = searchParams.get("module");
    if (module) where.module = module;

    const userId = searchParams.get("userId");
    if (userId) where.userId = userId;

    const from = searchParams.get("from");
    const to = searchParams.get("to");
    if (from || to) {
      const timestampFilter: Record<string, Date> = {};
      if (from) timestampFilter.gte = new Date(from);
      if (to) timestampFilter.lte = new Date(to);
      where.timestamp = timestampFilter;
    }

    const search = searchParams.get("search");
    if (search) {
      where.detail = { contains: search, mode: "insensitive" };
    }

    const [logs, total] = await Promise.all([
      prisma.auditLog.findMany({
        where,
        orderBy: { timestamp: "desc" },
        skip,
        take: limit,
        include: {
          user: {
            select: {
              id: true,
              email: true,
              firstName: true,
              lastName: true,
            },
          },
        },
      }),
      prisma.auditLog.count({ where }),
    ]);

    return NextResponse.json({
      data: logs,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error("GET /api/audit error:", error);
    return NextResponse.json(
      { error: "Erreur interne du serveur" },
      { status: 500 }
    );
  }
}
