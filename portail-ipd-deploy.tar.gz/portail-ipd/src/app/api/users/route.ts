import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import {
  getAuthenticatedUser,
  getClientIp,
  unauthorized,
  forbidden,
} from "@/lib/auth/middleware";
import {
  hashPassword,
  generateStrongPassword,
} from "@/lib/security/password";

/**
 * GET /api/users — List all users (admin only).
 */
export async function GET(req: NextRequest) {
  try {
    const auth = await getAuthenticatedUser(req);
    if (!auth) return unauthorized();
    if (auth.user.role !== "admin_general") return forbidden();

    const users = await prisma.user.findMany({
      select: {
        id: true,
        email: true,
        firstName: true,
        lastName: true,
        role: true,
        pole: true,
        department: true,
        title: true,
        avatar: true,
        isActive: true,
        lastLogin: true,
        mfaEnabled: true,
        createdAt: true,
        updatedAt: true,
      },
      orderBy: { createdAt: "desc" },
    });

    return NextResponse.json(users);
  } catch (error) {
    console.error("GET /api/users error:", error);
    return NextResponse.json(
      { error: "Erreur interne du serveur" },
      { status: 500 }
    );
  }
}

/**
 * POST /api/users — Create a new user (admin only).
 * Returns the created user + the plain-text password for the admin to share.
 */
export async function POST(req: NextRequest) {
  try {
    const auth = await getAuthenticatedUser(req);
    if (!auth) return unauthorized();
    if (auth.user.role !== "admin_general") return forbidden();

    const body = await req.json();
    const { email, firstName, lastName, role, pole, department, title } = body;

    // Validate required fields
    if (!email || !firstName || !lastName || !role || !pole || !department || !title) {
      return NextResponse.json(
        { error: "Tous les champs obligatoires doivent etre renseignes" },
        { status: 400 }
      );
    }

    // Check for duplicate email
    const existing = await prisma.user.findFirst({
      where: { email: { equals: email.toLowerCase().trim(), mode: "insensitive" } },
    });

    if (existing) {
      return NextResponse.json(
        { error: "Un utilisateur avec cet email existe deja" },
        { status: 409 }
      );
    }

    // Generate and hash password
    const plainPassword = generateStrongPassword();
    const hashedPassword = await hashPassword(plainPassword);

    const user = await prisma.user.create({
      data: {
        email: email.toLowerCase().trim(),
        password: hashedPassword,
        firstName,
        lastName,
        role,
        pole,
        department,
        title,
        avatar: body.avatar ?? null,
      },
      select: {
        id: true,
        email: true,
        firstName: true,
        lastName: true,
        role: true,
        pole: true,
        department: true,
        title: true,
        avatar: true,
        isActive: true,
        createdAt: true,
        updatedAt: true,
      },
    });

    const ip = getClientIp(req);

    // Audit log
    await prisma.auditLog.create({
      data: {
        userId: auth.user.id,
        userName: `${auth.user.firstName} ${auth.user.lastName}`,
        action: "CREATE_USER",
        module: "users",
        detail: `Utilisateur cree: ${user.email}`,
        ipAddress: ip,
      },
    });

    return NextResponse.json(
      { user, temporaryPassword: plainPassword },
      { status: 201 }
    );
  } catch (error) {
    console.error("POST /api/users error:", error);
    return NextResponse.json(
      { error: "Erreur interne du serveur" },
      { status: 500 }
    );
  }
}
