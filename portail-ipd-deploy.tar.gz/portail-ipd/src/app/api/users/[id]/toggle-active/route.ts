import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import {
  getAuthenticatedUser,
  getClientIp,
  unauthorized,
  forbidden,
} from "@/lib/auth/middleware";

type RouteParams = { params: Promise<{ id: string }> };

/**
 * PATCH /api/users/:id/toggle-active — Toggle isActive.
 */
export async function PATCH(req: NextRequest, { params }: RouteParams) {
  try {
    const auth = await getAuthenticatedUser(req);
    if (!auth) return unauthorized();
    if (auth.user.role !== "admin_general") return forbidden();

    const { id } = await params;

    // Prevent self-deactivation
    if (id === auth.user.id) {
      return NextResponse.json(
        { error: "Vous ne pouvez pas desactiver votre propre compte" },
        { status: 400 }
      );
    }

    const user = await prisma.user.findUnique({ where: { id } });
    if (!user) {
      return NextResponse.json(
        { error: "Utilisateur introuvable" },
        { status: 404 }
      );
    }

    const updated = await prisma.user.update({
      where: { id },
      data: { isActive: !user.isActive },
      select: {
        id: true,
        email: true,
        firstName: true,
        lastName: true,
        role: true,
        pole: true,
        department: true,
        title: true,
        avatar: true,
        isActive: true,
        lastLogin: true,
        mfaEnabled: true,
        createdAt: true,
        updatedAt: true,
      },
    });

    const ip = getClientIp(req);

    await prisma.auditLog.create({
      data: {
        userId: auth.user.id,
        userName: `${auth.user.firstName} ${auth.user.lastName}`,
        action: updated.isActive ? "ACTIVATE_USER" : "DEACTIVATE_USER",
        module: "users",
        detail: `Utilisateur ${updated.isActive ? "active" : "desactive"}: ${updated.email}`,
        ipAddress: ip,
      },
    });

    // If deactivated, invalidate all sessions
    if (!updated.isActive) {
      await prisma.session.deleteMany({ where: { userId: id } });
    }

    return NextResponse.json(updated);
  } catch (error) {
    console.error("PATCH /api/users/[id]/toggle-active error:", error);
    return NextResponse.json(
      { error: "Erreur interne du serveur" },
      { status: 500 }
    );
  }
}
