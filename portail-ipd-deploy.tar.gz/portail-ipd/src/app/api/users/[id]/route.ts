import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import {
  getAuthenticatedUser,
  getClientIp,
  unauthorized,
  forbidden,
} from "@/lib/auth/middleware";

type RouteParams = { params: Promise<{ id: string }> };

/**
 * GET /api/users/:id — Get a single user (admin only).
 */
export async function GET(req: NextRequest, { params }: RouteParams) {
  try {
    const auth = await getAuthenticatedUser(req);
    if (!auth) return unauthorized();
    if (auth.user.role !== "admin_general") return forbidden();

    const { id } = await params;

    const user = await prisma.user.findUnique({
      where: { id },
      select: {
        id: true,
        email: true,
        firstName: true,
        lastName: true,
        role: true,
        pole: true,
        department: true,
        title: true,
        avatar: true,
        isActive: true,
        lastLogin: true,
        mfaEnabled: true,
        createdAt: true,
        updatedAt: true,
      },
    });

    if (!user) {
      return NextResponse.json(
        { error: "Utilisateur introuvable" },
        { status: 404 }
      );
    }

    return NextResponse.json(user);
  } catch (error) {
    console.error("GET /api/users/[id] error:", error);
    return NextResponse.json(
      { error: "Erreur interne du serveur" },
      { status: 500 }
    );
  }
}

/**
 * PATCH /api/users/:id — Update user fields (not password). Admin only.
 */
export async function PATCH(req: NextRequest, { params }: RouteParams) {
  try {
    const auth = await getAuthenticatedUser(req);
    if (!auth) return unauthorized();
    if (auth.user.role !== "admin_general") return forbidden();

    const { id } = await params;
    const body = await req.json();

    // Only allow updating these fields
    const allowedFields = [
      "email",
      "firstName",
      "lastName",
      "role",
      "pole",
      "department",
      "title",
      "avatar",
    ] as const;

    const data: Record<string, unknown> = {};
    for (const field of allowedFields) {
      if (body[field] !== undefined) {
        data[field] =
          field === "email"
            ? (body[field] as string).toLowerCase().trim()
            : body[field];
      }
    }

    if (Object.keys(data).length === 0) {
      return NextResponse.json(
        { error: "Aucun champ a mettre a jour" },
        { status: 400 }
      );
    }

    const user = await prisma.user.update({
      where: { id },
      data,
      select: {
        id: true,
        email: true,
        firstName: true,
        lastName: true,
        role: true,
        pole: true,
        department: true,
        title: true,
        avatar: true,
        isActive: true,
        lastLogin: true,
        mfaEnabled: true,
        createdAt: true,
        updatedAt: true,
      },
    });

    const ip = getClientIp(req);

    await prisma.auditLog.create({
      data: {
        userId: auth.user.id,
        userName: `${auth.user.firstName} ${auth.user.lastName}`,
        action: "UPDATE_USER",
        module: "users",
        detail: `Utilisateur modifie: ${user.email} (champs: ${Object.keys(data).join(", ")})`,
        ipAddress: ip,
      },
    });

    return NextResponse.json(user);
  } catch (error) {
    console.error("PATCH /api/users/[id] error:", error);
    return NextResponse.json(
      { error: "Erreur interne du serveur" },
      { status: 500 }
    );
  }
}

/**
 * DELETE /api/users/:id — Delete a user. Admin only.
 */
export async function DELETE(req: NextRequest, { params }: RouteParams) {
  try {
    const auth = await getAuthenticatedUser(req);
    if (!auth) return unauthorized();
    if (auth.user.role !== "admin_general") return forbidden();

    const { id } = await params;

    // Prevent self-deletion
    if (id === auth.user.id) {
      return NextResponse.json(
        { error: "Vous ne pouvez pas supprimer votre propre compte" },
        { status: 400 }
      );
    }

    const user = await prisma.user.findUnique({ where: { id } });
    if (!user) {
      return NextResponse.json(
        { error: "Utilisateur introuvable" },
        { status: 404 }
      );
    }

    await prisma.user.delete({ where: { id } });

    const ip = getClientIp(req);

    await prisma.auditLog.create({
      data: {
        userId: auth.user.id,
        userName: `${auth.user.firstName} ${auth.user.lastName}`,
        action: "DELETE_USER",
        module: "users",
        detail: `Utilisateur supprime: ${user.email}`,
        ipAddress: ip,
      },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("DELETE /api/users/[id] error:", error);
    return NextResponse.json(
      { error: "Erreur interne du serveur" },
      { status: 500 }
    );
  }
}
