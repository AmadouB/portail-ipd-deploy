import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import {
  getAuthenticatedUser,
  getClientIp,
  unauthorized,
  forbidden,
} from "@/lib/auth/middleware";
import {
  hashPassword,
  generateStrongPassword,
} from "@/lib/security/password";

type RouteParams = { params: Promise<{ id: string }> };

/**
 * POST /api/users/:id/reset-password — Generate and set a new password. Admin only.
 */
export async function POST(req: NextRequest, { params }: RouteParams) {
  try {
    const auth = await getAuthenticatedUser(req);
    if (!auth) return unauthorized();
    if (auth.user.role !== "admin_general") return forbidden();

    const { id } = await params;

    const user = await prisma.user.findUnique({ where: { id } });
    if (!user) {
      return NextResponse.json(
        { error: "Utilisateur introuvable" },
        { status: 404 }
      );
    }

    const plainPassword = generateStrongPassword();
    const hashedPassword = await hashPassword(plainPassword);

    await prisma.user.update({
      where: { id },
      data: { password: hashedPassword },
    });

    // Invalidate all existing sessions for this user
    await prisma.session.deleteMany({ where: { userId: id } });

    const ip = getClientIp(req);

    await prisma.auditLog.create({
      data: {
        userId: auth.user.id,
        userName: `${auth.user.firstName} ${auth.user.lastName}`,
        action: "RESET_PASSWORD",
        module: "users",
        detail: `Mot de passe reinitialise pour: ${user.email}`,
        ipAddress: ip,
      },
    });

    return NextResponse.json({ temporaryPassword: plainPassword });
  } catch (error) {
    console.error("POST /api/users/[id]/reset-password error:", error);
    return NextResponse.json(
      { error: "Erreur interne du serveur" },
      { status: 500 }
    );
  }
}
