import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { getAuthenticatedUser, unauthorized } from "@/lib/auth/middleware";

/**
 * GET /api/notifications — Get notifications for the current user.
 * Joins UserNotification to include read status.
 */
export async function GET(req: NextRequest) {
  try {
    const auth = await getAuthenticatedUser(req);
    if (!auth) return unauthorized();

    const userNotifications = await prisma.userNotification.findMany({
      where: { userId: auth.user.id },
      include: {
        notification: true,
      },
      orderBy: {
        notification: { createdAt: "desc" },
      },
    });

    const result = userNotifications.map((un) => ({
      id: un.notification.id,
      type: un.notification.type,
      title: un.notification.title,
      message: un.notification.message,
      moduleId: un.notification.moduleId,
      severity: un.notification.severity,
      actionUrl: un.notification.actionUrl,
      createdAt: un.notification.createdAt,
      read: un.read,
      readAt: un.readAt,
      userNotificationId: un.id,
    }));

    return NextResponse.json(result);
  } catch (error) {
    console.error("GET /api/notifications error:", error);
    return NextResponse.json(
      { error: "Erreur interne du serveur" },
      { status: 500 }
    );
  }
}
