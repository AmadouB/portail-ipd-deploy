import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { getAuthenticatedUser, unauthorized } from "@/lib/auth/middleware";

type RouteParams = { params: Promise<{ id: string }> };

/**
 * PATCH /api/notifications/:id/read — Mark a single notification as read.
 * :id here is the notification ID.
 */
export async function PATCH(req: NextRequest, { params }: RouteParams) {
  try {
    const auth = await getAuthenticatedUser(req);
    if (!auth) return unauthorized();

    const { id } = await params;

    const userNotification = await prisma.userNotification.findFirst({
      where: {
        userId: auth.user.id,
        notificationId: id,
      },
    });

    if (!userNotification) {
      return NextResponse.json(
        { error: "Notification introuvable" },
        { status: 404 }
      );
    }

    const updated = await prisma.userNotification.update({
      where: { id: userNotification.id },
      data: {
        read: true,
        readAt: new Date(),
      },
      include: { notification: true },
    });

    return NextResponse.json({
      id: updated.notification.id,
      read: updated.read,
      readAt: updated.readAt,
    });
  } catch (error) {
    console.error("PATCH /api/notifications/[id]/read error:", error);
    return NextResponse.json(
      { error: "Erreur interne du serveur" },
      { status: 500 }
    );
  }
}
