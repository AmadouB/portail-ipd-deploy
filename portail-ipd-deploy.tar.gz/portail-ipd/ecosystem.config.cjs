module.exports = {
  apps: [
    {
      name: "portail-ipd",
      script: "node_modules/.bin/next",
      args: "start -p 3000",
      cwd: "/var/www/portail-ipd",
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: "512M",
      env: {
        NODE_ENV: "production",
        PORT: 3000,
      },
      // Les variables sensibles sont dans .env sur le serveur
      // DATABASE_URL, JWT_SECRET, JWT_EXPIRY
    },
  ],
};
