# Configuration JumpServer — IMS NextGen

## Architecture d'accès

```
[Poste utilisateur] → [VPN IPD] → [JumpServer] → [Serveur IMS 10.99.1.10]
```

## 1. Enregistrement de l'asset dans JumpServer

### Créer l'asset (serveur cible)
- **Nom** : `IMS-NextGen-PROD`
- **IP** : `10.99.1.10`
- **Plateforme** : Linux / Ubuntu
- **Protocoles** : SSH (22)
- **Nœud** : `IPD / Applications / IMS`

### Créer le compte système
- **Nom** : `deploy-ims`
- **Type** : Compte Linux
- **Méthode d'authentification** : Clé SSH
- **Privilège** : Compte ordinaire (avec sudo)

### Créer le compte d'application (accès web)
- **Nom** : `ims-web`
- **Type** : Application Web
- **URL** : `http://10.99.1.10`
- **Port** : 80

## 2. Permissions dans JumpServer

### Groupe "IMS-Admins"
- Accès SSH au serveur 10.99.1.10
- Compte : deploy-ims
- Actions autorisées : Connexion, Upload, Download
- Session recording : Activé

### Groupe "IMS-Users"
- Accès Web uniquement à http://10.99.1.10
- Pas d'accès SSH
- Session recording : Optionnel

## 3. Connexion SSH via JumpServer

```bash
# Option A : Via le web terminal JumpServer
# 1. Se connecter à https://jumpserver.ipd.local
# 2. Assets → IMS-NextGen-PROD → Connecter

# Option B : Via SSH ProxyJump
ssh -J jumpuser@jumpserver.ipd.local deploy-ims@10.99.1.10

# Option C : Config SSH locale (~/.ssh/config)
# Voir ssh-config ci-dessous
```

## 4. Politique d'audit
- Toutes les sessions SSH sont enregistrées (vidéo + commandes)
- Les transferts de fichiers sont journalisés
- Alertes sur commandes dangereuses (rm -rf, shutdown, etc.)
