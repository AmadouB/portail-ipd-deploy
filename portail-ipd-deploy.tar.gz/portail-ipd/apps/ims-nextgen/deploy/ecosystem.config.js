// ══════════════════════════════════════════
// PM2 Ecosystem — IMS NextGen
// Serveur: 10.99.1.10
// ══════════════════════════════════════════

module.exports = {
  apps: [
    {
      name: "ims-nextgen",
      cwd: "/opt/ims-nextgen",
      script: "node_modules/.bin/next",
      args: "start -p 3000",
      instances: 1,
      exec_mode: "fork",
      env: {
        NODE_ENV: "production",
        PORT: 3000,
      },
      // Logs
      log_date_format: "YYYY-MM-DD HH:mm:ss",
      error_file: "/var/log/ims-nextgen/error.log",
      out_file: "/var/log/ims-nextgen/out.log",
      merge_logs: true,
      // Auto-restart
      max_restarts: 10,
      min_uptime: "10s",
      restart_delay: 5000,
      // Memory limit (restart si > 512MB)
      max_memory_restart: "512M",
      // Watch (désactivé en production)
      watch: false,
    },
  ],
};
