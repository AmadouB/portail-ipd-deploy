#!/bin/bash
# ══════════════════════════════════════════
# Sauvegarde automatique — IMS NextGen
# Cron: 0 2 * * * /opt/ims-nextgen/deploy/scripts/backup.sh
# ══════════════════════════════════════════

set -euo pipefail

APP_DIR="/opt/ims-nextgen"
BACKUP_DIR="/opt/backups/ims-nextgen"
DATE=$(date +%Y%m%d_%H%M)
RETENTION_DAYS=30

echo "[$(date)] Démarrage backup IMS NextGen..."

mkdir -p "$BACKUP_DIR"/{db,uploads,full}

# 1. Sauvegarde base de données
if [ -f "$APP_DIR/prisma/prod.db" ]; then
    cp "$APP_DIR/prisma/prod.db" "$BACKUP_DIR/db/prod_${DATE}.db"
    echo "  ✓ Base de données sauvegardée"
fi

# 2. Sauvegarde uploads
if [ -d "$APP_DIR/public/uploads" ]; then
    tar czf "$BACKUP_DIR/uploads/uploads_${DATE}.tar.gz" -C "$APP_DIR/public" uploads/ 2>/dev/null || true
    echo "  ✓ Uploads sauvegardés"
fi

# 3. Sauvegarde config
cp "$APP_DIR/.env.production" "$BACKUP_DIR/env_${DATE}.bak" 2>/dev/null || true
echo "  ✓ Configuration sauvegardée"

# 4. Backup complet hebdomadaire (dimanche uniquement)
if [ "$(date +%u)" = "7" ]; then
    tar czf "$BACKUP_DIR/full/ims_full_${DATE}.tar.gz" \
        --exclude='node_modules' \
        --exclude='.next' \
        --exclude='.git' \
        -C /opt ims-nextgen/ 2>/dev/null || true
    echo "  ✓ Backup complet hebdomadaire créé"
fi

# 5. Nettoyage des anciens backups
find "$BACKUP_DIR/db" -name "*.db" -mtime +${RETENTION_DAYS} -delete 2>/dev/null || true
find "$BACKUP_DIR/uploads" -name "*.tar.gz" -mtime +${RETENTION_DAYS} -delete 2>/dev/null || true
find "$BACKUP_DIR/full" -name "*.tar.gz" -mtime +90 -delete 2>/dev/null || true
echo "  ✓ Anciens backups nettoyés (rétention: ${RETENTION_DAYS}j)"

echo "[$(date)] Backup terminé avec succès"
