#!/bin/bash
# ══════════════════════════════════════════
# Mise à jour — IMS NextGen
# Usage: sudo -u deploy-ims bash update.sh
# ══════════════════════════════════════════

set -euo pipefail

APP_DIR="/opt/ims-nextgen"

echo "[$(date)] Mise à jour IMS NextGen..."

export NVM_DIR="$HOME/.nvm"
. "$NVM_DIR/nvm.sh"

cd ${APP_DIR}

# 1. Backup avant mise à jour
echo "▶ Sauvegarde pré-mise à jour..."
cp prisma/prod.db prisma/prod.db.pre-update-$(date +%Y%m%d_%H%M)

# 2. Pull du code
echo "▶ Récupération du code..."
git pull origin main

# 3. Dépendances
echo "▶ Installation des dépendances..."
npm ci

# 4. Migration base de données
echo "▶ Migration base de données..."
npx prisma generate
npx prisma db push

# 5. Build
echo "▶ Build de l'application..."
npm run build

# 6. Restart
echo "▶ Redémarrage..."
pm2 restart ims-nextgen

echo "✅ Mise à jour terminée — $(date)"
pm2 status
