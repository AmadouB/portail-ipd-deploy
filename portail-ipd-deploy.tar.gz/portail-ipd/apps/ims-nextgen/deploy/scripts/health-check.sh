#!/bin/bash
# ══════════════════════════════════════════
# Health Check — IMS NextGen
# Vérifie que tous les services fonctionnent
# ══════════════════════════════════════════

echo "════ IMS NextGen Health Check — $(date) ════"
echo ""

# 1. PM2
echo "▶ PM2 Status:"
pm2 jlist 2>/dev/null | python3 -c "
import json,sys
data=json.load(sys.stdin)
for app in data:
    status=app.get('pm2_env',{}).get('status','unknown')
    cpu=app.get('monit',{}).get('cpu',0)
    mem=round(app.get('monit',{}).get('memory',0)/1024/1024,1)
    restarts=app.get('pm2_env',{}).get('restart_time',0)
    print(f'  {app[\"name\"]}: {status} | CPU: {cpu}% | RAM: {mem}MB | Restarts: {restarts}')
" 2>/dev/null || echo "  ⚠ PM2 non disponible"

# 2. Application HTTP
echo ""
echo "▶ Application HTTP:"
HTTP_CODE=$(curl -sf -o /dev/null -w "%{http_code}" http://127.0.0.1:3000/dashboard 2>/dev/null || echo "000")
if [ "$HTTP_CODE" = "200" ]; then
    echo "  ✅ http://127.0.0.1:3000 → $HTTP_CODE OK"
else
    echo "  ❌ http://127.0.0.1:3000 → $HTTP_CODE ERREUR"
fi

# 3. API
echo ""
echo "▶ API Health:"
API_CODE=$(curl -sf -o /dev/null -w "%{http_code}" http://127.0.0.1:3000/api/kpi 2>/dev/null || echo "000")
if [ "$API_CODE" = "200" ]; then
    echo "  ✅ /api/kpi → $API_CODE OK"
else
    echo "  ❌ /api/kpi → $API_CODE ERREUR"
fi

# 4. Nginx
echo ""
echo "▶ Nginx:"
if systemctl is-active --quiet nginx; then
    echo "  ✅ Nginx actif"
else
    echo "  ❌ Nginx inactif"
fi

# 5. Base de données
echo ""
echo "▶ Base de données:"
DB_FILE="/opt/ims-nextgen/prisma/prod.db"
if [ -f "$DB_FILE" ]; then
    DB_SIZE=$(du -h "$DB_FILE" | cut -f1)
    echo "  ✅ prod.db: $DB_SIZE"
else
    DB_FILE="/opt/ims-nextgen/prisma/dev.db"
    if [ -f "$DB_FILE" ]; then
        DB_SIZE=$(du -h "$DB_FILE" | cut -f1)
        echo "  ✅ dev.db: $DB_SIZE"
    else
        echo "  ❌ Aucune base trouvée"
    fi
fi

# 6. Espace disque
echo ""
echo "▶ Espace disque:"
df -h /opt | tail -1 | awk '{print "  Utilisé: "$3" / "$2" ("$5" utilisé)"}'

# 7. Firewall
echo ""
echo "▶ Firewall UFW:"
ufw status 2>/dev/null | head -5 || echo "  ℹ UFW non disponible"

echo ""
echo "════ Fin du Health Check ════"
