#!/bin/bash
# ══════════════════════════════════════════════════════════════
# Script d'installation — IMS NextGen
# Serveur cible: Ubuntu 22.04/24.04 @ 10.99.1.10
# Exécuter en tant que root ou avec sudo
#
# Usage:
#   ssh deploy-ims@10.99.1.10 (via VPN + JumpServer)
#   sudo bash install.sh
# ══════════════════════════════════════════════════════════════

set -euo pipefail

# ── Configuration ──
APP_NAME="ims-nextgen"
APP_DIR="/opt/${APP_NAME}"
APP_USER="deploy-ims"
NODE_VERSION="20"
SERVER_IP="10.99.1.10"
VPN_SUBNET="10.99.0.0/16"
JUMPSERVER_IP="10.99.1.1"   # Adresse IP du JumpServer — AJUSTER SI NECESSAIRE

echo ""
echo "╔══════════════════════════════════════════════════════╗"
echo "║   IMS NextGen — Installation sur ${SERVER_IP}       ║"
echo "║   Institut Pasteur de Dakar                         ║"
echo "╚══════════════════════════════════════════════════════╝"
echo ""

# ══════════════════════════════════════
# ÉTAPE 1 : Mise à jour système
# ══════════════════════════════════════
echo "▶ [1/8] Mise à jour du système..."
apt update && apt upgrade -y
apt install -y curl git build-essential nginx ufw fail2ban

# ══════════════════════════════════════
# ÉTAPE 2 : Création utilisateur
# ══════════════════════════════════════
echo "▶ [2/8] Création de l'utilisateur ${APP_USER}..."
if ! id "${APP_USER}" &>/dev/null; then
    adduser --disabled-password --gecos "IMS NextGen Deploy" ${APP_USER}
    usermod -aG sudo ${APP_USER}
    echo "  ✓ Utilisateur ${APP_USER} créé"
else
    echo "  ℹ Utilisateur ${APP_USER} existe déjà"
fi

# Préparer le répertoire SSH pour recevoir la clé JumpServer
mkdir -p /home/${APP_USER}/.ssh
chmod 700 /home/${APP_USER}/.ssh
touch /home/${APP_USER}/.ssh/authorized_keys
chmod 600 /home/${APP_USER}/.ssh/authorized_keys
chown -R ${APP_USER}:${APP_USER} /home/${APP_USER}/.ssh

echo ""
echo "  ╔══════════════════════════════════════════════════════════╗"
echo "  ║  IMPORTANT — Configuration JumpServer                   ║"
echo "  ║                                                          ║"
echo "  ║  1. Dans JumpServer, créer un Asset :                    ║"
echo "  ║     - Nom : IMS-NextGen-PROD                             ║"
echo "  ║     - IP  : ${SERVER_IP}                                 ║"
echo "  ║     - Port: 22                                           ║"
echo "  ║     - Plateforme : Linux                                 ║"
echo "  ║                                                          ║"
echo "  ║  2. Créer un Compte Système :                            ║"
echo "  ║     - Username : ${APP_USER}                             ║"
echo "  ║     - Auth : Clé SSH (pousser la clé publique)           ║"
echo "  ║                                                          ║"
echo "  ║  3. Pousser la clé publique JumpServer :                 ║"
echo "  ║     La clé sera dans authorized_keys automatiquement     ║"
echo "  ║     si JumpServer gère les assets via push.              ║"
echo "  ║     Sinon, collez-la manuellement :                      ║"
echo "  ║     /home/${APP_USER}/.ssh/authorized_keys               ║"
echo "  ╚══════════════════════════════════════════════════════════╝"
echo ""
read -p "  Appuyez sur Entrée après avoir configuré JumpServer..."

# ══════════════════════════════════════
# ÉTAPE 3 : Installation Node.js via NVM
# ══════════════════════════════════════
echo "▶ [3/8] Installation Node.js ${NODE_VERSION}..."
su - ${APP_USER} -c '
    export NVM_DIR="$HOME/.nvm"
    if [ ! -d "$NVM_DIR" ]; then
        curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.1/install.sh | bash
    fi
    . "$NVM_DIR/nvm.sh"
    nvm install '"${NODE_VERSION}"'
    nvm alias default '"${NODE_VERSION}"'
    npm install -g pm2
    echo "  ✓ Node.js $(node --version) + PM2 installés"
'

# ══════════════════════════════════════
# ÉTAPE 4 : Déploiement de l'application
# ══════════════════════════════════════
echo "▶ [4/8] Déploiement de l'application..."
mkdir -p ${APP_DIR}
mkdir -p /var/log/${APP_NAME}
mkdir -p /opt/backups/${APP_NAME}
chown -R ${APP_USER}:${APP_USER} ${APP_DIR} /var/log/${APP_NAME} /opt/backups/${APP_NAME}

echo "  ℹ Copiez les fichiers du projet dans ${APP_DIR}"
echo "    Option A: scp -r ./* ${APP_USER}@${SERVER_IP}:${APP_DIR}/"
echo "    Option B: git clone <REPO_URL> ${APP_DIR}"
echo ""
read -p "  Appuyez sur Entrée une fois les fichiers copiés..."

# Installation des dépendances et build
su - ${APP_USER} -c '
    export NVM_DIR="$HOME/.nvm"
    . "$NVM_DIR/nvm.sh"
    cd '"${APP_DIR}"'

    # Copier le fichier d'environnement production
    if [ -f .env.production ]; then
        cp .env.production .env
    fi

    # Générer les secrets
    NEXTAUTH_SECRET=$(openssl rand -base64 32)
    CRON_SECRET=$(openssl rand -hex 24)
    sed -i "s|REMPLACER_PAR_openssl_rand_base64_32|${NEXTAUTH_SECRET}|" .env
    sed -i "s|REMPLACER_PAR_openssl_rand_hex_24|${CRON_SECRET}|" .env
    echo "  ✓ Secrets générés"

    # Installer dépendances
    npm ci
    echo "  ✓ Dépendances installées"

    # Générer Prisma Client
    npx prisma generate

    # Initialiser la base de données
    npx prisma db push
    npx tsx prisma/seed.ts
    echo "  ✓ Base de données initialisée avec données de seed"

    # Créer le dossier uploads
    mkdir -p public/uploads

    # Builder l'application
    npm run build
    echo "  ✓ Application buildée"
'

# ══════════════════════════════════════
# ÉTAPE 5 : Configuration Nginx
# ══════════════════════════════════════
echo "▶ [5/8] Configuration Nginx..."
cp ${APP_DIR}/deploy/nginx/ims-nextgen.conf /etc/nginx/sites-available/${APP_NAME}
ln -sf /etc/nginx/sites-available/${APP_NAME} /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default

# Test de la config Nginx
nginx -t
systemctl reload nginx
echo "  ✓ Nginx configuré et rechargé"

# ══════════════════════════════════════
# ÉTAPE 6 : Configuration Firewall
# ══════════════════════════════════════
echo "▶ [6/8] Configuration du firewall UFW + sécurisation JumpServer..."
ufw --force reset
ufw default deny incoming
ufw default allow outgoing

# SSH UNIQUEMENT depuis le JumpServer (bastion) — PAS depuis tout le VPN
ufw allow from ${JUMPSERVER_IP} to any port 22 proto tcp comment "SSH JumpServer only"

# HTTP/HTTPS depuis le réseau VPN (les utilisateurs accèdent via navigateur)
ufw allow from ${VPN_SUBNET} to any port 80 proto tcp comment "HTTP via VPN"
ufw allow from ${VPN_SUBNET} to any port 443 proto tcp comment "HTTPS via VPN"

ufw --force enable
echo "  ✓ Firewall configuré"
echo "    - SSH : uniquement depuis JumpServer (${JUMPSERVER_IP})"
echo "    - HTTP/HTTPS : depuis VPN (${VPN_SUBNET})"
ufw status verbose

# ── Sécurisation SSH pour JumpServer ──
echo ""
echo "  ▶ Sécurisation SSH (compatible JumpServer)..."
# Backup config SSH
cp /etc/ssh/sshd_config /etc/ssh/sshd_config.bak.$(date +%Y%m%d)

# Appliquer les règles de durcissement
cat > /etc/ssh/sshd_config.d/ims-hardening.conf << 'SSHEOF'
# ══ IMS NextGen — SSH Hardening (JumpServer compatible) ══
# Désactiver l'accès root direct
PermitRootLogin no

# Authentification par clé uniquement (JumpServer pousse les clés)
PubkeyAuthentication yes
PasswordAuthentication no

# Restreindre les utilisateurs autorisés
AllowUsers deploy-ims

# Sécurité session
MaxAuthTries 3
MaxSessions 5
ClientAliveInterval 300
ClientAliveCountMax 2
LoginGraceTime 30

# Désactiver le forwarding (sauf si besoin JumpServer)
AllowTcpForwarding no
X11Forwarding no
SSHEOF

# Recharger SSH
systemctl reload sshd
echo "  ✓ SSH durci (clé publique uniquement, root désactivé)"
echo "  ⚠ IMPORTANT : Assurez-vous que la clé publique JumpServer est dans"
echo "    /home/${APP_USER}/.ssh/authorized_keys AVANT de vous déconnecter !"

# ══════════════════════════════════════
# ÉTAPE 7 : Démarrage avec PM2
# ══════════════════════════════════════
echo "▶ [7/8] Démarrage de l'application avec PM2..."
su - ${APP_USER} -c '
    export NVM_DIR="$HOME/.nvm"
    . "$NVM_DIR/nvm.sh"
    cd '"${APP_DIR}"'

    pm2 start deploy/ecosystem.config.js
    pm2 save

    echo "  ✓ Application démarrée"
    pm2 status
'

# Configurer PM2 pour démarrage automatique au boot
env PATH=$PATH:/home/${APP_USER}/.nvm/versions/node/v${NODE_VERSION}.*/bin pm2 startup systemd -u ${APP_USER} --hp /home/${APP_USER} 2>/dev/null || true

# ══════════════════════════════════════
# ÉTAPE 8 : Tâches planifiées
# ══════════════════════════════════════
echo "▶ [8/8] Configuration des tâches planifiées..."

# Crontab pour l'utilisateur deploy-ims
CRON_SECRET=$(grep CRON_SECRET ${APP_DIR}/.env | cut -d'"' -f2)
su - ${APP_USER} -c "
(crontab -l 2>/dev/null; echo '# IMS NextGen — Moteur de Persistance (lundi 6h00)') | crontab -
(crontab -l 2>/dev/null; echo '0 6 * * 1 curl -sf -X POST http://127.0.0.1:3000/api/persistence/run -H \"Authorization: Bearer ${CRON_SECRET}\" >> /var/log/${APP_NAME}/persistence.log 2>&1') | crontab -
(crontab -l 2>/dev/null; echo '') | crontab -
(crontab -l 2>/dev/null; echo '# Sauvegarde quotidienne (2h00)') | crontab -
(crontab -l 2>/dev/null; echo '0 2 * * * /opt/${APP_NAME}/deploy/scripts/backup.sh >> /var/log/${APP_NAME}/backup.log 2>&1') | crontab -
"
chmod +x ${APP_DIR}/deploy/scripts/backup.sh
echo "  ✓ Cron configuré : persistance lundi 6h, backup quotidien 2h"

# ══════════════════════════════════════
# TERMINÉ
# ══════════════════════════════════════
echo ""
echo "╔══════════════════════════════════════════════════════════╗"
echo "║   ✅ Installation terminée avec succès !                ║"
echo "╠══════════════════════════════════════════════════════════╣"
echo "║                                                          ║"
echo "║   URL Application : http://${SERVER_IP}                  ║"
echo "║   Accès SSH       : via JumpServer → ${SERVER_IP}       ║"
echo "║   Utilisateur     : ${APP_USER}                          ║"
echo "║                                                          ║"
echo "║   ── Commandes utiles (via JumpServer) ──                ║"
echo "║   pm2 status                  → état de l'application    ║"
echo "║   pm2 logs ims-nextgen        → logs temps réel          ║"
echo "║   pm2 restart ims-nextgen     → redémarrer               ║"
echo "║   pm2 monit                   → monitoring CPU/RAM       ║"
echo "║   bash deploy/scripts/health-check.sh  → diagnostic     ║"
echo "║   bash deploy/scripts/update.sh        → mise à jour    ║"
echo "║                                                          ║"
echo "║   ── Checklist JumpServer ──                             ║"
echo "║   [ ] Asset IMS-NextGen-PROD enregistré                  ║"
echo "║   [ ] Compte ${APP_USER} configuré (clé SSH)             ║"
echo "║   [ ] Permissions attribuées (IMS-Admins, IMS-Users)     ║"
echo "║   [ ] Session recording activé                           ║"
echo "║   [ ] Commandes dangereuses filtrées                     ║"
echo "║                                                          ║"
echo "╚══════════════════════════════════════════════════════════╝"
echo ""
