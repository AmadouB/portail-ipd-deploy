#!/bin/bash
# ══════════════════════════════════════════════════════════════
# Déploiement IMS NextGen via JumpServer
# Exécuter DEPUIS le poste local (macOS) connecté au VPN
#
# Prérequis :
#   - VPN IPD connecté
#   - Config SSH avec JumpServer (voir deploy/jumpserver/ssh-config)
#   - Clé SSH configurée dans JumpServer
#
# Usage :
#   cd ims-nextgen/
#   bash deploy/scripts/deploy-via-jumpserver.sh
# ══════════════════════════════════════════════════════════════

set -euo pipefail

SERVER="ims-prod"  # Alias SSH défini dans ~/.ssh/config (via ProxyJump JumpServer)
REMOTE_DIR="/opt/ims-nextgen"

echo ""
echo "╔══════════════════════════════════════════════════════╗"
echo "║   IMS NextGen — Déploiement via JumpServer          ║"
echo "║   Cible: ${SERVER} → 10.99.1.10                    ║"
echo "╚══════════════════════════════════════════════════════╝"
echo ""

# Vérifier la connexion SSH via JumpServer
echo "▶ Test de connexion via JumpServer..."
if ! ssh -o ConnectTimeout=10 ${SERVER} "echo OK" 2>/dev/null; then
    echo "❌ Impossible de se connecter au serveur via JumpServer."
    echo "   Vérifiez :"
    echo "   1. VPN IPD actif"
    echo "   2. ~/.ssh/config contient la config JumpServer (voir deploy/jumpserver/ssh-config)"
    echo "   3. Asset enregistré dans JumpServer"
    exit 1
fi
echo "  ✓ Connexion JumpServer OK"

# Créer l'archive (sans node_modules, .next, .git)
echo ""
echo "▶ Création de l'archive de déploiement..."
tar czf /tmp/ims-nextgen-deploy.tar.gz \
    --exclude='node_modules' \
    --exclude='.next' \
    --exclude='.git' \
    --exclude='prisma/dev.db' \
    --exclude='prisma/dev.db.bak' \
    --exclude='public/uploads/*' \
    -C "$(dirname "$(pwd)")" "$(basename "$(pwd)")"
ARCHIVE_SIZE=$(du -h /tmp/ims-nextgen-deploy.tar.gz | cut -f1)
echo "  ✓ Archive créée: ${ARCHIVE_SIZE}"

# Transférer via JumpServer (scp passe par le ProxyJump)
echo ""
echo "▶ Transfert vers le serveur (via JumpServer)..."
scp /tmp/ims-nextgen-deploy.tar.gz ${SERVER}:/tmp/
echo "  ✓ Archive transférée"

# Déployer sur le serveur
echo ""
echo "▶ Déploiement sur le serveur..."
ssh ${SERVER} << 'DEPLOY_EOF'
set -euo pipefail

export NVM_DIR="$HOME/.nvm"
[ -s "$NVM_DIR/nvm.sh" ] && . "$NVM_DIR/nvm.sh"

REMOTE_DIR="/opt/ims-nextgen"
BACKUP_DATE=$(date +%Y%m%d_%H%M)

# Backup base de données avant mise à jour
if [ -f "$REMOTE_DIR/prisma/prod.db" ]; then
    cp "$REMOTE_DIR/prisma/prod.db" "$REMOTE_DIR/prisma/prod.db.pre-deploy-${BACKUP_DATE}"
    echo "  ✓ Base de données sauvegardée"
fi

# Sauvegarder .env
if [ -f "$REMOTE_DIR/.env" ]; then
    cp "$REMOTE_DIR/.env" /tmp/ims-env-backup
fi

# Extraire la nouvelle version
cd /opt
tar xzf /tmp/ims-nextgen-deploy.tar.gz
rm /tmp/ims-nextgen-deploy.tar.gz

# Restaurer .env
if [ -f /tmp/ims-env-backup ]; then
    cp /tmp/ims-env-backup "$REMOTE_DIR/.env"
    echo "  ✓ Configuration restaurée"
fi

cd $REMOTE_DIR

# Installer dépendances
npm ci
echo "  ✓ Dépendances installées"

# Prisma
npx prisma generate
npx prisma db push
echo "  ✓ Base de données migrée"

# Build
npm run build
echo "  ✓ Application buildée"

# Créer dossier uploads si absent
mkdir -p public/uploads

# Restart
if command -v pm2 &>/dev/null; then
    pm2 restart ims-nextgen 2>/dev/null || pm2 start deploy/ecosystem.config.js
    echo "  ✓ Application redémarrée (PM2)"
    pm2 status
fi

echo ""
echo "✅ Déploiement terminé — $(date)"
DEPLOY_EOF

# Nettoyage local
rm -f /tmp/ims-nextgen-deploy.tar.gz

echo ""
echo "╔══════════════════════════════════════════════════════╗"
echo "║   ✅ Déploiement terminé !                           ║"
echo "║   URL: http://10.99.1.10                            ║"
echo "║                                                      ║"
echo "║   Vérifier: ssh ims-prod 'bash ${REMOTE_DIR}/deploy/scripts/health-check.sh'"
echo "╚══════════════════════════════════════════════════════╝"
