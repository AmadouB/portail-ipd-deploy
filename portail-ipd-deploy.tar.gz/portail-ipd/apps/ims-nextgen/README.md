# IMS NextGen — Activity & Performance Tracker

> Plateforme de Suivi Intégré des Activités — **Institut Pasteur de Dakar**

[![Next.js](https://img.shields.io/badge/Next.js-16.1.7-000000?logo=next.js)](https://nextjs.org/)
[![React](https://img.shields.io/badge/React-19.2-61DAFB?logo=react)](https://react.dev/)
[![Prisma](https://img.shields.io/badge/Prisma-7.5-2D3748?logo=prisma)](https://www.prisma.io/)
[![TypeScript](https://img.shields.io/badge/TypeScript-5-3178C6?logo=typescript)](https://www.typescriptlang.org/)
[![Tailwind](https://img.shields.io/badge/Tailwind-4-38B2AC?logo=tailwind-css)](https://tailwindcss.com/)

## Vue d'ensemble

IMS NextGen est une plateforme web full-stack qui centralise le suivi des activités de tous les départements de l'IPD, mesure la performance en temps réel via des indicateurs automatisés, et intègre un moteur de persistance unique pour suivre les actions non résolues avec alertes de stagnation.

## Fonctionnalités principales

### 📊 Dashboard stratégique
- KPIs consolidés : taux de clôture, CAPA on-time, écarts majeurs, score risque AFM
- Jauges circulaires par département avec code couleur
- Heatmap de charge et graphiques de tendance
- Filtres multi-critères (service, workstream, criticité, période)

### ✏️ Saisie des activités
- Portail de saisie départementale exhaustif
- Création/modification d'actions AFM et écarts OMS
- Filtres avancés (service, statut, workstream, criticité, classification, macro-écart)
- Création inline de nouvelles entités (services, workstreams, fournisseurs, macro-écarts)
- Upload de justificatifs (PDF, Excel, Images — 10 Mo max)

### ⏱️ Moteur de persistance (différenciateur clé)
- Report automatique hebdomadaire des commentaires non résolus
- Compteur de persistance avec 4 niveaux d'alerte :
  - 🟢 **1-2 sem.** : suivi normal
  - 🟡 **3-4 sem.** : notification responsable
  - 🟠 **5-7 sem.** : escalade chef département
  - 🔴 **8+ sem.** : alerte stagnation critique
- Timeline interactive d'évolution des commentaires

### 🛡️ Modules départementaux
- **Production** — Planning, équipements, risques
- **LCQ** — Validation H₂O₂, PQ Isolateur, contamination
- **Assurance Qualité** — Workshop, CAPA OMS, Inspection Readiness, Routine
- **CQVM** — Indicateurs, systèmes à qualifier
- **SMS** — ACP, équipements, formation, KPI
- **Finance** — Suivi budgétaire et urgences
- **Analyse Produits** — Matrice entité × statut, fournisseurs, devises

### 📤 Exports automatisés
- **PDF** : rapport hebdomadaire avec page de garde IPD
- **PPTX** : 4 slides format direction
- **Excel** : 4 feuilles (Écarts, Actions, GARAP, Persistance)

### 🎨 Design IPD
- Charte graphique officielle (#0089D0 Bleu IPD, #052A62 Bleu Foncé)
- Logo officiel adaptatif (mode clair/sombre)
- Typographie Poppins (titres) + Lato (corps)
- Glassmorphism, mode sombre par défaut

## Stack technique

| Composant | Technologie |
|---|---|
| Framework | Next.js 16.1.7 (App Router + Turbopack) |
| Frontend | React 19.2, Tailwind CSS 4, shadcn/ui |
| Backend | Next.js API Routes (REST) |
| ORM | Prisma 7.5 |
| Base de données | SQLite (dev) / PostgreSQL (prod) |
| Auth | NextAuth.js + bcryptjs |
| Charts | Recharts 3.8 |
| Exports | jsPDF, PptxGenJS, ExcelJS |
| State | Zustand |

## Installation locale

```bash
# Cloner le repo
git clone https://github.com/AmadouB/ims-nextgen.git
cd ims-nextgen

# Installer les dépendances
npm install

# Configurer l'environnement
cp .env.production.example .env
# Éditer .env avec vos secrets

# Initialiser la base de données
npx prisma db push
npx tsx prisma/seed.ts

# Lancer en développement
npm run dev
# → http://localhost:3000
```

## Déploiement Production

Le déploiement est conçu pour un serveur Ubuntu accessible via **VPN + JumpServer** :

```bash
# Configuration JumpServer dans ~/.ssh/config
cat deploy/jumpserver/ssh-config >> ~/.ssh/config

# Déploiement automatisé
ssh ims-prod
sudo bash /opt/ims-nextgen/deploy/scripts/install.sh
```

Voir [`deploy/jumpserver/README-JUMPSERVER.md`](deploy/jumpserver/README-JUMPSERVER.md) pour les détails complets.

## Documentation

- 🚀 [Spécifications de déploiement](docs/IMS_NextGen_Specifications_Deploiement.docx)
- 👤 [Guide utilisateur](docs/IMS_NextGen_Guide_Utilisateur.docx)

## Architecture

```
ims-nextgen/
├── src/
│   ├── app/
│   │   ├── (platform)/        # Pages applicatives
│   │   ├── api/               # API REST routes
│   │   └── globals.css        # Charte IPD
│   ├── components/
│   │   ├── dashboard/         # KPIs, jauges, heatmap
│   │   ├── saisie/            # Module de saisie
│   │   ├── persistance/       # Moteur de persistance
│   │   ├── departments/       # Vues départementales
│   │   ├── produits/          # Analyse produits
│   │   └── layout/            # Sidebar, header
│   └── lib/
│       ├── prisma.ts          # Client BDD
│       ├── persistence.ts     # Algorithme persistance
│       └── exports/           # PDF, PPTX, XLSX
├── prisma/
│   └── schema.prisma          # 17 modèles
├── deploy/                    # Scripts production
└── public/                    # Logos, uploads
```

## Crédits

**Mission SEID** — Suivi-Évaluation & Intelligence de Données
Réalisé par **Amadou BAO**, Senior Consultant SEID

---

*© 2026 Institut Pasteur de Dakar — Document confidentiel à usage interne*
