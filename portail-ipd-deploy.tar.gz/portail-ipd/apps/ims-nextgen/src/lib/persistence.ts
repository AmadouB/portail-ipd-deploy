import type { PrismaClient } from "@/generated/prisma/client";

// Retourne la semaine ISO au format "2026-W15"
export function getIsoWeek(date: Date): string {
  const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
  d.setUTCDate(d.getUTCDate() + 4 - (d.getUTCDay() || 7));
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  const weekNo = Math.ceil(((d.getTime() - yearStart.getTime()) / 86400000 + 1) / 7);
  return `${d.getUTCFullYear()}-W${String(weekNo).padStart(2, "0")}`;
}

// Niveau de stagnation basé sur le nombre de semaines de persistance
export type StagnationLevel = "GREEN" | "YELLOW" | "ORANGE" | "RED";

export function getStagnationLevel(weeks: number): StagnationLevel {
  if (weeks >= 8) return "RED";
  if (weeks >= 5) return "ORANGE";
  if (weeks >= 3) return "YELLOW";
  return "GREEN";
}

export function getStagnationLabel(level: StagnationLevel): string {
  switch (level) {
    case "GREEN": return "Suivi normal";
    case "YELLOW": return "Notification responsable";
    case "ORANGE": return "Escalade chef de département";
    case "RED": return "Alerte stagnation critique";
  }
}

// Calcul du score RIV (Risk Impact Value) selon la matrice 5x5 du CDC
export function calculateRivScore(probabilite: number, impact: number): string {
  const matrix: Record<string, string> = {
    "1-1": "Low", "1-2": "Low", "1-3": "Low", "1-4": "Medium", "1-5": "Medium",
    "2-1": "Low", "2-2": "Low", "2-3": "Medium", "2-4": "Medium", "2-5": "High",
    "3-1": "Low", "3-2": "Medium", "3-3": "Medium", "3-4": "High", "3-5": "High",
    "4-1": "Medium", "4-2": "Medium", "4-3": "High", "4-4": "High", "4-5": "Critical",
    "5-1": "Medium", "5-2": "High", "5-3": "High", "5-4": "Critical", "5-5": "Critical",
  };
  return matrix[`${probabilite}-${impact}`] || "Medium";
}

interface JobStats {
  semaineIso: string;
  actionsProcessed: number;
  commentsCarried: number;
  alertsTriggered: number;
}

/**
 * Moteur de persistance — exécuté chaque lundi matin.
 *
 * Algorithme:
 * 1. Scanner toutes les actions/écarts ouverts
 * 2. Pour chaque item, trouver le dernier commentaire non résolu
 * 3. Créer un nouveau commentaire pour la semaine courante (report automatique)
 * 4. Incrémenter semainesPersistance
 * 5. Évaluer les seuils et créer des notifications d'escalade
 */
export async function runPersistenceJob(prisma: PrismaClient): Promise<JobStats> {
  const now = new Date();
  const currentWeek = getIsoWeek(now);

  const stats: JobStats = {
    semaineIso: currentWeek,
    actionsProcessed: 0,
    commentsCarried: 0,
    alertsTriggered: 0,
  };

  // 1. Scanner les actions ouvertes (statut != "Clôturé")
  const openActions = await prisma.actionAFM.findMany({
    where: { statut: { not: "Clôturé" } },
    include: {
      comments: {
        where: { isResolved: false },
        orderBy: { createdAt: "desc" },
        take: 1,
        include: { createdBy: true },
      },
      responsables: { include: { user: true } },
      workstream: true,
    },
  });

  for (const action of openActions) {
    stats.actionsProcessed++;
    const lastComment = action.comments[0];

    if (lastComment && lastComment.semaineIso !== currentWeek) {
      // Report automatique du commentaire
      const newPersistance = lastComment.semainesPersistance + 1;

      await prisma.comment.create({
        data: {
          actionId: action.id,
          parentCommentId: lastComment.id,
          texte: lastComment.texte,
          semaineIso: currentWeek,
          semainesPersistance: newPersistance,
          isResolved: false,
          createdById: lastComment.createdById,
        },
      });
      stats.commentsCarried++;

      // Évaluer les seuils de stagnation
      const level = getStagnationLevel(newPersistance);
      const prevLevel = getStagnationLevel(lastComment.semainesPersistance);

      // Ne créer une notification que si le niveau change
      if (level !== prevLevel && level !== "GREEN") {
        const responsableIds = action.responsables.map(r => r.userId);

        for (const userId of responsableIds) {
          await prisma.notification.create({
            data: {
              userId,
              type: `STAGNATION_${level}`,
              titre: `Alerte de stagnation — ${getStagnationLabel(level)}`,
              message: `L'action "${action.description.substring(0, 80)}..." est non résolue depuis ${newPersistance} semaines.`,
              lien: `/actions/${action.id}`,
            },
          });
          stats.alertsTriggered++;
        }
      }
    }
  }

  // 2. Scanner les écarts ouverts
  const openEcarts = await prisma.ecart.findMany({
    where: { statut: { not: "CLOTURE" } },
    include: {
      comments: {
        where: { isResolved: false },
        orderBy: { createdAt: "desc" },
        take: 1,
      },
      service: true,
    },
  });

  for (const ecart of openEcarts) {
    stats.actionsProcessed++;
    const lastComment = ecart.comments[0];

    if (lastComment && lastComment.semaineIso !== currentWeek) {
      const newPersistance = lastComment.semainesPersistance + 1;

      await prisma.comment.create({
        data: {
          ecartId: ecart.id,
          parentCommentId: lastComment.id,
          texte: lastComment.texte,
          semaineIso: currentWeek,
          semainesPersistance: newPersistance,
          isResolved: false,
          createdById: lastComment.createdById,
        },
      });
      stats.commentsCarried++;

      const level = getStagnationLevel(newPersistance);
      const prevLevel = getStagnationLevel(lastComment.semainesPersistance);

      if (level !== prevLevel && level !== "GREEN") {
        // Notifier le premier admin trouvé pour les écarts
        const admin = await prisma.user.findFirst({ where: { role: "ADMIN", actif: true } });
        if (admin) {
          await prisma.notification.create({
            data: {
              userId: admin.id,
              type: `STAGNATION_${level}`,
              titre: `Alerte stagnation écart ${ecart.numero}`,
              message: `L'écart "${ecart.nomEcart.substring(0, 80)}" est non résolu depuis ${newPersistance} semaines.`,
              lien: `/ecarts/${ecart.id}`,
            },
          });
          stats.alertsTriggered++;
        }
      }
    }
  }

  return stats;
}
