// IPD Brand Colors - pour utilisation dans Recharts et composants JS
// (Recharts ne peut pas lire les CSS variables)

export const IPD_COLORS = {
  bleu: '#0089D0',
  noir: '#000000',
  bleuFonce: '#052A62',
  bleuClair: '#86B4DD',
  orange: '#EF7A16',
  jaune: '#FFD500',
  vert: '#27AE60',
  rouge: '#E74C3C',
  gris: '#F2F3F5',
  beige: '#E3E0D8',
} as const;

// Couleurs pour les graphiques Recharts
export const CHART_COLORS = [
  IPD_COLORS.bleu,
  IPD_COLORS.bleuFonce,
  IPD_COLORS.vert,
  IPD_COLORS.orange,
  IPD_COLORS.jaune,
  IPD_COLORS.bleuClair,
  IPD_COLORS.rouge,
] as const;

// Couleurs de statut
export const STATUS_COLORS = {
  enCours: IPD_COLORS.bleu,
  enRetard: IPD_COLORS.orange,
  cloture: IPD_COLORS.vert,
  critique: IPD_COLORS.rouge,
} as const;

// Couleurs de stagnation (persistance)
export const STAGNATION_COLORS = {
  GREEN: IPD_COLORS.vert,      // 1-2 semaines
  YELLOW: IPD_COLORS.jaune,    // 3-4 semaines
  ORANGE: IPD_COLORS.orange,   // 5-7 semaines
  RED: IPD_COLORS.rouge,       // 8+ semaines
} as const;

// Seuils de taux de réalisation pour jauges
export const TR_THRESHOLDS = {
  good: { min: 80, color: IPD_COLORS.vert },
  warning: { min: 50, color: IPD_COLORS.orange },
  critical: { min: 0, color: IPD_COLORS.rouge },
} as const;

// Matrice de risques (probabilité x impact) → niveau
export const RISK_MATRIX: Record<string, string> = {
  '1-1': 'Low', '1-2': 'Low', '1-3': 'Low', '1-4': 'Medium', '1-5': 'Medium',
  '2-1': 'Low', '2-2': 'Low', '2-3': 'Medium', '2-4': 'Medium', '2-5': 'High',
  '3-1': 'Low', '3-2': 'Medium', '3-3': 'Medium', '3-4': 'High', '3-5': 'High',
  '4-1': 'Medium', '4-2': 'Medium', '4-3': 'High', '4-4': 'High', '4-5': 'Critical',
  '5-1': 'Medium', '5-2': 'High', '5-3': 'High', '5-4': 'Critical', '5-5': 'Critical',
};

export const RISK_LEVEL_COLORS: Record<string, string> = {
  Low: IPD_COLORS.vert,
  Medium: IPD_COLORS.jaune,
  High: IPD_COLORS.orange,
  Critical: IPD_COLORS.rouge,
};
