// Export PPTX hebdomadaire — présentation format IPD

export async function generateWeeklyPptx(data: {
  semaine: string;
  tauxCloture: number;
  totalEcarts: number;
  clotures: number;
  actionsEnCours: number;
  actionsEnRetard: number;
  stagnationSummary: { green: number; yellow: number; orange: number; red: number };
  topActions: { description: string; statut: string; avancement: number; responsable: string }[];
  topEcarts: { numero: string; nomEcart: string; statut: string; pctAvancement: number }[];
  serviceBreakdown: { code: string; total: number; clotures: number; taux: number }[];
}): Promise<Buffer> {
  const PptxGenJS = (await import("pptxgenjs")).default;
  const pptx = new PptxGenJS();

  pptx.layout = "LAYOUT_16x9";
  pptx.author = "IMS NextGen — Institut Pasteur de Dakar";

  // Slide 1: Titre
  const slide1 = pptx.addSlide();
  slide1.background = { color: "052A62" };
  slide1.addText("IMS NextGen", { x: 1, y: 1.5, w: 8, h: 1, fontSize: 36, color: "FFFFFF", fontFace: "Arial", bold: true, align: "center" });
  slide1.addText("Rapport de Progression Hebdomadaire", { x: 1, y: 2.5, w: 8, h: 0.6, fontSize: 18, color: "0089D0", fontFace: "Arial", align: "center" });
  slide1.addText(`Semaine ${data.semaine}`, { x: 1, y: 3.3, w: 8, h: 0.5, fontSize: 14, color: "86B4DD", fontFace: "Arial", align: "center" });
  slide1.addText("Institut Pasteur de Dakar", { x: 1, y: 5, w: 8, h: 0.4, fontSize: 10, color: "86B4DD", fontFace: "Arial", align: "center" });

  // Slide 2: KPIs
  const slide2 = pptx.addSlide();
  slide2.background = { color: "FFFFFF" };
  slide2.addText("Indicateurs Clés", { x: 0.5, y: 0.3, w: 9, h: 0.6, fontSize: 24, color: "052A62", fontFace: "Arial", bold: true });

  const kpis = [
    { label: "Taux de Clôture", value: `${data.tauxCloture}%`, color: data.tauxCloture >= 80 ? "27AE60" : data.tauxCloture >= 50 ? "EF7A16" : "E74C3C" },
    { label: "Écarts Totaux", value: `${data.totalEcarts}`, color: "0089D0" },
    { label: "Clôturés", value: `${data.clotures}`, color: "27AE60" },
    { label: "Actions en Retard", value: `${data.actionsEnRetard}`, color: "E74C3C" },
  ];

  kpis.forEach((kpi, i) => {
    const x = 0.5 + i * 2.3;
    slide2.addShape(pptx.ShapeType.roundRect, { x, y: 1.2, w: 2, h: 1.5, fill: { color: kpi.color }, rectRadius: 0.1 });
    slide2.addText(kpi.value, { x, y: 1.3, w: 2, h: 0.8, fontSize: 28, color: "FFFFFF", fontFace: "Arial", bold: true, align: "center", valign: "middle" });
    slide2.addText(kpi.label, { x, y: 2.1, w: 2, h: 0.4, fontSize: 9, color: "FFFFFF", fontFace: "Arial", align: "center" });
  });

  // Slide 3: Actions prioritaires
  const slide3 = pptx.addSlide();
  slide3.background = { color: "FFFFFF" };
  slide3.addText("Actions Prioritaires", { x: 0.5, y: 0.3, w: 9, h: 0.6, fontSize: 24, color: "052A62", fontFace: "Arial", bold: true });

  const actionRows = data.topActions.slice(0, 8).map(a => [
    { text: a.description.substring(0, 40), options: { fontSize: 8, color: "333333" } },
    { text: a.statut, options: { fontSize: 8, color: a.statut === "Clôturé" ? "27AE60" : a.statut === "En retard" ? "E74C3C" : "0089D0" } },
    { text: `${a.avancement}%`, options: { fontSize: 8, color: "333333", align: "center" as const } },
    { text: a.responsable, options: { fontSize: 8, color: "666666" } },
  ]);

  slide3.addTable(
    [[
      { text: "Description", options: { bold: true, fontSize: 9, color: "FFFFFF", fill: { color: "052A62" } } },
      { text: "Statut", options: { bold: true, fontSize: 9, color: "FFFFFF", fill: { color: "052A62" } } },
      { text: "Avancement", options: { bold: true, fontSize: 9, color: "FFFFFF", fill: { color: "052A62" } } },
      { text: "Responsable", options: { bold: true, fontSize: 9, color: "FFFFFF", fill: { color: "052A62" } } },
    ], ...actionRows],
    { x: 0.5, y: 1.2, w: 9, colW: [4, 1.5, 1.5, 2], border: { type: "solid", pt: 0.5, color: "E3E0D8" }, rowH: 0.35 }
  );

  // Slide 4: Stagnation
  const slide4 = pptx.addSlide();
  slide4.background = { color: "052A62" };
  slide4.addText("Moteur de Persistance", { x: 0.5, y: 0.3, w: 9, h: 0.6, fontSize: 24, color: "FFFFFF", fontFace: "Arial", bold: true });

  const stagItems = [
    { label: "1-2 sem", count: data.stagnationSummary.green, color: "27AE60" },
    { label: "3-4 sem", count: data.stagnationSummary.yellow, color: "FFD500" },
    { label: "5-7 sem", count: data.stagnationSummary.orange, color: "EF7A16" },
    { label: "8+ sem", count: data.stagnationSummary.red, color: "E74C3C" },
  ];

  stagItems.forEach((item, i) => {
    const x = 0.5 + i * 2.3;
    slide4.addShape(pptx.ShapeType.roundRect, { x, y: 1.5, w: 2, h: 2, fill: { color: item.color }, rectRadius: 0.1 });
    slide4.addText(String(item.count), { x, y: 1.6, w: 2, h: 1, fontSize: 36, color: "FFFFFF", bold: true, align: "center", valign: "middle" });
    slide4.addText(item.label, { x, y: 2.8, w: 2, h: 0.4, fontSize: 11, color: "FFFFFF", align: "center" });
  });

  const buffer = await pptx.write({ outputType: "nodebuffer" }) as Buffer;
  return buffer;
}
