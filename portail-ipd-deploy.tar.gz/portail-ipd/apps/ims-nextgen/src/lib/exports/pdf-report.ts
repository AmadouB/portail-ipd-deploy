// Export PDF hebdomadaire — génération côté serveur
// Utilise jspdf + jspdf-autotable

export async function generateWeeklyPdf(data: {
  semaine: string;
  tauxCloture: number;
  totalEcarts: number;
  clotures: number;
  actionsEnCours: number;
  actionsEnRetard: number;
  stagnationSummary: { green: number; yellow: number; orange: number; red: number };
  topActions: { description: string; statut: string; avancement: number; responsable: string }[];
  topEcarts: { numero: string; nomEcart: string; statut: string; pctAvancement: number }[];
}): Promise<Buffer> {
  const jsPDF = (await import("jspdf")).default;
  const autoTable = (await import("jspdf-autotable")).default;

  const doc = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });

  // Page de garde
  doc.setFillColor(5, 42, 98); // IPD Bleu Foncé
  doc.rect(0, 0, 210, 297, "F");

  doc.setTextColor(255, 255, 255);
  doc.setFontSize(28);
  doc.text("IMS NextGen", 105, 80, { align: "center" });

  doc.setFontSize(14);
  doc.setTextColor(0, 137, 208); // IPD Bleu
  doc.text("Rapport Hebdomadaire", 105, 100, { align: "center" });

  doc.setFontSize(20);
  doc.setTextColor(255, 255, 255);
  doc.text(`Semaine ${data.semaine}`, 105, 120, { align: "center" });

  doc.setFontSize(10);
  doc.setTextColor(200, 200, 200);
  doc.text("Institut Pasteur de Dakar", 105, 250, { align: "center" });
  doc.text(`Généré le ${new Date().toLocaleDateString("fr-FR")}`, 105, 258, { align: "center" });

  // Page KPI
  doc.addPage();
  doc.setFillColor(255, 255, 255);
  doc.rect(0, 0, 210, 297, "F");

  doc.setTextColor(5, 42, 98);
  doc.setFontSize(18);
  doc.text("Indicateurs Clés de Performance", 20, 25);

  doc.setDrawColor(0, 137, 208);
  doc.setLineWidth(0.5);
  doc.line(20, 30, 190, 30);

  // KPI boxes
  const kpis = [
    { label: "Taux de Clôture", value: `${data.tauxCloture}%`, color: data.tauxCloture >= 80 ? [39, 174, 96] : data.tauxCloture >= 50 ? [239, 122, 22] : [231, 76, 60] },
    { label: "Écarts Totaux", value: `${data.totalEcarts}`, color: [0, 137, 208] },
    { label: "Écarts Clôturés", value: `${data.clotures}`, color: [39, 174, 96] },
    { label: "Actions en Retard", value: `${data.actionsEnRetard}`, color: [231, 76, 60] },
  ];

  kpis.forEach((kpi, i) => {
    const x = 20 + (i % 2) * 85;
    const y = 40 + Math.floor(i / 2) * 35;

    doc.setFillColor(kpi.color[0], kpi.color[1], kpi.color[2]);
    doc.roundedRect(x, y, 75, 28, 3, 3, "F");

    doc.setTextColor(255, 255, 255);
    doc.setFontSize(20);
    doc.text(kpi.value, x + 37.5, y + 14, { align: "center" });
    doc.setFontSize(8);
    doc.text(kpi.label, x + 37.5, y + 22, { align: "center" });
  });

  // Table des actions prioritaires
  doc.setTextColor(5, 42, 98);
  doc.setFontSize(14);
  doc.text("Actions Prioritaires", 20, 125);

  autoTable(doc, {
    startY: 130,
    head: [["Description", "Statut", "Avancement", "Responsable"]],
    body: data.topActions.map(a => [
      a.description.substring(0, 50),
      a.statut,
      `${a.avancement}%`,
      a.responsable,
    ]),
    theme: "grid",
    headStyles: { fillColor: [5, 42, 98], textColor: [255, 255, 255], fontSize: 8 },
    bodyStyles: { fontSize: 7, textColor: [50, 50, 50] },
    alternateRowStyles: { fillColor: [242, 243, 245] },
    margin: { left: 20, right: 20 },
  });

  // Stagnation summary
  const finalY = (doc as any).lastAutoTable?.finalY || 200;
  doc.setFontSize(14);
  doc.setTextColor(5, 42, 98);
  doc.text("Résumé Stagnation", 20, finalY + 15);

  const stagData = [
    ["1-2 semaines (Vert)", String(data.stagnationSummary.green)],
    ["3-4 semaines (Jaune)", String(data.stagnationSummary.yellow)],
    ["5-7 semaines (Orange)", String(data.stagnationSummary.orange)],
    ["8+ semaines (Rouge)", String(data.stagnationSummary.red)],
  ];

  autoTable(doc, {
    startY: finalY + 20,
    head: [["Niveau", "Nombre"]],
    body: stagData,
    theme: "grid",
    headStyles: { fillColor: [5, 42, 98], textColor: [255, 255, 255], fontSize: 8 },
    bodyStyles: { fontSize: 8 },
    margin: { left: 20, right: 20 },
    columnStyles: { 0: { cellWidth: 100 }, 1: { cellWidth: 40, halign: "center" } },
  });

  return Buffer.from(doc.output("arraybuffer"));
}
