// Export Excel — données brutes filtrables

export async function generateExcelExport(data: {
  ecarts: any[];
  actions: any[];
  garap: any[];
  comments: any[];
}): Promise<Buffer> {
  const ExcelJS = (await import("exceljs")).default;
  const workbook = new ExcelJS.Workbook();
  workbook.creator = "IMS NextGen — Institut Pasteur de Dakar";
  workbook.created = new Date();

  const headerStyle = {
    font: { bold: true, color: { argb: "FFFFFFFF" }, name: "Arial", size: 10 },
    fill: { type: "pattern" as const, pattern: "solid" as const, fgColor: { argb: "FF052A62" } },
    border: {
      top: { style: "thin" as const, color: { argb: "FFE3E0D8" } },
      bottom: { style: "thin" as const, color: { argb: "FFE3E0D8" } },
    },
  };

  // Feuille Écarts
  const wsEcarts = workbook.addWorksheet("Écarts OMS", { views: [{ state: "frozen", ySplit: 1 }] });
  wsEcarts.columns = [
    { header: "N° Écart", key: "numero", width: 12 },
    { header: "Nom", key: "nomEcart", width: 40 },
    { header: "Service", key: "service", width: 12 },
    { header: "Classification", key: "classification", width: 15 },
    { header: "Statut", key: "statut", width: 12 },
    { header: "Avancement %", key: "pctAvancement", width: 14 },
    { header: "Probabilité", key: "probabilite", width: 12 },
    { header: "Impact", key: "impact", width: 10 },
    { header: "Score RIV", key: "scoreRiv", width: 12 },
    { header: "Date Finalisation", key: "dateFinalisation", width: 16 },
  ];
  wsEcarts.getRow(1).eachCell(cell => Object.assign(cell, headerStyle));
  for (const e of data.ecarts) {
    wsEcarts.addRow({
      numero: e.numero,
      nomEcart: e.nomEcart,
      service: e.service?.code || "",
      classification: e.classification,
      statut: e.statut,
      pctAvancement: e.pctAvancement,
      probabilite: e.probabilite,
      impact: e.impact,
      scoreRiv: e.scoreRiv,
      dateFinalisation: e.dateFinalisation,
    });
  }

  // Feuille Actions AFM
  const wsActions = workbook.addWorksheet("Actions AFM", { views: [{ state: "frozen", ySplit: 1 }] });
  wsActions.columns = [
    { header: "ID", key: "id", width: 8 },
    { header: "Description", key: "description", width: 50 },
    { header: "Workstream", key: "workstream", width: 12 },
    { header: "Statut", key: "statut", width: 12 },
    { header: "Importance", key: "importance", width: 12 },
    { header: "Urgence", key: "urgence", width: 10 },
    { header: "Avancement %", key: "avancement", width: 14 },
    { header: "Criticité", key: "niveauCriticite", width: 12 },
    { header: "Deadline", key: "deadlineInitiale", width: 14 },
  ];
  wsActions.getRow(1).eachCell(cell => Object.assign(cell, headerStyle));
  for (const a of data.actions) {
    wsActions.addRow({
      id: a.id,
      description: a.description,
      workstream: a.workstream?.code || "",
      statut: a.statut,
      importance: a.importance,
      urgence: a.urgence,
      avancement: a.avancement,
      niveauCriticite: a.niveauCriticite,
      deadlineInitiale: a.deadlineInitiale,
    });
  }

  // Feuille GARAP
  const wsGarap = workbook.addWorksheet("GARAP Supply Chain", { views: [{ state: "frozen", ySplit: 1 }] });
  wsGarap.columns = [
    { header: "ID", key: "id", width: 8 },
    { header: "Entité", key: "entite", width: 10 },
    { header: "Nature Produits", key: "natureProduits", width: 30 },
    { header: "Fournisseur", key: "fournisseur", width: 20 },
    { header: "N° DA/BC", key: "numDaBc", width: 15 },
    { header: "Montant", key: "montant", width: 12 },
    { header: "Devise", key: "devise", width: 8 },
    { header: "Statut", key: "statutWorkflow", width: 18 },
    { header: "Date Livraison Prévue", key: "dateLivraisonPrevue", width: 18 },
  ];
  wsGarap.getRow(1).eachCell(cell => Object.assign(cell, headerStyle));
  for (const g of data.garap) {
    wsGarap.addRow({
      id: g.id,
      entite: g.entite?.code || "",
      natureProduits: g.natureProduits,
      fournisseur: g.fournisseur?.raisonSociale || "",
      numDaBc: g.numDaBc,
      montant: g.montant,
      devise: g.devise?.codeIso || "",
      statutWorkflow: g.statutWorkflow,
      dateLivraisonPrevue: g.dateLivraisonPrevue,
    });
  }

  // Feuille Commentaires / Persistance
  const wsComments = workbook.addWorksheet("Persistance", { views: [{ state: "frozen", ySplit: 1 }] });
  wsComments.columns = [
    { header: "ID", key: "id", width: 8 },
    { header: "Semaine", key: "semaineIso", width: 12 },
    { header: "Texte", key: "texte", width: 50 },
    { header: "Persistance (sem)", key: "semainesPersistance", width: 16 },
    { header: "Résolu", key: "isResolved", width: 10 },
    { header: "Créé par", key: "createdBy", width: 15 },
    { header: "Action ID", key: "actionId", width: 10 },
    { header: "Écart ID", key: "ecartId", width: 10 },
  ];
  wsComments.getRow(1).eachCell(cell => Object.assign(cell, headerStyle));
  for (const c of data.comments) {
    wsComments.addRow({
      id: c.id,
      semaineIso: c.semaineIso,
      texte: c.texte,
      semainesPersistance: c.semainesPersistance,
      isResolved: c.isResolved ? "Oui" : "Non",
      createdBy: c.createdBy?.name || "",
      actionId: c.actionId,
      ecartId: c.ecartId,
    });
  }

  const buffer = await workbook.xlsx.writeBuffer();
  return Buffer.from(buffer);
}
