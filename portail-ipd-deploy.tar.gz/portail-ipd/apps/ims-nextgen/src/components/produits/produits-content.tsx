"use client";

import { useEffect, useState, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend,
} from "recharts";
import {
  Package, TrendingUp, DollarSign, Building2, Truck, Search, Filter, X, ChevronDown,
  CheckCircle2, Clock, AlertTriangle, ArrowUpDown,
} from "lucide-react";
import { CHART_COLORS } from "@/lib/colors";

interface Produit {
  id: number;
  entite: string;
  natureProduits: string;
  fournisseur: string;
  numDaBc: string;
  montant: number;
  devise: string;
  commentaireDal: string;
  statut: string;
}

const STATUT_COLORS: Record<string, string> = {
  "Clôturé": "#27AE60",
  "Chez le transitaire": "#0089D0",
  "Attente retour fournisseur": "#EF7A16",
  "Attente paiement": "#FFD500",
  "Attente création DA": "#86B4DD",
  "Attente retour entité": "#E74C3C",
  "Traitement DAL": "#052A62",
  "Non défini": "#64748b",
};

const TOOLTIP_STYLE = { background: "#031A40", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 8, color: "#fff", fontSize: 13 };

export function ProduitsContent() {
  const [data, setData] = useState<Produit[]>([]);
  const [loading, setLoading] = useState(true);

  // Filters
  const [search, setSearch] = useState("");
  const [fEntite, setFEntite] = useState("");
  const [fStatut, setFStatut] = useState("");
  const [fFournisseur, setFFournisseur] = useState("");
  const [fDevise, setFDevise] = useState("");
  const [showFilters, setShowFilters] = useState(false);
  const [sortCol, setSortCol] = useState<string>("id");
  const [sortDir, setSortDir] = useState<"asc" | "desc">("asc");

  useEffect(() => {
    fetch("/api/produits").then(r => r.json()).then(d => setData(d.produits || [])).finally(() => setLoading(false));
  }, []);

  // Dynamic filter options
  const entites = useMemo(() => [...new Set(data.map(p => p.entite))].sort(), [data]);
  const statuts = useMemo(() => [...new Set(data.map(p => p.statut))].sort(), [data]);
  const fournisseurs = useMemo(() => [...new Set(data.map(p => p.fournisseur).filter(Boolean))].sort(), [data]);
  const devises = useMemo(() => [...new Set(data.map(p => p.devise).filter(Boolean))].sort(), [data]);

  // Filtering
  const filtered = useMemo(() => {
    let result = data;
    if (search) {
      const q = search.toLowerCase();
      result = result.filter(p =>
        p.natureProduits.toLowerCase().includes(q) ||
        p.fournisseur.toLowerCase().includes(q) ||
        p.numDaBc.toLowerCase().includes(q) ||
        p.commentaireDal.toLowerCase().includes(q)
      );
    }
    if (fEntite) result = result.filter(p => p.entite === fEntite);
    if (fStatut) result = result.filter(p => p.statut === fStatut);
    if (fFournisseur) result = result.filter(p => p.fournisseur === fFournisseur);
    if (fDevise) result = result.filter(p => p.devise === fDevise);

    // Sorting
    result = [...result].sort((a, b) => {
      let va: any = (a as any)[sortCol];
      let vb: any = (b as any)[sortCol];
      if (typeof va === "string") va = va.toLowerCase();
      if (typeof vb === "string") vb = vb.toLowerCase();
      if (va < vb) return sortDir === "asc" ? -1 : 1;
      if (va > vb) return sortDir === "asc" ? 1 : -1;
      return 0;
    });

    return result;
  }, [data, search, fEntite, fStatut, fFournisseur, fDevise, sortCol, sortDir]);

  const activeFilters = [fEntite, fStatut, fFournisseur, fDevise].filter(Boolean).length;

  function clearFilters() { setSearch(""); setFEntite(""); setFStatut(""); setFFournisseur(""); setFDevise(""); }
  function toggleSort(col: string) {
    if (sortCol === col) setSortDir(sortDir === "asc" ? "desc" : "asc");
    else { setSortCol(col); setSortDir("asc"); }
  }

  // ── KPI Calculations ──
  const totalProduits = data.length;
  const totalCloture = data.filter(p => p.statut === "Clôturé").length;
  const totalEnCours = totalProduits - totalCloture;
  const montantTotalEur = data.filter(p => p.devise === "€").reduce((s, p) => s + p.montant, 0);
  const montantTotalUsd = data.filter(p => p.devise === "$").reduce((s, p) => s + p.montant, 0);
  const montantTotalCfa = data.filter(p => p.devise === "F CFA").reduce((s, p) => s + p.montant, 0);
  const nbFournisseurs = new Set(data.map(p => p.fournisseur).filter(Boolean)).size;

  // ── Chart Data ──
  const parEntite = useMemo(() => {
    const map: Record<string, { total: number; cloture: number; montant: number }> = {};
    data.forEach(p => {
      if (!map[p.entite]) map[p.entite] = { total: 0, cloture: 0, montant: 0 };
      map[p.entite].total++;
      if (p.statut === "Clôturé") map[p.entite].cloture++;
      map[p.entite].montant += p.montant;
    });
    return Object.entries(map).map(([name, v]) => ({ name, ...v, enCours: v.total - v.cloture }));
  }, [data]);

  const parStatut = useMemo(() => {
    const map: Record<string, number> = {};
    data.forEach(p => { map[p.statut] = (map[p.statut] || 0) + 1; });
    return Object.entries(map).map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value);
  }, [data]);

  const parFournisseur = useMemo(() => {
    const map: Record<string, { count: number; montant: number }> = {};
    data.forEach(p => {
      if (!p.fournisseur) return;
      if (!map[p.fournisseur]) map[p.fournisseur] = { count: 0, montant: 0 };
      map[p.fournisseur].count++;
      map[p.fournisseur].montant += p.montant;
    });
    return Object.entries(map).map(([name, v]) => ({ name, ...v })).sort((a, b) => b.count - a.count).slice(0, 12);
  }, [data]);

  // Matrice entité x statut
  const matriceData = useMemo(() => {
    const statutList = [...new Set(data.map(p => p.statut))].sort();
    const entiteList = [...new Set(data.map(p => p.entite))].sort();
    return { statutList, entiteList, cells: entiteList.map(ent => {
      const row: any = { entite: ent };
      statutList.forEach(st => { row[st] = data.filter(p => p.entite === ent && p.statut === st).length; });
      row.total = data.filter(p => p.entite === ent).length;
      return row;
    }) };
  }, [data]);

  if (loading) return <div className="p-8 text-white/50">Chargement des données produits...</div>;

  const fmt = (n: number) => n.toLocaleString("fr-FR", { maximumFractionDigits: 0 });

  return (
    <div className="p-6 space-y-6">

      {/* ═══ KPI CARDS ═══ */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        <KpiCard icon={Package} label="Total produits" value={totalProduits} color="#0089D0" />
        <KpiCard icon={CheckCircle2} label="Clôturés" value={totalCloture} color="#27AE60" />
        <KpiCard icon={Clock} label="En cours" value={totalEnCours} color="#EF7A16" />
        <KpiCard icon={DollarSign} label="Montant EUR" value={`${fmt(montantTotalEur)} €`} color="#052A62" />
        <KpiCard icon={DollarSign} label="Montant CFA" value={`${fmt(montantTotalCfa)} F`} color="#FFD500" />
        <KpiCard icon={Truck} label="Fournisseurs" value={nbFournisseurs} color="#86B4DD" />
      </div>

      {/* ═══ CHARTS ROW 1: Entité + Statut ═══ */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card className="glass">
          <CardHeader><CardTitle className="text-base text-white">Répartition par Entité</CardTitle></CardHeader>
          <CardContent>
            <div className="h-[280px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={parEntite} layout="vertical">
                  <XAxis type="number" tick={{ fill: "rgba(255,255,255,0.5)", fontSize: 12 }} />
                  <YAxis type="category" dataKey="name" width={80} tick={{ fill: "rgba(255,255,255,0.7)", fontSize: 13, fontWeight: 600 }} />
                  <Tooltip contentStyle={TOOLTIP_STYLE} />
                  <Legend wrapperStyle={{ fontSize: 12, color: "rgba(255,255,255,0.6)" }} />
                  <Bar dataKey="cloture" name="Clôturés" fill="#27AE60" stackId="a" radius={[0, 0, 0, 0]} />
                  <Bar dataKey="enCours" name="En cours" fill="#EF7A16" stackId="a" radius={[0, 4, 4, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card className="glass">
          <CardHeader><CardTitle className="text-base text-white">Répartition par Statut</CardTitle></CardHeader>
          <CardContent>
            <div className="h-[280px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={parStatut} cx="50%" cy="50%" outerRadius={100} innerRadius={50} dataKey="value" paddingAngle={2}
                    label={({ name, percent }: any) => `${name.substring(0, 15)} (${Math.round((percent || 0) * 100)}%)`}
                    labelLine={{ stroke: "rgba(255,255,255,0.2)" }}
                  >
                    {parStatut.map((s, i) => (
                      <Cell key={i} fill={STATUT_COLORS[s.name] || CHART_COLORS[i % CHART_COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip contentStyle={TOOLTIP_STYLE} />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* ═══ CHARTS ROW 2: Fournisseurs ═══ */}
      <Card className="glass">
        <CardHeader><CardTitle className="text-base text-white">Top Fournisseurs (par nombre de commandes)</CardTitle></CardHeader>
        <CardContent>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={parFournisseur}>
                <XAxis dataKey="name" tick={{ fill: "rgba(255,255,255,0.5)", fontSize: 11 }} angle={-30} textAnchor="end" height={80} />
                <YAxis tick={{ fill: "rgba(255,255,255,0.4)", fontSize: 12 }} />
                <Tooltip contentStyle={TOOLTIP_STYLE} formatter={(v: any) => [`${v}`, "Commandes"]} />
                <Bar dataKey="count" name="Commandes" fill="#0089D0" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* ═══ MATRICE ENTITÉ × STATUT ═══ */}
      <Card className="glass">
        <CardHeader><CardTitle className="text-base text-white">Matrice Entité × Statut</CardTitle></CardHeader>
        <CardContent className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr>
                <th className="py-2 px-3 text-left text-[11px] uppercase tracking-wider text-white/55 font-bold border-b border-white/[0.06]">Entité</th>
                {matriceData.statutList.map(st => (
                  <th key={st} className="py-2 px-2 text-center text-[10px] uppercase tracking-wider text-white/45 font-bold border-b border-white/[0.06]" style={{ minWidth: 70 }}>
                    <span className="inline-block w-2 h-2 rounded-full mr-1" style={{ backgroundColor: STATUT_COLORS[st] || "#64748b" }} />
                    {st.substring(0, 18)}
                  </th>
                ))}
                <th className="py-2 px-3 text-center text-[11px] uppercase tracking-wider text-white/55 font-bold border-b border-white/[0.06]">Total</th>
              </tr>
            </thead>
            <tbody>
              {matriceData.cells.map(row => (
                <tr key={row.entite} className="border-b border-white/[0.04] hover:bg-white/[0.03]">
                  <td className="py-2.5 px-3 font-semibold text-white/80">{row.entite}</td>
                  {matriceData.statutList.map(st => {
                    const count = row[st] || 0;
                    return (
                      <td key={st} className="py-2.5 px-2 text-center">
                        {count > 0 ? (
                          <span className="inline-flex items-center justify-center min-w-[24px] h-6 rounded-md text-xs font-bold px-1.5"
                            style={{ backgroundColor: `${STATUT_COLORS[st] || "#64748b"}20`, color: STATUT_COLORS[st] || "#64748b" }}>
                            {count}
                          </span>
                        ) : <span className="text-white/15">—</span>}
                      </td>
                    );
                  })}
                  <td className="py-2.5 px-3 text-center font-bold text-white">{row.total}</td>
                </tr>
              ))}
              {/* Totals row */}
              <tr className="border-t-2 border-white/[0.1] bg-white/[0.02]">
                <td className="py-2.5 px-3 font-bold text-white/70">TOTAL</td>
                {matriceData.statutList.map(st => {
                  const total = matriceData.cells.reduce((s, r) => s + (r[st] || 0), 0);
                  return <td key={st} className="py-2.5 px-2 text-center font-bold text-white/60">{total}</td>;
                })}
                <td className="py-2.5 px-3 text-center font-black text-[#0089D0] text-base">{data.length}</td>
              </tr>
            </tbody>
          </table>
        </CardContent>
      </Card>

      {/* ═══ FILTERS + TABLE ═══ */}
      <Card className="glass">
        <CardHeader>
          <div className="flex items-center justify-between flex-wrap gap-3">
            <CardTitle className="text-base text-white">Détail des Produits & Commandes</CardTitle>
            <div className="flex items-center gap-2 text-sm text-white/45">
              {filtered.length} / {data.length} lignes
              {activeFilters > 0 && (
                <button onClick={clearFilters} className="flex items-center gap-1 text-xs text-white/40 hover:text-[#E74C3C] ml-2">
                  <X className="h-3 w-3" /> Effacer
                </button>
              )}
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Filters */}
          <div className="flex gap-3 flex-wrap items-center">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-white/30" />
              <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Rechercher produit, fournisseur, N°DA/BC..."
                className="w-full rounded-lg border border-white/[0.08] bg-white/[0.04] pl-9 pr-3 py-2.5 text-sm text-white/80 placeholder:text-white/30 focus:border-[#0089D0]/30 focus:outline-none" />
            </div>
            <select value={fEntite} onChange={e => setFEntite(e.target.value)} className="fsel">
              <option value="">🏢 Toutes entités</option>
              {entites.map(e => <option key={e} value={e}>{e} ({data.filter(p => p.entite === e).length})</option>)}
            </select>
            <select value={fStatut} onChange={e => setFStatut(e.target.value)} className="fsel">
              <option value="">📊 Tous statuts</option>
              {statuts.map(s => <option key={s} value={s}>{s} ({data.filter(p => p.statut === s).length})</option>)}
            </select>
            <button onClick={() => setShowFilters(!showFilters)} className={`flex items-center gap-1.5 rounded-lg border px-3 py-2.5 text-sm transition-all ${showFilters ? "border-[#0089D0]/25 bg-[#0089D0]/10 text-[#0089D0]" : "border-white/[0.08] text-white/50"}`}>
              <Filter className="h-3.5 w-3.5" /> Plus
              {activeFilters > 0 && <span className="flex h-4.5 min-w-4.5 items-center justify-center rounded-full bg-[#0089D0] px-1 text-[10px] font-bold text-white">{activeFilters}</span>}
            </button>
          </div>

          {showFilters && (
            <div className="flex gap-3 flex-wrap items-center rounded-xl border border-white/[0.06] bg-white/[0.02] p-3">
              <select value={fFournisseur} onChange={e => setFFournisseur(e.target.value)} className="fsel">
                <option value="">🚚 Tous fournisseurs</option>
                {fournisseurs.map(f => <option key={f} value={f}>{f} ({data.filter(p => p.fournisseur === f).length})</option>)}
              </select>
              <select value={fDevise} onChange={e => setFDevise(e.target.value)} className="fsel">
                <option value="">💱 Toutes devises</option>
                {devises.map(d => <option key={d} value={d}>{d} ({data.filter(p => p.devise === d).length})</option>)}
              </select>
            </div>
          )}

          {/* Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-white/[0.06]">
                  {[
                    { key: "entite", label: "Entité", w: "80px" },
                    { key: "natureProduits", label: "Nature Produits", w: "auto" },
                    { key: "fournisseur", label: "Fournisseur", w: "120px" },
                    { key: "numDaBc", label: "N°DA/BC", w: "110px" },
                    { key: "montant", label: "Montant", w: "100px" },
                    { key: "devise", label: "Dev.", w: "50px" },
                    { key: "statut", label: "Statut", w: "140px" },
                  ].map(col => (
                    <th key={col.key} onClick={() => toggleSort(col.key)}
                      className="py-3 px-3 text-left text-[11px] uppercase tracking-wider text-white/55 font-bold cursor-pointer hover:text-white/70 select-none"
                      style={{ minWidth: col.w }}>
                      <span className="flex items-center gap-1">
                        {col.label}
                        {sortCol === col.key && <ArrowUpDown className="h-3 w-3 text-[#0089D0]" />}
                      </span>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map(p => (
                  <tr key={p.id} className="border-b border-white/[0.04] hover:bg-white/[0.03] transition-colors">
                    <td className="py-2.5 px-3"><Badge className="bg-white/[0.08] text-white/60 text-[11px]">{p.entite}</Badge></td>
                    <td className="py-2.5 px-3 text-white/80 max-w-[300px]">
                      <span className="block truncate">{p.natureProduits}</span>
                      {p.commentaireDal && <span className="block text-xs text-white/35 truncate mt-0.5">{p.commentaireDal.substring(0, 60)}</span>}
                    </td>
                    <td className="py-2.5 px-3 text-white/60">{p.fournisseur || "—"}</td>
                    <td className="py-2.5 px-3 font-mono text-xs text-[#0089D0]">{p.numDaBc || "—"}</td>
                    <td className="py-2.5 px-3 text-right font-mono text-white/70">{p.montant > 0 ? fmt(p.montant) : "—"}</td>
                    <td className="py-2.5 px-3 text-center text-white/50">{p.devise}</td>
                    <td className="py-2.5 px-3">
                      <Badge className="text-[11px]" style={{
                        backgroundColor: `${STATUT_COLORS[p.statut] || "#64748b"}18`,
                        color: STATUT_COLORS[p.statut] || "#64748b",
                        border: `1px solid ${STATUT_COLORS[p.statut] || "#64748b"}30`,
                      }}>{p.statut}</Badge>
                    </td>
                  </tr>
                ))}
                {filtered.length === 0 && (
                  <tr><td colSpan={7} className="py-12 text-center text-white/30">Aucun produit trouvé</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      <style jsx global>{`
        .fsel {
          border-radius: 8px; border: 1px solid rgba(255,255,255,0.08); background: rgba(255,255,255,0.04);
          padding: 10px 12px; font-size: 14px; color: rgba(255,255,255,0.7); min-width: 150px; font-family: var(--font-sans);
        }
        .fsel:focus { outline: none; border-color: rgba(0,137,208,0.3); }
        .fsel option { background: #031A40; color: rgba(255,255,255,0.8); }
      `}</style>
    </div>
  );
}

function KpiCard({ icon: Icon, label, value, color }: { icon: any; label: string; value: string | number; color: string }) {
  return (
    <Card className="glass">
      <CardContent className="pt-5 pb-4">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-[11px] text-white/45 uppercase tracking-wider font-medium">{label}</p>
            <p className="text-2xl font-bold text-white mt-1">{value}</p>
          </div>
          <Icon className="h-6 w-6" style={{ color, opacity: 0.5 }} />
        </div>
      </CardContent>
    </Card>
  );
}
