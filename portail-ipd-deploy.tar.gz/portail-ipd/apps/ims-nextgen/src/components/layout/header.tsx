"use client";

import { Bell } from "lucide-react";
import { useEffect, useState } from "react";

interface HeaderProps {
  title: string;
  subtitle?: string;
}

export function Header({ title, subtitle }: HeaderProps) {
  const [unreadCount, setUnreadCount] = useState(0);
  const [showNotifs, setShowNotifs] = useState(false);
  const [notifications, setNotifications] = useState<any[]>([]);

  useEffect(() => {
    fetch("/api/notifications?unreadOnly=true&limit=5")
      .then(r => r.ok ? r.json() : { notifications: [], unreadCount: 0 })
      .then(d => {
        setUnreadCount(d.unreadCount ?? 0);
        setNotifications(d.notifications ?? []);
      })
      .catch(() => {});
  }, []);

  const markRead = async (id: number) => {
    await fetch("/api/notifications", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id, isRead: true }) });
    setNotifications(prev => prev.filter(n => n.id !== id));
    setUnreadCount(prev => Math.max(0, prev - 1));
  };

  return (
    <header className="border-b border-white/[0.06] bg-[#031A40]/80 backdrop-blur-xl px-6 py-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">{title}</h1>
          {subtitle && <p className="text-base text-white/60 mt-0.5">{subtitle}</p>}
        </div>
        <div className="flex items-center gap-3">
          {/* Notification Bell */}
          <div className="relative">
            <button
              onClick={() => setShowNotifs(!showNotifs)}
              className="relative flex items-center justify-center rounded-xl bg-white/[0.04] p-2 text-white/60 hover:text-white hover:bg-white/[0.08] transition-colors"
            >
              <Bell className="h-4.5 w-4.5" />
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 flex h-4.5 min-w-4.5 items-center justify-center rounded-full bg-[#E74C3C] px-1 text-[10px] font-bold text-white">
                  {unreadCount}
                </span>
              )}
            </button>
            {showNotifs && (
              <div className="absolute right-0 top-11 z-50 w-80 rounded-xl border border-white/[0.08] bg-[#031A40] shadow-2xl">
                <div className="border-b border-white/[0.06] px-4 py-3">
                  <h3 className="text-sm font-semibold text-white">Notifications</h3>
                </div>
                <div className="max-h-64 overflow-y-auto">
                  {notifications.length === 0 ? (
                    <div className="px-4 py-6 text-center text-xs text-white/40">Aucune notification</div>
                  ) : (
                    notifications.map((n: any) => (
                      <div key={n.id} className="flex items-start gap-3 border-b border-white/[0.04] px-4 py-3 hover:bg-white/[0.04] cursor-pointer" onClick={() => markRead(n.id)}>
                        <div className={`mt-1 h-2 w-2 shrink-0 rounded-full ${
                          n.type?.includes("RED") ? "bg-[#E74C3C]" :
                          n.type?.includes("ORANGE") ? "bg-[#EF7A16]" :
                          n.type?.includes("YELLOW") ? "bg-[#FFD500]" : "bg-[#27AE60]"
                        }`} />
                        <div>
                          <p className="text-xs font-medium text-white/80">{n.titre}</p>
                          <p className="text-[11px] text-white/40 mt-0.5">{n.message}</p>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}
          </div>
          <div className="flex items-center gap-2 rounded-xl bg-white/[0.04] px-3 py-1.5 text-xs text-white/60">
            <div className="h-2 w-2 rounded-full bg-[#27AE60] pulse-dot" />
            Systeme actif
          </div>
        </div>
      </div>
    </header>
  );
}
