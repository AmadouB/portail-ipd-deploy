"use client";

import Link from "next/link";
import Image from "next/image";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";
import {
  LayoutDashboard,
  ShieldAlert,
  ClipboardList,
  Package,
  AlertTriangle,
  Camera,
  FileBarChart,
  ScrollText,
  ChevronLeft,
  Settings,
  CalendarCheck,
  Sun,
  Moon,
  Timer,
  Presentation,
  PenSquare,
  ShoppingCart,
  Factory,
  Microscope,
  ShieldCheck,
  BarChart3,
  Wrench,
  Wallet,
  ChevronDown,
} from "lucide-react";
import { useState } from "react";
import { useTheme } from "@/components/theme-provider";

type NavItem = { href: string; label: string; icon: any };
type NavGroup = { label: string; items: NavItem[] };

const navStructure: (NavItem | NavGroup)[] = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/saisie", label: "Saisie Activités", icon: PenSquare },
  { href: "/focus-semaine", label: "Focus Semaine", icon: CalendarCheck },
  {
    label: "Départements",
    items: [
      { href: "/production", label: "Production", icon: Factory },
      { href: "/lcq", label: "LCQ", icon: Microscope },
      { href: "/assurance-qualite", label: "Assurance Qualité", icon: ShieldCheck },
      { href: "/cqvm", label: "CQVM", icon: BarChart3 },
      { href: "/sms", label: "SMS", icon: Wrench },
      { href: "/finance", label: "Finance", icon: Wallet },
    ],
  },
  { href: "/ecarts", label: "Ecarts OMS", icon: ShieldAlert },
  { href: "/actions", label: "Actions AFM", icon: ClipboardList },
  { href: "/garap", label: "Achats GARAP", icon: Package },
  { href: "/produits", label: "Analyse Produits", icon: ShoppingCart },
  { href: "/persistance", label: "Persistance", icon: Timer },
  { href: "/risques", label: "Risques", icon: AlertTriangle },
  { href: "/snapshots", label: "Snapshots", icon: Camera },
  { href: "/rapports", label: "Rapports", icon: FileBarChart },
  { href: "/presentation", label: "Présentation", icon: Presentation },
  { href: "/audit", label: "Audit Trail", icon: ScrollText },
  { href: "/administration", label: "Administration", icon: Settings },
];

function isNavGroup(item: NavItem | NavGroup): item is NavGroup {
  return "items" in item;
}

export function AppSidebar() {
  const pathname = usePathname();
  const [collapsed, setCollapsed] = useState(false);
  const [deptOpen, setDeptOpen] = useState(true);
  const { theme, toggle } = useTheme();

  return (
    <aside
      className={cn(
        "fixed left-0 top-0 z-40 h-screen border-r transition-all duration-300 flex flex-col",
        "border-sidebar-border bg-sidebar",
        collapsed ? "w-[72px]" : "w-[240px]"
      )}
    >
      <div className={cn(
        "border-b border-sidebar-border px-3 transition-all duration-300",
        collapsed ? "py-3 flex items-center justify-center" : "py-4"
      )}>
        {collapsed ? (
          /* Collapsed: show just the globe icon part of the logo */
          <div className="flex h-10 w-10 shrink-0 items-center justify-center">
            <Image
              src={theme === "dark" ? "/logo-ipd-white.png" : "/logo-ipd-dark.png"}
              alt="IPD"
              width={40}
              height={17}
              className="object-contain"
              priority
            />
          </div>
        ) : (
          /* Expanded: full logo with IMS-NextGen subtitle */
          <div className="space-y-2">
            <Image
              src={theme === "dark" ? "/logo-ipd-white.png" : "/logo-ipd-dark.png"}
              alt="Institut Pasteur de Dakar"
              width={180}
              height={77}
              className="object-contain"
              priority
            />
            <div className="flex items-center gap-2 px-0.5">
              <div className="h-px flex-1 bg-sidebar-border" />
              <span className="text-[11px] font-bold text-primary uppercase tracking-[0.2em]" style={{ fontFamily: 'var(--font-heading)' }}>
                IMS NextGen
              </span>
              <div className="h-px flex-1 bg-sidebar-border" />
            </div>
          </div>
        )}
      </div>

      <nav className="flex-1 space-y-0.5 px-3 py-4 overflow-y-auto">
        {navStructure.map((entry, idx) => {
          if (isNavGroup(entry)) {
            const groupActive = entry.items.some(i => pathname.startsWith(i.href));
            return (
              <div key={entry.label}>
                {!collapsed && (
                  <button
                    onClick={() => setDeptOpen(!deptOpen)}
                    className="flex w-full items-center justify-between rounded-lg px-3 py-2 text-[11px] uppercase tracking-widest text-muted-foreground/70 hover:text-muted-foreground transition-colors font-semibold"
                  >
                    <span>{entry.label}</span>
                    <ChevronDown className={cn("h-3 w-3 transition-transform", !deptOpen && "-rotate-90")} />
                  </button>
                )}
                {(deptOpen || collapsed) && entry.items.map(item => {
                  const isActive = pathname.startsWith(item.href);
                  const Icon = item.icon;
                  return (
                    <Link key={item.href} href={item.href} className={cn(
                      "flex items-center gap-3 rounded-xl px-3 py-2 text-sm font-medium transition-all duration-200 group",
                      !collapsed && "pl-5",
                      isActive ? "bg-primary/10 text-primary" : "text-muted-foreground hover:bg-accent hover:text-foreground"
                    )}>
                      <Icon className={cn("h-4 w-4 shrink-0 transition-all", isActive ? "text-primary" : "text-muted-foreground group-hover:text-foreground")} />
                      {!collapsed && <span className="text-[14px]">{item.label}</span>}
                    </Link>
                  );
                })}
              </div>
            );
          }

          const isActive = pathname.startsWith(entry.href);
          const Icon = entry.icon;
          return (
            <Link key={entry.href} href={entry.href} className={cn(
              "flex items-center gap-3 rounded-xl px-3 py-2.5 text-[15px] font-medium transition-all duration-200 group",
              isActive ? "bg-primary/10 text-primary" : "text-muted-foreground hover:bg-accent hover:text-foreground"
            )}>
              <Icon className={cn("h-5 w-5 shrink-0 transition-all", isActive ? "text-primary" : "text-muted-foreground group-hover:text-foreground")} />
              {!collapsed && <span>{entry.label}</span>}
            </Link>
          );
        })}
      </nav>

      <div className="border-t border-sidebar-border p-3 space-y-2">
        <button
          onClick={toggle}
          className={cn(
            "flex w-full items-center gap-3 rounded-xl px-3 py-2 text-sm font-medium text-muted-foreground hover:bg-accent hover:text-foreground transition-all",
            collapsed && "justify-center px-0"
          )}
        >
          {theme === "dark" ? (
            <Sun className="h-4.5 w-4.5 shrink-0 text-[#FFD500]" />
          ) : (
            <Moon className="h-4.5 w-4.5 shrink-0 text-[#052A62]" />
          )}
          {!collapsed && (
            <span>{theme === "dark" ? "Mode clair" : "Mode sombre"}</span>
          )}
        </button>

        <button
          onClick={() => setCollapsed(!collapsed)}
          className="flex w-full items-center justify-center rounded-xl p-2 text-muted-foreground hover:bg-accent hover:text-foreground transition-colors"
        >
          <ChevronLeft className={cn("h-4 w-4 transition-transform duration-300", collapsed && "rotate-180")} />
        </button>
      </div>
    </aside>
  );
}
