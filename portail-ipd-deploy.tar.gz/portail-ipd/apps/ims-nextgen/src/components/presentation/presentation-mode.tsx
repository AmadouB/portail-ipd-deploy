"use client";

import { useEffect, useState, useCallback } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Maximize2, Minimize2, ChevronLeft, ChevronRight, Play, Pause } from "lucide-react";
import { CircularGauge } from "@/components/dashboard/circular-gauge";

interface KpiData {
  tauxCloture: number;
  totalEcarts: number;
  clotures: number;
  majeursRestants: number;
  actionsParStatut: { cloture: number; enCours: number; enRetard: number; aLancer: number };
  serviceBreakdown: { code: string; total: number; clotures: number; taux: number }[];
  macroEcarts: { numero: string; description: string; classification: string; nbEcartsEnfants: number; tauxCloture: number }[];
}

interface PersistenceData {
  stagnationSummary: { green: number; yellow: number; orange: number; red: number };
  avgResolutionWeeks: number;
  totalOpenActions: number;
  totalOpenEcarts: number;
}

export function PresentationMode() {
  const [kpi, setKpi] = useState<KpiData | null>(null);
  const [persistence, setPersistence] = useState<PersistenceData | null>(null);
  const [slideIndex, setSlideIndex] = useState(0);
  const [fullscreen, setFullscreen] = useState(false);
  const [autoPlay, setAutoPlay] = useState(false);

  useEffect(() => {
    fetch("/api/kpi").then(r => r.json()).then(setKpi);
    fetch("/api/persistence/status").then(r => r.json()).then(setPersistence);
  }, []);

  const totalSlides = 4;

  const next = useCallback(() => setSlideIndex(i => (i + 1) % totalSlides), []);
  const prev = useCallback(() => setSlideIndex(i => (i - 1 + totalSlides) % totalSlides), []);

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === "ArrowRight" || e.key === " ") next();
      if (e.key === "ArrowLeft") prev();
      if (e.key === "Escape") setFullscreen(false);
      if (e.key === "f") {
        if (!document.fullscreenElement) document.documentElement.requestFullscreen();
        else document.exitFullscreen();
        setFullscreen(!fullscreen);
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [next, prev, fullscreen]);

  useEffect(() => {
    if (!autoPlay) return;
    const interval = setInterval(next, 8000);
    return () => clearInterval(interval);
  }, [autoPlay, next]);

  if (!kpi) return <div className="flex items-center justify-center h-screen text-white/40 text-lg">Chargement...</div>;

  const slides = [
    // Slide 0: Title
    () => (
      <div className="flex flex-col items-center justify-center h-full bg-gradient-to-br from-[#031A40] to-[#052A62]">
        <img src="/logo-ipd-white.png" alt="Institut Pasteur de Dakar" className="h-20 object-contain mb-6" />
        <div className="flex items-center gap-3 mb-6">
          <div className="h-px w-16 bg-white/15" />
          <span className="text-sm font-bold text-[#0089D0] uppercase tracking-[0.3em]" style={{ fontFamily: 'var(--font-heading)' }}>IMS NextGen</span>
          <div className="h-px w-16 bg-white/15" />
        </div>
        <p className="text-2xl text-white/70 mb-2">Rapport de Progression</p>
        <p className="text-white/30 mt-6">{new Date().toLocaleDateString("fr-FR", { weekday: "long", year: "numeric", month: "long", day: "numeric" })}</p>
      </div>
    ),

    // Slide 1: KPIs
    () => (
      <div className="h-full p-12 bg-[#052A62]">
        <h2 className="text-3xl font-bold text-white mb-8" style={{ fontFamily: 'var(--font-heading)' }}>Indicateurs Clés</h2>
        <div className="grid grid-cols-4 gap-8 mb-12">
          {[
            { label: "Taux Clôture", value: `${kpi.tauxCloture}%`, color: kpi.tauxCloture >= 80 ? "#27AE60" : "#EF7A16" },
            { label: "Écarts Totaux", value: `${kpi.totalEcarts}`, color: "#0089D0" },
            { label: "Clôturés", value: `${kpi.clotures}`, color: "#27AE60" },
            { label: "Majeurs Restants", value: `${kpi.majeursRestants}`, color: "#E74C3C" },
          ].map(k => (
            <div key={k.label} className="rounded-2xl p-6 text-center" style={{ backgroundColor: k.color }}>
              <p className="text-4xl font-bold text-white">{k.value}</p>
              <p className="text-sm text-white/80 mt-2">{k.label}</p>
            </div>
          ))}
        </div>
        <h3 className="text-xl text-white/60 mb-4">Taux par Service</h3>
        <div className="flex gap-6 justify-center">
          {kpi.serviceBreakdown.map(s => (
            <CircularGauge key={s.code} value={s.taux} label={s.code} size={100} />
          ))}
        </div>
      </div>
    ),

    // Slide 2: Actions
    () => (
      <div className="h-full p-12 bg-[#052A62]">
        <h2 className="text-3xl font-bold text-white mb-8" style={{ fontFamily: 'var(--font-heading)' }}>Actions AFM</h2>
        <div className="grid grid-cols-4 gap-6 mb-8">
          {[
            { label: "En cours", value: kpi.actionsParStatut.enCours, color: "#0089D0" },
            { label: "En retard", value: kpi.actionsParStatut.enRetard, color: "#E74C3C" },
            { label: "Clôturées", value: kpi.actionsParStatut.cloture, color: "#27AE60" },
            { label: "À lancer", value: kpi.actionsParStatut.aLancer, color: "#FFD500" },
          ].map(a => (
            <div key={a.label} className="rounded-2xl border-2 p-6 text-center" style={{ borderColor: a.color }}>
              <p className="text-4xl font-bold text-white">{a.value}</p>
              <p className="text-sm mt-2" style={{ color: a.color }}>{a.label}</p>
            </div>
          ))}
        </div>
      </div>
    ),

    // Slide 3: Stagnation
    () => {
      const s = persistence?.stagnationSummary || { green: 0, yellow: 0, orange: 0, red: 0 };
      return (
        <div className="h-full p-12 bg-[#052A62]">
          <h2 className="text-3xl font-bold text-white mb-8" style={{ fontFamily: 'var(--font-heading)' }}>Moteur de Persistance</h2>
          <div className="grid grid-cols-4 gap-8">
            {[
              { label: "1-2 semaines", count: s.green, color: "#27AE60", sublabel: "Normal" },
              { label: "3-4 semaines", count: s.yellow, color: "#FFD500", sublabel: "Attention" },
              { label: "5-7 semaines", count: s.orange, color: "#EF7A16", sublabel: "Escalade" },
              { label: "8+ semaines", count: s.red, color: "#E74C3C", sublabel: "Critique" },
            ].map(item => (
              <div key={item.label} className="rounded-2xl p-8 text-center" style={{ backgroundColor: item.color }}>
                <p className="text-5xl font-bold text-white">{item.count}</p>
                <p className="text-lg text-white/90 mt-2">{item.label}</p>
                <p className="text-sm text-white/60">{item.sublabel}</p>
              </div>
            ))}
          </div>
          {persistence && (
            <div className="mt-8 flex justify-center gap-12 text-white/60 text-lg">
              <span>Durée moy. résolution : <strong className="text-white">{persistence.avgResolutionWeeks} sem</strong></span>
              <span>Actions ouvertes : <strong className="text-white">{persistence.totalOpenActions}</strong></span>
              <span>Écarts ouverts : <strong className="text-white">{persistence.totalOpenEcarts}</strong></span>
            </div>
          )}
        </div>
      );
    },
  ];

  const CurrentSlide = slides[slideIndex];

  return (
    <div className="h-screen w-full relative overflow-hidden bg-[#031A40]">
      <div className="h-full">
        <CurrentSlide />
      </div>

      {/* Controls overlay */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex items-center gap-3 rounded-full bg-black/40 backdrop-blur-lg px-4 py-2">
        <button onClick={prev} className="p-1 text-white/60 hover:text-white"><ChevronLeft className="h-5 w-5" /></button>

        <div className="flex gap-1.5">
          {slides.map((_, i) => (
            <button key={i} onClick={() => setSlideIndex(i)} className={`h-2 rounded-full transition-all ${i === slideIndex ? "w-6 bg-[#0089D0]" : "w-2 bg-white/20"}`} />
          ))}
        </div>

        <button onClick={next} className="p-1 text-white/60 hover:text-white"><ChevronRight className="h-5 w-5" /></button>

        <div className="w-px h-5 bg-white/10 mx-1" />

        <button onClick={() => setAutoPlay(!autoPlay)} className="p-1 text-white/60 hover:text-white">
          {autoPlay ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
        </button>

        <button
          onClick={() => {
            if (!document.fullscreenElement) document.documentElement.requestFullscreen();
            else document.exitFullscreen();
            setFullscreen(!fullscreen);
          }}
          className="p-1 text-white/60 hover:text-white"
        >
          {fullscreen ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
        </button>

        <span className="text-xs text-white/30 ml-2">{slideIndex + 1}/{totalSlides}</span>
      </div>
    </div>
  );
}
