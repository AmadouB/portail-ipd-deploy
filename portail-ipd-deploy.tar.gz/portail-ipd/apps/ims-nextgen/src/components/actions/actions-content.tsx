"use client";

import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Pencil, Search, X, Info, ShieldAlert, AlertTriangle } from "lucide-react";
import { cn } from "@/lib/utils";

/* ------------------------------------------------------------------ */
/*  RIV Matrix Component (from RIV sheet)                              */
/* ------------------------------------------------------------------ */
const RIV_MATRIX: { impact: string; prob: string; cells: string[][] } = {
  impact: "Impact",
  prob: "Probability",
  cells: [
    // [probability 1..5] for impact 5 (Severe) down to 1 (Insignificant)
    ["Medium", "High", "Very High", "Very High", "Very High"],    // 5 Severe
    ["Medium", "Medium", "High", "Very High", "Very High"],       // 4 Major
    ["Low", "Medium", "Medium", "High", "Very High"],             // 3 Moderate
    ["Low", "Low", "Medium", "Medium", "High"],                   // 2 Minor
    ["Low", "Low", "Low", "Medium", "Medium"],                    // 1 Insignificant
  ],
};

const rivCellColors: Record<string, string> = {
  Low: "bg-[#27AE60]/20 text-emerald-300 border-emerald-500/30",
  Medium: "bg-[#EF7A16]/20 text-amber-300 border-amber-500/30",
  High: "bg-orange-500/20 text-orange-300 border-orange-500/30",
  "Very High": "bg-red-500/20 text-red-300 border-red-500/30",
};

const impactLabels = ["5 - Severe", "4 - Major", "3 - Moderate", "2 - Minor", "1 - Insignificant"];
const probLabels = ["1 - Very Low", "2 - Low", "3 - Medium", "4 - High", "5 - Almost Certain"];
const probPercent = ["< 5%", "5-25%", "26-75%", "76-95%", "> 95%"];

function RIVMatrixPanel({ actions }: { actions: Action[] }) {
  // Count actions in each cell
  const getActionsForCell = (impIdx: number, probIdx: number) => {
    const impactVal = 5 - impIdx;
    const probVal = probIdx + 1;
    const score = impactVal * probVal;
    return actions.filter((a) => a.statut !== "CLOTURE" && a.scoreRisque === score);
  };

  return (
    <div className="space-y-6">
      <Card className="glass border-white/[0.08]">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm text-white/70 flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-[#0089D0]" />
            Matrice RIV — Risk Impact Value
          </CardTitle>
          <p className="text-xs text-white/30">Score = Impact x Probabilite (1-25)</p>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr>
                  <th className="p-2 text-[10px] text-white/30 w-28" rowSpan={2}>IMPACT ↓ / PROB →</th>
                  {probLabels.map((p, i) => (
                    <th key={i} className="p-2 text-[10px] text-white/50 text-center border border-white/[0.06]">{p}</th>
                  ))}
                </tr>
                <tr>
                  {probPercent.map((p, i) => (
                    <th key={i} className="p-1 text-[9px] text-white/25 text-center border border-white/[0.06] font-normal">{p}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {impactLabels.map((imp, impIdx) => (
                  <tr key={impIdx}>
                    <td className="p-2 text-[11px] text-white/60 border border-white/[0.06] font-medium">{imp}</td>
                    {[0, 1, 2, 3, 4].map((probIdx) => {
                      const level = RIV_MATRIX.cells[impIdx][probIdx];
                      const score = (5 - impIdx) * (probIdx + 1);
                      const cellActions = getActionsForCell(impIdx, probIdx);
                      return (
                        <td key={probIdx} className={cn("p-2 text-center border border-white/[0.06] relative group", rivCellColors[level])}>
                          <span className="text-xs font-bold">{score}</span>
                          <br />
                          <span className="text-[9px] opacity-70">{level}</span>
                          {cellActions.length > 0 && (
                            <div className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-[#0089D0] text-[9px] font-bold text-white flex items-center justify-center shadow-md">
                              {cellActions.length}
                            </div>
                          )}
                          {cellActions.length > 0 && (
                            <div className="hidden group-hover:block absolute z-20 top-full left-1/2 -translate-x-1/2 mt-1 w-56 rounded-lg bg-[#031A40] border border-white/[0.10] shadow-xl p-2 text-left">
                              {cellActions.slice(0, 5).map((a) => (
                                <div key={a.id} className="text-[10px] text-white/60 py-0.5 border-b border-white/[0.04] last:border-0">
                                  <span className="text-[#0089D0] font-mono">#{a.chronoLegacy}</span> {a.description.slice(0, 40)}...
                                </div>
                              ))}
                              {cellActions.length > 5 && <p className="text-[9px] text-white/30 pt-1">+{cellActions.length - 5} autres</p>}
                            </div>
                          )}
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Legend */}
          <div className="flex items-center gap-4 mt-4 pt-3 border-t border-white/[0.06]">
            <span className="text-[10px] text-white/30 uppercase tracking-wider">Niveaux:</span>
            {["Low", "Medium", "High", "Very High"].map((l) => (
              <Badge key={l} variant="outline" className={cn("text-[10px]", rivCellColors[l])}>{l}</Badge>
            ))}
          </div>

          {/* Mitigation guidance */}
          <div className="grid grid-cols-4 gap-3 mt-4">
            {[
              { level: "Low", range: "1-3", action: "Plan de mitigation non requis", color: "border-emerald-500/20 bg-[#27AE60]/5" },
              { level: "Medium", range: "4-9", action: "Plan de mitigation recommande", color: "border-amber-500/20 bg-[#EF7A16]/5" },
              { level: "High", range: "10-12", action: "Plan obligatoire — revue bi-hebdomadaire", color: "border-orange-500/20 bg-orange-500/5" },
              { level: "Very High", range: "15-25", action: "Plan obligatoire — revue hebdomadaire", color: "border-red-500/20 bg-red-500/5" },
            ].map((m) => {
              const count = actions.filter((a) => a.statut !== "CLOTURE" && a.niveauCriticite === m.level).length;
              return (
                <div key={m.level} className={cn("rounded-xl border p-3", m.color)}>
                  <div className="flex items-center justify-between">
                    <Badge variant="outline" className={cn("text-[10px]", critColors[m.level])}>{m.level}</Badge>
                    <span className="text-lg font-bold text-white">{count}</span>
                  </div>
                  <p className="text-[9px] text-white/30 mt-1">Score [{m.range}]</p>
                  <p className="text-[10px] text-white/50 mt-1">{m.action}</p>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Guidance Rating Panel (from Guidance sheet)                        */
/* ------------------------------------------------------------------ */
const impactDimensions = [
  {
    name: "Deadlines (Planning)",
    levels: ["< 1 semaine", "1 a 2 semaines", "2 a 4 semaines", "4 semaines a 2 mois", "> 2 mois"],
  },
  {
    name: "Product Quality",
    levels: [
      "Produit sous controle, pas d'effet patient",
      "Liberation possible, plaintes elevees, rappel unique",
      "Effet mineur patient, rappel multi-marche",
      "Effet modere patient, rappel global",
      "Effet severe patient, sante et securite",
    ],
  },
  {
    name: "Safety",
    levels: [
      "Blessures mineures, premiers soins",
      "Traitement medical sans arret",
      "Arret de travail ou restriction",
      "Deficience permanente ou prolongee",
      "Deces, intervention reglementaire",
    ],
  },
  {
    name: "People (RH)",
    levels: [
      "5-10% employes, turnover 1-6%",
      "11-25% employes, turnover 6-9%",
      "26-50% employes, turnover 10-15%",
      "51-75% employes, turnover 16-24%",
      "> 75% employes, turnover > 25%",
    ],
  },
  {
    name: "Regulatory & QMS",
    levels: [
      "Observations mineures, clarifications",
      "Observations majeures court terme, notification",
      "Changements programmatiques, visite ciblee",
      "Investigation longue, warning letter probable",
      "Retrait produit, fermeture forcee du site",
    ],
  },
  {
    name: "Financial",
    levels: ["< 7 K EUR", "7 - 20 K EUR", "20 - 40 K EUR", "40 - 60 K EUR", "> 60 K EUR"],
  },
];

const impactHeaders = ["Insignificant (1)", "Minor (2)", "Moderate (3)", "Major (4)", "Severe (5)"];
const impactHeaderColors = [
  "text-[#27AE60] bg-[#27AE60]/10",
  "text-blue-400 bg-blue-500/10",
  "text-[#EF7A16] bg-[#EF7A16]/10",
  "text-orange-400 bg-orange-500/10",
  "text-red-400 bg-red-500/10",
];

function GuidancePanel() {
  return (
    <div className="space-y-6">
      {/* Probability scale */}
      <Card className="glass border-white/[0.08]">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm text-white/70 flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-[#EF7A16]" />
            Echelle de Probabilite (Probability)
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-5 gap-2">
            {[
              { lvl: "Very Low (1)", pct: "< 5%", color: "border-emerald-500/20 bg-[#27AE60]/5" },
              { lvl: "Low (2)", pct: "5 - 25%", color: "border-blue-500/20 bg-blue-500/5" },
              { lvl: "Medium (3)", pct: "26 - 75%", color: "border-amber-500/20 bg-[#EF7A16]/5" },
              { lvl: "High (4)", pct: "76 - 95%", color: "border-orange-500/20 bg-orange-500/5" },
              { lvl: "Almost Certain (5)", pct: "> 95%", color: "border-red-500/20 bg-red-500/5" },
            ].map((p) => (
              <div key={p.lvl} className={cn("rounded-xl border p-3 text-center", p.color)}>
                <p className="text-xs font-semibold text-white/80">{p.lvl}</p>
                <p className="text-lg font-bold text-white mt-1">{p.pct}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Impact dimensions table */}
      <Card className="glass border-white/[0.08]">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm text-white/70 flex items-center gap-2">
            <Info className="w-4 h-4 text-[#0089D0]" />
            Echelle d'Impact (Severity) par Dimension
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full border-collapse text-[11px]">
              <thead>
                <tr>
                  <th className="p-2 text-left text-white/30 text-[10px] uppercase tracking-wider border border-white/[0.06] w-32">Dimension</th>
                  {impactHeaders.map((h, i) => (
                    <th key={i} className={cn("p-2 text-center text-[10px] font-semibold border border-white/[0.06]", impactHeaderColors[i])}>
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {impactDimensions.map((dim) => (
                  <tr key={dim.name}>
                    <td className="p-2 font-medium text-white/70 border border-white/[0.06] bg-white/[0.02]">{dim.name}</td>
                    {dim.levels.map((lvl, i) => (
                      <td key={i} className={cn("p-2 text-white/50 border border-white/[0.06]", i >= 3 ? "bg-red-500/[0.03]" : i >= 2 ? "bg-[#EF7A16]/[0.03]" : "")}>
                        {lvl}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Criticality & Mitigation */}
      <Card className="glass border-white/[0.08]">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm text-white/70">Criticite & Plans de Mitigation</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
            {[
              { level: "Low", range: "[1-3]", mitigation: "Plan de mitigation non requis", color: "border-emerald-500/20 bg-[#27AE60]/5", icon: "✓" },
              { level: "Medium", range: "[4-9]", mitigation: "Plan de mitigation recommande", color: "border-amber-500/20 bg-[#EF7A16]/5", icon: "⚡" },
              { level: "High", range: "[10-12]", mitigation: "Plan de mitigation obligatoire — Revue bi-hebdomadaire", color: "border-orange-500/20 bg-orange-500/5", icon: "⚠" },
              { level: "Very High", range: "[15-25]", mitigation: "Plan de mitigation obligatoire — Revue hebdomadaire", color: "border-red-500/20 bg-red-500/5", icon: "🔴" },
            ].map((m) => (
              <div key={m.level} className={cn("rounded-xl border p-4 space-y-2", m.color)}>
                <div className="flex items-center gap-2">
                  <span className="text-lg">{m.icon}</span>
                  <Badge variant="outline" className={cn("text-xs", critColors[m.level])}>{m.level}</Badge>
                </div>
                <p className="text-[10px] text-white/30 font-mono">Score {m.range}</p>
                <p className="text-xs text-white/60">{m.mitigation}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

interface Action {
  id: number; chronoLegacy: number | null; description: string; statut: string;
  deadlineInitiale: string; deadlineRevisee: string | null; avancement: number;
  scoreRisque: number; niveauCriticite: string; commentaires: string | null;
  estImportant: boolean; estUrgent: boolean;
  workstream: { code: string; libelle: string };
  responsables: { user: { name: string } }[];
}

const statutColors: Record<string, string> = {
  CLOTURE: "bg-[#27AE60]/10 text-[#27AE60] border-emerald-500/20",
  EN_COURS: "bg-[#EF7A16]/10 text-[#EF7A16] border-amber-500/20",
  EN_RETARD: "bg-red-500/10 text-red-400 border-red-500/20",
  A_LANCER: "bg-blue-500/10 text-blue-400 border-blue-500/20",
};

const critColors: Record<string, string> = {
  Low: "bg-[#27AE60]/10 text-[#27AE60] border-emerald-500/20",
  Medium: "bg-[#EF7A16]/10 text-[#EF7A16] border-amber-500/20",
  High: "bg-orange-500/10 text-orange-400 border-orange-500/20",
  "Very High": "bg-red-500/10 text-red-400 border-red-500/20",
};

const selectClass = "rounded-lg bg-white/[0.04] border border-white/[0.08] px-3 py-1.5 text-sm text-white/70 focus:outline-none focus:ring-1 focus:ring-cyan-500/50";
const inputClass = "bg-white/[0.04] border-white/[0.08] text-white placeholder:text-white/30 focus:ring-cyan-500/50 focus:border-[#0089D0]/50";

function EditActionModal({ action, open, onClose, onSave }: { action: Action; open: boolean; onClose: () => void; onSave: () => void }) {
  const [form, setForm] = useState({
    statut: action.statut,
    avancement: action.avancement,
    estImportant: action.estImportant,
    estUrgent: action.estUrgent,
    deadlineRevisee: action.deadlineRevisee || "",
    description: action.description,
    commentaires: action.commentaires || "",
    scoreRisque: action.scoreRisque,
    niveauCriticite: action.niveauCriticite,
  });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    setForm({
      statut: action.statut, avancement: action.avancement, estImportant: action.estImportant,
      estUrgent: action.estUrgent, deadlineRevisee: action.deadlineRevisee || "",
      description: action.description, commentaires: action.commentaires || "",
      scoreRisque: action.scoreRisque, niveauCriticite: action.niveauCriticite,
    });
  }, [action]);

  const computeCriticite = (score: number) => {
    if (score >= 15) return "Very High";
    if (score >= 10) return "High";
    if (score >= 4) return "Medium";
    return "Low";
  };

  const handleScoreChange = (score: number) => {
    setForm({ ...form, scoreRisque: score, niveauCriticite: computeCriticite(score) });
  };

  const handleSave = async () => {
    setSaving(true);
    await fetch(`/api/actions-afm/${action.id}`, {
      method: "PUT", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        ...form,
        deadlineRevisee: form.deadlineRevisee || null,
        commentaires: form.commentaires || null,
      }),
    });
    setSaving(false);
    onSave();
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-[#031A40] border-white/[0.08] text-white max-w-2xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-[#0089D0]">Action #{action.chronoLegacy} - {action.workstream.code}</DialogTitle>
        </DialogHeader>
        <div className="grid gap-4 py-2">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-white/60 text-xs">Statut</Label>
              <select value={form.statut} onChange={(e) => setForm({ ...form, statut: e.target.value })} className={cn("w-full mt-1", selectClass)}>
                <option value="A_LANCER">A lancer</option>
                <option value="EN_COURS">En cours</option>
                <option value="EN_RETARD">En retard</option>
                <option value="CLOTURE">Cloture</option>
              </select>
            </div>
            <div>
              <Label className="text-white/60 text-xs">Avancement: {Math.round(form.avancement * 100)}%</Label>
              <Input type="range" min="0" max="1" step="0.05" value={form.avancement} onChange={(e) => setForm({ ...form, avancement: parseFloat(e.target.value) })} className="mt-1 accent-cyan-500" />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="flex items-center gap-3">
              <Switch checked={form.estImportant} onCheckedChange={(v) => setForm({ ...form, estImportant: v })} />
              <Label className="text-white/60 text-xs">Important</Label>
            </div>
            <div className="flex items-center gap-3">
              <Switch checked={form.estUrgent} onCheckedChange={(v) => setForm({ ...form, estUrgent: v })} />
              <Label className="text-white/60 text-xs">Urgent</Label>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-white/60 text-xs">Score Risque (1-25)</Label>
              <Input type="number" min="1" max="25" value={form.scoreRisque} onChange={(e) => handleScoreChange(parseInt(e.target.value) || 1)} className={cn("mt-1", inputClass)} />
              <Badge variant="outline" className={cn("mt-1 text-[10px]", critColors[form.niveauCriticite])}>{form.niveauCriticite}</Badge>
            </div>
            <div>
              <Label className="text-white/60 text-xs">Deadline revisee</Label>
              <Input type="date" value={form.deadlineRevisee} onChange={(e) => setForm({ ...form, deadlineRevisee: e.target.value })} className={cn("mt-1", inputClass)} />
            </div>
          </div>

          <div>
            <Label className="text-white/60 text-xs">Description</Label>
            <Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} rows={3} className={cn("mt-1", inputClass)} />
          </div>
          <div>
            <Label className="text-white/60 text-xs">Commentaires</Label>
            <Textarea value={form.commentaires} onChange={(e) => setForm({ ...form, commentaires: e.target.value })} rows={2} className={cn("mt-1", inputClass)} />
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <Button variant="outline" onClick={onClose} className="border-white/10 text-white/60 hover:bg-white/5">Annuler</Button>
            <Button onClick={handleSave} disabled={saving} className="bg-cyan-600 hover:bg-cyan-700 text-white">
              {saving ? "Enregistrement..." : "Enregistrer"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function EisenhowerMatrix({ actions, onEdit }: { actions: Action[]; onEdit: (a: Action) => void }) {
  const quadrants = [
    { label: "Urgent & Important", filter: (a: Action) => a.estUrgent && a.estImportant, color: "border-red-500/30", bg: "bg-red-500/5" },
    { label: "Important", filter: (a: Action) => !a.estUrgent && a.estImportant, color: "border-amber-500/30", bg: "bg-[#EF7A16]/5" },
    { label: "Urgent", filter: (a: Action) => a.estUrgent && !a.estImportant, color: "border-blue-500/30", bg: "bg-blue-500/5" },
    { label: "Ni urgent ni important", filter: (a: Action) => !a.estUrgent && !a.estImportant, color: "border-white/10", bg: "bg-white/[0.02]" },
  ];

  return (
    <div className="grid grid-cols-2 gap-3">
      {quadrants.map((q) => {
        const items = actions.filter(q.filter).filter((a) => a.statut !== "CLOTURE");
        return (
          <Card key={q.label} className={cn("border", q.color, q.bg)}>
            <CardHeader className="pb-2">
              <CardTitle className="text-xs text-white/60">{q.label} <span className="text-white/30">({items.length})</span></CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="space-y-1.5">
                {items.length === 0 && <p className="text-[10px] text-white/20">Aucune action</p>}
                {items.map((a) => (
                  <div key={a.id} className="flex items-center gap-2 text-[11px] group">
                    <span className="text-white/30 font-mono w-5">#{a.chronoLegacy}</span>
                    <span className="text-white/60 truncate flex-1">{a.description.substring(0, 50)}...</span>
                    <Badge variant="outline" className={cn("text-[9px]", critColors[a.niveauCriticite])}>{a.scoreRisque}</Badge>
                    <button onClick={() => onEdit(a)} className="opacity-0 group-hover:opacity-100 p-0.5 rounded hover:bg-white/[0.06] text-white/30 hover:text-[#0089D0] transition-all">
                      <Pencil className="h-3 w-3" />
                    </button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}

export function ActionsContent() {
  const [data, setData] = useState<{ actions: Action[]; workstreams: any[] } | null>(null);
  const [filter, setFilter] = useState({ ws: "", statut: "", criticite: "", importance: "", search: "", deadline: "" });
  const [editAction, setEditAction] = useState<Action | null>(null);

  const reload = () => fetch("/api/actions-afm").then((r) => r.json()).then(setData);
  useEffect(() => { reload(); }, []);

  if (!data) return <div className="flex items-center justify-center h-64 text-white/40">Chargement...</div>;

  const filtered = data.actions.filter((a) => {
    if (filter.ws && a.workstream.code !== filter.ws) return false;
    if (filter.statut && a.statut !== filter.statut) return false;
    if (filter.criticite && a.niveauCriticite !== filter.criticite) return false;
    if (filter.importance === "important" && !a.estImportant) return false;
    if (filter.importance === "urgent" && !a.estUrgent) return false;
    if (filter.importance === "both" && (!a.estImportant || !a.estUrgent)) return false;
    if (filter.search && !a.description.toLowerCase().includes(filter.search.toLowerCase()) && !String(a.chronoLegacy).includes(filter.search) && !(a.commentaires || "").toLowerCase().includes(filter.search.toLowerCase())) return false;
    if (filter.deadline === "depasse") {
      const dl = a.deadlineRevisee || a.deadlineInitiale;
      if (!dl || new Date(dl) >= new Date() || a.statut === "CLOTURE") return false;
    }
    if (filter.deadline === "7j") {
      const dl = a.deadlineRevisee || a.deadlineInitiale;
      const in7 = new Date(); in7.setDate(in7.getDate() + 7);
      if (!dl || new Date(dl) > in7 || new Date(dl) < new Date() || a.statut === "CLOTURE") return false;
    }
    return true;
  });

  const hasActiveFilters = Object.values(filter).some(Boolean);

  return (
    <div className="space-y-6">
      {/* KPI Summary Cards */}
      {(() => {
        const total = data.actions.length;
        const clotures = data.actions.filter((a) => a.statut === "CLOTURE").length;
        const enCours = data.actions.filter((a) => a.statut === "EN_COURS").length;
        const enRetard = data.actions.filter((a) => a.statut === "EN_RETARD").length;
        const aLancer = data.actions.filter((a) => a.statut === "A_LANCER").length;
        const veryHigh = data.actions.filter((a) => a.niveauCriticite === "Very High" && a.statut !== "CLOTURE").length;
        const avgAvanc = data.actions.filter((a) => a.statut !== "CLOTURE").length > 0
          ? Math.round(data.actions.filter((a) => a.statut !== "CLOTURE").reduce((s, a) => s + a.avancement, 0) / data.actions.filter((a) => a.statut !== "CLOTURE").length * 100)
          : 0;
        return (
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3 mb-4">
            <div className="rounded-xl glass border-white/[0.08] p-3 text-center">
              <p className="text-2xl font-bold text-white">{total}</p>
              <p className="text-[9px] text-white/30 uppercase">Total</p>
            </div>
            <div className="rounded-xl glass border-white/[0.08] p-3 text-center glow-emerald">
              <p className="text-2xl font-bold text-[#27AE60]">{clotures}</p>
              <p className="text-[9px] text-white/30 uppercase">Clotures</p>
            </div>
            <div className="rounded-xl glass border-white/[0.08] p-3 text-center glow-amber">
              <p className="text-2xl font-bold text-[#EF7A16]">{enCours}</p>
              <p className="text-[9px] text-white/30 uppercase">En cours</p>
            </div>
            <div className="rounded-xl glass border-white/[0.08] p-3 text-center glow-red">
              <p className="text-2xl font-bold text-red-400">{enRetard}</p>
              <p className="text-[9px] text-white/30 uppercase">En retard</p>
            </div>
            <div className="rounded-xl glass border-white/[0.08] p-3 text-center glow-cyan">
              <p className="text-2xl font-bold text-blue-400">{aLancer}</p>
              <p className="text-[9px] text-white/30 uppercase">A lancer</p>
            </div>
            <div className="rounded-xl glass border-white/[0.08] p-3 text-center glow-red">
              <p className="text-2xl font-bold text-red-400">{veryHigh}</p>
              <p className="text-[9px] text-white/30 uppercase">Very High</p>
            </div>
            <div className="rounded-xl glass border-white/[0.08] p-3 text-center glow-cyan">
              <p className="text-2xl font-bold text-[#0089D0]">{avgAvanc}%</p>
              <p className="text-[9px] text-white/30 uppercase">Avanc. moy.</p>
            </div>
          </div>
        );
      })()}

      <Tabs defaultValue="table">
        <TabsList className="bg-white/[0.04] border border-white/[0.06]">
          <TabsTrigger value="table" className="data-[state=active]:bg-[#0089D0]/10 data-[state=active]:text-[#0089D0]">Table</TabsTrigger>
          <TabsTrigger value="eisenhower" className="data-[state=active]:bg-[#0089D0]/10 data-[state=active]:text-[#0089D0]">Matrice Eisenhower</TabsTrigger>
          <TabsTrigger value="riv" className="data-[state=active]:bg-[#0089D0]/10 data-[state=active]:text-[#0089D0]">Matrice RIV</TabsTrigger>
          <TabsTrigger value="guidance" className="data-[state=active]:bg-[#0089D0]/10 data-[state=active]:text-[#0089D0]">Guidance Rating</TabsTrigger>
        </TabsList>

        <div className="flex gap-3 flex-wrap mt-4 items-center">
          <div className="relative">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-white/30" />
            <input value={filter.search} onChange={(e) => setFilter({ ...filter, search: e.target.value })} placeholder="Rechercher..." className={cn("pl-8 w-52", selectClass)} />
          </div>
          <select value={filter.ws} onChange={(e) => setFilter({ ...filter, ws: e.target.value })} className={selectClass}>
            <option value="">Tous les workstreams</option>
            {data.workstreams.map((ws) => <option key={ws.code} value={ws.code}>{ws.libelle}</option>)}
          </select>
          <select value={filter.statut} onChange={(e) => setFilter({ ...filter, statut: e.target.value })} className={selectClass}>
            <option value="">Tous les statuts</option>
            <option value="A_LANCER">A lancer</option>
            <option value="EN_COURS">En cours</option>
            <option value="EN_RETARD">En retard</option>
            <option value="CLOTURE">Cloture</option>
          </select>
          <select value={filter.criticite} onChange={(e) => setFilter({ ...filter, criticite: e.target.value })} className={selectClass}>
            <option value="">Toutes criticites</option>
            <option value="Low">Low</option>
            <option value="Medium">Medium</option>
            <option value="High">High</option>
            <option value="Very High">Very High</option>
          </select>
          <select value={filter.importance} onChange={(e) => setFilter({ ...filter, importance: e.target.value })} className={selectClass}>
            <option value="">Importance/Urgence</option>
            <option value="important">Important</option>
            <option value="urgent">Urgent</option>
            <option value="both">Important & Urgent</option>
          </select>
          <select value={filter.deadline} onChange={(e) => setFilter({ ...filter, deadline: e.target.value })} className={selectClass}>
            <option value="">Toutes deadlines</option>
            <option value="depasse">Deadline depassee</option>
            <option value="7j">Dans les 7 prochains jours</option>
          </select>
          {hasActiveFilters && (
            <button onClick={() => setFilter({ ws: "", statut: "", criticite: "", importance: "", search: "", deadline: "" })} className="flex items-center gap-1 text-xs text-red-400 hover:text-red-300">
              <X className="h-3 w-3" /> Reinitialiser
            </button>
          )}
        </div>

        <p className="text-xs text-white/30 mt-2">{filtered.length} action(s) affichee(s)</p>

        <TabsContent value="table" className="mt-2">
          <Card className="glass border-white/[0.08] overflow-hidden">
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="text-[10px] text-white/30 uppercase tracking-wider border-b border-white/[0.06]">
                      <th className="text-left py-3 px-3">#</th>
                      <th className="text-left py-3 px-3">WS</th>
                      <th className="text-left py-3 px-3">Description</th>
                      <th className="text-left py-3 px-3">Responsable(s)</th>
                      <th className="text-left py-3 px-3">Deadline</th>
                      <th className="text-left py-3 px-3">Statut</th>
                      <th className="text-left py-3 px-3">Risque</th>
                      <th className="text-left py-3 px-3">Avancement</th>
                      <th className="text-left py-3 px-3">Flags</th>
                      <th className="text-right py-3 px-3">Edit</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filtered.map((a) => (
                      <tr key={a.id} className="border-t border-white/[0.03] hover:bg-white/[0.02] transition-colors">
                        <td className="py-2.5 px-3 text-xs font-mono text-[#0089D0]">{a.chronoLegacy}</td>
                        <td className="py-2.5 px-3"><Badge variant="outline" className="text-[10px] border-white/10 text-white/50">{a.workstream.code}</Badge></td>
                        <td className="py-2.5 px-3 text-xs text-white/70 max-w-[250px] truncate">{a.description}</td>
                        <td className="py-2.5 px-3 text-xs text-white/50">{a.responsables.map((r) => r.user.name).join(", ") || "-"}</td>
                        <td className="py-2.5 px-3 text-xs text-white/40 font-mono">{a.deadlineRevisee || a.deadlineInitiale}</td>
                        <td className="py-2.5 px-3"><Badge variant="outline" className={cn("text-[10px]", statutColors[a.statut])}>{a.statut.replace("_", " ")}</Badge></td>
                        <td className="py-2.5 px-3">
                          <Badge variant="outline" className={cn("text-[10px]", critColors[a.niveauCriticite])}>
                            {a.scoreRisque} - {a.niveauCriticite}
                          </Badge>
                        </td>
                        <td className="py-2.5 px-3">
                          <div className="flex items-center gap-2">
                            <div className="w-14 h-1.5 rounded-full bg-white/[0.06]">
                              <div className="h-full rounded-full bg-[#0089D0]/60" style={{ width: `${a.avancement * 100}%` }} />
                            </div>
                            <span className="text-[10px] text-white/40">{Math.round(a.avancement * 100)}%</span>
                          </div>
                        </td>
                        <td className="py-2.5 px-3">
                          <div className="flex gap-1">
                            {a.estImportant && <span className="text-[9px] px-1 py-0.5 rounded bg-red-500/10 text-red-400">IMP</span>}
                            {a.estUrgent && <span className="text-[9px] px-1 py-0.5 rounded bg-[#EF7A16]/10 text-[#EF7A16]">URG</span>}
                          </div>
                        </td>
                        <td className="py-2.5 px-3 text-right">
                          <button onClick={() => setEditAction(a)} className="p-1 rounded hover:bg-white/[0.06] text-white/30 hover:text-[#0089D0] transition-colors">
                            <Pencil className="h-3.5 w-3.5" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="eisenhower" className="mt-2">
          <EisenhowerMatrix actions={filtered} onEdit={setEditAction} />
        </TabsContent>

        <TabsContent value="riv" className="mt-2">
          <RIVMatrixPanel actions={data.actions} />
        </TabsContent>

        <TabsContent value="guidance" className="mt-2">
          <GuidancePanel />
        </TabsContent>
      </Tabs>

      {editAction && (
        <EditActionModal action={editAction} open={!!editAction} onClose={() => setEditAction(null)} onSave={reload} />
      )}
    </div>
  );
}
