"use client";

import { cn } from "@/lib/utils";

interface MatrixProps {
  importance: number;
  urgence: number;
  onChange?: (importance: number, urgence: number) => void;
  readonly?: boolean;
}

const CELL_COLORS: Record<string, string> = {
  Low: "bg-[#27AE60]/20 text-[#27AE60]",
  Medium: "bg-[#FFD500]/20 text-[#FFD500]",
  High: "bg-[#EF7A16]/20 text-[#EF7A16]",
  Critical: "bg-[#E74C3C]/20 text-[#E74C3C]",
};

function getLevel(imp: number, urg: number): string {
  const matrix: Record<string, string> = {
    "1-1": "Low", "1-2": "Low", "1-3": "Low", "1-4": "Medium", "1-5": "Medium",
    "2-1": "Low", "2-2": "Low", "2-3": "Medium", "2-4": "Medium", "2-5": "High",
    "3-1": "Low", "3-2": "Medium", "3-3": "Medium", "3-4": "High", "3-5": "High",
    "4-1": "Medium", "4-2": "Medium", "4-3": "High", "4-4": "High", "4-5": "Critical",
    "5-1": "Medium", "5-2": "High", "5-3": "High", "5-4": "Critical", "5-5": "Critical",
  };
  return matrix[`${urg}-${imp}`] || "Low";
}

export function ImportanceUrgenceMatrix({ importance, urgence, onChange, readonly }: MatrixProps) {
  const level = getLevel(importance, urgence);

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2">
        <span className={cn("inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold", CELL_COLORS[level])}>
          {level}
        </span>
        <span className="text-xs text-white/40">Importance: {importance}/5 | Urgence: {urgence}/5</span>
      </div>

      {!readonly && onChange && (
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="text-xs text-white/40 mb-1 block">Importance</label>
            <input
              type="range"
              min={1} max={5} value={importance}
              onChange={e => onChange(parseInt(e.target.value), urgence)}
              className="w-full accent-[#0089D0]"
            />
            <div className="flex justify-between text-[10px] text-white/30">
              <span>1</span><span>2</span><span>3</span><span>4</span><span>5</span>
            </div>
          </div>
          <div>
            <label className="text-xs text-white/40 mb-1 block">Urgence</label>
            <input
              type="range"
              min={1} max={5} value={urgence}
              onChange={e => onChange(importance, parseInt(e.target.value))}
              className="w-full accent-[#EF7A16]"
            />
            <div className="flex justify-between text-[10px] text-white/30">
              <span>1</span><span>2</span><span>3</span><span>4</span><span>5</span>
            </div>
          </div>
        </div>
      )}

      {/* Mini 5x5 matrix visualization */}
      <div className="grid grid-cols-5 gap-0.5 w-[120px]">
        {[5, 4, 3, 2, 1].map(u => (
          [1, 2, 3, 4, 5].map(i => {
            const cellLevel = getLevel(i, u);
            const isSelected = i === importance && u === urgence;
            return (
              <div
                key={`${u}-${i}`}
                className={cn(
                  "h-5 w-full rounded-[2px] transition-all",
                  CELL_COLORS[cellLevel],
                  isSelected && "ring-2 ring-white scale-110 z-10",
                  !readonly && onChange && "cursor-pointer hover:opacity-80"
                )}
                onClick={() => !readonly && onChange?.(i, u)}
                title={`I:${i} U:${u} → ${cellLevel}`}
              />
            );
          })
        ))}
      </div>
    </div>
  );
}
