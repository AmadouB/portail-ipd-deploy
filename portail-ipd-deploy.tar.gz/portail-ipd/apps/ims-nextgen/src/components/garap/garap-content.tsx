"use client";

import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Pencil, Search, X } from "lucide-react";
import { cn } from "@/lib/utils";

interface Dossier {
  id: number; natureProduits: string; numDaBc: string | null; montant: number | null;
  statutWorkflow: string; dateLivraisonPrevue: string | null; dateLivraisonEffective: string | null;
  dateDerniereRelance: string | null; expressionBesoin: string | null; commentaireDal: string | null;
  entite: { code: string; libelle: string };
  fournisseur: { id: number; raisonSociale: string };
  devise: { codeIso: string; symbole: string; tauxConversionXof: number };
}

const pipelineStages = [
  { key: "ATTENTE_FOURNISSEUR", label: "Attente Fournisseur", color: "border-amber-500/30", dotColor: "bg-[#EF7A16]" },
  { key: "ATTENTE_PAIEMENT", label: "Attente Paiement DFC", color: "border-purple-500/30", dotColor: "bg-[#052A62]" },
  { key: "CHEZ_TRANSITAIRE", label: "Chez Transitaire", color: "border-[#0089D0]/30", dotColor: "bg-[#0089D0]" },
  { key: "EN_COURS_DOUANE", label: "En Cours Douane", color: "border-pink-500/30", dotColor: "bg-pink-400" },
  { key: "LIVRE", label: "Livre", color: "border-blue-500/30", dotColor: "bg-blue-400" },
  { key: "CLOTURE", label: "Cloture", color: "border-emerald-500/30", dotColor: "bg-[#27AE60]" },
];

const statutColors: Record<string, string> = {
  CLOTURE: "bg-[#27AE60]/10 text-[#27AE60] border-emerald-500/20",
  ATTENTE_FOURNISSEUR: "bg-[#EF7A16]/10 text-[#EF7A16] border-amber-500/20",
  ATTENTE_PAIEMENT: "bg-[#052A62]/10 text-[#052A62] border-purple-500/20",
  CHEZ_TRANSITAIRE: "bg-[#0089D0]/10 text-[#0089D0] border-[#0089D0]/20",
  EN_COURS_DOUANE: "bg-pink-500/10 text-pink-400 border-pink-500/20",
  LIVRE: "bg-blue-500/10 text-blue-400 border-blue-500/20",
};

const selectClass = "rounded-lg bg-white/[0.04] border border-white/[0.08] px-3 py-1.5 text-sm text-white/70 focus:outline-none focus:ring-1 focus:ring-cyan-500/50";
const inputClass = "bg-white/[0.04] border-white/[0.08] text-white placeholder:text-white/30 focus:ring-cyan-500/50 focus:border-[#0089D0]/50";

function formatMontant(m: number | null, devise: { symbole: string }) {
  if (!m) return "-";
  return `${m.toLocaleString("fr-FR", { maximumFractionDigits: 0 })} ${devise.symbole}`;
}

function EditGarapModal({ dossier, open, onClose, onSave }: { dossier: Dossier; open: boolean; onClose: () => void; onSave: () => void }) {
  const [form, setForm] = useState({
    statutWorkflow: dossier.statutWorkflow,
    montant: dossier.montant ?? 0,
    numDaBc: dossier.numDaBc || "",
    natureProduits: dossier.natureProduits,
    expressionBesoin: dossier.expressionBesoin || "",
    commentaireDal: dossier.commentaireDal || "",
    dateDerniereRelance: dossier.dateDerniereRelance || "",
    dateLivraisonPrevue: dossier.dateLivraisonPrevue || "",
    dateLivraisonEffective: dossier.dateLivraisonEffective || "",
  });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    setForm({
      statutWorkflow: dossier.statutWorkflow, montant: dossier.montant ?? 0,
      numDaBc: dossier.numDaBc || "", natureProduits: dossier.natureProduits,
      expressionBesoin: dossier.expressionBesoin || "", commentaireDal: dossier.commentaireDal || "",
      dateDerniereRelance: dossier.dateDerniereRelance || "",
      dateLivraisonPrevue: dossier.dateLivraisonPrevue || "",
      dateLivraisonEffective: dossier.dateLivraisonEffective || "",
    });
  }, [dossier]);

  const handleSave = async () => {
    setSaving(true);
    await fetch(`/api/garap/${dossier.id}`, {
      method: "PUT", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        ...form,
        montant: form.montant || null,
        numDaBc: form.numDaBc || null,
        expressionBesoin: form.expressionBesoin || null,
        commentaireDal: form.commentaireDal || null,
        dateDerniereRelance: form.dateDerniereRelance || null,
        dateLivraisonPrevue: form.dateLivraisonPrevue || null,
        dateLivraisonEffective: form.dateLivraisonEffective || null,
      }),
    });
    setSaving(false);
    onSave();
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-[#031A40] border-white/[0.08] text-white max-w-2xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-[#0089D0]">Dossier #{dossier.id} - {dossier.entite.libelle}</DialogTitle>
        </DialogHeader>
        <div className="grid gap-4 py-2">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-white/60 text-xs">Statut workflow</Label>
              <select value={form.statutWorkflow} onChange={(e) => setForm({ ...form, statutWorkflow: e.target.value })} className={cn("w-full mt-1", selectClass)}>
                {pipelineStages.map((s) => <option key={s.key} value={s.key}>{s.label}</option>)}
              </select>
            </div>
            <div>
              <Label className="text-white/60 text-xs">Montant ({dossier.devise.symbole})</Label>
              <Input type="number" step="0.01" value={form.montant} onChange={(e) => setForm({ ...form, montant: parseFloat(e.target.value) || 0 })} className={cn("mt-1", inputClass)} />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-white/60 text-xs">N DA/BC</Label>
              <Input value={form.numDaBc} onChange={(e) => setForm({ ...form, numDaBc: e.target.value })} className={cn("mt-1", inputClass)} />
            </div>
            <div>
              <Label className="text-white/60 text-xs">Nature produits</Label>
              <Input value={form.natureProduits} onChange={(e) => setForm({ ...form, natureProduits: e.target.value })} className={cn("mt-1", inputClass)} />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div>
              <Label className="text-white/60 text-xs">Derniere relance</Label>
              <Input type="date" value={form.dateDerniereRelance} onChange={(e) => setForm({ ...form, dateDerniereRelance: e.target.value })} className={cn("mt-1", inputClass)} />
            </div>
            <div>
              <Label className="text-white/60 text-xs">Livraison prevue</Label>
              <Input type="date" value={form.dateLivraisonPrevue} onChange={(e) => setForm({ ...form, dateLivraisonPrevue: e.target.value })} className={cn("mt-1", inputClass)} />
            </div>
            <div>
              <Label className="text-white/60 text-xs">Livraison effective</Label>
              <Input type="date" value={form.dateLivraisonEffective} onChange={(e) => setForm({ ...form, dateLivraisonEffective: e.target.value })} className={cn("mt-1", inputClass)} />
            </div>
          </div>

          <div>
            <Label className="text-white/60 text-xs">Expression du besoin</Label>
            <Textarea value={form.expressionBesoin} onChange={(e) => setForm({ ...form, expressionBesoin: e.target.value })} rows={2} className={cn("mt-1", inputClass)} />
          </div>
          <div>
            <Label className="text-white/60 text-xs">Commentaire DAL</Label>
            <Textarea value={form.commentaireDal} onChange={(e) => setForm({ ...form, commentaireDal: e.target.value })} rows={2} className={cn("mt-1", inputClass)} />
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <Button variant="outline" onClick={onClose} className="border-white/10 text-white/60 hover:bg-white/5">Annuler</Button>
            <Button onClick={handleSave} disabled={saving} className="bg-cyan-600 hover:bg-cyan-700 text-white">
              {saving ? "Enregistrement..." : "Enregistrer"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export function GarapContent() {
  const [data, setData] = useState<{ dossiers: Dossier[]; entites: any[]; fournisseurs: any[] } | null>(null);
  const [filter, setFilter] = useState({ entite: "", statut: "", fournisseur: "", devise: "", search: "" });
  const [editDossier, setEditDossier] = useState<Dossier | null>(null);

  const reload = () => fetch("/api/garap").then((r) => r.json()).then(setData);
  useEffect(() => { reload(); }, []);

  if (!data) return <div className="flex items-center justify-center h-64 text-white/40">Chargement...</div>;

  const filtered = data.dossiers.filter((d) => {
    if (filter.entite && d.entite.code !== filter.entite) return false;
    if (filter.statut && d.statutWorkflow !== filter.statut) return false;
    if (filter.fournisseur && String(d.fournisseur.id) !== filter.fournisseur) return false;
    if (filter.devise && d.devise.codeIso !== filter.devise) return false;
    if (filter.search && !d.natureProduits.toLowerCase().includes(filter.search.toLowerCase()) && !(d.numDaBc || "").toLowerCase().includes(filter.search.toLowerCase())) return false;
    return true;
  });

  const devises = [...new Set(data.dossiers.map((d) => d.devise.codeIso))];
  const hasActiveFilters = Object.values(filter).some(Boolean);

  return (
    <div className="space-y-6">
      <Tabs defaultValue="pipeline">
        <TabsList className="bg-white/[0.04] border border-white/[0.06]">
          <TabsTrigger value="pipeline" className="data-[state=active]:bg-[#0089D0]/10 data-[state=active]:text-[#0089D0]">Pipeline</TabsTrigger>
          <TabsTrigger value="table" className="data-[state=active]:bg-[#0089D0]/10 data-[state=active]:text-[#0089D0]">Table</TabsTrigger>
        </TabsList>

        <div className="flex gap-3 flex-wrap mt-4 items-center">
          <div className="relative">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-white/30" />
            <input value={filter.search} onChange={(e) => setFilter({ ...filter, search: e.target.value })} placeholder="Rechercher..." className={cn("pl-8 w-52", selectClass)} />
          </div>
          <select value={filter.entite} onChange={(e) => setFilter({ ...filter, entite: e.target.value })} className={selectClass}>
            <option value="">Toutes les entites</option>
            {data.entites.map((ent) => <option key={ent.code} value={ent.code}>{ent.libelle}</option>)}
          </select>
          <select value={filter.statut} onChange={(e) => setFilter({ ...filter, statut: e.target.value })} className={selectClass}>
            <option value="">Tous les statuts</option>
            {pipelineStages.map((s) => <option key={s.key} value={s.key}>{s.label}</option>)}
          </select>
          <select value={filter.fournisseur} onChange={(e) => setFilter({ ...filter, fournisseur: e.target.value })} className={selectClass}>
            <option value="">Tous fournisseurs</option>
            {data.fournisseurs.map((f) => <option key={f.id} value={String(f.id)}>{f.raisonSociale}</option>)}
          </select>
          <select value={filter.devise} onChange={(e) => setFilter({ ...filter, devise: e.target.value })} className={selectClass}>
            <option value="">Toutes devises</option>
            {devises.map((d) => <option key={d} value={d}>{d}</option>)}
          </select>
          {hasActiveFilters && (
            <button onClick={() => setFilter({ entite: "", statut: "", fournisseur: "", devise: "", search: "" })} className="flex items-center gap-1 text-xs text-red-400 hover:text-red-300">
              <X className="h-3 w-3" /> Reinitialiser
            </button>
          )}
        </div>

        <p className="text-xs text-white/30 mt-2">{filtered.length} dossier(s) affiche(s)</p>

        <TabsContent value="pipeline" className="mt-2">
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
            {pipelineStages.map((stage) => {
              const items = filtered.filter((d) => d.statutWorkflow === stage.key);
              return (
                <Card key={stage.key} className={cn("border glass", stage.color)}>
                  <CardHeader className="pb-2">
                    <div className="flex items-center gap-2">
                      <div className={cn("h-2 w-2 rounded-full", stage.dotColor)} />
                      <CardTitle className="text-xs text-white/60">{stage.label}</CardTitle>
                    </div>
                    <p className="text-2xl font-bold text-white">{items.length}</p>
                  </CardHeader>
                  <CardContent className="pt-0 max-h-[300px] overflow-y-auto">
                    <div className="space-y-2">
                      {items.slice(0, 8).map((d) => (
                        <div key={d.id} className="rounded-lg bg-white/[0.03] p-2 border border-white/[0.04] group cursor-pointer hover:border-[#0089D0]/20 transition-colors" onClick={() => setEditDossier(d)}>
                          <p className="text-[10px] text-white/60 truncate">{d.natureProduits}</p>
                          <div className="flex justify-between items-center mt-1">
                            <span className="text-[9px] text-white/30">{d.fournisseur.raisonSociale}</span>
                            <span className="text-[9px] text-[#0089D0] font-mono">{formatMontant(d.montant, d.devise)}</span>
                          </div>
                        </div>
                      ))}
                      {items.length > 8 && <p className="text-[10px] text-white/20 text-center">+{items.length - 8} autres</p>}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </TabsContent>

        <TabsContent value="table" className="mt-2">
          <Card className="glass border-white/[0.08] overflow-hidden">
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="text-[10px] text-white/30 uppercase tracking-wider border-b border-white/[0.06]">
                      <th className="text-left py-3 px-3">ID</th>
                      <th className="text-left py-3 px-3">Entite</th>
                      <th className="text-left py-3 px-3">Nature</th>
                      <th className="text-left py-3 px-3">Fournisseur</th>
                      <th className="text-left py-3 px-3">DA/BC</th>
                      <th className="text-left py-3 px-3">Montant</th>
                      <th className="text-left py-3 px-3">Livr. prevue</th>
                      <th className="text-left py-3 px-3">Statut</th>
                      <th className="text-right py-3 px-3">Edit</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filtered.slice(0, 80).map((d) => (
                      <tr key={d.id} className="border-t border-white/[0.03] hover:bg-white/[0.02] transition-colors">
                        <td className="py-2.5 px-3 text-xs font-mono text-[#0089D0]">{d.id}</td>
                        <td className="py-2.5 px-3"><Badge variant="outline" className="text-[10px] border-white/10 text-white/50">{d.entite.code}</Badge></td>
                        <td className="py-2.5 px-3 text-xs text-white/70 max-w-[200px] truncate">{d.natureProduits}</td>
                        <td className="py-2.5 px-3 text-xs text-white/50">{d.fournisseur.raisonSociale}</td>
                        <td className="py-2.5 px-3 text-xs text-white/40 font-mono">{d.numDaBc || "-"}</td>
                        <td className="py-2.5 px-3 text-xs text-white/60 font-mono">{formatMontant(d.montant, d.devise)}</td>
                        <td className="py-2.5 px-3 text-xs text-white/40 font-mono">{d.dateLivraisonPrevue || "-"}</td>
                        <td className="py-2.5 px-3"><Badge variant="outline" className={cn("text-[10px]", statutColors[d.statutWorkflow])}>{d.statutWorkflow.replace(/_/g, " ")}</Badge></td>
                        <td className="py-2.5 px-3 text-right">
                          <button onClick={() => setEditDossier(d)} className="p-1 rounded hover:bg-white/[0.06] text-white/30 hover:text-[#0089D0] transition-colors">
                            <Pencil className="h-3.5 w-3.5" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                {filtered.length > 80 && <p className="text-xs text-white/20 text-center py-3">Affichage limite a 80 sur {filtered.length}</p>}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {editDossier && (
        <EditGarapModal dossier={editDossier} open={!!editDossier} onClose={() => setEditDossier(null)} onSave={reload} />
      )}
    </div>
  );
}
