"use client";

import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Package, TrendingUp, Clock, CheckCircle2 } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import { CHART_COLORS } from "@/lib/colors";

interface GarapStats {
  total: number;
  clotures: number;
  tauxCloture: number;
  delaiMoyen: number;
  parFournisseur: { name: string; count: number }[];
  parEntite: { name: string; count: number }[];
  parStatut: { name: string; count: number }[];
}

export function GarapDashboard() {
  const [stats, setStats] = useState<GarapStats | null>(null);

  useEffect(() => {
    fetch("/api/garap?stats=true")
      .then(r => r.json())
      .then(data => {
        // Calculate stats from raw data if needed
        const items = data.items || data || [];
        if (Array.isArray(items)) {
          const total = items.length;
          const clotures = items.filter((i: any) => i.statutWorkflow === "CLOTUREE").length;

          // Group by fournisseur
          const fournisseurMap: Record<string, number> = {};
          const entiteMap: Record<string, number> = {};
          const statutMap: Record<string, number> = {};
          let totalDelai = 0;
          let delaiCount = 0;

          for (const item of items) {
            const fName = item.fournisseur?.raisonSociale || "Inconnu";
            fournisseurMap[fName] = (fournisseurMap[fName] || 0) + 1;

            const eName = item.entite?.code || "Inconnu";
            entiteMap[eName] = (entiteMap[eName] || 0) + 1;

            statutMap[item.statutWorkflow] = (statutMap[item.statutWorkflow] || 0) + 1;

            if (item.dateLivraisonPrevue && item.dateLivraisonEffective) {
              const diff = (new Date(item.dateLivraisonEffective).getTime() - new Date(item.dateLivraisonPrevue).getTime()) / (1000 * 60 * 60 * 24);
              totalDelai += diff;
              delaiCount++;
            }
          }

          setStats({
            total,
            clotures,
            tauxCloture: total > 0 ? Math.round((clotures / total) * 100) : 0,
            delaiMoyen: delaiCount > 0 ? Math.round(totalDelai / delaiCount) : 0,
            parFournisseur: Object.entries(fournisseurMap)
              .map(([name, count]) => ({ name, count }))
              .sort((a, b) => b.count - a.count)
              .slice(0, 8),
            parEntite: Object.entries(entiteMap).map(([name, count]) => ({ name, count })),
            parStatut: Object.entries(statutMap).map(([name, count]) => ({ name, count })),
          });
        }
      });
  }, []);

  if (!stats) return <div className="text-white/40 p-4">Chargement...</div>;

  return (
    <div className="space-y-6">
      {/* KPI Row */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="glass glow-cyan">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-white/55 uppercase">Total commandes</p>
                <p className="text-3xl font-bold text-white mt-1">{stats.total}</p>
              </div>
              <Package className="h-8 w-8 text-[#0089D0]/60" />
            </div>
          </CardContent>
        </Card>
        <Card className="glass glow-emerald">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-white/55 uppercase">Clôturées</p>
                <p className="text-3xl font-bold text-white mt-1">{stats.clotures}</p>
              </div>
              <CheckCircle2 className="h-8 w-8 text-[#27AE60]/60" />
            </div>
          </CardContent>
        </Card>
        <Card className="glass glow-amber">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-white/55 uppercase">Taux clôture</p>
                <p className="text-3xl font-bold text-white mt-1">{stats.tauxCloture}%</p>
              </div>
              <TrendingUp className="h-8 w-8 text-[#EF7A16]/60" />
            </div>
          </CardContent>
        </Card>
        <Card className="glass">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-white/55 uppercase">Délai moyen</p>
                <p className="text-3xl font-bold text-white mt-1">{stats.delaiMoyen}<span className="text-lg text-white/40">j</span></p>
              </div>
              <Clock className="h-8 w-8 text-white/30" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="glass">
          <CardHeader>
            <CardTitle className="text-sm text-white">Par fournisseur</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[250px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={stats.parFournisseur} layout="vertical">
                  <XAxis type="number" tick={{ fill: "rgba(255,255,255,0.4)", fontSize: 11 }} />
                  <YAxis type="category" dataKey="name" width={100} tick={{ fill: "rgba(255,255,255,0.6)", fontSize: 11 }} />
                  <Tooltip contentStyle={{ background: "#031A40", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 8, color: "#fff" }} />
                  <Bar dataKey="count" fill="#0089D0" radius={[0, 4, 4, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card className="glass">
          <CardHeader>
            <CardTitle className="text-sm text-white">Par entité</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[250px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={stats.parEntite} cx="50%" cy="50%" outerRadius={80} dataKey="count" label={({ name, percent }: any) => `${name} (${((percent ?? 0) * 100).toFixed(0)}%)`}>
                    {stats.parEntite.map((_, i) => (
                      <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip contentStyle={{ background: "#031A40", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 8, color: "#fff" }} />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
