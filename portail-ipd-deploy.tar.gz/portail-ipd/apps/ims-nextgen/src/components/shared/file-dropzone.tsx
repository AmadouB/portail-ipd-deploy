"use client";

import { useCallback, useState } from "react";
import { Upload, X, FileText, Image, Table } from "lucide-react";
import { cn } from "@/lib/utils";

interface FileDropzoneProps {
  onUpload: (file: File) => Promise<void>;
  actionId?: number;
  ecartId?: number;
  existingFiles?: { id: number; fileName: string; filePath: string; mimeType: string; fileSize: number }[];
  className?: string;
}

const ICONS: Record<string, React.ElementType> = {
  "application/pdf": FileText,
  "image/png": Image,
  "image/jpeg": Image,
  "image/gif": Image,
};

function formatSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} Ko`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} Mo`;
}

export function FileDropzone({ onUpload, existingFiles = [], className }: FileDropzoneProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleDrop = useCallback(async (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    setError(null);

    const files = Array.from(e.dataTransfer.files);
    for (const file of files) {
      if (file.size > 10 * 1024 * 1024) {
        setError("Fichier trop volumineux (max 10 Mo)");
        return;
      }
      setUploading(true);
      try {
        await onUpload(file);
      } catch (err: any) {
        setError(err.message || "Erreur lors de l'upload");
      } finally {
        setUploading(false);
      }
    }
  }, [onUpload]);

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;
    setError(null);
    for (const file of Array.from(files)) {
      if (file.size > 10 * 1024 * 1024) {
        setError("Fichier trop volumineux (max 10 Mo)");
        return;
      }
      setUploading(true);
      try {
        await onUpload(file);
      } catch (err: any) {
        setError(err.message || "Erreur lors de l'upload");
      } finally {
        setUploading(false);
      }
    }
    e.target.value = "";
  };

  return (
    <div className={cn("space-y-3", className)}>
      <div
        onDragOver={e => { e.preventDefault(); setIsDragging(true); }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={handleDrop}
        className={cn(
          "relative flex flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed p-6 transition-all cursor-pointer",
          isDragging ? "border-[#0089D0] bg-[#0089D0]/10" : "border-white/[0.12] bg-white/[0.02] hover:border-white/[0.2]"
        )}
      >
        <input
          type="file"
          multiple
          accept=".pdf,.xlsx,.xls,.png,.jpg,.jpeg,.gif"
          onChange={handleFileSelect}
          className="absolute inset-0 opacity-0 cursor-pointer"
        />
        <Upload className={cn("h-8 w-8", isDragging ? "text-[#0089D0]" : "text-white/30")} />
        <p className="text-sm text-white/50">
          {uploading ? "Upload en cours..." : "Glissez-déposez vos fichiers ici"}
        </p>
        <p className="text-xs text-white/30">PDF, Excel, Images — Max 10 Mo</p>
      </div>

      {error && <p className="text-xs text-[#E74C3C]">{error}</p>}

      {existingFiles.length > 0 && (
        <div className="space-y-2">
          {existingFiles.map(file => {
            const Icon = ICONS[file.mimeType] || FileText;
            return (
              <div key={file.id} className="flex items-center gap-3 rounded-lg border border-white/[0.06] bg-white/[0.03] px-3 py-2">
                <Icon className="h-4 w-4 text-[#0089D0]" />
                <a href={file.filePath} target="_blank" rel="noopener" className="flex-1 text-sm text-white/70 hover:text-white truncate">
                  {file.fileName}
                </a>
                <span className="text-xs text-white/30">{formatSize(file.fileSize)}</span>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
