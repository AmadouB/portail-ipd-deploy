"use client";

import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

interface Action {
  id: number; chronoLegacy: number | null; description: string; statut: string;
  scoreRisque: number; niveauCriticite: string; avancement: number;
  workstream: { code: string; libelle: string };
  responsables: { user: { name: string } }[];
}

const probLabels = ["1 - Very Low", "2 - Low", "3 - Medium", "4 - High", "5 - Almost Certain"];
const impactLabels = ["1 - Insignificant", "2 - Minor", "3 - Moderate", "4 - Major", "5 - Severe"];

// RIV matrix: matrix[impact][prob] = level
const rivMatrix: string[][] = [
  ["Low", "Low", "Low", "Medium", "Medium"],       // Impact 1
  ["Low", "Low", "Medium", "Medium", "High"],       // Impact 2
  ["Low", "Medium", "Medium", "High", "Very High"], // Impact 3
  ["Medium", "Medium", "High", "Very High", "Very High"], // Impact 4
  ["Medium", "High", "Very High", "Very High", "Very High"], // Impact 5
];

const levelColors: Record<string, string> = {
  Low: "bg-[#27AE60]/20 text-emerald-300 border-emerald-500/30",
  Medium: "bg-[#EF7A16]/20 text-amber-300 border-amber-500/30",
  High: "bg-orange-500/20 text-orange-300 border-orange-500/30",
  "Very High": "bg-red-500/20 text-red-300 border-red-500/30",
};

const levelBg: Record<string, string> = {
  Low: "bg-[#27AE60]/10",
  Medium: "bg-[#EF7A16]/10",
  High: "bg-orange-500/10",
  "Very High": "bg-red-500/10",
};

const critColors: Record<string, string> = {
  Low: "bg-[#27AE60]/10 text-[#27AE60] border-emerald-500/20",
  Medium: "bg-[#EF7A16]/10 text-[#EF7A16] border-amber-500/20",
  High: "bg-orange-500/10 text-orange-400 border-orange-500/20",
  "Very High": "bg-red-500/10 text-red-400 border-red-500/20",
};

export function RisquesContent() {
  const [actions, setActions] = useState<Action[]>([]);

  useEffect(() => {
    fetch("/api/actions-afm").then((r) => r.json()).then((d) => setActions(d.actions));
  }, []);

  const openActions = actions.filter((a) => a.statut !== "CLOTURE");

  const thresholds = [
    { range: "1-3", level: "Low", desc: "Pas d'action requise", color: "text-[#27AE60]" },
    { range: "4-9", level: "Medium", desc: "Plan de mitigation recommande", color: "text-[#EF7A16]" },
    { range: "10-12", level: "High", desc: "Plan de mitigation obligatoire", color: "text-orange-400" },
    { range: "15-25", level: "Very High", desc: "Escalade immediate a la Direction", color: "text-red-400" },
  ];

  return (
    <div className="space-y-6">
      {/* RIV Matrix */}
      <Card className="glass border-white/[0.08]">
        <CardHeader>
          <CardTitle className="text-sm text-white/70">Matrice RIV 5x5 - Impact x Probabilite</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr>
                  <th className="text-[10px] text-white/30 p-2 text-left">Impact / Prob.</th>
                  {probLabels.map((p, i) => (
                    <th key={i} className="text-[10px] text-white/40 p-2 text-center">{p}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {[...impactLabels].reverse().map((imp, ri) => {
                  const impIdx = 4 - ri;
                  return (
                    <tr key={impIdx}>
                      <td className="text-[10px] text-white/40 p-2 whitespace-nowrap">{imp}</td>
                      {[0, 1, 2, 3, 4].map((pi) => {
                        const level = rivMatrix[impIdx][pi];
                        const score = (impIdx + 1) * (pi + 1);
                        return (
                          <td key={pi} className="p-1">
                            <div className={cn("rounded-lg p-3 text-center border", levelColors[level])}>
                              <p className="text-sm font-bold">{score}</p>
                              <p className="text-[9px] opacity-70">{level}</p>
                            </div>
                          </td>
                        );
                      })}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Thresholds */}
      <div className="grid grid-cols-4 gap-3">
        {thresholds.map((t) => (
          <Card key={t.range} className="glass border-white/[0.08]">
            <CardContent className="p-4 text-center">
              <p className={cn("text-lg font-bold", t.color)}>{t.range}</p>
              <p className="text-xs text-white/60 mt-1">{t.level}</p>
              <p className="text-[10px] text-white/30 mt-1">{t.desc}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Actions by risk level */}
      <Card className="glass border-white/[0.08]">
        <CardHeader>
          <CardTitle className="text-sm text-white/70">Actions ouvertes par niveau de criticite</CardTitle>
        </CardHeader>
        <CardContent>
          {["Very High", "High", "Medium", "Low"].map((level) => {
            const items = openActions.filter((a) => a.niveauCriticite === level);
            if (items.length === 0) return null;
            return (
              <div key={level} className="mb-4">
                <div className="flex items-center gap-2 mb-2">
                  <Badge variant="outline" className={cn("text-xs", critColors[level])}>{level}</Badge>
                  <span className="text-xs text-white/30">{items.length} action(s)</span>
                </div>
                <div className="space-y-1.5">
                  {items.map((a) => (
                    <div key={a.id} className="flex items-center gap-3 rounded-lg bg-white/[0.02] p-2.5 border border-white/[0.04]">
                      <span className="text-xs font-mono text-[#0089D0] w-8">#{a.chronoLegacy}</span>
                      <span className="text-xs text-white/60 flex-1 truncate">{a.description}</span>
                      <Badge variant="outline" className="text-[10px] border-white/10 text-white/40">{a.workstream.code}</Badge>
                      <span className="text-xs font-mono text-white/50">Score: {a.scoreRisque}</span>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </CardContent>
      </Card>
    </div>
  );
}
