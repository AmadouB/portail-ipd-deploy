"use client";

import { useState } from "react";
import { Plus, X, Check, Loader2 } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

type EntityType = "service" | "workstream" | "entite" | "fournisseur" | "macroEcart";

interface EntityCreatorProps {
  type: EntityType;
  onCreated: (entity: any) => void;
  trigger?: React.ReactNode;
}

const ENTITY_CONFIG: Record<EntityType, { label: string; icon: string; fields: { key: string; label: string; required?: boolean; placeholder?: string }[] }> = {
  service: {
    label: "Service / Département",
    icon: "🏢",
    fields: [
      { key: "code", label: "Code", required: true, placeholder: "Ex: DRO, RH, IT..." },
      { key: "libelle", label: "Libellé complet", required: true, placeholder: "Direction des Ressources..." },
      { key: "libelleCourt", label: "Libellé court", placeholder: "Ex: DRO" },
    ],
  },
  workstream: {
    label: "Workstream",
    icon: "📂",
    fields: [
      { key: "code", label: "Code", required: true, placeholder: "Ex: WS8, WS9..." },
      { key: "libelle", label: "Libellé", required: true, placeholder: "Nom du workstream..." },
      { key: "responsableWs", label: "Responsable WS", placeholder: "Nom du responsable..." },
    ],
  },
  entite: {
    label: "Entité (Supply Chain)",
    icon: "🏭",
    fields: [
      { key: "code", label: "Code", required: true, placeholder: "Ex: MAINT, LOG..." },
      { key: "libelle", label: "Libellé", required: true, placeholder: "Nom de l'entité..." },
    ],
  },
  fournisseur: {
    label: "Fournisseur",
    icon: "🚚",
    fields: [
      { key: "raisonSociale", label: "Raison sociale", required: true, placeholder: "Nom du fournisseur..." },
      { key: "pays", label: "Pays", placeholder: "Ex: Sénégal, France..." },
      { key: "delaiMoyenLivraison", label: "Délai moyen (jours)", placeholder: "Ex: 30" },
    ],
  },
  macroEcart: {
    label: "Macro-Écart",
    icon: "📋",
    fields: [
      { key: "numero", label: "Numéro", required: true, placeholder: "Ex: 12, 13..." },
      { key: "description", label: "Description", required: true, placeholder: "Description du macro-écart..." },
      { key: "classification", label: "Classification", placeholder: "Majeure / Mineure" },
    ],
  },
};

export function EntityCreator({ type, onCreated, trigger }: EntityCreatorProps) {
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [values, setValues] = useState<Record<string, string>>({});

  const config = ENTITY_CONFIG[type];

  const handleSave = async () => {
    setError(null);
    // Validate required fields
    for (const field of config.fields) {
      if (field.required && !values[field.key]?.trim()) {
        setError(`Le champ "${field.label}" est requis`);
        return;
      }
    }

    setSaving(true);
    try {
      const res = await fetch("/api/entites", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ entityType: type, ...values }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Erreur lors de la création");
        return;
      }
      onCreated(data.entity);
      setValues({});
      setOpen(false);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <>
      {trigger ? (
        <div onClick={() => setOpen(true)}>{trigger}</div>
      ) : (
        <button
          onClick={() => setOpen(true)}
          className="flex items-center gap-1.5 rounded-md border border-dashed border-[#0089D0]/30 bg-[#0089D0]/5 px-2.5 py-1.5 text-[11px] font-medium text-[#0089D0] hover:bg-[#0089D0]/10 transition-colors"
        >
          <Plus className="h-3 w-3" /> Nouveau {config.label}
        </button>
      )}

      <Dialog open={open} onOpenChange={v => { if (!v) { setOpen(false); setError(null); setValues({}); } }}>
        <DialogContent className="bg-[#031A40] border-white/[0.08] text-white max-w-md">
          <DialogHeader>
            <DialogTitle className="text-white flex items-center gap-2">
              <span>{config.icon}</span> Nouveau {config.label}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 mt-2">
            {config.fields.map(field => (
              <div key={field.key}>
                <label className="block text-[10px] text-white/40 mb-1 font-bold uppercase tracking-wider">
                  {field.label} {field.required && <span className="text-[#E74C3C]">*</span>}
                </label>
                <input
                  value={values[field.key] || ""}
                  onChange={e => setValues({ ...values, [field.key]: e.target.value })}
                  placeholder={field.placeholder}
                  className="w-full rounded-lg border border-white/[0.08] bg-white/[0.04] px-3 py-2 text-sm text-white/80 placeholder:text-white/25 focus:border-[#0089D0]/30 focus:outline-none"
                />
              </div>
            ))}

            {error && (
              <div className="rounded-lg bg-[#E74C3C]/10 border border-[#E74C3C]/20 px-3 py-2 text-xs text-[#E74C3C]">
                {error}
              </div>
            )}

            <div className="flex justify-end gap-2 pt-2">
              <button onClick={() => { setOpen(false); setError(null); setValues({}); }} className="px-3 py-1.5 rounded-lg border border-white/[0.08] text-white/50 text-sm hover:bg-white/[0.04]">
                Annuler
              </button>
              <button onClick={handleSave} disabled={saving} className="flex items-center gap-1.5 px-4 py-1.5 rounded-lg bg-[#0089D0] text-white text-sm font-semibold hover:bg-[#0089D0]/80 disabled:opacity-50">
                {saving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Check className="h-3.5 w-3.5" />}
                {saving ? "Création..." : "Créer"}
              </button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
