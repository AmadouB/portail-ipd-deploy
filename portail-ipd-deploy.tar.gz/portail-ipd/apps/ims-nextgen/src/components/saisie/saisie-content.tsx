"use client";

import { useEffect, useState, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import {
  Plus, Search, Filter, Save, X, Upload, MessageSquare, Paperclip, CheckCircle2,
  AlertTriangle, Clock, ChevronDown, FileText, Trash2, Edit3,
} from "lucide-react";
import { ImportanceUrgenceMatrix } from "@/components/actions/importance-urgence-matrix";
import { FileDropzone } from "@/components/shared/file-dropzone";
import { StagnationBadge } from "@/components/persistance/stagnation-badge";
import { EntityCreator } from "./entity-creator";

// ---------- Types ----------
interface RefData {
  services: { id: number; code: string; libelle: string }[];
  workstreams: { id: number; code: string; libelle: string }[];
  users: { id: number; name: string; email: string; service: string | null }[];
  macroEcarts: { id: number; numero: string; description: string }[];
  actions: any[];
  ecarts: any[];
}

type ViewType = "actions" | "ecarts";
type FormMode = "create" | "edit";

// ---------- Status helpers ----------
// Statuts réels dans la BDD (respecter la casse exacte)
const ACTION_STATUTS = ["EN_COURS", "EN_RETARD", "CLOTURE", "Clôturé", "En cours", "En retard", "A_LANCER", "A lancer", "Bloqué", "Non démarré"];
const ECART_STATUTS = ["EN_COURS", "REVU", "CLOTURE"];
const ECART_CLASSIFICATIONS = ["Majeur", "Mineur", "Majeure", "Mineure", "Observation"];
const CRITICITE_LEVELS = ["Low", "Medium", "High", "Very High", "Critical"];

// Labels lisibles pour affichage
const STATUT_LABELS: Record<string, string> = {
  EN_COURS: "En cours", EN_RETARD: "En retard", CLOTURE: "Clôturé",
  A_LANCER: "A lancer", "Clôturé": "Clôturé", "En cours": "En cours",
  "En retard": "En retard", "A lancer": "A lancer", "Bloqué": "Bloqué",
  "Non démarré": "Non démarré", REVU: "Revu",
  Majeur: "Majeur", Mineur: "Mineur", Majeure: "Majeure", Mineure: "Mineure",
};

function statusColor(s: string) {
  const map: Record<string, string> = {
    "En cours": "bg-[#0089D0]/15 text-[#0089D0]",
    EN_COURS: "bg-[#0089D0]/15 text-[#0089D0]",
    "En retard": "bg-[#E74C3C]/15 text-[#E74C3C]",
    EN_RETARD: "bg-[#E74C3C]/15 text-[#E74C3C]",
    "Clôturé": "bg-[#27AE60]/15 text-[#27AE60]",
    CLOTURE: "bg-[#27AE60]/15 text-[#27AE60]",
    REVU: "bg-[#FFD500]/15 text-[#FFD500]",
    "Non démarré": "bg-white/[0.08] text-white/50",
    A_LANCER: "bg-white/[0.08] text-white/50",
    "A lancer": "bg-white/[0.08] text-white/50",
    "Bloqué": "bg-[#E74C3C]/15 text-[#E74C3C]",
    Majeur: "bg-[#E74C3C]/15 text-[#E74C3C]",
    Mineur: "bg-[#EF7A16]/15 text-[#EF7A16]",
  };
  return map[s] || "bg-white/[0.08] text-white/50";
}

// ---------- Main Component ----------
export function SaisieContent() {
  const [ref, setRef] = useState<RefData | null>(null);
  const [loading, setLoading] = useState(true);
  const [view, setView] = useState<ViewType>("actions");
  const [search, setSearch] = useState("");
  const [filterService, setFilterService] = useState("");
  const [filterStatut, setFilterStatut] = useState("");
  const [filterWorkstream, setFilterWorkstream] = useState("");
  const [filterCriticite, setFilterCriticite] = useState("");
  const [filterClassif, setFilterClassif] = useState("");
  const [filterMacroEcart, setFilterMacroEcart] = useState("");
  const [filterDateFrom, setFilterDateFrom] = useState("");
  const [filterDateTo, setFilterDateTo] = useState("");
  const [showAllFilters, setShowAllFilters] = useState(false);
  const [modalOpen, setModalOpen] = useState(false);
  const [formMode, setFormMode] = useState<FormMode>("create");
  const [editId, setEditId] = useState<number | null>(null);
  const [saving, setSaving] = useState(false);

  // Action form state
  const [fWorkstream, setFWorkstream] = useState("");
  const [fDescription, setFDescription] = useState("");
  const [fDeadline, setFDeadline] = useState("");
  const [fDeadlineRev, setFDeadlineRev] = useState("");
  const [fStatut, setFStatut] = useState("En cours");
  const [fImportance, setFImportance] = useState(1);
  const [fUrgence, setFUrgence] = useState(1);
  const [fAvancement, setFAvancement] = useState(0);
  const [fCommentaires, setFCommentaires] = useState("");
  const [fResponsables, setFResponsables] = useState<number[]>([]);
  const [fNewComment, setFNewComment] = useState("");

  // Ecart form state
  const [fNumero, setFNumero] = useState("");
  const [fNomEcart, setFNomEcart] = useState("");
  const [fEcartDesc, setFEcartDesc] = useState("");
  const [fMacroEcart, setFMacroEcart] = useState("");
  const [fServiceId, setFServiceId] = useState("");
  const [fClassif, setFClassif] = useState("Mineure");
  const [fEcartStatut, setFEcartStatut] = useState("EN_COURS");
  const [fPctAvanc, setFPctAvanc] = useState(0);
  const [fCauses, setFCauses] = useState("");
  const [fCorrectives, setFCorrectives] = useState("");
  const [fBloquants, setFBloquants] = useState("");
  const [fDocsRef, setFDocsRef] = useState("");
  const [fDateFinal, setFDateFinal] = useState("");
  const [fProba, setFProba] = useState(1);
  const [fImpact, setFImpact] = useState(1);
  const [fCommentAvanc, setFCommentAvanc] = useState("");

  // Files
  const [existingFiles, setExistingFiles] = useState<any[]>([]);

  const fetchData = useCallback(() => {
    setLoading(true);
    fetch(`/api/saisie?type=all`)
      .then(r => r.json())
      .then(setRef)
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  // ---------- Dynamic filter options (extracted from actual data) ----------
  const actionStatuts = [...new Set((ref?.actions || []).map((a: any) => a.statut))].filter(Boolean).sort() as string[];
  const actionWsIds = [...new Set((ref?.actions || []).map((a: any) => a.workstreamId))].filter(Boolean) as number[];
  const actionCriticites = [...new Set((ref?.actions || []).map((a: any) => a.niveauCriticite))].filter(Boolean).sort() as string[];
  const ecartStatuts = [...new Set((ref?.ecarts || []).map((e: any) => e.statut))].filter(Boolean).sort() as string[];
  const ecartClassifs = [...new Set((ref?.ecarts || []).map((e: any) => e.classification))].filter(Boolean).sort() as string[];

  // ---------- Filtering ----------
  const filteredActions = (ref?.actions || []).filter((a: any) => {
    if (search) {
      const q = search.toLowerCase();
      const match = a.description?.toLowerCase().includes(q)
        || String(a.chronoAuto || "").toLowerCase().includes(q)
        || String(a.chronoLegacy || "").includes(q)
        || a.commentaires?.toLowerCase().includes(q);
      if (!match) return false;
    }
    if (filterStatut && a.statut !== filterStatut) return false;
    if (filterWorkstream && String(a.workstreamId) !== filterWorkstream) return false;
    if (filterCriticite && a.niveauCriticite !== filterCriticite) return false;
    if (filterService) {
      // Filter by workstream service mapping OR responsable service
      const hasService = a.responsables?.some((r: any) => r.user?.service === filterService);
      if (!hasService) return false;
    }
    if (filterDateFrom && a.deadlineInitiale < filterDateFrom) return false;
    if (filterDateTo && a.deadlineInitiale > filterDateTo) return false;
    return true;
  });

  const filteredEcarts = (ref?.ecarts || []).filter((e: any) => {
    if (search) {
      const q = search.toLowerCase();
      const match = e.nomEcart?.toLowerCase().includes(q)
        || e.numero?.toLowerCase().includes(q)
        || e.description?.toLowerCase().includes(q)
        || e.analyseCauses?.toLowerCase().includes(q)
        || e.actionsCorrectives?.toLowerCase().includes(q);
      if (!match) return false;
    }
    if (filterService && e.service?.code !== filterService) return false;
    if (filterStatut && e.statut !== filterStatut) return false;
    if (filterClassif && e.classification !== filterClassif) return false;
    if (filterMacroEcart && String(e.macroEcartId) !== filterMacroEcart) return false;
    if (filterDateFrom && e.dateFinalisation && e.dateFinalisation < filterDateFrom) return false;
    if (filterDateTo && e.dateFinalisation && e.dateFinalisation > filterDateTo) return false;
    return true;
  });

  const activeFilterCount = [filterService, filterStatut, filterWorkstream, filterCriticite, filterClassif, filterMacroEcart, filterDateFrom, filterDateTo].filter(Boolean).length;

  function clearAllFilters() {
    setFilterService(""); setFilterStatut(""); setFilterWorkstream(""); setFilterCriticite("");
    setFilterClassif(""); setFilterMacroEcart(""); setFilterDateFrom(""); setFilterDateTo("");
    setSearch("");
  }

  // ---------- Form Helpers ----------
  function resetForm() {
    setFWorkstream(""); setFDescription(""); setFDeadline(""); setFDeadlineRev("");
    setFStatut("En cours"); setFImportance(1); setFUrgence(1); setFAvancement(0);
    setFCommentaires(""); setFResponsables([]); setFNewComment("");
    setFNumero(""); setFNomEcart(""); setFEcartDesc(""); setFMacroEcart(""); setFServiceId("");
    setFClassif("Mineure"); setFEcartStatut("EN_COURS"); setFPctAvanc(0);
    setFCauses(""); setFCorrectives(""); setFBloquants(""); setFDocsRef("");
    setFDateFinal(""); setFProba(1); setFImpact(1); setFCommentAvanc("");
    setExistingFiles([]); setEditId(null);
  }

  function openCreate() {
    resetForm();
    setFormMode("create");
    setModalOpen(true);
  }

  function openEdit(item: any) {
    setFormMode("edit");
    setEditId(item.id);
    if (view === "actions") {
      setFWorkstream(String(item.workstreamId));
      setFDescription(item.description);
      setFDeadline(item.deadlineInitiale || "");
      setFDeadlineRev(item.deadlineRevisee || "");
      setFStatut(item.statut);
      setFImportance(item.importance || 1);
      setFUrgence(item.urgence || 1);
      setFAvancement(item.avancement || 0);
      setFCommentaires(item.commentaires || "");
      setFResponsables(item.responsables?.map((r: any) => r.userId) || []);
      setExistingFiles(item.attachments || []);
    } else {
      setFNumero(item.numero);
      setFNomEcart(item.nomEcart);
      setFEcartDesc(item.description);
      setFMacroEcart(String(item.macroEcartId));
      setFServiceId(String(item.serviceId));
      setFClassif(item.classification);
      setFEcartStatut(item.statut);
      setFPctAvanc(item.pctAvancement || 0);
      setFCauses(item.analyseCauses || "");
      setFCorrectives(item.actionsCorrectives || "");
      setFBloquants(item.pointsBloquants || "");
      setFDocsRef(item.documentsReference || "");
      setFDateFinal(item.dateFinalisation || "");
      setFProba(item.probabilite || 1);
      setFImpact(item.impact || 1);
      setFCommentAvanc(item.commentaireAvancement || "");
      setExistingFiles(item.attachments || []);
    }
    setFNewComment("");
    setModalOpen(true);
  }

  async function handleSave() {
    setSaving(true);
    try {
      const method = formMode === "create" ? "POST" : "PUT";
      let payload: any;

      if (view === "actions") {
        payload = {
          type: "action",
          ...(formMode === "edit" && { id: editId }),
          workstreamId: fWorkstream,
          description: fDescription,
          deadlineInitiale: fDeadline,
          deadlineRevisee: fDeadlineRev || null,
          statut: fStatut,
          importance: fImportance,
          urgence: fUrgence,
          avancement: fAvancement,
          commentaires: fCommentaires,
          responsableIds: fResponsables,
          ...(fNewComment && { newComment: fNewComment, commentUserId: fResponsables[0] || 1 }),
        };
      } else {
        payload = {
          type: "ecart",
          ...(formMode === "edit" && { id: editId }),
          numero: fNumero,
          nomEcart: fNomEcart,
          description: fEcartDesc,
          macroEcartId: fMacroEcart,
          serviceId: fServiceId,
          classification: fClassif,
          statut: fEcartStatut,
          pctAvancement: fPctAvanc,
          analyseCauses: fCauses,
          actionsCorrectives: fCorrectives,
          pointsBloquants: fBloquants,
          documentsReference: fDocsRef,
          dateFinalisation: fDateFinal,
          probabilite: fProba,
          impact: fImpact,
          commentaireAvancement: fCommentAvanc,
          ...(fNewComment && { newComment: fNewComment, commentUserId: 1 }),
        };
      }

      const res = await fetch("/api/saisie", {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (res.ok) {
        setModalOpen(false);
        resetForm();
        fetchData();
      }
    } finally {
      setSaving(false);
    }
  }

  async function handleFileUpload(file: File) {
    if (!editId) return;
    const formData = new FormData();
    formData.append("file", file);
    formData.append("uploadedById", "1");
    if (view === "actions") formData.append("actionId", String(editId));
    else formData.append("ecartId", String(editId));

    const res = await fetch("/api/attachments", { method: "POST", body: formData });
    if (res.ok) {
      const att = await res.json();
      setExistingFiles(prev => [...prev, att]);
    }
  }

  if (loading || !ref) return <div className="p-8 text-white/40">Chargement du module de saisie...</div>;

  return (
    <div className="p-6 space-y-5">
      {/* ========== TOOLBAR ========== */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex gap-2">
          <button onClick={() => setView("actions")} className={`px-4 py-2 rounded-lg text-sm font-semibold border transition-all ${view === "actions" ? "bg-[#0089D0]/10 border-[#0089D0]/25 text-[#0089D0]" : "border-white/[0.08] text-white/50 hover:border-white/[0.15]"}`}>
            📋 Actions AFM
          </button>
          <button onClick={() => setView("ecarts")} className={`px-4 py-2 rounded-lg text-sm font-semibold border transition-all ${view === "ecarts" ? "bg-[#0089D0]/10 border-[#0089D0]/25 text-[#0089D0]" : "border-white/[0.08] text-white/50 hover:border-white/[0.15]"}`}>
            🛡️ Écarts OMS
          </button>
        </div>
        <button onClick={openCreate} className="flex items-center gap-2 rounded-lg bg-[#0089D0] px-4 py-2.5 text-sm font-semibold text-white hover:bg-[#0089D0]/80 transition-colors">
          <Plus className="h-4 w-4" /> {view === "actions" ? "Nouvelle Action" : "Nouvel Écart"}
        </button>
      </div>

      {/* ========== FILTERS ========== */}
      <div className="space-y-3">
        {/* Row 1: Search + Service + Statut + Toggle more */}
        <div className="flex gap-3 flex-wrap items-center">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-white/30" />
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Rechercher par description, numéro, chrono..." className="w-full rounded-lg border border-white/[0.08] bg-white/[0.04] pl-9 pr-3 py-2 text-sm text-white/80 placeholder:text-white/30 focus:border-[#0089D0]/30 focus:outline-none" />
          </div>

          <select value={filterService} onChange={e => setFilterService(e.target.value)} className="filter-select">
            <option value="">🏢 Tous services</option>
            {ref.services.map(s => <option key={s.id} value={s.code}>{s.code} — {s.libelle}</option>)}
          </select>

          <select value={filterStatut} onChange={e => setFilterStatut(e.target.value)} className="filter-select">
            <option value="">📊 Tous statuts</option>
            {(view === "actions" ? actionStatuts : ecartStatuts).map(s => <option key={s} value={s}>{STATUT_LABELS[s] || s}</option>)}
          </select>

          <button
            onClick={() => setShowAllFilters(!showAllFilters)}
            className={`flex items-center gap-1.5 rounded-lg border px-3 py-2 text-sm transition-all ${showAllFilters ? "border-[#0089D0]/25 bg-[#0089D0]/10 text-[#0089D0]" : "border-white/[0.08] bg-white/[0.04] text-white/50 hover:border-white/[0.15]"}`}
          >
            <Filter className="h-3.5 w-3.5" />
            Filtres
            {activeFilterCount > 0 && (
              <span className="flex h-4.5 min-w-4.5 items-center justify-center rounded-full bg-[#0089D0] px-1 text-[10px] font-bold text-white">{activeFilterCount}</span>
            )}
            <ChevronDown className={`h-3 w-3 transition-transform ${showAllFilters ? "rotate-180" : ""}`} />
          </button>

          {activeFilterCount > 0 && (
            <button onClick={clearAllFilters} className="flex items-center gap-1 rounded-lg px-2.5 py-2 text-xs text-white/40 hover:text-[#E74C3C] transition-colors">
              <X className="h-3 w-3" /> Effacer tout
            </button>
          )}
        </div>

        {/* Row 2: Advanced filters (collapsible) */}
        {showAllFilters && (
          <div className="flex gap-3 flex-wrap items-center rounded-xl border border-white/[0.06] bg-white/[0.02] p-3">
            {view === "actions" && (
              <>
                <select value={filterWorkstream} onChange={e => setFilterWorkstream(e.target.value)} className="filter-select">
                  <option value="">📂 Tous workstreams</option>
                  {ref.workstreams.filter(w => actionWsIds.includes(w.id)).map(w => (
                    <option key={w.id} value={w.id}>{w.code} — {w.libelle} ({(ref?.actions || []).filter((a: any) => a.workstreamId === w.id).length})</option>
                  ))}
                </select>

                <select value={filterCriticite} onChange={e => setFilterCriticite(e.target.value)} className="filter-select">
                  <option value="">⚠️ Toutes criticités</option>
                  {actionCriticites.map(c => (
                    <option key={c} value={c}>{c} ({(ref?.actions || []).filter((a: any) => a.niveauCriticite === c).length})</option>
                  ))}
                </select>
              </>
            )}

            {view === "ecarts" && (
              <>
                <select value={filterClassif} onChange={e => setFilterClassif(e.target.value)} className="filter-select">
                  <option value="">🏷️ Toutes classifications</option>
                  {ecartClassifs.map(c => (
                    <option key={c} value={c}>{c} ({(ref?.ecarts || []).filter((e: any) => e.classification === c).length})</option>
                  ))}
                </select>

                <select value={filterMacroEcart} onChange={e => setFilterMacroEcart(e.target.value)} className="filter-select">
                  <option value="">📋 Tous macro-écarts</option>
                  {ref.macroEcarts.map(m => (
                    <option key={m.id} value={m.id}>{m.numero} — {m.description.substring(0, 30)} ({(ref?.ecarts || []).filter((e: any) => e.macroEcartId === m.id).length})</option>
                  ))}
                </select>
              </>
            )}

            <div className="flex items-center gap-2">
              <span className="text-[10px] text-white/30 uppercase tracking-wider">Du</span>
              <input type="date" value={filterDateFrom} onChange={e => setFilterDateFrom(e.target.value)} className="filter-select !w-auto" />
              <span className="text-[10px] text-white/30 uppercase tracking-wider">Au</span>
              <input type="date" value={filterDateTo} onChange={e => setFilterDateTo(e.target.value)} className="filter-select !w-auto" />
            </div>
          </div>
        )}
      </div>

      {/* ========== STATS BAR ========== */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {view === "actions" ? (() => {
          const all = ref.actions;
          const enCours = all.filter((a: any) => ["EN_COURS", "En cours"].includes(a.statut)).length;
          const enRetard = all.filter((a: any) => ["EN_RETARD", "En retard"].includes(a.statut)).length;
          const clotures = all.filter((a: any) => ["CLOTURE", "Clôturé"].includes(a.statut)).length;
          return <>
            <MiniStat label="Total" value={all.length} color="#0089D0" />
            <MiniStat label="En cours" value={enCours} color="#FFD500" />
            <MiniStat label="En retard" value={enRetard} color="#E74C3C" />
            <MiniStat label="Clôturées" value={clotures} color="#27AE60" />
          </>;
        })() : (() => {
          const all = ref.ecarts;
          return <>
            <MiniStat label="Total" value={all.length} color="#0089D0" />
            <MiniStat label="En cours" value={all.filter((e: any) => e.statut === "EN_COURS").length} color="#FFD500" />
            <MiniStat label="Revus" value={all.filter((e: any) => e.statut === "REVU").length} color="#EF7A16" />
            <MiniStat label="Clôturés" value={all.filter((e: any) => e.statut === "CLOTURE").length} color="#27AE60" />
          </>;
        })()}
      </div>

      {/* Résultat du filtrage */}
      {activeFilterCount > 0 && (
        <div className="text-sm text-white/55">
          {view === "actions" ? filteredActions.length : filteredEcarts.length} résultat(s) sur {view === "actions" ? ref.actions.length : ref.ecarts.length} — {activeFilterCount} filtre(s) actif(s)
        </div>
      )}

      {/* ========== TABLE ========== */}
      <Card className="glass overflow-hidden">
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            {view === "actions" ? (
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-white/[0.06]">
                    <th className="py-3 px-4 text-left text-[11px] uppercase tracking-wider text-white/55 font-bold">Chrono</th>
                    <th className="py-3 px-4 text-left text-[11px] uppercase tracking-wider text-white/55 font-bold">Description</th>
                    <th className="py-3 px-4 text-left text-[11px] uppercase tracking-wider text-white/55 font-bold">WS</th>
                    <th className="py-3 px-4 text-left text-[11px] uppercase tracking-wider text-white/55 font-bold">Responsable(s)</th>
                    <th className="py-3 px-4 text-center text-[11px] uppercase tracking-wider text-white/55 font-bold">Statut</th>
                    <th className="py-3 px-4 text-center text-[11px] uppercase tracking-wider text-white/55 font-bold">I/U</th>
                    <th className="py-3 px-4 text-center text-[11px] uppercase tracking-wider text-white/55 font-bold">Avanc.</th>
                    <th className="py-3 px-4 text-center text-[11px] uppercase tracking-wider text-white/55 font-bold">Deadline</th>
                    <th className="py-3 px-4 text-center text-[11px] uppercase tracking-wider text-white/55 font-bold">💬</th>
                    <th className="py-3 px-4 text-center text-[11px] uppercase tracking-wider text-white/55 font-bold">📎</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredActions.map((a: any) => (
                    <tr key={a.id} onClick={() => openEdit(a)} className="border-b border-white/[0.04] hover:bg-white/[0.03] cursor-pointer transition-colors">
                      <td className="py-3 px-4 font-mono text-xs text-[#0089D0]">{a.chronoAuto || `#${a.chronoLegacy || a.id}`}</td>
                      <td className="py-3 px-4 text-white/80 max-w-[300px] truncate">{a.description}</td>
                      <td className="py-3 px-4"><Badge className="bg-white/[0.06] text-white/50 text-[10px]">{a.workstream?.code}</Badge></td>
                      <td className="py-3 px-4 text-xs text-white/50">{a.responsables?.map((r: any) => r.user.name).join(", ") || "—"}</td>
                      <td className="py-3 px-4 text-center"><Badge className={statusColor(a.statut)}>{a.statut}</Badge></td>
                      <td className="py-3 px-4 text-center text-xs">
                        <span className={`font-bold ${(a.importance || 1) * (a.urgence || 1) >= 15 ? "text-[#E74C3C]" : (a.importance || 1) * (a.urgence || 1) >= 8 ? "text-[#EF7A16]" : "text-white/40"}`}>
                          {a.importance || 1}/{a.urgence || 1}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <div className="flex items-center gap-1.5 justify-center">
                          <div className="w-12 h-1.5 rounded-full bg-white/[0.06] overflow-hidden">
                            <div className="h-full rounded-full" style={{ width: `${a.avancement}%`, background: a.avancement >= 80 ? "#27AE60" : a.avancement >= 40 ? "#FFD500" : "#E74C3C" }} />
                          </div>
                          <span className="text-xs text-white/50">{a.avancement}%</span>
                        </div>
                      </td>
                      <td className="py-3 px-4 text-center text-xs text-white/40 font-mono">{a.deadlineInitiale ? new Date(a.deadlineInitiale).toLocaleDateString("fr-FR", { day: "2-digit", month: "2-digit" }) : "—"}</td>
                      <td className="py-3 px-4 text-center text-xs text-white/30">{a._count?.comments || 0}</td>
                      <td className="py-3 px-4 text-center text-xs text-white/30">{a._count?.attachments || 0}</td>
                    </tr>
                  ))}
                  {filteredActions.length === 0 && (
                    <tr><td colSpan={10} className="py-12 text-center text-white/30">Aucune action trouvée</td></tr>
                  )}
                </tbody>
              </table>
            ) : (
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-white/[0.06]">
                    <th className="py-3 px-4 text-left text-[11px] uppercase tracking-wider text-white/55 font-bold">N°</th>
                    <th className="py-3 px-4 text-left text-[11px] uppercase tracking-wider text-white/55 font-bold">Écart</th>
                    <th className="py-3 px-4 text-left text-[11px] uppercase tracking-wider text-white/55 font-bold">Service</th>
                    <th className="py-3 px-4 text-center text-[11px] uppercase tracking-wider text-white/55 font-bold">Class.</th>
                    <th className="py-3 px-4 text-center text-[11px] uppercase tracking-wider text-white/55 font-bold">Statut</th>
                    <th className="py-3 px-4 text-center text-[11px] uppercase tracking-wider text-white/55 font-bold">RIV</th>
                    <th className="py-3 px-4 text-center text-[11px] uppercase tracking-wider text-white/55 font-bold">Avanc.</th>
                    <th className="py-3 px-4 text-center text-[11px] uppercase tracking-wider text-white/55 font-bold">Date Final.</th>
                    <th className="py-3 px-4 text-center text-[11px] uppercase tracking-wider text-white/55 font-bold">💬</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredEcarts.map((e: any) => (
                    <tr key={e.id} onClick={() => openEdit(e)} className="border-b border-white/[0.04] hover:bg-white/[0.03] cursor-pointer transition-colors">
                      <td className="py-3 px-4 font-mono text-xs text-[#0089D0]">{e.numero}</td>
                      <td className="py-3 px-4 text-white/80 max-w-[250px] truncate">{e.nomEcart}</td>
                      <td className="py-3 px-4"><Badge className="bg-white/[0.06] text-white/50 text-[10px]">{e.service?.code}</Badge></td>
                      <td className="py-3 px-4 text-center"><Badge className={e.classification === "Majeure" ? "bg-[#E74C3C]/15 text-[#E74C3C]" : "bg-white/[0.06] text-white/40"}>{e.classification}</Badge></td>
                      <td className="py-3 px-4 text-center"><Badge className={statusColor(e.statut)}>{e.statut}</Badge></td>
                      <td className="py-3 px-4 text-center text-xs">
                        {e.scoreRiv ? <Badge className={`${e.scoreRiv === "Critical" ? "bg-[#E74C3C]/15 text-[#E74C3C]" : e.scoreRiv === "High" ? "bg-[#EF7A16]/15 text-[#EF7A16]" : "bg-white/[0.06] text-white/40"}`}>{e.scoreRiv}</Badge> : "—"}
                      </td>
                      <td className="py-3 px-4 text-center">
                        <div className="flex items-center gap-1.5 justify-center">
                          <div className="w-12 h-1.5 rounded-full bg-white/[0.06] overflow-hidden">
                            <div className="h-full rounded-full" style={{ width: `${e.pctAvancement}%`, background: e.pctAvancement >= 80 ? "#27AE60" : "#FFD500" }} />
                          </div>
                          <span className="text-xs text-white/50">{e.pctAvancement}%</span>
                        </div>
                      </td>
                      <td className="py-3 px-4 text-center text-xs text-white/40 font-mono">{e.dateFinalisation || "—"}</td>
                      <td className="py-3 px-4 text-center text-xs text-white/30">{e._count?.comments || 0}</td>
                    </tr>
                  ))}
                  {filteredEcarts.length === 0 && (
                    <tr><td colSpan={9} className="py-12 text-center text-white/30">Aucun écart trouvé</td></tr>
                  )}
                </tbody>
              </table>
            )}
          </div>
        </CardContent>
      </Card>

      {/* ========== MODAL FORMULAIRE ========== */}
      <Dialog open={modalOpen} onOpenChange={v => { if (!v) { setModalOpen(false); resetForm(); } }}>
        <DialogContent className="bg-[#031A40] border-white/[0.08] text-white max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-white text-lg flex items-center gap-2">
              {formMode === "create" ? <Plus className="h-5 w-5 text-[#0089D0]" /> : <Edit3 className="h-5 w-5 text-[#EF7A16]" />}
              {formMode === "create" ? (view === "actions" ? "Nouvelle Action AFM" : "Nouvel Écart OMS") : (view === "actions" ? "Modifier Action AFM" : "Modifier Écart OMS")}
              {formMode === "edit" && <Badge className="ml-2 bg-[#EF7A16]/15 text-[#EF7A16]">#{editId}</Badge>}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-5 mt-2">
            {view === "actions" ? (
              /* ---- ACTION FORM ---- */
              <>
                <div className="grid grid-cols-2 gap-4">
                  <FormField label="Workstream *" required>
                    <div className="flex gap-2">
                      <select value={fWorkstream} onChange={e => setFWorkstream(e.target.value)} className="input-field flex-1">
                        <option value="">Sélectionner...</option>
                        {ref.workstreams.map(w => <option key={w.id} value={w.id}>{w.code} — {w.libelle}</option>)}
                      </select>
                      <EntityCreator type="workstream" onCreated={(ws) => { ref.workstreams.push(ws); setFWorkstream(String(ws.id)); fetchData(); }} />
                    </div>
                  </FormField>
                  <FormField label="Statut">
                    <select value={fStatut} onChange={e => {
                      const v = e.target.value;
                      setFStatut(v);
                      if (["Clôturé", "CLOTURE"].includes(v)) setFAvancement(100);
                    }} className="input-field">
                      {ACTION_STATUTS.map(s => <option key={s} value={s}>{STATUT_LABELS[s] || s}</option>)}
                    </select>
                  </FormField>
                </div>

                <FormField label="Description (QUOI) *" required>
                  <textarea value={fDescription} onChange={e => setFDescription(e.target.value)} rows={3} className="input-field" placeholder="Description détaillée de l'action..." />
                </FormField>

                <div className="grid grid-cols-2 gap-4">
                  <FormField label="Deadline initiale (QUAND)">
                    <input type="date" value={fDeadline} onChange={e => setFDeadline(e.target.value)} className="input-field" />
                  </FormField>
                  <FormField label="Deadline révisée">
                    <input type="date" value={fDeadlineRev} onChange={e => setFDeadlineRev(e.target.value)} className="input-field" />
                  </FormField>
                </div>

                <FormField label="Responsable(s) (QUI)">
                  <div className="space-y-2">
                    <select onChange={e => {
                      const uid = parseInt(e.target.value);
                      if (uid && !fResponsables.includes(uid)) setFResponsables([...fResponsables, uid]);
                      e.target.value = "";
                    }} className="input-field">
                      <option value="">Ajouter un responsable...</option>
                      {ref.users.map(u => <option key={u.id} value={u.id}>{u.name} ({u.service || "N/A"})</option>)}
                    </select>
                    {fResponsables.length > 0 && (
                      <div className="flex flex-wrap gap-1.5">
                        {fResponsables.map(uid => {
                          const u = ref.users.find(x => x.id === uid);
                          return (
                            <Badge key={uid} className="bg-[#0089D0]/10 text-[#0089D0] gap-1 pr-1">
                              {u?.name}
                              <button onClick={() => setFResponsables(fResponsables.filter(x => x !== uid))} className="ml-1 hover:text-white"><X className="h-3 w-3" /></button>
                            </Badge>
                          );
                        })}
                      </div>
                    )}
                  </div>
                </FormField>

                <div className="grid grid-cols-2 gap-4">
                  <FormField label="Avancement (%)">
                    <div className="flex items-center gap-3">
                      <input type="range" min={0} max={100} step={5} value={fAvancement} onChange={e => setFAvancement(parseInt(e.target.value))} className="flex-1 accent-[#0089D0]" />
                      <span className="text-sm font-bold text-white w-12 text-right">{fAvancement}%</span>
                    </div>
                  </FormField>
                  <FormField label="Matrice Importance / Urgence">
                    <ImportanceUrgenceMatrix importance={fImportance} urgence={fUrgence} onChange={(i, u) => { setFImportance(i); setFUrgence(u); }} />
                  </FormField>
                </div>

                <FormField label="Commentaires / Observations">
                  <textarea value={fCommentaires} onChange={e => setFCommentaires(e.target.value)} rows={2} className="input-field" placeholder="Points bloquants, observations..." />
                </FormField>
              </>
            ) : (
              /* ---- ECART FORM ---- */
              <>
                <div className="grid grid-cols-3 gap-4">
                  <FormField label="N° Écart *" required>
                    <input value={fNumero} onChange={e => setFNumero(e.target.value)} className="input-field" placeholder="Ex: 2.1.3.a" />
                  </FormField>
                  <FormField label="Service *" required>
                    <div className="flex gap-2">
                      <select value={fServiceId} onChange={e => setFServiceId(e.target.value)} className="input-field flex-1">
                        <option value="">Sélectionner...</option>
                        {ref.services.map(s => <option key={s.id} value={s.id}>{s.code} — {s.libelle}</option>)}
                      </select>
                      <EntityCreator type="service" onCreated={(svc) => { ref.services.push(svc); setFServiceId(String(svc.id)); fetchData(); }} />
                    </div>
                  </FormField>
                  <FormField label="Macro-Écart parent">
                    <div className="flex gap-2">
                      <select value={fMacroEcart} onChange={e => setFMacroEcart(e.target.value)} className="input-field flex-1">
                        <option value="">Sélectionner...</option>
                        {ref.macroEcarts.map(m => <option key={m.id} value={m.id}>{m.numero} — {m.description.substring(0, 35)}</option>)}
                      </select>
                      <EntityCreator type="macroEcart" onCreated={(me) => { ref.macroEcarts.push(me); setFMacroEcart(String(me.id)); fetchData(); }} />
                    </div>
                  </FormField>
                </div>

                <FormField label="Nom de l'écart *" required>
                  <input value={fNomEcart} onChange={e => setFNomEcart(e.target.value)} className="input-field" placeholder="Intitulé de l'écart..." />
                </FormField>

                <FormField label="Description détaillée">
                  <textarea value={fEcartDesc} onChange={e => setFEcartDesc(e.target.value)} rows={3} className="input-field" placeholder="Description complète de l'écart identifié..." />
                </FormField>

                <div className="grid grid-cols-3 gap-4">
                  <FormField label="Classification">
                    <select value={fClassif} onChange={e => setFClassif(e.target.value)} className="input-field">
                      {ECART_CLASSIFICATIONS.map(c => <option key={c}>{c}</option>)}
                    </select>
                  </FormField>
                  <FormField label="Statut">
                    <select value={fEcartStatut} onChange={e => {
                      const v = e.target.value;
                      setFEcartStatut(v);
                      if (v === "CLOTURE") setFPctAvanc(100);
                    }} className="input-field">
                      {ECART_STATUTS.map(s => <option key={s} value={s}>{STATUT_LABELS[s] || s}</option>)}
                    </select>
                  </FormField>
                  <FormField label="Date de finalisation">
                    <input type="date" value={fDateFinal} onChange={e => setFDateFinal(e.target.value)} className="input-field" />
                  </FormField>
                </div>

                <FormField label="Avancement (%)">
                  <div className="flex items-center gap-3">
                    <input type="range" min={0} max={100} step={5} value={fPctAvanc} onChange={e => setFPctAvanc(parseInt(e.target.value))} className="flex-1 accent-[#0089D0]" />
                    <span className="text-sm font-bold text-white w-12 text-right">{fPctAvanc}%</span>
                  </div>
                </FormField>

                <FormField label="Analyse des causes (Root Cause)">
                  <textarea value={fCauses} onChange={e => setFCauses(e.target.value)} rows={2} className="input-field" placeholder="Analyse des causes racines..." />
                </FormField>

                <FormField label="Actions correctives / préventives (CAPA)">
                  <textarea value={fCorrectives} onChange={e => setFCorrectives(e.target.value)} rows={2} className="input-field" placeholder="Actions correctives et préventives mises en œuvre..." />
                </FormField>

                <FormField label="Points bloquants">
                  <textarea value={fBloquants} onChange={e => setFBloquants(e.target.value)} rows={2} className="input-field" placeholder="Points bloquants identifiés..." />
                </FormField>

                <div className="grid grid-cols-2 gap-4">
                  <FormField label="Documents de référence">
                    <input value={fDocsRef} onChange={e => setFDocsRef(e.target.value)} className="input-field" placeholder="Procédures, SOP, liens..." />
                  </FormField>
                  <FormField label="Matrice de Risque (Probabilité / Impact)">
                    <ImportanceUrgenceMatrix importance={fImpact} urgence={fProba} onChange={(imp, urg) => { setFImpact(imp); setFProba(urg); }} />
                  </FormField>
                </div>

                <FormField label="Commentaire d'avancement">
                  <textarea value={fCommentAvanc} onChange={e => setFCommentAvanc(e.target.value)} rows={2} className="input-field" placeholder="Dernières avancées, prochaines étapes..." />
                </FormField>
              </>
            )}

            {/* ---- COMMENTS SECTION (edit mode) ---- */}
            {formMode === "edit" && (
              <div className="border-t border-white/[0.06] pt-4 space-y-3">
                <h4 className="text-sm font-semibold text-white/60 flex items-center gap-2"><MessageSquare className="h-4 w-4" /> Historique des commentaires</h4>
                {(() => {
                  const item = view === "actions"
                    ? ref.actions.find((a: any) => a.id === editId)
                    : ref.ecarts.find((e: any) => e.id === editId);
                  const comments = item?.comments || [];
                  return comments.length > 0 ? (
                    <div className="space-y-2 max-h-32 overflow-y-auto">
                      {comments.map((c: any, i: number) => (
                        <div key={i} className="rounded-lg bg-white/[0.03] border border-white/[0.06] p-2.5 text-xs">
                          <div className="flex items-center justify-between text-white/30 mb-1">
                            <span className="font-semibold text-white/50">{c.createdBy?.name}</span>
                            <span>{c.semaineIso}</span>
                          </div>
                          <p className="text-white/60">{c.texte}</p>
                        </div>
                      ))}
                    </div>
                  ) : <p className="text-xs text-white/30">Aucun commentaire</p>;
                })()}
                <textarea value={fNewComment} onChange={e => setFNewComment(e.target.value)} rows={2} className="input-field" placeholder="Ajouter un nouveau commentaire pour cette semaine..." />
              </div>
            )}

            {/* ---- FILE UPLOAD (edit mode) ---- */}
            {formMode === "edit" && (
              <div className="border-t border-white/[0.06] pt-4">
                <h4 className="text-sm font-semibold text-white/60 flex items-center gap-2 mb-3"><Paperclip className="h-4 w-4" /> Justificatifs</h4>
                <FileDropzone onUpload={handleFileUpload} existingFiles={existingFiles} />
              </div>
            )}

            {/* ---- SAVE ---- */}
            <div className="flex justify-end gap-3 pt-3 border-t border-white/[0.06]">
              <button onClick={() => { setModalOpen(false); resetForm(); }} className="px-4 py-2 rounded-lg border border-white/[0.08] text-white/50 text-sm hover:bg-white/[0.04] transition-colors">
                Annuler
              </button>
              <button onClick={handleSave} disabled={saving} className="flex items-center gap-2 px-5 py-2 rounded-lg bg-[#0089D0] text-white text-sm font-semibold hover:bg-[#0089D0]/80 transition-colors disabled:opacity-50">
                <Save className="h-4 w-4" /> {saving ? "Enregistrement..." : formMode === "create" ? "Créer" : "Enregistrer"}
              </button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* inline styles for form fields */}
      <style jsx global>{`
        .input-field {
          width: 100%;
          border-radius: 8px;
          border: 1px solid rgba(255,255,255,0.10);
          background: rgba(255,255,255,0.05);
          padding: 10px 14px;
          font-size: 15px;
          color: rgba(255,255,255,0.9);
          transition: border-color 0.2s;
          font-family: var(--font-sans);
          line-height: 1.5;
        }
        .input-field:focus {
          outline: none;
          border-color: rgba(0,137,208,0.4);
          background: rgba(255,255,255,0.07);
        }
        .input-field::placeholder {
          color: rgba(255,255,255,0.35);
        }
        .input-field option, .filter-select option {
          background: #031A40;
          color: rgba(255,255,255,0.9);
          font-size: 14px;
        }
        .filter-select {
          border-radius: 8px;
          border: 1px solid rgba(255,255,255,0.10);
          background: rgba(255,255,255,0.05);
          padding: 10px 14px;
          font-size: 14px;
          color: rgba(255,255,255,0.8);
          transition: border-color 0.2s;
          font-family: var(--font-sans);
          min-width: 160px;
        }
        .filter-select:focus {
          outline: none;
          border-color: rgba(0,137,208,0.4);
        }
      `}</style>
    </div>
  );
}

// ---------- Sub-components ----------
function FormField({ label, required, children }: { label: string; required?: boolean; children: React.ReactNode }) {
  return (
    <div>
      <label className="block text-[12px] text-white/55 mb-2 font-semibold uppercase tracking-wider">
        {label}
      </label>
      {children}
    </div>
  );
}

function MiniStat({ label, value, color }: { label: string; value: number; color: string }) {
  return (
    <div className="rounded-lg border border-white/[0.06] bg-white/[0.03] px-4 py-3.5 flex items-center justify-between">
      <span className="text-sm text-white/55 font-medium">{label}</span>
      <span className="text-xl font-bold" style={{ color }}>{value}</span>
    </div>
  );
}
