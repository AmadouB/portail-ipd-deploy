"use client";

import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CalendarDays, Wrench, AlertTriangle, MessageSquare } from "lucide-react";

const PLAN = [
  { id: 1, a: "Contrôles environnement locaux", d: "2026-01-19", f: "2026-01-30", p: 100, s: "Fait" },
  { id: 2, a: "Incubation VPA 1", d: "2026-01-30", f: "", p: 100, s: "Fait" },
  { id: 3, a: "Inoculation VPA1 / Incubation VPA2", d: "2026-02-06", f: "2026-02-20", p: 100, s: "Fait" },
  { id: 4, a: "Récolte VPA 1", d: "2026-02-10", f: "2026-02-24", p: 80, s: "En cours" },
  { id: 5, a: "MFT1 Excipient 1", d: "2026-02-12", f: "2026-03-04", p: 80, s: "En cours" },
  { id: 6, a: "MFT1 Vaccin (QP CCIT)", d: "2026-03-04", f: "2026-03-23", p: 0, s: "Non démarré" },
  { id: 7, a: "MFT2 Vaccin", d: "2026-03-09", f: "2026-04-03", p: 0, s: "Non démarré" },
  { id: 8, a: "MFT3 Vaccin", d: "2026-03-12", f: "2026-04-08", p: 0, s: "Non démarré" },
];

const EQUIP = [
  { id: 1, n: "Isolateur Bioquell – Maintenance", s: "Clôturée", p: 100, comment: "" },
  { id: 2, n: "Réglages pressions CQVM/SMS", s: "En cours", p: 60, comment: "HVAC Conseil contacté" },
  { id: 3, n: "Portes d'accès bâtiment", s: "En cours", p: 80, comment: "Livrées, pose 16/02" },
  { id: 4, n: "Fenêtres installées", s: "Clôturée", p: 100, comment: "" },
];

const RISKS = [
  { id: 1, n: "Approvisionnement œufs", c: "Élevé", det: "1 200 œufs/livraison, 1 récolte/semaine", plan: "TC Valo bimensuelle", s: "En cours", col: "#EF7A16" },
  { id: 2, n: "Isolateur", c: "Élevé", det: "Forte dépendance Excipient DS/DP", plan: "Stock pièces critiques", s: "En cours", col: "#EF7A16" },
  { id: 3, n: "HVAC", c: "Très Critique", det: "Pressions instables ZAC DEV250106", plan: "Audit HVAC Conseil, BC", s: "En cours", col: "#E74C3C" },
];

function StatusBadge({ s }: { s: string }) {
  const colors: Record<string, string> = {
    Fait: "bg-[#27AE60]/15 text-[#27AE60]", Clôturée: "bg-[#27AE60]/15 text-[#27AE60]",
    "En cours": "bg-[#FFD500]/15 text-[#FFD500]", "Non démarré": "bg-white/[0.06] text-white/40",
    Critique: "bg-[#E74C3C]/15 text-[#E74C3C]",
  };
  return <Badge className={colors[s] || "bg-white/[0.06] text-white/40"}>{s}</Badge>;
}

function ProgressBar({ value, color = "#0089D0" }: { value: number; color?: string }) {
  return (
    <div className="h-2 flex-1 rounded-full bg-white/[0.06] overflow-hidden">
      <div className="h-full rounded-full transition-all duration-700" style={{ width: `${value}%`, background: `linear-gradient(90deg, ${color}, ${color}bb)` }} />
    </div>
  );
}

export function ProductionContent() {
  const [tab, setTab] = useState<"planning" | "equip" | "risques">("planning");
  const tabs = [
    { id: "planning" as const, label: "📅 Planning", icon: CalendarDays },
    { id: "equip" as const, label: "🏗️ Équipements", icon: Wrench },
    { id: "risques" as const, label: "⚠️ Risques", icon: AlertTriangle },
  ];

  return (
    <div className="p-6 space-y-6">
      <div className="flex gap-2 flex-wrap">
        {tabs.map(t => (
          <button key={t.id} onClick={() => setTab(t.id)} className={`px-4 py-2 rounded-lg text-sm font-medium border transition-all ${tab === t.id ? "bg-[#0089D0]/10 border-[#0089D0]/25 text-[#0089D0] font-semibold" : "border-white/[0.08] text-white/50 hover:border-white/[0.15] hover:text-white/70"}`}>
            {t.label}
          </button>
        ))}
      </div>

      {tab === "planning" && (
        <Card className="glass">
          <CardHeader><CardTitle className="text-lg text-white flex items-center gap-2">📅 Planning de Reprise — Validation Procédé</CardTitle></CardHeader>
          <CardContent className="space-y-2">
            {PLAN.map(p => {
              const col = p.p === 100 ? "#27AE60" : p.p > 0 ? "#0089D0" : "#64748b";
              return (
                <div key={p.id} className="grid grid-cols-[2fr_0.8fr_0.8fr_1.2fr_0.7fr] items-center gap-2 p-3 rounded-lg bg-white/[0.02] hover:bg-white/[0.04] transition-all cursor-pointer">
                  <span className="text-sm font-medium text-white/80">{p.a}</span>
                  <span className="text-sm text-white/55">{p.d ? new Date(p.d).toLocaleDateString("fr-FR", { day: "2-digit", month: "2-digit" }) : "—"}</span>
                  <span className="text-sm text-white/55">{p.f ? new Date(p.f).toLocaleDateString("fr-FR", { day: "2-digit", month: "2-digit" }) : "—"}</span>
                  <div className="flex items-center gap-2">
                    <ProgressBar value={p.p} color={col} />
                    <span className="text-xs font-bold text-white/70 w-8">{p.p}%</span>
                  </div>
                  <StatusBadge s={p.s} />
                </div>
              );
            })}
          </CardContent>
        </Card>
      )}

      {tab === "equip" && (
        <Card className="glass">
          <CardHeader><CardTitle className="text-lg text-white">🏗️ Locaux & Équipements</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            {EQUIP.map(e => (
              <div key={e.id} className="rounded-lg border border-white/[0.06] bg-white/[0.02] p-4 hover:bg-white/[0.04] transition-all cursor-pointer">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-white/80">{e.n}</span>
                  <StatusBadge s={e.s} />
                </div>
                <div className="flex items-center gap-2">
                  <ProgressBar value={e.p} color={e.p === 100 ? "#27AE60" : "#0089D0"} />
                  <span className="text-xs font-bold text-white/70">{e.p}%</span>
                </div>
                {e.comment && (
                  <div className="flex items-center gap-1.5 mt-2 text-sm text-white/55">
                    <MessageSquare className="h-3 w-3" /> {e.comment}
                  </div>
                )}
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {tab === "risques" && (
        <div className="space-y-4">
          {RISKS.map(r => (
            <Card key={r.id} className="glass hover:border-white/[0.15] transition-all cursor-pointer" style={{ borderLeft: `4px solid ${r.col}` }}>
              <CardContent className="p-5">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-base font-bold text-white">{r.n}</span>
                  <div className="flex items-center gap-2">
                    <Badge className={`${r.c === "Très Critique" ? "bg-[#E74C3C]/15 text-[#E74C3C]" : "bg-[#EF7A16]/15 text-[#EF7A16]"}`}>{r.c}</Badge>
                    <StatusBadge s={r.s} />
                  </div>
                </div>
                <p className="text-sm text-white/50 mb-2">{r.det}</p>
                <p className="text-sm text-[#0089D0]">➜ {r.plan}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
