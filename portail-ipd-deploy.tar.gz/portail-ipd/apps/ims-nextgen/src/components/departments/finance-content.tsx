"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const FINANCE = [
  { id: 1, i: "Intervention HVAC Conseil", t: "Maintenance", u: "Critique", s: "Chiffrage en cours" },
  { id: 2, i: "BC travaux portes", t: "Infrastructure", u: "Moyen", s: "Envoyés" },
  { id: 3, i: "Pièces détachées critiques", t: "Équipements", u: "Élevé", s: "En cours" },
  { id: 4, i: "Valises outils", t: "Outillage", u: "Faible", s: "À venir" },
  { id: 5, i: "EPI personnel", t: "Sécurité", u: "Faible", s: "À venir" },
];

const URGENCY_COLORS: Record<string, string> = {
  Critique: "#E74C3C",
  "Élevé": "#EF7A16",
  Moyen: "#FFD500",
  Faible: "#64748b",
};

export function FinanceContent() {
  return (
    <div className="p-6 space-y-6">
      <Card className="glass">
        <CardHeader><CardTitle className="text-lg text-white">💰 Suivi Budgétaire</CardTitle></CardHeader>
        <CardContent className="space-y-2">
          {FINANCE.map(f => {
            const uCol = URGENCY_COLORS[f.u] || "#64748b";
            return (
              <div key={f.id} className="flex items-center justify-between p-4 rounded-lg border border-white/[0.06] bg-white/[0.02] cursor-pointer hover:bg-white/[0.04] transition-all">
                <div className="flex-1">
                  <p className="text-sm font-medium text-white/80">{f.i}</p>
                  <p className="text-sm text-white/55 mt-0.5">{f.t}</p>
                </div>
                <div className="flex items-center gap-2">
                  <Badge className="border" style={{ background: `${uCol}15`, color: uCol, borderColor: `${uCol}30` }}>{f.u}</Badge>
                  <Badge className="bg-[#0089D0]/10 text-[#0089D0] border border-[#0089D0]/20">{f.s}</Badge>
                </div>
              </div>
            );
          })}
        </CardContent>
      </Card>

      {/* Résumé budgétaire */}
      <div className="grid grid-cols-3 gap-4">
        <Card className="glass text-center">
          <CardContent className="pt-6">
            <p className="text-sm text-white/55 uppercase tracking-wider">Postes critiques</p>
            <p className="text-3xl font-bold text-[#E74C3C] mt-2">{FINANCE.filter(f => f.u === "Critique").length}</p>
          </CardContent>
        </Card>
        <Card className="glass text-center">
          <CardContent className="pt-6">
            <p className="text-sm text-white/55 uppercase tracking-wider">En cours</p>
            <p className="text-3xl font-bold text-[#0089D0] mt-2">{FINANCE.filter(f => f.s === "En cours" || f.s === "Chiffrage en cours").length}</p>
          </CardContent>
        </Card>
        <Card className="glass text-center">
          <CardContent className="pt-6">
            <p className="text-sm text-white/55 uppercase tracking-wider">Total postes</p>
            <p className="text-3xl font-bold text-white mt-2">{FINANCE.length}</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
