"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { PieChart, Pie, Cell, ResponsiveContainer } from "recharts";

const GAUGES = [
  { v: 87.8, t: 95, l: "Conformité Prod", c: "#EF7A16" },
  { v: 92, t: 97, l: "Conformité LCQ", c: "#0089D0" },
  { v: 90, t: 100, l: "CAPA OMS", c: "#052A62" },
];

const SYSTEMS = [
  { id: 1, s: "Autoclave", st: "Qualification en cours", p: 60 },
  { id: 2, s: "MySIRUS", st: "Validation système", p: 50 },
  { id: 3, s: "Data Matrix", st: "Validation en cours", p: 45 },
  { id: 4, s: "Validation transport", st: "En préparation", p: 20 },
];

function Gauge({ value, target, label, color }: { value: number; target: number; label: string; color: string }) {
  const pct = Math.min((value / target) * 100, 100);
  const data = [{ value: pct }, { value: 100 - pct }];
  return (
    <div className="text-center">
      <div className="relative w-[120px] h-[120px] mx-auto">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie data={data} cx="50%" cy="50%" innerRadius={40} outerRadius={50} startAngle={90} endAngle={-270} dataKey="value" stroke="none">
              <Cell fill={color} />
              <Cell fill="rgba(255,255,255,0.06)" />
            </Pie>
          </PieChart>
        </ResponsiveContainer>
        <div className="absolute inset-0 flex items-center justify-center">
          <span className="text-lg font-black" style={{ color }}>{value}%</span>
        </div>
      </div>
      <p className="text-sm text-white/60 mt-2">{label}</p>
      <p className="text-xs text-white/45">Cible: {target}%</p>
    </div>
  );
}

function ProgressBar({ value, color = "#052A62" }: { value: number; color?: string }) {
  return (
    <div className="h-2 flex-1 rounded-full bg-white/[0.06] overflow-hidden">
      <div className="h-full rounded-full transition-all" style={{ width: `${value}%`, background: color }} />
    </div>
  );
}

export function CqvmContent() {
  return (
    <div className="p-6 space-y-6">
      <Card className="glass">
        <CardHeader><CardTitle className="text-lg text-white">📊 Indicateurs CQVM</CardTitle></CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 gap-6">
            {GAUGES.map((g, i) => (
              <Gauge key={i} value={g.v} target={g.t} label={g.l} color={g.c} />
            ))}
          </div>
        </CardContent>
      </Card>

      <Card className="glass">
        <CardHeader><CardTitle className="text-lg text-white">🔧 Systèmes à Qualifier</CardTitle></CardHeader>
        <CardContent className="space-y-3">
          {SYSTEMS.map(s => (
            <div key={s.id} className="rounded-lg border border-white/[0.06] bg-white/[0.02] p-4 cursor-pointer hover:bg-white/[0.04] transition-all">
              <div className="flex items-center justify-between mb-2 text-sm">
                <span className="font-medium text-white/80">{s.s}</span>
                <span className="text-sm text-white/55">{s.st}</span>
              </div>
              <div className="flex items-center gap-2">
                <ProgressBar value={s.p} color="#052A62" />
                <span className="text-xs font-bold text-white/70">{s.p}%</span>
                <span className={`text-base ${s.p >= 60 ? "" : "text-[#E74C3C]"}`}>{s.p >= 60 ? "😐" : "😞"}</span>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}
