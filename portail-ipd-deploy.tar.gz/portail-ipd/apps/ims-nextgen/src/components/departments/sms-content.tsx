"use client";

import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const ACP = [
  { id: 1, y: "2024", t: 29, d: 25, p: 87 },
  { id: 2, y: "2025", t: 72, d: 60, p: 83 },
];

const EQUIP = [
  { id: 1, n: "Groupe Froid", d: "Commande faite", p: 50 },
  { id: 2, n: "Régulateurs LCQ", d: "En cours", p: 80 },
  { id: 3, n: "CTA (pression ZAC)", d: "HVAC Sem. 11", p: 40 },
  { id: 4, n: "Criticité équipements", d: "Gros éq. faits", p: 85 },
];

const KPIS = [
  { id: "form", l: "Formation Technique", v: 40, icon: "🎓" },
  { id: "outils", l: "Outillage", v: 93, icon: "🔨" },
  { id: "kpi", l: "Tableau de Bord KPI", v: 35, icon: "📊" },
];

function ProgressBar({ value, color = "#0089D0", height = "8px" }: { value: number; color?: string; height?: string }) {
  return (
    <div className="flex-1 rounded-full bg-white/[0.06] overflow-hidden" style={{ height }}>
      <div className="h-full rounded-full transition-all duration-700" style={{ width: `${value}%`, background: `linear-gradient(90deg, ${color}, ${color}bb)` }} />
    </div>
  );
}

export function SmsContent() {
  const [tab, setTab] = useState<"acp" | "equip" | "form" | "outils" | "kpi">("acp");

  return (
    <div className="p-6 space-y-6">
      <div className="flex gap-2 flex-wrap">
        {[
          { id: "acp" as const, label: "📋 ACP" },
          { id: "equip" as const, label: "⚙️ Équip." },
          { id: "form" as const, label: "🎓 Form." },
          { id: "outils" as const, label: "🔨 Outils" },
          { id: "kpi" as const, label: "📊 KPI" },
        ].map(t => (
          <button key={t.id} onClick={() => setTab(t.id)} className={`px-4 py-2 rounded-lg text-sm font-medium border transition-all ${tab === t.id ? "bg-[#0089D0]/10 border-[#0089D0]/25 text-[#0089D0] font-semibold" : "border-white/[0.08] text-white/50 hover:border-white/[0.15]"}`}>
            {t.label}
          </button>
        ))}
      </div>

      {tab === "acp" && (
        <Card className="glass">
          <CardHeader><CardTitle className="text-lg text-white">📋 Actions Correctives & Préventives</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            {ACP.map(a => (
              <div key={a.id} className="rounded-lg border border-white/[0.06] bg-white/[0.02] p-4 cursor-pointer hover:bg-white/[0.04] transition-all">
                <div className="flex items-center justify-between mb-2 text-sm">
                  <span className="font-bold text-white/80">{a.y} : {a.t} ACP</span>
                  <span className="text-white/60">{a.d} clôturées</span>
                </div>
                <div className="flex items-center gap-3">
                  <ProgressBar value={a.p} color={a.p >= 85 ? "#27AE60" : "#FFD500"} height="12px" />
                  <span className="text-lg font-black text-white">{a.p}%</span>
                  <span className="text-xl">{a.p >= 85 ? "😃" : "😐"}</span>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {tab === "equip" && (
        <Card className="glass">
          <CardHeader><CardTitle className="text-lg text-white">⚙️ Équipements</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            {EQUIP.map(e => (
              <div key={e.id} className="rounded-lg border border-white/[0.06] bg-white/[0.02] p-4 cursor-pointer hover:bg-white/[0.04] transition-all">
                <div className="flex items-center justify-between mb-2 text-sm">
                  <span className="font-medium text-white/80">{e.n}</span>
                  <span className="text-sm text-white/55">{e.d}</span>
                </div>
                <div className="flex items-center gap-2">
                  <ProgressBar value={e.p} color={e.p >= 80 ? "#27AE60" : e.p >= 50 ? "#FFD500" : "#E74C3C"} />
                  <span className="text-xs font-bold text-white/70">{e.p}%</span>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {(tab === "form" || tab === "outils" || tab === "kpi") && (() => {
        const k = KPIS.find(x => x.id === tab)!;
        const col = k.v >= 80 ? "#27AE60" : k.v >= 50 ? "#FFD500" : "#E74C3C";
        return (
          <Card className="glass cursor-pointer">
            <CardHeader><CardTitle className="text-lg text-white">{k.icon} {k.l}</CardTitle></CardHeader>
            <CardContent>
              <div className="flex items-center gap-4">
                <ProgressBar value={k.v} color={col} height="14px" />
                <span className="text-xl font-black" style={{ color: col }}>{k.v}%</span>
                <span className="text-2xl">{k.v >= 80 ? "😃" : k.v >= 50 ? "😐" : "😞"}</span>
              </div>
            </CardContent>
          </Card>
        );
      })()}
    </div>
  );
}
