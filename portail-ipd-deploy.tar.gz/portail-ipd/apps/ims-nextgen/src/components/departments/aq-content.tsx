"use client";

import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend } from "recharts";

const WS5M = [
  { id: 1, n: "Milieu/Matériel", t: 23, c: 10 },
  { id: 2, n: "Matière/Méthode", t: 20, c: 3 },
  { id: 3, n: "Mgmt/Main d'œuvre", t: 12, c: 5 },
];

const CAPA_AQ = [
  { id: 1, a: "Configuration fichier suivi", ac: "Babacar Dogue / DDSI", p: 90, dl: "Nouveau délai", s: "En cours", comment: "Attente retour CQVM" },
  { id: 2, a: "Procédure nettoyage/désinfection", ac: "M-L. Tall", p: 100, dl: "Clôturée", s: "Clôturée", comment: "" },
  { id: 3, a: "Instructions production nettoyage", ac: "Djibril", p: 50, dl: "Avant production", s: "En cours", comment: "" },
];

const IR_FICHES = [
  { id: 1, e: "AQ", f: "16 fiches rédigées", rv: "OK", en: "OK" },
  { id: 2, e: "CQ", f: "Transmises", rv: "OK", en: "OK" },
  { id: 3, e: "Production", f: "Transmises", rv: "OK", en: "OK" },
  { id: 4, e: "CQVM", f: "Transmises", rv: "OK", en: "OK" },
  { id: 5, e: "SMS", f: "Transmises", rv: "OK", en: "OK" },
];

const ROUTINE_DATA = [
  { dept: "SMS", d2024: 4, d2025: 10 },
  { dept: "Production", d2024: 0, d2025: 3 },
  { dept: "LCQ", d2024: 2, d2025: 8 },
  { dept: "CQVM", d2024: 0, d2025: 3 },
];

function StatusBadge({ s }: { s: string }) {
  const colors: Record<string, string> = {
    Clôturée: "bg-[#27AE60]/15 text-[#27AE60]", "En cours": "bg-[#FFD500]/15 text-[#FFD500]",
    OK: "bg-[#27AE60]/15 text-[#27AE60]",
  };
  return <Badge className={colors[s] || "bg-white/[0.06] text-white/40"}>{s}</Badge>;
}

function ProgressBar({ value, color = "#0089D0" }: { value: number; color?: string }) {
  return (
    <div className="h-2 flex-1 rounded-full bg-white/[0.06] overflow-hidden">
      <div className="h-full rounded-full transition-all" style={{ width: `${value}%`, background: color }} />
    </div>
  );
}

export function AqContent() {
  const [tab, setTab] = useState<"workshop" | "capa" | "readiness" | "routine">("workshop");

  const totalW = WS5M.reduce((a, w) => a + w.t, 0);
  const closedW = WS5M.reduce((a, w) => a + w.c, 0);
  const pctW = totalW ? Math.round((closedW / totalW) * 100) : 0;

  return (
    <div className="p-6 space-y-6">
      <div className="flex gap-2 flex-wrap">
        {[
          { id: "workshop" as const, label: "🔧 Workshop" },
          { id: "capa" as const, label: "📑 CAPA OMS" },
          { id: "readiness" as const, label: "✅ Readiness" },
          { id: "routine" as const, label: "⏰ Routine" },
        ].map(t => (
          <button key={t.id} onClick={() => setTab(t.id)} className={`px-4 py-2 rounded-lg text-sm font-medium border transition-all ${tab === t.id ? "bg-[#0089D0]/10 border-[#0089D0]/25 text-[#0089D0] font-semibold" : "border-white/[0.08] text-white/50 hover:border-white/[0.15]"}`}>
            {t.label}
          </button>
        ))}
      </div>

      {tab === "workshop" && (
        <div className="space-y-4">
          <Card className="glass">
            <CardContent className="p-5">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-bold text-white">Workshop ZAC – {totalW} Actions</h3>
                <span className={`text-3xl font-black ${pctW < 50 ? "text-[#E74C3C]" : "text-[#FFD500]"}`}>{pctW}%</span>
              </div>
              <div className="space-y-3">
                {WS5M.map(w => {
                  const p = w.t ? Math.round((w.c / w.t) * 100) : 0;
                  return (
                    <div key={w.id} className="rounded-lg border border-white/[0.06] bg-white/[0.02] p-4 cursor-pointer hover:bg-white/[0.04] transition-all">
                      <div className="flex items-center justify-between mb-2 text-sm">
                        <span className="font-medium text-white/80">{w.n}</span>
                        <span className="text-white/60"><b>{w.c}</b>/{w.t} ({p}%)</span>
                      </div>
                      <ProgressBar value={p} color={p > 40 ? "#EF7A16" : "#E74C3C"} />
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
          <Card className="glass">
            <CardHeader><CardTitle className="text-sm text-white/70">Risque CAPA</CardTitle></CardHeader>
            <CardContent>
              <div className="h-[250px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={[{ name: "Élevé", ouvert: 7, cloture: 11 }, { name: "Moyen", ouvert: 22, cloture: 6 }, { name: "Faible", ouvert: 7, cloture: 2 }]}>
                    <XAxis dataKey="name" tick={{ fill: "rgba(255,255,255,0.5)", fontSize: 11 }} />
                    <YAxis tick={{ fill: "rgba(255,255,255,0.4)", fontSize: 11 }} />
                    <Tooltip contentStyle={{ background: "#031A40", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 8, color: "#fff" }} />
                    <Legend wrapperStyle={{ color: "rgba(255,255,255,0.6)", fontSize: 11 }} />
                    <Bar dataKey="ouvert" name="Ouvert" fill="#E74C3C" radius={[6, 6, 0, 0]} />
                    <Bar dataKey="cloture" name="Clôturé" fill="#27AE60" radius={[6, 6, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {tab === "capa" && (
        <Card className="glass">
          <CardHeader><CardTitle className="text-lg text-white">📑 CAPA OMS</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            {CAPA_AQ.map(c => (
              <div key={c.id} className="rounded-lg border border-white/[0.06] bg-white/[0.02] p-4 cursor-pointer hover:bg-white/[0.04] transition-all">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-semibold text-white/80">{c.a}</span>
                  <StatusBadge s={c.s} />
                </div>
                <p className="text-sm text-white/55 mb-2">{c.ac} | {c.dl}</p>
                <div className="flex items-center gap-2">
                  <ProgressBar value={c.p} color={c.p === 100 ? "#27AE60" : "#0089D0"} />
                  <span className="text-xs font-bold text-white/70">{c.p}%</span>
                </div>
                {c.comment && <p className="text-sm text-white/55 mt-2">💬 {c.comment}</p>}
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {tab === "readiness" && (
        <Card className="glass">
          <CardHeader>
            <CardTitle className="text-lg text-white">✅ Inspection Readiness</CardTitle>
            <p className="text-sm text-white/55 mt-1">Délai : 30/04/2026</p>
          </CardHeader>
          <CardContent className="space-y-2">
            {IR_FICHES.map(f => (
              <div key={f.id} className="grid grid-cols-[0.5fr_1.5fr_0.5fr_0.5fr] gap-2 items-center p-3 rounded-lg bg-white/[0.02] hover:bg-white/[0.04] cursor-pointer transition-all">
                <span className="text-sm font-bold text-white/80">{f.e}</span>
                <span className="text-sm text-white/50">{f.f}</span>
                <Badge className={`${f.rv === "OK" ? "bg-[#27AE60]/15 text-[#27AE60]" : "bg-[#FFD500]/15 text-[#FFD500]"}`}>Revue {f.rv}</Badge>
                <Badge className={`${f.en === "OK" ? "bg-[#27AE60]/15 text-[#27AE60]" : "bg-[#FFD500]/15 text-[#FFD500]"}`}>Enreg. {f.en}</Badge>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {tab === "routine" && (
        <Card className="glass">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg text-white">⏰ CAPA Routine</CardTitle>
              <span className="text-sm text-[#27AE60] font-semibold">54→51→49→31 ↓</span>
            </div>
          </CardHeader>
          <CardContent>
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={ROUTINE_DATA}>
                  <XAxis dataKey="dept" tick={{ fill: "rgba(255,255,255,0.5)", fontSize: 11 }} />
                  <YAxis tick={{ fill: "rgba(255,255,255,0.4)", fontSize: 11 }} />
                  <Tooltip contentStyle={{ background: "#031A40", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 8, color: "#fff" }} />
                  <Legend wrapperStyle={{ color: "rgba(255,255,255,0.6)", fontSize: 11 }} />
                  <Bar dataKey="d2024" name="2024" fill="#052A62" radius={[6, 6, 0, 0]} />
                  <Bar dataKey="d2025" name="2025" fill="#E74C3C" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
