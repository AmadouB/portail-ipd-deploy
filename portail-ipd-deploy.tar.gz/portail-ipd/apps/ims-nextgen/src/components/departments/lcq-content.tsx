"use client";

import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { MessageSquare } from "lucide-react";

const H2O2 = [
  { id: 1, n: "Charge 3", det: "QP1/QP2/QP3 Faits – Conformes", p: 100, s: "Conforme" },
  { id: 2, n: "Charge 2", det: "QP1 OK, QP2 : 2/3 conformes", p: 75, s: "En cours" },
  { id: 3, n: "Charge 1 (Excipient)", det: "Non réalisée – CQVM", p: 0, s: "Non démarré" },
  { id: 4, n: "Charge 4 (Œufs)", det: "Non réalisée – CQVM", p: 0, s: "Non démarré" },
];

const PQ_ACTIONS = [
  { id: 1, a: "Réclamation interne", r: "AQ", s: "En cours" },
  { id: 2, a: "Prospection nouveau fournisseur", r: "DAL", s: "Contacts faits" },
  { id: 3, a: "Commande pièces + gants", r: "Supply", s: "En cours" },
];

const CONTAM = [
  { id: 1, z: "VPA 1", op: "Inoculation 06/02", r: "Conforme – J14", s: "Conforme" },
  { id: 2, z: "VPA 2", op: "Récolte 17/02", r: "Conformes J5", s: "Conforme" },
  { id: 3, z: "VPA 3", op: "Inoculation 20/02", r: "Conformes J5", s: "Conforme" },
  { id: 4, z: "MFT 3", op: "Réalisé 18/02", r: "Conformes J5", s: "Conforme" },
];

function StatusBadge({ s }: { s: string }) {
  const colors: Record<string, string> = {
    Conforme: "bg-[#27AE60]/15 text-[#27AE60]", "En cours": "bg-[#FFD500]/15 text-[#FFD500]",
    "Non démarré": "bg-white/[0.06] text-white/40", "Contacts faits": "bg-[#0089D0]/15 text-[#0089D0]",
  };
  return <Badge className={colors[s] || "bg-white/[0.06] text-white/40"}>{s}</Badge>;
}

function ProgressBar({ value, color = "#0089D0" }: { value: number; color?: string }) {
  return (
    <div className="h-2 flex-1 rounded-full bg-white/[0.06] overflow-hidden">
      <div className="h-full rounded-full transition-all duration-700" style={{ width: `${value}%`, background: `linear-gradient(90deg, ${color}, ${color}bb)` }} />
    </div>
  );
}

export function LcqContent() {
  const [tab, setTab] = useState<"h2o2" | "pq" | "contam">("h2o2");

  const avgH2O2 = Math.round(H2O2.reduce((a, c) => a + c.p, 0) / H2O2.length);

  return (
    <div className="p-6 space-y-6">
      <div className="flex gap-2 flex-wrap">
        {[
          { id: "h2o2" as const, label: "🧪 H₂O₂" },
          { id: "pq" as const, label: "🔬 PQ Isolateur" },
          { id: "contam" as const, label: "🦠 Contamination" },
        ].map(t => (
          <button key={t.id} onClick={() => setTab(t.id)} className={`px-4 py-2 rounded-lg text-sm font-medium border transition-all ${tab === t.id ? "bg-[#0089D0]/10 border-[#0089D0]/25 text-[#0089D0] font-semibold" : "border-white/[0.08] text-white/50 hover:border-white/[0.15]"}`}>
            {t.label}
          </button>
        ))}
      </div>

      {tab === "h2o2" && (
        <Card className="glass">
          <CardHeader><CardTitle className="text-lg text-white">🧪 Validation H₂O₂ Airlock</CardTitle></CardHeader>
          <CardContent>
            <div className="flex items-center gap-3 mb-6">
              <ProgressBar value={avgH2O2} color="#052A62" />
              <span className="text-lg font-bold text-white">{avgH2O2}%</span>
            </div>
            <div className="space-y-3">
              {H2O2.map(c => (
                <div key={c.id} className="rounded-lg border border-white/[0.06] bg-white/[0.02] p-4 hover:bg-white/[0.04] cursor-pointer transition-all">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-semibold text-white/80">{c.n}</span>
                    <StatusBadge s={c.s} />
                  </div>
                  <p className="text-sm text-white/55 mb-2">{c.det}</p>
                  <ProgressBar value={c.p} color={c.p === 100 ? "#27AE60" : c.p > 0 ? "#FFD500" : "#64748b"} />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {tab === "pq" && (
        <Card className="glass">
          <CardHeader><CardTitle className="text-lg text-white">🔬 PQ Isolateur</CardTitle></CardHeader>
          <CardContent>
            <div className="rounded-lg bg-[#0089D0]/5 border border-[#0089D0]/15 p-3 mb-4 text-sm text-white/60">
              <b>Rapport :</b> Réception 23/02 – Revue IPD en cours
            </div>
            <div className="space-y-2">
              {PQ_ACTIONS.map(p => (
                <div key={p.id} className="flex items-center justify-between p-3 rounded-lg border border-white/[0.06] bg-white/[0.02] hover:bg-white/[0.04] cursor-pointer transition-all">
                  <span className="text-sm text-white/80">{p.a}</span>
                  <div className="flex items-center gap-2">
                    <Badge className="bg-white/[0.06] text-white/40">{p.r}</Badge>
                    <StatusBadge s={p.s} />
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {tab === "contam" && (
        <Card className="glass">
          <CardHeader><CardTitle className="text-lg text-white">🦠 Surveillance Microbiologique</CardTitle></CardHeader>
          <CardContent>
            <div className="rounded-lg bg-[#27AE60]/5 border border-[#27AE60]/15 p-3 mb-4 text-sm text-[#27AE60]">
              ✅ S9 conformes | VPA 3 conformes
            </div>
            <div className="space-y-2">
              {CONTAM.map(c => (
                <div key={c.id} className="grid grid-cols-[0.5fr_0.8fr_1.2fr_auto] gap-3 items-center p-3 rounded-lg bg-white/[0.02] hover:bg-white/[0.04] cursor-pointer transition-all">
                  <span className="text-sm font-semibold text-white/80">{c.z}</span>
                  <span className="text-sm text-white/55">{c.op}</span>
                  <span className="text-sm text-white/60">{c.r}</span>
                  <StatusBadge s={c.s} />
                </div>
              ))}
            </div>
            <div className="rounded-lg bg-[#E74C3C]/5 border border-[#E74C3C]/15 p-3 mt-4 text-sm text-[#E74C3C]">
              ⚠️ DEV250106 – 15 moisissures SAS IR/RLS 10/02
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
