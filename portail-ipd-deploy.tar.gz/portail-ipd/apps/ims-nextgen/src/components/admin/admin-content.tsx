"use client";

import { useEffect, useState, useCallback } from "react";
import {
  Users, UserPlus, Search, Shield, Eye, EyeOff, Pencil,
  UserCheck, UserX, Phone, Mail, Briefcase, Building2,
  ChevronDown, X, Key, Save, Filter, RotateCcw,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */
interface UserData {
  id: number;
  name: string;
  email: string;
  role: string;
  service: string | null;
  telephone: string | null;
  poste: string | null;
  actif: boolean;
  lastLoginAt: string | null;
  createdAt: string;
  _count: { auditTrails: number; actionsResponsable: number };
}

const ROLES = ["ADMIN", "CONTRIBUTEUR", "LECTEUR", "AUDITEUR"];
const SERVICES = ["PMO", "PRODUCTION", "AQ", "CQVM", "SMS", "LCQ", "Finance", "RH", "Regulatory", "Direction", "SEID", "Externe"];

const roleColors: Record<string, string> = {
  ADMIN: "bg-red-500/20 text-red-400 border-red-500/30",
  CONTRIBUTEUR: "bg-[#0089D0]/20 text-[#0089D0] border-[#0089D0]/30",
  LECTEUR: "bg-[#27AE60]/20 text-[#27AE60] border-emerald-500/30",
  AUDITEUR: "bg-[#052A62]/20 text-[#052A62] border-purple-500/30",
};

const selectClass = "rounded-lg bg-white/[0.04] border border-white/[0.08] px-3 py-1.5 text-sm text-white/70 focus:outline-none focus:ring-1 focus:ring-cyan-500/50 w-full";

function getInitials(name: string) {
  return name.split(" ").map(w => w[0]).join("").toUpperCase().slice(0, 2);
}

function getAvatarColor(name: string) {
  const colors = [
    "from-cyan-500 to-blue-500",
    "from-purple-500 to-pink-500",
    "from-emerald-500 to-teal-500",
    "from-amber-500 to-orange-500",
    "from-rose-500 to-red-500",
    "from-indigo-500 to-violet-500",
  ];
  let hash = 0;
  for (let i = 0; i < name.length; i++) hash = name.charCodeAt(i) + ((hash << 5) - hash);
  return colors[Math.abs(hash) % colors.length];
}

/* ------------------------------------------------------------------ */
/*  Create / Edit User Modal                                           */
/* ------------------------------------------------------------------ */
function UserFormModal({
  open, onClose, user, onSaved,
}: {
  open: boolean; onClose: () => void; user: UserData | null; onSaved: () => void;
}) {
  const isEdit = !!user;
  const [form, setForm] = useState({
    name: "", email: "", password: "", role: "CONTRIBUTEUR", service: "", telephone: "", poste: "", actif: true,
  });
  const [showPwd, setShowPwd] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (user) {
      setForm({
        name: user.name, email: user.email, password: "", role: user.role,
        service: user.service || "", telephone: user.telephone || "", poste: user.poste || "", actif: user.actif,
      });
    } else {
      setForm({ name: "", email: "", password: "", role: "CONTRIBUTEUR", service: "", telephone: "", poste: "", actif: true });
    }
    setError("");
  }, [user, open]);

  const handleSave = async () => {
    setError("");
    if (!form.name || !form.email) { setError("Nom et email requis"); return; }
    if (!isEdit && !form.password) { setError("Mot de passe requis pour un nouvel utilisateur"); return; }

    setSaving(true);
    try {
      const body: Record<string, any> = { ...form };
      if (!body.password) delete body.password;

      const res = await fetch(isEdit ? `/api/users/${user!.id}` : "/api/users", {
        method: isEdit ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });

      if (!res.ok) {
        const data = await res.json();
        setError(data.error || "Erreur serveur");
        setSaving(false);
        return;
      }

      onSaved();
      onClose();
    } catch {
      setError("Erreur de connexion");
    }
    setSaving(false);
  };

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="bg-[#031A40] border-white/[0.08] text-white max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-white flex items-center gap-2">
            {isEdit ? <Pencil className="w-5 h-5 text-[#0089D0]" /> : <UserPlus className="w-5 h-5 text-[#0089D0]" />}
            {isEdit ? `Modifier ${user!.name}` : "Nouvel utilisateur"}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 mt-2">
          {error && <div className="rounded-lg bg-red-500/10 border border-red-500/20 p-3 text-sm text-red-400">{error}</div>}

          {/* Name + Email */}
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label className="text-white/50 text-xs">Nom complet *</Label>
              <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Prenom Nom" className="bg-white/[0.04] border-white/[0.08] text-white placeholder:text-white/20" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-white/50 text-xs">Email *</Label>
              <Input value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="email@ipd.sn" className="bg-white/[0.04] border-white/[0.08] text-white placeholder:text-white/20" />
            </div>
          </div>

          {/* Password */}
          <div className="space-y-1.5">
            <Label className="text-white/50 text-xs">{isEdit ? "Nouveau mot de passe (laisser vide si inchange)" : "Mot de passe *"}</Label>
            <div className="relative">
              <Input type={showPwd ? "text" : "password"} value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} placeholder={isEdit ? "••••••" : "Mot de passe"} className="bg-white/[0.04] border-white/[0.08] text-white placeholder:text-white/20 pr-10" />
              <button type="button" onClick={() => setShowPwd(!showPwd)} className="absolute right-3 top-1/2 -translate-y-1/2 text-white/20 hover:text-white/40">
                {showPwd ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Role + Service */}
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label className="text-white/50 text-xs">Role *</Label>
              <select value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })} className={selectClass}>
                {ROLES.map((r) => <option key={r} value={r} className="bg-[#031A40]">{r}</option>)}
              </select>
            </div>
            <div className="space-y-1.5">
              <Label className="text-white/50 text-xs">Service</Label>
              <select value={form.service} onChange={(e) => setForm({ ...form, service: e.target.value })} className={selectClass}>
                <option value="" className="bg-[#031A40]">-- Aucun --</option>
                {SERVICES.map((s) => <option key={s} value={s} className="bg-[#031A40]">{s}</option>)}
              </select>
            </div>
          </div>

          {/* Poste */}
          <div className="space-y-1.5">
            <Label className="text-white/50 text-xs">Poste / Fonction</Label>
            <Input value={form.poste} onChange={(e) => setForm({ ...form, poste: e.target.value })} placeholder="Ex: Directeur Qualite" className="bg-white/[0.04] border-white/[0.08] text-white placeholder:text-white/20" />
          </div>

          {/* Phone */}
          <div className="space-y-1.5">
            <Label className="text-white/50 text-xs">Telephone</Label>
            <Input value={form.telephone} onChange={(e) => setForm({ ...form, telephone: e.target.value })} placeholder="+221 77 000 0000" className="bg-white/[0.04] border-white/[0.08] text-white placeholder:text-white/20" />
          </div>

          {/* Active switch */}
          {isEdit && (
            <div className="flex items-center justify-between rounded-lg bg-white/[0.03] p-3 border border-white/[0.06]">
              <div>
                <p className="text-sm text-white/70">Compte actif</p>
                <p className="text-xs text-white/30">Desactiver bloque l'acces a la plateforme</p>
              </div>
              <Switch checked={form.actif} onCheckedChange={(v) => setForm({ ...form, actif: v })} />
            </div>
          )}

          {/* Actions */}
          <div className="flex gap-3 pt-2">
            <button onClick={onClose} className="flex-1 rounded-xl bg-white/[0.04] border border-white/[0.08] py-2.5 text-sm text-white/50 hover:bg-white/[0.08] transition-colors">
              Annuler
            </button>
            <button onClick={handleSave} disabled={saving} className="flex-1 rounded-xl bg-gradient-to-r from-cyan-500 to-cyan-600 py-2.5 text-sm font-semibold text-[#0a0e1a] hover:from-cyan-400 hover:to-cyan-500 disabled:opacity-50 transition-all flex items-center justify-center gap-2">
              {saving ? (
                <svg className="animate-spin w-4 h-4" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" /><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" /></svg>
              ) : <Save className="w-4 h-4" />}
              {isEdit ? "Enregistrer" : "Creer l'utilisateur"}
            </button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

/* ------------------------------------------------------------------ */
/*  User Detail Modal                                                  */
/* ------------------------------------------------------------------ */
function UserDetailModal({ open, onClose, user }: { open: boolean; onClose: () => void; user: UserData | null }) {
  if (!user) return null;
  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="bg-[#031A40] border-white/[0.08] text-white max-w-md">
        <DialogHeader>
          <DialogTitle className="text-white sr-only">Detail utilisateur</DialogTitle>
        </DialogHeader>
        <div className="flex flex-col items-center py-4">
          <div className={`w-20 h-20 rounded-2xl bg-gradient-to-br ${getAvatarColor(user.name)} flex items-center justify-center text-2xl font-bold text-white shadow-lg`}>
            {getInitials(user.name)}
          </div>
          <h3 className="text-xl font-bold text-white mt-4">{user.name}</h3>
          <p className="text-sm text-white/40">{user.poste || user.role}</p>
          <Badge className={`mt-2 ${roleColors[user.role] || ""}`}>{user.role}</Badge>

          <div className="w-full mt-6 space-y-3">
            <div className="flex items-center gap-3 text-sm rounded-lg bg-white/[0.03] p-3 border border-white/[0.06]">
              <Mail className="w-4 h-4 text-white/30" />
              <span className="text-white/60">{user.email}</span>
            </div>
            {user.telephone && (
              <div className="flex items-center gap-3 text-sm rounded-lg bg-white/[0.03] p-3 border border-white/[0.06]">
                <Phone className="w-4 h-4 text-white/30" />
                <span className="text-white/60">{user.telephone}</span>
              </div>
            )}
            <div className="flex items-center gap-3 text-sm rounded-lg bg-white/[0.03] p-3 border border-white/[0.06]">
              <Building2 className="w-4 h-4 text-white/30" />
              <span className="text-white/60">{user.service || "Non assigne"}</span>
            </div>
            {user.poste && (
              <div className="flex items-center gap-3 text-sm rounded-lg bg-white/[0.03] p-3 border border-white/[0.06]">
                <Briefcase className="w-4 h-4 text-white/30" />
                <span className="text-white/60">{user.poste}</span>
              </div>
            )}
            <div className="grid grid-cols-2 gap-3">
              <div className="rounded-lg bg-white/[0.03] p-3 border border-white/[0.06] text-center">
                <p className="text-lg font-bold text-white">{user._count.auditTrails}</p>
                <p className="text-[10px] text-white/30">Actions audit</p>
              </div>
              <div className="rounded-lg bg-white/[0.03] p-3 border border-white/[0.06] text-center">
                <p className="text-lg font-bold text-white">{user._count.actionsResponsable}</p>
                <p className="text-[10px] text-white/30">Actions AFM</p>
              </div>
            </div>
            <div className="flex items-center justify-between text-xs text-white/30 pt-2">
              <span>Cree le {new Date(user.createdAt).toLocaleDateString("fr-FR")}</span>
              <Badge className={user.actif ? "bg-[#27AE60]/20 text-[#27AE60] text-[10px]" : "bg-red-500/20 text-red-400 text-[10px]"}>
                {user.actif ? "Actif" : "Desactive"}
              </Badge>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

/* ------------------------------------------------------------------ */
/*  Main Admin Content                                                 */
/* ------------------------------------------------------------------ */
export function AdminContent() {
  const [users, setUsers] = useState<UserData[]>([]);
  const [loading, setLoading] = useState(true);

  // Filters
  const [search, setSearch] = useState("");
  const [filterRole, setFilterRole] = useState("");
  const [filterService, setFilterService] = useState("");
  const [filterActif, setFilterActif] = useState("");

  // Modals
  const [formOpen, setFormOpen] = useState(false);
  const [editUser, setEditUser] = useState<UserData | null>(null);
  const [detailUser, setDetailUser] = useState<UserData | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    const res = await fetch("/api/users");
    const data = await res.json();
    setUsers(data);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const filtered = users.filter((u) => {
    if (search) {
      const s = search.toLowerCase();
      if (!u.name.toLowerCase().includes(s) && !u.email.toLowerCase().includes(s) && !(u.poste || "").toLowerCase().includes(s)) return false;
    }
    if (filterRole && u.role !== filterRole) return false;
    if (filterService && u.service !== filterService) return false;
    if (filterActif === "actif" && !u.actif) return false;
    if (filterActif === "inactif" && u.actif) return false;
    return true;
  });

  const stats = {
    total: users.length,
    admins: users.filter((u) => u.role === "ADMIN").length,
    actifs: users.filter((u) => u.actif).length,
    services: [...new Set(users.map((u) => u.service).filter(Boolean))].length,
  };

  const resetFilters = () => { setSearch(""); setFilterRole(""); setFilterService(""); setFilterActif(""); };

  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="glass glow-cyan border-white/[0.08]">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="rounded-lg bg-[#0089D0]/10 p-2.5"><Users className="w-5 h-5 text-[#0089D0]" /></div>
            <div>
              <p className="text-2xl font-bold text-white">{stats.total}</p>
              <p className="text-[10px] text-white/40 uppercase tracking-wider">Utilisateurs</p>
            </div>
          </CardContent>
        </Card>
        <Card className="glass glow-red border-white/[0.08]">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="rounded-lg bg-red-500/10 p-2.5"><Shield className="w-5 h-5 text-red-400" /></div>
            <div>
              <p className="text-2xl font-bold text-white">{stats.admins}</p>
              <p className="text-[10px] text-white/40 uppercase tracking-wider">Administrateurs</p>
            </div>
          </CardContent>
        </Card>
        <Card className="glass glow-emerald border-white/[0.08]">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="rounded-lg bg-[#27AE60]/10 p-2.5"><UserCheck className="w-5 h-5 text-[#27AE60]" /></div>
            <div>
              <p className="text-2xl font-bold text-white">{stats.actifs}</p>
              <p className="text-[10px] text-white/40 uppercase tracking-wider">Comptes actifs</p>
            </div>
          </CardContent>
        </Card>
        <Card className="glass glow-purple border-white/[0.08]">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="rounded-lg bg-[#052A62]/10 p-2.5"><Building2 className="w-5 h-5 text-[#052A62]" /></div>
            <div>
              <p className="text-2xl font-bold text-white">{stats.services}</p>
              <p className="text-[10px] text-white/40 uppercase tracking-wider">Services</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Toolbar */}
      <div className="flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/20" />
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Rechercher nom, email, poste..." className="w-full rounded-xl bg-white/[0.04] border border-white/[0.08] pl-10 pr-4 py-2.5 text-sm text-white placeholder:text-white/20 focus:outline-none focus:ring-1 focus:ring-cyan-500/50" />
        </div>
        <select value={filterRole} onChange={(e) => setFilterRole(e.target.value)} className={selectClass + " !w-auto min-w-[120px]"}>
          <option value="" className="bg-[#031A40]">Tous roles</option>
          {ROLES.map((r) => <option key={r} value={r} className="bg-[#031A40]">{r}</option>)}
        </select>
        <select value={filterService} onChange={(e) => setFilterService(e.target.value)} className={selectClass + " !w-auto min-w-[130px]"}>
          <option value="" className="bg-[#031A40]">Tous services</option>
          {SERVICES.map((s) => <option key={s} value={s} className="bg-[#031A40]">{s}</option>)}
        </select>
        <select value={filterActif} onChange={(e) => setFilterActif(e.target.value)} className={selectClass + " !w-auto min-w-[110px]"}>
          <option value="" className="bg-[#031A40]">Tous statuts</option>
          <option value="actif" className="bg-[#031A40]">Actif</option>
          <option value="inactif" className="bg-[#031A40]">Inactif</option>
        </select>
        {(search || filterRole || filterService || filterActif) && (
          <button onClick={resetFilters} className="rounded-lg bg-white/[0.04] border border-white/[0.08] p-2 text-white/30 hover:text-white/60 hover:bg-white/[0.08] transition-colors">
            <RotateCcw className="w-4 h-4" />
          </button>
        )}
        <button onClick={() => { setEditUser(null); setFormOpen(true); }} className="rounded-xl bg-gradient-to-r from-cyan-500 to-cyan-600 px-5 py-2.5 text-sm font-semibold text-[#0a0e1a] hover:from-cyan-400 hover:to-cyan-500 transition-all shadow-[0_0_20px_rgba(6,182,212,0.2)] flex items-center gap-2">
          <UserPlus className="w-4 h-4" /> Nouvel utilisateur
        </button>
      </div>

      {/* Results count */}
      <p className="text-xs text-white/30">{filtered.length} utilisateur(s) affiche(s)</p>

      {/* User cards grid */}
      {loading ? (
        <div className="flex items-center justify-center h-40 text-white/30">Chargement...</div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((user) => (
            <Card key={user.id} className={`glass border-white/[0.08] hover:border-white/[0.15] transition-all cursor-pointer group ${!user.actif ? "opacity-50" : ""}`} onClick={() => setDetailUser(user)}>
              <CardContent className="p-4">
                <div className="flex items-start gap-3">
                  <div className={`w-12 h-12 shrink-0 rounded-xl bg-gradient-to-br ${getAvatarColor(user.name)} flex items-center justify-center text-base font-bold text-white shadow-md`}>
                    {getInitials(user.name)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <h3 className="text-sm font-semibold text-white truncate">{user.name}</h3>
                      <button onClick={(e) => { e.stopPropagation(); setEditUser(user); setFormOpen(true); }} className="opacity-0 group-hover:opacity-100 rounded-lg p-1.5 text-white/30 hover:text-[#0089D0] hover:bg-white/[0.06] transition-all">
                        <Pencil className="w-3.5 h-3.5" />
                      </button>
                    </div>
                    <p className="text-xs text-white/40 truncate">{user.email}</p>
                    {user.poste && <p className="text-[10px] text-white/25 mt-0.5 truncate">{user.poste}</p>}
                  </div>
                </div>
                <div className="flex items-center justify-between mt-3">
                  <div className="flex items-center gap-2">
                    <Badge className={`text-[10px] ${roleColors[user.role] || "bg-white/10 text-white/50"}`}>{user.role}</Badge>
                    {user.service && <Badge variant="outline" className="text-[10px] border-white/10 text-white/40">{user.service}</Badge>}
                  </div>
                  <div className="flex items-center gap-1">
                    <div className={`w-2 h-2 rounded-full ${user.actif ? "bg-[#27AE60]" : "bg-red-400"}`} />
                    <span className="text-[10px] text-white/25">{user.actif ? "Actif" : "Inactif"}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Role distribution */}
      <Card className="glass border-white/[0.08]">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm text-white/70">Repartition par role</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-4 gap-3">
            {ROLES.map((role) => {
              const count = users.filter((u) => u.role === role).length;
              const pct = users.length ? Math.round((count / users.length) * 100) : 0;
              return (
                <div key={role} className="rounded-xl bg-white/[0.03] p-3 border border-white/[0.06] text-center">
                  <Badge className={`${roleColors[role]} text-xs mb-2`}>{role}</Badge>
                  <p className="text-xl font-bold text-white">{count}</p>
                  <div className="mt-2 h-1.5 rounded-full bg-white/[0.06]">
                    <div className="h-full rounded-full bg-[#0089D0]/60" style={{ width: `${pct}%` }} />
                  </div>
                  <p className="text-[10px] text-white/25 mt-1">{pct}%</p>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Modals */}
      <UserFormModal open={formOpen} onClose={() => { setFormOpen(false); setEditUser(null); }} user={editUser} onSaved={load} />
      <UserDetailModal open={!!detailUser} onClose={() => setDetailUser(null)} user={detailUser} />
    </div>
  );
}
