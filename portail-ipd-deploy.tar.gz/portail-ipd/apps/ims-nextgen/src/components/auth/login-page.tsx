"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Eye, EyeOff, Lock, User, ArrowRight, ShieldCheck, Activity, FlaskConical, Syringe, Microscope, Pill, HeartPulse, Dna, Beaker } from "lucide-react";

/* ------------------------------------------------------------------ */
/*  Animated SVG illustrations                                        */
/* ------------------------------------------------------------------ */

function HexagonGrid() {
  return (
    <svg className="absolute inset-0 w-full h-full opacity-[0.04]" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <pattern id="hex" width="56" height="100" patternUnits="userSpaceOnUse" patternTransform="scale(2)">
          <path d="M28 66L0 50L0 16L28 0L56 16L56 50L28 66L28 100" fill="none" stroke="rgba(6,182,212,1)" strokeWidth="0.5" />
        </pattern>
      </defs>
      <rect width="100%" height="100%" fill="url(#hex)" />
    </svg>
  );
}

function MoleculeIllustration() {
  return (
    <svg viewBox="0 0 400 400" className="w-72 h-72 opacity-20 absolute -top-10 -right-10" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <radialGradient id="mol1" cx="50%" cy="50%" r="50%"><stop offset="0%" stopColor="#0089D0" stopOpacity="0.6" /><stop offset="100%" stopColor="#0089D0" stopOpacity="0" /></radialGradient>
        <radialGradient id="mol2" cx="50%" cy="50%" r="50%"><stop offset="0%" stopColor="#8b5cf6" stopOpacity="0.5" /><stop offset="100%" stopColor="#8b5cf6" stopOpacity="0" /></radialGradient>
      </defs>
      {/* Molecular structure */}
      <line x1="200" y1="100" x2="300" y2="180" stroke="#0089D0" strokeWidth="1.5" opacity="0.3" />
      <line x1="200" y1="100" x2="100" y2="160" stroke="#0089D0" strokeWidth="1.5" opacity="0.3" />
      <line x1="100" y1="160" x2="120" y2="280" stroke="#8b5cf6" strokeWidth="1.5" opacity="0.3" />
      <line x1="300" y1="180" x2="280" y2="300" stroke="#8b5cf6" strokeWidth="1.5" opacity="0.3" />
      <line x1="120" y1="280" x2="280" y2="300" stroke="#10b981" strokeWidth="1.5" opacity="0.3" />
      <line x1="200" y1="100" x2="200" y2="200" stroke="#0089D0" strokeWidth="1.5" opacity="0.2" />
      <line x1="200" y1="200" x2="120" y2="280" stroke="#10b981" strokeWidth="1.5" opacity="0.2" />
      <line x1="200" y1="200" x2="280" y2="300" stroke="#10b981" strokeWidth="1.5" opacity="0.2" />
      <circle cx="200" cy="100" r="14" fill="url(#mol1)" />
      <circle cx="200" cy="100" r="6" fill="#0089D0" opacity="0.6" />
      <circle cx="300" cy="180" r="11" fill="url(#mol2)" />
      <circle cx="300" cy="180" r="5" fill="#8b5cf6" opacity="0.5" />
      <circle cx="100" cy="160" r="11" fill="url(#mol1)" />
      <circle cx="100" cy="160" r="5" fill="#0089D0" opacity="0.5" />
      <circle cx="120" cy="280" r="13" fill="url(#mol2)" />
      <circle cx="120" cy="280" r="6" fill="#8b5cf6" opacity="0.5" />
      <circle cx="280" cy="300" r="13" fill="url(#mol1)" />
      <circle cx="280" cy="300" r="6" fill="#10b981" opacity="0.5" />
      <circle cx="200" cy="200" r="10" fill="url(#mol1)" />
      <circle cx="200" cy="200" r="4" fill="#0089D0" opacity="0.4" />
    </svg>
  );
}

function DNAHelix() {
  return (
    <svg viewBox="0 0 120 500" className="w-20 h-80 absolute left-8 top-1/4 opacity-15" xmlns="http://www.w3.org/2000/svg">
      {[...Array(12)].map((_, i) => {
        const y = i * 40 + 20;
        const x1 = 30 + Math.sin(i * 0.8) * 25;
        const x2 = 90 - Math.sin(i * 0.8) * 25;
        return (
          <g key={i}>
            <line x1={x1} y1={y} x2={x2} y2={y} stroke="#0089D0" strokeWidth="1" opacity={0.3 + Math.sin(i * 0.5) * 0.15} />
            <circle cx={x1} cy={y} r="4" fill="#0089D0" opacity={0.4 + Math.sin(i * 0.5) * 0.2}>
              <animate attributeName="opacity" values={`${0.3};${0.6};${0.3}`} dur={`${2 + i * 0.3}s`} repeatCount="indefinite" />
            </circle>
            <circle cx={x2} cy={y} r="4" fill="#8b5cf6" opacity={0.4 + Math.cos(i * 0.5) * 0.2}>
              <animate attributeName="opacity" values={`${0.3};${0.6};${0.3}`} dur={`${2.5 + i * 0.2}s`} repeatCount="indefinite" />
            </circle>
          </g>
        );
      })}
      {/* Helix curves */}
      <path d={`M ${30 + Math.sin(0) * 25} 20 ${[...Array(12)].map((_, i) => `Q ${60} ${i * 40 + 40} ${30 + Math.sin((i + 1) * 0.8) * 25} ${(i + 1) * 40 + 20}`).join(" ")}`} fill="none" stroke="#0089D0" strokeWidth="1.5" opacity="0.2" />
      <path d={`M ${90 - Math.sin(0) * 25} 20 ${[...Array(12)].map((_, i) => `Q ${60} ${i * 40 + 40} ${90 - Math.sin((i + 1) * 0.8) * 25} ${(i + 1) * 40 + 20}`).join(" ")}`} fill="none" stroke="#8b5cf6" strokeWidth="1.5" opacity="0.2" />
    </svg>
  );
}

function VaccineVial() {
  return (
    <svg viewBox="0 0 200 300" className="w-36 h-52 opacity-20" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="vial-glass" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="#0089D0" stopOpacity="0.15" />
          <stop offset="30%" stopColor="#0089D0" stopOpacity="0.05" />
          <stop offset="70%" stopColor="#0089D0" stopOpacity="0.05" />
          <stop offset="100%" stopColor="#0089D0" stopOpacity="0.15" />
        </linearGradient>
        <linearGradient id="liquid" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#0089D0" stopOpacity="0.4" />
          <stop offset="100%" stopColor="#8b5cf6" stopOpacity="0.3" />
        </linearGradient>
      </defs>
      {/* Cap */}
      <rect x="70" y="20" width="60" height="20" rx="3" fill="#0089D0" opacity="0.3" />
      <rect x="75" y="10" width="50" height="15" rx="4" fill="#0089D0" opacity="0.2" />
      {/* Neck */}
      <rect x="80" y="40" width="40" height="30" rx="2" fill="url(#vial-glass)" stroke="#0089D0" strokeWidth="1" opacity="0.4" />
      {/* Body */}
      <path d="M 80 70 L 60 100 L 60 250 Q 60 270 80 270 L 120 270 Q 140 270 140 250 L 140 100 L 120 70 Z" fill="url(#vial-glass)" stroke="#0089D0" strokeWidth="1.2" opacity="0.4" />
      {/* Liquid */}
      <path d="M 62 160 Q 100 150 138 160 L 138 250 Q 138 268 120 268 L 80 268 Q 62 268 62 250 Z" fill="url(#liquid)">
        <animate attributeName="d" values="M 62 160 Q 100 150 138 160 L 138 250 Q 138 268 120 268 L 80 268 Q 62 268 62 250 Z;M 62 160 Q 100 170 138 160 L 138 250 Q 138 268 120 268 L 80 268 Q 62 268 62 250 Z;M 62 160 Q 100 150 138 160 L 138 250 Q 138 268 120 268 L 80 268 Q 62 268 62 250 Z" dur="4s" repeatCount="indefinite" />
      </path>
      {/* Bubbles */}
      <circle cx="85" cy="220" r="3" fill="#0089D0" opacity="0.3">
        <animate attributeName="cy" values="220;170;220" dur="3s" repeatCount="indefinite" />
        <animate attributeName="opacity" values="0.3;0.1;0.3" dur="3s" repeatCount="indefinite" />
      </circle>
      <circle cx="110" cy="240" r="2" fill="#8b5cf6" opacity="0.3">
        <animate attributeName="cy" values="240;180;240" dur="4s" repeatCount="indefinite" />
        <animate attributeName="opacity" values="0.3;0.1;0.3" dur="4s" repeatCount="indefinite" />
      </circle>
      <circle cx="95" cy="200" r="2.5" fill="#10b981" opacity="0.2">
        <animate attributeName="cy" values="200;165;200" dur="3.5s" repeatCount="indefinite" />
      </circle>
      {/* Label */}
      <rect x="70" y="180" width="60" height="40" rx="3" fill="none" stroke="#0089D0" strokeWidth="0.8" opacity="0.3" />
      <text x="100" y="202" textAnchor="middle" fill="#0089D0" fontSize="8" opacity="0.5" fontFamily="monospace">VACCINE</text>
      <text x="100" y="214" textAnchor="middle" fill="#0089D0" fontSize="6" opacity="0.3" fontFamily="monospace">IPD-2026</text>
    </svg>
  );
}

function MicroscopeIllustration() {
  return (
    <svg viewBox="0 0 200 260" className="w-40 h-52 opacity-15" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="micro-body" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#0089D0" stopOpacity="0.3" />
          <stop offset="100%" stopColor="#8b5cf6" stopOpacity="0.2" />
        </linearGradient>
      </defs>
      {/* Base */}
      <ellipse cx="100" cy="240" rx="70" ry="12" fill="#0089D0" opacity="0.15" />
      <rect x="40" y="225" width="120" height="18" rx="4" fill="url(#micro-body)" stroke="#0089D0" strokeWidth="1" opacity="0.3" />
      {/* Stage */}
      <rect x="55" y="180" width="90" height="8" rx="2" fill="#0089D0" stroke="#0089D0" strokeWidth="0.8" opacity="0.3" />
      {/* Arm */}
      <path d="M 120 225 L 120 100 Q 120 85 110 80 L 90 70" fill="none" stroke="#0089D0" strokeWidth="3" strokeLinecap="round" opacity="0.3" />
      {/* Body tube */}
      <rect x="82" y="35" width="20" height="40" rx="3" fill="url(#micro-body)" stroke="#0089D0" strokeWidth="1" opacity="0.3" />
      {/* Eyepiece */}
      <rect x="78" y="20" width="28" height="18" rx="5" fill="#0089D0" stroke="#0089D0" strokeWidth="1" opacity="0.3" />
      <ellipse cx="92" cy="22" rx="10" ry="4" fill="#0089D0" opacity="0.1" />
      {/* Objective */}
      <rect x="86" y="75" width="12" height="25" rx="3" fill="url(#micro-body)" stroke="#0089D0" strokeWidth="0.8" opacity="0.35" />
      {/* Focus knob */}
      <circle cx="130" cy="150" r="10" fill="none" stroke="#0089D0" strokeWidth="1.5" opacity="0.25" />
      <circle cx="130" cy="150" r="4" fill="#0089D0" opacity="0.15" />
      {/* Light cone */}
      <path d="M 92 100 L 75 175 L 109 175 Z" fill="#0089D0" opacity="0.04" />
      {/* Slide glow */}
      <circle cx="92" cy="184" r="6" fill="#0089D0" opacity="0.15">
        <animate attributeName="opacity" values="0.1;0.25;0.1" dur="2s" repeatCount="indefinite" />
      </circle>
    </svg>
  );
}

function QualityShield() {
  return (
    <svg viewBox="0 0 200 240" className="w-36 h-44 opacity-20" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="shield-grad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#10b981" stopOpacity="0.3" />
          <stop offset="100%" stopColor="#0089D0" stopOpacity="0.15" />
        </linearGradient>
      </defs>
      <path d="M 100 20 L 170 55 L 170 120 Q 170 180 100 220 Q 30 180 30 120 L 30 55 Z" fill="url(#shield-grad)" stroke="#10b981" strokeWidth="1.5" opacity="0.4" />
      <path d="M 100 40 L 155 65 L 155 115 Q 155 165 100 200 Q 45 165 45 115 L 45 65 Z" fill="none" stroke="#0089D0" strokeWidth="0.8" opacity="0.2" strokeDasharray="4 3" />
      {/* Check mark */}
      <path d="M 70 120 L 92 145 L 135 95" fill="none" stroke="#10b981" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" opacity="0.5">
        <animate attributeName="opacity" values="0.3;0.6;0.3" dur="3s" repeatCount="indefinite" />
      </path>
      {/* GMP Text */}
      <text x="100" y="180" textAnchor="middle" fill="#10b981" fontSize="14" fontWeight="bold" opacity="0.4" fontFamily="monospace">GMP</text>
      <text x="100" y="195" textAnchor="middle" fill="#0089D0" fontSize="8" opacity="0.3" fontFamily="monospace">CERTIFIED</text>
    </svg>
  );
}

function seededRandom(seed: number) {
  const x = Math.sin(seed * 9301 + 49297) * 49297;
  return x - Math.floor(x);
}

function FloatingParticles() {
  const particles = Array.from({ length: 30 }, (_, i) => ({
    id: i,
    cx: seededRandom(i * 7 + 1) * 100,
    cy: seededRandom(i * 13 + 2) * 100,
    r: seededRandom(i * 17 + 3) * 2 + 0.5,
    dur: seededRandom(i * 23 + 4) * 6 + 4,
    delay: seededRandom(i * 29 + 5) * 5,
    color: ["#0089D0", "#8b5cf6", "#10b981", "#f59e0b"][Math.floor(seededRandom(i * 31 + 6) * 4)],
  }));

  return (
    <svg className="absolute inset-0 w-full h-full pointer-events-none" xmlns="http://www.w3.org/2000/svg">
      {particles.map((p) => (
        <circle key={p.id} cx={`${p.cx}%`} cy={`${p.cy}%`} r={p.r} fill={p.color} opacity="0.15">
          <animate attributeName="cy" values={`${p.cy}%;${p.cy - 8}%;${p.cy}%`} dur={`${p.dur}s`} begin={`${p.delay}s`} repeatCount="indefinite" />
          <animate attributeName="opacity" values="0.1;0.3;0.1" dur={`${p.dur}s`} begin={`${p.delay}s`} repeatCount="indefinite" />
        </circle>
      ))}
    </svg>
  );
}

function CircuitLines() {
  return (
    <svg className="absolute bottom-0 left-0 w-full h-64 opacity-[0.06]" viewBox="0 0 1200 300" xmlns="http://www.w3.org/2000/svg">
      <path d="M0 250 H200 V180 H350 V220 H500" stroke="#0089D0" strokeWidth="1.5" fill="none" />
      <path d="M500 220 H600 V150 H750 V200 H900 V170 H1050 V230 H1200" stroke="#0089D0" strokeWidth="1.5" fill="none" />
      <path d="M0 280 H150 V200 H280 V260 H400 V190 H550 V250 H700 V210 H850 V260 H1000 V200 H1200" stroke="#8b5cf6" strokeWidth="1" fill="none" />
      {/* Circuit nodes */}
      {[200, 350, 500, 600, 750, 900, 1050].map((x, i) => (
        <circle key={i} cx={x} cy={[180, 220, 220, 150, 200, 170, 230][i]} r="3" fill="#0089D0" opacity="0.5">
          <animate attributeName="opacity" values="0.3;0.7;0.3" dur={`${2 + i * 0.5}s`} repeatCount="indefinite" />
        </circle>
      ))}
    </svg>
  );
}

/* ------------------------------------------------------------------ */
/*  Feature icons bar                                                  */
/* ------------------------------------------------------------------ */

const features = [
  { icon: ShieldCheck, label: "Ecarts OMS", color: "text-[#0089D0]" },
  { icon: FlaskConical, label: "Actions AFM", color: "text-[#052A62]" },
  { icon: Syringe, label: "Vaccins", color: "text-[#27AE60]" },
  { icon: Pill, label: "GARAP", color: "text-[#EF7A16]" },
  { icon: HeartPulse, label: "Qualite", color: "text-pink-400" },
  { icon: Dna, label: "BPF/GMP", color: "text-[#0089D0]" },
];

/* ------------------------------------------------------------------ */
/*  Login Page Component                                               */
/* ------------------------------------------------------------------ */

export function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    // Simulated auth — accept any non-empty credentials
    await new Promise((r) => setTimeout(r, 1200));

    if (!email || !password) {
      setError("Veuillez remplir tous les champs.");
      setLoading(false);
      return;
    }

    // Successful login
    router.push("/dashboard");
  };

  return (
    <div className="relative min-h-screen overflow-hidden flex items-center justify-center bg-[#031A40]">
      {/* Background layers */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#0a0e1a] via-[#0f1629] to-[#0a0e1a]" />
      <HexagonGrid />
      <FloatingParticles />
      <CircuitLines />

      {/* Decorative glow orbs */}
      <div className="absolute top-[-15%] left-[-10%] w-[600px] h-[600px] rounded-full bg-[#0089D0]/[0.04] blur-[120px]" />
      <div className="absolute bottom-[-20%] right-[-10%] w-[500px] h-[500px] rounded-full bg-[#052A62]/[0.04] blur-[120px]" />
      <div className="absolute top-[40%] right-[20%] w-[300px] h-[300px] rounded-full bg-[#27AE60]/[0.03] blur-[100px]" />

      {/* DNA Helix left */}
      <DNAHelix />

      {/* Main content */}
      <div className="relative z-10 w-full max-w-6xl mx-auto px-6 flex flex-col lg:flex-row items-center gap-12 lg:gap-20">

        {/* ============ LEFT SIDE — Illustrations & branding ============ */}
        <div className="flex-1 flex flex-col items-center lg:items-start text-center lg:text-left">
          {/* Logo IPD officiel */}
          <div className="mb-8 animate-fade-up">
            <img
              src="/logo-ipd-white.png"
              alt="Institut Pasteur de Dakar"
              className="h-16 object-contain mb-3"
            />
            <div className="flex items-center gap-2">
              <div className="h-px flex-1 bg-white/10" />
              <span className="text-[10px] font-bold text-[#0089D0] uppercase tracking-[0.25em]">IMS NextGen</span>
              <div className="h-px flex-1 bg-white/10" />
            </div>
          </div>

          {/* Headline */}
          <h2 className="text-4xl lg:text-5xl font-bold text-white leading-tight mb-4 animate-fade-up-delay">
            Pilotage <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-400">Strategique</span>
            <br />des Activites Critiques
          </h2>
          <p className="text-base text-white/40 max-w-md mb-8 leading-relaxed animate-fade-up-delay2">
            Plateforme integree de gestion qualite pour la production de vaccins
            a usage humain — UVFJ / IPD.
          </p>

          {/* Illustrations grid */}
          <div className="grid grid-cols-3 gap-6 mb-8">
            <div className="flex flex-col items-center gap-2 animate-float">
              <VaccineVial />
              <span className="text-[10px] text-white/25 uppercase tracking-widest">Vaccins</span>
            </div>
            <div className="flex flex-col items-center gap-2 animate-float-delay">
              <MicroscopeIllustration />
              <span className="text-[10px] text-white/25 uppercase tracking-widest">Controle</span>
            </div>
            <div className="flex flex-col items-center gap-2 animate-float-slow">
              <QualityShield />
              <span className="text-[10px] text-white/25 uppercase tracking-widest">Qualite</span>
            </div>
          </div>

          {/* Feature badges */}
          <div className="flex flex-wrap gap-3 justify-center lg:justify-start">
            {features.map((f) => (
              <div key={f.label} className="flex items-center gap-1.5 rounded-full bg-white/[0.04] border border-white/[0.06] px-3 py-1.5 hover:border-white/[0.12] transition-colors">
                <f.icon className={`w-3.5 h-3.5 ${f.color}`} />
                <span className="text-[11px] text-white/50">{f.label}</span>
              </div>
            ))}
          </div>
        </div>

        {/* ============ RIGHT SIDE — Login form ============ */}
        <div className="w-full max-w-md">
          {/* Molecule illustration behind card */}
          <div className="relative">
            <MoleculeIllustration />

            {/* Glow border card */}
            <div className="relative rounded-3xl glow-border">
              <div className="rounded-3xl bg-[#031A40]/90 backdrop-blur-xl border border-white/[0.08] p-8 shadow-[0_0_80px_rgba(6,182,212,0.08)]">

                {/* Card header */}
                <div className="text-center mb-8">
                  <div className="w-14 h-14 mx-auto rounded-2xl bg-gradient-to-br from-cyan-500/15 to-emerald-500/15 border border-[#0089D0]/20 flex items-center justify-center mb-4">
                    <Lock className="w-6 h-6 text-[#0089D0]" />
                  </div>
                  <h3 className="text-xl font-semibold text-white">Connexion</h3>
                  <p className="text-sm text-white/30 mt-1">Accedez a votre espace de pilotage</p>
                </div>

                {/* Error */}
                {error && (
                  <div className="mb-4 rounded-xl bg-red-500/10 border border-red-500/20 p-3 text-sm text-red-400 text-center">
                    {error}
                  </div>
                )}

                {/* Form */}
                <form onSubmit={handleLogin} className="space-y-5">
                  {/* Email */}
                  <div className="space-y-1.5">
                    <label className="text-xs text-white/40 uppercase tracking-wider font-medium">Identifiant</label>
                    <div className="relative">
                      <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-white/20" />
                      <input
                        type="text"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="nom.prenom@pasteur.sn"
                        className="w-full rounded-xl bg-white/[0.04] border border-white/[0.08] pl-11 pr-4 py-3 text-sm text-white placeholder:text-white/20 focus:outline-none focus:ring-2 focus:ring-cyan-500/30 focus:border-[#0089D0]/30 transition-all"
                      />
                    </div>
                  </div>

                  {/* Password */}
                  <div className="space-y-1.5">
                    <label className="text-xs text-white/40 uppercase tracking-wider font-medium">Mot de passe</label>
                    <div className="relative">
                      <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-white/20" />
                      <input
                        type={showPassword ? "text" : "password"}
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="••••••••"
                        className="w-full rounded-xl bg-white/[0.04] border border-white/[0.08] pl-11 pr-11 py-3 text-sm text-white placeholder:text-white/20 focus:outline-none focus:ring-2 focus:ring-cyan-500/30 focus:border-[#0089D0]/30 transition-all"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3.5 top-1/2 -translate-y-1/2 text-white/20 hover:text-white/40 transition-colors"
                      >
                        {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>

                  {/* Remember & forgot */}
                  <div className="flex items-center justify-between">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input type="checkbox" className="rounded border-white/20 bg-white/[0.04] text-[#0089D0] focus:ring-cyan-500/30 w-3.5 h-3.5" />
                      <span className="text-xs text-white/30">Rester connecte</span>
                    </label>
                    <button type="button" className="text-xs text-[#0089D0]/60 hover:text-[#0089D0] transition-colors">
                      Mot de passe oublie ?
                    </button>
                  </div>

                  {/* Submit */}
                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full relative rounded-xl bg-gradient-to-r from-cyan-500 to-cyan-600 py-3 text-sm font-semibold text-[#0a0e1a] hover:from-cyan-400 hover:to-cyan-500 transition-all duration-300 shadow-[0_0_30px_rgba(6,182,212,0.25)] hover:shadow-[0_0_40px_rgba(6,182,212,0.35)] disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 group"
                  >
                    {loading ? (
                      <>
                        <svg className="animate-spin w-4 h-4" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                        </svg>
                        Connexion en cours...
                      </>
                    ) : (
                      <>
                        Acceder a la plateforme
                        <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                      </>
                    )}
                  </button>
                </form>

                {/* Demo accounts */}
                <div className="mt-6 pt-5 border-t border-white/[0.06]">
                  <p className="text-[10px] text-white/20 text-center uppercase tracking-wider mb-3">Acces rapide demo</p>
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      { role: "Directeur UVFJ", email: "directeur@pasteur.sn" },
                      { role: "Resp. Qualite", email: "qualite@pasteur.sn" },
                      { role: "Resp. Production", email: "production@pasteur.sn" },
                      { role: "Auditeur", email: "auditeur@pasteur.sn" },
                    ].map((acc) => (
                      <button
                        key={acc.role}
                        type="button"
                        onClick={() => { setEmail(acc.email); setPassword("demo2026"); }}
                        className="rounded-lg bg-white/[0.03] border border-white/[0.06] px-3 py-2 text-left hover:bg-white/[0.06] hover:border-white/[0.10] transition-all group"
                      >
                        <span className="text-[11px] text-white/50 group-hover:text-white/70 block">{acc.role}</span>
                        <span className="text-[9px] text-white/20">{acc.email}</span>
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Footer */}
          <div className="text-center mt-6">
            <p className="text-[10px] text-white/15">
              IMS-NextGen v2.0 — Institut Pasteur de Dakar &copy; 2026
            </p>
            <p className="text-[9px] text-white/10 mt-1">
              Unite de production des Vaccins Fievre Jaune
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
