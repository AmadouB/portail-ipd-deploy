"use client";

interface HeatmapProps {
  data: { department: string; weeks: { week: string; count: number }[] }[];
}

export function Heatmap({ data }: HeatmapProps) {
  if (!data.length) return null;

  const weeks = data[0]?.weeks.map(w => w.week) || [];
  const maxCount = Math.max(...data.flatMap(d => d.weeks.map(w => w.count)), 1);

  function getCellColor(count: number): string {
    if (count === 0) return "rgba(255,255,255,0.02)";
    const intensity = count / maxCount;
    if (intensity > 0.75) return "rgba(231,76,60,0.6)";
    if (intensity > 0.5) return "rgba(239,122,22,0.5)";
    if (intensity > 0.25) return "rgba(255,213,0,0.4)";
    return "rgba(0,137,208,0.3)";
  }

  return (
    <div className="overflow-x-auto">
      <div className="min-w-[600px]">
        {/* Header row */}
        <div className="flex gap-1 mb-1">
          <div className="w-24 shrink-0" />
          {weeks.map(w => (
            <div key={w} className="flex-1 text-center text-[10px] text-white/30">{w}</div>
          ))}
        </div>
        {/* Data rows */}
        {data.map(row => (
          <div key={row.department} className="flex gap-1 mb-1">
            <div className="w-24 shrink-0 text-xs text-white/50 flex items-center truncate pr-2">{row.department}</div>
            {row.weeks.map((cell, i) => (
              <div
                key={i}
                className="flex-1 h-7 rounded-sm flex items-center justify-center text-[10px] text-white/60 transition-colors hover:ring-1 hover:ring-white/20"
                style={{ backgroundColor: getCellColor(cell.count) }}
                title={`${row.department} - ${cell.week}: ${cell.count} items`}
              >
                {cell.count > 0 && cell.count}
              </div>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}
