"use client";

import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid,
} from "recharts";

interface Snapshot {
  id: number; snapshotDate: string; snapshotLabel: string; statut: string;
  pctAvancement: number; margeProgression: number | null; estCloture: boolean;
  ecart: { numero: string; service: { code: string }; macroEcart: { numero: string } };
}

export function SnapshotsContent() {
  const [data, setData] = useState<{ snapshots: Snapshot[] } | null>(null);

  useEffect(() => {
    fetch("/api/snapshots").then((r) => r.json()).then(setData);
  }, []);

  if (!data) return <div className="flex items-center justify-center h-64 text-white/40">Chargement...</div>;

  // Aggregate by snapshot label
  const labels = [...new Set(data.snapshots.map((s) => s.snapshotLabel))].sort();
  const trendData = labels.map((label) => {
    const snaps = data.snapshots.filter((s) => s.snapshotLabel === label);
    const avgPct = snaps.reduce((sum, s) => sum + s.pctAvancement, 0) / snaps.length;
    const clotures = snaps.filter((s) => s.estCloture).length;
    return { label: label.replace("Snapshot_", ""), avgPct: Math.round(avgPct * 100), clotures, total: snaps.length };
  });

  // Group by service for burn-down
  const services = [...new Set(data.snapshots.map((s) => s.ecart.service.code))];
  const serviceColors: Record<string, string> = { PROD: "#06b6d4", AQ: "#8b5cf6", CQVM: "#10b981", CQ: "#f59e0b", SMS: "#ec4899", PHARM: "#ef4444" };

  const serviceTrend = labels.map((label) => {
    const entry: Record<string, any> = { label: label.replace("Snapshot_", "") };
    for (const svc of services) {
      const snaps = data.snapshots.filter((s) => s.snapshotLabel === label && s.ecart.service.code === svc);
      entry[svc] = snaps.length > 0 ? Math.round((snaps.reduce((sum, s) => sum + s.pctAvancement, 0) / snaps.length) * 100) : 0;
    }
    return entry;
  });

  return (
    <div className="space-y-6">
      {/* Summary cards */}
      <div className="grid grid-cols-3 gap-4">
        {trendData.map((t) => (
          <Card key={t.label} className="glass border-white/[0.08]">
            <CardContent className="p-4">
              <p className="text-xs text-white/40">{t.label}</p>
              <p className="text-2xl font-bold text-white mt-1">{t.avgPct}%</p>
              <p className="text-[10px] text-white/30">{t.clotures}/{t.total} ecarts clotures</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Global trend */}
      <Card className="glass border-white/[0.08]">
        <CardHeader>
          <CardTitle className="text-sm text-white/70">Progression globale</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={trendData}>
              <CartesianGrid stroke="rgba(255,255,255,0.04)" />
              <XAxis dataKey="label" tick={{ fill: "rgba(255,255,255,0.4)", fontSize: 11 }} />
              <YAxis domain={[0, 100]} tick={{ fill: "rgba(255,255,255,0.4)", fontSize: 11 }} />
              <Tooltip contentStyle={{ background: "#111827", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 8, color: "#fff" }} />
              <Line type="monotone" dataKey="avgPct" stroke="#06b6d4" strokeWidth={2} dot={{ fill: "#06b6d4", r: 4 }} name="Avancement moyen %" />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Burn-down by service */}
      <Card className="glass border-white/[0.08]">
        <CardHeader>
          <CardTitle className="text-sm text-white/70">Progression par service</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={serviceTrend}>
              <CartesianGrid stroke="rgba(255,255,255,0.04)" />
              <XAxis dataKey="label" tick={{ fill: "rgba(255,255,255,0.4)", fontSize: 11 }} />
              <YAxis domain={[0, 100]} tick={{ fill: "rgba(255,255,255,0.4)", fontSize: 11 }} />
              <Tooltip contentStyle={{ background: "#111827", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 8, color: "#fff" }} />
              {services.map((svc) => (
                <Line key={svc} type="monotone" dataKey={svc} stroke={serviceColors[svc] || "#666"} strokeWidth={2} dot={{ r: 3 }} name={svc} />
              ))}
            </LineChart>
          </ResponsiveContainer>
          <div className="flex gap-4 mt-3 justify-center">
            {services.map((svc) => (
              <div key={svc} className="flex items-center gap-1.5">
                <div className="h-2 w-2 rounded-full" style={{ background: serviceColors[svc] || "#666" }} />
                <span className="text-[10px] text-white/40">{svc}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Stagnation alerts */}
      <Card className="glass border-white/[0.08]">
        <CardHeader>
          <CardTitle className="text-sm text-white/70">Alertes de stagnation</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {data.snapshots
              .filter((s) => s.snapshotLabel === labels[labels.length - 1] && s.margeProgression !== null && s.margeProgression <= 0 && !s.estCloture)
              .map((s) => (
                <div key={s.id} className="flex items-center gap-3 rounded-lg bg-red-500/5 p-2.5 border border-red-500/10">
                  <Badge variant="outline" className="text-[10px] bg-red-500/10 text-red-400 border-red-500/20">Stagnation</Badge>
                  <span className="text-xs font-mono text-[#0089D0]">{s.ecart.numero}</span>
                  <span className="text-xs text-white/60 flex-1">{s.ecart.service.code}</span>
                  <span className="text-xs text-red-400 font-mono">Delta: {s.margeProgression ? (s.margeProgression * 100).toFixed(0) : 0}%</span>
                </div>
              ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
