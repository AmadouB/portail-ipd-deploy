"use client";

import { useEffect, useState } from "react";
import { ShieldCheck, AlertTriangle, Target, Gauge, Award, Package, BarChart3, Clock, X, ExternalLink, MessageSquare } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend,
} from "recharts";

interface KpiData {
  tauxCloture: number;
  totalEcarts: number;
  clotures: number;
  capaOnTime: number;
  capaHorsDelai: number;
  majeursRestants: number;
  scoreRisqueMoyen: number;
  gmpStatus: string;
  garapTotal: number;
  garapClotures: number;
  avancementParWs: { code: string; avancement: number }[];
  serviceBreakdown: { code: string; total: number; clotures: number; taux: number }[];
  macroEcarts: { numero: string; description: string; classification: string; nbEcartsEnfants: number; tauxCloture: number }[];
  actionsParStatut: { cloture: number; enCours: number; enRetard: number; aLancer: number };
  garapParStatut: Record<string, number>;
  details: {
    ecartsOuverts: any[];
    ecartsClotures: any[];
    ecartsCapaHorsDelai: any[];
    ecartsMajeursOuverts: any[];
    actionsDetail: any[];
    garapDetail: any[];
    actionsEnRetard: any[];
    actionsRisqueEleve: any[];
  };
}

const COLORS = ["#0089D0", "#052A62", "#27AE60", "#EF7A16", "#FFD500", "#86B4DD", "#E74C3C"];

function DetailModal({ open, onClose, title, children }: { open: boolean; onClose: () => void; title: string; children: React.ReactNode }) {
  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="bg-[#031A40] border-white/[0.08] text-white max-w-3xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-white">{title}</DialogTitle>
        </DialogHeader>
        {children}
      </DialogContent>
    </Dialog>
  );
}

function DetailRow({ label, value }: { label: string; value: React.ReactNode }) {
  if (!value) return null;
  return (
    <div className="flex gap-2 text-sm">
      <span className="text-white/40 min-w-[120px] shrink-0">{label}</span>
      <span className="text-white/80">{value}</span>
    </div>
  );
}

function CommentBlock({ text, label }: { text?: string; label?: string }) {
  if (!text) return null;
  return (
    <div className="mt-1 flex items-start gap-1.5 text-xs">
      <MessageSquare className="h-3 w-3 text-[#0089D0]/60 mt-0.5 shrink-0" />
      <span className="text-white/50">{label ? <span className="text-white/30">{label}: </span> : null}{text}</span>
    </div>
  );
}

function EcartItem({ e }: { e: any }) {
  return (
    <div className="rounded-lg bg-white/[0.03] border border-white/[0.06] p-3 space-y-1">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-sm font-medium text-white">{e.numero}</span>
          <Badge variant="outline" className="text-[10px] border-white/10 text-white/50">{e.service}</Badge>
          {e.classification === "Majeur" && <Badge className="bg-red-500/20 text-red-400 text-[10px]">Majeur</Badge>}
        </div>
        <div className="flex items-center gap-2">
          {e.capaHorsDelai && <Badge className="bg-red-500/20 text-red-400 text-[10px]">CAPA HD</Badge>}
          <Badge className={`text-[10px] ${e.statut === "CLOTURE" ? "bg-[#27AE60]/20 text-[#27AE60]" : e.statut === "EN_COURS" ? "bg-[#EF7A16]/20 text-[#EF7A16]" : "bg-blue-500/20 text-blue-400"}`}>
            {e.statut}
          </Badge>
        </div>
      </div>
      <p className="text-xs text-white/60">{e.nomEcart}</p>
      {e.pctAvancement !== undefined && (
        <div className="flex items-center gap-2 mt-1">
          <div className="flex-1 h-1.5 rounded-full bg-white/[0.06]">
            <div className="h-full rounded-full bg-[#0089D0]/60" style={{ width: `${e.pctAvancement}%` }} />
          </div>
          <span className="text-xs text-white/40">{e.pctAvancement}%</span>
        </div>
      )}
      <CommentBlock text={e.commentaireAvancement} label="Avancement" />
      <CommentBlock text={e.commentaires} label="Commentaire" />
      {e.pointsBloquants && <CommentBlock text={e.pointsBloquants} label="Bloquants" />}
    </div>
  );
}

function ActionItem({ a }: { a: any }) {
  return (
    <div className="rounded-lg bg-white/[0.03] border border-white/[0.06] p-3 space-y-1">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-sm font-medium text-white">{a.chronoLegacy}</span>
          <Badge variant="outline" className="text-[10px] border-white/10 text-white/50">{a.workstream}</Badge>
        </div>
        <div className="flex items-center gap-2">
          <Badge className={`text-[10px] ${a.scoreRisque >= 10 ? "bg-red-500/20 text-red-400" : a.scoreRisque >= 6 ? "bg-orange-500/20 text-orange-400" : a.scoreRisque >= 3 ? "bg-[#EF7A16]/20 text-[#EF7A16]" : "bg-[#27AE60]/20 text-[#27AE60]"}`}>
            RIV {a.scoreRisque}
          </Badge>
          <Badge className={`text-[10px] ${a.statut === "CLOTURE" ? "bg-[#27AE60]/20 text-[#27AE60]" : a.statut === "EN_RETARD" ? "bg-red-500/20 text-red-400" : "bg-[#EF7A16]/20 text-[#EF7A16]"}`}>
            {a.statut}
          </Badge>
        </div>
      </div>
      <p className="text-xs text-white/60 line-clamp-2">{a.description}</p>
      <div className="flex items-center gap-2 mt-1">
        <div className="flex-1 h-1.5 rounded-full bg-white/[0.06]">
          <div className="h-full rounded-full bg-[#0089D0]/60" style={{ width: `${a.avancement * 100}%` }} />
        </div>
        <span className="text-xs text-white/40">{Math.round(a.avancement * 100)}%</span>
      </div>
      {a.responsables && <p className="text-xs text-white/45 mt-0.5">Resp: {a.responsables}</p>}
      <CommentBlock text={a.commentaires} />
    </div>
  );
}

function GarapItem({ g }: { g: any }) {
  return (
    <div className="rounded-lg bg-white/[0.03] border border-white/[0.06] p-3 space-y-1">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-sm font-medium text-white">{g.entite}</span>
          <Badge variant="outline" className="text-[10px] border-white/10 text-white/50">{g.fournisseur}</Badge>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-sm text-white/60">{Number(g.montant).toLocaleString()} {g.devise}</span>
          <Badge className={`text-[10px] ${g.statutWorkflow === "CLOTURE" || g.statutWorkflow === "LIVRE" ? "bg-[#27AE60]/20 text-[#27AE60]" : "bg-[#EF7A16]/20 text-[#EF7A16]"}`}>
            {g.statutWorkflow}
          </Badge>
        </div>
      </div>
      <p className="text-xs text-white/60 line-clamp-2">{g.natureProduits}</p>
      {g.dateLivraisonPrevue && <p className="text-xs text-white/45">Livraison prevue: {new Date(g.dateLivraisonPrevue).toLocaleDateString("fr-FR")}</p>}
      <CommentBlock text={g.commentaireDal} label="DAL" />
    </div>
  );
}

function StatCard({ icon: Icon, label, value, sub, glowClass, onClick }: {
  icon: any; label: string; value: string | number; sub?: string; glowClass: string; onClick?: () => void;
}) {
  return (
    <Card className={`glass ${glowClass} border-white/[0.08] ${onClick ? "cursor-pointer hover:scale-[1.02] transition-transform" : ""}`} onClick={onClick}>
      <CardContent className="p-4">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-sm text-white/55 uppercase tracking-wider">{label}</p>
            <p className="text-2xl font-bold text-white mt-1">{value}</p>
            {sub && <p className="text-sm text-white/60 mt-1">{sub}</p>}
          </div>
          <div className="rounded-lg bg-white/[0.04] p-2">
            <Icon className="h-5 w-5 text-white/40" />
          </div>
        </div>
        {onClick && <p className="text-[10px] text-[#0089D0]/40 mt-2">Cliquer pour les details</p>}
      </CardContent>
    </Card>
  );
}

export function DashboardContent() {
  const [data, setData] = useState<KpiData | null>(null);
  const [modal, setModal] = useState<string | null>(null);

  useEffect(() => {
    fetch("/api/kpi").then((r) => r.json()).then(setData);
  }, []);

  if (!data) return <div className="flex items-center justify-center h-64 text-white/40">Chargement...</div>;

  const pieData = [
    { name: "Clotures", value: data.clotures, color: "#10b981" },
    { name: "En cours", value: data.totalEcarts - data.clotures, color: "#f59e0b" },
  ];

  const capaData = [
    { name: "On-time", value: data.capaOnTime, color: "#10b981" },
    { name: "Hors delai", value: data.capaHorsDelai, color: "#ef4444" },
  ];

  const garapPipelineData = [
    { name: "Cloture", value: data.garapParStatut.CLOTURE || 0, color: "#10b981" },
    { name: "Att. Fourn.", value: data.garapParStatut.ATTENTE_FOURNISSEUR || 0, color: "#f59e0b" },
    { name: "Att. Paie.", value: data.garapParStatut.ATTENTE_PAIEMENT || 0, color: "#8b5cf6" },
    { name: "Transitaire", value: data.garapParStatut.CHEZ_TRANSITAIRE || 0, color: "#06b6d4" },
    { name: "Douane", value: data.garapParStatut.EN_COURS_DOUANE || 0, color: "#ec4899" },
    { name: "Livre", value: data.garapParStatut.LIVRE || 0, color: "#10b981" },
  ];

  const daysToInspection = 180;

  return (
    <div className="space-y-6">
      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard icon={ShieldCheck} label="Taux de cloture global" value={`${data.tauxCloture}%`} sub={`${data.clotures}/${data.totalEcarts} ecarts`} glowClass="glow-emerald" onClick={() => setModal("cloture")} />
        <StatCard icon={Target} label="CAPA On-time" value={`${data.capaOnTime}`} sub={`vs ${data.capaHorsDelai} hors delai`} glowClass="glow-cyan" onClick={() => setModal("capa")} />
        <StatCard icon={AlertTriangle} label="Majeurs restants" value={data.majeursRestants} sub="ecarts ouverts" glowClass="glow-red" onClick={() => setModal("majeurs")} />
        <StatCard icon={Gauge} label="Score risque AFM" value={`${data.scoreRisqueMoyen}/25`} sub="moyenne ponderee" glowClass="glow-amber" onClick={() => setModal("risque")} />
        <StatCard icon={Award} label="Certificat GMP" value={data.gmpStatus} sub="Delivre OMS" glowClass="glow-emerald" onClick={() => setModal("gmp")} />
        <StatCard icon={Package} label="Dossiers GARAP" value={`${data.garapClotures}/${data.garapTotal}`} sub="clotures" glowClass="glow-purple" onClick={() => setModal("garap")} />
        <StatCard icon={BarChart3} label="Actions AFM" value={data.actionsParStatut.cloture + data.actionsParStatut.enCours + data.actionsParStatut.enRetard + data.actionsParStatut.aLancer} sub={`${data.actionsParStatut.enRetard} en retard`} glowClass="glow-cyan" onClick={() => setModal("actions")} />
        <StatCard icon={Clock} label="Inspection Readiness" value={`J-${daysToInspection}`} sub="prochaine inspection OMS" glowClass="glow-amber" onClick={() => setModal("inspection")} />
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="glass border-white/[0.08] cursor-pointer hover:border-white/[0.15] transition-colors" onClick={() => setModal("cloture")}>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-white/70">Taux de cloture ecarts</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie data={pieData} cx="50%" cy="50%" innerRadius={50} outerRadius={80} dataKey="value" strokeWidth={0}>
                  {pieData.map((entry, i) => (<Cell key={i} fill={entry.color} />))}
                </Pie>
                <Legend formatter={(value) => <span className="text-xs text-white/60">{value}</span>} />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="glass border-white/[0.08] cursor-pointer hover:border-white/[0.15] transition-colors" onClick={() => setModal("capa")}>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-white/70">CAPA On-time vs Hors delai</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie data={capaData} cx="50%" cy="50%" innerRadius={50} outerRadius={80} dataKey="value" strokeWidth={0}>
                  {capaData.map((entry, i) => (<Cell key={i} fill={entry.color} />))}
                </Pie>
                <Legend formatter={(value) => <span className="text-xs text-white/60">{value}</span>} />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="glass border-white/[0.08] cursor-pointer hover:border-white/[0.15] transition-colors" onClick={() => setModal("garap")}>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-white/70">Pipeline GARAP</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={garapPipelineData} layout="vertical">
                <XAxis type="number" tick={{ fill: "rgba(255,255,255,0.4)", fontSize: 11 }} />
                <YAxis type="category" dataKey="name" tick={{ fill: "rgba(255,255,255,0.4)", fontSize: 10 }} width={70} />
                <Tooltip contentStyle={{ background: "#111827", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 8, color: "#fff" }} />
                <Bar dataKey="value" radius={[0, 4, 4, 0]}>
                  {garapPipelineData.map((entry, i) => (<Cell key={i} fill={entry.color} />))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Workstream Avancement */}
      <Card className="glass border-white/[0.08]">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm text-white/70">Avancement par Workstream</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={data.avancementParWs}>
              <XAxis dataKey="code" tick={{ fill: "rgba(255,255,255,0.5)", fontSize: 11 }} />
              <YAxis domain={[0, 100]} tick={{ fill: "rgba(255,255,255,0.4)", fontSize: 11 }} />
              <Tooltip contentStyle={{ background: "#111827", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 8, color: "#fff" }} formatter={(v) => [`${v}%`, "Avancement"]} />
              <Bar dataKey="avancement" radius={[4, 4, 0, 0]}>
                {data.avancementParWs.map((_, i) => (<Cell key={i} fill={COLORS[i % COLORS.length]} />))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Service Breakdown */}
      <Card className="glass border-white/[0.08]">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm text-white/70">Ecarts par service</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
            {data.serviceBreakdown.map((svc) => (
              <div key={svc.code} className="rounded-xl bg-white/[0.03] p-3 border border-white/[0.06] cursor-pointer hover:border-[#0089D0]/30 transition-colors" onClick={() => setModal(`service-${svc.code}`)}>
                <p className="text-sm text-white/55">{svc.code}</p>
                <p className="text-lg font-bold text-white">{svc.taux}%</p>
                <p className="text-xs text-white/45">{svc.clotures}/{svc.total} clotures</p>
                <div className="mt-2 h-1.5 rounded-full bg-white/[0.06]">
                  <div className="h-full rounded-full bg-[#0089D0]/60" style={{ width: `${svc.taux}%` }} />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Macro-ecarts */}
      {data.macroEcarts && (
        <Card className="glass border-white/[0.08]">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-white/70">Macro-ecarts OMS</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {data.macroEcarts.map((m) => (
                <div key={m.numero} className="rounded-xl bg-white/[0.03] p-3 border border-white/[0.06]">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-white">{m.numero}</span>
                    <Badge className={`text-[10px] ${m.classification === "Majeur" ? "bg-red-500/20 text-red-400" : "bg-[#EF7A16]/20 text-[#EF7A16]"}`}>{m.classification}</Badge>
                  </div>
                  <p className="text-sm text-white/60 mt-1 line-clamp-2">{m.description}</p>
                  <div className="flex items-center justify-between mt-2">
                    <span className="text-xs text-white/45">{m.nbEcartsEnfants} ecarts</span>
                    <span className="text-xs font-medium text-white/70">{m.tauxCloture}%</span>
                  </div>
                  <div className="mt-1 h-1.5 rounded-full bg-white/[0.06]">
                    <div className="h-full rounded-full bg-[#0089D0]/60" style={{ width: `${m.tauxCloture}%` }} />
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* ===== DETAIL MODALS ===== */}

      {/* Taux de cloture */}
      <DetailModal open={modal === "cloture"} onClose={() => setModal(null)} title={`Ecarts ouverts (${data.details.ecartsOuverts.length})`}>
        <div className="space-y-2 max-h-[60vh] overflow-y-auto pr-1">
          {data.details.ecartsOuverts.length === 0 ? (
            <p className="text-sm text-white/40 text-center py-4">Tous les ecarts sont clotures</p>
          ) : data.details.ecartsOuverts.map((e: any) => <EcartItem key={e.id} e={e} />)}
        </div>
        <div className="mt-3 pt-3 border-t border-white/[0.06]">
          <p className="text-sm text-white/45">Ecarts clotures: {data.details.ecartsClotures.length} | Total: {data.totalEcarts}</p>
        </div>
      </DetailModal>

      {/* CAPA */}
      <DetailModal open={modal === "capa"} onClose={() => setModal(null)} title={`CAPA hors delai (${data.details.ecartsCapaHorsDelai.length})`}>
        <div className="space-y-2 max-h-[60vh] overflow-y-auto pr-1">
          {data.details.ecartsCapaHorsDelai.length === 0 ? (
            <p className="text-sm text-white/40 text-center py-4">Aucune CAPA hors delai</p>
          ) : data.details.ecartsCapaHorsDelai.map((e: any) => <EcartItem key={e.id} e={e} />)}
        </div>
        <div className="mt-3 pt-3 border-t border-white/[0.06] grid grid-cols-2 gap-2 text-sm text-white/55">
          <span>On-time: {data.capaOnTime}</span>
          <span>Hors delai: {data.capaHorsDelai}</span>
        </div>
      </DetailModal>

      {/* Majeurs */}
      <DetailModal open={modal === "majeurs"} onClose={() => setModal(null)} title={`Ecarts majeurs ouverts (${data.details.ecartsMajeursOuverts.length})`}>
        <div className="space-y-2 max-h-[60vh] overflow-y-auto pr-1">
          {data.details.ecartsMajeursOuverts.length === 0 ? (
            <p className="text-sm text-white/40 text-center py-4">Aucun ecart majeur ouvert</p>
          ) : data.details.ecartsMajeursOuverts.map((e: any) => (
            <div key={e.id} className="rounded-lg bg-white/[0.03] border border-red-500/20 p-3 space-y-1">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-medium text-white">{e.numero}</span>
                  <Badge variant="outline" className="text-[10px] border-white/10 text-white/50">{e.service}</Badge>
                  <Badge variant="outline" className="text-[10px] border-white/10 text-white/40">ME {e.macroEcart}</Badge>
                </div>
                <Badge className="bg-red-500/20 text-red-400 text-[10px]">{e.statut}</Badge>
              </div>
              <p className="text-xs text-white/60">{e.nomEcart}</p>
              {e.pctAvancement !== undefined && (
                <div className="flex items-center gap-2">
                  <div className="flex-1 h-1.5 rounded-full bg-white/[0.06]">
                    <div className="h-full rounded-full bg-red-500/60" style={{ width: `${e.pctAvancement}%` }} />
                  </div>
                  <span className="text-xs text-white/40">{e.pctAvancement}%</span>
                </div>
              )}
              <CommentBlock text={e.pointsBloquants} label="Points bloquants" />
              <CommentBlock text={e.commentaireAvancement} label="Avancement" />
            </div>
          ))}
        </div>
      </DetailModal>

      {/* Score risque */}
      <DetailModal open={modal === "risque"} onClose={() => setModal(null)} title={`Actions a risque eleve (${data.details.actionsRisqueEleve.length})`}>
        <div className="space-y-2 max-h-[60vh] overflow-y-auto pr-1">
          {data.details.actionsRisqueEleve.length === 0 ? (
            <p className="text-sm text-white/40 text-center py-4">Aucune action a risque eleve</p>
          ) : data.details.actionsRisqueEleve.map((a: any) => <ActionItem key={a.id} a={a} />)}
        </div>
        <div className="mt-3 pt-3 border-t border-white/[0.06]">
          <p className="text-sm text-white/45">Score risque moyen: {data.scoreRisqueMoyen}/25</p>
        </div>
      </DetailModal>

      {/* GMP */}
      <DetailModal open={modal === "gmp"} onClose={() => setModal(null)} title="Certificat GMP - Readiness">
        <div className="space-y-3">
          <div className="rounded-lg bg-[#27AE60]/10 border border-emerald-500/20 p-4 text-center">
            <Award className="h-10 w-10 text-[#27AE60] mx-auto" />
            <p className="text-lg font-bold text-[#27AE60] mt-2">Certificat {data.gmpStatus}</p>
            <p className="text-sm text-white/55 mt-1">Delivre par l'OMS</p>
          </div>
          <div className="grid grid-cols-2 gap-3 text-sm">
            <div className="rounded-lg bg-white/[0.03] p-3 border border-white/[0.06]">
              <p className="text-white/40 text-xs">Ecarts clotures</p>
              <p className="text-xl font-bold text-white">{data.tauxCloture}%</p>
            </div>
            <div className="rounded-lg bg-white/[0.03] p-3 border border-white/[0.06]">
              <p className="text-white/40 text-xs">Majeurs restants</p>
              <p className="text-xl font-bold text-white">{data.majeursRestants}</p>
            </div>
            <div className="rounded-lg bg-white/[0.03] p-3 border border-white/[0.06]">
              <p className="text-white/40 text-xs">CAPA on-time</p>
              <p className="text-xl font-bold text-white">{Math.round((data.capaOnTime / data.totalEcarts) * 100)}%</p>
            </div>
            <div className="rounded-lg bg-white/[0.03] p-3 border border-white/[0.06]">
              <p className="text-white/40 text-xs">Score risque</p>
              <p className="text-xl font-bold text-white">{data.scoreRisqueMoyen}/25</p>
            </div>
          </div>
        </div>
      </DetailModal>

      {/* GARAP */}
      <DetailModal open={modal === "garap"} onClose={() => setModal(null)} title={`Dossiers GARAP (${data.garapTotal})`}>
        <div className="space-y-3">
          <div className="grid grid-cols-3 gap-2">
            {Object.entries(data.garapParStatut).map(([k, v]) => (
              <div key={k} className="rounded-lg bg-white/[0.03] p-2 border border-white/[0.06] text-center">
                <p className="text-xs text-white/40">{k.replace(/_/g, " ")}</p>
                <p className="text-lg font-bold text-white">{v as number}</p>
              </div>
            ))}
          </div>
          <p className="text-sm text-white/60 font-medium">Dossiers en cours</p>
          <div className="space-y-2 max-h-[40vh] overflow-y-auto pr-1">
            {data.details.garapDetail.filter((g: any) => g.statutWorkflow !== "CLOTURE" && g.statutWorkflow !== "LIVRE").map((g: any) => <GarapItem key={g.id} g={g} />)}
          </div>
        </div>
      </DetailModal>

      {/* Actions */}
      <DetailModal open={modal === "actions"} onClose={() => setModal(null)} title="Actions AFM">
        <div className="space-y-3">
          <div className="grid grid-cols-4 gap-2">
            <div className="rounded-lg bg-[#27AE60]/10 p-2 border border-emerald-500/20 text-center">
              <p className="text-xs text-white/40">Cloture</p>
              <p className="text-lg font-bold text-[#27AE60]">{data.actionsParStatut.cloture}</p>
            </div>
            <div className="rounded-lg bg-[#EF7A16]/10 p-2 border border-amber-500/20 text-center">
              <p className="text-xs text-white/40">En cours</p>
              <p className="text-lg font-bold text-[#EF7A16]">{data.actionsParStatut.enCours}</p>
            </div>
            <div className="rounded-lg bg-red-500/10 p-2 border border-red-500/20 text-center">
              <p className="text-xs text-white/40">En retard</p>
              <p className="text-lg font-bold text-red-400">{data.actionsParStatut.enRetard}</p>
            </div>
            <div className="rounded-lg bg-blue-500/10 p-2 border border-blue-500/20 text-center">
              <p className="text-xs text-white/40">A lancer</p>
              <p className="text-lg font-bold text-blue-400">{data.actionsParStatut.aLancer}</p>
            </div>
          </div>
          {data.details.actionsEnRetard.length > 0 && (
            <>
              <p className="text-xs text-red-400 font-medium">Actions en retard ({data.details.actionsEnRetard.length})</p>
              <div className="space-y-2 max-h-[30vh] overflow-y-auto pr-1">
                {data.details.actionsEnRetard.map((a: any) => <ActionItem key={a.id} a={a} />)}
              </div>
            </>
          )}
          <p className="text-sm text-white/60 font-medium">Toutes les actions ({data.details.actionsDetail.length})</p>
          <div className="space-y-2 max-h-[30vh] overflow-y-auto pr-1">
            {data.details.actionsDetail.map((a: any) => <ActionItem key={a.id} a={a} />)}
          </div>
        </div>
      </DetailModal>

      {/* Inspection Readiness */}
      <DetailModal open={modal === "inspection"} onClose={() => setModal(null)} title="Inspection Readiness">
        <div className="space-y-3">
          <div className="rounded-lg bg-[#EF7A16]/10 border border-amber-500/20 p-4 text-center">
            <Clock className="h-10 w-10 text-[#EF7A16] mx-auto" />
            <p className="text-2xl font-bold text-[#EF7A16] mt-2">J-{daysToInspection}</p>
            <p className="text-sm text-white/55 mt-1">Prochaine inspection OMS</p>
          </div>
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm p-2 rounded-lg bg-white/[0.03]">
              <span className="text-white/60">Taux de cloture ecarts</span>
              <Badge className={data.tauxCloture >= 90 ? "bg-[#27AE60]/20 text-[#27AE60]" : "bg-[#EF7A16]/20 text-[#EF7A16]"}>{data.tauxCloture}%</Badge>
            </div>
            <div className="flex items-center justify-between text-sm p-2 rounded-lg bg-white/[0.03]">
              <span className="text-white/60">Ecarts majeurs ouverts</span>
              <Badge className={data.majeursRestants === 0 ? "bg-[#27AE60]/20 text-[#27AE60]" : "bg-red-500/20 text-red-400"}>{data.majeursRestants}</Badge>
            </div>
            <div className="flex items-center justify-between text-sm p-2 rounded-lg bg-white/[0.03]">
              <span className="text-white/60">CAPA hors delai</span>
              <Badge className={data.capaHorsDelai === 0 ? "bg-[#27AE60]/20 text-[#27AE60]" : "bg-red-500/20 text-red-400"}>{data.capaHorsDelai}</Badge>
            </div>
            <div className="flex items-center justify-between text-sm p-2 rounded-lg bg-white/[0.03]">
              <span className="text-white/60">Score risque moyen</span>
              <Badge className={data.scoreRisqueMoyen <= 5 ? "bg-[#27AE60]/20 text-[#27AE60]" : "bg-[#EF7A16]/20 text-[#EF7A16]"}>{data.scoreRisqueMoyen}/25</Badge>
            </div>
            <div className="flex items-center justify-between text-sm p-2 rounded-lg bg-white/[0.03]">
              <span className="text-white/60">Certificat GMP</span>
              <Badge className="bg-[#27AE60]/20 text-[#27AE60]">{data.gmpStatus}</Badge>
            </div>
          </div>
          {data.details.ecartsMajeursOuverts.length > 0 && (
            <>
              <p className="text-xs text-red-400 font-medium mt-2">Ecarts majeurs bloquants</p>
              <div className="space-y-2 max-h-[30vh] overflow-y-auto pr-1">
                {data.details.ecartsMajeursOuverts.map((e: any) => <EcartItem key={e.id} e={e} />)}
              </div>
            </>
          )}
        </div>
      </DetailModal>

      {/* Service-specific modals */}
      {data.serviceBreakdown.map((svc) => (
        <DetailModal key={svc.code} open={modal === `service-${svc.code}`} onClose={() => setModal(null)} title={`Service ${svc.code} - ${svc.clotures}/${svc.total} clotures (${svc.taux}%)`}>
          <div className="space-y-2 max-h-[60vh] overflow-y-auto pr-1">
            {data.details.ecartsOuverts.filter((e: any) => e.service === svc.code).length === 0 ? (
              <p className="text-sm text-[#27AE60]/60 text-center py-4">Tous les ecarts de ce service sont clotures</p>
            ) : data.details.ecartsOuverts.filter((e: any) => e.service === svc.code).map((e: any) => <EcartItem key={e.id} e={e} />)}
          </div>
        </DetailModal>
      ))}
    </div>
  );
}
