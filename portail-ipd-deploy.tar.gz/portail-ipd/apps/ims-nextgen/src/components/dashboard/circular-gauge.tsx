"use client";

import { PieChart, Pie, Cell, ResponsiveContainer } from "recharts";

interface CircularGaugeProps {
  value: number; // 0-100
  label: string;
  size?: number;
}

export function CircularGauge({ value, label, size = 120 }: CircularGaugeProps) {
  const color = value >= 80 ? "#27AE60" : value >= 50 ? "#EF7A16" : "#E74C3C";
  const data = [
    { name: "progress", value },
    { name: "remaining", value: 100 - value },
  ];

  return (
    <div className="flex flex-col items-center gap-1">
      <div style={{ width: size, height: size }} className="relative">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              innerRadius={size * 0.35}
              outerRadius={size * 0.45}
              startAngle={90}
              endAngle={-270}
              dataKey="value"
              stroke="none"
            >
              <Cell fill={color} />
              <Cell fill="rgba(255,255,255,0.06)" />
            </Pie>
          </PieChart>
        </ResponsiveContainer>
        <div className="absolute inset-0 flex items-center justify-center">
          <span className="text-lg font-bold text-white">{Math.round(value)}%</span>
        </div>
      </div>
      <span className="text-xs text-white/50 text-center max-w-[100px] truncate">{label}</span>
    </div>
  );
}
