"use client";

import { useState, useEffect } from "react";
import { Filter, X } from "lucide-react";

interface FilterState {
  service: string;
  workstream: string;
  criticite: string;
  dateFrom: string;
  dateTo: string;
}

interface DashboardFiltersProps {
  onFilterChange: (filters: FilterState) => void;
}

export function DashboardFilters({ onFilterChange }: DashboardFiltersProps) {
  const [filters, setFilters] = useState<FilterState>({
    service: "",
    workstream: "",
    criticite: "",
    dateFrom: "",
    dateTo: "",
  });
  const [services, setServices] = useState<{ id: number; code: string; libelle: string }[]>([]);
  const [workstreams, setWorkstreams] = useState<{ id: number; code: string; libelle: string }[]>([]);
  const [expanded, setExpanded] = useState(false);

  useEffect(() => {
    fetch("/api/kpi")
      .then(r => r.json())
      .then(d => {
        if (d.serviceBreakdown) setServices(d.serviceBreakdown.map((s: any) => ({ id: 0, code: s.code, libelle: s.code })));
      });
  }, []);

  const updateFilter = (key: keyof FilterState, value: string) => {
    const next = { ...filters, [key]: value };
    setFilters(next);
    onFilterChange(next);
  };

  const clearFilters = () => {
    const empty: FilterState = { service: "", workstream: "", criticite: "", dateFrom: "", dateTo: "" };
    setFilters(empty);
    onFilterChange(empty);
  };

  const hasFilters = Object.values(filters).some(v => v !== "");

  return (
    <div className="space-y-3">
      <button
        onClick={() => setExpanded(!expanded)}
        className="flex items-center gap-2 rounded-lg border border-white/[0.08] bg-white/[0.04] px-3 py-2 text-sm text-white/70 hover:bg-white/[0.08] transition-colors"
      >
        <Filter className="h-4 w-4" />
        Filtres
        {hasFilters && (
          <span className="ml-1 flex h-4.5 min-w-4.5 items-center justify-center rounded-full bg-[#0089D0] px-1 text-[10px] text-white">
            {Object.values(filters).filter(v => v).length}
          </span>
        )}
      </button>

      {expanded && (
        <div className="flex flex-wrap gap-3 rounded-xl border border-white/[0.06] bg-white/[0.03] p-4">
          <select
            value={filters.service}
            onChange={e => updateFilter("service", e.target.value)}
            className="rounded-lg border border-white/[0.08] bg-white/[0.04] px-3 py-1.5 text-sm text-white/80"
          >
            <option value="">Tous les services</option>
            {services.map(s => (
              <option key={s.code} value={s.code}>{s.code}</option>
            ))}
          </select>

          <select
            value={filters.criticite}
            onChange={e => updateFilter("criticite", e.target.value)}
            className="rounded-lg border border-white/[0.08] bg-white/[0.04] px-3 py-1.5 text-sm text-white/80"
          >
            <option value="">Toutes criticités</option>
            <option value="Low">Low</option>
            <option value="Medium">Medium</option>
            <option value="High">High</option>
            <option value="Critical">Critical</option>
          </select>

          <input
            type="date"
            value={filters.dateFrom}
            onChange={e => updateFilter("dateFrom", e.target.value)}
            className="rounded-lg border border-white/[0.08] bg-white/[0.04] px-3 py-1.5 text-sm text-white/80"
            placeholder="Date début"
          />

          <input
            type="date"
            value={filters.dateTo}
            onChange={e => updateFilter("dateTo", e.target.value)}
            className="rounded-lg border border-white/[0.08] bg-white/[0.04] px-3 py-1.5 text-sm text-white/80"
            placeholder="Date fin"
          />

          {hasFilters && (
            <button onClick={clearFilters} className="flex items-center gap-1 rounded-lg px-3 py-1.5 text-sm text-white/40 hover:text-white/70">
              <X className="h-3 w-3" /> Effacer
            </button>
          )}
        </div>
      )}
    </div>
  );
}
