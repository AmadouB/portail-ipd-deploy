"use client";

import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { ChevronDown, ChevronRight, AlertCircle, CheckCircle2, Clock, Pencil, Search, X } from "lucide-react";
import { cn } from "@/lib/utils";

interface Ecart {
  id: number; numero: string; classification: string; statut: string;
  pctAvancement: number; capaHorsDelai: boolean; nomEcart: string; description: string;
  actionsCorrectives: string | null; analyseCauses: string | null;
  commentaires: string | null; commentaireAvancement: string | null;
  version: number; dateFinalisation: string | null; dateCloture: string | null;
  service: { code: string; libelle: string };
}

interface MacroEcart {
  id: number; numero: string; description: string; classification: string;
  nbEcartsEnfants: number; tauxCloture: number; ecarts: Ecart[];
}

const statutConfig: Record<string, { label: string; color: string; icon: any }> = {
  EN_COURS: { label: "En cours", color: "bg-[#EF7A16]/10 text-[#EF7A16] border-amber-500/20", icon: Clock },
  REVU: { label: "Revu", color: "bg-blue-500/10 text-blue-400 border-blue-500/20", icon: AlertCircle },
  CLOTURE: { label: "Cloture", color: "bg-[#27AE60]/10 text-[#27AE60] border-emerald-500/20", icon: CheckCircle2 },
};

const selectClass = "rounded-lg bg-white/[0.04] border border-white/[0.08] px-3 py-1.5 text-sm text-white/70 focus:outline-none focus:ring-1 focus:ring-cyan-500/50";
const inputClass = "bg-white/[0.04] border-white/[0.08] text-white placeholder:text-white/30 focus:ring-cyan-500/50 focus:border-[#0089D0]/50";

function StatutBadge({ statut }: { statut: string }) {
  const cfg = statutConfig[statut] || statutConfig.EN_COURS;
  const Icon = cfg.icon;
  return (
    <Badge variant="outline" className={cn("gap-1 text-[10px]", cfg.color)}>
      <Icon className="h-3 w-3" /> {cfg.label}
    </Badge>
  );
}

function EditEcartModal({ ecart, open, onClose, onSave }: { ecart: Ecart; open: boolean; onClose: () => void; onSave: () => void }) {
  const [form, setForm] = useState({
    statut: ecart.statut,
    pctAvancement: ecart.pctAvancement,
    classification: ecart.classification,
    capaHorsDelai: ecart.capaHorsDelai,
    description: ecart.description,
    actionsCorrectives: ecart.actionsCorrectives || "",
    analyseCauses: ecart.analyseCauses || "",
    commentaires: ecart.commentaires || "",
    commentaireAvancement: ecart.commentaireAvancement || "",
    version: ecart.version,
    dateFinalisation: ecart.dateFinalisation || "",
    dateCloture: ecart.dateCloture || "",
  });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    setForm({
      statut: ecart.statut, pctAvancement: ecart.pctAvancement, classification: ecart.classification,
      capaHorsDelai: ecart.capaHorsDelai, description: ecart.description,
      actionsCorrectives: ecart.actionsCorrectives || "", analyseCauses: ecart.analyseCauses || "",
      commentaires: ecart.commentaires || "", commentaireAvancement: ecart.commentaireAvancement || "",
      version: ecart.version, dateFinalisation: ecart.dateFinalisation || "", dateCloture: ecart.dateCloture || "",
    });
  }, [ecart]);

  const handleSave = async () => {
    setSaving(true);
    await fetch(`/api/ecarts/${ecart.id}`, {
      method: "PUT", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        ...form,
        dateFinalisation: form.dateFinalisation || null, dateCloture: form.dateCloture || null,
        actionsCorrectives: form.actionsCorrectives || null, analyseCauses: form.analyseCauses || null,
        commentaires: form.commentaires || null, commentaireAvancement: form.commentaireAvancement || null,
      }),
    });
    setSaving(false);
    onSave();
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-[#031A40] border-white/[0.08] text-white max-w-2xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-[#0089D0] font-mono">{ecart.numero} - {ecart.nomEcart}</DialogTitle>
        </DialogHeader>
        <div className="grid gap-4 py-2">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-white/60 text-xs">Statut</Label>
              <select value={form.statut} onChange={(e) => setForm({ ...form, statut: e.target.value })} className={cn("w-full mt-1", selectClass)}>
                <option value="EN_COURS">En cours</option>
                <option value="REVU">Revu</option>
                <option value="CLOTURE">Cloture</option>
              </select>
            </div>
            <div>
              <Label className="text-white/60 text-xs">Classification</Label>
              <select value={form.classification} onChange={(e) => setForm({ ...form, classification: e.target.value })} className={cn("w-full mt-1", selectClass)}>
                <option value="Majeur">Majeur</option>
                <option value="Mineur">Mineur</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-white/60 text-xs">Avancement: {Math.round(form.pctAvancement * 100)}%</Label>
              <Input type="range" min="0" max="1" step="0.05" value={form.pctAvancement} onChange={(e) => setForm({ ...form, pctAvancement: parseFloat(e.target.value) })} className="mt-1 accent-cyan-500" />
            </div>
            <div>
              <Label className="text-white/60 text-xs">Version</Label>
              <Input type="number" value={form.version} onChange={(e) => setForm({ ...form, version: parseInt(e.target.value) || 1 })} className={cn("mt-1", inputClass)} />
            </div>
          </div>

          <div className="flex items-center gap-3">
            <Switch checked={form.capaHorsDelai} onCheckedChange={(v) => setForm({ ...form, capaHorsDelai: v })} />
            <Label className="text-white/60 text-xs">CAPA Hors delai</Label>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-white/60 text-xs">Date finalisation</Label>
              <Input type="date" value={form.dateFinalisation} onChange={(e) => setForm({ ...form, dateFinalisation: e.target.value })} className={cn("mt-1", inputClass)} />
            </div>
            <div>
              <Label className="text-white/60 text-xs">Date cloture</Label>
              <Input type="date" value={form.dateCloture} onChange={(e) => setForm({ ...form, dateCloture: e.target.value })} className={cn("mt-1", inputClass)} />
            </div>
          </div>

          <div>
            <Label className="text-white/60 text-xs">Description</Label>
            <Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} rows={2} className={cn("mt-1", inputClass)} />
          </div>
          <div>
            <Label className="text-white/60 text-xs">Actions correctives</Label>
            <Textarea value={form.actionsCorrectives} onChange={(e) => setForm({ ...form, actionsCorrectives: e.target.value })} rows={2} className={cn("mt-1", inputClass)} />
          </div>
          <div>
            <Label className="text-white/60 text-xs">Analyse des causes</Label>
            <Textarea value={form.analyseCauses} onChange={(e) => setForm({ ...form, analyseCauses: e.target.value })} rows={2} className={cn("mt-1", inputClass)} />
          </div>
          <div>
            <Label className="text-white/60 text-xs">Commentaire avancement</Label>
            <Textarea value={form.commentaireAvancement} onChange={(e) => setForm({ ...form, commentaireAvancement: e.target.value })} rows={2} className={cn("mt-1", inputClass)} />
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <Button variant="outline" onClick={onClose} className="border-white/10 text-white/60 hover:bg-white/5">Annuler</Button>
            <Button onClick={handleSave} disabled={saving} className="bg-cyan-600 hover:bg-cyan-700 text-white">
              {saving ? "Enregistrement..." : "Enregistrer"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export function EcartsContent() {
  const [data, setData] = useState<{ macroEcarts: MacroEcart[]; ecarts: Ecart[] } | null>(null);
  const [expanded, setExpanded] = useState<Set<number>>(new Set());
  const [filter, setFilter] = useState({ service: "", statut: "", capa: "", classification: "", macroEcart: "", search: "" });
  const [editEcart, setEditEcart] = useState<Ecart | null>(null);

  const reload = () => fetch("/api/ecarts").then((r) => r.json()).then(setData);
  useEffect(() => { reload(); }, []);

  if (!data) return <div className="flex items-center justify-center h-64 text-white/40">Chargement...</div>;

  const toggle = (id: number) => {
    const next = new Set(expanded);
    next.has(id) ? next.delete(id) : next.add(id);
    setExpanded(next);
  };

  const filteredEcarts = (ecarts: Ecart[]) => ecarts.filter((e) => {
    if (filter.service && e.service.code !== filter.service) return false;
    if (filter.statut && e.statut !== filter.statut) return false;
    if (filter.capa === "oui" && !e.capaHorsDelai) return false;
    if (filter.capa === "non" && e.capaHorsDelai) return false;
    if (filter.classification && e.classification !== filter.classification) return false;
    if (filter.search && !e.nomEcart.toLowerCase().includes(filter.search.toLowerCase()) && !e.numero.toLowerCase().includes(filter.search.toLowerCase())) return false;
    return true;
  });

  const services = [...new Set(data.ecarts.map((e) => e.service.code))];
  const hasActiveFilters = Object.values(filter).some(Boolean);

  return (
    <div className="space-y-4">
      <div className="flex gap-3 flex-wrap items-center">
        <div className="relative">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-white/30" />
          <input value={filter.search} onChange={(e) => setFilter({ ...filter, search: e.target.value })} placeholder="Rechercher..." className={cn("pl-8 w-52", selectClass)} />
        </div>
        <select value={filter.service} onChange={(e) => setFilter({ ...filter, service: e.target.value })} className={selectClass}>
          <option value="">Tous les services</option>
          {services.map((s) => <option key={s} value={s}>{s}</option>)}
        </select>
        <select value={filter.statut} onChange={(e) => setFilter({ ...filter, statut: e.target.value })} className={selectClass}>
          <option value="">Tous les statuts</option>
          <option value="EN_COURS">En cours</option>
          <option value="REVU">Revu</option>
          <option value="CLOTURE">Cloture</option>
        </select>
        <select value={filter.classification} onChange={(e) => setFilter({ ...filter, classification: e.target.value })} className={selectClass}>
          <option value="">Toutes classifications</option>
          <option value="Majeur">Majeur</option>
          <option value="Mineur">Mineur</option>
        </select>
        <select value={filter.capa} onChange={(e) => setFilter({ ...filter, capa: e.target.value })} className={selectClass}>
          <option value="">Tous CAPA</option>
          <option value="oui">Hors delai</option>
          <option value="non">On-time</option>
        </select>
        <select value={filter.macroEcart} onChange={(e) => setFilter({ ...filter, macroEcart: e.target.value })} className={selectClass}>
          <option value="">Tous macro-ecarts</option>
          {data.macroEcarts.map((m) => <option key={m.id} value={String(m.id)}>{m.numero}</option>)}
        </select>
        {hasActiveFilters && (
          <button onClick={() => setFilter({ service: "", statut: "", capa: "", classification: "", macroEcart: "", search: "" })} className="flex items-center gap-1 text-xs text-red-400 hover:text-red-300">
            <X className="h-3 w-3" /> Reinitialiser
          </button>
        )}
      </div>

      {data.macroEcarts
        .filter((m) => !filter.macroEcart || String(m.id) === filter.macroEcart)
        .map((macro) => {
          const isExpanded = expanded.has(macro.id);
          const children = filteredEcarts(macro.ecarts);
          if (hasActiveFilters && children.length === 0 && !filter.macroEcart) return null;
          const childrenClotures = children.filter((e) => e.statut === "CLOTURE").length;
          return (
            <Card key={macro.id} className="glass border-white/[0.08] overflow-hidden">
              <button onClick={() => toggle(macro.id)} className="w-full text-left">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      {isExpanded ? <ChevronDown className="h-4 w-4 text-white/40" /> : <ChevronRight className="h-4 w-4 text-white/40" />}
                      <Badge variant="outline" className={macro.classification === "Majeur" ? "bg-red-500/10 text-red-400 border-red-500/20" : "bg-[#EF7A16]/10 text-[#EF7A16] border-amber-500/20"}>
                        {macro.classification}
                      </Badge>
                      <CardTitle className="text-sm text-white/90">
                        <span className="text-[#0089D0] font-mono mr-2">{macro.numero}</span>
                        {macro.description.substring(0, 80)}...
                      </CardTitle>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="text-xs text-white/40">{childrenClotures}/{children.length}</span>
                      <div className="w-20">
                        <Progress value={children.length > 0 ? (childrenClotures / children.length) * 100 : 0} className="h-1.5 bg-white/[0.06]" />
                      </div>
                    </div>
                  </div>
                </CardHeader>
              </button>
              {isExpanded && (
                <CardContent className="pt-0">
                  <div className="border-t border-white/[0.06] pt-3">
                    <table className="w-full">
                      <thead>
                        <tr className="text-[10px] text-white/30 uppercase tracking-wider">
                          <th className="text-left py-2 px-2">Ref</th>
                          <th className="text-left py-2 px-2">Ecart</th>
                          <th className="text-left py-2 px-2">Service</th>
                          <th className="text-left py-2 px-2">Statut</th>
                          <th className="text-left py-2 px-2">Avancement</th>
                          <th className="text-left py-2 px-2">CAPA</th>
                          <th className="text-left py-2 px-2">Ver.</th>
                          <th className="text-right py-2 px-2">Edit</th>
                        </tr>
                      </thead>
                      <tbody>
                        {children.map((e) => (
                          <tr key={e.id} className="border-t border-white/[0.03] hover:bg-white/[0.02] transition-colors">
                            <td className="py-2 px-2 text-xs font-mono text-[#0089D0]">{e.numero}</td>
                            <td className="py-2 px-2 text-xs text-white/70 max-w-[250px] truncate">{e.nomEcart}</td>
                            <td className="py-2 px-2"><Badge variant="outline" className="text-[10px] border-white/10 text-white/50">{e.service.code}</Badge></td>
                            <td className="py-2 px-2"><StatutBadge statut={e.statut} /></td>
                            <td className="py-2 px-2">
                              <div className="flex items-center gap-2">
                                <div className="w-16 h-1.5 rounded-full bg-white/[0.06]">
                                  <div className="h-full rounded-full bg-[#0089D0]/60" style={{ width: `${e.pctAvancement * 100}%` }} />
                                </div>
                                <span className="text-[10px] text-white/40">{Math.round(e.pctAvancement * 100)}%</span>
                              </div>
                            </td>
                            <td className="py-2 px-2">
                              {e.capaHorsDelai ? <Badge variant="outline" className="text-[10px] bg-red-500/10 text-red-400 border-red-500/20">Hors delai</Badge> : <Badge variant="outline" className="text-[10px] bg-[#27AE60]/10 text-[#27AE60] border-emerald-500/20">On-time</Badge>}
                            </td>
                            <td className="py-2 px-2 text-xs text-white/30">v{e.version}</td>
                            <td className="py-2 px-2 text-right">
                              <button onClick={(ev) => { ev.stopPropagation(); setEditEcart(e); }} className="p-1 rounded hover:bg-white/[0.06] text-white/30 hover:text-[#0089D0] transition-colors">
                                <Pencil className="h-3.5 w-3.5" />
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              )}
            </Card>
          );
        })}

      {editEcart && (
        <EditEcartModal ecart={editEcart} open={!!editEcart} onClose={() => setEditEcart(null)} onSave={reload} />
      )}
    </div>
  );
}
