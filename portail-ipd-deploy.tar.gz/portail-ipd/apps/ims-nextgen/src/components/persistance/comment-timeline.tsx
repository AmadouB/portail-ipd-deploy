"use client";

import { useEffect, useState } from "react";
import { StagnationBadge } from "./stagnation-badge";
import { MessageSquare, CheckCircle2, ArrowRight } from "lucide-react";

interface CommentChainItem {
  id: number;
  texte: string;
  semaineIso: string;
  semainesPersistance: number;
  isResolved: boolean;
  resolvedAt?: string;
  createdAt: string;
  createdBy: { name: string };
  resolvedBy?: { name: string };
  parentCommentId?: number | null;
}

interface Props {
  actionId?: number;
  ecartId?: number;
}

export function CommentTimeline({ actionId, ecartId }: Props) {
  const [comments, setComments] = useState<CommentChainItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const params = new URLSearchParams();
    if (actionId) params.set("actionId", String(actionId));
    if (ecartId) params.set("ecartId", String(ecartId));

    fetch(`/api/comments?${params}`)
      .then(r => r.json())
      .then(d => setComments(d.comments || []))
      .finally(() => setLoading(false));
  }, [actionId, ecartId]);

  if (loading) return <div className="text-sm text-white/40 py-4">Chargement de la timeline...</div>;
  if (comments.length === 0) return <div className="text-sm text-white/40 py-4">Aucun commentaire enregistré.</div>;

  // Grouper par semaineIso et trier chronologiquement
  const sorted = [...comments].sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());

  return (
    <div className="relative">
      {/* Ligne verticale */}
      <div className="absolute left-4 top-0 bottom-0 w-0.5 bg-white/[0.08]" />

      <div className="space-y-4">
        {sorted.map((comment, idx) => (
          <div key={comment.id} className="relative flex gap-4 pl-10">
            {/* Dot on timeline */}
            <div className={`absolute left-[11px] top-2 h-3 w-3 rounded-full border-2 ${
              comment.isResolved
                ? "bg-[#27AE60] border-[#27AE60]/30"
                : comment.semainesPersistance >= 8
                  ? "bg-[#E74C3C] border-[#E74C3C]/30 animate-pulse"
                  : comment.semainesPersistance >= 5
                    ? "bg-[#EF7A16] border-[#EF7A16]/30"
                    : comment.semainesPersistance >= 3
                      ? "bg-[#FFD500] border-[#FFD500]/30"
                      : "bg-[#0089D0] border-[#0089D0]/30"
            }`} />

            <div className="flex-1 rounded-lg border border-white/[0.06] bg-white/[0.03] p-3 space-y-2">
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-semibold text-white/60">{comment.semaineIso}</span>
                  {comment.semainesPersistance > 0 && (
                    <StagnationBadge weeks={comment.semainesPersistance} />
                  )}
                </div>
                {comment.isResolved ? (
                  <span className="flex items-center gap-1 text-xs text-[#27AE60]">
                    <CheckCircle2 className="h-3 w-3" /> Résolu
                  </span>
                ) : (
                  <span className="text-xs text-white/30">En cours</span>
                )}
              </div>

              <p className="text-sm text-white/80 leading-relaxed">{comment.texte}</p>

              <div className="flex items-center gap-3 text-[11px] text-white/30">
                <span className="flex items-center gap-1">
                  <MessageSquare className="h-3 w-3" /> {comment.createdBy.name}
                </span>
                <span>{new Date(comment.createdAt).toLocaleDateString("fr-FR")}</span>
                {comment.isResolved && comment.resolvedBy && (
                  <span className="text-[#27AE60]">Résolu par {comment.resolvedBy.name}</span>
                )}
              </div>

              {idx < sorted.length - 1 && sorted[idx + 1].parentCommentId === comment.id && (
                <div className="flex items-center gap-1 text-[10px] text-white/20 pt-1">
                  <ArrowRight className="h-3 w-3" /> Reporté à la semaine suivante
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
