"use client";

import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Timer, Play, AlertTriangle, CheckCircle2, Clock, TrendingUp, RefreshCw } from "lucide-react";
import { StagnationBadge } from "./stagnation-badge";

interface PersistenceStatus {
  lastJob: any;
  currentWeek: string;
  stagnationSummary: { green: number; yellow: number; orange: number; red: number };
  avgResolutionWeeks: number;
  totalOpenActions: number;
  totalOpenEcarts: number;
  totalUnresolved: number;
}

export function PersistanceContent() {
  const [status, setStatus] = useState<PersistenceStatus | null>(null);
  const [loading, setLoading] = useState(true);
  const [running, setRunning] = useState(false);

  const fetchStatus = () => {
    setLoading(true);
    fetch("/api/persistence/status")
      .then(r => r.json())
      .then(setStatus)
      .finally(() => setLoading(false));
  };

  useEffect(() => { fetchStatus(); }, []);

  const runJob = async () => {
    setRunning(true);
    try {
      const res = await fetch("/api/persistence/run", { method: "POST" });
      const data = await res.json();
      if (data.success) {
        fetchStatus();
      }
    } finally {
      setRunning(false);
    }
  };

  if (loading) return <div className="p-8 text-white/40">Chargement...</div>;
  if (!status) return <div className="p-8 text-white/40">Erreur de chargement</div>;

  const { stagnationSummary: s } = status;
  const totalTracked = s.green + s.yellow + s.orange + s.red;
  const stagnationIndex = totalTracked > 0 ? Math.round((s.red / totalTracked) * 100) : 0;

  return (
    <div className="p-6 space-y-6">
      {/* Header Actions */}
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm text-white/50">Semaine en cours : <span className="text-white font-semibold">{status.currentWeek}</span></p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={fetchStatus}
            className="flex items-center gap-2 rounded-lg border border-white/[0.08] bg-white/[0.04] px-3 py-2 text-sm text-white/70 hover:bg-white/[0.08] transition-colors"
          >
            <RefreshCw className="h-4 w-4" /> Actualiser
          </button>
          <button
            onClick={runJob}
            disabled={running}
            className="flex items-center gap-2 rounded-lg bg-[#0089D0] px-4 py-2 text-sm font-semibold text-white hover:bg-[#0089D0]/80 transition-colors disabled:opacity-50"
          >
            <Play className="h-4 w-4" /> {running ? "Exécution..." : "Exécuter maintenant"}
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="glass glow-cyan">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-white/55 uppercase tracking-wider font-medium">Commentaires suivis</p>
                <p className="text-3xl font-bold text-white mt-1">{totalTracked}</p>
              </div>
              <Timer className="h-8 w-8 text-[#0089D0]/60" />
            </div>
          </CardContent>
        </Card>

        <Card className="glass glow-emerald">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-white/55 uppercase tracking-wider font-medium">Durée moy. résolution</p>
                <p className="text-3xl font-bold text-white mt-1">{status.avgResolutionWeeks}<span className="text-lg text-white/40"> sem</span></p>
              </div>
              <Clock className="h-8 w-8 text-[#27AE60]/60" />
            </div>
            <p className="text-sm text-white/45 mt-2">Cible : &lt; 4 semaines</p>
          </CardContent>
        </Card>

        <Card className="glass glow-amber">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-white/55 uppercase tracking-wider font-medium">Indice stagnation</p>
                <p className="text-3xl font-bold text-white mt-1">{stagnationIndex}<span className="text-lg text-white/40">%</span></p>
              </div>
              <TrendingUp className="h-8 w-8 text-[#EF7A16]/60" />
            </div>
            <p className="text-sm text-white/45 mt-2">Cible : &lt; 5%</p>
          </CardContent>
        </Card>

        <Card className="glass glow-red">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-white/55 uppercase tracking-wider font-medium">Alertes critiques</p>
                <p className="text-3xl font-bold text-white mt-1">{s.red}</p>
              </div>
              <AlertTriangle className="h-8 w-8 text-[#E74C3C]/60" />
            </div>
            <p className="text-sm text-white/45 mt-2">Actions &gt; 8 semaines</p>
          </CardContent>
        </Card>
      </div>

      {/* Stagnation Summary */}
      <Card className="glass">
        <CardHeader>
          <CardTitle className="text-lg text-white">Répartition par niveau de stagnation</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-4 gap-4">
            {[
              { level: "GREEN" as const, count: s.green, label: "1-2 sem", sublabel: "Suivi normal", color: "#27AE60" },
              { level: "YELLOW" as const, count: s.yellow, label: "3-4 sem", sublabel: "Notification responsable", color: "#FFD500" },
              { level: "ORANGE" as const, count: s.orange, label: "5-7 sem", sublabel: "Escalade département", color: "#EF7A16" },
              { level: "RED" as const, count: s.red, label: "8+ sem", sublabel: "Alerte critique", color: "#E74C3C" },
            ].map(item => (
              <div key={item.level} className="rounded-xl border border-white/[0.06] bg-white/[0.03] p-4 text-center">
                <div className="mx-auto mb-2 h-3 w-3 rounded-full" style={{ backgroundColor: item.color }} />
                <p className="text-2xl font-bold text-white">{item.count}</p>
                <p className="text-xs font-medium text-white/60 mt-1">{item.label}</p>
                <p className="text-[10px] text-white/30">{item.sublabel}</p>
              </div>
            ))}
          </div>

          {/* Progress bar */}
          {totalTracked > 0 && (
            <div className="mt-6">
              <div className="flex h-3 rounded-full overflow-hidden bg-white/[0.04]">
                {s.green > 0 && <div className="bg-[#27AE60]" style={{ width: `${(s.green / totalTracked) * 100}%` }} />}
                {s.yellow > 0 && <div className="bg-[#FFD500]" style={{ width: `${(s.yellow / totalTracked) * 100}%` }} />}
                {s.orange > 0 && <div className="bg-[#EF7A16]" style={{ width: `${(s.orange / totalTracked) * 100}%` }} />}
                {s.red > 0 && <div className="bg-[#E74C3C]" style={{ width: `${(s.red / totalTracked) * 100}%` }} />}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Dernier Job */}
      <Card className="glass">
        <CardHeader>
          <CardTitle className="text-lg text-white">Dernier job de persistance</CardTitle>
        </CardHeader>
        <CardContent>
          {status.lastJob ? (
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
              <div>
                <p className="text-xs text-white/40">Semaine</p>
                <p className="text-sm font-semibold text-white">{status.lastJob.semaineIso}</p>
              </div>
              <div>
                <p className="text-xs text-white/40">Statut</p>
                <Badge className={status.lastJob.status === "COMPLETED" ? "bg-[#27AE60]/15 text-[#27AE60]" : "bg-[#E74C3C]/15 text-[#E74C3C]"}>
                  {status.lastJob.status}
                </Badge>
              </div>
              <div>
                <p className="text-xs text-white/40">Actions traitées</p>
                <p className="text-sm font-semibold text-white">{status.lastJob.actionsProcessed}</p>
              </div>
              <div>
                <p className="text-xs text-white/40">Commentaires reportés</p>
                <p className="text-sm font-semibold text-white">{status.lastJob.commentsCarried}</p>
              </div>
              <div>
                <p className="text-xs text-white/40">Alertes déclenchées</p>
                <p className="text-sm font-semibold text-white">{status.lastJob.alertsTriggered}</p>
              </div>
            </div>
          ) : (
            <p className="text-sm text-white/40">Aucun job exécuté pour le moment.</p>
          )}
        </CardContent>
      </Card>

      {/* Open items summary */}
      <div className="grid grid-cols-2 gap-4">
        <Card className="glass">
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-[#0089D0]/10">
                <CheckCircle2 className="h-5 w-5 text-[#0089D0]" />
              </div>
              <div>
                <p className="text-xs text-white/40">Actions ouvertes</p>
                <p className="text-xl font-bold text-white">{status.totalOpenActions}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="glass">
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-[#EF7A16]/10">
                <AlertTriangle className="h-5 w-5 text-[#EF7A16]" />
              </div>
              <div>
                <p className="text-xs text-white/40">Écarts ouverts</p>
                <p className="text-xl font-bold text-white">{status.totalOpenEcarts}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
