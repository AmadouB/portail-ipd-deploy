"use client";

import { cn } from "@/lib/utils";

type StagnationLevel = "GREEN" | "YELLOW" | "ORANGE" | "RED";

const LEVEL_CONFIG: Record<StagnationLevel, { bg: string; text: string; label: string }> = {
  GREEN: { bg: "bg-[#27AE60]/15", text: "text-[#27AE60]", label: "Normal" },
  YELLOW: { bg: "bg-[#FFD500]/15", text: "text-[#FFD500]", label: "Attention" },
  ORANGE: { bg: "bg-[#EF7A16]/15", text: "text-[#EF7A16]", label: "Escalade" },
  RED: { bg: "bg-[#E74C3C]/15", text: "text-[#E74C3C]", label: "Critique" },
};

function getLevel(weeks: number): StagnationLevel {
  if (weeks >= 8) return "RED";
  if (weeks >= 5) return "ORANGE";
  if (weeks >= 3) return "YELLOW";
  return "GREEN";
}

export function StagnationBadge({ weeks, className }: { weeks: number; className?: string }) {
  const level = getLevel(weeks);
  const config = LEVEL_CONFIG[level];
  return (
    <span className={cn("inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-xs font-semibold", config.bg, config.text, className)}>
      <span className={cn("h-1.5 w-1.5 rounded-full", level === "RED" ? "animate-pulse" : "", `bg-current`)} />
      {weeks}s — {config.label}
    </span>
  );
}

export function StagnationDot({ weeks, className }: { weeks: number; className?: string }) {
  const level = getLevel(weeks);
  const colors: Record<StagnationLevel, string> = {
    GREEN: "bg-[#27AE60]",
    YELLOW: "bg-[#FFD500]",
    ORANGE: "bg-[#EF7A16]",
    RED: "bg-[#E74C3C] animate-pulse",
  };
  return <span className={cn("inline-block h-2.5 w-2.5 rounded-full", colors[level], className)} />;
}
