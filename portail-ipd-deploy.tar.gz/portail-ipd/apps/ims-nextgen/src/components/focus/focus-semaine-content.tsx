"use client";

import { useEffect, useState } from "react";
import {
  TrendingUp, TrendingDown, CheckCircle2, AlertTriangle, Clock,
  ArrowUp, ArrowDown, Minus, MessageSquare, Calendar, Target,
  ChevronRight, AlertCircle, Flame,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface FocusData {
  semaine: string;
  semainePrecedente: string;
  tauxCloture: number;
  totalEcarts: number;
  totalClotures: number;
  enCours: number;
  avancees: any[];
  cloturesCetteSemaine: any[];
  retards: any[];
  snapshotDates: string[];
}

function ProgressArrow({ marge }: { marge: number }) {
  if (marge > 0) return <ArrowUp className="w-4 h-4 text-[#27AE60]" />;
  if (marge < 0) return <ArrowDown className="w-4 h-4 text-red-400" />;
  return <Minus className="w-3.5 h-3.5 text-white/20" />;
}

function ProgressBar({ pct, prev, color }: { pct: number; prev?: number; color?: string }) {
  return (
    <div className="relative h-2 rounded-full bg-white/[0.06] overflow-hidden">
      {prev !== undefined && prev < pct && (
        <div className="absolute h-full rounded-full bg-white/[0.08]" style={{ width: `${prev * 100}%` }} />
      )}
      <div className={`absolute h-full rounded-full ${color || "bg-[#0089D0]/70"}`} style={{ width: `${pct * 100}%` }} />
    </div>
  );
}

export function FocusSemaineContent() {
  const [data, setData] = useState<FocusData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/focus-semaine")
      .then((r) => r.json())
      .then((d) => { setData(d); setLoading(false); })
      .catch(() => setLoading(false));
  }, []);

  if (loading) return <div className="flex items-center justify-center h-64 text-white/40">Chargement...</div>;
  if (!data) return <div className="text-white/40 text-center py-20">Aucune donnee disponible</div>;

  const stagnants = data.retards.filter((r) => r.stagnant);
  const enProgression = data.retards.filter((r) => !r.stagnant && r.margeProgression > 0);

  return (
    <div className="space-y-6">
      {/* Header stats */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <Card className="glass glow-cyan border-white/[0.08]">
          <CardContent className="p-4 text-center">
            <Calendar className="w-5 h-5 text-[#0089D0] mx-auto mb-2" />
            <p className="text-lg font-bold text-white">{data.semaine ? new Date(data.semaine).toLocaleDateString("fr-FR", { day: "numeric", month: "short", year: "numeric" }) : "N/A"}</p>
            <p className="text-[10px] text-white/30 uppercase">Semaine en cours</p>
          </CardContent>
        </Card>
        <Card className="glass glow-emerald border-white/[0.08]">
          <CardContent className="p-4 text-center">
            <CheckCircle2 className="w-5 h-5 text-[#27AE60] mx-auto mb-2" />
            <p className="text-2xl font-bold text-[#27AE60]">{data.tauxCloture}%</p>
            <p className="text-[10px] text-white/30 uppercase">Taux cloture</p>
          </CardContent>
        </Card>
        <Card className="glass border-white/[0.08]">
          <CardContent className="p-4 text-center">
            <TrendingUp className="w-5 h-5 text-[#0089D0] mx-auto mb-2" />
            <p className="text-2xl font-bold text-[#0089D0]">{data.avancees.length}</p>
            <p className="text-[10px] text-white/30 uppercase">Avancees</p>
          </CardContent>
        </Card>
        <Card className="glass border-white/[0.08]">
          <CardContent className="p-4 text-center">
            <CheckCircle2 className="w-5 h-5 text-[#27AE60] mx-auto mb-2" />
            <p className="text-2xl font-bold text-[#27AE60]">{data.cloturesCetteSemaine.length}</p>
            <p className="text-[10px] text-white/30 uppercase">Clotures cette semaine</p>
          </CardContent>
        </Card>
        <Card className="glass glow-red border-white/[0.08]">
          <CardContent className="p-4 text-center">
            <AlertTriangle className="w-5 h-5 text-red-400 mx-auto mb-2" />
            <p className="text-2xl font-bold text-red-400">{data.enCours}</p>
            <p className="text-[10px] text-white/30 uppercase">Encore ouverts</p>
          </CardContent>
        </Card>
      </div>

      {/* ===== AVANCEES DE LA SEMAINE ===== */}
      <Card className="glass border-emerald-500/20">
        <CardHeader className="pb-3">
          <CardTitle className="text-base text-[#27AE60] flex items-center gap-2">
            <TrendingUp className="w-5 h-5" />
            Avancees de la semaine
            <Badge className="bg-[#27AE60]/20 text-[#27AE60] text-xs ml-2">{data.avancees.length}</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {data.avancees.length === 0 ? (
            <p className="text-sm text-white/30 text-center py-4">Aucune avancee cette semaine</p>
          ) : (
            <div className="space-y-3">
              {data.avancees.map((a, i) => (
                <div key={`${a.numero}-${i}-av`} className="rounded-xl bg-white/[0.03] border border-emerald-500/10 p-4 space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-semibold text-white">{a.numero}</span>
                      <Badge variant="outline" className="text-[10px] border-white/10 text-white/40">{a.service}</Badge>
                      <Badge variant="outline" className="text-[10px] border-white/10 text-white/30">ME {a.macroEcart}</Badge>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="flex items-center gap-1 text-[#27AE60]">
                        <ArrowUp className="w-3.5 h-3.5" />
                        <span className="text-sm font-bold">+{Math.round(a.margeProgression * 100)}%</span>
                      </div>
                      <Badge className={a.statut === "CLOTURE" ? "bg-[#27AE60]/20 text-[#27AE60] text-[10px]" : "bg-[#EF7A16]/20 text-[#EF7A16] text-[10px]"}>
                        {a.statut === "CLOTURE" ? "Cloture" : "En cours"}
                      </Badge>
                    </div>
                  </div>
                  <p className="text-xs text-white/50 line-clamp-1">{a.nomEcart}</p>
                  <div className="flex items-center gap-3">
                    <span className="text-[10px] text-white/30">{Math.round(a.pctPrecedent * 100)}%</span>
                    <div className="flex-1">
                      <ProgressBar pct={a.pctAvancement} prev={a.pctPrecedent} color="bg-[#27AE60]/70" />
                    </div>
                    <span className="text-xs font-medium text-[#27AE60]">{Math.round(a.pctAvancement * 100)}%</span>
                  </div>
                  {a.commentaire && (
                    <div className="flex items-start gap-1.5 mt-1">
                      <MessageSquare className="w-3 h-3 text-[#27AE60]/40 mt-0.5 shrink-0" />
                      <p className="text-[11px] text-white/40 line-clamp-2">{a.commentaire}</p>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* ===== CLOTURES CETTE SEMAINE ===== */}
      {data.cloturesCetteSemaine.length > 0 && (
        <Card className="glass border-emerald-500/20">
          <CardHeader className="pb-3">
            <CardTitle className="text-base text-[#27AE60] flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5" />
              Ecarts clotures cette semaine
              <Badge className="bg-[#27AE60]/20 text-[#27AE60] text-xs ml-2">{data.cloturesCetteSemaine.length}</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {data.cloturesCetteSemaine.map((c) => (
                <div key={`${c.numero}-cl`} className="rounded-xl bg-[#27AE60]/[0.04] border border-emerald-500/10 p-3 flex items-center gap-3">
                  <CheckCircle2 className="w-5 h-5 text-[#27AE60] shrink-0" />
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-semibold text-white">{c.numero}</span>
                      <Badge className={c.classification === "Majeur" ? "bg-red-500/20 text-red-400 text-[10px]" : "bg-[#EF7A16]/20 text-[#EF7A16] text-[10px]"}>
                        {c.classification}
                      </Badge>
                    </div>
                    <p className="text-xs text-white/40 truncate">{c.nomEcart}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* ===== RETARDS & ECARTS EN SOUFFRANCE ===== */}
      <Card className="glass border-red-500/20">
        <CardHeader className="pb-3">
          <CardTitle className="text-base text-red-400 flex items-center gap-2">
            <Flame className="w-5 h-5" />
            Ecarts en retard / en souffrance
            <Badge className="bg-red-500/20 text-red-400 text-xs ml-2">{data.retards.length}</Badge>
          </CardTitle>
          <p className="text-xs text-white/30 mt-1">Ecarts ouverts tries par avancement croissant — les plus en retard en premier</p>
        </CardHeader>
        <CardContent>
          {data.retards.length === 0 ? (
            <p className="text-sm text-[#27AE60]/60 text-center py-6">Tous les ecarts sont clotures !</p>
          ) : (
            <div className="space-y-3">
              {data.retards.map((r, idx) => (
                <div key={`${r.numero}-ret`} className={`rounded-xl p-4 space-y-2 border ${r.stagnant ? "bg-red-500/[0.04] border-red-500/20" : "bg-white/[0.03] border-amber-500/15"}`}>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {idx < 3 && <Flame className="w-4 h-4 text-red-400" />}
                      <span className="text-sm font-semibold text-white">{r.numero}</span>
                      <Badge variant="outline" className="text-[10px] border-white/10 text-white/40">{r.service}</Badge>
                      <Badge className={r.classification === "Majeur" ? "bg-red-500/20 text-red-400 text-[10px]" : "bg-[#EF7A16]/20 text-[#EF7A16] text-[10px]"}>
                        {r.classification}
                      </Badge>
                      {r.capaHorsDelai && <Badge className="bg-red-500/20 text-red-400 text-[10px]">CAPA HD</Badge>}
                    </div>
                    <div className="flex items-center gap-2">
                      {r.stagnant ? (
                        <Badge className="bg-red-500/20 text-red-400 text-[10px]">
                          <AlertCircle className="w-3 h-3 mr-1" /> Stagnant
                        </Badge>
                      ) : r.margeProgression > 0 ? (
                        <div className="flex items-center gap-1 text-[#27AE60]">
                          <ArrowUp className="w-3 h-3" />
                          <span className="text-[11px] font-bold">+{Math.round(r.margeProgression * 100)}%</span>
                        </div>
                      ) : null}
                      <span className="text-xs text-white/30">v{r.version}</span>
                    </div>
                  </div>
                  <p className="text-xs text-white/50 line-clamp-1">{r.nomEcart}</p>

                  {/* Progress bar with previous week ghost */}
                  <div className="flex items-center gap-3">
                    <span className="text-[10px] text-white/20 w-8">{Math.round(r.pctPrecedent * 100)}%</span>
                    <div className="flex-1">
                      <ProgressBar pct={r.pctAvancement} prev={r.pctPrecedent} color={r.stagnant ? "bg-red-500/60" : "bg-[#EF7A16]/60"} />
                    </div>
                    <span className={`text-xs font-bold ${r.pctAvancement < 0.5 ? "text-red-400" : "text-[#EF7A16]"}`}>
                      {Math.round(r.pctAvancement * 100)}%
                    </span>
                  </div>

                  {/* Dates */}
                  {(r.dateFinalisation || r.dateFinalisationRevue) && (
                    <div className="flex gap-4 text-[10px] text-white/25">
                      {r.dateFinalisation && <span>Deadline: {r.dateFinalisation}</span>}
                      {r.dateFinalisationRevue && <span>Revisee: {r.dateFinalisationRevue}</span>}
                    </div>
                  )}

                  {/* Points bloquants */}
                  {r.pointsBloquants && (
                    <div className="flex items-start gap-1.5 rounded-lg bg-red-500/[0.06] p-2 mt-1">
                      <AlertTriangle className="w-3 h-3 text-red-400 mt-0.5 shrink-0" />
                      <p className="text-[11px] text-red-400/70">{r.pointsBloquants}</p>
                    </div>
                  )}

                  {/* Commentaire */}
                  {r.commentaire && (
                    <div className="flex items-start gap-1.5 mt-1">
                      <MessageSquare className="w-3 h-3 text-white/20 mt-0.5 shrink-0" />
                      <p className="text-[11px] text-white/35 line-clamp-3">{r.commentaire}</p>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* ===== RESUME RAPIDE ===== */}
      <Card className="glass border-white/[0.08]">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm text-white/70">Resume hebdomadaire</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="rounded-xl bg-[#27AE60]/[0.04] border border-emerald-500/15 p-4">
              <p className="text-xs text-[#27AE60] font-medium mb-2">Points positifs</p>
              <ul className="space-y-1.5 text-xs text-white/50">
                <li className="flex items-start gap-1.5"><CheckCircle2 className="w-3 h-3 text-[#27AE60] mt-0.5 shrink-0" /> {data.totalClotures}/{data.totalEcarts} ecarts clotures ({data.tauxCloture}%)</li>
                {data.avancees.length > 0 && <li className="flex items-start gap-1.5"><TrendingUp className="w-3 h-3 text-[#27AE60] mt-0.5 shrink-0" /> {data.avancees.length} ecart(s) en progression cette semaine</li>}
                {data.cloturesCetteSemaine.length > 0 && <li className="flex items-start gap-1.5"><CheckCircle2 className="w-3 h-3 text-[#27AE60] mt-0.5 shrink-0" /> {data.cloturesCetteSemaine.length} ecart(s) nouvellement cloture(s)</li>}
              </ul>
            </div>
            <div className="rounded-xl bg-red-500/[0.04] border border-red-500/15 p-4">
              <p className="text-xs text-red-400 font-medium mb-2">Points d'attention</p>
              <ul className="space-y-1.5 text-xs text-white/50">
                <li className="flex items-start gap-1.5"><AlertTriangle className="w-3 h-3 text-red-400 mt-0.5 shrink-0" /> {data.enCours} ecart(s) encore ouvert(s)</li>
                {stagnants.length > 0 && <li className="flex items-start gap-1.5"><AlertCircle className="w-3 h-3 text-red-400 mt-0.5 shrink-0" /> {stagnants.length} ecart(s) stagnant(s) sans progression</li>}
                {data.retards.filter((r) => r.pctAvancement < 0.5).length > 0 && (
                  <li className="flex items-start gap-1.5"><Flame className="w-3 h-3 text-red-400 mt-0.5 shrink-0" /> {data.retards.filter((r) => r.pctAvancement < 0.5).length} ecart(s) en dessous de 50%</li>
                )}
              </ul>
            </div>
            <div className="rounded-xl bg-white/[0.03] border border-white/[0.06] p-4">
              <p className="text-xs text-white/50 font-medium mb-2">Ecarts les plus en retard</p>
              <ul className="space-y-2">
                {data.retards.slice(0, 3).map((r) => (
                  <li key={r.numero} className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-1.5">
                      <Flame className="w-3 h-3 text-red-400 shrink-0" />
                      <span className="text-white/60">{r.numero}</span>
                    </div>
                    <span className={`font-bold ${r.pctAvancement < 0.5 ? "text-red-400" : "text-[#EF7A16]"}`}>
                      {Math.round(r.pctAvancement * 100)}%
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
