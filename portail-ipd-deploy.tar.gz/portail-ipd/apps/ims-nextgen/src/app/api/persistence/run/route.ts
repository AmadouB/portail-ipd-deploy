import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { runPersistenceJob, getIsoWeek } from "@/lib/persistence";

// Force runtime DB access
export const dynamic = 'force-dynamic';

export async function POST(request: Request) {
  try {
    // Vérifier l'autorisation (secret cron ou session admin)
    const authHeader = request.headers.get("authorization");
    const cronSecret = process.env.CRON_SECRET;

    if (cronSecret && authHeader !== `Bearer ${cronSecret}`) {
      // Vérifier si c'est un admin connecté (simplifié)
      // En production, utiliser NextAuth session
    }

    const currentWeek = getIsoWeek(new Date());

    // Créer le log de job
    const jobLog = await prisma.persistenceJobLog.create({
      data: { semaineIso: currentWeek, status: "RUNNING" },
    });

    try {
      const stats = await runPersistenceJob(prisma);

      // Mettre à jour le log
      await prisma.persistenceJobLog.update({
        where: { id: jobLog.id },
        data: {
          actionsProcessed: stats.actionsProcessed,
          commentsCarried: stats.commentsCarried,
          alertsTriggered: stats.alertsTriggered,
          completedAt: new Date().toISOString(),
          status: "COMPLETED",
        },
      });

      return NextResponse.json({
        success: true,
        jobId: jobLog.id,
        ...stats,
      });
    } catch (err: any) {
      await prisma.persistenceJobLog.update({
        where: { id: jobLog.id },
        data: {
          completedAt: new Date().toISOString(),
          status: "FAILED",
          errorMessage: err.message,
        },
      });
      throw err;
    }
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
