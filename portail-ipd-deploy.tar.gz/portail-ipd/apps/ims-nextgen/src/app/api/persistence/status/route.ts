import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getIsoWeek } from "@/lib/persistence";

// Force runtime DB access
export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const lastJob = await prisma.persistenceJobLog.findFirst({
      orderBy: { startedAt: "desc" },
    });

    const currentWeek = getIsoWeek(new Date());

    // Statistiques de stagnation
    const stagnationStats = await prisma.comment.groupBy({
      by: ["semainesPersistance"],
      where: { isResolved: false },
      _count: true,
    });

    const stagnationSummary = {
      green: 0,
      yellow: 0,
      orange: 0,
      red: 0,
    };

    for (const s of stagnationStats) {
      const weeks = s.semainesPersistance;
      if (weeks >= 8) stagnationSummary.red += s._count;
      else if (weeks >= 5) stagnationSummary.orange += s._count;
      else if (weeks >= 3) stagnationSummary.yellow += s._count;
      else stagnationSummary.green += s._count;
    }

    // KPIs de résolution
    const resolvedComments = await prisma.comment.findMany({
      where: { isResolved: true, resolvedAt: { not: null } },
      select: { createdAt: true, resolvedAt: true },
    });

    let avgResolutionWeeks = 0;
    if (resolvedComments.length > 0) {
      const totalDays = resolvedComments.reduce((sum, c) => {
        const created = new Date(c.createdAt);
        const resolved = new Date(c.resolvedAt!);
        return sum + (resolved.getTime() - created.getTime()) / (1000 * 60 * 60 * 24);
      }, 0);
      avgResolutionWeeks = Math.round((totalDays / resolvedComments.length / 7) * 10) / 10;
    }

    const totalOpenActions = await prisma.actionAFM.count({ where: { statut: { not: "Clôturé" } } });
    const totalOpenEcarts = await prisma.ecart.count({ where: { statut: { not: "CLOTURE" } } });

    return NextResponse.json({
      lastJob,
      currentWeek,
      stagnationSummary,
      avgResolutionWeeks,
      totalOpenActions,
      totalOpenEcarts,
      totalUnresolved: stagnationSummary.green + stagnationSummary.yellow + stagnationSummary.orange + stagnationSummary.red,
    });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
