import { prisma } from "@/lib/prisma";
import { NextResponse } from "next/server";

// Force runtime DB access
export const dynamic = 'force-dynamic';

export async function GET() {
  const [ecarts, actions, garap, macroEcarts] = await Promise.all([
    prisma.ecart.findMany({ include: { service: true, macroEcart: true } }),
    prisma.actionAFM.findMany({ include: { workstream: true, responsables: { include: { user: true } } } }),
    prisma.suiviGarap.findMany({ include: { entite: true, fournisseur: true, devise: true } }),
    prisma.macroEcart.findMany(),
  ]);

  const totalEcarts = ecarts.length;
  const clotures = ecarts.filter((e) => e.statut === "CLOTURE").length;
  const tauxCloture = totalEcarts > 0 ? clotures / totalEcarts : 0;

  const capaHorsDelai = ecarts.filter((e) => e.capaHorsDelai).length;
  const capaOnTime = totalEcarts - capaHorsDelai;

  const majeursRestants = ecarts.filter((e) => e.classification === "Majeur" && e.statut !== "CLOTURE").length;

  const actionsOuvertes = actions.filter((a) => a.statut !== "CLOTURE");
  const scoreRisqueMoyen = actionsOuvertes.length > 0
    ? Math.round(actionsOuvertes.reduce((s, a) => s + a.scoreRisque, 0) / actionsOuvertes.length)
    : 0;

  const garapClotures = garap.filter((g) => g.statutWorkflow === "CLOTURE").length;

  // Avancement par workstream
  const wsAvancement: Record<string, { total: number; sum: number }> = {};
  for (const a of actions) {
    const code = a.workstream?.code || "N/A";
    if (!wsAvancement[code]) wsAvancement[code] = { total: 0, sum: 0 };
    wsAvancement[code].total++;
    wsAvancement[code].sum += a.avancement;
  }

  const avancementParWs = Object.entries(wsAvancement).map(([code, v]) => ({
    code,
    avancement: Math.round((v.sum / v.total) * 100),
  }));

  // Service breakdown for ecarts
  const serviceBreakdown: Record<string, { total: number; clotures: number }> = {};
  for (const e of ecarts) {
    const svc = e.service?.code || "N/A";
    if (!serviceBreakdown[svc]) serviceBreakdown[svc] = { total: 0, clotures: 0 };
    serviceBreakdown[svc].total++;
    if (e.statut === "CLOTURE") serviceBreakdown[svc].clotures++;
  }

  // Detail lists for drill-down
  const ecartsOuverts = ecarts.filter((e) => e.statut !== "CLOTURE").map((e) => ({
    id: e.id, numero: e.numero, nomEcart: e.nomEcart, statut: e.statut,
    classification: e.classification, pctAvancement: e.pctAvancement,
    service: e.service.code, commentaireAvancement: e.commentaireAvancement,
    commentaires: e.commentaires, capaHorsDelai: e.capaHorsDelai,
  }));

  const ecartsClotures = ecarts.filter((e) => e.statut === "CLOTURE").map((e) => ({
    id: e.id, numero: e.numero, nomEcart: e.nomEcart,
    service: e.service.code, dateCloture: e.dateCloture,
    commentaires: e.commentaires,
  }));

  const ecartsCapaHorsDelai = ecarts.filter((e) => e.capaHorsDelai).map((e) => ({
    id: e.id, numero: e.numero, nomEcart: e.nomEcart, statut: e.statut,
    service: e.service.code, dateFinalisation: e.dateFinalisation,
    commentaires: e.commentaires, commentaireAvancement: e.commentaireAvancement,
  }));

  const ecartsMajeursOuverts = ecarts.filter((e) => e.classification === "Majeur" && e.statut !== "CLOTURE").map((e) => ({
    id: e.id, numero: e.numero, nomEcart: e.nomEcart, statut: e.statut,
    pctAvancement: e.pctAvancement, service: e.service.code,
    macroEcart: e.macroEcart.numero,
    pointsBloquants: e.pointsBloquants, commentaireAvancement: e.commentaireAvancement,
  }));

  const actionsDetail = actions.map((a) => ({
    id: a.id, chronoLegacy: a.chronoLegacy, description: a.description, statut: a.statut,
    avancement: a.avancement, scoreRisque: a.scoreRisque, niveauCriticite: a.niveauCriticite,
    workstream: a.workstream.code, commentaires: a.commentaires,
    deadlineInitiale: a.deadlineInitiale, deadlineRevisee: a.deadlineRevisee,
    responsables: a.responsables.map((r) => r.user.name).join(", "),
    estImportant: a.estImportant, estUrgent: a.estUrgent,
  }));

  const garapDetail = garap.map((g) => ({
    id: g.id, natureProduits: g.natureProduits, statutWorkflow: g.statutWorkflow,
    montant: g.montant, entite: g.entite.libelle, fournisseur: g.fournisseur.raisonSociale,
    devise: g.devise.symbole, commentaireDal: g.commentaireDal,
    dateLivraisonPrevue: g.dateLivraisonPrevue,
  }));

  return NextResponse.json({
    tauxCloture: Math.round(tauxCloture * 1000) / 10,
    totalEcarts,
    clotures,
    capaOnTime,
    capaHorsDelai,
    majeursRestants,
    scoreRisqueMoyen,
    gmpStatus: "Obtenu",
    garapTotal: garap.length,
    garapClotures,
    avancementParWs,
    serviceBreakdown: Object.entries(serviceBreakdown).map(([code, v]) => ({
      code, total: v.total, clotures: v.clotures,
      taux: Math.round((v.clotures / v.total) * 100),
    })),
    macroEcarts: macroEcarts.map((m) => ({
      numero: m.numero, description: m.description, classification: m.classification,
      nbEcartsEnfants: m.nbEcartsEnfants, tauxCloture: Math.round(m.tauxCloture * 100),
    })),
    actionsParStatut: {
      cloture: actions.filter((a) => a.statut === "CLOTURE").length,
      enCours: actions.filter((a) => a.statut === "EN_COURS").length,
      enRetard: actions.filter((a) => a.statut === "EN_RETARD").length,
      aLancer: actions.filter((a) => a.statut === "A_LANCER").length,
    },
    garapParStatut: {
      CLOTURE: garap.filter((g) => g.statutWorkflow === "CLOTURE").length,
      ATTENTE_FOURNISSEUR: garap.filter((g) => g.statutWorkflow === "ATTENTE_FOURNISSEUR").length,
      ATTENTE_PAIEMENT: garap.filter((g) => g.statutWorkflow === "ATTENTE_PAIEMENT").length,
      CHEZ_TRANSITAIRE: garap.filter((g) => g.statutWorkflow === "CHEZ_TRANSITAIRE").length,
      EN_COURS_DOUANE: garap.filter((g) => g.statutWorkflow === "EN_COURS_DOUANE").length,
      LIVRE: garap.filter((g) => g.statutWorkflow === "LIVRE").length,
    },
    // Detail lists
    details: {
      ecartsOuverts,
      ecartsClotures,
      ecartsCapaHorsDelai,
      ecartsMajeursOuverts,
      actionsDetail,
      garapDetail,
      actionsEnRetard: actionsDetail.filter((a) => a.statut === "EN_RETARD"),
      actionsRisqueEleve: actionsDetail.filter((a) => a.scoreRisque >= 10).sort((a, b) => b.scoreRisque - a.scoreRisque),
    },
  });
}
