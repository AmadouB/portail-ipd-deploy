import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { writeFile, mkdir } from "fs/promises";
import path from "path";

// Force runtime DB access
export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const actionId = searchParams.get("actionId");
    const ecartId = searchParams.get("ecartId");
    const commentId = searchParams.get("commentId");

    const where: any = {};
    if (actionId) where.actionId = parseInt(actionId);
    if (ecartId) where.ecartId = parseInt(ecartId);
    if (commentId) where.commentId = parseInt(commentId);

    const attachments = await prisma.attachment.findMany({
      where,
      include: { uploadedBy: { select: { id: true, name: true } } },
      orderBy: { uploadedAt: "desc" },
    });

    return NextResponse.json({ attachments });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData();
    const file = formData.get("file") as File;
    const actionId = formData.get("actionId") as string;
    const ecartId = formData.get("ecartId") as string;
    const commentId = formData.get("commentId") as string;
    const uploadedById = formData.get("uploadedById") as string;

    if (!file || !uploadedById) {
      return NextResponse.json({ error: "file et uploadedById requis" }, { status: 400 });
    }

    // Validate file type
    const allowedTypes = [
      "application/pdf",
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      "application/vnd.ms-excel",
      "image/png", "image/jpeg", "image/gif",
    ];
    if (!allowedTypes.includes(file.type)) {
      return NextResponse.json({ error: "Type de fichier non autorisé" }, { status: 400 });
    }

    // Max 10MB
    if (file.size > 10 * 1024 * 1024) {
      return NextResponse.json({ error: "Fichier trop volumineux (max 10 Mo)" }, { status: 400 });
    }

    const now = new Date();
    const year = now.getFullYear();
    const week = String(Math.ceil(((now.getTime() - new Date(year, 0, 1).getTime()) / 86400000 + 1) / 7)).padStart(2, "0");

    const uploadDir = path.join(process.cwd(), "public", "uploads", String(year), `W${week}`);
    await mkdir(uploadDir, { recursive: true });

    const uniqueName = `${Date.now()}-${file.name.replace(/[^a-zA-Z0-9._-]/g, "_")}`;
    const filePath = path.join(uploadDir, uniqueName);

    const bytes = await file.arrayBuffer();
    await writeFile(filePath, Buffer.from(bytes));

    const relativePath = `/uploads/${year}/W${week}/${uniqueName}`;

    const attachment = await prisma.attachment.create({
      data: {
        actionId: actionId ? parseInt(actionId) : undefined,
        ecartId: ecartId ? parseInt(ecartId) : undefined,
        commentId: commentId ? parseInt(commentId) : undefined,
        fileName: file.name,
        filePath: relativePath,
        fileSize: file.size,
        mimeType: file.type,
        uploadedById: parseInt(uploadedById),
      },
    });

    return NextResponse.json(attachment, { status: 201 });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
