import { prisma } from "@/lib/prisma";
import { NextRequest, NextResponse } from "next/server";

// Force runtime DB access
export const dynamic = 'force-dynamic';

// GET — Liste toutes les entités de référence
export async function GET() {
  const [services, workstreams, entites, fournisseurs, macroEcarts] = await Promise.all([
    prisma.service.findMany({ orderBy: { code: "asc" } }),
    prisma.workstream.findMany({ orderBy: { code: "asc" } }),
    prisma.entite.findMany({ orderBy: { code: "asc" } }),
    prisma.fournisseur.findMany({ orderBy: { raisonSociale: "asc" } }),
    prisma.macroEcart.findMany({ orderBy: { numero: "asc" } }),
  ]);
  return NextResponse.json({ services, workstreams, entites, fournisseurs, macroEcarts });
}

// POST — Crée une nouvelle entité de référence
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { entityType, ...data } = body;

    switch (entityType) {
      case "service": {
        const { code, libelle, libelleCourt } = data;
        if (!code || !libelle) return NextResponse.json({ error: "Code et libellé requis" }, { status: 400 });
        const existing = await prisma.service.findUnique({ where: { code } });
        if (existing) return NextResponse.json({ error: `Le service "${code}" existe déjà` }, { status: 409 });
        const service = await prisma.service.create({ data: { code: code.toUpperCase(), libelle, libelleCourt: libelleCourt || code.toUpperCase() } });
        return NextResponse.json({ success: true, entity: service, entityType: "service" }, { status: 201 });
      }

      case "workstream": {
        const { code, libelle, responsableWs } = data;
        if (!code || !libelle) return NextResponse.json({ error: "Code et libellé requis" }, { status: 400 });
        const existing = await prisma.workstream.findUnique({ where: { code } });
        if (existing) return NextResponse.json({ error: `Le workstream "${code}" existe déjà` }, { status: 409 });
        const ws = await prisma.workstream.create({ data: { code: code.toUpperCase(), libelle, responsableWs: responsableWs || null } });
        return NextResponse.json({ success: true, entity: ws, entityType: "workstream" }, { status: 201 });
      }

      case "entite": {
        const { code, libelle } = data;
        if (!code || !libelle) return NextResponse.json({ error: "Code et libellé requis" }, { status: 400 });
        const existing = await prisma.entite.findUnique({ where: { code } });
        if (existing) return NextResponse.json({ error: `L'entité "${code}" existe déjà` }, { status: 409 });
        const entite = await prisma.entite.create({ data: { code: code.toUpperCase(), libelle } });
        return NextResponse.json({ success: true, entity: entite, entityType: "entite" }, { status: 201 });
      }

      case "fournisseur": {
        const { raisonSociale, pays, delaiMoyenLivraison } = data;
        if (!raisonSociale) return NextResponse.json({ error: "Raison sociale requise" }, { status: 400 });
        const fournisseur = await prisma.fournisseur.create({ data: { raisonSociale, pays: pays || null, delaiMoyenLivraison: delaiMoyenLivraison ? parseInt(delaiMoyenLivraison) : null } });
        return NextResponse.json({ success: true, entity: fournisseur, entityType: "fournisseur" }, { status: 201 });
      }

      case "macroEcart": {
        const { numero, description, classification } = data;
        if (!numero || !description) return NextResponse.json({ error: "Numéro et description requis" }, { status: 400 });
        const existing = await prisma.macroEcart.findUnique({ where: { numero } });
        if (existing) return NextResponse.json({ error: `Le macro-écart "${numero}" existe déjà` }, { status: 409 });
        const me = await prisma.macroEcart.create({ data: { numero, description, classification: classification || "Mineure" } });
        return NextResponse.json({ success: true, entity: me, entityType: "macroEcart" }, { status: 201 });
      }

      default:
        return NextResponse.json({ error: "entityType invalide" }, { status: 400 });
    }
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
