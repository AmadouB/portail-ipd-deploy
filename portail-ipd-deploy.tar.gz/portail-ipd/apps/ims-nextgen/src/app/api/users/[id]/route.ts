import { prisma } from "@/lib/prisma";
import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";

// Force runtime DB access
export const dynamic = 'force-dynamic';

export async function PUT(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const userId = Number(id);
  const body = await request.json();
  const { name, email, role, service, telephone, poste, actif, password } = body;

  const current = await prisma.user.findUnique({ where: { id: userId } });
  if (!current) {
    return NextResponse.json({ error: "Utilisateur non trouve" }, { status: 404 });
  }

  // Build update data
  const updateData: Record<string, any> = {};
  const changes: { champ: string; avant: string; apres: string }[] = [];

  if (name !== undefined && name !== current.name) { updateData.name = name; changes.push({ champ: "name", avant: current.name, apres: name }); }
  if (email !== undefined && email !== current.email) { updateData.email = email; changes.push({ champ: "email", avant: current.email, apres: email }); }
  if (role !== undefined && role !== current.role) { updateData.role = role; changes.push({ champ: "role", avant: current.role, apres: role }); }
  if (service !== undefined && service !== current.service) { updateData.service = service; changes.push({ champ: "service", avant: current.service || "", apres: service }); }
  if (telephone !== undefined && telephone !== current.telephone) { updateData.telephone = telephone; changes.push({ champ: "telephone", avant: current.telephone || "", apres: telephone }); }
  if (poste !== undefined && poste !== current.poste) { updateData.poste = poste; changes.push({ champ: "poste", avant: current.poste || "", apres: poste }); }
  if (actif !== undefined && actif !== current.actif) { updateData.actif = actif; changes.push({ champ: "actif", avant: String(current.actif), apres: String(actif) }); }
  if (password) { updateData.password = bcrypt.hashSync(password, 10); changes.push({ champ: "password", avant: "***", apres: "***" }); }

  const user = await prisma.user.update({ where: { id: userId }, data: updateData });

  // Audit trail
  for (const c of changes) {
    await prisma.auditTrail.create({
      data: {
        tableSource: "User",
        recordId: userId,
        actionType: "UPDATE",
        champModifie: c.champ,
        valeurAvant: c.avant,
        valeurApres: c.apres,
        userId: 1,
      },
    });
  }

  return NextResponse.json(user);
}

export async function DELETE(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const userId = Number(id);

  const current = await prisma.user.findUnique({ where: { id: userId } });
  if (!current) {
    return NextResponse.json({ error: "Utilisateur non trouve" }, { status: 404 });
  }

  // Soft delete: deactivate rather than hard delete
  const user = await prisma.user.update({
    where: { id: userId },
    data: { actif: false },
  });

  await prisma.auditTrail.create({
    data: {
      tableSource: "User",
      recordId: userId,
      actionType: "DESACTIVATION",
      champModifie: "actif",
      valeurAvant: "true",
      valeurApres: "false",
      userId: 1,
    },
  });

  return NextResponse.json(user);
}
