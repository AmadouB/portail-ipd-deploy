import { prisma } from "@/lib/prisma";
import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";

// Force runtime DB access
export const dynamic = 'force-dynamic';

export async function GET() {
  const users = await prisma.user.findMany({
    orderBy: { createdAt: "desc" },
    select: {
      id: true,
      name: true,
      email: true,
      role: true,
      service: true,
      telephone: true,
      poste: true,
      actif: true,
      lastLoginAt: true,
      createdAt: true,
      _count: {
        select: {
          auditTrails: true,
          actionsResponsable: true,
        },
      },
    },
  });
  return NextResponse.json(users);
}

export async function POST(request: Request) {
  const body = await request.json();
  const { name, email, password, role, service, telephone, poste } = body;

  if (!name || !email || !password) {
    return NextResponse.json({ error: "Nom, email et mot de passe requis" }, { status: 400 });
  }

  // Check duplicate
  const existing = await prisma.user.findUnique({ where: { email } });
  if (existing) {
    return NextResponse.json({ error: "Cet email existe deja" }, { status: 409 });
  }

  const hashedPassword = bcrypt.hashSync(password, 10);
  const user = await prisma.user.create({
    data: {
      name,
      email,
      password: hashedPassword,
      role: role || "LECTEUR",
      service: service || null,
      telephone: telephone || null,
      poste: poste || null,
    },
  });

  // Audit
  await prisma.auditTrail.create({
    data: {
      tableSource: "User",
      recordId: user.id,
      actionType: "CREATE",
      champModifie: "all",
      valeurAvant: null,
      valeurApres: `${name} (${email}) - ${role}`,
      userId: 1,
    },
  });

  return NextResponse.json(user, { status: 201 });
}
