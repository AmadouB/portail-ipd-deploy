import { prisma } from "@/lib/prisma";
import { NextResponse } from "next/server";

// Force runtime DB access
export const dynamic = 'force-dynamic';

export async function GET() {
  // Get all snapshots sorted by date
  const snapshots = await prisma.snapshot.findMany({
    include: { ecart: { include: { service: true, macroEcart: true } } },
    orderBy: { snapshotDate: "desc" },
  });

  // Get unique dates
  const dates = [...new Set(snapshots.map((s) => s.snapshotDate))].sort().reverse();
  const latestDate = dates[0];
  const previousDate = dates[1];

  // Latest snapshot data
  const latestSnaps = snapshots.filter((s) => s.snapshotDate === latestDate);
  const previousSnaps = previousDate ? snapshots.filter((s) => s.snapshotDate === previousDate) : [];

  // Build progress map for previous week
  const prevMap: Record<string, { pct: number; statut: string }> = {};
  for (const s of previousSnaps) {
    prevMap[s.ecart.numero] = { pct: s.pctAvancement, statut: s.statut };
  }

  // Deduplicate snapshots by ecart numero (keep latest)
  const dedup = (snaps: typeof latestSnaps) => {
    const map = new Map<string, (typeof latestSnaps)[0]>();
    for (const s of snaps) map.set(s.ecart.numero, s);
    return [...map.values()];
  };
  const uniqueLatest = dedup(latestSnaps);
  const uniquePrevious = dedup(previousSnaps);
  for (const s of uniquePrevious) prevMap[s.ecart.numero] = { pct: s.pctAvancement, statut: s.statut };

  // Avancees de la semaine (ecarts with positive marge)
  const avancees = uniqueLatest
    .filter((s) => (s.margeProgression || 0) > 0)
    .map((s) => ({
      id: s.ecart.id,
      numero: s.ecart.numero,
      nomEcart: s.ecart.nomEcart,
      service: s.ecart.service.code,
      macroEcart: s.ecart.macroEcart.numero,
      classification: s.ecart.classification,
      statut: s.statut,
      pctAvancement: s.pctAvancement,
      pctPrecedent: prevMap[s.ecart.numero]?.pct ?? s.pctAvancement - (s.margeProgression || 0),
      margeProgression: s.margeProgression || 0,
      commentaire: s.commentaireAvancement,
      version: s.version,
    }))
    .sort((a, b) => (b.margeProgression || 0) - (a.margeProgression || 0));

  // Recently closed (clotures cette semaine)
  const cloturesCetteSemaine = uniqueLatest
    .filter((s) => s.statut === "CLOTURE" && prevMap[s.ecart.numero]?.statut !== "CLOTURE")
    .map((s) => ({
      id: s.ecart.id,
      numero: s.ecart.numero,
      nomEcart: s.ecart.nomEcart,
      service: s.ecart.service.code,
      classification: s.ecart.classification,
      commentaire: s.commentaireAvancement,
    }));

  // Ecarts en cours (not closed) — retards
  const allEcarts = await prisma.ecart.findMany({
    where: { statut: { not: "CLOTURE" } },
    include: { service: true, macroEcart: true },
    orderBy: { pctAvancement: "asc" },
  });

  const retards = allEcarts.map((e) => {
    const latestSnap = latestSnaps.find((s) => s.ecart.numero === e.numero);
    const prevSnap = prevMap[e.numero];
    return {
      id: e.id,
      numero: e.numero,
      nomEcart: e.nomEcart,
      service: e.service.code,
      macroEcart: e.macroEcart.numero,
      classification: e.classification,
      statut: e.statut,
      pctAvancement: e.pctAvancement,
      pctPrecedent: prevSnap?.pct ?? e.pctAvancement,
      margeProgression: latestSnap?.margeProgression || 0,
      capaHorsDelai: e.capaHorsDelai,
      dateFinalisation: e.dateFinalisation,
      dateFinalisationRevue: e.dateFinalisationRevue,
      commentaire: e.commentaireAvancement,
      pointsBloquants: e.pointsBloquants,
      version: e.version,
      stagnant: (latestSnap?.margeProgression || 0) === 0,
    };
  });

  // Summary stats
  const totalEcarts = await prisma.ecart.count();
  const totalClotures = await prisma.ecart.count({ where: { statut: "CLOTURE" } });

  return NextResponse.json({
    semaine: latestDate,
    semainePrecedente: previousDate,
    tauxCloture: Math.round((totalClotures / totalEcarts) * 1000) / 10,
    totalEcarts,
    totalClotures,
    enCours: totalEcarts - totalClotures,
    avancees,
    cloturesCetteSemaine,
    retards,
    snapshotDates: dates.slice(0, 8),
  });
}
