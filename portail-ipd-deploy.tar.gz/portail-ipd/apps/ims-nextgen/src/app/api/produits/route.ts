import { NextResponse } from "next/server";
import produitsData from "@/data/produits.json";

export async function GET() {
  // Normaliser les statuts
  const data = (produitsData as any[]).map((p, i) => ({
    id: i + 1,
    ...p,
    statut: normalizeStatut(p.statut),
    devise: p.devise || "€",
    montant: typeof p.montant === "number" ? p.montant : parseFloat(String(p.montant).replace(/\s/g, "").replace(",", ".")) || 0,
  }));

  return NextResponse.json({ produits: data });
}

function normalizeStatut(s: string): string {
  if (!s) return "Non défini";
  const lower = s.toLowerCase().trim();
  if (lower === "cloture" || lower === "clôturé") return "Clôturé";
  if (lower.includes("transitaire")) return "Chez le transitaire";
  if (lower.includes("retour fournisseur")) return "Attente retour fournisseur";
  if (lower.includes("paiement")) return "Attente paiement";
  if (lower.includes("creation") || lower.includes("création")) return "Attente création DA";
  if (lower.includes("retour entit")) return "Attente retour entité";
  if (lower.includes("traitement") || lower.includes("dal")) return "Traitement DAL";
  return s;
}
