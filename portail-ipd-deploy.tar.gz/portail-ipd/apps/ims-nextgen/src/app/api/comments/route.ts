import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

// Force runtime DB access
export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const actionId = searchParams.get("actionId");
    const ecartId = searchParams.get("ecartId");
    const semaineIso = searchParams.get("semaineIso");
    const isResolved = searchParams.get("isResolved");

    const where: any = {};
    if (actionId) where.actionId = parseInt(actionId);
    if (ecartId) where.ecartId = parseInt(ecartId);
    if (semaineIso) where.semaineIso = semaineIso;
    if (isResolved !== null && isResolved !== undefined) {
      where.isResolved = isResolved === "true";
    }

    const comments = await prisma.comment.findMany({
      where,
      include: {
        createdBy: { select: { id: true, name: true, email: true } },
        resolvedBy: { select: { id: true, name: true } },
        parentComment: { select: { id: true, semaineIso: true, texte: true } },
        attachments: true,
        _count: { select: { childComments: true } },
      },
      orderBy: { createdAt: "desc" },
    });

    return NextResponse.json({ comments });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { actionId, ecartId, texte, createdById, semaineIso } = body;

    if (!texte || !createdById) {
      return NextResponse.json({ error: "texte et createdById requis" }, { status: 400 });
    }

    const { getIsoWeek } = await import("@/lib/persistence");
    const week = semaineIso || getIsoWeek(new Date());

    const comment = await prisma.comment.create({
      data: {
        actionId: actionId ? parseInt(actionId) : undefined,
        ecartId: ecartId ? parseInt(ecartId) : undefined,
        texte,
        semaineIso: week,
        createdById: parseInt(createdById),
      },
      include: {
        createdBy: { select: { id: true, name: true } },
      },
    });

    return NextResponse.json(comment, { status: 201 });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function PATCH(request: Request) {
  try {
    const body = await request.json();
    const { id, isResolved, resolvedById } = body;

    if (!id) {
      return NextResponse.json({ error: "id requis" }, { status: 400 });
    }

    const data: any = {};
    if (isResolved !== undefined) {
      data.isResolved = isResolved;
      if (isResolved) {
        data.resolvedAt = new Date().toISOString();
        data.resolvedById = resolvedById;
      } else {
        data.resolvedAt = null;
        data.resolvedById = null;
      }
    }

    const comment = await prisma.comment.update({
      where: { id: parseInt(id) },
      data,
    });

    return NextResponse.json(comment);
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
