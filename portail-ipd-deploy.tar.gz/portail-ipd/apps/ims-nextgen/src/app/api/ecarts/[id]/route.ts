import { prisma } from "@/lib/prisma";
import { NextRequest, NextResponse } from "next/server";

// Force runtime DB access
export const dynamic = 'force-dynamic';

export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const body = await req.json();

  const before = await prisma.ecart.findUnique({ where: { id: parseInt(id) } });
  if (!before) return NextResponse.json({ error: "Not found" }, { status: 404 });

  const updated = await prisma.ecart.update({
    where: { id: parseInt(id) },
    data: {
      ...(body.statut !== undefined && { statut: body.statut }),
      ...(body.pctAvancement !== undefined && { pctAvancement: body.pctAvancement }),
      ...(body.classification !== undefined && { classification: body.classification }),
      ...(body.capaHorsDelai !== undefined && { capaHorsDelai: body.capaHorsDelai }),
      ...(body.description !== undefined && { description: body.description }),
      ...(body.actionsCorrectives !== undefined && { actionsCorrectives: body.actionsCorrectives }),
      ...(body.analyseCauses !== undefined && { analyseCauses: body.analyseCauses }),
      ...(body.commentaires !== undefined && { commentaires: body.commentaires }),
      ...(body.commentaireAvancement !== undefined && { commentaireAvancement: body.commentaireAvancement }),
      ...(body.dateFinalisation !== undefined && { dateFinalisation: body.dateFinalisation }),
      ...(body.dateCloture !== undefined && { dateCloture: body.dateCloture }),
      ...(body.version !== undefined && { version: body.version }),
    },
    include: { service: true, macroEcart: true },
  });

  // Audit trail
  const changedFields = Object.keys(body).filter((k) => (before as any)[k] !== body[k]);
  for (const field of changedFields) {
    await prisma.auditTrail.create({
      data: {
        tableSource: "Ecart",
        recordId: parseInt(id),
        actionType: "UPDATE",
        champModifie: field,
        valeurAvant: String((before as any)[field] ?? ""),
        valeurApres: String(body[field] ?? ""),
        userId: 1,
      },
    });
  }

  return NextResponse.json(updated);
}
