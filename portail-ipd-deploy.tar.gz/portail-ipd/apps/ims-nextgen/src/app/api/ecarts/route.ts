import { prisma } from "@/lib/prisma";
import { NextResponse } from "next/server";

// Force runtime DB access
export const dynamic = 'force-dynamic';

export async function GET() {
  const [macroEcarts, ecarts] = await Promise.all([
    prisma.macroEcart.findMany({ include: { ecarts: { include: { service: true } } }, orderBy: { numero: "asc" } }),
    prisma.ecart.findMany({ include: { service: true, macroEcart: true }, orderBy: { numero: "asc" } }),
  ]);
  return NextResponse.json({ macroEcarts, ecarts });
}
