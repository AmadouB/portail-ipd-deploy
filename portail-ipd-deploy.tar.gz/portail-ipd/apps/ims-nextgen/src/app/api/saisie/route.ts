import { prisma } from "@/lib/prisma";
import { NextRequest, NextResponse } from "next/server";
import { getIsoWeek, calculateRivScore } from "@/lib/persistence";

// Force runtime DB access
export const dynamic = 'force-dynamic';

// GET — Récupère toutes les données nécessaires au module de saisie
export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const serviceCode = searchParams.get("service");
  const type = searchParams.get("type") || "all"; // "actions", "ecarts", "all"

  const [services, workstreams, users, macroEcarts] = await Promise.all([
    prisma.service.findMany({ orderBy: { code: "asc" } }),
    prisma.workstream.findMany({ orderBy: { code: "asc" } }),
    prisma.user.findMany({ where: { actif: true }, select: { id: true, name: true, email: true, service: true, role: true }, orderBy: { name: "asc" } }),
    prisma.macroEcart.findMany({ orderBy: { numero: "asc" } }),
  ]);

  let actions: any[] = [];
  let ecarts: any[] = [];

  if (type === "actions" || type === "all") {
    actions = await prisma.actionAFM.findMany({
      include: {
        workstream: true,
        responsables: { include: { user: { select: { id: true, name: true } } } },
        comments: { orderBy: { createdAt: "desc" }, take: 3, include: { createdBy: { select: { name: true } } } },
        attachments: { orderBy: { uploadedAt: "desc" } },
        _count: { select: { comments: true, attachments: true } },
      },
      orderBy: { id: "desc" },
    });
  }

  if (type === "ecarts" || type === "all") {
    const ecartWhere: any = {};
    if (serviceCode) {
      const svc = services.find(s => s.code === serviceCode);
      if (svc) ecartWhere.serviceId = svc.id;
    }
    ecarts = await prisma.ecart.findMany({
      where: ecartWhere,
      include: {
        service: true,
        macroEcart: true,
        comments: { orderBy: { createdAt: "desc" }, take: 3, include: { createdBy: { select: { name: true } } } },
        attachments: { orderBy: { uploadedAt: "desc" } },
        _count: { select: { comments: true, attachments: true } },
      },
      orderBy: { numero: "asc" },
    });
  }

  return NextResponse.json({ services, workstreams, users, macroEcarts, actions, ecarts });
}

// POST — Crée une nouvelle activité (action AFM ou écart)
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { type } = body; // "action" ou "ecart"

    if (type === "action") {
      const { workstreamId, description, deadlineInitiale, deadlineRevisee, statut, importance, urgence, avancement, commentaires, responsableIds } = body;

      if (!workstreamId || !description) {
        return NextResponse.json({ error: "Workstream et description requis" }, { status: 400 });
      }

      // Auto-chrono
      const lastAction = await prisma.actionAFM.findFirst({ orderBy: { id: "desc" } });
      const nextNum = (lastAction?.id || 0) + 1;
      const year = new Date().getFullYear();
      const chronoAuto = `AFM-${year}-${String(nextNum).padStart(4, "0")}`;

      const scoreRisque = (importance || 1) * (urgence || 1);
      const niveauCriticite = calculateRivScore(urgence || 1, importance || 1);

      const action = await prisma.actionAFM.create({
        data: {
          chronoAuto,
          dateCapture: new Date().toISOString().split("T")[0],
          workstreamId: parseInt(workstreamId),
          description,
          deadlineInitiale: deadlineInitiale || new Date().toISOString().split("T")[0],
          deadlineRevisee: deadlineRevisee || null,
          statut: statut || "En cours",
          estImportant: (importance || 1) >= 4,
          estUrgent: (urgence || 1) >= 4,
          importance: importance || 1,
          urgence: urgence || 1,
          avancement: avancement || 0,
          commentaires: commentaires || null,
          scoreRisque,
          niveauCriticite,
        },
      });

      // Assign responsables
      if (responsableIds?.length) {
        await prisma.actionResponsable.createMany({
          data: responsableIds.map((uid: number) => ({ actionId: action.id, userId: uid })),
        });
      }

      // Create initial comment if commentaires provided
      if (commentaires && responsableIds?.[0]) {
        const week = getIsoWeek(new Date());
        await prisma.comment.create({
          data: {
            actionId: action.id,
            texte: commentaires,
            semaineIso: week,
            createdById: responsableIds[0],
          },
        });
      }

      return NextResponse.json({ success: true, action, chronoAuto }, { status: 201 });

    } else if (type === "ecart") {
      const { numero, nomEcart, description, macroEcartId, serviceId, classification, statut, pctAvancement, analyseCauses, actionsCorrectives, pointsBloquants, documentsReference, dateFinalisation, probabilite, impact, commentaireAvancement } = body;

      if (!numero || !nomEcart || !serviceId) {
        return NextResponse.json({ error: "Numéro, nom et service requis" }, { status: 400 });
      }

      const scoreRiv = (probabilite && impact) ? calculateRivScore(probabilite, impact) : null;

      const ecart = await prisma.ecart.create({
        data: {
          numero,
          nomEcart,
          description: description || "",
          macroEcartId: parseInt(macroEcartId),
          serviceId: parseInt(serviceId),
          classification: classification || "Mineure",
          statut: statut || "EN_COURS",
          pctAvancement: pctAvancement || 0,
          analyseCauses: analyseCauses || null,
          actionsCorrectives: actionsCorrectives || null,
          pointsBloquants: pointsBloquants || null,
          documentsReference: documentsReference || null,
          dateFinalisation: dateFinalisation || null,
          probabilite: probabilite || null,
          impact: impact || null,
          scoreRiv,
          commentaireAvancement: commentaireAvancement || null,
        },
      });

      return NextResponse.json({ success: true, ecart }, { status: 201 });
    }

    return NextResponse.json({ error: "Type invalide (action ou ecart)" }, { status: 400 });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

// PUT — Met à jour une activité existante
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { type, id } = body;

    if (type === "action") {
      const { workstreamId, description, deadlineInitiale, deadlineRevisee, statut, importance, urgence, avancement, commentaires, responsableIds, newComment, commentUserId } = body;

      const scoreRisque = (importance || 1) * (urgence || 1);
      const niveauCriticite = calculateRivScore(urgence || 1, importance || 1);

      // Forcer 100% si statut clôturé
      const isClosed = statut && ["Clôturé", "CLOTURE"].includes(statut);
      const finalAvancement = isClosed ? 100 : avancement;

      const action = await prisma.actionAFM.update({
        where: { id: parseInt(id) },
        data: {
          ...(workstreamId && { workstreamId: parseInt(workstreamId) }),
          ...(description && { description }),
          ...(deadlineInitiale && { deadlineInitiale }),
          ...(deadlineRevisee !== undefined && { deadlineRevisee }),
          ...(statut && { statut }),
          ...(importance && { importance, estImportant: importance >= 4 }),
          ...(urgence && { urgence, estUrgent: urgence >= 4 }),
          ...(finalAvancement !== undefined && { avancement: finalAvancement }),
          ...(commentaires !== undefined && { commentaires }),
          scoreRisque,
          niveauCriticite,
        },
      });

      // Update responsables if provided
      if (responsableIds) {
        await prisma.actionResponsable.deleteMany({ where: { actionId: parseInt(id) } });
        if (responsableIds.length) {
          await prisma.actionResponsable.createMany({
            data: responsableIds.map((uid: number) => ({ actionId: parseInt(id), userId: uid })),
          });
        }
      }

      // Add new comment
      if (newComment && commentUserId) {
        const week = getIsoWeek(new Date());
        await prisma.comment.create({
          data: {
            actionId: parseInt(id),
            texte: newComment,
            semaineIso: week,
            createdById: parseInt(commentUserId),
          },
        });
      }

      return NextResponse.json({ success: true, action });

    } else if (type === "ecart") {
      const { numero, nomEcart, description, serviceId, classification, statut, pctAvancement, analyseCauses, actionsCorrectives, pointsBloquants, documentsReference, dateFinalisation, probabilite, impact, commentaireAvancement, newComment, commentUserId } = body;

      const scoreRiv = (probabilite && impact) ? calculateRivScore(probabilite, impact) : undefined;

      // Forcer 100% si statut clôturé
      const isEcartClosed = statut === "CLOTURE";
      const finalPctAvancement = isEcartClosed ? 100 : pctAvancement;

      const ecart = await prisma.ecart.update({
        where: { id: parseInt(id) },
        data: {
          ...(nomEcart && { nomEcart }),
          ...(description && { description }),
          ...(serviceId && { serviceId: parseInt(serviceId) }),
          ...(classification && { classification }),
          ...(statut && { statut }),
          ...(finalPctAvancement !== undefined && { pctAvancement: finalPctAvancement }),
          ...(analyseCauses !== undefined && { analyseCauses }),
          ...(actionsCorrectives !== undefined && { actionsCorrectives }),
          ...(pointsBloquants !== undefined && { pointsBloquants }),
          ...(documentsReference !== undefined && { documentsReference }),
          ...(dateFinalisation !== undefined && { dateFinalisation }),
          ...(probabilite !== undefined && { probabilite }),
          ...(impact !== undefined && { impact }),
          ...(scoreRiv && { scoreRiv }),
          ...(commentaireAvancement !== undefined && { commentaireAvancement }),
          ...(isEcartClosed && { dateCloture: new Date().toISOString().split("T")[0] }),
        },
      });

      if (newComment && commentUserId) {
        const week = getIsoWeek(new Date());
        await prisma.comment.create({
          data: {
            ecartId: parseInt(id),
            texte: newComment,
            semaineIso: week,
            createdById: parseInt(commentUserId),
          },
        });
      }

      return NextResponse.json({ success: true, ecart });
    }

    return NextResponse.json({ error: "Type invalide" }, { status: 400 });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
