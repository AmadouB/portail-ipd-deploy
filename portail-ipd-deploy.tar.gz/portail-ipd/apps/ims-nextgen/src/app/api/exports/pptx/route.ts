import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { generateWeeklyPptx } from "@/lib/exports/pptx-report";
import { getIsoWeek } from "@/lib/persistence";

// Force runtime DB access
export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const semaine = getIsoWeek(new Date());

    const [ecarts, actions, stagnationRaw] = await Promise.all([
      prisma.ecart.findMany({ include: { service: true } }),
      prisma.actionAFM.findMany({ include: { responsables: { include: { user: true } }, workstream: true } }),
      prisma.comment.findMany({ where: { isResolved: false }, select: { semainesPersistance: true } }),
    ]);

    const totalEcarts = ecarts.length;
    const clotures = ecarts.filter(e => e.statut === "CLOTURE").length;
    const tauxCloture = totalEcarts > 0 ? Math.round((clotures / totalEcarts) * 100) : 0;

    const stagnationSummary = { green: 0, yellow: 0, orange: 0, red: 0 };
    for (const c of stagnationRaw) {
      if (c.semainesPersistance >= 8) stagnationSummary.red++;
      else if (c.semainesPersistance >= 5) stagnationSummary.orange++;
      else if (c.semainesPersistance >= 3) stagnationSummary.yellow++;
      else stagnationSummary.green++;
    }

    const serviceBreakdown = Object.values(
      ecarts.reduce((acc: any, e) => {
        const code = e.service?.code || "N/A";
        if (!acc[code]) acc[code] = { code, total: 0, clotures: 0, taux: 0 };
        acc[code].total++;
        if (e.statut === "CLOTURE") acc[code].clotures++;
        acc[code].taux = Math.round((acc[code].clotures / acc[code].total) * 100);
        return acc;
      }, {} as any)
    );

    const pptxBuffer = await generateWeeklyPptx({
      semaine,
      tauxCloture,
      totalEcarts,
      clotures,
      actionsEnCours: actions.filter(a => a.statut === "En cours").length,
      actionsEnRetard: actions.filter(a => a.statut === "En retard").length,
      stagnationSummary,
      topActions: actions
        .filter(a => a.statut !== "Clôturé")
        .sort((a, b) => b.scoreRisque - a.scoreRisque)
        .slice(0, 10)
        .map(a => ({
          description: a.description,
          statut: a.statut,
          avancement: a.avancement,
          responsable: a.responsables[0]?.user.name || "N/A",
        })),
      topEcarts: ecarts.filter(e => e.statut !== "CLOTURE").slice(0, 10).map(e => ({
        numero: e.numero, nomEcart: e.nomEcart, statut: e.statut, pctAvancement: e.pctAvancement,
      })),
      serviceBreakdown: serviceBreakdown as any,
    });

    return new NextResponse(new Uint8Array(pptxBuffer), {
      headers: {
        "Content-Type": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
        "Content-Disposition": `attachment; filename="IMS_Presentation_${semaine}.pptx"`,
      },
    });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
