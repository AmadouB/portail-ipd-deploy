import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { generateWeeklyPdf } from "@/lib/exports/pdf-report";
import { getIsoWeek } from "@/lib/persistence";

// Force runtime DB access
export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const semaine = getIsoWeek(new Date());

    const [ecarts, actions, stagnationRaw] = await Promise.all([
      prisma.ecart.findMany({ include: { service: true } }),
      prisma.actionAFM.findMany({ include: { responsables: { include: { user: true } }, workstream: true } }),
      prisma.comment.findMany({ where: { isResolved: false }, select: { semainesPersistance: true } }),
    ]);

    const totalEcarts = ecarts.length;
    const clotures = ecarts.filter(e => e.statut === "CLOTURE").length;
    const tauxCloture = totalEcarts > 0 ? Math.round((clotures / totalEcarts) * 100) : 0;

    const actionsEnRetard = actions.filter(a => a.statut === "En retard").length;
    const actionsEnCours = actions.filter(a => a.statut === "En cours").length;

    const stagnationSummary = { green: 0, yellow: 0, orange: 0, red: 0 };
    for (const c of stagnationRaw) {
      if (c.semainesPersistance >= 8) stagnationSummary.red++;
      else if (c.semainesPersistance >= 5) stagnationSummary.orange++;
      else if (c.semainesPersistance >= 3) stagnationSummary.yellow++;
      else stagnationSummary.green++;
    }

    const topActions = actions
      .filter(a => a.statut !== "Clôturé")
      .sort((a, b) => b.scoreRisque - a.scoreRisque)
      .slice(0, 10)
      .map(a => ({
        description: a.description,
        statut: a.statut,
        avancement: a.avancement,
        responsable: a.responsables[0]?.user.name || "N/A",
      }));

    const topEcarts = ecarts
      .filter(e => e.statut !== "CLOTURE")
      .slice(0, 10)
      .map(e => ({
        numero: e.numero,
        nomEcart: e.nomEcart,
        statut: e.statut,
        pctAvancement: e.pctAvancement,
      }));

    const pdfBuffer = await generateWeeklyPdf({
      semaine,
      tauxCloture,
      totalEcarts,
      clotures,
      actionsEnCours,
      actionsEnRetard,
      stagnationSummary,
      topActions,
      topEcarts,
    });

    return new NextResponse(new Uint8Array(pdfBuffer), {
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition": `attachment; filename="IMS_Rapport_${semaine}.pdf"`,
      },
    });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
