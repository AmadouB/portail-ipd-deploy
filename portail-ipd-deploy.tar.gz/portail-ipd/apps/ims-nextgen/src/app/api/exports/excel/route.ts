import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { generateExcelExport } from "@/lib/exports/excel-export";
import { getIsoWeek } from "@/lib/persistence";

// Force runtime DB access
export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const semaine = getIsoWeek(new Date());

    const [ecarts, actions, garap, comments] = await Promise.all([
      prisma.ecart.findMany({ include: { service: true, macroEcart: true } }),
      prisma.actionAFM.findMany({ include: { workstream: true, responsables: { include: { user: true } } } }),
      prisma.suiviGarap.findMany({ include: { entite: true, fournisseur: true, devise: true } }),
      prisma.comment.findMany({ include: { createdBy: { select: { name: true } } }, orderBy: { createdAt: "desc" } }),
    ]);

    const buffer = await generateExcelExport({ ecarts, actions, garap, comments });

    return new NextResponse(new Uint8Array(buffer), {
      headers: {
        "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "Content-Disposition": `attachment; filename="IMS_Export_${semaine}.xlsx"`,
      },
    });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
