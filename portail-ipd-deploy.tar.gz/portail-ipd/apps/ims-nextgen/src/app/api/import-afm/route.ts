import { prisma } from "@/lib/prisma";
import { NextResponse } from "next/server";

// Force runtime DB access
export const dynamic = 'force-dynamic';

// Parsed data from "Action Log AFM_ IMS & Lancement Prod - Année 2026.xlsx"
const AFM_2026_DATA = [
  { chrono: 1, date: "2026-01-15", ws: "WS5F", desc: "Fournir un Programme AFM - Depenses d'investissement - Previsionnel sur 3-6 mois : pour supporter la demande de financement", qui: "Patrick / Lamine S. / Fode D.", quand: "2026-01-17", statut: "CLOTURE", imp: true, urg: true, avanc: 1, comm: "" },
  { chrono: 2, date: "2025-12-18", ws: "WS1", desc: "Signatures des protocoles Pharmtech et AVN", qui: "Babacar Dogue", quand: "2026-02-28", statut: "EN_COURS", imp: true, urg: false, avanc: 0.4, comm: "Delai initial 16 Jan, repousse au 28 Fev" },
  { chrono: 3, date: "2026-01-07", ws: "WS1", desc: "Annexe au PDV/VMP 2026 de AFM: planning prospectif version 1", qui: "Babacar Dogue", quand: "2026-02-20", statut: "EN_COURS", imp: true, urg: false, avanc: 0.3, comm: "Delai initial 16 Jan, repousse au 20 Fev" },
  { chrono: 4, date: "2026-01-13", ws: "WS1", desc: "Appel d'offre BID, Commande equipements Macrolot 06F: transmettre l'Analyse technique des offres a la DAL", qui: "Fode D.", quand: "2026-01-16", statut: "CLOTURE", imp: true, urg: true, avanc: 1, comm: "" },
  { chrono: 5, date: "2026-01-20", ws: "WS5F", desc: "Appel d'offre BID, Commande equipements Macrolot 06F: Rapport d'evaluation a soumettre au bailleur", qui: "Cheikhou D.", quand: "2026-02-05", statut: "CLOTURE", imp: true, urg: true, avanc: 1, comm: "05/02: Rapport envoye par DOI. 10/02: Rapport transmis a la BID" },
  { chrono: 6, date: "2026-01-13", ws: "WS5F", desc: "Organiser Reunion Strategie Ordonnancement Paiements Priorite 1 AFM", qui: "Patrick", quand: "2026-01-16", statut: "CLOTURE", imp: true, urg: true, avanc: 1, comm: "" },
  { chrono: 7, date: "2026-01-13", ws: "WS1", desc: "Planning de mise en route les installations existantes (eviter les mauvaises surprises de demarrage)", qui: "Fode D.", quand: "2026-01-30", statut: "CLOTURE", imp: true, urg: false, avanc: 1, comm: "Pris en compte dans le planning consolide de AFM, necessite remobilisation prestataires" },
  { chrono: 8, date: "2026-01-13", ws: "PMO", desc: "Finaliser le Planning consolide AFM PQ OMS 2027", qui: "Patrick / Tous", quand: "2026-02-07", statut: "EN_COURS", imp: true, urg: true, avanc: 0.6, comm: "05/02: Atelier tenu le 03/02, target date repousse" },
  { chrono: 9, date: "2026-01-13", ws: "PMO", desc: "Fichier Action Log IMS: mettre en place", qui: "Patrick", quand: "2026-01-16", statut: "CLOTURE", imp: true, urg: true, avanc: 1, comm: "" },
  { chrono: 10, date: "2026-01-16", ws: "WS1", desc: "Travaux etancheisation Plafond DP Vs HVAC, Delta P, Nuisibles", qui: "Magatte D.", quand: "2026-01-23", statut: "EN_RETARD", imp: true, urg: true, avanc: 0.3, comm: "Delai initial au 23 Jan" },
  { chrono: 11, date: "2026-01-16", ws: "WS4", desc: "Data Matrix (URS et consultations fournisseurs)", qui: "Omar G.", quand: "2026-02-28", statut: "EN_COURS", imp: true, urg: false, avanc: 0.2, comm: "" },
  { chrono: 12, date: "2026-01-16", ws: "WS1", desc: "Monitoring de progres sur les actions de mitigations suite audit energetique", qui: "Fode D. / Serigne", quand: "2026-01-22", statut: "CLOTURE", imp: true, urg: true, avanc: 1, comm: "" },
  { chrono: 13, date: "2026-01-16", ws: "WS4", desc: "Faire valider par l'AG avant envoi a DAL, Terms of Reference pour equipements Prod", qui: "Patrick", quand: "2026-01-28", statut: "EN_RETARD", imp: true, urg: true, avanc: 0.5, comm: "Envoye a AG le 19 Jan. Delai initial au 28 Jan" },
  { chrono: 14, date: "2026-01-16", ws: "WS1", desc: "Faire valider par l'AG avant envoi a DAL, Terms of Reference pour equipements Infra", qui: "Patrick", quand: "2026-01-28", statut: "EN_RETARD", imp: true, urg: true, avanc: 0.5, comm: "Delai initial au 28 Jan" },
  { chrono: 15, date: "2026-01-20", ws: "WS4", desc: "Venir aupres de la DAL avec une expression de besoin globale annuelle pour Production", qui: "Lahad", quand: "2026-02-15", statut: "CLOTURE", imp: true, urg: false, avanc: 1, comm: "Transmis le 13/02/2026 a la DAL" },
  { chrono: 16, date: "2026-01-20", ws: "WS5F", desc: "Organiser une reunion avec DFC/DAL/DOI experts pour le Decaissement 5 BID", qui: "Patrick", quand: "2026-01-24", statut: "CLOTURE", imp: true, urg: true, avanc: 1, comm: "Reunion effectuee le 22 Jan, CR envoye" },
  { chrono: 17, date: "2026-01-20", ws: "WS5F", desc: "Rediger le document nouveau projet financement AFM", qui: "Patrick / DOI", quand: "2026-01-28", statut: "CLOTURE", imp: true, urg: true, avanc: 1, comm: "Transmis le 03 Fev a la DFC" },
  { chrono: 18, date: "2026-01-20", ws: "WS5F", desc: "Reprendre contact avec les prestataires strategiques AFM pour negociation contrats", qui: "Lamine S. / Patrick / DOI", quand: "2026-03-15", statut: "EN_COURS", imp: true, urg: true, avanc: 0.35, comm: "Contact/echanges preliminaires effectues avec Mirross" },
  { chrono: 19, date: "2026-02-05", ws: "WS1", desc: "Securiser l'approvisionnement en gazoil", qui: "L. Mendy / DAL / DFC", quand: "2026-02-15", statut: "EN_RETARD", imp: true, urg: true, avanc: 0.4, comm: "05/02: le gazoil est necessaire a la production de vapeur" },
  { chrono: 20, date: "2026-02-05", ws: "WS1", desc: "Commande de pieces de rechange des equipements critiques", qui: "L. Mendy / DAL", quand: "2026-03-01", statut: "A_LANCER", imp: true, urg: true, avanc: 0, comm: "" },
  { chrono: 21, date: "2026-02-05", ws: "WS1", desc: "Souscription de contrats de maintenance pour les equipements critiques", qui: "L. Mendy / DAL", quand: "2026-03-01", statut: "A_LANCER", imp: true, urg: true, avanc: 0, comm: "" },
  { chrono: 22, date: "2026-02-05", ws: "WS1", desc: "Commande de reactifs pour le systeme de production d'eau pharmaceutique", qui: "L. Mendy / DAL", quand: "2026-02-20", statut: "EN_COURS", imp: true, urg: true, avanc: 0.7, comm: "05/02: dates de livraison en attente update DAL" },
  { chrono: 23, date: "2026-02-05", ws: "TTT", desc: "Verification disponibilite des pieces de rechanges des equipements AFM", qui: "Fode D.", quand: "2026-02-15", statut: "EN_COURS", imp: true, urg: true, avanc: 0.9, comm: "09/02: Verif faite, certaines PdR manquantes" },
  { chrono: 24, date: "2026-02-05", ws: "TTT", desc: "Protocole de Tech Transfert DP", qui: "DND / Patrick", quand: "2026-03-15", statut: "EN_COURS", imp: true, urg: true, avanc: 0.5, comm: "Envoye pour relecture, attente retour" },
  { chrono: 25, date: "2026-02-05", ws: "TTT", desc: "Draft Design des charges d'autoclave et H2O2 cabine de lavage", qui: "AKC", quand: "2026-03-10", statut: "EN_COURS", imp: true, urg: false, avanc: 0.7, comm: "Draft en cours" },
  { chrono: 26, date: "2026-02-05", ws: "TTT", desc: "Equipements (lave linge, seche linge, autoclave): verification mise en route", qui: "MFD", quand: "2026-03-15", statut: "EN_COURS", imp: true, urg: false, avanc: 0.3, comm: "Verification des equipements pour mise en route" },
  { chrono: 27, date: "2026-02-05", ws: "TTT", desc: "Redaction des procedures operatoires AFM", qui: "Production", quand: "2026-03-30", statut: "EN_COURS", imp: true, urg: true, avanc: 0.1, comm: "Draft en cours" },
  { chrono: 28, date: "2026-02-05", ws: "TTT", desc: "Paniers cabine de lavage: verification disponibilite", qui: "MFD / Patrick", quand: "2026-02-15", statut: "EN_COURS", imp: true, urg: true, avanc: 0.98, comm: "Verifier si tous les paniers des cabines sont disponibles" },
  { chrono: 29, date: "2026-02-05", ws: "TTT", desc: "Formation TS et agents de production AFM", qui: "DND / Patrick", quand: "2026-06-30", statut: "EN_COURS", imp: true, urg: true, avanc: 0.15, comm: "2 TS / 10 depuis Nov 2025. 02 Agents / 06" },
  { chrono: 30, date: "2026-02-10", ws: "WS1", desc: "Acquisition analyseur vapeur NCG (non condensable gases)", qui: "L. Mendy / DAL", quand: "2026-03-15", statut: "EN_COURS", imp: true, urg: true, avanc: 0.7, comm: "05/02: Equipement necessaire pour les activites" },
  { chrono: 31, date: "2026-02-16", ws: "WS5H", desc: "Avancement fiches de postes a recruter et validation par AG pour publication annonces", qui: "Moussa S.", quand: "2026-02-28", statut: "EN_COURS", imp: true, urg: true, avanc: 0.2, comm: "" },
  { chrono: 32, date: "2026-02-16", ws: "WS7", desc: "Suivi plan d'action CAPA suite Inspection ARP Licence Exploitation", qui: "Awa L.", quand: "2026-06-30", statut: "EN_COURS", imp: true, urg: false, avanc: 0.1, comm: "" },
  { chrono: 33, date: "2026-02-16", ws: "WS7", desc: "Suivi avancement delivrance Licence Exploitation par l'ARP", qui: "Awa L.", quand: "2026-06-30", statut: "EN_COURS", imp: true, urg: false, avanc: 0.1, comm: "" },
  { chrono: 34, date: "2026-02-19", ws: "WS3", desc: "Reunion LCQ/PROD/AQ Ste, documentation EM (delai a definir + strategie)", qui: "Lamine T.", quand: "2026-02-27", statut: "EN_COURS", imp: true, urg: true, avanc: 0.2, comm: "" },
  { chrono: 35, date: "2026-02-19", ws: "WS3", desc: "Definition Besoin en boites de petri et consommables pour l'EM", qui: "Lamine T.", quand: "2026-03-06", statut: "EN_COURS", imp: true, urg: true, avanc: 0.1, comm: "" },
];

export async function POST() {
  // Get workstream map
  const workstreams = await prisma.workstream.findMany();
  const wsMap: Record<string, number> = {};
  for (const w of workstreams) wsMap[w.code] = w.id;

  // Delete existing actions and recreate from Excel data
  await prisma.actionResponsable.deleteMany();
  await prisma.actionAFM.deleteMany();

  const created = [];
  for (const a of AFM_2026_DATA) {
    const wsId = wsMap[a.ws] || wsMap["PMO"] || 1;

    // Compute score risque based on importance/urgence
    let scoreRisque = 1;
    if (a.imp && a.urg) scoreRisque = a.statut === "EN_RETARD" ? 20 : 15;
    else if (a.imp) scoreRisque = 10;
    else if (a.urg) scoreRisque = 8;
    else scoreRisque = 3;

    let criticite = "Low";
    if (scoreRisque >= 15) criticite = "Very High";
    else if (scoreRisque >= 10) criticite = "High";
    else if (scoreRisque >= 5) criticite = "Medium";

    const action = await prisma.actionAFM.create({
      data: {
        chronoLegacy: a.chrono,
        dateCapture: a.date,
        workstreamId: wsId,
        description: a.desc,
        deadlineInitiale: a.quand,
        deadlineRevisee: null,
        statut: a.statut,
        estImportant: a.imp,
        estUrgent: a.urg,
        avancement: a.avanc,
        commentaires: a.comm || null,
        scoreRisque,
        niveauCriticite: criticite,
      },
    });
    created.push({ id: action.id, chrono: a.chrono, desc: a.desc.slice(0, 50) });
  }

  return NextResponse.json({ imported: created.length, actions: created });
}
