import { prisma } from "@/lib/prisma";
import { NextResponse } from "next/server";

// Force runtime DB access
export const dynamic = 'force-dynamic';

export async function GET() {
  const snapshots = await prisma.snapshot.findMany({
    include: { ecart: { include: { service: true, macroEcart: true } } },
    orderBy: [{ snapshotDate: "asc" }, { ecartId: "asc" }],
  });
  return NextResponse.json({ snapshots });
}
