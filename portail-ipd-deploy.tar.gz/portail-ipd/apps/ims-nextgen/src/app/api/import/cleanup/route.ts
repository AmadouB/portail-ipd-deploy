import { prisma } from "@/lib/prisma";
import { NextResponse } from "next/server";

// Force runtime DB access
export const dynamic = 'force-dynamic';

const EXCEL_NUMEROS = [
  "2.1.1","2.1.2","2.1.3.a","2.1.3.b","2.1.4.a","2.1.4.b","2.1.4.c","2.1.4.d","2.1.4.e","2.1.4.f",
  "2.1.5","2.1.6.a","2.1.6.b","2.1.6.c","2.2.1.a","2.2.1.b","2.2.1.c","2.2.1.d","2.2.1.e",
  "2.2.2.","2.2.3","2.2.4","2.3.1.a","2.3.1.b","2.3.1.c","2.3.2.a","2.3.2.b","2.3.2.c","2.3.2.d",
  "2.3.3.a","2.3.3.b","2.3.3.c","2.3.3.d","2.3.3.e","2.3.3.f","2.3.4","2.3.5.a","2.3.5.b",
  "2.4.1","2.4.2","2.4.3","2.4.4","3.1.1","3.1.2","3.1.3","3.2","3.3","3.4","3.5.1","3.5.2","3.6","3.7",
];

export async function POST() {
  // Delete ecarts NOT in the Excel file
  const allEcarts = await prisma.ecart.findMany();
  const toDelete = allEcarts.filter((e) => !EXCEL_NUMEROS.includes(e.numero));
  const deleteIds = toDelete.map((e) => e.id);

  if (deleteIds.length > 0) {
    await prisma.snapshot.deleteMany({ where: { ecartId: { in: deleteIds } } });
    await prisma.ecart.deleteMany({ where: { id: { in: deleteIds } } });
  }

  // Also remove duplicate snapshots (same ecartId + snapshotDate)
  const snaps = await prisma.snapshot.findMany({ orderBy: { id: "asc" } });
  const snapSeen = new Set<string>();
  const snapDupes: number[] = [];
  for (const s of snaps) {
    const key = `${s.ecartId}-${s.snapshotDate}`;
    if (snapSeen.has(key)) snapDupes.push(s.id);
    else snapSeen.add(key);
  }
  if (snapDupes.length > 0) {
    await prisma.snapshot.deleteMany({ where: { id: { in: snapDupes } } });
  }

  // Also remove duplicate ecarts by numero
  const remaining = await prisma.ecart.findMany({ orderBy: { id: "asc" } });
  const numSeen = new Map<string, number>();
  const ecartDupes: number[] = [];
  for (const e of remaining) {
    if (numSeen.has(e.numero)) ecartDupes.push(e.id);
    else numSeen.set(e.numero, e.id);
  }
  if (ecartDupes.length > 0) {
    await prisma.snapshot.deleteMany({ where: { ecartId: { in: ecartDupes } } });
    await prisma.ecart.deleteMany({ where: { id: { in: ecartDupes } } });
  }

  // Update macro-ecart counts
  const macros = await prisma.macroEcart.findMany({ include: { ecarts: true } });
  for (const m of macros) {
    const total = m.ecarts.length;
    const clotures = m.ecarts.filter((e) => e.statut === "CLOTURE").length;
    await prisma.macroEcart.update({
      where: { id: m.id },
      data: { nbEcartsEnfants: total, tauxCloture: total > 0 ? Math.round((clotures / total) * 100) : 0 },
    });
  }

  const finalCount = await prisma.ecart.count();
  const cloturesCount = await prisma.ecart.count({ where: { statut: "CLOTURE" } });
  const snapCount = await prisma.snapshot.count();

  return NextResponse.json({
    deletedOldEcarts: deleteIds.length,
    deletedDupeEcarts: ecartDupes.length,
    deletedDupeSnapshots: snapDupes.length,
    finalEcarts: finalCount,
    clotures: cloturesCount,
    enCours: finalCount - cloturesCount,
    snapshots: snapCount,
  });
}
