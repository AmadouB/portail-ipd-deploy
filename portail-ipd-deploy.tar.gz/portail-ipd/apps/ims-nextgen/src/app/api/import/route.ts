import { prisma } from "@/lib/prisma";
import { NextResponse } from "next/server";
import { readFileSync } from "fs";

// Force runtime DB access
export const dynamic = 'force-dynamic';

export async function POST() {
  try {
    const raw = readFileSync("/tmp/ecarts_data.json", "utf-8");
    const data = JSON.parse(raw);

    // Map services
    const services = await prisma.service.findMany();
    const svcMap: Record<string, number> = {};
    for (const s of services) svcMap[s.code] = s.id;

    // Create missing services
    for (const code of ["CQ", "PHARM"]) {
      if (!svcMap[code]) {
        const created = await prisma.service.create({
          data: { code, libelle: code === "CQ" ? "Controle Qualite" : "Pharmacien Responsable", libelleCourt: code },
        });
        svcMap[code] = created.id;
      }
    }

    // Map macro-ecarts
    const macros = await prisma.macroEcart.findMany();
    const macroMap: Record<string, number> = {};
    for (const m of macros) macroMap[m.numero] = m.id;

    // Update macro-ecart descriptions from Excel
    for (const me of data.macroEcarts) {
      if (macroMap[me.numero]) {
        await prisma.macroEcart.update({
          where: { id: macroMap[me.numero] },
          data: { description: me.description, classification: me.classification },
        });
      }
    }

    // Update ecarts from Excel data
    let updated = 0;
    let created = 0;
    for (const e of data.ecarts) {
      const serviceId = svcMap[e.service];
      if (!serviceId) continue;

      const macroId = macroMap[e.macroEcart];
      if (!macroId) continue;

      const existing = await prisma.ecart.findUnique({ where: { numero: e.numero } });
      const ecartData = {
        macroEcartId: macroId,
        serviceId: serviceId,
        classification: e.classification,
        statut: e.statut,
        pctAvancement: e.pctAvancement,
        capaHorsDelai: e.capaHorsDelai,
        version: e.version,
        dateCloture: e.dateCloture,
        dateFinalisation: e.dateFinalisation,
        dateFinalisationRevue: e.dateFinalisationRevue,
        nomEcart: e.nomEcart,
        description: e.description,
        commentaireAvancement: e.commentaireAvancement,
        commentaires: e.commentaires,
        analyseCauses: e.analyseCauses,
        actionsCorrectives: e.actionsCorrectives,
        pointsBloquants: e.pointsBloquants,
      };

      if (existing) {
        await prisma.ecart.update({ where: { id: existing.id }, data: ecartData });
        updated++;
      } else {
        await prisma.ecart.create({ data: { numero: e.numero, ...ecartData } });
        created++;
      }
    }

    // Update macro-ecart stats
    const allMacros = await prisma.macroEcart.findMany({ include: { ecarts: true } });
    for (const m of allMacros) {
      const total = m.ecarts.length;
      const clotures = m.ecarts.filter((e) => e.statut === "CLOTURE").length;
      await prisma.macroEcart.update({
        where: { id: m.id },
        data: {
          nbEcartsEnfants: total,
          tauxCloture: total > 0 ? Math.round((clotures / total) * 100) : 0,
        },
      });
    }

    // Import weekly snapshots
    let snapsCreated = 0;
    const ecartsByNumero: Record<string, number> = {};
    const allEcarts = await prisma.ecart.findMany();
    for (const e of allEcarts) ecartsByNumero[e.numero] = e.id;

    // Delete old snapshots and recreate with real data
    await prisma.snapshot.deleteMany({});
    for (const s of data.weeklySnapshots) {
      const ecartId = ecartsByNumero[s.ecart];
      if (!ecartId) continue;
      await prisma.snapshot.create({
        data: {
          ecartId,
          snapshotDate: s.date,
          snapshotLabel: s.label,
          statut: s.statut,
          pctAvancement: s.pctAvancement,
          margeProgression: s.margeProgression,
          version: s.version,
          estCloture: s.statut === "CLOTURE",
          commentaireAvancement: s.commentaire,
        },
      });
      snapsCreated++;
    }

    return NextResponse.json({
      success: true,
      updated,
      created,
      snapsCreated,
      totalEcarts: data.ecarts.length,
    });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
