import { prisma } from "@/lib/prisma";
import { NextResponse } from "next/server";

// Force runtime DB access
export const dynamic = 'force-dynamic';

export async function GET() {
  const dossiers = await prisma.suiviGarap.findMany({
    include: { entite: true, fournisseur: true, devise: true },
    orderBy: { id: "asc" },
  });
  const entites = await prisma.entite.findMany();
  const fournisseurs = await prisma.fournisseur.findMany();
  return NextResponse.json({ dossiers, entites, fournisseurs });
}
