import { prisma } from "@/lib/prisma";
import { NextRequest, NextResponse } from "next/server";

// Force runtime DB access
export const dynamic = 'force-dynamic';

export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const body = await req.json();

  const before = await prisma.suiviGarap.findUnique({ where: { id: parseInt(id) } });
  if (!before) return NextResponse.json({ error: "Not found" }, { status: 404 });

  const updated = await prisma.suiviGarap.update({
    where: { id: parseInt(id) },
    data: {
      ...(body.statutWorkflow !== undefined && { statutWorkflow: body.statutWorkflow }),
      ...(body.montant !== undefined && { montant: body.montant }),
      ...(body.numDaBc !== undefined && { numDaBc: body.numDaBc }),
      ...(body.commentaireDal !== undefined && { commentaireDal: body.commentaireDal }),
      ...(body.dateDerniereRelance !== undefined && { dateDerniereRelance: body.dateDerniereRelance }),
      ...(body.dateLivraisonPrevue !== undefined && { dateLivraisonPrevue: body.dateLivraisonPrevue }),
      ...(body.dateLivraisonEffective !== undefined && { dateLivraisonEffective: body.dateLivraisonEffective }),
      ...(body.expressionBesoin !== undefined && { expressionBesoin: body.expressionBesoin }),
      ...(body.natureProduits !== undefined && { natureProduits: body.natureProduits }),
    },
    include: { entite: true, fournisseur: true, devise: true },
  });

  const changedFields = Object.keys(body).filter((k) => (before as any)[k] !== body[k]);
  for (const field of changedFields) {
    await prisma.auditTrail.create({
      data: {
        tableSource: "SuiviGarap",
        recordId: parseInt(id),
        actionType: "UPDATE",
        champModifie: field,
        valeurAvant: String((before as any)[field] ?? ""),
        valeurApres: String(body[field] ?? ""),
        userId: 1,
      },
    });
  }

  return NextResponse.json(updated);
}
