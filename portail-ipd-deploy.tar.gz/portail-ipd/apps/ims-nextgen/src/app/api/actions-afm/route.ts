import { prisma } from "@/lib/prisma";
import { NextResponse } from "next/server";

// Force runtime DB access
export const dynamic = 'force-dynamic';

export async function GET() {
  const actions = await prisma.actionAFM.findMany({
    include: { workstream: true, responsables: { include: { user: true } } },
    orderBy: { chronoLegacy: "asc" },
  });
  const workstreams = await prisma.workstream.findMany({ orderBy: { code: "asc" } });
  return NextResponse.json({ actions, workstreams });
}
