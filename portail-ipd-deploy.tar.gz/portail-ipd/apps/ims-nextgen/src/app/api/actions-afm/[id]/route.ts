import { prisma } from "@/lib/prisma";
import { NextRequest, NextResponse } from "next/server";

// Force runtime DB access
export const dynamic = 'force-dynamic';

export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const body = await req.json();

  const before = await prisma.actionAFM.findUnique({ where: { id: parseInt(id) } });
  if (!before) return NextResponse.json({ error: "Not found" }, { status: 404 });

  const updated = await prisma.actionAFM.update({
    where: { id: parseInt(id) },
    data: {
      ...(body.statut !== undefined && { statut: body.statut }),
      ...(body.avancement !== undefined && { avancement: body.avancement }),
      ...(body.estImportant !== undefined && { estImportant: body.estImportant }),
      ...(body.estUrgent !== undefined && { estUrgent: body.estUrgent }),
      ...(body.deadlineRevisee !== undefined && { deadlineRevisee: body.deadlineRevisee }),
      ...(body.description !== undefined && { description: body.description }),
      ...(body.commentaires !== undefined && { commentaires: body.commentaires }),
      ...(body.scoreRisque !== undefined && { scoreRisque: body.scoreRisque }),
      ...(body.niveauCriticite !== undefined && { niveauCriticite: body.niveauCriticite }),
    },
    include: { workstream: true, responsables: { include: { user: true } } },
  });

  const changedFields = Object.keys(body).filter((k) => (before as any)[k] !== body[k]);
  for (const field of changedFields) {
    await prisma.auditTrail.create({
      data: {
        tableSource: "ActionAFM",
        recordId: parseInt(id),
        actionType: "UPDATE",
        champModifie: field,
        valeurAvant: String((before as any)[field] ?? ""),
        valeurApres: String(body[field] ?? ""),
        userId: 1,
      },
    });
  }

  return NextResponse.json(updated);
}
