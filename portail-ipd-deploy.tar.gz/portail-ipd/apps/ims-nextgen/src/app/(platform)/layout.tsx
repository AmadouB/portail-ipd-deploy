import { AppSidebar } from "@/components/layout/app-sidebar";
import { FullscreenButton } from "@/components/layout/fullscreen-button";

export default function PlatformLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-grid">
      <AppSidebar />
      <div className="pl-[240px] transition-all duration-300">
        {children}
      </div>
      <FullscreenButton />
    </div>
  );
}
