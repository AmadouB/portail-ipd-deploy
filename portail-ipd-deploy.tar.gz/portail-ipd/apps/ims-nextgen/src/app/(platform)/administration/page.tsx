import { AdminContent } from "@/components/admin/admin-content";

export default function AdministrationPage() {
  return (
    <>
      <header className="sticky top-0 z-30 bg-[#0a0e1a]/80 backdrop-blur-xl border-b border-white/[0.06] px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold text-white">Administration</h1>
            <p className="text-xs text-white/40 mt-0.5">Gestion des utilisateurs et parametres systeme</p>
          </div>
        </div>
      </header>
      <main className="p-6">
        <AdminContent />
      </main>
    </>
  );
}
