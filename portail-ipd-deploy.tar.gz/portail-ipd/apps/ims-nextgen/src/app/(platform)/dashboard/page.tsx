import { Header } from "@/components/layout/header";
import { DashboardContent } from "@/components/dashboard/dashboard-content";

export default function DashboardPage() {
  return (
    <>
      <Header title="Dashboard de Pilotage" subtitle="IMS-NextGen | Vue strategique Direction" />
      <main className="p-6">
        <DashboardContent />
      </main>
    </>
  );
}
