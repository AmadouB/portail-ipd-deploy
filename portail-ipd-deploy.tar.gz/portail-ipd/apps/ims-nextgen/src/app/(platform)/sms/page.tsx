import { Header } from "@/components/layout/header";
import { SmsContent } from "@/components/departments/sms-content";

export default function SmsPage() {
  return (
    <>
      <Header title="SMS" subtitle="Services Maintenance & Sécurité — Équipements, ACP, Formation" />
      <SmsContent />
    </>
  );
}
