import { Header } from "@/components/layout/header";
import { LcqContent } from "@/components/departments/lcq-content";

export default function LcqPage() {
  return (
    <>
      <Header title="LCQ" subtitle="Programme de Désinfection & Contrôle Qualité" />
      <LcqContent />
    </>
  );
}
