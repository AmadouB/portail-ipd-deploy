"use client";

import { Header } from "@/components/layout/header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { FileBarChart, Download, FileText, Presentation, Table, Loader2 } from "lucide-react";
import { useState } from "react";

const slides = [
  { num: "1", section: "Page de garde", contenu: "Titre IMS, date, logo IPD", source: "Automatique" },
  { num: "2", section: "Cartographie macro-ecarts", contenu: "Vue d'ensemble 4 Majeurs + 7 Mineurs", source: "Macro_Ecarts" },
  { num: "3", section: "Synthese KPI", contenu: "Taux de cloture global, CAPA on-time vs hors delai", source: "Calcule" },
  { num: "4", section: "Actions de suivi", contenu: "Tableau actions prioritaires avec responsables et statuts", source: "Action_Log + Ecarts" },
  { num: "5-9", section: "PRODUCTION", contenu: "Locaux/Equipements, Planning reprise, Risques & Attenuation", source: "Ecarts + Actions PROD" },
  { num: "10-12", section: "LCQ", contenu: "Validation Airlock H2O2, Mold Contamination, tests", source: "Ecarts + Actions LCQ" },
  { num: "13-16", section: "ASSURANCE QUALITE", contenu: "CAPA Workshop, WHO CAPA, Inspection Readiness", source: "Ecarts AQ" },
  { num: "17-20", section: "CQVM", contenu: "Indicateurs CQVM, CAPA OMS, Prep Next Inspection", source: "Ecarts CQVM" },
  { num: "21-22", section: "DRO", contenu: "Mold Contamination (renvoi Production)", source: "Transverse" },
  { num: "23-25", section: "SMS", contenu: "Points cles, ACP a cloturer, Formation technique", source: "Ecarts + Actions SMS" },
  { num: "26", section: "SUPPLY CHAIN", contenu: "Synthese GARAP, dossiers en cours, alertes logistiques", source: "Suivi_Achats_GARAP" },
  { num: "27", section: "FINANCE", contenu: "Budget AFM, engagements, etat des paiements", source: "Action_Log WS5" },
];

export default function RapportsPage() {
  const [downloading, setDownloading] = useState<string | null>(null);

  const downloadExport = async (type: "pdf" | "pptx" | "excel") => {
    setDownloading(type);
    try {
      const res = await fetch(`/api/exports/${type}`);
      if (!res.ok) throw new Error("Export failed");
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      const ext = type === "excel" ? "xlsx" : type;
      a.download = `IMS_Rapport.${ext}`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error(err);
    } finally {
      setDownloading(null);
    }
  };

  return (
    <>
      <Header title="Rapports IMS" subtitle="Generation automatisee des presentations hebdomadaires" />
      <main className="p-6 space-y-6">
        {/* Export Actions */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="glass border-white/[0.08] glow-cyan cursor-pointer hover:border-[#0089D0]/30 transition-all" onClick={() => downloadExport("pdf")}>
            <CardContent className="p-6 flex items-center gap-4">
              <div className="rounded-xl bg-[#E74C3C]/10 p-3">
                <FileText className="h-8 w-8 text-[#E74C3C]" />
              </div>
              <div className="flex-1">
                <h3 className="text-sm font-semibold text-white">Rapport PDF</h3>
                <p className="text-xs text-white/40 mt-0.5">Synthese hebdomadaire avec KPIs et graphiques</p>
              </div>
              {downloading === "pdf" ? <Loader2 className="h-5 w-5 text-white/40 animate-spin" /> : <Download className="h-5 w-5 text-white/30" />}
            </CardContent>
          </Card>

          <Card className="glass border-white/[0.08] glow-amber cursor-pointer hover:border-[#EF7A16]/30 transition-all" onClick={() => downloadExport("pptx")}>
            <CardContent className="p-6 flex items-center gap-4">
              <div className="rounded-xl bg-[#EF7A16]/10 p-3">
                <Presentation className="h-8 w-8 text-[#EF7A16]" />
              </div>
              <div className="flex-1">
                <h3 className="text-sm font-semibold text-white">Presentation PPTX</h3>
                <p className="text-xs text-white/40 mt-0.5">Slides formatees IPD pour reunions de direction</p>
              </div>
              {downloading === "pptx" ? <Loader2 className="h-5 w-5 text-white/40 animate-spin" /> : <Download className="h-5 w-5 text-white/30" />}
            </CardContent>
          </Card>

          <Card className="glass border-white/[0.08] glow-emerald cursor-pointer hover:border-[#27AE60]/30 transition-all" onClick={() => downloadExport("excel")}>
            <CardContent className="p-6 flex items-center gap-4">
              <div className="rounded-xl bg-[#27AE60]/10 p-3">
                <Table className="h-8 w-8 text-[#27AE60]" />
              </div>
              <div className="flex-1">
                <h3 className="text-sm font-semibold text-white">Export Excel</h3>
                <p className="text-xs text-white/40 mt-0.5">Donnees brutes filtrables pour analyses</p>
              </div>
              {downloading === "excel" ? <Loader2 className="h-5 w-5 text-white/40 animate-spin" /> : <Download className="h-5 w-5 text-white/30" />}
            </CardContent>
          </Card>
        </div>

        {/* Slide Structure Reference */}
        <Card className="glass border-white/[0.08]">
          <CardHeader>
            <CardTitle className="flex items-center gap-3 text-lg text-white">
              <FileBarChart className="h-5 w-5 text-[#0089D0]" />
              Structure de la presentation hebdomadaire (27 slides)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-white/[0.08]">
                    <th className="py-2 px-3 text-left text-white/40 font-medium">Slide(s)</th>
                    <th className="py-2 px-3 text-left text-white/40 font-medium">Section</th>
                    <th className="py-2 px-3 text-left text-white/40 font-medium">Contenu</th>
                    <th className="py-2 px-3 text-left text-white/40 font-medium">Source</th>
                  </tr>
                </thead>
                <tbody>
                  {slides.map((s) => (
                    <tr key={s.num} className="border-b border-white/[0.04] hover:bg-white/[0.02]">
                      <td className="py-2 px-3">
                        <Badge variant="secondary" className="bg-[#0089D0]/10 text-[#0089D0] font-mono text-xs">
                          {s.num}
                        </Badge>
                      </td>
                      <td className="py-2 px-3 text-white/80 font-medium">{s.section}</td>
                      <td className="py-2 px-3 text-white/50">{s.contenu}</td>
                      <td className="py-2 px-3">
                        <span className="text-xs text-white/30">{s.source}</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </main>
    </>
  );
}
