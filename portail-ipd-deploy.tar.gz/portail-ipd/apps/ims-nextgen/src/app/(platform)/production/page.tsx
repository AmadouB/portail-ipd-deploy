import { Header } from "@/components/layout/header";
import { ProductionContent } from "@/components/departments/production-content";

export default function ProductionPage() {
  return (
    <>
      <Header title="Production" subtitle="Validation Procédé de Fabrication & Aseptique" />
      <ProductionContent />
    </>
  );
}
