import { Header } from "@/components/layout/header";
import { AqContent } from "@/components/departments/aq-content";

export default function AssuranceQualitePage() {
  return (
    <>
      <Header title="Assurance Qualité" subtitle="Système Qualité Pharmaceutique — Workshop, CAPA, Inspection Readiness" />
      <AqContent />
    </>
  );
}
