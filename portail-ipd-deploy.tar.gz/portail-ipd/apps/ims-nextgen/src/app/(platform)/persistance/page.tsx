import { Header } from "@/components/layout/header";
import { PersistanceContent } from "@/components/persistance/persistance-content";

export default function PersistancePage() {
  return (
    <>
      <Header title="Moteur de Persistance" subtitle="Suivi de la durée de non-résolution des actions et commentaires" />
      <PersistanceContent />
    </>
  );
}
