import { Header } from "@/components/layout/header";
import { prisma } from "@/lib/prisma";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { notFound } from "next/navigation";

// Force runtime DB access
export const dynamic = 'force-dynamic';

export default async function ActionDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const action = await prisma.actionAFM.findUnique({
    where: { id: parseInt(id) },
    include: { workstream: true, responsables: { include: { user: true } } },
  });
  if (!action) return notFound();

  return (
    <>
      <Header title={`Action #${action.chronoLegacy}`} subtitle={action.workstream.libelle} />
      <main className="p-6 space-y-6">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card className="glass border-white/[0.08]"><CardContent className="p-4">
            <p className="text-xs text-white/40">Statut</p>
            <p className="text-lg font-bold text-white mt-1">{action.statut.replace("_", " ")}</p>
          </CardContent></Card>
          <Card className="glass border-white/[0.08]"><CardContent className="p-4">
            <p className="text-xs text-white/40">Score Risque</p>
            <p className="text-lg font-bold text-white mt-1">{action.scoreRisque}/25 ({action.niveauCriticite})</p>
          </CardContent></Card>
          <Card className="glass border-white/[0.08]"><CardContent className="p-4">
            <p className="text-xs text-white/40">Avancement</p>
            <p className="text-lg font-bold text-white mt-1">{Math.round(action.avancement * 100)}%</p>
          </CardContent></Card>
          <Card className="glass border-white/[0.08]"><CardContent className="p-4">
            <p className="text-xs text-white/40">Deadline</p>
            <p className="text-lg font-bold text-white mt-1 font-mono">{action.deadlineInitiale}</p>
          </CardContent></Card>
        </div>
        <Card className="glass border-white/[0.08]"><CardContent className="p-4 space-y-3 text-sm">
          <div><span className="text-white/40">Description:</span> <p className="text-white/70 mt-1">{action.description}</p></div>
          <div><span className="text-white/40">Responsable(s):</span> <span className="text-white/70">{action.responsables.map((r) => r.user.name).join(", ") || "-"}</span></div>
          <div className="flex gap-3"><Badge variant="outline" className={action.estImportant ? "bg-red-500/10 text-red-400 border-red-500/20" : "border-white/10 text-white/30"}>{action.estImportant ? "Important" : "Non important"}</Badge><Badge variant="outline" className={action.estUrgent ? "bg-[#EF7A16]/10 text-[#EF7A16] border-amber-500/20" : "border-white/10 text-white/30"}>{action.estUrgent ? "Urgent" : "Non urgent"}</Badge></div>
        </CardContent></Card>
      </main>
    </>
  );
}
