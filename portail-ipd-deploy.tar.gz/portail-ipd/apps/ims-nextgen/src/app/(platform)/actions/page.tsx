import { Header } from "@/components/layout/header";
import { ActionsContent } from "@/components/actions/actions-content";

export default function ActionsPage() {
  return (
    <>
      <Header title="Actions AFM" subtitle="36 actions | Lancement Production AFM PQ OMS 2027" />
      <main className="p-6">
        <ActionsContent />
      </main>
    </>
  );
}
