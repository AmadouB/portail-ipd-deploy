import { Header } from "@/components/layout/header";
import { ProduitsContent } from "@/components/produits/produits-content";

export default function ProduitsPage() {
  return (
    <>
      <Header title="Analyse Produits" subtitle="Suivi des commandes, fournisseurs et approvisionnements par entité" />
      <ProduitsContent />
    </>
  );
}
