import { Header } from "@/components/layout/header";
import { EcartsContent } from "@/components/ecarts/ecarts-content";

export default function EcartsPage() {
  return (
    <>
      <Header title="Ecarts OMS" subtitle="53 ecarts | Inspection ARP Juillet 2025" />
      <main className="p-6">
        <EcartsContent />
      </main>
    </>
  );
}
