import { Header } from "@/components/layout/header";
import { prisma } from "@/lib/prisma";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { notFound } from "next/navigation";

// Force runtime DB access
export const dynamic = 'force-dynamic';

export default async function EcartDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const ecart = await prisma.ecart.findUnique({
    where: { id: parseInt(id) },
    include: { service: true, macroEcart: true, snapshots: { orderBy: { snapshotDate: "asc" } } },
  });

  if (!ecart) return notFound();

  const statutColor = ecart.statut === "CLOTURE" ? "bg-[#27AE60]/10 text-[#27AE60] border-emerald-500/20"
    : ecart.statut === "REVU" ? "bg-blue-500/10 text-blue-400 border-blue-500/20"
    : "bg-[#EF7A16]/10 text-[#EF7A16] border-amber-500/20";

  return (
    <>
      <Header title={`Ecart ${ecart.numero}`} subtitle={ecart.nomEcart} />
      <main className="p-6 space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="glass border-white/[0.08]">
            <CardContent className="p-4">
              <p className="text-xs text-white/40">Statut</p>
              <Badge variant="outline" className={`mt-2 ${statutColor}`}>{ecart.statut.replace("_", " ")}</Badge>
            </CardContent>
          </Card>
          <Card className="glass border-white/[0.08]">
            <CardContent className="p-4">
              <p className="text-xs text-white/40">Avancement</p>
              <p className="text-2xl font-bold text-white mt-1">{Math.round(ecart.pctAvancement * 100)}%</p>
            </CardContent>
          </Card>
          <Card className="glass border-white/[0.08]">
            <CardContent className="p-4">
              <p className="text-xs text-white/40">Service</p>
              <p className="text-lg font-semibold text-white mt-1">{ecart.service.libelle}</p>
            </CardContent>
          </Card>
        </div>

        <Card className="glass border-white/[0.08]">
          <CardHeader><CardTitle className="text-sm text-white/70">Details</CardTitle></CardHeader>
          <CardContent className="space-y-3 text-sm">
            <div><span className="text-white/40">Classification:</span> <Badge variant="outline" className={ecart.classification === "Majeur" ? "bg-red-500/10 text-red-400 border-red-500/20" : "bg-[#EF7A16]/10 text-[#EF7A16] border-amber-500/20"}>{ecart.classification}</Badge></div>
            <div><span className="text-white/40">Macro-ecart:</span> <span className="text-[#0089D0] font-mono">{ecart.macroEcart.numero}</span> - {ecart.macroEcart.description.substring(0, 60)}</div>
            <div><span className="text-white/40">Version:</span> <span className="text-white/70">v{ecart.version}</span></div>
            <div><span className="text-white/40">CAPA:</span> {ecart.capaHorsDelai ? <Badge variant="outline" className="bg-red-500/10 text-red-400 border-red-500/20">Hors delai</Badge> : <Badge variant="outline" className="bg-[#27AE60]/10 text-[#27AE60] border-emerald-500/20">On-time</Badge>}</div>
            {ecart.description && <div><span className="text-white/40">Description:</span> <p className="text-white/60 mt-1">{ecart.description}</p></div>}
            {ecart.actionsCorrectives && <div><span className="text-white/40">Actions correctives:</span> <p className="text-white/60 mt-1">{ecart.actionsCorrectives}</p></div>}
          </CardContent>
        </Card>

        <Card className="glass border-white/[0.08]">
          <CardHeader><CardTitle className="text-sm text-white/70">Historique Snapshots</CardTitle></CardHeader>
          <CardContent>
            <table className="w-full">
              <thead><tr className="text-[10px] text-white/30 uppercase tracking-wider">
                <th className="text-left py-2 px-2">Date</th><th className="text-left py-2 px-2">Label</th><th className="text-left py-2 px-2">Statut</th><th className="text-left py-2 px-2">Avancement</th><th className="text-left py-2 px-2">Delta</th>
              </tr></thead>
              <tbody>{ecart.snapshots.map((s) => (
                <tr key={s.id} className="border-t border-white/[0.03]">
                  <td className="py-2 px-2 text-xs text-white/40 font-mono">{s.snapshotDate}</td>
                  <td className="py-2 px-2 text-xs text-white/50">{s.snapshotLabel}</td>
                  <td className="py-2 px-2 text-xs text-white/50">{s.statut}</td>
                  <td className="py-2 px-2 text-xs text-white/60">{Math.round(s.pctAvancement * 100)}%</td>
                  <td className="py-2 px-2 text-xs font-mono">{s.margeProgression !== null ? <span className={s.margeProgression >= 0 ? "text-[#27AE60]" : "text-red-400"}>{s.margeProgression > 0 ? "+" : ""}{Math.round(s.margeProgression * 100)}%</span> : "-"}</td>
                </tr>
              ))}</tbody>
            </table>
          </CardContent>
        </Card>
      </main>
    </>
  );
}
