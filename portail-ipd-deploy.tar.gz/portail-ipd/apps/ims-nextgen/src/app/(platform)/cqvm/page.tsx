import { Header } from "@/components/layout/header";
import { CqvmContent } from "@/components/departments/cqvm-content";

export default function CqvmPage() {
  return (
    <>
      <Header title="CQVM" subtitle="Contrôle Qualité & Validation des Méthodes" />
      <CqvmContent />
    </>
  );
}
