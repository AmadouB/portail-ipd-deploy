"use client";

import { PresentationMode } from "@/components/presentation/presentation-mode";

export default function PresentationPage() {
  return <PresentationMode />;
}
