import { Header } from "@/components/layout/header";
import { prisma } from "@/lib/prisma";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

// Force runtime DB access
export const dynamic = 'force-dynamic';

export default async function AuditPage() {
  const trails = await prisma.auditTrail.findMany({
    include: { user: true },
    orderBy: { timestamp: "desc" },
    take: 100,
  });

  const actionColors: Record<string, string> = {
    INSERT: "bg-[#27AE60]/10 text-[#27AE60] border-emerald-500/20",
    UPDATE: "bg-[#EF7A16]/10 text-[#EF7A16] border-amber-500/20",
    DELETE: "bg-red-500/10 text-red-400 border-red-500/20",
  };

  return (
    <>
      <Header title="Audit Trail" subtitle="Tracabilite complete | Conforme GMP/OMS" />
      <main className="p-6">
        <Card className="glass border-white/[0.08]">
          <CardHeader>
            <CardTitle className="text-sm text-white/70">Journal des modifications</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="text-[10px] text-white/30 uppercase tracking-wider border-b border-white/[0.06]">
                    <th className="text-left py-3 px-3">Date</th>
                    <th className="text-left py-3 px-3">Utilisateur</th>
                    <th className="text-left py-3 px-3">Action</th>
                    <th className="text-left py-3 px-3">Table</th>
                    <th className="text-left py-3 px-3">ID</th>
                    <th className="text-left py-3 px-3">Champ</th>
                    <th className="text-left py-3 px-3">Avant</th>
                    <th className="text-left py-3 px-3">Apres</th>
                  </tr>
                </thead>
                <tbody>
                  {trails.map((t) => (
                    <tr key={t.id} className="border-t border-white/[0.03] hover:bg-white/[0.02] transition-colors">
                      <td className="py-2.5 px-3 text-xs text-white/40 font-mono">{new Date(t.timestamp).toLocaleString("fr-FR")}</td>
                      <td className="py-2.5 px-3 text-xs text-white/60">{t.user.name}</td>
                      <td className="py-2.5 px-3"><Badge variant="outline" className={`text-[10px] ${actionColors[t.actionType] || ""}`}>{t.actionType}</Badge></td>
                      <td className="py-2.5 px-3 text-xs text-[#0089D0] font-mono">{t.tableSource}</td>
                      <td className="py-2.5 px-3 text-xs text-white/30 font-mono">{t.recordId}</td>
                      <td className="py-2.5 px-3 text-xs text-white/50">{t.champModifie || "-"}</td>
                      <td className="py-2.5 px-3 text-xs text-red-400/60 font-mono">{t.valeurAvant || "-"}</td>
                      <td className="py-2.5 px-3 text-xs text-[#27AE60]/60 font-mono">{t.valeurApres || "-"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </main>
    </>
  );
}
