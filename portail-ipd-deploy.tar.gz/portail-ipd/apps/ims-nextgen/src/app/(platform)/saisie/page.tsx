import { Header } from "@/components/layout/header";
import { SaisieContent } from "@/components/saisie/saisie-content";

export default function SaisiePage() {
  return (
    <>
      <Header title="Saisie des Activités" subtitle="Portail de saisie départemental — Création et mise à jour des actions et écarts" />
      <SaisieContent />
    </>
  );
}
