import { Header } from "@/components/layout/header";
import { FinanceContent } from "@/components/departments/finance-content";

export default function FinancePage() {
  return (
    <>
      <Header title="Finance" subtitle="Suivi Budgétaire & Commandes AFM" />
      <FinanceContent />
    </>
  );
}
