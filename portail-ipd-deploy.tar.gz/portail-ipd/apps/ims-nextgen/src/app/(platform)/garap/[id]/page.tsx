import { Header } from "@/components/layout/header";
import { prisma } from "@/lib/prisma";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { notFound } from "next/navigation";

// Force runtime DB access
export const dynamic = 'force-dynamic';

const statutColors: Record<string, string> = {
  ATTENTE_FOURNISSEUR: "bg-slate-500/10 text-slate-400 border-slate-500/20",
  BC_EMIS: "bg-blue-500/10 text-blue-400 border-blue-500/20",
  EN_COURS_LIVRAISON: "bg-[#052A62]/10 text-[#052A62] border-[#052A62]/20",
  PARTIELLEMENT_LIVRE: "bg-[#EF7A16]/10 text-[#EF7A16] border-[#EF7A16]/20",
  LIVRE: "bg-[#27AE60]/10 text-[#27AE60] border-[#27AE60]/20",
  CLOTUREE: "bg-[#27AE60]/10 text-[#27AE60] border-[#27AE60]/20",
  ANNULE: "bg-red-500/10 text-red-400 border-red-500/20",
};

export default async function GarapDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const dossier = await prisma.suiviGarap.findUnique({
    where: { id: parseInt(id) },
    include: { entite: true, fournisseur: true, devise: true },
  });
  if (!dossier) return notFound();

  const formatMontant = (montant: number, codeIso: string) => {
    if (codeIso === "XOF") return `${montant.toLocaleString("fr-FR")} FCFA`;
    return `${montant.toLocaleString("fr-FR")} ${codeIso}`;
  };

  return (
    <>
      <Header title={`Dossier GARAP #${dossier.id}`} subtitle={dossier.entite.libelle} />
      <main className="p-6 space-y-6">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card className="glass border-white/[0.08]"><CardContent className="p-4">
            <p className="text-xs text-white/40">Statut</p>
            <Badge variant="outline" className={`mt-2 ${statutColors[dossier.statutWorkflow] || "border-white/10 text-white/50"}`}>
              {dossier.statutWorkflow.replace(/_/g, " ")}
            </Badge>
          </CardContent></Card>
          <Card className="glass border-white/[0.08]"><CardContent className="p-4">
            <p className="text-xs text-white/40">Montant</p>
            <p className="text-lg font-bold text-white mt-1">{formatMontant(dossier.montant ?? 0, dossier.devise.codeIso)}</p>
          </CardContent></Card>
          <Card className="glass border-white/[0.08]"><CardContent className="p-4">
            <p className="text-xs text-white/40">Nature</p>
            <p className="text-lg font-bold text-white mt-1">{dossier.natureProduits}</p>
          </CardContent></Card>
          <Card className="glass border-white/[0.08]"><CardContent className="p-4">
            <p className="text-xs text-white/40">N DA/BC</p>
            <p className="text-lg font-bold text-[#0089D0] mt-1 font-mono">{dossier.numDaBc || "-"}</p>
          </CardContent></Card>
        </div>

        <Card className="glass border-white/[0.08]">
          <CardHeader><CardTitle className="text-sm text-white/70">Details du dossier</CardTitle></CardHeader>
          <CardContent className="space-y-3 text-sm">
            <div><span className="text-white/40">Expression du besoin:</span> <p className="text-white/70 mt-1">{dossier.expressionBesoin}</p></div>
            <div><span className="text-white/40">Fournisseur:</span> <span className="text-white/70">{dossier.fournisseur?.raisonSociale || "-"}</span></div>
            <div><span className="text-white/40">Entite:</span> <span className="text-white/70">{dossier.entite.libelle}</span></div>
            {dossier.dateDerniereRelance && <div><span className="text-white/40">Derniere relance:</span> <span className="text-white/70 font-mono">{dossier.dateDerniereRelance}</span></div>}
            {dossier.dateLivraisonPrevue && <div><span className="text-white/40">Livraison prevue:</span> <span className="text-white/70 font-mono">{dossier.dateLivraisonPrevue}</span></div>}
            {dossier.dateLivraisonEffective && <div><span className="text-white/40">Livraison effective:</span> <span className="text-white/70 font-mono">{dossier.dateLivraisonEffective}</span></div>}
            {dossier.commentaireDal && <div><span className="text-white/40">Commentaire DAL:</span> <p className="text-white/60 mt-1">{dossier.commentaireDal}</p></div>}
          </CardContent>
        </Card>
      </main>
    </>
  );
}
