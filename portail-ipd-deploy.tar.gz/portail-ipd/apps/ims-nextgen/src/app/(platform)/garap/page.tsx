import { Header } from "@/components/layout/header";
import { GarapContent } from "@/components/garap/garap-content";

export default function GarapPage() {
  return (
    <>
      <Header title="Suivi Achats GARAP" subtitle="130 dossiers | Cycle de vie complet des commandes" />
      <main className="p-6">
        <GarapContent />
      </main>
    </>
  );
}
