import { Header } from "@/components/layout/header";
import { RisquesContent } from "@/components/risk/risques-content";

export default function RisquesPage() {
  return (
    <>
      <Header title="Matrice de Risques RIV" subtitle="Risk Impact Value | 5x5 Matrix" />
      <main className="p-6">
        <RisquesContent />
      </main>
    </>
  );
}
