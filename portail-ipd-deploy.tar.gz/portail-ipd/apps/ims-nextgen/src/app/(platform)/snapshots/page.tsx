import { Header } from "@/components/layout/header";
import { SnapshotsContent } from "@/components/dashboard/snapshots-content";

export default function SnapshotsPage() {
  return (
    <>
      <Header title="Snapshots Historiques" subtitle="Captures periodiques | Analyse de tendance" />
      <main className="p-6">
        <SnapshotsContent />
      </main>
    </>
  );
}
