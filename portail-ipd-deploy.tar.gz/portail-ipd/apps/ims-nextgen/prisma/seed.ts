import { PrismaClient } from "../src/generated/prisma/client.js";
import { PrismaBetterSqlite3 } from "@prisma/adapter-better-sqlite3";
import { hashSync } from "bcryptjs";
import path from "path";
import { fileURLToPath } from "url";

const __filename2 = fileURLToPath(import.meta.url);
const __dirname2 = path.dirname(__filename2);

const adapter = new PrismaBetterSqlite3({ url: path.resolve(__dirname2, "..", "dev.db") });
const prisma = new PrismaClient({ adapter } as any);

async function main() {
  console.log("Seeding database...");

  // ── SERVICES (6) ──
  const services = await Promise.all([
    prisma.service.create({ data: { code: "PROD", libelle: "PRODUCTION", libelleCourt: "Production" } }),
    prisma.service.create({ data: { code: "AQ", libelle: "ASSURANCE QUALITE", libelleCourt: "AQ" } }),
    prisma.service.create({ data: { code: "CQVM", libelle: "CONTROLE, QUALIFICATION, VALIDATION, METROLOGIE", libelleCourt: "CQVM" } }),
    prisma.service.create({ data: { code: "CQ", libelle: "CONTROLE QUALITE", libelleCourt: "CQ" } }),
    prisma.service.create({ data: { code: "SMS", libelle: "SERVICE MAINTENANCE SCIENTIFIQUE", libelleCourt: "SMS" } }),
    prisma.service.create({ data: { code: "PHARM", libelle: "PHARMACIEN RESPONSABLE", libelleCourt: "Pharmacien" } }),
  ]);
  const [sProd, sAQ, sCQVM, sCQ, sSMS, sPharm] = services;

  // ── WORKSTREAMS (8) ──
  const workstreams = await Promise.all([
    prisma.workstream.create({ data: { code: "WS1", libelle: "WS1-Infra", responsableWs: "Babacar" } }),
    prisma.workstream.create({ data: { code: "WS3", libelle: "WS3-CQ Robustness & EM", responsableWs: "Lamine T." } }),
    prisma.workstream.create({ data: { code: "WS4", libelle: "WS4-Prod", responsableWs: "Babacar" } }),
    prisma.workstream.create({ data: { code: "WS5F", libelle: "WS5-Finances & Achats", responsableWs: "Lamine S." } }),
    prisma.workstream.create({ data: { code: "WS5H", libelle: "WS5-HR Consultants & Int. Staff", responsableWs: "Moussa S." } }),
    prisma.workstream.create({ data: { code: "WS7", libelle: "WS7-Regulatory & Pharmacovigilance", responsableWs: "Awa L." } }),
    prisma.workstream.create({ data: { code: "TTT", libelle: "WS TTT (Tech Transfer)", responsableWs: "Serigne" } }),
    prisma.workstream.create({ data: { code: "PMO", libelle: "PMO / All Streams", responsableWs: "Patrick" } }),
  ]);
  const [ws1, ws3, ws4, ws5f, ws5h, ws7, wsTTT, wsPMO] = workstreams;

  // ── ENTITES GARAP (5) ──
  const entites = await Promise.all([
    prisma.entite.create({ data: { code: "LCQ", libelle: "Laboratoire de Controle Qualite" } }),
    prisma.entite.create({ data: { code: "PROD", libelle: "Production" } }),
    prisma.entite.create({ data: { code: "CQVM", libelle: "CQVM" } }),
    prisma.entite.create({ data: { code: "SMS", libelle: "Service Maintenance Scientifique" } }),
    prisma.entite.create({ data: { code: "PLCQ", libelle: "PROD/LCQ" } }),
  ]);
  const [eLCQ, ePROD, eCQVM, eSMS, ePLCQ] = entites;

  // ── DEVISES (5) ──
  const devises = await Promise.all([
    prisma.devise.create({ data: { codeIso: "EUR", symbole: "\u20ac", tauxConversionXof: 655.957 } }),
    prisma.devise.create({ data: { codeIso: "XOF", symbole: "CFA", tauxConversionXof: 1 } }),
    prisma.devise.create({ data: { codeIso: "USD", symbole: "$", tauxConversionXof: 615.0 } }),
    prisma.devise.create({ data: { codeIso: "ZAR", symbole: "R", tauxConversionXof: 34.5 } }),
    prisma.devise.create({ data: { codeIso: "GBP", symbole: "\u00a3", tauxConversionXof: 780.0 } }),
  ]);
  const [dEUR, dXOF, dUSD, dZAR, dGBP] = devises;

  // ── FOURNISSEURS (10) ──
  const fournisseurs = await Promise.all([
    prisma.fournisseur.create({ data: { raisonSociale: "Thermofisher", pays: "USA", delaiMoyenLivraison: 45 } }),
    prisma.fournisseur.create({ data: { raisonSociale: "IPP", pays: "France", delaiMoyenLivraison: 30 } }),
    prisma.fournisseur.create({ data: { raisonSociale: "Sidji", pays: "Senegal", delaiMoyenLivraison: 7 } }),
    prisma.fournisseur.create({ data: { raisonSociale: "JCE", pays: "France", delaiMoyenLivraison: 35 } }),
    prisma.fournisseur.create({ data: { raisonSociale: "Fischer Scientific", pays: "USA", delaiMoyenLivraison: 40 } }),
    prisma.fournisseur.create({ data: { raisonSociale: "CEVA", pays: "France", delaiMoyenLivraison: 25 } }),
    prisma.fournisseur.create({ data: { raisonSociale: "Pharmtech", pays: "Allemagne", delaiMoyenLivraison: 60 } }),
    prisma.fournisseur.create({ data: { raisonSociale: "HVAC Conseil", pays: "France", delaiMoyenLivraison: 20 } }),
    prisma.fournisseur.create({ data: { raisonSociale: "DND Biotech", pays: "Inde", delaiMoyenLivraison: 50 } }),
    prisma.fournisseur.create({ data: { raisonSociale: "Bioquell", pays: "UK", delaiMoyenLivraison: 35 } }),
  ]);

  // ── USERS (21) ──
  const pwd = hashSync("ims2026", 10);
  const users = await Promise.all([
    prisma.user.create({ data: { name: "Admin IMS", email: "admin@ipd.sn", password: pwd, role: "ADMIN", service: "PMO", poste: "Administrateur systeme", telephone: "+221 77 000 0001" } }),
    prisma.user.create({ data: { name: "Patrick", email: "patrick@ipd.sn", password: pwd, role: "CONTRIBUTEUR", service: "PMO", poste: "Chef de projet PMO" } }),
    prisma.user.create({ data: { name: "Babacar", email: "babacar@ipd.sn", password: pwd, role: "CONTRIBUTEUR", service: "PRODUCTION", poste: "Responsable production" } }),
    prisma.user.create({ data: { name: "Aminata", email: "aminata@ipd.sn", password: pwd, role: "CONTRIBUTEUR", service: "AQ", poste: "Responsable assurance qualite" } }),
    prisma.user.create({ data: { name: "Awa L.", email: "awa.l@ipd.sn", password: pwd, role: "CONTRIBUTEUR", service: "Regulatory", poste: "Charge affaires reglementaires" } }),
    prisma.user.create({ data: { name: "Moussa S.", email: "moussa.s@ipd.sn", password: pwd, role: "CONTRIBUTEUR", service: "RH", poste: "Responsable RH" } }),
    prisma.user.create({ data: { name: "Fode D.", email: "fode.d@ipd.sn", password: pwd, role: "CONTRIBUTEUR", service: "PRODUCTION", poste: "Superviseur fabrication" } }),
    prisma.user.create({ data: { name: "Omar G.", email: "omar.g@ipd.sn", password: pwd, role: "CONTRIBUTEUR", service: "PRODUCTION", poste: "Technicien production" } }),
    prisma.user.create({ data: { name: "Jean-Raymond", email: "jean.raymond@ipd.sn", password: pwd, role: "CONTRIBUTEUR", service: "AQ", poste: "Auditeur qualite interne" } }),
    prisma.user.create({ data: { name: "Lamine T.", email: "lamine.t@ipd.sn", password: pwd, role: "CONTRIBUTEUR", service: "LCQ", poste: "Analyste controle qualite" } }),
    prisma.user.create({ data: { name: "Serigne", email: "serigne@ipd.sn", password: pwd, role: "CONTRIBUTEUR", service: "CQVM", poste: "Responsable CQVM" } }),
    prisma.user.create({ data: { name: "AKC", email: "akc@ipd.sn", password: pwd, role: "CONTRIBUTEUR", service: "CQVM", poste: "Technicien CQVM" } }),
    prisma.user.create({ data: { name: "L. Mendy", email: "l.mendy@ipd.sn", password: pwd, role: "CONTRIBUTEUR", service: "SMS", poste: "Responsable SMS" } }),
    prisma.user.create({ data: { name: "Magatte D.", email: "magatte.d@ipd.sn", password: pwd, role: "CONTRIBUTEUR", service: "SMS", poste: "Technicien SMS" } }),
    prisma.user.create({ data: { name: "Lamine S.", email: "lamine.s@ipd.sn", password: pwd, role: "CONTRIBUTEUR", service: "Finance", poste: "Responsable financier" } }),
    prisma.user.create({ data: { name: "Cheikhou D.", email: "cheikhou.d@ipd.sn", password: pwd, role: "CONTRIBUTEUR", service: "Finance", poste: "Comptable" } }),
    prisma.user.create({ data: { name: "Dr. Ndiaye", email: "ndiaye@ipd.sn", password: pwd, role: "LECTEUR", service: "Direction", poste: "Directeur adjoint" } }),
    prisma.user.create({ data: { name: "Auditeur OMS", email: "auditeur@ipd.sn", password: pwd, role: "AUDITEUR", service: "Externe", poste: "Auditeur international OMS" } }),
    prisma.user.create({ data: { name: "Amadou BAO", email: "amadou@ipd.sn", password: pwd, role: "ADMIN", service: "SEID", poste: "Directeur SEID", telephone: "+221 77 000 0019" } }),
    prisma.user.create({ data: { name: "Papa Seye", email: "papa.seye@ipd.sn", password: pwd, role: "ADMIN", service: "Direction", poste: "Directeur UVFJ", telephone: "+221 77 000 0020" } }),
    prisma.user.create({ data: { name: "Fatoumata Niang", email: "fatoumata.niang@ipd.sn", password: pwd, role: "ADMIN", service: "AQ", poste: "Directrice Assurance Qualite", telephone: "+221 77 000 0021" } }),
  ]);

  // ── MACRO-ECARTS (11) ──
  const macroEcarts = await Promise.all([
    prisma.macroEcart.create({ data: { numero: "2.1", description: "La validation du procede de fabrication et du procede aseptique a ete jugee deficiente", classification: "Majeur", nbEcartsEnfants: 8, tauxCloture: 0.875 } }),
    prisma.macroEcart.create({ data: { numero: "2.2", description: "Facilities and equipment were found deficient", classification: "Majeur", nbEcartsEnfants: 7, tauxCloture: 0.857 } }),
    prisma.macroEcart.create({ data: { numero: "2.3", description: "The pharmaceutical quality system was deficient", classification: "Majeur", nbEcartsEnfants: 6, tauxCloture: 0.833 } }),
    prisma.macroEcart.create({ data: { numero: "2.4", description: "Le programme de desinfection a ete juge deficient", classification: "Majeur", nbEcartsEnfants: 5, tauxCloture: 1.0 } }),
    prisma.macroEcart.create({ data: { numero: "3.1", description: "La gestion du seed lot est inadequate", classification: "Mineur", nbEcartsEnfants: 4, tauxCloture: 1.0 } }),
    prisma.macroEcart.create({ data: { numero: "3.2", description: "Les gants utilises par les operateurs dans les processus manuels aseptiques", classification: "Mineur", nbEcartsEnfants: 4, tauxCloture: 1.0 } }),
    prisma.macroEcart.create({ data: { numero: "3.3", description: "Le tube du compteur de particules de l emplacement le plus proche", classification: "Mineur", nbEcartsEnfants: 3, tauxCloture: 1.0 } }),
    prisma.macroEcart.create({ data: { numero: "3.4", description: "Le VMP indique que les qualifications des installations n ont pas ete completees", classification: "Mineur", nbEcartsEnfants: 5, tauxCloture: 0.8 } }),
    prisma.macroEcart.create({ data: { numero: "3.5", description: "Le CCS est inadequat", classification: "Mineur", nbEcartsEnfants: 4, tauxCloture: 1.0 } }),
    prisma.macroEcart.create({ data: { numero: "3.6", description: "Le manuel de qualite ne faisait pas reference a la structure organisationnelle", classification: "Mineur", nbEcartsEnfants: 4, tauxCloture: 1.0 } }),
    prisma.macroEcart.create({ data: { numero: "3.7", description: "Sampling was conducted in a grade A BSC installed in grade D room", classification: "Mineur", nbEcartsEnfants: 3, tauxCloture: 1.0 } }),
  ]);

  // ── ECARTS (53) ──
  // Helper function
  function ecart(
    numero: string, macroIdx: number, serviceId: number, classification: string,
    statut: string, pct: number, horsDelai: boolean, nomEcart: string, desc: string,
    version: number, dateFin?: string, dateCloture?: string
  ) {
    return {
      numero, macroEcartId: macroEcarts[macroIdx].id, serviceId, classification, statut,
      pctAvancement: pct, capaHorsDelai: horsDelai, nomEcart, description: desc,
      version, dateFinalisation: dateFin || "2025-12-31",
      dateCloture: statut === "CLOTURE" ? (dateCloture || "2026-01-15") : null,
      dateCreation: "2025-08-01",
      actionsCorrectives: statut === "CLOTURE" ? "Actions correctives implementees et validees" : "Plan CAPA en cours d execution",
      updatedById: users[1].id,
    };
  }

  // PRODUCTION: 23 ecarts
  const ecartsData = [
    // Macro 2.1 (8 ecarts) - PRODUCTION heavy
    ecart("2.1.1", 0, sProd.id, "Majeur", "CLOTURE", 1.0, true, "Validation procede aseptique - MFT", "Le Media Fill Test n est pas representatif des conditions de production", 12, "2025-10-15", "2025-12-20"),
    ecart("2.1.2", 0, sProd.id, "Majeur", "CLOTURE", 1.0, false, "Protocole VPA incomplet", "Le protocole de Validation du Procede Aseptique ne couvre pas tous les scenarios", 8, "2025-11-30", "2025-11-25"),
    ecart("2.1.3", 0, sProd.id, "Majeur", "CLOTURE", 1.0, true, "Qualification isolateur Bioquell", "L isolateur Bioquell n a pas ete requalifie apres maintenance majeure", 15, "2025-10-01", "2025-12-10"),
    ecart("2.1.4", 0, sCQVM.id, "Majeur", "REVU", 0.85, true, "Revalidation procede remplissage", "Le procede de remplissage aseptique necessite une revalidation complete", 18, "2025-11-15"),
    ecart("2.1.5", 0, sProd.id, "Majeur", "CLOTURE", 1.0, false, "Formation operateurs aseptique", "Formation des operateurs sur les nouvelles procedures aseptiques", 6, "2025-12-01", "2025-11-28"),
    ecart("2.1.6", 0, sCQVM.id, "Majeur", "CLOTURE", 1.0, true, "Monitoring particules ZAC", "Le monitoring des particules en ZAC ne respecte pas la frequence requise", 10, "2025-10-30", "2026-01-05"),
    ecart("2.1.7", 0, sProd.id, "Majeur", "CLOTURE", 1.0, false, "Campagne de qualification", "Campagne de qualification des equipements de production", 7, "2025-12-15", "2025-12-10"),
    ecart("2.1.8", 0, sAQ.id, "Majeur", "EN_COURS", 0.70, true, "Revue PQR annuelle", "La revue qualite produit annuelle n integre pas les donnees de validation", 5, "2026-01-31"),

    // Macro 2.2 (7 ecarts) - Facilities
    ecart("2.2.1", 1, sProd.id, "Majeur", "CLOTURE", 1.0, true, "Etancheite ZAC production", "Defauts d etancheite identifies dans la ZAC de production", 14, "2025-09-30", "2025-12-15"),
    ecart("2.2.2", 1, sSMS.id, "Majeur", "CLOTURE", 1.0, false, "HVAC qualification", "Le systeme HVAC n est pas qualifie conformement aux normes GMP", 9, "2025-11-15", "2025-11-10"),
    ecart("2.2.3", 1, sProd.id, "Majeur", "CLOTURE", 1.0, true, "Classification salles propres", "Requalification de la classification des salles propres requise", 11, "2025-10-15", "2026-01-08"),
    ecart("2.2.4", 1, sProd.id, "Majeur", "REVU", 0.90, true, "Remplacement filtres HEPA", "Les filtres HEPA n ont pas ete remplaces selon le planning", 8, "2025-12-01"),
    ecart("2.2.5", 1, sProd.id, "Majeur", "CLOTURE", 1.0, false, "Calibration instruments", "Equipements de mesure hors planning de calibration", 6, "2025-11-30", "2025-11-25"),
    ecart("2.2.6", 1, sCQVM.id, "Majeur", "CLOTURE", 1.0, true, "Qualification eau purifiee", "Le systeme de production d eau purifiee necessite une requalification", 13, "2025-10-01", "2025-12-20"),
    ecart("2.2.7", 1, sProd.id, "Majeur", "EN_COURS", 0.60, true, "Mise a niveau locaux", "Travaux de mise a niveau des locaux de production", 4, "2026-02-28"),

    // Macro 2.3 (6 ecarts) - QA System
    ecart("2.3.1", 2, sAQ.id, "Majeur", "CLOTURE", 1.0, false, "Revue systeme qualite pharma", "Le systeme qualite pharmaceutique ne couvre pas tous les processus requis", 10, "2025-11-30", "2025-11-28"),
    ecart("2.3.2", 2, sAQ.id, "Majeur", "CLOTURE", 1.0, true, "CAPA Workshop contamination ZAC", "Atelier CAPA pour la contamination recurrente en ZAC", 16, "2025-10-15", "2025-12-30"),
    ecart("2.3.3", 2, sAQ.id, "Majeur", "CLOTURE", 1.0, false, "WHO CAPA status tracking", "Mise en place du suivi CAPA conforme aux exigences OMS", 7, "2025-12-01", "2025-11-30"),
    ecart("2.3.4", 2, sAQ.id, "Majeur", "CLOTURE", 1.0, true, "Inspection Readiness program", "Programme de preparation aux inspections non formalise", 12, "2025-10-30", "2026-01-10"),
    ecart("2.3.5", 2, sAQ.id, "Majeur", "EN_COURS", 0.75, true, "Documentation QMS update", "Mise a jour de la documentation du systeme de management qualite", 9, "2026-01-31"),
    ecart("2.3.6", 2, sAQ.id, "Majeur", "CLOTURE", 1.0, false, "Formation GMP personnels", "Plan de formation GMP pour l ensemble du personnel", 5, "2025-12-15", "2025-12-12"),

    // Macro 2.4 (5 ecarts) - Disinfection
    ecart("2.4.1", 3, sProd.id, "Majeur", "CLOTURE", 1.0, false, "Protocole desinfection surfaces", "Le protocole de desinfection des surfaces n est pas valide", 8, "2025-11-15", "2025-11-10"),
    ecart("2.4.2", 3, sProd.id, "Majeur", "CLOTURE", 1.0, true, "Validation biocides", "Les biocides utilises ne sont pas valides selon les normes", 11, "2025-10-30", "2025-12-05"),
    ecart("2.4.3", 3, sProd.id, "Majeur", "CLOTURE", 1.0, false, "Rotation agents desinfection", "Programme de rotation des agents de desinfection absent", 6, "2025-12-01", "2025-11-28"),
    ecart("2.4.4", 3, sAQ.id, "Majeur", "CLOTURE", 1.0, true, "Controle efficacite desinfection", "Les controles d efficacite de la desinfection sont insuffisants", 9, "2025-10-15", "2025-12-15"),
    ecart("2.4.5", 3, sProd.id, "Majeur", "CLOTURE", 1.0, false, "SOP desinfection mise a jour", "Les SOPs de desinfection necessite une mise a jour", 5, "2025-11-30", "2025-11-25"),

    // Macro 3.1 (4 ecarts) - Seed lot
    ecart("3.1.1", 4, sCQ.id, "Mineur", "CLOTURE", 1.0, false, "Gestion seed lot documentation", "Documentation de gestion du seed lot incomplete", 7, "2025-11-15", "2025-11-10"),
    ecart("3.1.2", 4, sCQ.id, "Mineur", "CLOTURE", 1.0, true, "Tracabilite seed lot", "La tracabilite du seed lot n est pas assuree de bout en bout", 10, "2025-10-31", "2025-12-01"),
    ecart("3.1.3", 4, sProd.id, "Mineur", "CLOTURE", 1.0, false, "Stockage seed lot conditions", "Les conditions de stockage du seed lot ne sont pas documentees", 5, "2025-12-01", "2025-11-28"),
    ecart("3.1.4", 4, sCQ.id, "Mineur", "CLOTURE", 1.0, false, "Controle identite seed lot", "Les controles d identite du seed lot ne sont pas systematiques", 4, "2025-11-30", "2025-11-25"),

    // Macro 3.2 (4 ecarts) - Gloves
    ecart("3.2.1", 5, sProd.id, "Mineur", "CLOTURE", 1.0, false, "Specification gants aseptiques", "Les specifications des gants pour processus aseptiques sont inadequates", 6, "2025-11-15", "2025-11-10"),
    ecart("3.2.2", 5, sProd.id, "Mineur", "CLOTURE", 1.0, true, "Formation habillage aseptique", "La formation a l habillage aseptique est insuffisante", 8, "2025-10-31", "2025-12-05"),
    ecart("3.2.3", 5, sAQ.id, "Mineur", "CLOTURE", 1.0, false, "SOP changement gants", "SOP de changement de gants non conforme", 5, "2025-12-01", "2025-11-28"),
    ecart("3.2.4", 5, sProd.id, "Mineur", "CLOTURE", 1.0, false, "Qualification fournisseur gants", "Le fournisseur de gants n est pas qualifie GMP", 4, "2025-11-30", "2025-11-25"),

    // Macro 3.3 (3 ecarts) - Particle counter
    ecart("3.3.1", 6, sCQVM.id, "Mineur", "CLOTURE", 1.0, true, "Positionnement compteur particules", "Le tube du compteur de particules n est pas positionne correctement", 9, "2025-10-31", "2025-12-10"),
    ecart("3.3.2", 6, sCQVM.id, "Mineur", "CLOTURE", 1.0, false, "Calibration compteurs", "La calibration des compteurs de particules n est pas a jour", 6, "2025-11-30", "2025-11-25"),
    ecart("3.3.3", 6, sProd.id, "Mineur", "CLOTURE", 1.0, false, "Procedure monitoring particules", "La procedure de monitoring des particules est obsolete", 5, "2025-12-01", "2025-11-28"),

    // Macro 3.4 (5 ecarts) - VMP
    ecart("3.4.1", 7, sCQVM.id, "Mineur", "CLOTURE", 1.0, false, "Mise a jour VMP", "Le VMP ne reflete pas l etat actuel des qualifications", 8, "2025-11-15", "2025-11-10"),
    ecart("3.4.2", 7, sCQVM.id, "Mineur", "EN_COURS", 0.65, true, "Planning requalification", "Le planning de requalification des installations est incomplet", 11, "2026-02-15"),
    ecart("3.4.3", 7, sCQVM.id, "Mineur", "CLOTURE", 1.0, true, "Documentation qualification", "La documentation de qualification des equipements est incomplete", 7, "2025-10-31", "2025-12-15"),
    ecart("3.4.4", 7, sProd.id, "Mineur", "CLOTURE", 1.0, false, "Qualification utilites", "Les utilites (eau, air, vapeur) ne sont pas toutes qualifiees", 6, "2025-12-01", "2025-11-28"),
    ecart("3.4.5", 7, sAQ.id, "Mineur", "EN_COURS", 0.50, true, "Revue periodique VMP", "La revue periodique du VMP n est pas realisee", 4, "2026-03-31"),

    // Macro 3.5 (4 ecarts) - CCS
    ecart("3.5.1", 8, sAQ.id, "Mineur", "CLOTURE", 1.0, false, "Strategie CCS", "Le CCS ne couvre pas l ensemble des risques de contamination", 7, "2025-11-15", "2025-11-10"),
    ecart("3.5.2", 8, sAQ.id, "Mineur", "CLOTURE", 1.0, true, "Monitoring environnemental CCS", "Le programme de monitoring environnemental est inadequat", 10, "2025-10-31", "2025-12-08"),
    ecart("3.5.3", 8, sProd.id, "Mineur", "CLOTURE", 1.0, false, "Programme nettoyage CCS", "Le programme de nettoyage n est pas aligne avec le CCS", 5, "2025-12-01", "2025-11-28"),
    ecart("3.5.4", 8, sAQ.id, "Mineur", "CLOTURE", 1.0, false, "Revue annuelle CCS", "La revue annuelle du CCS n est pas documentee", 4, "2025-11-30", "2025-11-25"),

    // Macro 3.6 (4 ecarts) - Quality manual
    ecart("3.6.1", 9, sAQ.id, "Mineur", "CLOTURE", 1.0, false, "Structure organisationnelle QM", "Le manuel de qualite ne reference pas la structure organisationnelle actuelle", 6, "2025-11-15", "2025-11-10"),
    ecart("3.6.2", 9, sAQ.id, "Mineur", "CLOTURE", 1.0, true, "Organigramme fonctionnel", "L organigramme fonctionnel n est pas a jour dans le QM", 8, "2025-10-31", "2025-12-05"),
    ecart("3.6.3", 9, sAQ.id, "Mineur", "CLOTURE", 1.0, false, "Responsabilites documentees", "Les responsabilites cles ne sont pas documentees dans le QM", 5, "2025-12-01", "2025-11-28"),
    ecart("3.6.4", 9, sPharm.id, "Mineur", "CLOTURE", 1.0, false, "Role pharmacien responsable", "Le role du pharmacien responsable n est pas clairement defini", 4, "2025-11-30", "2025-11-25"),

    // Macro 3.7 (3 ecarts) - Sampling
    ecart("3.7.1", 10, sCQ.id, "Mineur", "CLOTURE", 1.0, false, "Classification BSC sampling", "Le BSC utilise pour le sampling est installe dans une salle grade D inappropriee", 7, "2025-11-15", "2025-11-10"),
    ecart("3.7.2", 10, sProd.id, "Mineur", "CLOTURE", 1.0, true, "Deplacement BSC grade B", "Deplacement du BSC vers une salle de grade B", 9, "2025-10-31", "2025-12-12"),
    ecart("3.7.3", 10, sCQVM.id, "Mineur", "CLOTURE", 1.0, false, "Qualification BSC apres deplacement", "Requalification du BSC apres le deplacement", 5, "2025-12-01", "2025-11-28"),
  ];

  const ecarts = [];
  for (const e of ecartsData) {
    ecarts.push(await prisma.ecart.create({ data: e }));
  }
  console.log(`Created ${ecarts.length} ecarts`);

  // ── ACTION LOG AFM (36 actions) ──
  const actionsData = [
    // WS1-Infra (12 actions)
    { chronoLegacy: 1, dateCapture: "2025-09-01", wsId: ws1.id, desc: "Audit etancheite ZAC A/B - Identification des points de fuite", deadline: "2025-10-15", statut: "CLOTURE", imp: true, urg: true, avanc: 1.0, risk: 15, crit: "Very High" },
    { chronoLegacy: 2, dateCapture: "2025-09-01", wsId: ws1.id, desc: "Remplacement joints et scellements ZAC production", deadline: "2025-11-30", statut: "CLOTURE", imp: true, urg: false, avanc: 1.0, risk: 12, crit: "High" },
    { chronoLegacy: 3, dateCapture: "2025-09-05", wsId: ws1.id, desc: "Qualification HVAC - Revalidation systeme CTA", deadline: "2025-12-15", statut: "CLOTURE", imp: true, urg: true, avanc: 1.0, risk: 20, crit: "Very High" },
    { chronoLegacy: 4, dateCapture: "2025-09-10", wsId: ws1.id, desc: "Installation nouveau groupe froid ZAC", deadline: "2026-01-31", statut: "EN_COURS", imp: true, urg: false, avanc: 0.75, risk: 10, crit: "High" },
    { chronoLegacy: 5, dateCapture: "2025-09-10", wsId: ws1.id, desc: "Remplacement filtres HEPA Grade A/B", deadline: "2025-11-15", statut: "CLOTURE", imp: true, urg: true, avanc: 1.0, risk: 16, crit: "Very High" },
    { chronoLegacy: 6, dateCapture: "2025-09-15", wsId: ws1.id, desc: "Travaux mise a niveau vestiaires et SAS", deadline: "2026-02-28", statut: "EN_COURS", imp: false, urg: false, avanc: 0.45, risk: 6, crit: "Medium" },
    { chronoLegacy: 7, dateCapture: "2025-09-15", wsId: ws1.id, desc: "Requalification salles propres post-travaux", deadline: "2026-03-15", statut: "A_LANCER", imp: true, urg: false, avanc: 0.0, risk: 12, crit: "High" },
    { chronoLegacy: 8, dateCapture: "2025-09-20", wsId: ws1.id, desc: "Mise en conformite eclairage ZAC", deadline: "2025-12-31", statut: "CLOTURE", imp: false, urg: false, avanc: 1.0, risk: 3, crit: "Low" },
    { chronoLegacy: 9, dateCapture: "2025-10-01", wsId: ws1.id, desc: "Installation systeme BMS monitoring", deadline: "2026-02-15", statut: "EN_COURS", imp: true, urg: false, avanc: 0.60, risk: 8, crit: "Medium" },
    { chronoLegacy: 10, dateCapture: "2025-10-01", wsId: ws1.id, desc: "Qualification eau purifiee - Loop 2", deadline: "2026-01-15", statut: "EN_RETARD", imp: true, urg: true, avanc: 0.50, risk: 20, crit: "Very High" },
    { chronoLegacy: 11, dateCapture: "2025-10-05", wsId: ws1.id, desc: "Mise a niveau systeme alarme incendie", deadline: "2025-12-15", statut: "CLOTURE", imp: false, urg: true, avanc: 1.0, risk: 4, crit: "Medium" },
    { chronoLegacy: 12, dateCapture: "2025-10-10", wsId: ws1.id, desc: "Renovation sol epoxy zone remplissage", deadline: "2026-03-31", statut: "A_LANCER", imp: false, urg: false, avanc: 0.0, risk: 6, crit: "Medium" },

    // WS3-CQ (2 actions)
    { chronoLegacy: 13, dateCapture: "2025-09-15", wsId: ws3.id, desc: "Validation methode de test sterility - Robustesse", deadline: "2025-12-31", statut: "CLOTURE", imp: true, urg: false, avanc: 1.0, risk: 10, crit: "High" },
    { chronoLegacy: 14, dateCapture: "2025-10-01", wsId: ws3.id, desc: "Programme Environmental Monitoring - Revision complete", deadline: "2026-01-31", statut: "EN_COURS", imp: true, urg: true, avanc: 0.80, risk: 15, crit: "Very High" },

    // WS4-Prod (3 actions)
    { chronoLegacy: 15, dateCapture: "2025-09-20", wsId: ws4.id, desc: "Qualification equipement remplissage Data Matrix", deadline: "2026-01-15", statut: "EN_COURS", imp: true, urg: false, avanc: 0.70, risk: 12, crit: "High" },
    { chronoLegacy: 16, dateCapture: "2025-10-01", wsId: ws4.id, desc: "Ordonnancement production lots pilotes", deadline: "2026-02-28", statut: "EN_COURS", imp: true, urg: true, avanc: 0.55, risk: 16, crit: "Very High" },
    { chronoLegacy: 17, dateCapture: "2025-10-15", wsId: ws4.id, desc: "Plan de reprise production apres travaux HVAC", deadline: "2026-04-15", statut: "A_LANCER", imp: true, urg: false, avanc: 0.0, risk: 20, crit: "Very High" },

    // WS5-Finances (6 actions)
    { chronoLegacy: 18, dateCapture: "2025-09-01", wsId: ws5f.id, desc: "Budget programme AFM - Validation DFC", deadline: "2025-10-31", statut: "CLOTURE", imp: true, urg: true, avanc: 1.0, risk: 9, crit: "Medium" },
    { chronoLegacy: 19, dateCapture: "2025-09-15", wsId: ws5f.id, desc: "Appel d offres equipements remplissage", deadline: "2025-12-15", statut: "CLOTURE", imp: true, urg: false, avanc: 1.0, risk: 8, crit: "Medium" },
    { chronoLegacy: 20, dateCapture: "2025-10-01", wsId: ws5f.id, desc: "Ordonnancement paiements fournisseurs internationaux", deadline: "2026-03-31", statut: "EN_COURS", imp: false, urg: false, avanc: 0.40, risk: 6, crit: "Medium" },
    { chronoLegacy: 21, dateCapture: "2025-10-15", wsId: ws5f.id, desc: "Negociation contrat HVAC Conseil", deadline: "2025-11-30", statut: "CLOTURE", imp: false, urg: true, avanc: 1.0, risk: 4, crit: "Medium" },
    { chronoLegacy: 22, dateCapture: "2025-11-01", wsId: ws5f.id, desc: "Suivi DAL commandes GARAP prioritaires", deadline: "2026-02-28", statut: "EN_COURS", imp: true, urg: false, avanc: 0.65, risk: 8, crit: "Medium" },
    { chronoLegacy: 23, dateCapture: "2025-11-15", wsId: ws5f.id, desc: "Rapport financier trimestriel programme AFM", deadline: "2026-01-15", statut: "EN_RETARD", imp: false, urg: true, avanc: 0.30, risk: 4, crit: "Medium" },

    // WS5-HR (1 action)
    { chronoLegacy: 24, dateCapture: "2025-10-01", wsId: ws5h.id, desc: "Fiches de poste et recrutements consultants techniques", deadline: "2025-12-31", statut: "CLOTURE", imp: false, urg: false, avanc: 1.0, risk: 3, crit: "Low" },

    // WS7-Regulatory (2 actions)
    { chronoLegacy: 25, dateCapture: "2025-09-01", wsId: ws7.id, desc: "Preparation dossier renouvellement certificat GMP", deadline: "2026-03-31", statut: "EN_COURS", imp: true, urg: true, avanc: 0.70, risk: 25, crit: "Very High" },
    { chronoLegacy: 26, dateCapture: "2025-10-01", wsId: ws7.id, desc: "Mise a jour licence exploitation - ANRP", deadline: "2026-02-28", statut: "EN_COURS", imp: true, urg: false, avanc: 0.55, risk: 15, crit: "Very High" },

    // WS TTT (7 actions)
    { chronoLegacy: 27, dateCapture: "2025-09-15", wsId: wsTTT.id, desc: "Protocole transfert technologique - Design charges", deadline: "2025-12-31", statut: "CLOTURE", imp: true, urg: false, avanc: 1.0, risk: 12, crit: "High" },
    { chronoLegacy: 28, dateCapture: "2025-09-20", wsId: wsTTT.id, desc: "Qualification equipements transfert", deadline: "2026-02-28", statut: "EN_COURS", imp: true, urg: false, avanc: 0.60, risk: 10, crit: "High" },
    { chronoLegacy: 29, dateCapture: "2025-10-01", wsId: wsTTT.id, desc: "Formation equipes sur nouveau procede AFM", deadline: "2026-01-31", statut: "EN_COURS", imp: true, urg: true, avanc: 0.40, risk: 16, crit: "Very High" },
    { chronoLegacy: 30, dateCapture: "2025-10-15", wsId: wsTTT.id, desc: "Validation parametres critiques procede", deadline: "2026-03-15", statut: "A_LANCER", imp: true, urg: false, avanc: 0.0, risk: 20, crit: "Very High" },
    { chronoLegacy: 31, dateCapture: "2025-10-15", wsId: wsTTT.id, desc: "Elaboration batch records AFM", deadline: "2026-02-15", statut: "EN_COURS", imp: false, urg: false, avanc: 0.35, risk: 8, crit: "Medium" },
    { chronoLegacy: 32, dateCapture: "2025-11-01", wsId: wsTTT.id, desc: "Test de stabilite lots pilotes", deadline: "2026-06-30", statut: "A_LANCER", imp: true, urg: false, avanc: 0.0, risk: 15, crit: "Very High" },
    { chronoLegacy: 33, dateCapture: "2025-11-15", wsId: wsTTT.id, desc: "Documentation CTD Module 3 - Qualite", deadline: "2026-04-30", statut: "A_LANCER", imp: true, urg: false, avanc: 0.0, risk: 12, crit: "High" },

    // PMO (3 actions - adjusted to get 36 total)
    { chronoLegacy: 34, dateCapture: "2025-09-01", wsId: wsPMO.id, desc: "Coordination transverse IMS - Reunion hebdomadaire", deadline: "2026-12-31", statut: "EN_COURS", imp: true, urg: false, avanc: 0.50, risk: 6, crit: "Medium" },
    { chronoLegacy: 35, dateCapture: "2025-10-01", wsId: wsPMO.id, desc: "Planning consolide programme AFM - Gantt global", deadline: "2025-11-30", statut: "CLOTURE", imp: true, urg: true, avanc: 1.0, risk: 9, crit: "Medium" },
    { chronoLegacy: 36, dateCapture: "2025-11-01", wsId: wsPMO.id, desc: "Preparation revue de direction trimestrielle", deadline: "2026-01-15", statut: "CLOTURE", imp: false, urg: false, avanc: 1.0, risk: 3, crit: "Low" },
  ];

  const actions = [];
  for (const a of actionsData) {
    actions.push(await prisma.actionAFM.create({
      data: {
        chronoLegacy: a.chronoLegacy,
        dateCapture: a.dateCapture,
        workstreamId: a.wsId,
        description: a.desc,
        deadlineInitiale: a.deadline,
        statut: a.statut,
        estImportant: a.imp,
        estUrgent: a.urg,
        avancement: a.avanc,
        scoreRisque: a.risk,
        niveauCriticite: a.crit,
      },
    }));
  }
  console.log(`Created ${actions.length} actions AFM`);

  // Action-Responsable assignments
  const userMap: Record<string, number> = {};
  users.forEach(u => { userMap[u.name] = u.id; });

  const assignments = [
    [1, "Babacar"], [1, "Fode D."], [2, "L. Mendy"], [3, "HVAC Conseil" as string],
    [4, "Babacar"], [5, "L. Mendy"], [6, "Fode D."], [7, "Babacar"],
    [8, "Omar G."], [9, "Babacar"], [10, "Serigne"], [11, "L. Mendy"],
    [12, "Fode D."], [13, "Lamine T."], [14, "Lamine T."], [15, "Babacar"],
    [16, "Babacar"], [16, "Fode D."], [17, "Babacar"], [18, "Lamine S."],
    [19, "Lamine S."], [19, "Cheikhou D."], [20, "Lamine S."], [21, "Patrick"],
    [22, "Lamine S."], [23, "Cheikhou D."], [24, "Moussa S."],
    [25, "Awa L."], [26, "Awa L."], [27, "Serigne"], [28, "Serigne"],
    [28, "AKC"], [29, "Serigne"], [30, "Serigne"], [31, "AKC"],
    [32, "Serigne"], [33, "Awa L."], [34, "Patrick"], [35, "Patrick"],
    [36, "Patrick"],
  ];

  for (const [actIdx, userName] of assignments) {
    const uid = userMap[userName as string];
    if (uid && actions[Number(actIdx) - 1]) {
      await prisma.actionResponsable.create({
        data: { actionId: actions[Number(actIdx) - 1].id, userId: uid },
      }).catch(() => {});
    }
  }

  // ── SUIVI GARAP (130 dossiers) ──
  const garapStatuts = ["CLOTURE", "ATTENTE_FOURNISSEUR", "ATTENTE_PAIEMENT", "CHEZ_TRANSITAIRE", "EN_COURS_DOUANE", "LIVRE"];
  const naturesProd = [
    "Reactifs de controle qualite", "Milieux de culture", "Consommables laboratoire",
    "Pieces detachees HVAC", "Equipement de filtration", "Produits chimiques",
    "Colonnes chromatographiques", "Kits de test sterility", "Flacons et bouchons",
    "Gants steriles Grade A", "Desinfectants valides", "Filtres HEPA",
    "Capteurs temperature", "Sondes de pression", "Calibrateurs",
    "EPI salle propre", "Oeufs embryonnes SPF", "Seringues pre-remplies",
    "Etiquettes Data Matrix", "Boites de Petri", "Papier enregistreur",
  ];

  const entiteDistribution = [
    { ent: eLCQ, count: 26 }, { ent: ePROD, count: 35 },
    { ent: eCQVM, count: 25 }, { ent: eSMS, count: 22 }, { ent: ePLCQ, count: 22 },
  ];

  let garapCount = 0;
  for (const { ent, count } of entiteDistribution) {
    for (let i = 0; i < count; i++) {
      const fIdx = (garapCount + i) % fournisseurs.length;
      const dIdx = garapCount % 3 < 2 ? 0 : (garapCount % 5 === 0 ? 2 : garapCount % 7 === 0 ? 3 : 1);
      const sIdx = garapCount < 45 ? 0 : garapCount < 65 ? 5 : garapCount < 85 ? 1 : garapCount < 100 ? 2 : garapCount < 115 ? 3 : 4;
      const montant = Math.round((500 + Math.random() * 49500) * 100) / 100;
      const daNum = garapCount < 80 ? `25DA-${String(2200 + garapCount).padStart(5, "0")}` : `25BC-${String(1100 + garapCount - 80).padStart(5, "0")}`;

      await prisma.suiviGarap.create({
        data: {
          entiteId: ent.id,
          expressionBesoin: `Besoin ${naturesProd[garapCount % naturesProd.length]} pour ${ent.libelle}`,
          natureProduits: naturesProd[garapCount % naturesProd.length],
          fournisseurId: fournisseurs[fIdx].id,
          numDaBc: daNum,
          montant,
          deviseId: devises[dIdx].id,
          statutWorkflow: garapStatuts[sIdx],
          dateDerniereRelance: sIdx >= 1 && sIdx <= 3 ? "2026-02-15" : null,
          dateLivraisonPrevue: "2026-04-30",
          dateLivraisonEffective: sIdx === 0 || sIdx === 5 ? "2026-01-20" : null,
          commentaireDal: sIdx === 0 ? "Dossier cloture - livraison conforme" : null,
        },
      });
      garapCount++;
    }
  }
  console.log(`Created ${garapCount} dossiers GARAP`);

  // ── SNAPSHOTS (159 = 53 ecarts * 3 snapshots) ──
  const snapLabels = [
    { label: "Snapshot_Nov2025", date: "2025-11-01" },
    { label: "Snapshot_Dec2025", date: "2025-12-01" },
    { label: "Snapshot_Jan2026", date: "2026-01-01" },
  ];

  let snapCount = 0;
  for (const e of ecarts) {
    let prevPct = 0;
    for (let si = 0; si < snapLabels.length; si++) {
      const snap = snapLabels[si];
      // Simulate progression over time
      let pct: number;
      if (e.statut === "CLOTURE") {
        pct = si === 0 ? 0.4 + Math.random() * 0.3 : si === 1 ? 0.7 + Math.random() * 0.2 : 1.0;
      } else {
        pct = si === 0 ? 0.1 + Math.random() * 0.3 : si === 1 ? 0.3 + Math.random() * 0.3 : e.pctAvancement;
      }
      pct = Math.round(pct * 100) / 100;

      await prisma.snapshot.create({
        data: {
          ecartId: e.id,
          snapshotDate: snap.date,
          snapshotLabel: snap.label,
          statut: pct >= 1 ? "CLOTURE" : pct > 0.5 ? "REVU" : "EN_COURS",
          pctAvancement: pct,
          margeProgression: si > 0 ? Math.round((pct - prevPct) * 100) / 100 : null,
          version: e.version - (2 - si) > 0 ? e.version - (2 - si) : 1,
          estCloture: pct >= 1,
        },
      });
      prevPct = pct;
      snapCount++;
    }
  }
  console.log(`Created ${snapCount} snapshots`);

  // ── SYNTHESES GARAP (sample of ~50 entries) ──
  const synthDates = ["2025-11-15", "2025-11-22", "2025-11-29", "2025-12-06", "2025-12-13", "2025-12-20", "2026-01-10", "2026-01-17", "2026-01-24", "2026-01-31"];
  let synthCount = 0;
  for (const date of synthDates) {
    for (const ent of entites) {
      await prisma.syntheseGarap.create({
        data: {
          dateSynthese: date,
          entiteId: ent.id,
          typeLigne: "RESUME",
          sujetDescription: `Synthese GARAP ${ent.libelle} - ${6 + synthCount} dossiers clotures / ${3 + Math.floor(synthCount / 5)} la semaine passee`,
          categorieStatut: `${6 + synthCount} clotures`,
        },
      });
      synthCount++;
    }
  }
  console.log(`Created ${synthCount} syntheses GARAP`);

  // ── AUDIT TRAIL (sample entries) ──
  const auditEntries = [
    { table: "Ecart", recordId: 1, action: "UPDATE", champ: "statut", avant: "EN_COURS", apres: "CLOTURE", userId: users[1].id },
    { table: "Ecart", recordId: 5, action: "UPDATE", champ: "pctAvancement", avant: "0.80", apres: "1.00", userId: users[2].id },
    { table: "ActionAFM", recordId: 3, action: "UPDATE", champ: "statut", avant: "EN_COURS", apres: "CLOTURE", userId: users[1].id },
    { table: "SuiviGarap", recordId: 10, action: "UPDATE", champ: "statutWorkflow", avant: "ATTENTE_FOURNISSEUR", apres: "CHEZ_TRANSITAIRE", userId: users[14].id },
    { table: "Ecart", recordId: 15, action: "UPDATE", champ: "version", avant: "9", apres: "10", userId: users[3].id },
  ];

  for (const ae of auditEntries) {
    await prisma.auditTrail.create({
      data: {
        tableSource: ae.table,
        recordId: ae.recordId,
        actionType: ae.action,
        champModifie: ae.champ,
        valeurAvant: ae.avant,
        valeurApres: ae.apres,
        userId: ae.userId,
        ipAddress: "192.168.1.100",
      },
    });
  }

  console.log("Seed completed successfully!");
}

main()
  .then(async () => { await prisma.$disconnect(); })
  .catch(async (e) => { console.error(e); await prisma.$disconnect(); process.exit(1); });
