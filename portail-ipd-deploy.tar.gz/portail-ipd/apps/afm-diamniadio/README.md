# AFM Diamniadio — Dashboard de pilotage production vaccinale

Plateforme web de pilotage opérationnel et stratégique de l'unité de production AFM au Vaccinopole de Diamniadio, Sénégal. Couvre les 5 modules du cahier des charges : **Pilotage Financier, Excellence Industrielle, Conformité Réglementaire, Gestion des Risques, Performance Production**.

Objectif stratégique : lancement GMP de routine en 2027 (3 M doses, 20 M$).

## Stack

- **Next.js 16** App Router + **TypeScript 5** strict
- **Tailwind CSS v4** + composants UI maison (pattern shadcn/Radix light)
- **Prisma 6** avec SQLite (dev) / PostgreSQL (prod)
- **JWT jose** + `bcryptjs` (cookies httpOnly)
- **Recharts** pour les graphiques, **Leaflet** pour la cartographie équipements
- **Zustand** pour l'état client léger

## Démarrage

Prérequis : une base **PostgreSQL** (locale ou hostée). Pour le dev, le plus rapide est [Neon](https://neon.tech) (free tier 3 Go).

```bash
cp .env.example .env
# Éditer .env : remplacer DATABASE_URL par l'URL Neon/Postgres
pnpm install
pnpm exec prisma db push   # crée les tables
pnpm db:seed               # données cahier des charges
pnpm dev
```

Ouvrir [http://localhost:3000](http://localhost:3000) puis se connecter :
- **Email** : `pasteur@afm-diamniadio.sn`
- **Mot de passe** : `passer`

Autres comptes utiles (même mot de passe `passer`) :
- `admin@afm-diamniadio.sn` (DG)
- `fin@afm-diamniadio.sn` (Direction Financière)
- `indus@afm-diamniadio.sn` (Direction Industrielle)
- `qa@afm-diamniadio.sn` (Assurance Qualité)
- `prod@afm-diamniadio.sn` (Production)

⚠️ Changer tous les mots de passe avant mise en production réelle.

## Déploiement Vercel

1. **Provisionner une base Postgres** — créer un projet sur [neon.tech](https://neon.tech) (gratuit) et copier la connection string.
2. **Ajouter les variables d'environnement Vercel** :
   ```bash
   vercel env add DATABASE_URL production
   # coller l'URL Neon
   vercel env add AUTH_SECRET production
   # coller le secret généré avec : openssl rand -hex 32
   ```
3. **Déployer** : chaque push sur `main` déclenche un build. Le build exécute `prisma db push` qui crée les tables automatiquement.
4. **Seed initial** (une seule fois) : depuis votre machine avec le DATABASE_URL Neon dans `.env`, exécuter `pnpm db:seed`.

## Modules

| Module | Chemin | KPI principaux |
|---|---|---|
| Pilotage Financier | `/app/financier` | Cash-flow, levées 30 M€, CAPEX/OPEX |
| Excellence Industrielle | `/app/industriel` | Qualifications IQ/OQ/PQ, SOP, équipements |
| Conformité Réglementaire | `/app/conformite` | Jalons OMS/ARP, déviations, audits |
| Gestion des Risques | `/app/risques` | Contamination, énergie Senelec, supply |
| Performance Production | `/app/production` | Volumes, OEE, rendements |

## Structure

```
app/
  app/                    # pages authentifiées
    dashboard/            # vue d'ensemble 5 modules
    {financier,industriel,conformite,risques,production}/
    admin/                # RBAC, utilisateurs
  api/                    # route handlers REST
  login/                  # page de connexion
components/
  ui/                     # primitives UI
  layout/                 # Sidebar, Topbar
  charts/                 # KPICard, CashflowChart, etc.
  modules/                # composants dédiés par module
lib/
  prisma.ts / auth.ts / dal.ts / rbac.ts / utils.ts
prisma/
  schema.prisma / seed.ts
```

## Rôles & RBAC

6 rôles : `DG`, `DIR_FIN`, `DIR_INDUS`, `QA`, `PROD`, `LECTEUR`. Matrice de permissions dans `lib/rbac.ts`.

## Évolutions post-livraison

Le cahier des charges prévoit trois phases ; cette itération couvre les 5 modules en profondeur Phase 1-2. Évolutions à venir :

### Intégrations (§4.2)
- SCADA (acquisition temps réel équipements)
- LIMS (laboratoire, contrôles qualité)
- MES (ordres de fabrication)
- ENNOV (gestion documentaire SOP, validations)
- ERP SAP (finances, stocks, achats, RH)
- Capteurs IoT (température, humidité, pression)

### Fonctionnalités avancées (§5)
- IA : prédiction défaillances, détection anomalies, optimisation planning
- Mobilité : PWA installable, QR codes équipements, app iOS/Android
- Collaboration : workflows approbation, signatures électroniques 21 CFR Part 11, rapports PDF automatisés

### Infrastructure prod
- Basculer SQLite → PostgreSQL (cf `.env.example`)
- Ajouter InfluxDB pour séries temporelles (monitoring environnemental)
- Docker multi-stage Alpine + Kubernetes
- Prometheus + Grafana + ELK Stack
- SSO, 2FA, TLS 1.3, chiffrement DB

### Sécurité & conformité (§6)
- GMP (Good Manufacturing Practice) — validation CSV
- 21 CFR Part 11 — signatures électroniques, intégrité données
- RGPD — protection données personnelles

## Cahier des charges

Source : `/Users/amadou/Downloads/Cahier_des_charges_Dashboard_AFM_Diamniadio_1.docx` (20 avril 2026).
