import { NextResponse } from "next/server";
import { getSession } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

/**
 * POST /api/update-status
 * body: { entityType, id, patch: { statut?, progression?, ... } }
 *
 * Whitelist stricte des entités et champs modifiables.
 */

type UpdateHandler = (id: string, patch: Record<string, unknown>) => Promise<unknown>;

const HANDLERS: Record<string, { fields: string[]; handler: UpdateHandler }> = {
  deviation: {
    fields: ["statut", "actionCorrective", "responsable", "dateResolution"],
    handler: async (id, p) =>
      prisma.deviation.update({
        where: { id },
        data: {
          ...(p.statut !== undefined && { statut: String(p.statut) }),
          ...(p.actionCorrective !== undefined && { actionCorrective: p.actionCorrective as string | null }),
          ...(p.responsable !== undefined && { responsable: p.responsable as string | null }),
          ...(p.dateResolution !== undefined && {
            dateResolution: p.dateResolution ? new Date(p.dateResolution as string) : null,
          }),
        },
      }),
  },
  milestone: {
    fields: ["statut", "progression", "dateRealisee", "notes"],
    handler: async (id, p) =>
      prisma.regulatoryMilestone.update({
        where: { id },
        data: {
          ...(p.statut !== undefined && { statut: String(p.statut) }),
          ...(p.progression !== undefined && { progression: Number(p.progression) }),
          ...(p.dateRealisee !== undefined && {
            dateRealisee: p.dateRealisee ? new Date(p.dateRealisee as string) : null,
          }),
          ...(p.notes !== undefined && { notes: p.notes as string | null }),
        },
      }),
  },
  risk: {
    fields: ["statut", "mitigation", "responsable", "probabilite", "impact"],
    handler: async (id, p) => {
      const data: Record<string, unknown> = {};
      if (p.statut !== undefined) data.statut = String(p.statut);
      if (p.mitigation !== undefined) data.mitigation = p.mitigation as string | null;
      if (p.responsable !== undefined) data.responsable = p.responsable as string | null;
      if (p.probabilite !== undefined) data.probabilite = Number(p.probabilite);
      if (p.impact !== undefined) data.impact = Number(p.impact);
      if (p.probabilite !== undefined || p.impact !== undefined) {
        // recompute score
        const existing = await prisma.risk.findUnique({ where: { id } });
        if (existing) {
          const prob = p.probabilite !== undefined ? Number(p.probabilite) : existing.probabilite;
          const imp = p.impact !== undefined ? Number(p.impact) : existing.impact;
          data.score = prob * imp;
        }
      }
      return prisma.risk.update({ where: { id }, data });
    },
  },
  equipment: {
    fields: ["statut", "notes"],
    handler: async (id, p) =>
      prisma.equipment.update({
        where: { id },
        data: {
          ...(p.statut !== undefined && { statut: String(p.statut) }),
          ...(p.notes !== undefined && { notes: p.notes as string | null }),
        },
      }),
  },
  funding_round: {
    fields: ["statut", "montantLeveEur", "dateRealisee", "notes"],
    handler: async (id, p) =>
      prisma.fundingRound.update({
        where: { id },
        data: {
          ...(p.statut !== undefined && { statut: String(p.statut) }),
          ...(p.montantLeveEur !== undefined && { montantLeveEur: Number(p.montantLeveEur) }),
          ...(p.dateRealisee !== undefined && {
            dateRealisee: p.dateRealisee ? new Date(p.dateRealisee as string) : null,
          }),
          ...(p.notes !== undefined && { notes: p.notes as string | null }),
        },
      }),
  },
  qualification: {
    fields: ["statut", "dateRealisee", "operateur", "rapport"],
    handler: async (id, p) =>
      prisma.qualification.update({
        where: { id },
        data: {
          ...(p.statut !== undefined && { statut: String(p.statut) }),
          ...(p.operateur !== undefined && { operateur: p.operateur as string | null }),
          ...(p.rapport !== undefined && { rapport: p.rapport as string | null }),
          ...(p.dateRealisee !== undefined && {
            dateRealisee: p.dateRealisee ? new Date(p.dateRealisee as string) : null,
          }),
        },
      }),
  },
  sop: {
    fields: ["statut", "version", "approbateur"],
    handler: async (id, p) =>
      prisma.sOP.update({
        where: { id },
        data: {
          ...(p.statut !== undefined && { statut: String(p.statut) }),
          ...(p.version !== undefined && { version: String(p.version) }),
          ...(p.approbateur !== undefined && { approbateur: p.approbateur as string | null }),
        },
      }),
  },
  production_batch: {
    fields: ["statut", "rendement", "notes"],
    handler: async (id, p) =>
      prisma.productionBatch.update({
        where: { id },
        data: {
          ...(p.statut !== undefined && { statut: String(p.statut) }),
          ...(p.rendement !== undefined && { rendement: Number(p.rendement) }),
          ...(p.notes !== undefined && { notes: p.notes as string | null }),
        },
      }),
  },
  budget_line: {
    fields: ["budgetEur", "consommeEur", "alerteDepassement", "notes"],
    handler: async (id, p) =>
      prisma.budgetLine.update({
        where: { id },
        data: {
          ...(p.budgetEur !== undefined && { budgetEur: Number(p.budgetEur) }),
          ...(p.consommeEur !== undefined && { consommeEur: Number(p.consommeEur) }),
          ...(p.alerteDepassement !== undefined && {
            alerteDepassement: p.alerteDepassement === "true" || p.alerteDepassement === true,
          }),
          ...(p.notes !== undefined && { notes: p.notes as string | null }),
        },
      }),
  },
  audit: {
    fields: ["statut", "dateRealisee", "rapport", "auditeur"],
    handler: async (id, p) =>
      prisma.audit.update({
        where: { id },
        data: {
          ...(p.statut !== undefined && { statut: String(p.statut) }),
          ...(p.dateRealisee !== undefined && {
            dateRealisee: p.dateRealisee ? new Date(p.dateRealisee as string) : null,
          }),
          ...(p.rapport !== undefined && { rapport: p.rapport as string | null }),
          ...(p.auditeur !== undefined && { auditeur: p.auditeur as string | null }),
        },
      }),
  },
  power_incident: {
    fields: ["impact", "dureeMin", "notes"],
    handler: async (id, p) =>
      prisma.powerIncident.update({
        where: { id },
        data: {
          ...(p.impact !== undefined && { impact: String(p.impact) }),
          ...(p.dureeMin !== undefined && { dureeMin: Number(p.dureeMin) }),
          ...(p.notes !== undefined && { notes: p.notes as string | null }),
        },
      }),
  },
  stock_level: {
    fields: ["quantite", "seuilAlerte", "dateExpiration"],
    handler: async (id, p) =>
      prisma.stockLevel.update({
        where: { id },
        data: {
          ...(p.quantite !== undefined && { quantite: Number(p.quantite) }),
          ...(p.seuilAlerte !== undefined && { seuilAlerte: Number(p.seuilAlerte) }),
          ...(p.dateExpiration !== undefined && {
            dateExpiration: p.dateExpiration ? new Date(p.dateExpiration as string) : null,
          }),
        },
      }),
  },
  production_target: {
    fields: ["cibleDoses", "realisDoses", "revenusEurRealise", "commentaire"],
    handler: async (id, p) =>
      prisma.productionTarget.update({
        where: { id },
        data: {
          ...(p.cibleDoses !== undefined && { cibleDoses: Number(p.cibleDoses) }),
          ...(p.realisDoses !== undefined && { realisDoses: Number(p.realisDoses) }),
          ...(p.revenusEurRealise !== undefined && {
            revenusEurRealise: Number(p.revenusEurRealise),
          }),
          ...(p.commentaire !== undefined && { commentaire: p.commentaire as string | null }),
        },
      }),
  },
  ogsm_action: {
    fields: ["statut", "progression", "priorite", "dateFin", "responsableId", "description"],
    handler: async (id, p) =>
      prisma.ogsmAction.update({
        where: { id },
        data: {
          ...(p.statut !== undefined && { statut: String(p.statut) }),
          ...(p.progression !== undefined && { progression: Number(p.progression) }),
          ...(p.priorite !== undefined && { priorite: String(p.priorite) }),
          ...(p.dateFin !== undefined && {
            dateFin: p.dateFin ? new Date(p.dateFin as string) : null,
          }),
          ...(p.responsableId !== undefined && {
            responsableId: p.responsableId ? String(p.responsableId) : null,
          }),
          ...(p.description !== undefined && { description: p.description as string | null }),
        },
      }),
  },
  ogsm_mesure: {
    fields: ["valeurActuelle", "cibleValeur"],
    handler: async (id, p) =>
      prisma.ogsmMesure.update({
        where: { id },
        data: {
          ...(p.valeurActuelle !== undefined && { valeurActuelle: Number(p.valeurActuelle) }),
          ...(p.cibleValeur !== undefined && { cibleValeur: Number(p.cibleValeur) }),
        },
      }),
  },
  ogsm_goal: {
    fields: ["statut", "realiseValeur"],
    handler: async (id, p) =>
      prisma.ogsmGoal.update({
        where: { id },
        data: {
          ...(p.statut !== undefined && { statut: String(p.statut) }),
          ...(p.realiseValeur !== undefined && { realiseValeur: Number(p.realiseValeur) }),
        },
      }),
  },
};

export async function POST(req: Request) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "UNAUTHENTICATED" }, { status: 401 });

  const body = (await req.json()) as {
    entityType?: string;
    id?: string;
    patch?: Record<string, unknown>;
  };
  const { entityType, id, patch } = body;

  if (!entityType || !id || !patch) {
    return NextResponse.json({ error: "Champs manquants" }, { status: 400 });
  }

  const handler = HANDLERS[entityType];
  if (!handler) {
    return NextResponse.json({ error: `entityType inconnu : ${entityType}` }, { status: 400 });
  }

  // Filtrer patch sur whitelist
  const filtered: Record<string, unknown> = {};
  for (const f of handler.fields) {
    if (f in patch) filtered[f] = patch[f];
  }

  try {
    const result = await handler.handler(id, filtered);
    await prisma.auditLog.create({
      data: {
        userId: session.sub,
        action: "UPDATE_STATUS",
        entity: entityType,
        entityId: id,
        details: JSON.stringify(filtered),
      },
    });
    return NextResponse.json({ ok: true, result });
  } catch (e) {
    return NextResponse.json(
      { error: "Erreur mise à jour", details: (e as Error).message },
      { status: 500 }
    );
  }
}
