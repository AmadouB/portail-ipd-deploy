import { NextResponse } from "next/server";
import { getSession } from "@/lib/auth";
import { getQualifications } from "@/lib/dal";

export async function GET() {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "UNAUTHENTICATED" }, { status: 401 });
  return NextResponse.json({ qualifications: await getQualifications() });
}
