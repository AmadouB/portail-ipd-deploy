import { NextResponse } from "next/server";
import { getSession } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

/**
 * GET /api/comments?entityType=deviation&entityId=xxx
 * POST /api/comments — body: { entityType, entityId, contenu, periode? }
 */

export async function GET(req: Request) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "UNAUTHENTICATED" }, { status: 401 });

  const url = new URL(req.url);
  const entityType = url.searchParams.get("entityType");
  const entityId = url.searchParams.get("entityId");
  if (!entityType || !entityId) {
    return NextResponse.json({ error: "entityType et entityId requis" }, { status: 400 });
  }

  const comments = await prisma.comment.findMany({
    where: { entityType, entityId },
    orderBy: { createdAt: "desc" },
  });

  return NextResponse.json({ comments });
}

export async function POST(req: Request) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "UNAUTHENTICATED" }, { status: 401 });

  const body = (await req.json()) as {
    entityType?: string;
    entityId?: string;
    contenu?: string;
    periode?: string | null;
  };
  const { entityType, entityId, contenu, periode } = body;

  if (!entityType || !entityId || !contenu || contenu.trim().length === 0) {
    return NextResponse.json({ error: "Champs manquants" }, { status: 400 });
  }

  const comment = await prisma.comment.create({
    data: {
      entityType,
      entityId,
      contenu: contenu.trim(),
      periode: periode ?? null,
      auteurId: session.sub,
      auteurNom: `${session.prenom} ${session.nom}`,
    },
  });

  return NextResponse.json({ comment });
}
