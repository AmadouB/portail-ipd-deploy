import { NextResponse } from "next/server";
import { getSession } from "@/lib/auth";
import { getOEEMetrics } from "@/lib/dal";

export async function GET(req: Request) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "UNAUTHENTICATED" }, { status: 401 });
  const url = new URL(req.url);
  const equipmentId = url.searchParams.get("equipmentId") ?? undefined;
  return NextResponse.json({ metrics: await getOEEMetrics(equipmentId) });
}
