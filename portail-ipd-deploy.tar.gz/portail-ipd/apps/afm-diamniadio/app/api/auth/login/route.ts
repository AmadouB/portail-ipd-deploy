import { NextResponse } from "next/server";
import { authenticateUser, signSession, setSessionCookie } from "@/lib/auth";

export async function POST(req: Request) {
  const { email, password } = (await req.json()) as { email?: string; password?: string };
  if (!email || !password) {
    return NextResponse.json({ error: "Email et mot de passe requis" }, { status: 400 });
  }
  const user = await authenticateUser(email, password);
  if (!user) {
    return NextResponse.json({ error: "Identifiants invalides" }, { status: 401 });
  }
  const token = await signSession({
    sub: user.id,
    email: user.email,
    role: user.roleCode,
    prenom: user.prenom,
    nom: user.nom,
  });
  await setSessionCookie(token);
  return NextResponse.json({ ok: true });
}
