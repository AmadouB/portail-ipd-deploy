import { NextResponse } from "next/server";
import { clearSessionCookie } from "@/lib/auth";

const BASE_PATH = process.env.NEXT_PUBLIC_BASE_PATH ?? process.env.BASE_PATH ?? "";

export async function GET(req: Request) {
  await clearSessionCookie();
  const origin = new URL(req.url).origin;
  return NextResponse.redirect(new URL(`${BASE_PATH}/login`, origin));
}

export async function POST() {
  await clearSessionCookie();
  return NextResponse.json({ ok: true });
}
