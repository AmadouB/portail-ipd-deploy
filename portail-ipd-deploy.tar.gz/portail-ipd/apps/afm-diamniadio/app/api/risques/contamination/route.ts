import { NextResponse } from "next/server";
import { getSession } from "@/lib/auth";
import { getEnvironmentalReadings } from "@/lib/dal";

export async function GET(req: Request) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "UNAUTHENTICATED" }, { status: 401 });
  const url = new URL(req.url);
  const zone = url.searchParams.get("zone") ?? undefined;
  return NextResponse.json({ readings: await getEnvironmentalReadings(zone) });
}
