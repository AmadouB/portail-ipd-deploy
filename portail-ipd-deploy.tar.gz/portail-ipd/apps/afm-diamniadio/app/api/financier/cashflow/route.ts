import { NextResponse } from "next/server";
import { getSession } from "@/lib/auth";
import { getCashflow } from "@/lib/dal";

export async function GET() {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "UNAUTHENTICATED" }, { status: 401 });
  const data = await getCashflow(12);
  return NextResponse.json({ cashflow: data });
}
