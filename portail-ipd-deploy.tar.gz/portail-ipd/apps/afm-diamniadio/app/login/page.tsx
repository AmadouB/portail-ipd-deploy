"use client";

import { useState } from "react";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { apiPath } from "@/lib/api";

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    const res = await fetch(apiPath("/api/auth/login"), {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    });
    setLoading(false);
    if (res.ok) {
      router.push("/app/dashboard");
      router.refresh();
    } else {
      const body = await res.json().catch(() => ({ error: "Erreur" }));
      setError(body.error ?? "Identifiants invalides");
    }
  }

  return (
    <main className="min-h-screen flex items-center justify-center bg-gradient-to-br from-sky-50 via-white to-[#86B4DD]/20 px-4">
      <div className="w-full max-w-md">
        {/* Bloc co-branding IPD + AFM — charte p.15 (logo IPD | ligne bleue | nom projet) */}
        <div className="flex items-center justify-center gap-4 mb-8">
          <Image
            src="/logo-ipd.png"
            alt="Institut Pasteur de Dakar"
            width={220}
            height={90}
            priority
            className="h-14 w-auto object-contain"
          />
          <div className="h-14 w-px bg-[#0089D0]" aria-hidden />
          <div>
            <div
              className="text-lg font-bold text-[#0089D0] leading-tight"
              style={{ fontFamily: "var(--font-poppins)" }}
            >
              AFM
            </div>
            <div className="text-xs text-slate-700">Diamniadio</div>
          </div>
        </div>

        <div className="text-center mb-8">
          <h1 className="text-2xl font-bold text-slate-900" style={{ fontFamily: "var(--font-poppins)" }}>
            Dashboard de pilotage
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Production vaccinale · Vaccinopole de Diamniadio
          </p>
        </div>

        <form
          onSubmit={onSubmit}
          className="bg-white border border-slate-200 rounded-2xl shadow-sm p-8 space-y-5"
        >
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">
              Adresse e-mail
            </label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="pasteur@afm-diamniadio.sn"
              className="w-full px-3.5 py-2.5 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#0089D0]/40 focus:border-[#0089D0]"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">
              Mot de passe
            </label>
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-3.5 py-2.5 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#0089D0]/40 focus:border-[#0089D0]"
            />
          </div>

          {error && (
            <div className="text-sm text-red-700 bg-red-50 border border-red-200 rounded-lg px-3 py-2">
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full py-2.5 rounded-lg bg-[#0089D0] hover:bg-[#052A62] text-white text-sm font-medium transition-colors disabled:opacity-60"
            style={{ fontFamily: "var(--font-poppins)" }}
          >
            {loading ? "Connexion…" : "Se connecter"}
          </button>

          <div className="text-xs text-slate-500 text-center pt-2">
            Compte démo : <span className="font-mono">pasteur@afm-diamniadio.sn</span> /{" "}
            <span className="font-mono">passer</span>
          </div>
        </form>

        <div className="text-center text-xs text-slate-400 mt-6">
          © Institut Pasteur de Dakar 2026 · Fondation d&apos;utilité publique · Conforme GMP / 21 CFR Part 11 / RGPD
        </div>
      </div>
    </main>
  );
}
