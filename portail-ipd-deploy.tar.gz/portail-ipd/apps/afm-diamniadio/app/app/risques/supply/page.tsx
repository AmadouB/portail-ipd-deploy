import { Package, AlertTriangle, Truck } from "lucide-react";
import { getStockLevels, currentPeriode } from "@/lib/dal";
import { prisma } from "@/lib/prisma";
import { Card, CardBody, CardHeader, CardTitle } from "@/components/ui/card";
import { KpiCard } from "@/components/ui/kpi-card";
import { PageHeader } from "@/components/layout/page-header";
import { StocksTable } from "@/components/modules/risques/stocks-table";

export default async function SupplyPage() {
  const stocks = await getStockLevels();
  const alertes = stocks.filter((s) => s.quantite < s.seuilAlerte);
  const biomanguinhos = stocks.filter((s) => s.fournisseur === "BIOMANGUINHOS");
  const biomTotal = biomanguinhos.reduce((s, x) => s + x.quantite, 0);

  const counts = await prisma.comment.groupBy({
    by: ["entityId"],
    where: { entityType: "stock_level" },
    _count: true,
  });
  const countMap = new Map(counts.map((c) => [c.entityId, c._count]));
  const rows = stocks.map((s) => ({ ...s, commentCount: countMap.get(s.id) ?? 0 }));

  return (
    <div className="max-w-7xl mx-auto">
      <PageHeader
        title="Supply — stocks & fournisseurs critiques"
        subtitle="Back-up Drug Substance Biomanguinhos, stocks sécuritaires, consommables. Cliquer sur « Modifier » pour réajuster un stock ou commenter la revue d'inventaire."
      />

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <KpiCard
          label="Références en alerte"
          value={alertes.length}
          suffix={alertes.length > 0 ? "sous seuil" : "OK"}
          hint="Quantité < seuil alerte"
          icon={AlertTriangle}
          tone={alertes.length > 0 ? "danger" : "success"}
        />
        <KpiCard
          label="Stock DS Biomanguinhos"
          value={biomTotal.toLocaleString("fr-FR")}
          suffix="flacons"
          hint={`${biomanguinhos.length} lot(s)`}
          icon={Package}
          tone="primary"
        />
        <KpiCard
          label="Références gérées"
          value={stocks.length}
          hint="Inventaire consommables + DS"
          icon={Package}
          tone="accent"
        />
        <KpiCard
          label="Fournisseurs actifs"
          value={new Set(stocks.map((s) => s.fournisseur)).size}
          hint="Biomanguinhos + autres"
          icon={Truck}
          tone="success"
        />
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Niveaux de stock</CardTitle>
        </CardHeader>
        <CardBody className="p-0">
          <StocksTable stocks={rows} defaultPeriode={currentPeriode()} />
        </CardBody>
      </Card>
    </div>
  );
}
