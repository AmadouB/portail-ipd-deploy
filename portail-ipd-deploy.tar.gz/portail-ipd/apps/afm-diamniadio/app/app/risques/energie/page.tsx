import { Zap, Clock, ShieldAlert, CheckCircle2 } from "lucide-react";
import { getPowerIncidents, currentPeriode } from "@/lib/dal";
import { prisma } from "@/lib/prisma";
import { Card, CardBody, CardHeader, CardTitle } from "@/components/ui/card";
import { KpiCard } from "@/components/ui/kpi-card";
import { PageHeader } from "@/components/layout/page-header";
import { PowerIncidentsTable } from "@/components/modules/risques/power-incidents-table";

export default async function EnergiePage() {
  const incidents = await getPowerIncidents();
  const totalMin = incidents.reduce((s, i) => s + i.dureeMin, 0);
  const majeurs = incidents.filter((i) => i.impact === "MAJEUR" || i.impact === "CRITIQUE").length;

  const totalMinutes30j = 30 * 24 * 60;
  const dispoUps = ((totalMinutes30j - totalMin) / totalMinutes30j) * 100;

  const counts = await prisma.comment.groupBy({
    by: ["entityId"],
    where: { entityType: "power_incident" },
    _count: true,
  });
  const countMap = new Map(counts.map((c) => [c.entityId, c._count]));
  const rows = incidents.map((i) => ({ ...i, commentCount: countMap.get(i.id) ?? 0 }));

  return (
    <div className="max-w-7xl mx-auto">
      <PageHeader
        title="Gestion énergétique — Senelec, UPS, ligne sécurisée"
        subtitle="Stabilité électrique Diamniadio : risque critique §1.2 du cahier des charges. Cliquer sur « Modifier » pour requalifier un incident ou ajouter un retour d'expérience."
      />

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <KpiCard
          label="Incidents 30 j"
          value={incidents.length}
          hint={`${majeurs} majeur(s)/critique(s)`}
          icon={Zap}
          tone={majeurs > 0 ? "warning" : "primary"}
        />
        <KpiCard
          label="Minutes totales"
          value={totalMin}
          suffix="min"
          hint="Durée cumulée des coupures"
          icon={Clock}
          tone="accent"
        />
        <KpiCard
          label="Disponibilité UPS"
          value={dispoUps.toFixed(2)}
          suffix="%"
          hint="Sur la fenêtre 30 jours"
          icon={CheckCircle2}
          tone="success"
        />
        <KpiCard
          label="Ligne sécurisée"
          value="En cours"
          hint="Installation ligne dédiée Senelec"
          icon={ShieldAlert}
          tone="warning"
        />
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Journal des incidents électriques</CardTitle>
        </CardHeader>
        <CardBody className="p-0">
          <PowerIncidentsTable incidents={rows} defaultPeriode={currentPeriode()} />
        </CardBody>
      </Card>
    </div>
  );
}
