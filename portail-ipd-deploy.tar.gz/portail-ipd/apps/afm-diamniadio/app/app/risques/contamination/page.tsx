import { getEnvironmentalReadings } from "@/lib/dal";
import { Card, CardBody, CardHeader, CardTitle } from "@/components/ui/card";
import { KpiCard } from "@/components/ui/kpi-card";
import { PageHeader } from "@/components/layout/page-header";
import { EnvChart } from "@/components/charts/env-chart";
import { Shield, Droplets, Wind, Thermometer } from "lucide-react";

const META: Record<
  string,
  { label: string; icon: typeof Shield; unite: string; seuilMin?: number; seuilMax?: number }
> = {
  TEMP: { label: "Température", icon: Thermometer, unite: "°C", seuilMin: 18, seuilMax: 22 },
  HUMIDITE: { label: "Humidité", icon: Droplets, unite: "%", seuilMin: 30, seuilMax: 60 },
  PRESSION: { label: "Pression différentielle", icon: Wind, unite: "Pa", seuilMin: 10, seuilMax: 20 },
  PARTICULES: { label: "Particules", icon: Shield, unite: "/m³", seuilMax: 3520 },
};

export default async function ContaminationPage() {
  const readings = await getEnvironmentalReadings();

  const byParam = (p: string) =>
    readings
      .filter((r) => r.parametre === p)
      .map((r) => ({
        date: new Date(r.timestamp).toLocaleDateString("fr-FR", { day: "2-digit", month: "2-digit" }),
        valeur: r.valeur,
        zone: r.zone,
      }));

  const lastByParam = (p: string) => {
    const filtered = readings.filter((r) => r.parametre === p);
    return filtered[filtered.length - 1]?.valeur ?? 0;
  };

  return (
    <div className="max-w-7xl mx-auto">
      <PageHeader
        title="Monitoring contamination & environnement"
        subtitle="Surveillance temps réel zones classées — seuils GMP. Alerte Pseudomonas sur eau EPPI."
      />

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        {Object.entries(META).map(([key, m]) => {
          const Icon = m.icon;
          return (
            <KpiCard
              key={key}
              label={m.label}
              value={lastByParam(key).toFixed(1)}
              suffix={m.unite}
              hint={
                m.seuilMin !== undefined
                  ? `Tolérance ${m.seuilMin}–${m.seuilMax} ${m.unite}`
                  : `Seuil max ${m.seuilMax} ${m.unite}`
              }
              icon={Icon}
              tone="primary"
            />
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {Object.entries(META).map(([key, m]) => (
          <Card key={key}>
            <CardHeader>
              <CardTitle>
                {m.label} — 30 derniers jours
              </CardTitle>
            </CardHeader>
            <CardBody>
              <EnvChart
                data={byParam(key)}
                unite={m.unite}
                seuilMin={m.seuilMin}
                seuilMax={m.seuilMax}
              />
            </CardBody>
          </Card>
        ))}
      </div>
    </div>
  );
}
