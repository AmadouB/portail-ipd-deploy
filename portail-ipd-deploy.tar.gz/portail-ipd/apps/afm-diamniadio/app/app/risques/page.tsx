import { AlertTriangle, Shield, Zap, Package } from "lucide-react";
import { getRisks, currentPeriode } from "@/lib/dal";
import { prisma } from "@/lib/prisma";
import { Card, CardBody, CardHeader, CardTitle } from "@/components/ui/card";
import { KpiCard } from "@/components/ui/kpi-card";
import { Badge } from "@/components/ui/badge";
import { PageHeader } from "@/components/layout/page-header";
import { RiskHeatmap } from "@/components/charts/risk-heatmap";
import { RisksTable } from "@/components/modules/risques/risks-table";

const CAT_META: Record<string, { label: string; icon: typeof AlertTriangle }> = {
  CONTAMINATION: { label: "Contamination", icon: Shield },
  ENERGIE: { label: "Énergie", icon: Zap },
  SUPPLY: { label: "Supply", icon: Package },
  QUALITE: { label: "Qualité", icon: AlertTriangle },
  AUTRE: { label: "Autre", icon: AlertTriangle },
};

export default async function RisquesPage() {
  const risks = await getRisks();
  const critiques = risks.filter((r) => r.score >= 15).length;
  const eleves = risks.filter((r) => r.score >= 10 && r.score < 15).length;

  const counts = await prisma.comment.groupBy({
    by: ["entityId"],
    where: { entityType: "risk" },
    _count: true,
  });
  const countMap = new Map(counts.map((c) => [c.entityId, c._count]));
  const rows = risks.map((r) => ({ ...r, commentCount: countMap.get(r.id) ?? 0 }));

  const byCat: Record<string, number> = {};
  for (const r of risks) byCat[r.categorie] = (byCat[r.categorie] ?? 0) + 1;

  return (
    <div className="max-w-7xl mx-auto">
      <PageHeader
        title="Gestion des Risques"
        subtitle="Matrice d'identification, de suivi et de mitigation des risques critiques."
      />

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <KpiCard
          label="Risques actifs"
          value={risks.length}
          hint="Toutes catégories"
          icon={AlertTriangle}
          tone="primary"
        />
        <KpiCard
          label="Risques critiques"
          value={critiques}
          suffix="score ≥ 15"
          hint="Nécessitent mitigation urgente"
          icon={AlertTriangle}
          tone="danger"
        />
        <KpiCard
          label="Risques élevés"
          value={eleves}
          suffix="10 ≤ score < 15"
          hint="Surveillance active"
          icon={AlertTriangle}
          tone="warning"
        />
        <KpiCard
          label="Sous contrôle"
          value={risks.filter((r) => r.statut === "SOUS_CONTROLE").length}
          suffix="stables"
          hint="Plan de mitigation effectif"
          icon={Shield}
          tone="success"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-4 mb-6">
        <Card className="lg:col-span-3">
          <CardHeader>
            <CardTitle>Matrice probabilité × impact</CardTitle>
          </CardHeader>
          <CardBody>
            <RiskHeatmap risks={risks} />
          </CardBody>
        </Card>
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Répartition par catégorie</CardTitle>
          </CardHeader>
          <CardBody>
            <div className="space-y-3">
              {Object.entries(byCat).map(([cat, count]) => {
                const meta = CAT_META[cat] ?? CAT_META.AUTRE;
                const Icon = meta.icon;
                return (
                  <div
                    key={cat}
                    className="flex items-center justify-between p-3 rounded-lg bg-slate-50 border border-slate-100"
                  >
                    <div className="flex items-center gap-2">
                      <Icon size={16} className="text-slate-500" />
                      <span className="text-sm font-medium text-slate-800">{meta.label}</span>
                    </div>
                    <Badge variant="info">{count}</Badge>
                  </div>
                );
              })}
            </div>
          </CardBody>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Registre des risques</CardTitle>
        </CardHeader>
        <CardBody className="p-0">
          <RisksTable risks={rows} defaultPeriode={currentPeriode()} />
        </CardBody>
      </Card>
    </div>
  );
}
