import Link from "next/link";
import {
  Wallet, Factory, ShieldCheck, AlertTriangle, TrendingUp, ArrowRight, Target,
} from "lucide-react";
import { getOverview } from "@/lib/dal";
import { Card, CardBody, CardHeader, CardTitle } from "@/components/ui/card";
import { KpiCard } from "@/components/ui/kpi-card";
import { Badge, statutVariant } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { PageHeader } from "@/components/layout/page-header";
import { formatEur, formatDoses, formatDate } from "@/lib/utils";

export default async function DashboardPage() {
  const d = await getOverview();

  const modules = [
    {
      title: "Pilotage Financier",
      href: "/app/financier",
      icon: Wallet,
      tone: "primary" as const,
      main: formatEur(d.financier.montantLeve),
      suffix: `/ ${formatEur(d.financier.montantCible)}`,
      hint: `Trésorerie : ${formatEur(d.financier.cashPosition)}`,
      progress: d.financier.montantCible
        ? Math.round((d.financier.montantLeve / d.financier.montantCible) * 100)
        : 0,
    },
    {
      title: "Excellence Industrielle",
      href: "/app/industriel",
      icon: Factory,
      tone: "accent" as const,
      main: `${d.industriel.qualifFait}/${d.industriel.qualifTotal}`,
      suffix: "qualifs",
      hint: `${d.industriel.equipements} équipements suivis`,
      progress: d.industriel.pctQualif,
    },
    {
      title: "Conformité Réglementaire",
      href: "/app/conformite",
      icon: ShieldCheck,
      tone: "success" as const,
      main: d.conformite.jalons.length.toString(),
      suffix: "jalons OMS/ARP",
      hint: `${d.conformite.deviationsOuvertes} déviation(s) en traitement`,
      progress:
        d.conformite.jalons.reduce((s, j) => s + j.progression, 0) /
        Math.max(d.conformite.jalons.length, 1),
    },
    {
      title: "Gestion des Risques",
      href: "/app/risques",
      icon: AlertTriangle,
      tone: d.risques.critiques > 0 ? ("danger" as const) : ("warning" as const),
      main: d.risques.total.toString(),
      suffix: "risques actifs",
      hint: `${d.risques.critiques} critique(s) (score ≥ 15)`,
      progress: null,
    },
    {
      title: "Performance Production",
      href: "/app/production",
      icon: TrendingUp,
      tone: "primary" as const,
      main: formatDoses(d.production.realisDoses),
      suffix: `/ ${formatDoses(d.production.cibleDoses)} doses`,
      hint: `OEE moyen : ${d.production.oeeMoyen} % · ${d.production.annee ?? "—"}`,
      progress: d.production.cibleDoses
        ? Math.round((d.production.realisDoses / d.production.cibleDoses) * 100)
        : 0,
    },
  ];

  return (
    <div className="max-w-7xl mx-auto">
      <PageHeader
        title="Tableau de bord"
        subtitle="Vue d'ensemble des 5 modules de pilotage — objectif stratégique GMP 2027."
      />

      {/* Bannière objectif */}
      <div className="mb-6 p-5 rounded-xl bg-gradient-to-br from-sky-700 to-[#052A62] text-white flex items-center justify-between shadow-sm">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-lg bg-white/10 flex items-center justify-center">
            <Target size={24} />
          </div>
          <div>
            <div className="text-xs uppercase tracking-wider text-sky-200">
              Objectif stratégique
            </div>
            <div className="text-lg font-semibold">
              Lancement production GMP de routine en 2027
            </div>
            <div className="text-sm text-sky-100 mt-0.5">
              3 M doses · 20 M$ de revenus · 10 M doses en 2028 · 41 M$ en 2029
            </div>
          </div>
        </div>
        <div className="hidden md:block text-right">
          <div className="text-xs text-sky-200 uppercase tracking-wider">Financement</div>
          <div className="text-xl font-bold tabular-nums">
            {formatEur(d.financier.montantLeve)} / {formatEur(d.financier.montantCible)}
          </div>
          <div className="text-xs text-sky-100 mt-0.5">sur cible 30 M€</div>
        </div>
      </div>

      {/* Grille 5 modules */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4 mb-6">
        {modules.map((m) => {
          const Icon = m.icon;
          return (
            <Link
              key={m.href}
              href={m.href}
              className="group block bg-white dark:bg-[var(--afm-surface)] border border-slate-200 dark:border-[var(--afm-border)] rounded-xl p-5 shadow-sm hover:shadow-md hover:border-sky-300 dark:hover:border-[#0089D0]/50 transition-all"
            >
              <div className="flex items-center justify-between mb-3">
                <div
                  className={`w-9 h-9 rounded-lg flex items-center justify-center ${
                    m.tone === "primary"
                      ? "bg-sky-50 text-sky-600"
                      : m.tone === "accent"
                      ? "bg-sky-50 text-sky-700"
                      : m.tone === "success"
                      ? "bg-green-50 text-green-700"
                      : m.tone === "warning"
                      ? "bg-orange-50 text-orange-700"
                      : "bg-red-50 text-red-700"
                  }`}
                >
                  <Icon size={18} />
                </div>
                <ArrowRight
                  size={16}
                  className="text-slate-300 group-hover:text-sky-600 group-hover:translate-x-0.5 transition-all"
                />
              </div>
              <div className="text-xs uppercase tracking-wider text-slate-500 font-medium mb-1">
                {m.title}
              </div>
              <div className="flex items-baseline gap-1.5">
                <span className="text-xl font-bold tabular-nums text-slate-900 dark:text-[var(--afm-text)]">{m.main}</span>
                <span className="text-xs text-slate-500">{m.suffix}</span>
              </div>
              <div className="text-xs text-slate-500 mt-1.5">{m.hint}</div>
              {m.progress !== null && (
                <Progress
                  value={m.progress}
                  tone={
                    (m.tone as string) === "danger"
                      ? "danger"
                      : (m.tone as string) === "warning"
                      ? "warning"
                      : "primary"
                  }
                  className="mt-3"
                />
              )}
            </Link>
          );
        })}
      </div>

      {/* Jalons + Top risques */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader>
            <CardTitle>Jalons réglementaires OMS / ARP</CardTitle>
          </CardHeader>
          <CardBody>
            <div className="space-y-4">
              {d.conformite.jalons.map((j) => (
                <div key={j.id}>
                  <div className="flex items-start justify-between mb-1.5">
                    <div>
                      <div className="text-sm font-medium text-slate-900 dark:text-[var(--afm-text)]">{j.libelle}</div>
                      <div className="text-xs text-slate-500">
                        {j.autorite} · cible {formatDate(j.dateCible)}
                      </div>
                    </div>
                    <Badge variant={statutVariant(j.statut)}>{j.statut}</Badge>
                  </div>
                  <Progress
                    value={j.progression}
                    tone={j.progression >= 70 ? "success" : j.progression >= 30 ? "primary" : "warning"}
                  />
                </div>
              ))}
            </div>
          </CardBody>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Top risques à fort enjeu</CardTitle>
          </CardHeader>
          <CardBody>
            <div className="space-y-3">
              {d.risques.top3.map((r) => (
                <div
                  key={r.id}
                  className="flex items-start justify-between p-3 rounded-lg bg-slate-50 dark:bg-[var(--afm-bg)]/60 border border-slate-100 dark:border-[var(--afm-border)]/50"
                >
                  <div className="min-w-0">
                    <div className="text-sm font-medium text-slate-900 dark:text-[var(--afm-text)]">{r.libelle}</div>
                    <div className="text-xs text-slate-500 mt-0.5">
                      {r.categorie} · P {r.probabilite} × I {r.impact}
                    </div>
                  </div>
                  <Badge
                    variant={r.score >= 15 ? "critical" : r.score >= 10 ? "danger" : "warning"}
                  >
                    Score {r.score}
                  </Badge>
                </div>
              ))}
            </div>
          </CardBody>
        </Card>
      </div>
    </div>
  );
}
