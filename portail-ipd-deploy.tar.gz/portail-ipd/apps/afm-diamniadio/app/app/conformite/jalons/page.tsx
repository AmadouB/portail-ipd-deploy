import { getMilestones, currentTrimestre } from "@/lib/dal";
import { prisma } from "@/lib/prisma";
import { PageHeader } from "@/components/layout/page-header";
import { MilestonesList } from "@/components/modules/conformite/milestones-list";

export default async function JalonsPage() {
  const jalons = await getMilestones();

  const counts = await prisma.comment.groupBy({
    by: ["entityId"],
    where: { entityType: "milestone" },
    _count: true,
  });
  const countMap = new Map(counts.map((c) => [c.entityId, c._count]));

  const rows = jalons.map((j) => ({ ...j, commentCount: countMap.get(j.id) ?? 0 }));

  return (
    <div className="max-w-5xl mx-auto">
      <PageHeader
        title="Jalons réglementaires"
        subtitle="Licence d'exploitation (Q2 2026) · Certificat GMP (Q1 2027) · PQ OMS (Q4 2027). Cliquer sur « Modifier » pour mettre à jour le statut, la progression et commenter par trimestre."
      />

      <MilestonesList milestones={rows} defaultPeriode={currentTrimestre()} />
    </div>
  );
}
