import { ShieldCheck, FileWarning, CalendarCheck } from "lucide-react";
import { getMilestones, getDeviations, getAudits } from "@/lib/dal";
import { Card, CardBody, CardHeader, CardTitle } from "@/components/ui/card";
import { KpiCard } from "@/components/ui/kpi-card";
import { Badge, statutVariant } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { PageHeader } from "@/components/layout/page-header";
import { formatDate } from "@/lib/utils";

export default async function ConformitePage() {
  const [jalons, deviations, audits] = await Promise.all([
    getMilestones(),
    getDeviations(),
    getAudits(),
  ]);

  const devOuvertes = deviations.filter((d) => d.statut !== "CLOSE").length;
  const devCritiques = deviations.filter((d) => d.severite === "CRITIQUE" && d.statut !== "CLOSE").length;
  const auditsAVenir = audits.filter((a) => a.statut === "PLANIFIE").length;

  return (
    <div className="max-w-7xl mx-auto">
      <PageHeader
        title="Conformité Réglementaire"
        subtitle="Jalons OMS/ARP, écarts & déviations, audits et inspections."
      />

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <KpiCard
          label="Jalons réglementaires"
          value={jalons.length}
          suffix="suivis"
          hint="Licence · GMP · PQ OMS"
          icon={ShieldCheck}
          tone="primary"
        />
        <KpiCard
          label="Déviations ouvertes"
          value={devOuvertes}
          suffix={devOuvertes > 0 ? "à traiter" : "0"}
          hint={`${devCritiques} critique(s)`}
          icon={FileWarning}
          tone={devCritiques > 0 ? "danger" : "warning"}
        />
        <KpiCard
          label="Audits à venir"
          value={auditsAVenir}
          suffix="planifiés"
          hint="ARP, OMS, mock inspections"
          icon={CalendarCheck}
          tone="accent"
        />
        <KpiCard
          label="Progression moyenne"
          value={`${Math.round(jalons.reduce((s, j) => s + j.progression, 0) / Math.max(jalons.length, 1))} %`}
          hint="Sur l'ensemble des jalons"
          icon={ShieldCheck}
          tone="success"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader>
            <CardTitle>Timeline des jalons OMS / ARP</CardTitle>
          </CardHeader>
          <CardBody>
            <div className="space-y-5 relative">
              <div className="absolute left-[7px] top-2 bottom-2 w-0.5 bg-slate-200" aria-hidden />
              {jalons.map((j) => (
                <div key={j.id} className="relative pl-6">
                  <div
                    className={`absolute left-0 top-1 w-4 h-4 rounded-full border-2 border-white shadow-sm ${
                      j.statut === "OBTENU"
                        ? "bg-green-600"
                        : j.statut === "EN_COURS"
                        ? "bg-sky-600"
                        : "bg-slate-300"
                    }`}
                  />
                  <div className="flex items-start justify-between mb-1.5">
                    <div>
                      <div className="text-sm font-medium text-slate-900">{j.libelle}</div>
                      <div className="text-xs text-slate-500">
                        {j.autorite} · {j.type} · cible {formatDate(j.dateCible)}
                      </div>
                    </div>
                    <Badge variant={statutVariant(j.statut)}>{j.statut}</Badge>
                  </div>
                  <Progress
                    value={j.progression}
                    tone={
                      j.progression >= 70 ? "success" : j.progression >= 30 ? "primary" : "warning"
                    }
                  />
                  {j.notes && <div className="text-xs text-slate-500 mt-1.5">{j.notes}</div>}
                </div>
              ))}
            </div>
          </CardBody>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Déviations récentes</CardTitle>
          </CardHeader>
          <CardBody>
            <div className="space-y-2">
              {deviations.slice(0, 6).map((d) => (
                <div
                  key={d.id}
                  className="flex items-start justify-between p-3 rounded-lg bg-slate-50 border border-slate-100"
                >
                  <div className="min-w-0">
                    <div className="flex items-center gap-2 mb-0.5">
                      <span className="text-xs font-mono text-slate-500">{d.code}</span>
                      <Badge variant={statutVariant(d.severite)}>{d.severite}</Badge>
                    </div>
                    <div className="text-sm font-medium text-slate-900">{d.titre}</div>
                    <div className="text-xs text-slate-500 mt-0.5">
                      Détecté le {formatDate(d.dateDetection)}
                    </div>
                  </div>
                  <Badge variant={statutVariant(d.statut)}>{d.statut}</Badge>
                </div>
              ))}
            </div>
          </CardBody>
        </Card>
      </div>
    </div>
  );
}
