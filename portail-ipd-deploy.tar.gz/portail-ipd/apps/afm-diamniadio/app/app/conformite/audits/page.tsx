import { getAudits, currentTrimestre } from "@/lib/dal";
import { prisma } from "@/lib/prisma";
import { PageHeader } from "@/components/layout/page-header";
import { AuditsList } from "@/components/modules/conformite/audits-list";

export default async function AuditsPage() {
  const audits = await getAudits();

  const counts = await prisma.comment.groupBy({
    by: ["entityId"],
    where: { entityType: "audit" },
    _count: true,
  });
  const countMap = new Map(counts.map((c) => [c.entityId, c._count]));
  const rows = audits.map((a) => ({ ...a, commentCount: countMap.get(a.id) ?? 0 }));

  return (
    <div className="max-w-6xl mx-auto">
      <PageHeader
        title="Audits & inspections"
        subtitle="Calendrier ARP / OMS, audits internes et mock inspections. Cliquer sur « Modifier » pour mettre à jour statut, rapport, ou commenter par trimestre."
      />

      <AuditsList audits={rows} defaultPeriode={currentTrimestre()} />
    </div>
  );
}
