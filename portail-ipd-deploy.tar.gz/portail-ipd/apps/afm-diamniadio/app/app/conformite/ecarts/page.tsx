import { getDeviations } from "@/lib/dal";
import { prisma } from "@/lib/prisma";
import { Card, CardBody, CardHeader, CardTitle } from "@/components/ui/card";
import { PageHeader } from "@/components/layout/page-header";
import { DeviationsTable } from "@/components/modules/conformite/deviations-table";
import { currentPeriode } from "@/lib/dal";

export default async function EcartsPage() {
  const deviations = await getDeviations();
  const ouvertes = deviations.filter((d) => d.statut !== "CLOSE").length;
  const critiques = deviations.filter((d) => d.severite === "CRITIQUE").length;

  // Compte de commentaires par déviation (évite N+1)
  const counts = await prisma.comment.groupBy({
    by: ["entityId"],
    where: { entityType: "deviation" },
    _count: true,
  });
  const countMap = new Map(counts.map((c) => [c.entityId, c._count]));

  const rows = deviations.map((d) => ({
    ...d,
    commentCount: countMap.get(d.id) ?? 0,
  }));

  return (
    <div className="max-w-7xl mx-auto">
      <PageHeader
        title="Écarts & déviations qualité"
        subtitle={`${ouvertes} déviation(s) en traitement · ${critiques} classée(s) critique(s). Cliquer sur « Modifier » pour changer le statut ou ajouter un commentaire.`}
      />

      <Card>
        <CardHeader>
          <CardTitle>Registre des déviations</CardTitle>
        </CardHeader>
        <CardBody className="p-0">
          <DeviationsTable deviations={rows} defaultPeriode={currentPeriode()} />
        </CardBody>
      </Card>
    </div>
  );
}
