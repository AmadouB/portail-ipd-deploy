import { getBudgetLines, currentPeriode } from "@/lib/dal";
import { prisma } from "@/lib/prisma";
import { Card, CardBody, CardHeader, CardTitle } from "@/components/ui/card";
import { PageHeader } from "@/components/layout/page-header";
import { BudgetsTable } from "@/components/modules/financier/budgets-table";
import { formatEur } from "@/lib/utils";

export default async function BudgetsPage() {
  const lines = await getBudgetLines();
  const capex = lines.filter((l) => l.categorie === "CAPEX");
  const opex = lines.filter((l) => l.categorie === "OPEX");
  const totalBudget = lines.reduce((s, b) => s + b.budgetEur, 0);
  const totalConsomme = lines.reduce((s, b) => s + b.consommeEur, 0);

  const counts = await prisma.comment.groupBy({
    by: ["entityId"],
    where: { entityType: "budget_line" },
    _count: true,
  });
  const countMap = new Map(counts.map((c) => [c.entityId, c._count]));
  const withCounts = lines.map((l) => ({ ...l, commentCount: countMap.get(l.id) ?? 0 }));
  const capexRows = withCounts.filter((l) => l.categorie === "CAPEX");
  const opexRows = withCounts.filter((l) => l.categorie === "OPEX");

  return (
    <div className="max-w-6xl mx-auto">
      <PageHeader
        title="Budgets CAPEX / OPEX"
        subtitle={`${formatEur(totalConsomme)} consommés sur ${formatEur(totalBudget)} budgétisés. Cliquer sur « Modifier » pour ajuster un poste ou commenter la revue mensuelle.`}
      />

      <div className="grid grid-cols-1 gap-4 mb-6">
        <Card>
          <CardHeader>
            <CardTitle>
              CAPEX — {formatEur(capex.reduce((s, b) => s + b.budgetEur, 0))} budgétisés
            </CardTitle>
          </CardHeader>
          <CardBody className="p-0">
            <BudgetsTable rows={capexRows} defaultPeriode={currentPeriode()} />
          </CardBody>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>
              OPEX — {formatEur(opex.reduce((s, b) => s + b.budgetEur, 0))} budgétisés
            </CardTitle>
          </CardHeader>
          <CardBody className="p-0">
            <BudgetsTable rows={opexRows} defaultPeriode={currentPeriode()} />
          </CardBody>
        </Card>
      </div>
    </div>
  );
}
