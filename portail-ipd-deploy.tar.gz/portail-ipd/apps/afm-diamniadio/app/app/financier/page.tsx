import { Wallet, TrendingUp, AlertOctagon } from "lucide-react";
import { getFundingRounds, getCashflow, getBudgetLines } from "@/lib/dal";
import { Card, CardBody, CardHeader, CardTitle } from "@/components/ui/card";
import { KpiCard } from "@/components/ui/kpi-card";
import { Badge, statutVariant } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { PageHeader } from "@/components/layout/page-header";
import { CashflowChart } from "@/components/charts/cashflow-chart";
import { formatEur, formatDate } from "@/lib/utils";

export default async function FinancierPage() {
  const [rounds, cashflow, budgets] = await Promise.all([
    getFundingRounds(),
    getCashflow(),
    getBudgetLines(),
  ]);

  const totalCible = rounds.reduce((s, r) => s + r.montantCibleEur, 0);
  const totalLeve = rounds.reduce((s, r) => s + r.montantLeveEur, 0);
  const position = cashflow.at(-1)?.positionEur ?? 0;
  const depassements = budgets.filter((b) => b.alerteDepassement).length;

  const chartData = cashflow.map((c) => ({
    month: new Date(c.date).toLocaleDateString("fr-FR", { month: "short", year: "2-digit" }),
    position: c.positionEur,
    entrees: c.entreesEur,
    sorties: c.sortiesEur,
  }));

  return (
    <div className="max-w-7xl mx-auto">
      <PageHeader
        title="Pilotage Financier"
        subtitle="Cash-flow, levées de fonds, budgets CAPEX/OPEX."
      />

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <KpiCard
          label="Trésorerie actuelle"
          value={formatEur(position)}
          hint="Position quotidienne"
          icon={Wallet}
          tone="primary"
        />
        <KpiCard
          label="Levées réalisées"
          value={formatEur(totalLeve)}
          suffix={`/ ${formatEur(totalCible)}`}
          hint={`${Math.round((totalLeve / Math.max(totalCible, 1)) * 100)} % de la cible 30 M€`}
          icon={TrendingUp}
          tone="success"
        />
        <KpiCard
          label="Budgets 2026"
          value={formatEur(budgets.reduce((s, b) => s + b.budgetEur, 0))}
          hint={`${formatEur(budgets.reduce((s, b) => s + b.consommeEur, 0))} consommés`}
          icon={Wallet}
          tone="accent"
        />
        <KpiCard
          label="Dépassements"
          value={depassements}
          suffix={depassements > 0 ? "alerte" : "OK"}
          hint="Postes en dépassement"
          icon={AlertOctagon}
          tone={depassements > 0 ? "danger" : "success"}
        />
      </div>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Cash-flow 12 mois — position de trésorerie</CardTitle>
        </CardHeader>
        <CardBody>
          <CashflowChart data={chartData} />
        </CardBody>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader>
            <CardTitle>Levées de fonds — 30 M€ cible</CardTitle>
          </CardHeader>
          <CardBody>
            <div className="space-y-4">
              {rounds.map((r) => {
                const pct = Math.round((r.montantLeveEur / r.montantCibleEur) * 100);
                return (
                  <div key={r.id}>
                    <div className="flex items-start justify-between mb-1.5">
                      <div>
                        <div className="text-sm font-medium text-slate-900">{r.libelle}</div>
                        <div className="text-xs text-slate-500">
                          {formatEur(r.montantLeveEur)} / {formatEur(r.montantCibleEur)} · cible{" "}
                          {formatDate(r.dateCible)}
                        </div>
                      </div>
                      <Badge variant={statutVariant(r.statut)}>{r.statut}</Badge>
                    </div>
                    <Progress
                      value={pct}
                      tone={pct >= 100 ? "success" : pct >= 50 ? "primary" : "warning"}
                    />
                  </div>
                );
              })}
            </div>
          </CardBody>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Budgets CAPEX / OPEX 2026</CardTitle>
          </CardHeader>
          <CardBody>
            <div className="space-y-3">
              {budgets.slice(0, 7).map((b) => {
                const pct = Math.min(100, Math.round((b.consommeEur / b.budgetEur) * 100));
                return (
                  <div key={b.id}>
                    <div className="flex items-center justify-between text-xs mb-1">
                      <div className="flex items-center gap-2 min-w-0">
                        <Badge variant={b.categorie === "CAPEX" ? "info" : "neutral"}>
                          {b.categorie}
                        </Badge>
                        <span className="text-slate-700 truncate">{b.poste}</span>
                      </div>
                      <span className="tabular-nums text-slate-600 flex-shrink-0">
                        {formatEur(b.consommeEur)} / {formatEur(b.budgetEur)}
                      </span>
                    </div>
                    <Progress
                      value={pct}
                      tone={b.alerteDepassement ? "danger" : pct > 80 ? "warning" : "primary"}
                    />
                  </div>
                );
              })}
            </div>
          </CardBody>
        </Card>
      </div>
    </div>
  );
}
