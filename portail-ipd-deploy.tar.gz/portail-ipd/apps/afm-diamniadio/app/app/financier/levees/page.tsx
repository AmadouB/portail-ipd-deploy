import { getFundingRounds, currentPeriode } from "@/lib/dal";
import { prisma } from "@/lib/prisma";
import { Card, CardBody, CardHeader, CardTitle } from "@/components/ui/card";
import { PageHeader } from "@/components/layout/page-header";
import { FundingRoundsTable } from "@/components/modules/financier/funding-rounds-table";
import { formatEur } from "@/lib/utils";

export default async function LeveesPage() {
  const rounds = await getFundingRounds();
  const totalCible = rounds.reduce((s, r) => s + r.montantCibleEur, 0);
  const totalLeve = rounds.reduce((s, r) => s + r.montantLeveEur, 0);

  const counts = await prisma.comment.groupBy({
    by: ["entityId"],
    where: { entityType: "funding_round" },
    _count: true,
  });
  const countMap = new Map(counts.map((c) => [c.entityId, c._count]));
  const rows = rounds.map((r) => ({ ...r, commentCount: countMap.get(r.id) ?? 0 }));

  return (
    <div className="max-w-6xl mx-auto">
      <PageHeader
        title="Levées de fonds"
        subtitle={`${formatEur(totalLeve)} levés sur cible ${formatEur(totalCible)} — OGSM §1.1. Cliquer sur « Modifier » pour mettre à jour montants et statut, ou commenter le round.`}
      />

      <Card>
        <CardHeader>
          <CardTitle>Tranches de financement</CardTitle>
        </CardHeader>
        <CardBody className="p-0">
          <FundingRoundsTable rounds={rows} defaultPeriode={currentPeriode()} />
        </CardBody>
      </Card>
    </div>
  );
}
