import { getOgsmMatrix } from "@/lib/dal";
import { prisma } from "@/lib/prisma";
import { PageHeader } from "@/components/layout/page-header";
import { OgsmMatrix } from "@/components/modules/ogsm/ogsm-matrix";

export default async function OgsmPage() {
  const { objective, goals, axes, actions, users } = await getOgsmMatrix();

  const counts = await prisma.comment.groupBy({
    by: ["entityId"],
    where: { entityType: "ogsm_action" },
    _count: true,
  });
  const countMap = new Map(counts.map((c) => [c.entityId, c._count]));
  const actionsWithComments = actions.map((a) => ({
    ...a,
    commentCount: countMap.get(a.id) ?? 0,
  }));

  return (
    <div className="max-w-[1400px] mx-auto">
      <PageHeader
        title="OGSM — Matrice de pilotage stratégique"
        subtitle="Objectifs · Buts · Axes stratégiques · Plans d'action · Mesures · Responsables. Les visuels et statistiques réagissent automatiquement aux filtres sélectionnés."
      />

      <OgsmMatrix
        objective={objective}
        goals={goals}
        axes={axes}
        actions={actionsWithComments}
        users={users}
      />
    </div>
  );
}
