import { getProductionBatches, currentPeriode } from "@/lib/dal";
import { prisma } from "@/lib/prisma";
import { Card, CardBody, CardHeader, CardTitle } from "@/components/ui/card";
import { PageHeader } from "@/components/layout/page-header";
import { BatchesTable } from "@/components/modules/production/batches-table";
import { formatPct } from "@/lib/utils";

export default async function RendementsPage() {
  const batches = await getProductionBatches();
  const total = batches.length;
  const conformes = batches.filter((b) => b.statut === "CONFORME").length;
  const rejetes = batches.filter((b) => b.statut === "REJETE").length;
  const reprises = batches.filter((b) => b.statut === "REPRISE").length;

  const counts = await prisma.comment.groupBy({
    by: ["entityId"],
    where: { entityType: "production_batch" },
    _count: true,
  });
  const countMap = new Map(counts.map((c) => [c.entityId, c._count]));
  const rows = batches.map((b) => ({ ...b, commentCount: countMap.get(b.id) ?? 0 }));

  const donut = [
    { label: "Conformes", count: conformes, color: "bg-green-500", pct: (conformes / total) * 100 },
    { label: "Reprises", count: reprises, color: "bg-orange-500", pct: (reprises / total) * 100 },
    { label: "Rejetés", count: rejetes, color: "bg-red-500", pct: (rejetes / total) * 100 },
  ];

  return (
    <div className="max-w-7xl mx-auto">
      <PageHeader
        title="Rendements & qualité des lots"
        subtitle={`${total} lots suivis · ${formatPct((conformes / total) * 100, 1)} de lots conformes. Cliquer sur « Modifier » pour changer le statut d'un lot ou documenter une reprise.`}
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-6">
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle>Répartition</CardTitle>
          </CardHeader>
          <CardBody>
            <div className="space-y-3">
              {donut.map((d) => (
                <div key={d.label}>
                  <div className="flex items-center justify-between text-sm mb-1">
                    <div className="flex items-center gap-2">
                      <span className={`w-3 h-3 rounded-sm ${d.color}`} />
                      <span>{d.label}</span>
                    </div>
                    <span className="tabular-nums text-slate-600">
                      {d.count} ({d.pct.toFixed(1)} %)
                    </span>
                  </div>
                  <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className={`${d.color} h-full rounded-full`}
                      style={{ width: `${d.pct}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </CardBody>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Lots de production</CardTitle>
          </CardHeader>
          <CardBody className="p-0">
            <BatchesTable batches={rows} defaultPeriode={currentPeriode()} />
          </CardBody>
        </Card>
      </div>
    </div>
  );
}
