import { getProductionTargets, currentTrimestre } from "@/lib/dal";
import { prisma } from "@/lib/prisma";
import { PageHeader } from "@/components/layout/page-header";
import { VolumesClient } from "@/components/modules/production/volumes-client";

export default async function VolumesPage() {
  const targets = await getProductionTargets();

  const counts = await prisma.comment.groupBy({
    by: ["entityId"],
    where: { entityType: "production_target" },
    _count: true,
  });
  const countMap = new Map(counts.map((c) => [c.entityId, c._count]));
  const rows = targets.map((t) => ({ ...t, commentCount: countMap.get(t.id) ?? 0 }));

  return (
    <div className="max-w-6xl mx-auto">
      <PageHeader
        title="Volumes de production 2027 / 2028 / 2029"
        subtitle="Cibles OGSM : 3 M doses (2027) · 10 M doses (2028) · 14 M doses (2029). Cliquer sur « Modifier » pour ajuster cibles/réalisé et commenter les revues trimestrielles."
      />

      <VolumesClient targets={rows} defaultPeriode={currentTrimestre()} />
    </div>
  );
}
