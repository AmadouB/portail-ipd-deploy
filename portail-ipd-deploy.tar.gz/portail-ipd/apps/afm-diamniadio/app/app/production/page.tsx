import { TrendingUp, Package, Factory, AlertTriangle } from "lucide-react";
import { getProductionTargets, getProductionBatches, getOEEMetrics } from "@/lib/dal";
import { Card, CardBody, CardHeader, CardTitle } from "@/components/ui/card";
import { KpiCard } from "@/components/ui/kpi-card";
import { Badge, statutVariant } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { PageHeader } from "@/components/layout/page-header";
import { OEEGauge } from "@/components/charts/oee-gauge";
import { formatDoses, formatDate, formatPct, formatEur } from "@/lib/utils";

export default async function ProductionPage() {
  const [targets, batches, oeeMetrics] = await Promise.all([
    getProductionTargets(),
    getProductionBatches(),
    getOEEMetrics(),
  ]);

  const currentTarget = targets[0];
  const totalProd = batches
    .filter((b) => b.statut === "CONFORME")
    .reduce((s, b) => s + b.volumeDoses, 0);
  const rejets = batches.filter((b) => b.statut === "REJETE").length;
  const reprises = batches.filter((b) => b.statut === "REPRISE").length;
  const avgRendement =
    batches.filter((b) => b.rendement).reduce((s, b) => s + (b.rendement ?? 0), 0) /
    Math.max(batches.filter((b) => b.rendement).length, 1);

  // Moyennes OEE sur fenêtre récente
  const avgDispo =
    oeeMetrics.reduce((s, m) => s + m.disponibilite, 0) / Math.max(oeeMetrics.length, 1);
  const avgPerf =
    oeeMetrics.reduce((s, m) => s + m.performance, 0) / Math.max(oeeMetrics.length, 1);
  const avgQual = oeeMetrics.reduce((s, m) => s + m.qualite, 0) / Math.max(oeeMetrics.length, 1);
  const avgOee = oeeMetrics.reduce((s, m) => s + m.oee, 0) / Math.max(oeeMetrics.length, 1);

  return (
    <div className="max-w-7xl mx-auto">
      <PageHeader
        title="Performance Production"
        subtitle="Volumes cibles 2027/2028/2029 · OEE · rendements & qualité lots."
      />

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <KpiCard
          label={`Cible ${currentTarget?.annee ?? "—"}`}
          value={formatDoses(currentTarget?.cibleDoses ?? 0)}
          suffix="doses"
          hint={`Revenus cible ${formatEur(currentTarget?.revenusEurCible ?? 0)}`}
          icon={TrendingUp}
          tone="primary"
        />
        <KpiCard
          label="Doses produites (lots conformes)"
          value={formatDoses(totalProd)}
          suffix="doses"
          hint={`${batches.filter((b) => b.statut === "CONFORME").length} lots conformes`}
          icon={Package}
          tone="success"
        />
        <KpiCard
          label="OEE moyen 30 j"
          value={`${avgOee.toFixed(1)}`}
          suffix="%"
          hint={`Rendement moyen lots : ${formatPct(avgRendement)}`}
          icon={Factory}
          tone="accent"
        />
        <KpiCard
          label="Lots non conformes"
          value={rejets + reprises}
          hint={`${rejets} rejet(s) · ${reprises} reprise(s)`}
          icon={AlertTriangle}
          tone={rejets > 0 ? "danger" : "warning"}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-6">
        <Card>
          <CardHeader>
            <CardTitle>OEE — Disponibilité × Performance × Qualité</CardTitle>
          </CardHeader>
          <CardBody>
            <div className="flex items-center justify-around py-4">
              <OEEGauge label="Disponibilité" value={avgDispo} />
              <OEEGauge label="Performance" value={avgPerf} />
              <OEEGauge label="Qualité" value={avgQual} />
              <OEEGauge label="OEE global" value={avgOee} size={140} />
            </div>
            <div className="text-xs text-slate-500 text-center mt-2">
              Moyennes sur 30 jours · 4 équipements critiques suivis
            </div>
          </CardBody>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Objectifs pluriannuels</CardTitle>
          </CardHeader>
          <CardBody>
            <div className="space-y-4">
              {targets.map((t) => {
                const pct = t.cibleDoses ? Math.round((t.realisDoses / t.cibleDoses) * 100) : 0;
                return (
                  <div key={t.id}>
                    <div className="flex items-baseline justify-between mb-1">
                      <span className="text-sm font-semibold text-slate-900">{t.annee}</span>
                      <span className="text-xs text-slate-500 tabular-nums">
                        {formatDoses(t.realisDoses)} / {formatDoses(t.cibleDoses)} doses
                      </span>
                    </div>
                    <Progress
                      value={pct}
                      tone={pct >= 100 ? "success" : pct >= 50 ? "primary" : "warning"}
                    />
                    {t.commentaire && (
                      <div className="text-xs text-slate-500 mt-1">{t.commentaire}</div>
                    )}
                  </div>
                );
              })}
            </div>
          </CardBody>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Lots récents</CardTitle>
        </CardHeader>
        <CardBody>
          <div className="space-y-2">
            {batches.slice(0, 8).map((b) => (
              <div
                key={b.id}
                className="flex items-center justify-between p-3 rounded-lg bg-slate-50 border border-slate-100"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <span className="font-mono text-xs text-slate-600">{b.numeroLot}</span>
                  <span className="text-sm text-slate-700">
                    {formatDoses(b.volumeDoses)} doses · {formatDate(b.dateProduction)}
                  </span>
                  {b.rendement && (
                    <span className="text-xs text-slate-500">
                      rendement {formatPct(b.rendement, 1)}
                    </span>
                  )}
                </div>
                <Badge variant={statutVariant(b.statut)}>{b.statut}</Badge>
              </div>
            ))}
          </div>
        </CardBody>
      </Card>
    </div>
  );
}
