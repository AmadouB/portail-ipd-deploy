import { getOEEMetrics, getEquipments } from "@/lib/dal";
import { Card, CardBody, CardHeader, CardTitle } from "@/components/ui/card";
import { OEEGauge } from "@/components/charts/oee-gauge";
import { PageHeader } from "@/components/layout/page-header";

export default async function OeePage() {
  const [metrics, equipements] = await Promise.all([getOEEMetrics(), getEquipments()]);

  const byEquipment: Record<string, { dispo: number; perf: number; qual: number; oee: number; count: number; libelle: string }> = {};
  for (const m of metrics) {
    const key = m.equipmentId;
    const eq = equipements.find((e) => e.id === key);
    byEquipment[key] ||= { dispo: 0, perf: 0, qual: 0, oee: 0, count: 0, libelle: eq?.libelle ?? key };
    byEquipment[key].dispo += m.disponibilite;
    byEquipment[key].perf += m.performance;
    byEquipment[key].qual += m.qualite;
    byEquipment[key].oee += m.oee;
    byEquipment[key].count += 1;
  }

  const rows = Object.values(byEquipment).map((b) => ({
    ...b,
    dispo: b.dispo / b.count,
    perf: b.perf / b.count,
    qual: b.qual / b.count,
    oee: b.oee / b.count,
  }));

  return (
    <div className="max-w-7xl mx-auto">
      <PageHeader
        title="OEE — Overall Equipment Effectiveness"
        subtitle="Disponibilité × Performance × Qualité par équipement critique, moyenne 30 j."
      />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {rows.map((r) => (
          <Card key={r.libelle}>
            <CardHeader>
              <CardTitle>{r.libelle}</CardTitle>
            </CardHeader>
            <CardBody>
              <div className="flex items-center justify-around py-2">
                <OEEGauge label="Disponibilité" value={r.dispo} size={96} />
                <OEEGauge label="Performance" value={r.perf} size={96} />
                <OEEGauge label="Qualité" value={r.qual} size={96} />
                <OEEGauge label="OEE" value={r.oee} size={120} />
              </div>
            </CardBody>
          </Card>
        ))}
      </div>
    </div>
  );
}
