import { getEquipments, currentPeriode } from "@/lib/dal";
import { prisma } from "@/lib/prisma";
import { Card, CardBody, CardHeader, CardTitle } from "@/components/ui/card";
import { PageHeader } from "@/components/layout/page-header";
import { QualificationsMatrix } from "@/components/modules/industriel/qualifications-matrix";

export default async function QualificationsPage() {
  const equipements = await getEquipments();

  const counts = await prisma.comment.groupBy({
    by: ["entityId"],
    where: { entityType: "qualification" },
    _count: true,
  });
  const countMap = new Map(counts.map((c) => [c.entityId, c._count]));

  const rows = equipements.map((eq) => ({
    ...eq,
    qualifications: eq.qualifications.map((q) => ({
      ...q,
      commentCount: countMap.get(q.id) ?? 0,
    })),
  }));

  return (
    <div className="max-w-7xl mx-auto">
      <PageHeader
        title="Qualifications IQ / OQ / PQ"
        subtitle="Matrice équipement × phase — cliquer sur une cellule pour modifier le statut et ajouter un commentaire de revue."
      />

      <Card>
        <CardHeader>
          <CardTitle>Matrice qualifications</CardTitle>
        </CardHeader>
        <CardBody className="p-0">
          <QualificationsMatrix equipements={rows} defaultPeriode={currentPeriode()} />
        </CardBody>
      </Card>
    </div>
  );
}
