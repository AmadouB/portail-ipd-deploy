import Link from "next/link";
import { Factory, CheckCircle2, FileText, Wrench } from "lucide-react";
import { getEquipments, getQualifications, getSops } from "@/lib/dal";
import { Card, CardBody, CardHeader, CardTitle } from "@/components/ui/card";
import { KpiCard } from "@/components/ui/kpi-card";
import { Badge, statutVariant } from "@/components/ui/badge";
import { PageHeader } from "@/components/layout/page-header";

export default async function IndustrielPage() {
  const [equipements, qualifs, sops] = await Promise.all([
    getEquipments(),
    getQualifications(),
    getSops(),
  ]);

  const qualifFait = qualifs.filter((q) => q.statut === "FAIT").length;
  const sopValides = sops.filter((s) => s.statut === "VALIDE").length;
  const equipOperationnels = equipements.filter((e) => e.statut === "OPERATIONNEL").length;
  const equipCritiques = equipements.filter((e) => e.criticite === "CRITIQUE");

  return (
    <div className="max-w-7xl mx-auto">
      <PageHeader
        title="Excellence Industrielle"
        subtitle="Qualifications IQ/OQ/PQ, documentation SOP, équipements critiques."
      />

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <KpiCard
          label="Équipements"
          value={`${equipOperationnels}/${equipements.length}`}
          suffix="ops"
          hint={`${equipCritiques.length} équipements critiques`}
          icon={Factory}
          tone="primary"
        />
        <KpiCard
          label="Qualifications IQ/OQ/PQ"
          value={`${qualifFait}/${qualifs.length}`}
          suffix="faites"
          hint={`${Math.round((qualifFait / Math.max(qualifs.length, 1)) * 100)} % validées`}
          icon={CheckCircle2}
          tone="success"
        />
        <KpiCard
          label="SOP validées"
          value={`${sopValides}/${sops.length}`}
          suffix="SOP"
          hint={`${sops.filter((s) => s.statut === "EN_REVUE").length} en revue`}
          icon={FileText}
          tone="accent"
        />
        <KpiCard
          label="En maintenance"
          value={equipements.filter((e) => e.statut === "MAINTENANCE").length}
          suffix="équipements"
          hint="Maintenance préventive ou curative"
          icon={Wrench}
          tone="warning"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader>
            <CardTitle>Équipements critiques</CardTitle>
          </CardHeader>
          <CardBody>
            <div className="space-y-2">
              {equipCritiques.map((eq) => (
                <Link
                  key={eq.id}
                  href="/app/industriel/equipements"
                  className="flex items-center justify-between p-3 rounded-lg bg-slate-50 border border-slate-100 hover:bg-slate-100 transition-colors"
                >
                  <div className="min-w-0">
                    <div className="text-sm font-medium text-slate-900">{eq.libelle}</div>
                    <div className="text-xs text-slate-500">
                      {eq.code} · {eq.zone}
                    </div>
                  </div>
                  <Badge variant={statutVariant(eq.statut)}>{eq.statut}</Badge>
                </Link>
              ))}
            </div>
          </CardBody>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>SOP récemment révisées</CardTitle>
          </CardHeader>
          <CardBody>
            <div className="space-y-2">
              {sops.slice(0, 6).map((s) => (
                <div
                  key={s.id}
                  className="flex items-center justify-between p-3 rounded-lg bg-slate-50 border border-slate-100"
                >
                  <div className="min-w-0">
                    <div className="text-sm font-medium text-slate-900 truncate">{s.titre}</div>
                    <div className="text-xs text-slate-500">
                      {s.code} · v{s.version} · {s.categorie ?? "—"}
                    </div>
                  </div>
                  <Badge variant={statutVariant(s.statut)}>{s.statut}</Badge>
                </div>
              ))}
            </div>
          </CardBody>
        </Card>
      </div>
    </div>
  );
}
