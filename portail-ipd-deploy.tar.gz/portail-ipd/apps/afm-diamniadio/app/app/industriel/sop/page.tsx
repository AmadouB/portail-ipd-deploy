import { getSops, currentTrimestre } from "@/lib/dal";
import { prisma } from "@/lib/prisma";
import { Card, CardBody, CardHeader, CardTitle } from "@/components/ui/card";
import { PageHeader } from "@/components/layout/page-header";
import { SopTable } from "@/components/modules/industriel/sop-table";

export default async function SopPage() {
  const sops = await getSops();
  const now = Date.now();
  const echues = sops.filter(
    (s) => s.dateProchainRevision && new Date(s.dateProchainRevision).getTime() < now
  ).length;

  const counts = await prisma.comment.groupBy({
    by: ["entityId"],
    where: { entityType: "sop" },
    _count: true,
  });
  const countMap = new Map(counts.map((c) => [c.entityId, c._count]));
  const rows = sops.map((s) => ({ ...s, commentCount: countMap.get(s.id) ?? 0 }));

  return (
    <div className="max-w-7xl mx-auto">
      <PageHeader
        title="Documentation SOP"
        subtitle={`${sops.filter((s) => s.statut === "VALIDE").length} SOP validées · ${echues} révision(s) échue(s). Cliquer sur « Modifier » pour mettre à jour statut, version ou ajouter une note de revue.`}
      />

      <Card>
        <CardHeader>
          <CardTitle>Liste des procédures opératoires standards</CardTitle>
        </CardHeader>
        <CardBody className="p-0">
          <SopTable sops={rows} defaultPeriode={currentTrimestre()} />
        </CardBody>
      </Card>
    </div>
  );
}
