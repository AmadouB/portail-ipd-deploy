import { getEquipments, currentPeriode } from "@/lib/dal";
import { prisma } from "@/lib/prisma";
import { Card, CardBody, CardHeader, CardTitle } from "@/components/ui/card";
import { PageHeader } from "@/components/layout/page-header";
import { EquipmentMapDynamic } from "@/components/charts/equipment-map-dynamic";
import { EquipmentsTable } from "@/components/modules/industriel/equipments-table";

export default async function EquipementsPage() {
  const equipements = await getEquipments();

  const counts = await prisma.comment.groupBy({
    by: ["entityId"],
    where: { entityType: "equipment" },
    _count: true,
  });
  const countMap = new Map(counts.map((c) => [c.entityId, c._count]));
  const rows = equipements.map((e) => ({ ...e, commentCount: countMap.get(e.id) ?? 0 }));

  const mapData = equipements.map((e) => ({
    id: e.id,
    code: e.code,
    libelle: e.libelle,
    zone: e.zone,
    lat: e.lat,
    lng: e.lng,
    statut: e.statut,
    criticite: e.criticite,
  }));

  return (
    <div className="max-w-7xl mx-auto">
      <PageHeader
        title="Équipements critiques — site Diamniadio"
        subtitle="Localisation, statut opérationnel et notes de maintenance par période. Cliquer sur « Modifier » pour changer un statut ou commenter."
      />

      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Plan du site Vaccinopole de Diamniadio</CardTitle>
        </CardHeader>
        <CardBody>
          <EquipmentMapDynamic equipements={mapData} />
          <div className="flex items-center gap-4 mt-3 text-xs text-slate-600">
            <LegendDot color="#16a34a" label="Opérationnel" />
            <LegendDot color="#ea580c" label="Maintenance" />
            <LegendDot color="#0ea5e9" label="Installation" />
            <LegendDot color="#dc2626" label="Hors service" />
          </div>
        </CardBody>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Liste des équipements</CardTitle>
        </CardHeader>
        <CardBody className="p-0">
          <EquipmentsTable equipements={rows} defaultPeriode={currentPeriode()} />
        </CardBody>
      </Card>
    </div>
  );
}

function LegendDot({ color, label }: { color: string; label: string }) {
  return (
    <div className="flex items-center gap-1.5">
      <span
        className="w-3 h-3 rounded-full border border-white shadow-sm"
        style={{ background: color }}
      />
      {label}
    </div>
  );
}
