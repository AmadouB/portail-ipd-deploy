import { prisma } from "@/lib/prisma";
import { Card, CardBody, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, Thead, Tbody, Tr, Th, Td } from "@/components/ui/table";
import { PageHeader } from "@/components/layout/page-header";
import { ROLE_LABELS, MODULE_ACCESS } from "@/lib/rbac";
import { formatDateTime, initiales } from "@/lib/utils";

export default async function AdminPage() {
  const users = await prisma.user.findMany({
    include: { role: true },
    orderBy: { createdAt: "asc" },
  });
  const roles = await prisma.role.findMany({ orderBy: { niveau: "desc" } });

  return (
    <div className="max-w-7xl mx-auto">
      <PageHeader
        title="Administration"
        subtitle="Utilisateurs, rôles et matrice des permissions."
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-6">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Utilisateurs</CardTitle>
          </CardHeader>
          <CardBody className="p-0">
            <Table>
              <Thead>
                <Tr>
                  <Th></Th>
                  <Th>Nom</Th>
                  <Th>Email</Th>
                  <Th>Rôle</Th>
                  <Th>Dernière connexion</Th>
                  <Th>Statut</Th>
                </Tr>
              </Thead>
              <Tbody>
                {users.map((u) => (
                  <Tr key={u.id}>
                    <Td>
                      <div className="w-8 h-8 rounded-full bg-sky-100 text-sky-700 flex items-center justify-center text-xs font-semibold">
                        {initiales(u.prenom, u.nom)}
                      </div>
                    </Td>
                    <Td>
                      <div className="font-medium text-slate-900">
                        {u.prenom} {u.nom}
                      </div>
                      {u.titre && <div className="text-xs text-slate-500">{u.titre}</div>}
                    </Td>
                    <Td className="text-xs">{u.email}</Td>
                    <Td>
                      <Badge variant="info">{ROLE_LABELS[u.roleCode] ?? u.roleCode}</Badge>
                    </Td>
                    <Td className="text-xs">{formatDateTime(u.lastLoginAt)}</Td>
                    <Td>
                      <Badge variant={u.actif ? "success" : "neutral"}>
                        {u.actif ? "Actif" : "Inactif"}
                      </Badge>
                    </Td>
                  </Tr>
                ))}
              </Tbody>
            </Table>
          </CardBody>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Rôles & permissions</CardTitle>
          </CardHeader>
          <CardBody>
            <div className="space-y-3">
              {roles.map((r) => (
                <div key={r.code} className="p-3 rounded-lg bg-slate-50 border border-slate-100">
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-sm font-semibold text-slate-900">{r.libelle}</span>
                    <span className="text-xs text-slate-500 font-mono">niv. {r.niveau}</span>
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {(MODULE_ACCESS[r.code] ?? []).map((m) => (
                      <Badge key={m} variant="neutral" className="text-[10px]">
                        {m}
                      </Badge>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </CardBody>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Intégrations & conformité</CardTitle>
        </CardHeader>
        <CardBody>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
            <div>
              <div className="text-xs uppercase tracking-wider text-slate-500 font-medium mb-1">
                Intégrations (§4.2)
              </div>
              <ul className="space-y-1 text-slate-700">
                <li>• SCADA — acquisition temps réel</li>
                <li>• LIMS — contrôles qualité</li>
                <li>• MES — ordres de fabrication</li>
                <li>• ENNOV — gestion documentaire</li>
                <li>• ERP SAP — finances & RH</li>
              </ul>
              <div className="text-xs text-slate-500 mt-1 italic">Prévues post-livraison</div>
            </div>
            <div>
              <div className="text-xs uppercase tracking-wider text-slate-500 font-medium mb-1">
                Sécurité (§6.1)
              </div>
              <ul className="space-y-1 text-slate-700">
                <li>• JWT httpOnly (jose + bcryptjs)</li>
                <li>• RBAC 6 rôles</li>
                <li>• Audit trails (table AuditLog)</li>
                <li>• SSO / 2FA — post-livraison</li>
                <li>• TLS 1.3 — en production</li>
              </ul>
            </div>
            <div>
              <div className="text-xs uppercase tracking-wider text-slate-500 font-medium mb-1">
                Conformité (§6.2)
              </div>
              <ul className="space-y-1 text-slate-700">
                <li>• GMP — Good Manufacturing Practice</li>
                <li>• 21 CFR Part 11 — signatures électroniques</li>
                <li>• RGPD — protection données</li>
                <li>• Validation CSV — à formaliser</li>
              </ul>
            </div>
          </div>
        </CardBody>
      </Card>
    </div>
  );
}
