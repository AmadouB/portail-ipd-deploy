import type { NextConfig } from "next";

/**
 * Lorsque la variable BASE_PATH est définie (déploiement sous-chemin nginx),
 * Next.js sert toute l'app sous ce préfixe (ex : /AFM).
 *
 * Build standalone : output autonome dans .next/standalone (pour systemd / Docker).
 */
const basePath = process.env.NEXT_PUBLIC_BASE_PATH ?? process.env.BASE_PATH ?? "";

const nextConfig: NextConfig = {
  basePath: basePath || undefined,
  assetPrefix: basePath || undefined,
  output: "standalone",
  trailingSlash: false,
};

export default nextConfig;
