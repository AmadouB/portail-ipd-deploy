"use client";

import { useEffect, useState, type ReactNode } from "react";
import { Send, MessageSquare, CalendarDays } from "lucide-react";
import { initiales, formatDateTime } from "@/lib/utils";
import { apiPath } from "@/lib/api";

export type Comment = {
  id: string;
  entityType: string;
  entityId: string;
  periode: string | null;
  auteurId: string;
  auteurNom: string;
  contenu: string;
  createdAt: string;
};

function PeriodeLabel({ periode }: { periode: string }) {
  // "2026-04" → "Avril 2026", "2026-T1" → "T1 2026"
  if (/^\d{4}-T\d$/.test(periode)) {
    const [y, t] = periode.split("-");
    return <span>Trimestre {t.replace("T", "")} — {y}</span>;
  }
  if (/^\d{4}-\d{2}$/.test(periode)) {
    const [y, m] = periode.split("-");
    const months = [
      "Janvier", "Février", "Mars", "Avril", "Mai", "Juin",
      "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre",
    ];
    return <span>{months[Number(m) - 1]} {y}</span>;
  }
  return <span>{periode}</span>;
}

function groupByPeriode(comments: Comment[]): Array<{ periode: string | null; items: Comment[] }> {
  const groups: Record<string, Comment[]> = {};
  const order: (string | null)[] = [];
  for (const c of comments) {
    const key = c.periode ?? "_none";
    if (!(key in groups)) {
      groups[key] = [];
      order.push(c.periode);
    }
    groups[key].push(c);
  }
  return order.map((p) => ({ periode: p, items: groups[p ?? "_none"] }));
}

export function CommentThread({
  entityType,
  entityId,
  defaultPeriode,
  header,
}: {
  entityType: string;
  entityId: string;
  defaultPeriode?: string;
  header?: ReactNode;
}) {
  const [comments, setComments] = useState<Comment[]>([]);
  const [loading, setLoading] = useState(true);
  const [contenu, setContenu] = useState("");
  const [periode, setPeriode] = useState(defaultPeriode ?? "");
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      setLoading(true);
      const res = await fetch(
        apiPath(`/api/comments?entityType=${encodeURIComponent(entityType)}&entityId=${encodeURIComponent(entityId)}`)
      );
      if (!res.ok) return;
      const data = await res.json();
      if (!cancelled) {
        setComments(data.comments);
        setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [entityType, entityId]);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!contenu.trim() || submitting) return;
    setSubmitting(true);
    const res = await fetch(apiPath("/api/comments"), {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        entityType,
        entityId,
        contenu,
        periode: periode || null,
      }),
    });
    setSubmitting(false);
    if (res.ok) {
      const data = await res.json();
      setComments([data.comment, ...comments]);
      setContenu("");
    }
  }

  const groups = groupByPeriode(comments);

  return (
    <div>
      {header}

      <form
        onSubmit={onSubmit}
        className="bg-slate-50 dark:bg-[var(--afm-bg)]/60 border border-slate-200 dark:border-[var(--afm-border)] rounded-lg p-3 mb-4"
      >
        <div className="flex items-center gap-2 mb-2">
          <CalendarDays size={14} className="text-slate-400 dark:text-slate-500" />
          <input
            type="text"
            value={periode}
            onChange={(e) => setPeriode(e.target.value)}
            placeholder="Période (ex: 2026-04, 2026-T2) — optionnel"
            className="flex-1 bg-transparent text-xs text-slate-700 dark:text-[var(--afm-text)]/85 placeholder:text-slate-400 dark:text-slate-500 focus:outline-none font-mono"
          />
        </div>
        <div className="flex items-start gap-2">
          <textarea
            value={contenu}
            onChange={(e) => setContenu(e.target.value)}
            placeholder="Ajouter un commentaire…"
            rows={2}
            className="flex-1 px-3 py-2 bg-white dark:bg-[var(--afm-surface)] border border-slate-200 dark:border-[var(--afm-border)] rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-[#0089D0]/30 focus:border-[#0089D0]"
          />
          <button
            type="submit"
            disabled={!contenu.trim() || submitting}
            className="px-3 py-2 rounded-md bg-[#0089D0] hover:bg-[#052A62] text-white text-sm font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-1.5"
          >
            <Send size={14} />
            {submitting ? "…" : "Publier"}
          </button>
        </div>
      </form>

      {loading && <div className="text-sm text-slate-400 dark:text-slate-500 text-center py-4">Chargement…</div>}

      {!loading && comments.length === 0 && (
        <div className="flex flex-col items-center justify-center py-8 text-slate-400 dark:text-slate-500">
          <MessageSquare size={28} className="mb-2 opacity-40" />
          <p className="text-sm">Aucun commentaire pour le moment.</p>
        </div>
      )}

      {!loading && groups.length > 0 && (
        <div className="space-y-5">
          {groups.map((g) => (
            <div key={g.periode ?? "none"}>
              <div className="flex items-center gap-2 mb-2 pb-1.5 border-b border-slate-100 dark:border-[var(--afm-border)]/60">
                <CalendarDays size={13} className="text-[#0089D0]" />
                <span
                  className="text-xs font-semibold text-[#0089D0] uppercase tracking-wider"
                  style={{ fontFamily: "var(--font-poppins)" }}
                >
                  {g.periode ? <PeriodeLabel periode={g.periode} /> : "Non daté"}
                </span>
                <span className="text-xs text-slate-400 dark:text-slate-500">· {g.items.length}</span>
              </div>
              <div className="space-y-3">
                {g.items.map((c) => (
                  <div key={c.id} className="flex gap-3">
                    <div className="w-8 h-8 rounded-full bg-[#86B4DD]/30 text-[#052A62] flex items-center justify-center text-xs font-semibold flex-shrink-0">
                      {initiales(c.auteurNom.split(" ")[0] ?? "", c.auteurNom.split(" ")[1] ?? "")}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-baseline gap-2 mb-0.5">
                        <span className="text-sm font-medium text-slate-900 dark:text-[var(--afm-text)]">{c.auteurNom}</span>
                        <span className="text-xs text-slate-400 dark:text-slate-500">{formatDateTime(c.createdAt)}</span>
                      </div>
                      <p className="text-sm text-slate-700 dark:text-[var(--afm-text)]/85 whitespace-pre-wrap">{c.contenu}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
