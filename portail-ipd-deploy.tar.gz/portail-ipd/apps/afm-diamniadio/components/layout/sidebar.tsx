"use client";

import Link from "next/link";
import Image from "next/image";
import { usePathname } from "next/navigation";
import {
  LayoutDashboard, Wallet, Factory, ShieldCheck, AlertTriangle,
  TrendingUp, Settings, Dot, Target,
} from "lucide-react";
import { cn } from "@/lib/utils";

type NavItem = {
  label: string;
  href: string;
  icon: typeof LayoutDashboard;
  children?: { label: string; href: string }[];
};

const nav: NavItem[] = [
  { label: "Tableau de bord", href: "/app/dashboard", icon: LayoutDashboard },
  { label: "OGSM — Stratégie", href: "/app/ogsm", icon: Target },
  {
    label: "Pilotage Financier",
    href: "/app/financier",
    icon: Wallet,
    children: [
      { label: "Vue d'ensemble", href: "/app/financier" },
      { label: "Levées de fonds", href: "/app/financier/levees" },
      { label: "Budget CAPEX / OPEX", href: "/app/financier/budgets" },
    ],
  },
  {
    label: "Excellence Industrielle",
    href: "/app/industriel",
    icon: Factory,
    children: [
      { label: "Vue d'ensemble", href: "/app/industriel" },
      { label: "Qualifications IQ/OQ/PQ", href: "/app/industriel/qualifications" },
      { label: "Documentation SOP", href: "/app/industriel/sop" },
      { label: "Équipements critiques", href: "/app/industriel/equipements" },
    ],
  },
  {
    label: "Conformité",
    href: "/app/conformite",
    icon: ShieldCheck,
    children: [
      { label: "Vue d'ensemble", href: "/app/conformite" },
      { label: "Jalons OMS/ARP", href: "/app/conformite/jalons" },
      { label: "Écarts & déviations", href: "/app/conformite/ecarts" },
      { label: "Audits", href: "/app/conformite/audits" },
    ],
  },
  {
    label: "Gestion des Risques",
    href: "/app/risques",
    icon: AlertTriangle,
    children: [
      { label: "Vue d'ensemble", href: "/app/risques" },
      { label: "Contamination", href: "/app/risques/contamination" },
      { label: "Énergie (Senelec)", href: "/app/risques/energie" },
      { label: "Supply (Biomanguinhos)", href: "/app/risques/supply" },
    ],
  },
  {
    label: "Performance Production",
    href: "/app/production",
    icon: TrendingUp,
    children: [
      { label: "Vue d'ensemble", href: "/app/production" },
      { label: "Volumes 2027/2028/2029", href: "/app/production/volumes" },
      { label: "OEE", href: "/app/production/oee" },
      { label: "Rendements", href: "/app/production/rendements" },
    ],
  },
  { label: "Administration", href: "/app/admin", icon: Settings },
];

export function Sidebar() {
  const pathname = usePathname();

  return (
    <aside className="w-64 bg-white dark:bg-[var(--afm-surface)] border-r border-slate-200 dark:border-[var(--afm-border)] h-screen sticky top-0 flex flex-col">
      {/* Header — logo IPD + nom de projet AFM (charte §15) */}
      <div className="p-4 border-b border-slate-200 dark:border-[var(--afm-border)]">
        <Link href="/app/dashboard" className="flex items-center gap-3">
          <Image
            src="/logo-ipd.png"
            alt="Institut Pasteur de Dakar"
            width={160}
            height={68}
            priority
            className="h-12 w-auto object-contain"
          />
        </Link>
        <div className="mt-3 pt-3 border-t border-[#0089D0]/30">
          <div className="text-[11px] uppercase tracking-wider text-slate-500 font-medium">
            Projet
          </div>
          <div className="text-sm font-bold text-[#0089D0] leading-tight" style={{ fontFamily: "var(--font-poppins)" }}>
            AFM Diamniadio
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5">Vaccinopole — fièvre jaune</div>
        </div>
      </div>

      <nav className="flex-1 overflow-y-auto p-3 space-y-1">
        {nav.map((item) => {
          const Icon = item.icon;
          const active =
            pathname === item.href ||
            (item.href !== "/app/dashboard" && pathname.startsWith(item.href));
          const showChildren = active && item.children;
          return (
            <div key={item.href}>
              <Link
                href={item.href}
                className={cn(
                  "flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-colors",
                  active
                    ? "bg-sky-50 dark:bg-[#0089D0]/15 text-[#0089D0] font-medium"
                    : "text-slate-700 dark:text-[var(--afm-text)]/85 hover:bg-slate-100 dark:hover:bg-[var(--afm-border)]/40"
                )}
              >
                <Icon size={17} className={active ? "text-[#0089D0]" : "text-slate-500 dark:text-[var(--afm-text-muted)]"} />
                <span>{item.label}</span>
              </Link>
              {showChildren && (
                <div className="ml-6 mt-1 mb-2 space-y-0.5">
                  {item.children!.map((c) => {
                    const cActive = pathname === c.href;
                    return (
                      <Link
                        key={c.href}
                        href={c.href}
                        className={cn(
                          "flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs transition-colors",
                          cActive
                            ? "text-[#0089D0] font-medium"
                            : "text-slate-600 hover:text-slate-900"
                        )}
                      >
                        <Dot size={14} className={cActive ? "text-[#0089D0]" : "text-slate-400"} />
                        {c.label}
                      </Link>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
      </nav>

      <div className="p-4 border-t border-slate-200 dark:border-[var(--afm-border)] text-xs text-slate-500 dark:text-[var(--afm-text-muted)]">
        <div className="font-medium text-slate-700 dark:text-[var(--afm-text)]">Objectif GMP 2027</div>
        <div>3 M doses · 20 M$</div>
      </div>
    </aside>
  );
}
