import Link from "next/link";
import { LogOut } from "lucide-react";
import { initiales } from "@/lib/utils";
import { ROLE_LABELS } from "@/lib/rbac";
import { ThemeToggle } from "@/components/ui/theme-toggle";

export function Topbar(props: {
  prenom: string;
  nom: string;
  email: string;
  role: string;
}) {
  const { prenom, nom, email, role } = props;
  return (
    <header className="h-16 bg-white dark:bg-[var(--afm-surface)] border-b border-slate-200 dark:border-[var(--afm-border)] px-6 flex items-center justify-between sticky top-0 z-10">
      <div>
        <div className="text-xs text-slate-500 dark:text-[var(--afm-text-muted)]">
          Vaccinopole de Diamniadio · Sénégal
        </div>
        <div className="text-sm font-medium text-slate-900 dark:text-[var(--afm-text)]">
          Production GMP fièvre jaune — cap 2027
        </div>
      </div>

      <div className="flex items-center gap-4">
        <ThemeToggle />

        <div className="text-right">
          <div className="text-sm font-medium text-slate-900 dark:text-[var(--afm-text)]">
            {prenom} {nom}
          </div>
          <div className="text-xs text-slate-500 dark:text-[var(--afm-text-muted)]">
            {ROLE_LABELS[role] ?? role} · {email}
          </div>
        </div>
        <div className="w-10 h-10 rounded-full bg-sky-100 dark:bg-[#0089D0]/20 text-[#0089D0] flex items-center justify-center font-semibold text-sm">
          {initiales(prenom, nom)}
        </div>
        <Link
          href="/api/auth/logout"
          className="p-2 rounded-lg text-slate-500 dark:text-[var(--afm-text-muted)] hover:bg-slate-100 dark:hover:bg-[var(--afm-border)]/40 hover:text-slate-700 dark:hover:text-[var(--afm-text)] transition-colors"
          aria-label="Déconnexion"
        >
          <LogOut size={18} />
        </Link>
      </div>
    </header>
  );
}
