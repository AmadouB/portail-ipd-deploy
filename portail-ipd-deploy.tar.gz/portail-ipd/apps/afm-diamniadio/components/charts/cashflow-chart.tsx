"use client";

import {
  Area, AreaChart, CartesianGrid, LabelList, ResponsiveContainer,
  Tooltip, XAxis, YAxis,
} from "recharts";

type Point = { month: string; position: number; entrees: number; sorties: number };

export function CashflowChart({ data }: { data: Point[] }) {
  return (
    <div className="h-72 w-full chart-themed">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data} margin={{ top: 24, right: 12, left: 8, bottom: 0 }}>
          <defs>
            <linearGradient id="gPos" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#0089D0" stopOpacity={0.35} />
              <stop offset="100%" stopColor="#0089D0" stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid stroke="currentColor" strokeOpacity={0.15} strokeDasharray="3 3" vertical={false} />
          <XAxis
            dataKey="month"
            tick={{ fontSize: 12, fontWeight: 500, fill: "currentColor" }}
            tickLine={false}
            axisLine={false}
          />
          <YAxis
            tick={{ fontSize: 12, fontWeight: 500, fill: "currentColor" }}
            tickLine={false}
            axisLine={false}
            tickFormatter={(v) => `${(Number(v) / 1_000_000).toFixed(1)} M€`}
            width={60}
          />
          <Tooltip
            formatter={(v) => `${Number(v).toLocaleString("fr-FR")} €`}
            labelStyle={{ fontSize: 12, fontWeight: 500 }}
            contentStyle={{ fontSize: 12, borderRadius: 8, border: "1px solid #e2e8f0" }}
          />
          <Area
            type="monotone"
            dataKey="position"
            stroke="#0089D0"
            strokeWidth={2.5}
            fill="url(#gPos)"
            name="Position trésorerie"
            dot={{ r: 3, fill: "#0089D0" }}
          >
            <LabelList
              dataKey="position"
              position="top"
              formatter={(v) => `${(Number(v ?? 0) / 1_000_000).toFixed(1)} M€`}
              style={{ fontSize: 10, fontWeight: 600, fill: "#0089D0" }}
            />
          </Area>
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}
