import { Fragment } from "react";
import { cn } from "@/lib/utils";

type Risk = {
  id: string;
  code: string;
  libelle: string;
  probabilite: number;
  impact: number;
  score: number;
};

function bgColor(prob: number, impact: number): string {
  const score = prob * impact;
  if (score >= 15) return "bg-red-200";
  if (score >= 10) return "bg-orange-200";
  if (score >= 6) return "bg-amber-100";
  if (score >= 3) return "bg-lime-100";
  return "bg-green-100";
}

export function RiskHeatmap({ risks }: { risks: Risk[] }) {
  const cells: Record<string, Risk[]> = {};
  for (const r of risks) {
    const key = `${r.probabilite}-${r.impact}`;
    (cells[key] ||= []).push(r);
  }

  return (
    <div>
      <div className="grid grid-cols-[auto_repeat(5,1fr)] gap-1">
        <div />
        {[1, 2, 3, 4, 5].map((p) => (
          <div key={`col-${p}`} className="text-xs text-slate-500 text-center font-mono">
            P {p}
          </div>
        ))}
        {[5, 4, 3, 2, 1].map((impact) => (
          <Fragment key={`row-${impact}`}>
            <div className="text-xs text-slate-500 text-right pr-2 font-mono flex items-center justify-end">
              I {impact}
            </div>
            {[1, 2, 3, 4, 5].map((prob) => {
              const inCell = cells[`${prob}-${impact}`] ?? [];
              return (
                <div
                  key={`cell-${prob}-${impact}`}
                  className={cn(
                    "min-h-[72px] rounded border border-slate-200 p-1.5 flex flex-col gap-0.5",
                    bgColor(prob, impact)
                  )}
                  title={inCell.map((r) => r.libelle).join("\n")}
                >
                  {inCell.slice(0, 3).map((r) => (
                    <div
                      key={r.id}
                      className="text-[10px] font-medium text-slate-800 bg-white/80 rounded px-1 py-0.5 truncate"
                    >
                      {r.code}
                    </div>
                  ))}
                  {inCell.length > 3 && (
                    <div className="text-[10px] text-slate-700 px-1">+{inCell.length - 3}</div>
                  )}
                </div>
              );
            })}
          </Fragment>
        ))}
      </div>
      <div className="text-xs text-slate-500 text-center mt-3">
        Probabilité (P) × Impact (I) — score 1 à 25
      </div>
    </div>
  );
}
