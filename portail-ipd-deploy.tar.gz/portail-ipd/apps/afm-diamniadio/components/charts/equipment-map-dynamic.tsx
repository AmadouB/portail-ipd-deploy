"use client";

import dynamic from "next/dynamic";

export const EquipmentMapDynamic = dynamic(
  () => import("./equipment-map").then((m) => m.EquipmentMap),
  { ssr: false, loading: () => <div className="h-96 w-full bg-slate-100 rounded-xl animate-pulse" /> }
);
