import { cn } from "@/lib/utils";

export function OEEGauge({
  label,
  value,
  size = 120,
}: {
  label: string;
  value: number;
  size?: number;
}) {
  const pct = Math.max(0, Math.min(100, value));
  const radius = (size - 16) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference * (1 - pct / 100);

  const tone =
    pct >= 85 ? "#16a34a" : pct >= 70 ? "#0089D0" : pct >= 50 ? "#ea580c" : "#dc2626";

  return (
    <div className="flex flex-col items-center">
      <div className="relative" style={{ width: size, height: size }}>
        <svg width={size} height={size} className="-rotate-90">
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="none"
            stroke="#e2e8f0"
            strokeWidth="10"
          />
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="none"
            stroke={tone}
            strokeWidth="10"
            strokeDasharray={circumference}
            strokeDashoffset={offset}
            strokeLinecap="round"
            className="transition-all"
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="text-2xl font-bold tabular-nums" style={{ color: tone }}>
            {pct.toFixed(0)}
          </span>
          <span className="text-[10px] text-slate-500 uppercase tracking-wider">%</span>
        </div>
      </div>
      <div className={cn("text-xs text-slate-600 mt-2 font-medium")}>{label}</div>
    </div>
  );
}
