"use client";

import {
  Line, LineChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis, ReferenceLine,
} from "recharts";

type Point = { date: string; valeur: number; zone: string };

const zoneColors: Record<string, string> = {
  "Zone A — Remplissage": "#0089D0",
  "Zone B — Stérilisation": "#052A62",
  "Zone C — Utilités": "#86B4DD",
};

export function EnvChart({
  data,
  unite,
  seuilMin,
  seuilMax,
}: {
  data: Point[];
  unite: string;
  seuilMin?: number;
  seuilMax?: number;
}) {
  // Pivote : date + valeur par zone
  const dates = [...new Set(data.map((d) => d.date))].sort();
  const zones = [...new Set(data.map((d) => d.zone))];
  const chartData = dates.map((date) => {
    const row: Record<string, number | string> = { date };
    for (const z of zones) {
      const p = data.find((d) => d.date === date && d.zone === z);
      if (p) row[z] = p.valeur;
    }
    return row;
  });

  return (
    <div className="h-72 w-full chart-themed">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={chartData} margin={{ top: 16, right: 12, left: 8, bottom: 0 }}>
          <CartesianGrid stroke="currentColor" strokeOpacity={0.15} strokeDasharray="3 3" vertical={false} />
          <XAxis
            dataKey="date"
            tick={{ fontSize: 12, fontWeight: 500, fill: "currentColor" }}
            tickLine={false}
            axisLine={false}
            interval="preserveStartEnd"
          />
          <YAxis
            tick={{ fontSize: 12, fontWeight: 500, fill: "currentColor" }}
            tickLine={false}
            axisLine={false}
            tickFormatter={(v) => `${String(v)} ${unite}`}
            width={60}
          />
          <Tooltip
            formatter={(v) => `${String(v)} ${unite}`}
            contentStyle={{ fontSize: 12, borderRadius: 8, border: "1px solid #e2e8f0" }}
          />
          <Legend wrapperStyle={{ fontSize: 11, fontWeight: 500, paddingTop: 4 }} iconSize={10} />
          {seuilMin !== undefined && (
            <ReferenceLine
              y={seuilMin}
              stroke="#dc2626"
              strokeDasharray="4 4"
              label={{ value: `min ${seuilMin}`, fontSize: 11, fontWeight: 600, fill: "#dc2626", position: "insideBottomLeft" }}
            />
          )}
          {seuilMax !== undefined && (
            <ReferenceLine
              y={seuilMax}
              stroke="#dc2626"
              strokeDasharray="4 4"
              label={{ value: `max ${seuilMax}`, fontSize: 11, fontWeight: 600, fill: "#dc2626", position: "insideTopLeft" }}
            />
          )}
          {zones.map((z) => (
            <Line
              key={z}
              type="monotone"
              dataKey={z}
              stroke={zoneColors[z] ?? "#64748b"}
              strokeWidth={2.5}
              dot={false}
              activeDot={{ r: 5 }}
              name={z}
            />
          ))}
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
