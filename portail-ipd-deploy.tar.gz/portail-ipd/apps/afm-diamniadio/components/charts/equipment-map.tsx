"use client";

import { MapContainer, TileLayer, CircleMarker, Popup, Tooltip } from "react-leaflet";
import "leaflet/dist/leaflet.css";

type Equipement = {
  id: string;
  code: string;
  libelle: string;
  zone: string;
  lat: number | null;
  lng: number | null;
  statut: string;
  criticite: string;
};

const color = (statut: string): string => {
  switch (statut) {
    case "OPERATIONNEL":
      return "#16a34a";
    case "MAINTENANCE":
      return "#ea580c";
    case "HS":
      return "#dc2626";
    case "INSTALLATION":
      return "#0ea5e9";
    default:
      return "#64748b";
  }
};

export function EquipmentMap({ equipements }: { equipements: Equipement[] }) {
  const withCoords = equipements.filter(
    (e): e is Equipement & { lat: number; lng: number } => e.lat !== null && e.lng !== null
  );
  const center: [number, number] = withCoords.length
    ? [withCoords[0].lat, withCoords[0].lng]
    : [14.7203, -17.2218];

  return (
    <div className="h-96 w-full">
      <MapContainer center={center} zoom={18} scrollWheelZoom={false}>
        <TileLayer
          attribution='&copy; OpenStreetMap'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        {withCoords.map((eq) => (
          <CircleMarker
            key={eq.id}
            center={[eq.lat, eq.lng]}
            radius={10}
            pathOptions={{
              color: color(eq.statut),
              fillColor: color(eq.statut),
              fillOpacity: 0.7,
              weight: 2,
            }}
          >
            <Tooltip>{eq.libelle}</Tooltip>
            <Popup>
              <div className="text-sm">
                <div className="font-semibold">{eq.libelle}</div>
                <div className="text-xs text-slate-600 mt-0.5">{eq.code}</div>
                <div className="text-xs mt-1">
                  <span className="text-slate-500">Zone :</span> {eq.zone}
                </div>
                <div className="text-xs">
                  <span className="text-slate-500">Statut :</span> {eq.statut}
                </div>
                <div className="text-xs">
                  <span className="text-slate-500">Criticité :</span> {eq.criticite}
                </div>
              </div>
            </Popup>
          </CircleMarker>
        ))}
      </MapContainer>
    </div>
  );
}
