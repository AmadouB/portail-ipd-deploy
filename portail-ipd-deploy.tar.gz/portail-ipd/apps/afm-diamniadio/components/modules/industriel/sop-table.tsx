"use client";

import { useState } from "react";
import { Pencil, MessageSquare } from "lucide-react";
import { Table, Thead, Tbody, Tr, Th, Td } from "@/components/ui/table";
import { Badge, statutVariant } from "@/components/ui/badge";
import { StatusEditModal } from "@/components/modals/status-edit-modal";
import { formatDate } from "@/lib/utils";

type SOP = {
  id: string;
  code: string;
  titre: string;
  version: string;
  statut: string;
  dateRevision: Date | string | null;
  dateProchainRevision: Date | string | null;
  approbateur: string | null;
  categorie: string | null;
  commentCount?: number;
};

const STATUT_OPTIONS = [
  { value: "BROUILLON", label: "Brouillon" },
  { value: "EN_REVUE", label: "En revue" },
  { value: "VALIDE", label: "Validé" },
  { value: "OBSOLETE", label: "Obsolète" },
];

export function SopTable({
  sops,
  defaultPeriode,
}: {
  sops: SOP[];
  defaultPeriode: string;
}) {
  const [editing, setEditing] = useState<SOP | null>(null);
  const now = Date.now();

  return (
    <>
      <Table>
        <Thead>
          <Tr>
            <Th>Code</Th>
            <Th>Titre</Th>
            <Th>Catégorie</Th>
            <Th>Version</Th>
            <Th>Dernière révision</Th>
            <Th>Prochaine révision</Th>
            <Th>Approbateur</Th>
            <Th>Statut</Th>
            <Th></Th>
          </Tr>
        </Thead>
        <Tbody>
          {sops.map((s) => {
            const echue =
              s.dateProchainRevision && new Date(s.dateProchainRevision).getTime() < now;
            return (
              <Tr key={s.id}>
                <Td className="font-mono text-xs">{s.code}</Td>
                <Td className="font-medium text-slate-900">{s.titre}</Td>
                <Td className="text-xs">{s.categorie ?? "—"}</Td>
                <Td className="tabular-nums">v{s.version}</Td>
                <Td className="text-xs">{formatDate(s.dateRevision)}</Td>
                <Td className={echue ? "text-red-700 text-xs font-medium" : "text-xs"}>
                  {formatDate(s.dateProchainRevision)}
                  {echue && " ⚠"}
                </Td>
                <Td className="text-xs">{s.approbateur ?? "—"}</Td>
                <Td>
                  <Badge variant={statutVariant(s.statut)}>{s.statut}</Badge>
                </Td>
                <Td>
                  <button
                    onClick={() => setEditing(s)}
                    className="inline-flex items-center gap-1 px-2 py-1 rounded-md text-xs text-[#0089D0] hover:bg-sky-50 font-medium transition-colors"
                  >
                    <Pencil size={12} />
                    <span>Modifier</span>
                    {s.commentCount ? (
                      <span className="ml-1 inline-flex items-center gap-0.5 text-[10px] text-slate-500">
                        <MessageSquare size={10} />
                        {s.commentCount}
                      </span>
                    ) : null}
                  </button>
                </Td>
              </Tr>
            );
          })}
        </Tbody>
      </Table>

      {editing && (
        <StatusEditModal
          open={!!editing}
          onClose={() => setEditing(null)}
          entityType="sop"
          entityId={editing.id}
          title={editing.titre}
          description={`${editing.code} · v${editing.version} · ${editing.categorie ?? "—"}`}
          currentStatus={editing.statut}
          defaultPeriode={defaultPeriode}
          fields={[
            {
              name: "statut",
              label: "Statut SOP",
              type: "select",
              options: STATUT_OPTIONS,
              defaultValue: editing.statut,
            },
            {
              name: "version",
              label: "Version",
              type: "text",
              defaultValue: editing.version,
            },
            {
              name: "approbateur",
              label: "Approbateur",
              type: "text",
              defaultValue: editing.approbateur ?? "",
            },
          ]}
        />
      )}
    </>
  );
}
