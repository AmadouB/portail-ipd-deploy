"use client";

import { useState } from "react";
import { Pencil, MessageSquare } from "lucide-react";
import { Table, Thead, Tbody, Tr, Th, Td } from "@/components/ui/table";
import { Badge, statutVariant } from "@/components/ui/badge";
import { StatusEditModal } from "@/components/modals/status-edit-modal";
import { formatDate } from "@/lib/utils";

type Equipment = {
  id: string;
  code: string;
  libelle: string;
  type: string;
  zone: string;
  dateInstallation: Date | string | null;
  statut: string;
  criticite: string;
  notes: string | null;
  commentCount?: number;
};

const STATUT_OPTIONS = [
  { value: "OPERATIONNEL", label: "Opérationnel" },
  { value: "MAINTENANCE", label: "Maintenance" },
  { value: "INSTALLATION", label: "Installation" },
  { value: "HS", label: "Hors service" },
];

export function EquipmentsTable({
  equipements,
  defaultPeriode,
}: {
  equipements: Equipment[];
  defaultPeriode: string;
}) {
  const [editing, setEditing] = useState<Equipment | null>(null);

  return (
    <>
      <Table>
        <Thead>
          <Tr>
            <Th>Code</Th>
            <Th>Libellé</Th>
            <Th>Type</Th>
            <Th>Zone</Th>
            <Th>Installation</Th>
            <Th>Criticité</Th>
            <Th>Statut</Th>
            <Th></Th>
          </Tr>
        </Thead>
        <Tbody>
          {equipements.map((eq) => (
            <Tr key={eq.id}>
              <Td className="font-mono text-xs">{eq.code}</Td>
              <Td className="font-medium text-slate-900">{eq.libelle}</Td>
              <Td className="text-xs">{eq.type}</Td>
              <Td className="text-xs">{eq.zone}</Td>
              <Td className="text-xs">{formatDate(eq.dateInstallation)}</Td>
              <Td>
                <Badge
                  variant={
                    eq.criticite === "CRITIQUE"
                      ? "critical"
                      : eq.criticite === "IMPORTANTE"
                      ? "warning"
                      : "neutral"
                  }
                >
                  {eq.criticite}
                </Badge>
              </Td>
              <Td>
                <Badge variant={statutVariant(eq.statut)}>{eq.statut}</Badge>
              </Td>
              <Td>
                <button
                  onClick={() => setEditing(eq)}
                  className="inline-flex items-center gap-1 px-2 py-1 rounded-md text-xs text-[#0089D0] hover:bg-sky-50 font-medium transition-colors"
                >
                  <Pencil size={12} />
                  <span>Modifier</span>
                  {eq.commentCount ? (
                    <span className="ml-1 inline-flex items-center gap-0.5 text-[10px] text-slate-500">
                      <MessageSquare size={10} />
                      {eq.commentCount}
                    </span>
                  ) : null}
                </button>
              </Td>
            </Tr>
          ))}
        </Tbody>
      </Table>

      {editing && (
        <StatusEditModal
          open={!!editing}
          onClose={() => setEditing(null)}
          entityType="equipment"
          entityId={editing.id}
          title={editing.libelle}
          description={`${editing.code} · ${editing.type} · ${editing.zone}`}
          currentStatus={editing.statut}
          defaultPeriode={defaultPeriode}
          fields={[
            {
              name: "statut",
              label: "Statut opérationnel",
              type: "select",
              options: STATUT_OPTIONS,
              defaultValue: editing.statut,
            },
            {
              name: "notes",
              label: "Notes techniques",
              type: "textarea",
              defaultValue: editing.notes ?? "",
            },
          ]}
        />
      )}
    </>
  );
}
