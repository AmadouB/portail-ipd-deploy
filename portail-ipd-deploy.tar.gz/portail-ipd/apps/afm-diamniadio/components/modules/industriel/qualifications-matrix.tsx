"use client";

import { useState } from "react";
import { MessageSquare } from "lucide-react";
import { Table, Thead, Tbody, Tr, Th, Td } from "@/components/ui/table";
import { Badge, statutVariant } from "@/components/ui/badge";
import { StatusEditModal } from "@/components/modals/status-edit-modal";
import { formatDate } from "@/lib/utils";

type Qualification = {
  id: string;
  equipmentId: string;
  phase: string;
  statut: string;
  datePrevue: Date | string;
  dateRealisee: Date | string | null;
  operateur: string | null;
  rapport: string | null;
  commentCount?: number;
};

type Equipment = {
  id: string;
  code: string;
  libelle: string;
  zone: string;
  criticite: string;
  qualifications: Qualification[];
};

const PHASES = ["IQ", "OQ", "PQ"] as const;

const STATUT_OPTIONS = [
  { value: "A_FAIRE", label: "À faire" },
  { value: "EN_COURS", label: "En cours" },
  { value: "FAIT", label: "Fait" },
  { value: "ECHEC", label: "Échec" },
];

export function QualificationsMatrix({
  equipements,
  defaultPeriode,
}: {
  equipements: Equipment[];
  defaultPeriode: string;
}) {
  const [editing, setEditing] = useState<{ qualif: Qualification; equipement: Equipment } | null>(
    null
  );

  return (
    <>
      <Table>
        <Thead>
          <Tr>
            <Th>Équipement</Th>
            <Th>Zone</Th>
            {PHASES.map((p) => (
              <Th key={p} className="text-center">
                {p}
              </Th>
            ))}
            <Th>Criticité</Th>
          </Tr>
        </Thead>
        <Tbody>
          {equipements.map((eq) => (
            <Tr key={eq.id}>
              <Td>
                <div className="font-medium text-slate-900">{eq.libelle}</div>
                <div className="text-xs text-slate-500 font-mono">{eq.code}</div>
              </Td>
              <Td className="text-xs">{eq.zone}</Td>
              {PHASES.map((p) => {
                const q = eq.qualifications.find((x) => x.phase === p);
                if (!q) return <Td key={p} className="text-center text-slate-300">—</Td>;
                return (
                  <Td key={p} className="text-center">
                    <button
                      onClick={() => setEditing({ qualif: q, equipement: eq })}
                      className="flex flex-col items-center gap-1 hover:bg-sky-50 rounded-md px-2 py-1 transition-colors w-full"
                      title="Cliquer pour modifier"
                    >
                      <Badge variant={statutVariant(q.statut)}>{q.statut}</Badge>
                      <div className="text-[10px] text-slate-500">
                        {q.dateRealisee
                          ? `fait ${formatDate(q.dateRealisee)}`
                          : `prévu ${formatDate(q.datePrevue)}`}
                      </div>
                      {q.commentCount ? (
                        <span className="inline-flex items-center gap-0.5 text-[10px] text-slate-500">
                          <MessageSquare size={9} />
                          {q.commentCount}
                        </span>
                      ) : null}
                    </button>
                  </Td>
                );
              })}
              <Td>
                <Badge
                  variant={
                    eq.criticite === "CRITIQUE"
                      ? "critical"
                      : eq.criticite === "IMPORTANTE"
                      ? "warning"
                      : "neutral"
                  }
                >
                  {eq.criticite}
                </Badge>
              </Td>
            </Tr>
          ))}
        </Tbody>
      </Table>

      {editing && (
        <StatusEditModal
          open={!!editing}
          onClose={() => setEditing(null)}
          entityType="qualification"
          entityId={editing.qualif.id}
          title={`Qualification ${editing.qualif.phase} — ${editing.equipement.libelle}`}
          description={`${editing.equipement.code} · ${editing.equipement.zone}`}
          currentStatus={editing.qualif.statut}
          defaultPeriode={defaultPeriode}
          fields={[
            {
              name: "statut",
              label: "Statut qualification",
              type: "select",
              options: STATUT_OPTIONS,
              defaultValue: editing.qualif.statut,
            },
            {
              name: "dateRealisee",
              label: "Date de réalisation",
              type: "date",
              defaultValue: editing.qualif.dateRealisee
                ? new Date(editing.qualif.dateRealisee).toISOString().slice(0, 10)
                : "",
            },
            {
              name: "operateur",
              label: "Opérateur / équipe",
              type: "text",
              defaultValue: editing.qualif.operateur ?? "",
            },
            {
              name: "rapport",
              label: "Référence rapport",
              type: "text",
              defaultValue: editing.qualif.rapport ?? "",
            },
          ]}
        />
      )}
    </>
  );
}
