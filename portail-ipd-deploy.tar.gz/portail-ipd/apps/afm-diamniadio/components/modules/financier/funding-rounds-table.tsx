"use client";

import { useState } from "react";
import { Pencil, MessageSquare } from "lucide-react";
import { Table, Thead, Tbody, Tr, Th, Td } from "@/components/ui/table";
import { Badge, statutVariant } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { StatusEditModal } from "@/components/modals/status-edit-modal";
import { formatEur, formatDate } from "@/lib/utils";

type Round = {
  id: string;
  code: string;
  libelle: string;
  source: string | null;
  montantCibleEur: number;
  montantLeveEur: number;
  dateCible: Date | string;
  dateRealisee: Date | string | null;
  statut: string;
  notes: string | null;
  commentCount?: number;
};

const STATUT_OPTIONS = [
  { value: "CIBLE", label: "Cible" },
  { value: "EN_COURS", label: "En cours" },
  { value: "ATTEINT", label: "Atteint" },
  { value: "RETARD", label: "En retard" },
];

export function FundingRoundsTable({
  rounds,
  defaultPeriode,
}: {
  rounds: Round[];
  defaultPeriode: string;
}) {
  const [editing, setEditing] = useState<Round | null>(null);

  return (
    <>
      <Table>
        <Thead>
          <Tr>
            <Th>Code</Th>
            <Th>Libellé</Th>
            <Th>Source</Th>
            <Th className="text-right">Cible</Th>
            <Th className="text-right">Levé</Th>
            <Th>Avancement</Th>
            <Th>Date cible</Th>
            <Th>Statut</Th>
            <Th></Th>
          </Tr>
        </Thead>
        <Tbody>
          {rounds.map((r) => {
            const pct = Math.round((r.montantLeveEur / r.montantCibleEur) * 100);
            return (
              <Tr key={r.id}>
                <Td className="font-mono text-xs">{r.code}</Td>
                <Td>
                  <div className="font-medium text-slate-900">{r.libelle}</div>
                  {r.notes && <div className="text-xs text-slate-500 mt-0.5">{r.notes}</div>}
                </Td>
                <Td className="text-xs">{r.source ?? "—"}</Td>
                <Td className="text-right tabular-nums">{formatEur(r.montantCibleEur)}</Td>
                <Td className="text-right tabular-nums font-medium">
                  {formatEur(r.montantLeveEur)}
                </Td>
                <Td className="w-40">
                  <div className="flex items-center gap-2">
                    <Progress value={pct} tone={pct >= 100 ? "success" : "primary"} />
                    <span className="text-xs text-slate-500 tabular-nums w-10 text-right">
                      {pct}%
                    </span>
                  </div>
                </Td>
                <Td>{formatDate(r.dateCible)}</Td>
                <Td>
                  <Badge variant={statutVariant(r.statut)}>{r.statut}</Badge>
                </Td>
                <Td>
                  <button
                    onClick={() => setEditing(r)}
                    className="inline-flex items-center gap-1 px-2 py-1 rounded-md text-xs text-[#0089D0] hover:bg-sky-50 font-medium transition-colors"
                  >
                    <Pencil size={12} />
                    <span>Modifier</span>
                    {r.commentCount ? (
                      <span className="ml-1 inline-flex items-center gap-0.5 text-[10px] text-slate-500">
                        <MessageSquare size={10} />
                        {r.commentCount}
                      </span>
                    ) : null}
                  </button>
                </Td>
              </Tr>
            );
          })}
        </Tbody>
      </Table>

      {editing && (
        <StatusEditModal
          open={!!editing}
          onClose={() => setEditing(null)}
          entityType="funding_round"
          entityId={editing.id}
          title={editing.libelle}
          description={`${editing.code} · Cible ${formatEur(editing.montantCibleEur)}`}
          currentStatus={editing.statut}
          defaultPeriode={defaultPeriode}
          fields={[
            {
              name: "statut",
              label: "Statut",
              type: "select",
              options: STATUT_OPTIONS,
              defaultValue: editing.statut,
            },
            {
              name: "montantLeveEur",
              label: "Montant levé",
              type: "number",
              defaultValue: editing.montantLeveEur,
              suffix: "€",
              min: 0,
            },
            {
              name: "dateRealisee",
              label: "Date de clôture",
              type: "date",
              defaultValue: editing.dateRealisee
                ? new Date(editing.dateRealisee).toISOString().slice(0, 10)
                : "",
            },
            {
              name: "notes",
              label: "Notes",
              type: "textarea",
              defaultValue: editing.notes ?? "",
            },
          ]}
        />
      )}
    </>
  );
}
