"use client";

import { useState } from "react";
import { Pencil, MessageSquare } from "lucide-react";
import { Table, Thead, Tbody, Tr, Th, Td } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { StatusEditModal } from "@/components/modals/status-edit-modal";
import { formatEur } from "@/lib/utils";

type BudgetLine = {
  id: string;
  categorie: string;
  poste: string;
  budgetEur: number;
  consommeEur: number;
  periode: string;
  alerteDepassement: boolean;
  notes: string | null;
  commentCount?: number;
};

const ALERT_OPTIONS = [
  { value: "false", label: "OK — sous budget" },
  { value: "true", label: "Dépassement signalé" },
];

export function BudgetsTable({
  rows,
  defaultPeriode,
}: {
  rows: BudgetLine[];
  defaultPeriode: string;
}) {
  const [editing, setEditing] = useState<BudgetLine | null>(null);

  return (
    <>
      <Table>
        <Thead>
          <Tr>
            <Th>Poste</Th>
            <Th className="text-right">Budget</Th>
            <Th className="text-right">Consommé</Th>
            <Th className="w-44">Avancement</Th>
            <Th></Th>
          </Tr>
        </Thead>
        <Tbody>
          {rows.map((r) => {
            const pct = Math.min(100, Math.round((r.consommeEur / r.budgetEur) * 100));
            return (
              <Tr key={r.id}>
                <Td>
                  <div className="flex items-center gap-2">
                    <span className="text-slate-800">{r.poste}</span>
                    {r.alerteDepassement && <Badge variant="danger">Dépassement</Badge>}
                  </div>
                </Td>
                <Td className="text-right tabular-nums">{formatEur(r.budgetEur)}</Td>
                <Td className="text-right tabular-nums font-medium">
                  {formatEur(r.consommeEur)}
                </Td>
                <Td>
                  <div className="flex items-center gap-2">
                    <Progress
                      value={pct}
                      tone={r.alerteDepassement ? "danger" : pct > 80 ? "warning" : "primary"}
                    />
                    <span className="text-xs text-slate-500 tabular-nums w-10 text-right">
                      {pct}%
                    </span>
                  </div>
                </Td>
                <Td>
                  <button
                    onClick={() => setEditing(r)}
                    className="inline-flex items-center gap-1 px-2 py-1 rounded-md text-xs text-[#0089D0] hover:bg-sky-50 font-medium transition-colors"
                  >
                    <Pencil size={12} />
                    <span>Modifier</span>
                    {r.commentCount ? (
                      <span className="ml-1 inline-flex items-center gap-0.5 text-[10px] text-slate-500">
                        <MessageSquare size={10} />
                        {r.commentCount}
                      </span>
                    ) : null}
                  </button>
                </Td>
              </Tr>
            );
          })}
        </Tbody>
      </Table>

      {editing && (
        <StatusEditModal
          open={!!editing}
          onClose={() => setEditing(null)}
          entityType="budget_line"
          entityId={editing.id}
          title={editing.poste}
          description={`${editing.categorie} · période ${editing.periode}`}
          currentStatus={editing.alerteDepassement ? "DÉPASSEMENT" : "OK"}
          defaultPeriode={defaultPeriode}
          fields={[
            {
              name: "budgetEur",
              label: "Budget alloué",
              type: "number",
              defaultValue: editing.budgetEur,
              suffix: "€",
              min: 0,
            },
            {
              name: "consommeEur",
              label: "Consommé à ce jour",
              type: "number",
              defaultValue: editing.consommeEur,
              suffix: "€",
              min: 0,
            },
            {
              name: "alerteDepassement",
              label: "Alerte dépassement",
              type: "select",
              options: ALERT_OPTIONS,
              defaultValue: String(editing.alerteDepassement),
            },
            {
              name: "notes",
              label: "Notes",
              type: "textarea",
              defaultValue: editing.notes ?? "",
            },
          ]}
        />
      )}
    </>
  );
}
