"use client";

import { useState } from "react";
import { Pencil, MessageSquare } from "lucide-react";
import { Table, Thead, Tbody, Tr, Th, Td } from "@/components/ui/table";
import { Badge, statutVariant } from "@/components/ui/badge";
import { StatusEditModal } from "@/components/modals/status-edit-modal";
import { formatDate, formatDoses, formatPct } from "@/lib/utils";

type Batch = {
  id: string;
  numeroLot: string;
  dateProduction: Date | string;
  volumeDoses: number;
  statut: string;
  rendement: number | null;
  operateur: string | null;
  notes: string | null;
  commentCount?: number;
};

const STATUT_OPTIONS = [
  { value: "EN_COURS", label: "En cours" },
  { value: "CONFORME", label: "Conforme" },
  { value: "REJETE", label: "Rejeté" },
  { value: "REPRISE", label: "Reprise" },
];

export function BatchesTable({
  batches,
  defaultPeriode,
}: {
  batches: Batch[];
  defaultPeriode: string;
}) {
  const [editing, setEditing] = useState<Batch | null>(null);

  return (
    <>
      <Table>
        <Thead>
          <Tr>
            <Th>Lot</Th>
            <Th>Date</Th>
            <Th className="text-right">Volume</Th>
            <Th className="text-right">Rendement</Th>
            <Th>Opérateur</Th>
            <Th>Statut</Th>
            <Th></Th>
          </Tr>
        </Thead>
        <Tbody>
          {batches.map((b) => (
            <Tr key={b.id}>
              <Td className="font-mono text-xs">{b.numeroLot}</Td>
              <Td className="text-xs">{formatDate(b.dateProduction)}</Td>
              <Td className="text-right tabular-nums">
                {formatDoses(b.volumeDoses)} doses
              </Td>
              <Td className="text-right tabular-nums">
                {b.rendement ? formatPct(b.rendement, 1) : "—"}
              </Td>
              <Td className="text-xs">{b.operateur ?? "—"}</Td>
              <Td>
                <Badge variant={statutVariant(b.statut)}>{b.statut}</Badge>
              </Td>
              <Td>
                <button
                  onClick={() => setEditing(b)}
                  className="inline-flex items-center gap-1 px-2 py-1 rounded-md text-xs text-[#0089D0] hover:bg-sky-50 font-medium transition-colors"
                >
                  <Pencil size={12} />
                  <span>Modifier</span>
                  {b.commentCount ? (
                    <span className="ml-1 inline-flex items-center gap-0.5 text-[10px] text-slate-500">
                      <MessageSquare size={10} />
                      {b.commentCount}
                    </span>
                  ) : null}
                </button>
              </Td>
            </Tr>
          ))}
        </Tbody>
      </Table>

      {editing && (
        <StatusEditModal
          open={!!editing}
          onClose={() => setEditing(null)}
          entityType="production_batch"
          entityId={editing.id}
          title={`Lot ${editing.numeroLot}`}
          description={`${formatDoses(editing.volumeDoses)} doses · produit le ${formatDate(editing.dateProduction)}`}
          currentStatus={editing.statut}
          defaultPeriode={defaultPeriode}
          fields={[
            {
              name: "statut",
              label: "Statut lot",
              type: "select",
              options: STATUT_OPTIONS,
              defaultValue: editing.statut,
            },
            {
              name: "rendement",
              label: "Rendement",
              type: "number",
              defaultValue: editing.rendement ?? 0,
              suffix: "%",
              min: 0,
              max: 100,
            },
            {
              name: "notes",
              label: "Notes de libération / motif reprise",
              type: "textarea",
              defaultValue: editing.notes ?? "",
            },
          ]}
        />
      )}
    </>
  );
}
