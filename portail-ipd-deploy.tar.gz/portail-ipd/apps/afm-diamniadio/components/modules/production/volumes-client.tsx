"use client";

import { useState } from "react";
import { Pencil, MessageSquare } from "lucide-react";
import { Bar, BarChart, CartesianGrid, LabelList, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Card, CardBody, CardHeader, CardTitle } from "@/components/ui/card";
import { StatusEditModal } from "@/components/modals/status-edit-modal";

type Target = {
  id: string;
  annee: number;
  cibleDoses: number;
  realisDoses: number;
  revenusEurCible: number;
  revenusEurRealise: number;
  commentaire: string | null;
  commentCount?: number;
};

export function VolumesClient({
  targets,
  defaultPeriode,
}: {
  targets: Target[];
  defaultPeriode: string;
}) {
  const [editing, setEditing] = useState<Target | null>(null);

  const chartData = targets.map((t) => ({
    annee: t.annee.toString(),
    Cible: t.cibleDoses / 1_000_000,
    Réalisé: t.realisDoses / 1_000_000,
  }));

  return (
    <>
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Cible vs réalisé (millions de doses)</CardTitle>
        </CardHeader>
        <CardBody>
          <div className="h-80 chart-themed">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} margin={{ top: 24, right: 12, left: 0, bottom: 0 }}>
                <CartesianGrid stroke="currentColor" strokeOpacity={0.15} strokeDasharray="3 3" vertical={false} />
                <XAxis
                  dataKey="annee"
                  tick={{ fontSize: 13, fontWeight: 600, fill: "currentColor" }}
                  tickLine={false}
                  axisLine={false}
                />
                <YAxis
                  tick={{ fontSize: 12, fontWeight: 500, fill: "currentColor" }}
                  tickLine={false}
                  axisLine={false}
                  tickFormatter={(v) => `${String(v)} M`}
                  width={50}
                />
                <Tooltip
                  formatter={(v) => `${Number(v).toFixed(1)} M doses`}
                  contentStyle={{ fontSize: 12, borderRadius: 8, border: "1px solid #e2e8f0" }}
                />
                <Legend wrapperStyle={{ fontSize: 12, fontWeight: 500 }} />
                <Bar dataKey="Cible" fill="#cbd5e1" radius={[4, 4, 0, 0]}>
                  <LabelList
                    dataKey="Cible"
                    position="top"
                    formatter={(v) => `${Number(v ?? 0).toFixed(1)} M`}
                    style={{ fontSize: 11, fontWeight: 600, fill: "currentColor" }}
                  />
                </Bar>
                <Bar dataKey="Réalisé" fill="#0089D0" radius={[4, 4, 0, 0]}>
                  <LabelList
                    dataKey="Réalisé"
                    position="top"
                    formatter={(v) => (Number(v ?? 0) > 0 ? `${Number(v).toFixed(1)} M` : "")}
                    style={{ fontSize: 11, fontWeight: 700, fill: "#0089D0" }}
                  />
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardBody>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {targets.map((t) => (
          <Card key={t.id}>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>{t.annee}</CardTitle>
                <button
                  onClick={() => setEditing(t)}
                  className="inline-flex items-center gap-1 px-2 py-1 rounded-md text-xs text-[#0089D0] hover:bg-sky-50 font-medium transition-colors border border-[#0089D0]/20"
                >
                  <Pencil size={12} />
                  Modifier
                  {t.commentCount ? (
                    <span className="ml-1 inline-flex items-center gap-0.5 text-[10px] text-slate-500">
                      <MessageSquare size={10} />
                      {t.commentCount}
                    </span>
                  ) : null}
                </button>
              </div>
            </CardHeader>
            <CardBody>
              <div className="text-xs text-slate-500 uppercase tracking-wider mb-1">Doses cibles</div>
              <div className="text-2xl font-bold text-slate-900 tabular-nums">
                {(t.cibleDoses / 1_000_000).toFixed(0)} M
              </div>
              <div className="text-xs text-slate-500 mt-0.5">
                Réalisé : {(t.realisDoses / 1_000_000).toFixed(1)} M doses
              </div>
              <div className="text-xs text-slate-500 mt-2">
                Revenus cible : {(t.revenusEurCible / 1_000_000).toFixed(1)} M€ · Réalisé :{" "}
                {(t.revenusEurRealise / 1_000_000).toFixed(1)} M€
              </div>
              {t.commentaire && (
                <div className="text-xs text-slate-600 mt-3 italic">{t.commentaire}</div>
              )}
            </CardBody>
          </Card>
        ))}
      </div>

      {editing && (
        <StatusEditModal
          open={!!editing}
          onClose={() => setEditing(null)}
          entityType="production_target"
          entityId={editing.id}
          title={`Objectif de production ${editing.annee}`}
          description={`Cible OGSM — ${(editing.cibleDoses / 1_000_000).toFixed(1)} M doses`}
          defaultPeriode={defaultPeriode}
          fields={[
            {
              name: "cibleDoses",
              label: "Cible (doses)",
              type: "number",
              defaultValue: editing.cibleDoses,
              min: 0,
            },
            {
              name: "realisDoses",
              label: "Réalisé (doses)",
              type: "number",
              defaultValue: editing.realisDoses,
              min: 0,
            },
            {
              name: "revenusEurRealise",
              label: "Revenus réalisés (€)",
              type: "number",
              defaultValue: editing.revenusEurRealise,
              min: 0,
            },
            {
              name: "commentaire",
              label: "Commentaire OGSM",
              type: "textarea",
              defaultValue: editing.commentaire ?? "",
            },
          ]}
        />
      )}
    </>
  );
}
