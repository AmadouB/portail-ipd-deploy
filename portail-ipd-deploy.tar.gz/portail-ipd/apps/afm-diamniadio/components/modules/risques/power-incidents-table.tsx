"use client";

import { useState } from "react";
import { Pencil, MessageSquare } from "lucide-react";
import { Table, Thead, Tbody, Tr, Th, Td } from "@/components/ui/table";
import { Badge, statutVariant } from "@/components/ui/badge";
import { StatusEditModal } from "@/components/modals/status-edit-modal";
import { formatDateTime } from "@/lib/utils";

type Incident = {
  id: string;
  date: Date | string;
  dureeMin: number;
  source: string;
  impact: string;
  zones: string;
  notes: string | null;
  commentCount?: number;
};

const IMPACT_OPTIONS = [
  { value: "AUCUN", label: "Aucun" },
  { value: "MINEUR", label: "Mineur" },
  { value: "MAJEUR", label: "Majeur" },
  { value: "CRITIQUE", label: "Critique" },
];

export function PowerIncidentsTable({
  incidents,
  defaultPeriode,
}: {
  incidents: Incident[];
  defaultPeriode: string;
}) {
  const [editing, setEditing] = useState<Incident | null>(null);

  return (
    <>
      <Table>
        <Thead>
          <Tr>
            <Th>Date / heure</Th>
            <Th>Source</Th>
            <Th className="text-right">Durée (min)</Th>
            <Th>Zones impactées</Th>
            <Th>Impact</Th>
            <Th>Notes</Th>
            <Th></Th>
          </Tr>
        </Thead>
        <Tbody>
          {incidents.map((i) => (
            <Tr key={i.id}>
              <Td className="text-xs">{formatDateTime(i.date)}</Td>
              <Td>
                <Badge variant="neutral">{i.source}</Badge>
              </Td>
              <Td className="text-right tabular-nums font-medium">{i.dureeMin}</Td>
              <Td className="text-xs">{i.zones}</Td>
              <Td>
                <Badge variant={statutVariant(i.impact)}>{i.impact}</Badge>
              </Td>
              <Td className="text-xs text-slate-600 max-w-xs">{i.notes ?? "—"}</Td>
              <Td>
                <button
                  onClick={() => setEditing(i)}
                  className="inline-flex items-center gap-1 px-2 py-1 rounded-md text-xs text-[#0089D0] hover:bg-sky-50 font-medium transition-colors"
                >
                  <Pencil size={12} />
                  <span>Modifier</span>
                  {i.commentCount ? (
                    <span className="ml-1 inline-flex items-center gap-0.5 text-[10px] text-slate-500">
                      <MessageSquare size={10} />
                      {i.commentCount}
                    </span>
                  ) : null}
                </button>
              </Td>
            </Tr>
          ))}
        </Tbody>
      </Table>

      {editing && (
        <StatusEditModal
          open={!!editing}
          onClose={() => setEditing(null)}
          entityType="power_incident"
          entityId={editing.id}
          title={`Incident ${formatDateTime(editing.date)}`}
          description={`Source : ${editing.source} · Zones : ${editing.zones}`}
          currentStatus={editing.impact}
          defaultPeriode={defaultPeriode}
          fields={[
            {
              name: "impact",
              label: "Impact",
              type: "select",
              options: IMPACT_OPTIONS,
              defaultValue: editing.impact,
            },
            {
              name: "dureeMin",
              label: "Durée",
              type: "number",
              defaultValue: editing.dureeMin,
              suffix: "min",
              min: 0,
            },
            {
              name: "notes",
              label: "Notes / actions prises",
              type: "textarea",
              defaultValue: editing.notes ?? "",
            },
          ]}
        />
      )}
    </>
  );
}
