"use client";

import { useState } from "react";
import { Pencil, MessageSquare } from "lucide-react";
import { Table, Thead, Tbody, Tr, Th, Td } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { StatusEditModal } from "@/components/modals/status-edit-modal";
import { formatDate } from "@/lib/utils";

type Stock = {
  id: string;
  produit: string;
  lot: string | null;
  quantite: number;
  unite: string;
  seuilAlerte: number;
  fournisseur: string;
  dateExpiration: Date | string | null;
  commentCount?: number;
};

export function StocksTable({
  stocks,
  defaultPeriode,
}: {
  stocks: Stock[];
  defaultPeriode: string;
}) {
  const [editing, setEditing] = useState<Stock | null>(null);

  return (
    <>
      <Table>
        <Thead>
          <Tr>
            <Th>Produit</Th>
            <Th>Lot</Th>
            <Th>Fournisseur</Th>
            <Th className="text-right">Quantité</Th>
            <Th className="text-right">Seuil alerte</Th>
            <Th>Niveau</Th>
            <Th>Expiration</Th>
            <Th></Th>
          </Tr>
        </Thead>
        <Tbody>
          {stocks.map((s) => {
            const pct = Math.min(200, Math.round((s.quantite / s.seuilAlerte) * 100));
            const enAlerte = s.quantite < s.seuilAlerte;
            return (
              <Tr key={s.id}>
                <Td className="font-medium text-slate-900">{s.produit}</Td>
                <Td className="font-mono text-xs">{s.lot ?? "—"}</Td>
                <Td>
                  <Badge variant={s.fournisseur === "BIOMANGUINHOS" ? "info" : "neutral"}>
                    {s.fournisseur}
                  </Badge>
                </Td>
                <Td className="text-right tabular-nums font-medium">
                  {s.quantite.toLocaleString("fr-FR")} {s.unite}
                </Td>
                <Td className="text-right tabular-nums text-slate-500">
                  {s.seuilAlerte.toLocaleString("fr-FR")}
                </Td>
                <Td className="w-40">
                  <div className="flex items-center gap-2">
                    <Progress
                      value={Math.min(100, pct)}
                      tone={enAlerte ? "danger" : pct < 150 ? "warning" : "success"}
                    />
                    {enAlerte && <Badge variant="danger">Bas</Badge>}
                  </div>
                </Td>
                <Td className="text-xs">{formatDate(s.dateExpiration)}</Td>
                <Td>
                  <button
                    onClick={() => setEditing(s)}
                    className="inline-flex items-center gap-1 px-2 py-1 rounded-md text-xs text-[#0089D0] hover:bg-sky-50 font-medium transition-colors"
                  >
                    <Pencil size={12} />
                    <span>Modifier</span>
                    {s.commentCount ? (
                      <span className="ml-1 inline-flex items-center gap-0.5 text-[10px] text-slate-500">
                        <MessageSquare size={10} />
                        {s.commentCount}
                      </span>
                    ) : null}
                  </button>
                </Td>
              </Tr>
            );
          })}
        </Tbody>
      </Table>

      {editing && (
        <StatusEditModal
          open={!!editing}
          onClose={() => setEditing(null)}
          entityType="stock_level"
          entityId={editing.id}
          title={editing.produit}
          description={`Lot ${editing.lot ?? "—"} · ${editing.fournisseur}`}
          currentStatus={editing.quantite < editing.seuilAlerte ? "BAS" : "OK"}
          defaultPeriode={defaultPeriode}
          fields={[
            {
              name: "quantite",
              label: `Quantité (${editing.unite})`,
              type: "number",
              defaultValue: editing.quantite,
              min: 0,
            },
            {
              name: "seuilAlerte",
              label: `Seuil d'alerte (${editing.unite})`,
              type: "number",
              defaultValue: editing.seuilAlerte,
              min: 0,
            },
            {
              name: "dateExpiration",
              label: "Date d'expiration",
              type: "date",
              defaultValue: editing.dateExpiration
                ? new Date(editing.dateExpiration).toISOString().slice(0, 10)
                : "",
            },
          ]}
        />
      )}
    </>
  );
}
