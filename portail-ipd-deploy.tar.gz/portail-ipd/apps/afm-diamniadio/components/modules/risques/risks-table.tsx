"use client";

import { useState } from "react";
import { Pencil, MessageSquare } from "lucide-react";
import { Table, Thead, Tbody, Tr, Th, Td } from "@/components/ui/table";
import { Badge, statutVariant } from "@/components/ui/badge";
import { StatusEditModal } from "@/components/modals/status-edit-modal";

type Risk = {
  id: string;
  code: string;
  categorie: string;
  libelle: string;
  probabilite: number;
  impact: number;
  score: number;
  mitigation: string | null;
  statut: string;
  responsable: string | null;
  commentCount?: number;
};

const STATUT_OPTIONS = [
  { value: "IDENTIFIE", label: "Identifié" },
  { value: "EN_MITIGATION", label: "En mitigation" },
  { value: "SOUS_CONTROLE", label: "Sous contrôle" },
  { value: "CLOS", label: "Clos" },
];

const CAT_LABEL: Record<string, string> = {
  CONTAMINATION: "Contamination",
  ENERGIE: "Énergie",
  SUPPLY: "Supply",
  QUALITE: "Qualité",
  AUTRE: "Autre",
};

export function RisksTable({
  risks,
  defaultPeriode,
}: {
  risks: Risk[];
  defaultPeriode: string;
}) {
  const [editing, setEditing] = useState<Risk | null>(null);

  return (
    <>
      <Table>
        <Thead>
          <Tr>
            <Th>Code</Th>
            <Th>Libellé</Th>
            <Th>Catégorie</Th>
            <Th className="text-center">P</Th>
            <Th className="text-center">I</Th>
            <Th className="text-center">Score</Th>
            <Th>Mitigation</Th>
            <Th>Statut</Th>
            <Th></Th>
          </Tr>
        </Thead>
        <Tbody>
          {risks.map((r) => (
            <Tr key={r.id}>
              <Td className="font-mono text-xs">{r.code}</Td>
              <Td>
                <div className="font-medium text-slate-900">{r.libelle}</div>
                {r.responsable && (
                  <div className="text-xs text-slate-500 mt-0.5">
                    Responsable : {r.responsable}
                  </div>
                )}
              </Td>
              <Td>
                <Badge variant="neutral">{CAT_LABEL[r.categorie] ?? r.categorie}</Badge>
              </Td>
              <Td className="text-center tabular-nums">{r.probabilite}</Td>
              <Td className="text-center tabular-nums">{r.impact}</Td>
              <Td className="text-center">
                <Badge
                  variant={
                    r.score >= 15 ? "critical" : r.score >= 10 ? "danger" : r.score >= 6 ? "warning" : "success"
                  }
                >
                  {r.score}
                </Badge>
              </Td>
              <Td className="text-xs max-w-sm">{r.mitigation ?? "—"}</Td>
              <Td>
                <Badge variant={statutVariant(r.statut)}>{r.statut}</Badge>
              </Td>
              <Td>
                <button
                  onClick={() => setEditing(r)}
                  className="inline-flex items-center gap-1 px-2 py-1 rounded-md text-xs text-[#0089D0] hover:bg-sky-50 font-medium transition-colors"
                >
                  <Pencil size={12} />
                  <span>Modifier</span>
                  {r.commentCount ? (
                    <span className="ml-1 inline-flex items-center gap-0.5 text-[10px] text-slate-500">
                      <MessageSquare size={10} />
                      {r.commentCount}
                    </span>
                  ) : null}
                </button>
              </Td>
            </Tr>
          ))}
        </Tbody>
      </Table>

      {editing && (
        <StatusEditModal
          open={!!editing}
          onClose={() => setEditing(null)}
          entityType="risk"
          entityId={editing.id}
          title={editing.libelle}
          description={`${CAT_LABEL[editing.categorie] ?? editing.categorie} · ${editing.code} · Score ${editing.score}`}
          currentStatus={editing.statut}
          defaultPeriode={defaultPeriode}
          fields={[
            {
              name: "statut",
              label: "Statut",
              type: "select",
              options: STATUT_OPTIONS,
              defaultValue: editing.statut,
            },
            {
              name: "probabilite",
              label: "Probabilité (1-5)",
              type: "number",
              defaultValue: editing.probabilite,
              min: 1,
              max: 5,
            },
            {
              name: "impact",
              label: "Impact (1-5)",
              type: "number",
              defaultValue: editing.impact,
              min: 1,
              max: 5,
            },
            {
              name: "mitigation",
              label: "Plan de mitigation",
              type: "textarea",
              defaultValue: editing.mitigation ?? "",
            },
            {
              name: "responsable",
              label: "Responsable",
              type: "text",
              defaultValue: editing.responsable ?? "",
            },
          ]}
        />
      )}
    </>
  );
}
