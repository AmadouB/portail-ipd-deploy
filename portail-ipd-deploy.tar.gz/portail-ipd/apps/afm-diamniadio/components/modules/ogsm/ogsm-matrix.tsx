"use client";

import { useMemo, useState } from "react";
import {
  Pencil, MessageSquare, Target, Layers, Compass, TrendingUp, Filter, X,
} from "lucide-react";
import {
  Bar, BarChart, CartesianGrid, Cell, LabelList, Legend, Pie, PieChart,
  ResponsiveContainer, Tooltip, XAxis, YAxis,
} from "recharts";
import { Card, CardBody, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge, statutVariant } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { KpiCard } from "@/components/ui/kpi-card";
import { Table, Thead, Tbody, Tr, Th, Td } from "@/components/ui/table";
import { StatusEditModal } from "@/components/modals/status-edit-modal";
import { cn, formatDate } from "@/lib/utils";

type Mesure = {
  id: string;
  libelle: string;
  cibleValeur: number | null;
  valeurActuelle: number | null;
  unite: string | null;
  frequence: string | null;
};

type Responsable = { id: string; prenom: string; nom: string; email: string } | null;

type Action = {
  id: string;
  axeId: string;
  code: string;
  libelle: string;
  description: string | null;
  statut: string;
  progression: number;
  priorite: string;
  dateDebut: Date | string | null;
  dateFin: Date | string | null;
  responsable: Responsable;
  mesures: Mesure[];
  axe: { id: string; code: string; libelle: string; couleur: string | null; ordre: number };
  commentCount?: number;
};

type Axe = {
  id: string;
  code: string;
  libelle: string;
  description: string | null;
  ordre: number;
  couleur: string | null;
};

type Goal = {
  id: string;
  code: string;
  libelle: string;
  cibleValeur: number | null;
  cibleUnite: string | null;
  realiseValeur: number | null;
  dateCible: Date | string | null;
  statut: string;
};

type Objective = {
  id: string;
  libelle: string;
  description: string | null;
  annee: number | null;
  dateCible: Date | string | null;
};

type User = { id: string; prenom: string; nom: string; email: string; roleCode: string };

const STATUT_OPTIONS = [
  { value: "A_FAIRE", label: "À faire" },
  { value: "EN_COURS", label: "En cours" },
  { value: "FAIT", label: "Fait" },
  { value: "BLOQUE", label: "Bloqué" },
  { value: "ANNULE", label: "Annulé" },
];

const PRIORITE_OPTIONS = [
  { value: "HAUTE", label: "Haute" },
  { value: "MOYENNE", label: "Moyenne" },
  { value: "BASSE", label: "Basse" },
];

const STATUT_COLOR: Record<string, string> = {
  FAIT: "#16a34a",
  EN_COURS: "#0089D0",
  A_FAIRE: "#94a3b8",
  BLOQUE: "#dc2626",
  ANNULE: "#64748b",
};

export function OgsmMatrix({
  objective,
  goals,
  axes,
  actions,
  users,
}: {
  objective: Objective | null;
  goals: Goal[];
  axes: Axe[];
  actions: Action[];
  users: User[];
}) {
  const [fAxe, setFAxe] = useState<string>("");
  const [fStatut, setFStatut] = useState<string>("");
  const [fPriorite, setFPriorite] = useState<string>("");
  const [fResponsable, setFResponsable] = useState<string>("");
  const [fSearch, setFSearch] = useState<string>("");
  const [editing, setEditing] = useState<Action | null>(null);

  const filtered = useMemo(() => {
    return actions.filter((a) => {
      if (fAxe && a.axe.id !== fAxe) return false;
      if (fStatut && a.statut !== fStatut) return false;
      if (fPriorite && a.priorite !== fPriorite) return false;
      if (fResponsable && a.responsable?.id !== fResponsable) return false;
      if (fSearch) {
        const q = fSearch.toLowerCase();
        if (
          !a.libelle.toLowerCase().includes(q) &&
          !a.code.toLowerCase().includes(q) &&
          !(a.description?.toLowerCase().includes(q) ?? false)
        )
          return false;
      }
      return true;
    });
  }, [actions, fAxe, fStatut, fPriorite, fResponsable, fSearch]);

  const stats = useMemo(() => {
    const n = filtered.length;
    const byStatut: Record<string, number> = {};
    const byAxe: Record<string, { axe: Axe; count: number; progTotal: number }> = {};
    const byResp: Record<string, { nom: string; count: number }> = {};
    let progMoy = 0;
    const now = Date.now();
    let enRetard = 0;

    for (const a of filtered) {
      byStatut[a.statut] = (byStatut[a.statut] ?? 0) + 1;
      const ax = byAxe[a.axe.id] ?? { axe: a.axe, count: 0, progTotal: 0 };
      ax.count += 1;
      ax.progTotal += a.progression;
      byAxe[a.axe.id] = ax as typeof byAxe[string];
      const respKey = a.responsable?.id ?? "_none";
      const respNom = a.responsable ? `${a.responsable.prenom} ${a.responsable.nom}` : "— Non assigné";
      byResp[respKey] = byResp[respKey] ?? { nom: respNom, count: 0 };
      byResp[respKey].count += 1;
      progMoy += a.progression;
      if (a.dateFin && new Date(a.dateFin).getTime() < now && a.statut !== "FAIT" && a.statut !== "ANNULE") {
        enRetard += 1;
      }
    }
    progMoy = n ? Math.round(progMoy / n) : 0;

    return {
      n,
      byStatut: Object.entries(byStatut).map(([k, v]) => ({ name: k, value: v, color: STATUT_COLOR[k] ?? "#94a3b8" })),
      byAxe: Object.values(byAxe).map((a) => ({
        name: a.axe.libelle,
        count: a.count,
        progression: Math.round(a.progTotal / Math.max(a.count, 1)),
        couleur: a.axe.couleur ?? "#0089D0",
      })),
      byResp: Object.values(byResp).sort((a, b) => b.count - a.count),
      progMoy,
      enRetard,
      fait: byStatut.FAIT ?? 0,
    };
  }, [filtered]);

  const hasFilter = !!(fAxe || fStatut || fPriorite || fResponsable || fSearch);

  function clearFilters() {
    setFAxe("");
    setFStatut("");
    setFPriorite("");
    setFResponsable("");
    setFSearch("");
  }

  return (
    <>
      {/* Bloc OBJECTIF + BUTS */}
      {objective && (
        <Card className="mb-6 border-[#0089D0]/20 dark:border-[#0089D0]/40">
          <CardBody className="bg-gradient-to-br from-sky-50 to-white dark:from-[#0089D0]/10 dark:to-[var(--afm-surface)] rounded-xl">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-lg bg-[#0089D0] text-white flex items-center justify-center flex-shrink-0">
                <Target size={22} />
              </div>
              <div className="flex-1">
                <div className="text-xs uppercase tracking-wider text-[#0089D0] font-semibold mb-1" style={{ fontFamily: "var(--font-poppins)" }}>
                  Objectif stratégique {objective.annee ? `· ${objective.annee}` : ""}
                </div>
                <h2 className="text-xl font-bold text-slate-900 dark:text-[var(--afm-text)]" style={{ fontFamily: "var(--font-poppins)" }}>
                  {objective.libelle}
                </h2>
                {objective.description && (
                  <p className="text-sm text-slate-600 dark:text-[var(--afm-text-muted)] mt-1">{objective.description}</p>
                )}
              </div>
            </div>

            {goals.length > 0 && (
              <div className="mt-5 pt-5 border-t border-slate-200 dark:border-[var(--afm-border)]">
                <div className="text-xs uppercase tracking-wider text-slate-500 dark:text-[var(--afm-text-muted)] font-semibold mb-3">
                  Buts quantifiés
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-3">
                  {goals.map((g) => (
                    <div key={g.id} className="bg-white dark:bg-[var(--afm-surface)] border border-slate-200 dark:border-[var(--afm-border)] rounded-lg p-3">
                      <div className="text-xs font-mono text-slate-500 dark:text-[var(--afm-text-muted)]">{g.code}</div>
                      <div className="text-sm font-medium text-slate-900 dark:text-[var(--afm-text)] mt-0.5 min-h-[40px]">
                        {g.libelle}
                      </div>
                      <div className="flex items-baseline gap-1.5 mt-2">
                        <span className="text-lg font-bold text-[#0089D0] tabular-nums">
                          {g.cibleValeur !== null ? g.cibleValeur.toLocaleString("fr-FR") : "—"}
                        </span>
                        <span className="text-xs text-slate-500 dark:text-[var(--afm-text-muted)]">{g.cibleUnite}</span>
                      </div>
                      <Badge variant={statutVariant(g.statut)} className="mt-1.5">
                        {g.statut}
                      </Badge>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </CardBody>
        </Card>
      )}

      {/* KPI réactifs aux filtres */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
        <KpiCard label="Actions filtrées" value={stats.n} suffix={`/ ${actions.length}`} icon={Layers} tone="primary" />
        <KpiCard
          label="Progression moyenne"
          value={stats.progMoy}
          suffix="%"
          icon={TrendingUp}
          tone={stats.progMoy >= 70 ? "success" : stats.progMoy >= 40 ? "primary" : "warning"}
        />
        <KpiCard label="Actions terminées" value={stats.fait} suffix={stats.n ? `${Math.round((stats.fait / stats.n) * 100)} %` : ""} icon={Target} tone="success" />
        <KpiCard
          label="En retard / bloquées"
          value={stats.enRetard + (stats.byStatut.find((s) => s.name === "BLOQUE")?.value ?? 0)}
          icon={Compass}
          tone={stats.enRetard > 0 ? "danger" : "success"}
        />
      </div>

      {/* Filtres */}
      <Card className="mb-4">
        <CardBody className="p-3">
          <div className="flex items-center flex-wrap gap-2">
            <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-600 dark:text-[var(--afm-text-muted)] pr-2">
              <Filter size={14} />
              Filtres
            </div>
            <select
              value={fAxe}
              onChange={(e) => setFAxe(e.target.value)}
              className="px-2.5 py-1.5 border border-slate-200 dark:border-[var(--afm-border)] rounded-md text-xs bg-white dark:bg-[var(--afm-surface)] focus:outline-none focus:ring-2 focus:ring-[#0089D0]/30"
            >
              <option value="">Tous les axes</option>
              {axes.map((a) => (
                <option key={a.id} value={a.id}>
                  {a.libelle}
                </option>
              ))}
            </select>
            <select
              value={fStatut}
              onChange={(e) => setFStatut(e.target.value)}
              className="px-2.5 py-1.5 border border-slate-200 dark:border-[var(--afm-border)] rounded-md text-xs bg-white dark:bg-[var(--afm-surface)] focus:outline-none focus:ring-2 focus:ring-[#0089D0]/30"
            >
              <option value="">Tous les statuts</option>
              {STATUT_OPTIONS.map((s) => (
                <option key={s.value} value={s.value}>
                  {s.label}
                </option>
              ))}
            </select>
            <select
              value={fPriorite}
              onChange={(e) => setFPriorite(e.target.value)}
              className="px-2.5 py-1.5 border border-slate-200 dark:border-[var(--afm-border)] rounded-md text-xs bg-white dark:bg-[var(--afm-surface)] focus:outline-none focus:ring-2 focus:ring-[#0089D0]/30"
            >
              <option value="">Toutes priorités</option>
              {PRIORITE_OPTIONS.map((p) => (
                <option key={p.value} value={p.value}>
                  {p.label}
                </option>
              ))}
            </select>
            <select
              value={fResponsable}
              onChange={(e) => setFResponsable(e.target.value)}
              className="px-2.5 py-1.5 border border-slate-200 dark:border-[var(--afm-border)] rounded-md text-xs bg-white dark:bg-[var(--afm-surface)] focus:outline-none focus:ring-2 focus:ring-[#0089D0]/30"
            >
              <option value="">Tous responsables</option>
              {users.map((u) => (
                <option key={u.id} value={u.id}>
                  {u.prenom} {u.nom}
                </option>
              ))}
            </select>
            <input
              type="text"
              value={fSearch}
              onChange={(e) => setFSearch(e.target.value)}
              placeholder="Rechercher…"
              className="flex-1 min-w-[180px] px-2.5 py-1.5 border border-slate-200 dark:border-[var(--afm-border)] rounded-md text-xs focus:outline-none focus:ring-2 focus:ring-[#0089D0]/30"
            />
            {hasFilter && (
              <button
                onClick={clearFilters}
                className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs text-slate-600 dark:text-[var(--afm-text-muted)] hover:bg-slate-100 dark:hover:bg-[var(--afm-border)]/40 rounded-md"
              >
                <X size={12} />
                Réinitialiser
              </button>
            )}
          </div>
        </CardBody>
      </Card>

      {/* Visuels statistiques */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-sm">Répartition par statut</CardTitle>
          </CardHeader>
          <CardBody>
            <div className="h-52">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={stats.byStatut}
                    dataKey="value"
                    nameKey="name"
                    cx="50%"
                    cy="50%"
                    innerRadius={40}
                    outerRadius={72}
                    paddingAngle={2}
                    label={(e: unknown) => {
                      const d = e as { value?: number; percent?: number };
                      return d.percent ? `${(d.percent * 100).toFixed(0)}%` : `${d.value ?? ""}`;
                    }}
                    labelLine={false}
                  >
                    {stats.byStatut.map((s, i) => (
                      <Cell key={i} fill={s.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    formatter={(v, name) => [String(v), String(name)]}
                    contentStyle={{ fontSize: 12, borderRadius: 8 }}
                  />
                  <Legend wrapperStyle={{ fontSize: 11 }} />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardBody>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-sm">Progression moyenne par axe</CardTitle>
          </CardHeader>
          <CardBody>
            <div className="h-80 chart-themed">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={stats.byAxe}
                  layout="vertical"
                  margin={{ top: 8, right: 56, left: 5, bottom: 0 }}
                >
                  <CartesianGrid stroke="currentColor" strokeOpacity={0.15} horizontal={false} />
                  <XAxis
                    type="number"
                    domain={[0, 100]}
                    tickFormatter={(v) => `${String(v)}%`}
                    tick={{ fontSize: 11, fontWeight: 500, fill: "currentColor" }}
                    stroke="currentColor"
                    strokeOpacity={0.4}
                  />
                  <YAxis
                    type="category"
                    dataKey="name"
                    width={210}
                    tick={{ fontSize: 11, fontWeight: 600, fill: "currentColor" }}
                    interval={0}
                    tickFormatter={(v) => {
                      const s = String(v);
                      return s.length > 32 ? s.slice(0, 30) + "…" : s;
                    }}
                    stroke="currentColor"
                    strokeOpacity={0.4}
                  />
                  <Tooltip
                    formatter={(v) => [`${String(v)} %`, "Progression"]}
                    contentStyle={{ fontSize: 12, borderRadius: 8 }}
                  />
                  <Bar dataKey="progression" radius={[0, 4, 4, 0]}>
                    {stats.byAxe.map((a, i) => (
                      <Cell key={i} fill={a.couleur} />
                    ))}
                    <LabelList
                      dataKey="progression"
                      position="right"
                      formatter={(v) => `${Number(v ?? 0)} %`}
                      style={{ fontSize: 12, fontWeight: 700, fill: "currentColor" }}
                    />
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardBody>
        </Card>

      </div>

      {/* Matrice */}
      <Card>
        <CardHeader>
          <CardTitle>
            Matrice OGSM · {filtered.length} action{filtered.length > 1 ? "s" : ""}
          </CardTitle>
        </CardHeader>
        <CardBody className="p-0">
          <Table>
            <Thead>
              <Tr>
                <Th>Axe stratégique</Th>
                <Th>Code</Th>
                <Th>Plan d&apos;action</Th>
                <Th>Mesure(s)</Th>
                <Th>Responsable</Th>
                <Th>Priorité</Th>
                <Th>Échéance</Th>
                <Th className="w-40">Progression</Th>
                <Th>Statut</Th>
                <Th></Th>
              </Tr>
            </Thead>
            <Tbody>
              {filtered.map((a) => {
                const enRetard =
                  a.dateFin &&
                  new Date(a.dateFin).getTime() < Date.now() &&
                  a.statut !== "FAIT" &&
                  a.statut !== "ANNULE";
                return (
                  <Tr key={a.id}>
                    <Td>
                      <div className="flex items-center gap-2">
                        <span
                          className="inline-block w-1.5 h-8 rounded-full flex-shrink-0"
                          style={{ background: a.axe.couleur ?? "#0089D0" }}
                          aria-hidden
                        />
                        <span className="text-xs font-medium text-slate-700 dark:text-[var(--afm-text)]/85">{a.axe.libelle}</span>
                      </div>
                    </Td>
                    <Td className="font-mono text-xs">{a.code}</Td>
                    <Td className="max-w-sm">
                      <div className="font-medium text-slate-900 dark:text-[var(--afm-text)] text-sm">{a.libelle}</div>
                      {a.description && (
                        <div className="text-xs text-slate-500 dark:text-[var(--afm-text-muted)] mt-0.5 line-clamp-2">
                          {a.description}
                        </div>
                      )}
                    </Td>
                    <Td className="max-w-xs">
                      {a.mesures.length === 0 ? (
                        <span className="text-xs text-slate-400 dark:text-slate-500">—</span>
                      ) : (
                        <div className="space-y-1">
                          {a.mesures.map((m) => (
                            <div key={m.id} className="text-xs">
                              <span className="text-slate-700 dark:text-[var(--afm-text)]/85">{m.libelle}</span>
                              {m.cibleValeur !== null && (
                                <span className="text-slate-500 dark:text-[var(--afm-text-muted)] ml-1">
                                  :{" "}
                                  <span className="font-medium text-[#0089D0] tabular-nums">
                                    {m.valeurActuelle ?? 0}
                                  </span>
                                  {" / "}
                                  <span className="tabular-nums">{m.cibleValeur}</span>
                                  {m.unite && <span> {m.unite}</span>}
                                </span>
                              )}
                            </div>
                          ))}
                        </div>
                      )}
                    </Td>
                    <Td className="text-xs">
                      {a.responsable ? (
                        <div>
                          <div className="font-medium text-slate-900 dark:text-[var(--afm-text)]">
                            {a.responsable.prenom} {a.responsable.nom}
                          </div>
                        </div>
                      ) : (
                        <span className="text-slate-400 dark:text-slate-500">Non assigné</span>
                      )}
                    </Td>
                    <Td>
                      <Badge
                        variant={
                          a.priorite === "HAUTE"
                            ? "critical"
                            : a.priorite === "MOYENNE"
                            ? "warning"
                            : "neutral"
                        }
                      >
                        {a.priorite}
                      </Badge>
                    </Td>
                    <Td className={cn("text-xs", enRetard && "text-red-700 font-semibold")}>
                      {formatDate(a.dateFin)}
                      {enRetard && " ⚠"}
                    </Td>
                    <Td>
                      <div className="flex items-center gap-2">
                        <Progress
                          value={a.progression}
                          tone={
                            a.progression >= 70
                              ? "success"
                              : a.progression >= 30
                              ? "primary"
                              : "warning"
                          }
                        />
                        <span className="text-xs text-slate-500 dark:text-[var(--afm-text-muted)] tabular-nums w-8 text-right">
                          {a.progression}%
                        </span>
                      </div>
                    </Td>
                    <Td>
                      <Badge variant={statutVariant(a.statut)}>{a.statut}</Badge>
                    </Td>
                    <Td>
                      <button
                        onClick={() => setEditing(a)}
                        className="inline-flex items-center gap-1 px-2 py-1 rounded-md text-xs text-[#0089D0] hover:bg-sky-50 dark:hover:bg-[#0089D0]/15 font-medium transition-colors"
                      >
                        <Pencil size={12} />
                        <span>Modifier</span>
                        {a.commentCount ? (
                          <span className="ml-1 inline-flex items-center gap-0.5 text-[10px] text-slate-500 dark:text-[var(--afm-text-muted)]">
                            <MessageSquare size={10} />
                            {a.commentCount}
                          </span>
                        ) : null}
                      </button>
                    </Td>
                  </Tr>
                );
              })}
              {filtered.length === 0 && (
                <Tr>
                  <Td className="text-center text-sm text-slate-400 dark:text-slate-500 py-8" colSpan={10}>
                    Aucune action ne correspond aux filtres sélectionnés.
                  </Td>
                </Tr>
              )}
            </Tbody>
          </Table>
        </CardBody>
      </Card>

      {editing && (
        <StatusEditModal
          open={!!editing}
          onClose={() => setEditing(null)}
          entityType="ogsm_action"
          entityId={editing.id}
          title={editing.libelle}
          description={`${editing.axe.libelle} · ${editing.code}`}
          currentStatus={editing.statut}
          defaultPeriode={`${new Date().getFullYear()}-T${Math.floor(new Date().getMonth() / 3) + 1}`}
          fields={[
            {
              name: "statut",
              label: "Statut",
              type: "select",
              options: STATUT_OPTIONS,
              defaultValue: editing.statut,
            },
            {
              name: "progression",
              label: "Progression",
              type: "number",
              defaultValue: editing.progression,
              suffix: "%",
              min: 0,
              max: 100,
            },
            {
              name: "priorite",
              label: "Priorité",
              type: "select",
              options: PRIORITE_OPTIONS,
              defaultValue: editing.priorite,
            },
            {
              name: "responsableId",
              label: "Responsable",
              type: "select",
              options: users.map((u) => ({ value: u.id, label: `${u.prenom} ${u.nom}` })),
              defaultValue: editing.responsable?.id ?? "",
            },
            {
              name: "dateFin",
              label: "Échéance",
              type: "date",
              defaultValue: editing.dateFin
                ? new Date(editing.dateFin).toISOString().slice(0, 10)
                : "",
            },
            {
              name: "description",
              label: "Description / notes",
              type: "textarea",
              defaultValue: editing.description ?? "",
            },
          ]}
        />
      )}
    </>
  );
}
