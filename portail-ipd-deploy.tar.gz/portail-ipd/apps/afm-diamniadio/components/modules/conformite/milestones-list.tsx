"use client";

import { useState } from "react";
import { Pencil, MessageSquare } from "lucide-react";
import { Card, CardBody, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge, statutVariant } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { StatusEditModal } from "@/components/modals/status-edit-modal";
import { formatDate, relativeDate } from "@/lib/utils";

type Milestone = {
  id: string;
  code: string;
  libelle: string;
  autorite: string;
  type: string;
  dateCible: Date | string;
  dateRealisee: Date | string | null;
  statut: string;
  progression: number;
  notes: string | null;
  commentCount?: number;
};

const STATUT_OPTIONS = [
  { value: "PLANIFIE", label: "Planifié" },
  { value: "EN_COURS", label: "En cours" },
  { value: "OBTENU", label: "Obtenu" },
  { value: "RETARD", label: "En retard" },
];

export function MilestonesList({
  milestones,
  defaultPeriode,
}: {
  milestones: Milestone[];
  defaultPeriode: string;
}) {
  const [editing, setEditing] = useState<Milestone | null>(null);

  return (
    <>
      <div className="space-y-4">
        {milestones.map((j) => (
          <Card key={j.id}>
            <CardHeader>
              <div className="flex items-start justify-between gap-4">
                <div className="min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <Badge variant="info">{j.autorite}</Badge>
                    <Badge variant="neutral">{j.type}</Badge>
                  </div>
                  <CardTitle>{j.libelle}</CardTitle>
                  <div className="text-xs text-slate-500 mt-1">
                    Cible : {formatDate(j.dateCible)} ({relativeDate(j.dateCible)})
                    {j.dateRealisee && ` · Réalisé : ${formatDate(j.dateRealisee)}`}
                  </div>
                </div>
                <div className="flex items-center gap-2 flex-shrink-0">
                  <Badge variant={statutVariant(j.statut)}>{j.statut}</Badge>
                  <button
                    onClick={() => setEditing(j)}
                    className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-md text-xs text-[#0089D0] hover:bg-sky-50 font-medium transition-colors border border-[#0089D0]/20"
                  >
                    <Pencil size={12} />
                    Modifier
                    {j.commentCount ? (
                      <span className="ml-1 inline-flex items-center gap-0.5 text-[10px] text-slate-500">
                        <MessageSquare size={10} />
                        {j.commentCount}
                      </span>
                    ) : null}
                  </button>
                </div>
              </div>
            </CardHeader>
            <CardBody>
              <div className="flex items-center gap-4 mb-2">
                <Progress
                  value={j.progression}
                  tone={
                    j.progression >= 70 ? "success" : j.progression >= 30 ? "primary" : "warning"
                  }
                />
                <span className="text-sm font-semibold tabular-nums w-12 text-right">
                  {j.progression}%
                </span>
              </div>
              {j.notes && <div className="text-sm text-slate-600">{j.notes}</div>}
            </CardBody>
          </Card>
        ))}
      </div>

      {editing && (
        <StatusEditModal
          open={!!editing}
          onClose={() => setEditing(null)}
          entityType="milestone"
          entityId={editing.id}
          title={editing.libelle}
          description={`${editing.autorite} · ${editing.type} · ${editing.code}`}
          currentStatus={editing.statut}
          defaultPeriode={defaultPeriode}
          fields={[
            {
              name: "statut",
              label: "Statut",
              type: "select",
              options: STATUT_OPTIONS,
              defaultValue: editing.statut,
            },
            {
              name: "progression",
              label: "Progression",
              type: "number",
              defaultValue: editing.progression,
              suffix: "%",
              min: 0,
              max: 100,
            },
            {
              name: "dateRealisee",
              label: "Date de réalisation",
              type: "date",
              defaultValue: editing.dateRealisee
                ? new Date(editing.dateRealisee).toISOString().slice(0, 10)
                : "",
            },
            {
              name: "notes",
              label: "Notes",
              type: "textarea",
              defaultValue: editing.notes ?? "",
            },
          ]}
        />
      )}
    </>
  );
}
