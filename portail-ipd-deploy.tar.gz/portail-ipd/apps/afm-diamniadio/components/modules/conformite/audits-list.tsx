"use client";

import { useState } from "react";
import { Pencil, MessageSquare } from "lucide-react";
import { Badge, statutVariant } from "@/components/ui/badge";
import { Card, CardBody, CardHeader, CardTitle } from "@/components/ui/card";
import { StatusEditModal } from "@/components/modals/status-edit-modal";
import { formatDate, relativeDate } from "@/lib/utils";

type Audit = {
  id: string;
  code: string;
  type: string;
  libelle: string;
  datePrevue: Date | string;
  dateRealisee: Date | string | null;
  statut: string;
  rapport: string | null;
  auditeur: string | null;
  commentCount?: number;
};

const STATUT_OPTIONS = [
  { value: "PLANIFIE", label: "Planifié" },
  { value: "REALISE", label: "Réalisé" },
  { value: "RAPPORT_ATTENDU", label: "Rapport attendu" },
  { value: "CLOS", label: "Clos" },
];

export function AuditsList({
  audits,
  defaultPeriode,
}: {
  audits: Audit[];
  defaultPeriode: string;
}) {
  const [editing, setEditing] = useState<Audit | null>(null);
  const aVenir = audits.filter((a) => a.statut === "PLANIFIE");
  const passes = audits.filter((a) => a.statut !== "PLANIFIE");

  return (
    <>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader>
            <CardTitle>À venir ({aVenir.length})</CardTitle>
          </CardHeader>
          <CardBody>
            <div className="space-y-3">
              {aVenir.map((a) => (
                <AuditCard key={a.id} audit={a} onEdit={() => setEditing(a)} variant="upcoming" />
              ))}
              {aVenir.length === 0 && (
                <div className="text-sm text-slate-500 text-center py-6">Aucun audit planifié.</div>
              )}
            </div>
          </CardBody>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Historique ({passes.length})</CardTitle>
          </CardHeader>
          <CardBody>
            <div className="space-y-3">
              {passes.map((a) => (
                <AuditCard key={a.id} audit={a} onEdit={() => setEditing(a)} variant="past" />
              ))}
              {passes.length === 0 && (
                <div className="text-sm text-slate-500 text-center py-6">Aucun historique.</div>
              )}
            </div>
          </CardBody>
        </Card>
      </div>

      {editing && (
        <StatusEditModal
          open={!!editing}
          onClose={() => setEditing(null)}
          entityType="audit"
          entityId={editing.id}
          title={editing.libelle}
          description={`${editing.type} · ${editing.code}`}
          currentStatus={editing.statut}
          defaultPeriode={defaultPeriode}
          fields={[
            {
              name: "statut",
              label: "Statut",
              type: "select",
              options: STATUT_OPTIONS,
              defaultValue: editing.statut,
            },
            {
              name: "dateRealisee",
              label: "Date de réalisation",
              type: "date",
              defaultValue: editing.dateRealisee
                ? new Date(editing.dateRealisee).toISOString().slice(0, 10)
                : "",
            },
            {
              name: "auditeur",
              label: "Auditeur / organisme",
              type: "text",
              defaultValue: editing.auditeur ?? "",
            },
            {
              name: "rapport",
              label: "Synthèse rapport",
              type: "textarea",
              defaultValue: editing.rapport ?? "",
            },
          ]}
        />
      )}
    </>
  );
}

function AuditCard({
  audit,
  onEdit,
  variant,
}: {
  audit: Audit;
  onEdit: () => void;
  variant: "upcoming" | "past";
}) {
  return (
    <div
      className={
        variant === "upcoming"
          ? "flex items-start justify-between p-4 rounded-lg border border-slate-200 bg-gradient-to-br from-white to-slate-50"
          : "flex items-start justify-between p-4 rounded-lg bg-slate-50 border border-slate-100"
      }
    >
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-2 mb-1">
          <Badge variant={audit.type === "OMS" || audit.type === "ARP" ? "critical" : "info"}>
            {audit.type}
          </Badge>
          <span className="text-xs font-mono text-slate-500">{audit.code}</span>
        </div>
        <div className="text-sm font-medium text-slate-900">{audit.libelle}</div>
        <div className="text-xs text-slate-500 mt-1">
          {variant === "upcoming"
            ? `${formatDate(audit.datePrevue)} (${relativeDate(audit.datePrevue)})`
            : `Réalisé le ${formatDate(audit.dateRealisee ?? audit.datePrevue)}`}
        </div>
        {audit.auditeur && (
          <div className="text-xs text-slate-500 mt-0.5">Auditeur : {audit.auditeur}</div>
        )}
        {audit.rapport && (
          <div className="text-xs text-slate-600 mt-1 italic">{audit.rapport}</div>
        )}
      </div>
      <div className="flex flex-col items-end gap-2 ml-3">
        <Badge variant={statutVariant(audit.statut)}>{audit.statut}</Badge>
        <button
          onClick={onEdit}
          className="inline-flex items-center gap-1 px-2 py-1 rounded-md text-xs text-[#0089D0] hover:bg-sky-50 font-medium transition-colors border border-[#0089D0]/20"
        >
          <Pencil size={12} />
          Modifier
          {audit.commentCount ? (
            <span className="ml-1 inline-flex items-center gap-0.5 text-[10px] text-slate-500">
              <MessageSquare size={10} />
              {audit.commentCount}
            </span>
          ) : null}
        </button>
      </div>
    </div>
  );
}
