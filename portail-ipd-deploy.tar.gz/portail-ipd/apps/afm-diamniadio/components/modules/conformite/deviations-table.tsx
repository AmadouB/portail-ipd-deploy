"use client";

import { useState } from "react";
import { MessageSquare, Pencil } from "lucide-react";
import { Table, Thead, Tbody, Tr, Th, Td } from "@/components/ui/table";
import { Badge, statutVariant } from "@/components/ui/badge";
import { StatusEditModal } from "@/components/modals/status-edit-modal";
import { formatDate } from "@/lib/utils";

type Deviation = {
  id: string;
  code: string;
  titre: string;
  severite: string;
  statut: string;
  dateDetection: Date | string;
  dateResolution: Date | string | null;
  responsable: string | null;
  actionCorrective: string | null;
  commentCount?: number;
};

const STATUT_OPTIONS = [
  { value: "OUVERTE", label: "Ouverte" },
  { value: "EN_TRAITEMENT", label: "En traitement" },
  { value: "CLOSE", label: "Close" },
];

const SEVERITE_LABEL: Record<string, string> = {
  MINEURE: "Mineure",
  MAJEURE: "Majeure",
  CRITIQUE: "Critique",
};

export function DeviationsTable({
  deviations,
  defaultPeriode,
}: {
  deviations: Deviation[];
  defaultPeriode: string;
}) {
  const [editing, setEditing] = useState<Deviation | null>(null);

  return (
    <>
      <Table>
        <Thead>
          <Tr>
            <Th>Code</Th>
            <Th>Titre</Th>
            <Th>Sévérité</Th>
            <Th>Détection</Th>
            <Th>Responsable</Th>
            <Th>Action corrective</Th>
            <Th>Résolution</Th>
            <Th>Statut</Th>
            <Th></Th>
          </Tr>
        </Thead>
        <Tbody>
          {deviations.map((d) => (
            <Tr key={d.id}>
              <Td className="font-mono text-xs">{d.code}</Td>
              <Td className="font-medium text-slate-900">{d.titre}</Td>
              <Td>
                <Badge variant={statutVariant(d.severite)}>{SEVERITE_LABEL[d.severite] ?? d.severite}</Badge>
              </Td>
              <Td className="text-xs">{formatDate(d.dateDetection)}</Td>
              <Td className="text-xs">{d.responsable ?? "—"}</Td>
              <Td className="text-xs max-w-xs">{d.actionCorrective ?? "—"}</Td>
              <Td className="text-xs">{formatDate(d.dateResolution)}</Td>
              <Td>
                <Badge variant={statutVariant(d.statut)}>{d.statut}</Badge>
              </Td>
              <Td>
                <button
                  onClick={() => setEditing(d)}
                  className="inline-flex items-center gap-1 px-2 py-1 rounded-md text-xs text-[#0089D0] hover:bg-sky-50 font-medium transition-colors"
                  aria-label={`Modifier ${d.code}`}
                >
                  <Pencil size={12} />
                  <span>Modifier</span>
                  {d.commentCount ? (
                    <span className="ml-1 inline-flex items-center gap-0.5 text-[10px] text-slate-500">
                      <MessageSquare size={10} />
                      {d.commentCount}
                    </span>
                  ) : null}
                </button>
              </Td>
            </Tr>
          ))}
        </Tbody>
      </Table>

      {editing && (
        <StatusEditModal
          open={!!editing}
          onClose={() => setEditing(null)}
          entityType="deviation"
          entityId={editing.id}
          title={`Déviation ${editing.code}`}
          description={editing.titre}
          currentStatus={editing.statut}
          defaultPeriode={defaultPeriode}
          fields={[
            {
              name: "statut",
              label: "Statut",
              type: "select",
              options: STATUT_OPTIONS,
              defaultValue: editing.statut,
            },
            {
              name: "responsable",
              label: "Responsable",
              type: "text",
              defaultValue: editing.responsable ?? "",
            },
            {
              name: "actionCorrective",
              label: "Action corrective",
              type: "textarea",
              defaultValue: editing.actionCorrective ?? "",
            },
            {
              name: "dateResolution",
              label: "Date de résolution",
              type: "date",
              defaultValue: editing.dateResolution
                ? new Date(editing.dateResolution).toISOString().slice(0, 10)
                : "",
            },
          ]}
        />
      )}
    </>
  );
}
