"use client";

import { useEffect, type ReactNode } from "react";
import { X } from "lucide-react";
import { cn } from "@/lib/utils";

export function Dialog({
  open,
  onClose,
  title,
  description,
  children,
  widthClass = "max-w-lg",
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  description?: string;
  children: ReactNode;
  widthClass?: string;
}) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-start justify-center p-4 pt-16 overflow-y-auto"
      role="dialog"
      aria-modal="true"
      aria-labelledby="dialog-title"
    >
      <div
        className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm"
        onClick={onClose}
        aria-hidden
      />
      <div
        className={cn(
          "relative w-full bg-white dark:bg-[var(--afm-surface)] rounded-xl shadow-xl border border-slate-200 dark:border-[var(--afm-border)] animate-in fade-in zoom-in-95",
          widthClass
        )}
      >
        <div className="flex items-start justify-between p-5 border-b border-slate-100 dark:border-[var(--afm-border)]/60">
          <div className="pr-4">
            <h2
              id="dialog-title"
              className="text-lg font-bold text-slate-900 dark:text-[var(--afm-text)]"
              style={{ fontFamily: "var(--font-poppins)" }}
            >
              {title}
            </h2>
            {description && (
              <p className="text-sm text-slate-500 dark:text-[var(--afm-text-muted)] mt-1">{description}</p>
            )}
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-md text-slate-400 dark:text-[var(--afm-text-muted)] hover:text-slate-700 dark:hover:text-[var(--afm-text)] hover:bg-slate-100 dark:hover:bg-[var(--afm-border)]/40 transition-colors"
            aria-label="Fermer"
          >
            <X size={18} />
          </button>
        </div>
        <div className="p-5">{children}</div>
      </div>
    </div>
  );
}
