"use client";

import { useEffect, useState } from "react";
import { Sun, Moon } from "lucide-react";
import { cn } from "@/lib/utils";

type Theme = "light" | "dark";

export function ThemeToggle({ className }: { className?: string }) {
  const [theme, setTheme] = useState<Theme>("light");
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    const stored = (typeof window !== "undefined" && window.localStorage.getItem("afm-theme")) as Theme | null;
    const initial: Theme = stored ?? (window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light");
    setTheme(initial);
    document.documentElement.classList.toggle("dark", initial === "dark");
  }, []);

  function toggle() {
    const next: Theme = theme === "dark" ? "light" : "dark";
    setTheme(next);
    document.documentElement.classList.toggle("dark", next === "dark");
    try {
      window.localStorage.setItem("afm-theme", next);
    } catch {
      /* localStorage bloqué : pas grave, la session reste en mémoire */
    }
  }

  return (
    <button
      type="button"
      onClick={toggle}
      aria-label={theme === "dark" ? "Passer en mode clair" : "Passer en mode sombre"}
      title={theme === "dark" ? "Passer en mode clair" : "Passer en mode sombre"}
      className={cn(
        "relative inline-flex items-center h-8 w-14 rounded-full border transition-colors",
        "border-slate-300 bg-slate-100 hover:bg-slate-200",
        "dark:border-[var(--afm-border)] dark:bg-[var(--afm-surface)] dark:hover:bg-[var(--afm-primary-light)]/30",
        className
      )}
    >
      <span
        className={cn(
          "absolute top-0.5 flex items-center justify-center w-7 h-7 rounded-full shadow-sm transition-all",
          theme === "dark"
            ? "left-[24px] bg-[var(--afm-primary)] text-white"
            : "left-0.5 bg-white text-[#0089D0]"
        )}
        aria-hidden
      >
        {mounted && (theme === "dark" ? <Moon size={14} /> : <Sun size={14} />)}
      </span>
      <span className="sr-only">Thème</span>
    </button>
  );
}
