import { cn } from "@/lib/utils";
import type { ReactNode } from "react";

type Variant =
  | "default"
  | "success"
  | "warning"
  | "danger"
  | "critical"
  | "info"
  | "neutral";

const variants: Record<Variant, string> = {
  default: "bg-sky-50 text-sky-600 border-sky-200",
  success: "bg-green-50 text-green-700 border-green-200",
  warning: "bg-orange-50 text-orange-700 border-orange-200",
  danger: "bg-red-50 text-red-700 border-red-200",
  critical: "bg-red-100 text-red-900 border-red-300",
  info: "bg-sky-50 text-sky-700 border-sky-200",
  neutral: "bg-slate-50 text-slate-600 border-slate-200",
};

export function Badge({
  children,
  variant = "default",
  className,
}: {
  children: ReactNode;
  variant?: Variant;
  className?: string;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-xs font-medium border",
        variants[variant],
        className
      )}
    >
      {children}
    </span>
  );
}

/**
 * Mappe un statut commun sur un variant de badge.
 */
export function statutVariant(statut: string): Variant {
  const s = statut.toUpperCase();
  if (["FAIT", "VALIDE", "ATTEINT", "OBTENU", "CONFORME", "CLOS", "CLOSE", "SOUS_CONTROLE"].includes(s)) return "success";
  if (["EN_COURS", "EN_TRAITEMENT", "EN_REVUE", "EN_MITIGATION", "PLANIFIE", "REALISE", "RAPPORT_ATTENDU"].includes(s)) return "info";
  if (["RETARD", "MAJEURE", "OUVERTE", "REPRISE", "IDENTIFIE", "BROUILLON", "A_FAIRE", "MAINTENANCE", "INSTALLATION"].includes(s)) return "warning";
  if (["CRITIQUE", "REJETE", "HS", "ECHEC"].includes(s)) return "critical";
  if (["MINEURE", "MINEUR", "CIBLE"].includes(s)) return "neutral";
  return "neutral";
}
