import { cn } from "@/lib/utils";
import type { LucideIcon } from "lucide-react";

type Tone = "primary" | "accent" | "success" | "warning" | "danger";

const tones: Record<Tone, { bg: string; text: string; icon: string }> = {
  primary: { bg: "bg-sky-50 dark:bg-[#0089D0]/15", text: "text-sky-600 dark:text-[#0089D0]", icon: "text-sky-600 dark:text-[#0089D0]" },
  accent: { bg: "bg-sky-50 dark:bg-[#0089D0]/15", text: "text-sky-700 dark:text-[#0089D0]", icon: "text-sky-600 dark:text-[#0089D0]" },
  success: { bg: "bg-green-50 dark:bg-green-500/15", text: "text-green-700 dark:text-green-400", icon: "text-green-600 dark:text-green-400" },
  warning: { bg: "bg-orange-50 dark:bg-orange-500/15", text: "text-orange-700 dark:text-orange-400", icon: "text-orange-600 dark:text-orange-400" },
  danger: { bg: "bg-red-50 dark:bg-red-500/15", text: "text-red-700 dark:text-red-400", icon: "text-red-600 dark:text-red-400" },
};

export function KpiCard({
  label,
  value,
  suffix,
  hint,
  icon: Icon,
  tone = "primary",
  className,
}: {
  label: string;
  value: React.ReactNode;
  suffix?: string;
  hint?: string;
  icon?: LucideIcon;
  tone?: Tone;
  className?: string;
}) {
  const t = tones[tone];
  return (
    <div
      className={cn(
        "bg-white dark:bg-[var(--afm-surface)] border border-slate-200 dark:border-[var(--afm-border)] rounded-xl p-5 shadow-sm",
        className
      )}
    >
      <div className="flex items-center justify-between mb-3">
        <span className="text-xs uppercase tracking-wider text-slate-500 dark:text-[var(--afm-text-muted)] font-medium">
          {label}
        </span>
        {Icon && (
          <div className={cn("w-9 h-9 rounded-lg flex items-center justify-center", t.bg)}>
            <Icon size={18} className={t.icon} />
          </div>
        )}
      </div>
      <div className="flex items-baseline gap-1.5">
        <span className="text-2xl font-bold tabular-nums text-slate-900 dark:text-[var(--afm-text)]">
          {value}
        </span>
        {suffix && <span className={cn("text-sm font-medium", t.text)}>{suffix}</span>}
      </div>
      {hint && <div className="mt-1.5 text-xs text-slate-500 dark:text-[var(--afm-text-muted)]">{hint}</div>}
    </div>
  );
}
