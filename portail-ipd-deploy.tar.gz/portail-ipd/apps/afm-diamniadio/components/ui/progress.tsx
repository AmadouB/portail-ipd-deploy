import { cn } from "@/lib/utils";

type Tone = "primary" | "success" | "warning" | "danger";

const toneClasses: Record<Tone, string> = {
  primary: "bg-sky-600",
  success: "bg-green-600",
  warning: "bg-orange-500",
  danger: "bg-red-600",
};

export function Progress({
  value,
  tone = "primary",
  className,
  showLabel = false,
}: {
  value: number; // 0-100
  tone?: Tone;
  className?: string;
  showLabel?: boolean;
}) {
  const pct = Math.max(0, Math.min(100, value));
  return (
    <div className={cn("w-full", className)}>
      <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
        <div
          className={cn("h-full rounded-full transition-all", toneClasses[tone])}
          style={{ width: `${pct}%` }}
        />
      </div>
      {showLabel && (
        <div className="text-xs text-slate-500 mt-1 tabular-nums">{pct.toFixed(0)} %</div>
      )}
    </div>
  );
}
