"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Dialog } from "@/components/ui/dialog";
import { CommentThread } from "@/components/comments/comment-thread";
import { Badge, statutVariant } from "@/components/ui/badge";
import { apiPath } from "@/lib/api";

export type FieldDef =
  | {
      name: string;
      label: string;
      type: "select";
      options: { value: string; label: string }[];
      defaultValue?: string;
    }
  | {
      name: string;
      label: string;
      type: "text" | "number" | "date" | "textarea";
      defaultValue?: string | number | null;
      suffix?: string;
      min?: number;
      max?: number;
    };

/**
 * Modal d'édition de statut pour une entité quelconque.
 * - `fields` : champs modifiables (whitelistés côté API via /api/update-status)
 * - `showComments` : affiche le fil de discussion associé à l'entité
 */
export function StatusEditModal({
  open,
  onClose,
  entityType,
  entityId,
  title,
  description,
  currentStatus,
  fields,
  showComments = true,
  defaultPeriode,
}: {
  open: boolean;
  onClose: () => void;
  entityType: string;
  entityId: string;
  title: string;
  description?: string;
  currentStatus?: string;
  fields: FieldDef[];
  showComments?: boolean;
  defaultPeriode?: string;
}) {
  const router = useRouter();
  const [values, setValues] = useState<Record<string, string>>(() => {
    const initial: Record<string, string> = {};
    for (const f of fields) {
      initial[f.name] = f.defaultValue != null ? String(f.defaultValue) : "";
    }
    return initial;
  });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [savedFlash, setSavedFlash] = useState(false);

  async function onSave() {
    setError(null);
    setSaving(true);

    // Convert values for API (numbers, null-empty-strings)
    const patch: Record<string, unknown> = {};
    for (const f of fields) {
      const v = values[f.name];
      if (v === "") {
        if (f.type === "date" || f.type === "text" || f.type === "textarea") {
          patch[f.name] = null;
        }
        continue;
      }
      if (f.type === "number") patch[f.name] = Number(v);
      else patch[f.name] = v;
    }

    const res = await fetch(apiPath("/api/update-status"), {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ entityType, id: entityId, patch }),
    });
    setSaving(false);
    if (res.ok) {
      setSavedFlash(true);
      router.refresh();
      setTimeout(() => setSavedFlash(false), 1500);
    } else {
      const body = await res.json().catch(() => ({}));
      setError(body.error ?? "Erreur lors de la mise à jour");
    }
  }

  return (
    <Dialog
      open={open}
      onClose={onClose}
      title={title}
      description={description}
      widthClass={showComments ? "max-w-3xl" : "max-w-lg"}
    >
      <div className={showComments ? "grid grid-cols-1 md:grid-cols-5 gap-5" : ""}>
        {/* Form statut */}
        <div className={showComments ? "md:col-span-2" : ""}>
          {currentStatus && (
            <div className="mb-4 flex items-center gap-2">
              <span className="text-xs text-slate-500 dark:text-[var(--afm-text-muted)]">Statut actuel :</span>
              <Badge variant={statutVariant(currentStatus)}>{currentStatus}</Badge>
            </div>
          )}

          <div className="space-y-3">
            {fields.map((f) => (
              <div key={f.name}>
                <label className="block text-xs font-medium text-slate-700 dark:text-[var(--afm-text)]/85 mb-1">
                  {f.label}
                </label>
                {f.type === "select" ? (
                  <select
                    value={values[f.name]}
                    onChange={(e) => setValues({ ...values, [f.name]: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-[#0089D0]/30 focus:border-[#0089D0] bg-white dark:bg-[var(--afm-surface)]"
                  >
                    <option value="">—</option>
                    {f.options.map((o) => (
                      <option key={o.value} value={o.value}>
                        {o.label}
                      </option>
                    ))}
                  </select>
                ) : f.type === "textarea" ? (
                  <textarea
                    value={values[f.name]}
                    onChange={(e) => setValues({ ...values, [f.name]: e.target.value })}
                    rows={3}
                    className="w-full px-3 py-2 border border-slate-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-[#0089D0]/30 focus:border-[#0089D0]"
                  />
                ) : (
                  <div className="flex items-center gap-2">
                    <input
                      type={f.type}
                      value={values[f.name]}
                      onChange={(e) => setValues({ ...values, [f.name]: e.target.value })}
                      {...("min" in f ? { min: f.min } : {})}
                      {...("max" in f ? { max: f.max } : {})}
                      className="flex-1 px-3 py-2 border border-slate-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-[#0089D0]/30 focus:border-[#0089D0]"
                    />
                    {"suffix" in f && f.suffix && (
                      <span className="text-xs text-slate-500 dark:text-[var(--afm-text-muted)] font-medium">{f.suffix}</span>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>

          {error && (
            <div className="mt-3 text-xs text-red-700 bg-red-50 border border-red-200 rounded-md px-3 py-2">
              {error}
            </div>
          )}

          <div className="mt-5 flex items-center gap-2">
            <button
              onClick={onSave}
              disabled={saving}
              className="px-4 py-2 rounded-lg bg-[#0089D0] hover:bg-[#052A62] text-white text-sm font-medium transition-colors disabled:opacity-60"
              style={{ fontFamily: "var(--font-poppins)" }}
            >
              {saving ? "Enregistrement…" : "Enregistrer"}
            </button>
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-lg text-slate-700 dark:text-[var(--afm-text)]/85 text-sm font-medium hover:bg-slate-100 dark:hover:bg-[var(--afm-border)]/40 transition-colors"
            >
              Fermer
            </button>
            {savedFlash && (
              <span className="text-xs text-green-700 bg-green-50 border border-green-200 rounded-md px-2 py-1">
                Mis à jour ✓
              </span>
            )}
          </div>
        </div>

        {showComments && (
          <div className="md:col-span-3 md:border-l md:border-slate-200 dark:border-[var(--afm-border)] md:pl-5">
            <h3
              className="text-sm font-semibold text-slate-900 dark:text-[var(--afm-text)] mb-3"
              style={{ fontFamily: "var(--font-poppins)" }}
            >
              Historique & commentaires
            </h3>
            <CommentThread
              entityType={entityType}
              entityId={entityId}
              defaultPeriode={defaultPeriode}
            />
          </div>
        )}
      </div>
    </Dialog>
  );
}
