/**
 * Seed AFM Diamniadio — données issues du cahier des charges (20 avril 2026)
 *
 * Objectifs stratégiques :
 *  - 3 M doses / 20 M$ en 2027
 *  - 10 M doses en 2028
 *  - 41 M$ de revenus en 2029
 *  - Levée 30 M€ (0,75 avril / 9 juin / 20 en 2027)
 *  - Jalons OMS : Licence Q2-2026, GMP Q1-2027, PQ Q4-2027
 */

import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  console.log("🌱 Seed AFM Diamniadio — démarrage");

  // ───────── Rôles ─────────
  const roles = [
    { code: "DG", libelle: "Direction Générale", niveau: 100 },
    { code: "DIR_FIN", libelle: "Direction Financière", niveau: 80 },
    { code: "DIR_INDUS", libelle: "Direction Industrielle", niveau: 80 },
    { code: "QA", libelle: "Assurance Qualité", niveau: 60 },
    { code: "PROD", libelle: "Production", niveau: 40 },
    { code: "LECTEUR", libelle: "Lecture seule", niveau: 10 },
  ];
  for (const r of roles) {
    await prisma.role.upsert({ where: { code: r.code }, create: r, update: r });
  }

  // ───────── Admin ─────────
  // Identifiants simples demandés : pasteur / passer
  const passwordHash = await bcrypt.hash("passer", 10);
  await prisma.user.upsert({
    where: { email: "pasteur@afm-diamniadio.sn" },
    create: {
      email: "pasteur@afm-diamniadio.sn",
      passwordHash,
      prenom: "Institut",
      nom: "Pasteur",
      roleCode: "DG",
      titre: "Administrateur AFM Diamniadio",
      actif: true,
    },
    update: { passwordHash },
  });

  // Utilisateurs additionnels (même mot de passe simple)
  const additionalUsers = [
    { email: "admin@afm-diamniadio.sn", prenom: "Amadou", nom: "Bao", roleCode: "DG", titre: "Directeur Général" },
    { email: "fin@afm-diamniadio.sn", prenom: "Fatou", nom: "Sarr", roleCode: "DIR_FIN", titre: "Directrice Financière" },
    { email: "indus@afm-diamniadio.sn", prenom: "Cheikh", nom: "Diop", roleCode: "DIR_INDUS", titre: "Directeur Industriel" },
    { email: "qa@afm-diamniadio.sn", prenom: "Aissatou", nom: "Ndiaye", roleCode: "QA", titre: "Responsable Assurance Qualité" },
    { email: "prod@afm-diamniadio.sn", prenom: "Moussa", nom: "Fall", roleCode: "PROD", titre: "Chef de Production" },
  ];
  for (const u of additionalUsers) {
    await prisma.user.upsert({
      where: { email: u.email },
      create: { ...u, passwordHash, actif: true },
      update: { passwordHash },
    });
  }

  // ═════════ FINANCIER ═════════

  // Levées de fonds (§1.1)
  await prisma.fundingRound.deleteMany();
  await prisma.fundingRound.createMany({
    data: [
      {
        code: "LEVEE-AVR-2026",
        libelle: "Première tranche — subvention de démarrage",
        montantCibleEur: 750_000,
        montantLeveEur: 750_000,
        dateCible: new Date("2026-04-30"),
        dateRealisee: new Date("2026-04-15"),
        statut: "ATTEINT",
        source: "Subvention État / Fondation",
        notes: "Première tranche sécurisée en avril 2026.",
      },
      {
        code: "LEVEE-JUIN-2026",
        libelle: "Deuxième tranche — equity + dette",
        montantCibleEur: 9_000_000,
        montantLeveEur: 5_400_000,
        dateCible: new Date("2026-06-30"),
        statut: "EN_COURS",
        source: "Equity + dette concessionnelle",
        notes: "60 % levés, deux investisseurs en due diligence.",
      },
      {
        code: "LEVEE-2027",
        libelle: "Troisième tranche — CAPEX production",
        montantCibleEur: 20_000_000,
        montantLeveEur: 0,
        dateCible: new Date("2027-03-31"),
        statut: "CIBLE",
        source: "Mix equity / dette / subvention",
        notes: "Financement du CAPEX production GMP 2027.",
      },
    ],
  });

  // Cashflow — 12 derniers mois glissants
  await prisma.cashflowSnapshot.deleteMany();
  const cashflowBase = 2_500_000;
  for (let i = 11; i >= 0; i--) {
    const d = new Date();
    d.setMonth(d.getMonth() - i);
    d.setDate(1);
    d.setHours(0, 0, 0, 0);
    const entrees = 600_000 + Math.random() * 500_000 + (i < 3 ? 750_000 : 0); // pic avr 2026
    const sorties = 400_000 + Math.random() * 350_000;
    const position = cashflowBase + (11 - i) * 150_000 + (entrees - sorties) * 0.3;
    await prisma.cashflowSnapshot.create({
      data: {
        date: d,
        positionEur: Math.round(position),
        entreesEur: Math.round(entrees),
        sortiesEur: Math.round(sorties),
        projection12moisEur: Math.round(position + 18_000_000),
      },
    });
  }

  // Budget CAPEX/OPEX
  await prisma.budgetLine.deleteMany();
  await prisma.budgetLine.createMany({
    data: [
      { categorie: "CAPEX", poste: "Équipements production (EPPI, RO, COMBI)", budgetEur: 8_500_000, consommeEur: 3_200_000, periode: "2026", alerteDepassement: false },
      { categorie: "CAPEX", poste: "Ligne de remplissage aseptique", budgetEur: 4_200_000, consommeEur: 1_100_000, periode: "2026", alerteDepassement: false },
      { categorie: "CAPEX", poste: "Laboratoire contrôle qualité", budgetEur: 1_800_000, consommeEur: 1_850_000, periode: "2026", alerteDepassement: true },
      { categorie: "CAPEX", poste: "HVAC et utilités pharmaceutiques", budgetEur: 3_200_000, consommeEur: 950_000, periode: "2026", alerteDepassement: false },
      { categorie: "CAPEX", poste: "Informatique & automatisation", budgetEur: 900_000, consommeEur: 420_000, periode: "2026", alerteDepassement: false },
      { categorie: "OPEX", poste: "Masse salariale", budgetEur: 2_400_000, consommeEur: 780_000, periode: "2026", alerteDepassement: false },
      { categorie: "OPEX", poste: "Consommables production", budgetEur: 650_000, consommeEur: 190_000, periode: "2026", alerteDepassement: false },
      { categorie: "OPEX", poste: "Énergie et utilités", budgetEur: 380_000, consommeEur: 145_000, periode: "2026", alerteDepassement: false },
      { categorie: "OPEX", poste: "Consultants GMP & validation", budgetEur: 520_000, consommeEur: 380_000, periode: "2026", alerteDepassement: false },
      { categorie: "OPEX", poste: "Audits et certifications", budgetEur: 220_000, consommeEur: 95_000, periode: "2026", alerteDepassement: false },
      { categorie: "OPEX", poste: "Formation équipes", budgetEur: 180_000, consommeEur: 72_000, periode: "2026", alerteDepassement: false },
      { categorie: "OPEX", poste: "Maintenance préventive", budgetEur: 340_000, consommeEur: 88_000, periode: "2026", alerteDepassement: false },
    ],
  });

  // ═════════ INDUSTRIEL ═════════

  // Équipements (coordonnées Diamniadio 14.72°N, -17.22°W)
  await prisma.qualification.deleteMany();
  await prisma.equipment.deleteMany();

  const eppi = await prisma.equipment.create({
    data: {
      code: "EQ-EPPI-01", libelle: "EPPI — Eau pour préparations injectables", type: "EPPI",
      zone: "Zone C — Utilités", lat: 14.7205, lng: -17.2218,
      statut: "OPERATIONNEL", criticite: "CRITIQUE",
      dateInstallation: new Date("2025-11-10"),
      notes: "Capacité 2 000 L/h, vapeur pure intégrée.",
    },
  });
  const ro = await prisma.equipment.create({
    data: {
      code: "EQ-RO-01", libelle: "Osmose inverse — prétraitement eau", type: "RO",
      zone: "Zone C — Utilités", lat: 14.7207, lng: -17.2216,
      statut: "OPERATIONNEL", criticite: "CRITIQUE",
      dateInstallation: new Date("2025-10-02"),
    },
  });
  const combi = await prisma.equipment.create({
    data: {
      code: "EQ-COMBI-01", libelle: "COMBI — ligne remplissage / bouchage", type: "COMBI",
      zone: "Zone A — Remplissage aseptique", lat: 14.7202, lng: -17.2221,
      statut: "MAINTENANCE", criticite: "CRITIQUE",
      dateInstallation: new Date("2026-02-20"),
      notes: "Qualification OQ en cours, incident stabilité en T1-2026.",
    },
  });
  const laveuse = await prisma.equipment.create({
    data: {
      code: "EQ-LAV-01", libelle: "Laveuse flacons", type: "LAVEUSE_FLACONS",
      zone: "Zone A — Remplissage aseptique", lat: 14.7201, lng: -17.2220,
      statut: "OPERATIONNEL", criticite: "IMPORTANTE",
      dateInstallation: new Date("2026-01-15"),
    },
  });
  const autoclave = await prisma.equipment.create({
    data: {
      code: "EQ-AUTO-01", libelle: "Autoclave stérilisation", type: "AUTRE",
      zone: "Zone B — Stérilisation", lat: 14.7204, lng: -17.2215,
      statut: "INSTALLATION", criticite: "CRITIQUE",
      dateInstallation: new Date("2026-05-10"),
    },
  });

  const eqList = [eppi, ro, combi, laveuse, autoclave];
  const phases: ("IQ" | "OQ" | "PQ")[] = ["IQ", "OQ", "PQ"];
  const qualifData: Parameters<typeof prisma.qualification.create>[0]["data"][] = [];
  for (const eq of eqList) {
    for (const phase of phases) {
      const isDone = eq.code === "EQ-EPPI-01" || eq.code === "EQ-RO-01" || (eq.code === "EQ-LAV-01" && phase !== "PQ");
      const isInProgress = eq.code === "EQ-COMBI-01" && phase !== "PQ";
      const statut = isDone ? "FAIT" : isInProgress ? "EN_COURS" : eq.code === "EQ-AUTO-01" ? "A_FAIRE" : "A_FAIRE";
      qualifData.push({
        equipmentId: eq.id,
        phase,
        statut,
        datePrevue: new Date(phase === "IQ" ? "2026-02-15" : phase === "OQ" ? "2026-06-15" : "2026-10-15"),
        dateRealisee: isDone ? new Date(phase === "IQ" ? "2026-02-10" : phase === "OQ" ? "2026-06-08" : "2026-10-10") : null,
        operateur: isDone ? "Équipe QA" : null,
      });
    }
  }
  for (const q of qualifData) await prisma.qualification.create({ data: q });

  // SOP
  await prisma.sOP.deleteMany();
  await prisma.sOP.createMany({
    data: [
      { code: "SOP-PROD-001", titre: "Remplissage aseptique — ligne COMBI", version: "2.1", statut: "VALIDE", dateRevision: new Date("2026-01-15"), dateProchainRevision: new Date("2027-01-15"), approbateur: "Aissatou Ndiaye", categorie: "Production" },
      { code: "SOP-PROD-002", titre: "Stérilisation par autoclave", version: "1.3", statut: "EN_REVUE", dateRevision: new Date("2026-03-20"), dateProchainRevision: new Date("2027-03-20"), approbateur: "Aissatou Ndiaye", categorie: "Production" },
      { code: "SOP-QUAL-001", titre: "Contrôle microbiologique eau EPPI", version: "3.0", statut: "VALIDE", dateRevision: new Date("2025-12-10"), dateProchainRevision: new Date("2026-12-10"), approbateur: "Aissatou Ndiaye", categorie: "Qualité" },
      { code: "SOP-QUAL-002", titre: "Libération lots pharmaceutiques", version: "2.0", statut: "VALIDE", dateRevision: new Date("2026-02-05"), dateProchainRevision: new Date("2027-02-05"), approbateur: "Aissatou Ndiaye", categorie: "Qualité" },
      { code: "SOP-QUAL-003", titre: "Gestion des déviations qualité", version: "1.0", statut: "BROUILLON", dateRevision: new Date("2026-04-01"), approbateur: "—", categorie: "Qualité" },
      { code: "SOP-MAINT-001", titre: "Maintenance préventive EPPI/RO", version: "1.5", statut: "VALIDE", dateRevision: new Date("2026-01-22"), dateProchainRevision: new Date("2026-07-22"), approbateur: "Cheikh Diop", categorie: "Maintenance" },
      { code: "SOP-MAINT-002", titre: "Nettoyage CIP/SIP ligne COMBI", version: "2.2", statut: "VALIDE", dateRevision: new Date("2026-02-18"), dateProchainRevision: new Date("2027-02-18"), approbateur: "Cheikh Diop", categorie: "Maintenance" },
      { code: "SOP-HSE-001", titre: "Gestion des incidents électriques", version: "1.1", statut: "VALIDE", dateRevision: new Date("2025-11-30"), dateProchainRevision: new Date("2026-11-30"), approbateur: "Cheikh Diop", categorie: "HSE" },
      { code: "SOP-ENV-001", titre: "Monitoring environnemental zones classées", version: "2.0", statut: "EN_REVUE", dateRevision: new Date("2026-03-12"), dateProchainRevision: new Date("2027-03-12"), approbateur: "Aissatou Ndiaye", categorie: "Qualité" },
      { code: "SOP-LOG-001", titre: "Réception et stockage matières premières", version: "1.0", statut: "VALIDE", dateRevision: new Date("2026-01-05"), dateProchainRevision: new Date("2027-01-05"), approbateur: "Moussa Fall", categorie: "Logistique" },
    ],
  });

  // ═════════ CONFORMITÉ ═════════

  await prisma.regulatoryMilestone.deleteMany();
  await prisma.regulatoryMilestone.createMany({
    data: [
      {
        code: "JALON-LICENCE-ARP",
        libelle: "Licence d'exploitation ARP Sénégal",
        autorite: "ARP",
        type: "LICENCE",
        dateCible: new Date("2026-06-30"),
        statut: "EN_COURS",
        progression: 70,
        notes: "Dossier technique déposé, inspection site Q2-2026.",
      },
      {
        code: "JALON-GMP-CERTIF",
        libelle: "Certificat GMP (Good Manufacturing Practice)",
        autorite: "ARP",
        type: "GMP",
        dateCible: new Date("2027-03-31"),
        statut: "PLANIFIE",
        progression: 20,
        notes: "Suit l'obtention de la licence, mock inspection prévue T4-2026.",
      },
      {
        code: "JALON-PQ-OMS",
        libelle: "Préqualification OMS (WHO PQ)",
        autorite: "OMS",
        type: "PQ",
        dateCible: new Date("2027-12-31"),
        statut: "PLANIFIE",
        progression: 10,
        notes: "Dossier technique en préparation, nécessite 3 lots validés.",
      },
    ],
  });

  await prisma.deviation.deleteMany();
  await prisma.deviation.createMany({
    data: [
      { code: "DEV-2026-001", titre: "Dérive de conductivité eau EPPI", severite: "MAJEURE", dateDetection: new Date("2026-02-14"), statut: "CLOSE", actionCorrective: "Recalibrage sonde + révision SOP-QUAL-001.", responsable: "Aissatou Ndiaye", dateResolution: new Date("2026-02-20") },
      { code: "DEV-2026-002", titre: "Fuite mineure joint COMBI", severite: "MINEURE", dateDetection: new Date("2026-03-02"), statut: "CLOSE", actionCorrective: "Remplacement joint, inspection préventive.", responsable: "Cheikh Diop", dateResolution: new Date("2026-03-03") },
      { code: "DEV-2026-003", titre: "Alerte particules zone A remplissage", severite: "MAJEURE", dateDetection: new Date("2026-03-28"), statut: "EN_TRAITEMENT", actionCorrective: "Enquête HVAC en cours, filtration à renforcer.", responsable: "Cheikh Diop" },
      { code: "DEV-2026-004", titre: "Écart température stockage lot 2026-014", severite: "MINEURE", dateDetection: new Date("2026-04-08"), statut: "EN_TRAITEMENT", actionCorrective: "Impact qualité en cours d'évaluation.", responsable: "Aissatou Ndiaye" },
      { code: "DEV-2026-005", titre: "Échec test intégrité filtre 0,22 µm", severite: "CRITIQUE", dateDetection: new Date("2026-04-15"), statut: "OUVERTE", actionCorrective: "Lot en quarantaine, investigation approfondie.", responsable: "Aissatou Ndiaye" },
      { code: "DEV-2026-006", titre: "Documentation SOP obsolète identifiée", severite: "MINEURE", dateDetection: new Date("2026-04-18"), statut: "OUVERTE", actionCorrective: "Mise à jour programmée.", responsable: "Aissatou Ndiaye" },
    ],
  });

  await prisma.audit.deleteMany();
  await prisma.audit.createMany({
    data: [
      { code: "AUD-2026-INT-01", type: "INTERNE", libelle: "Audit interne SOP Production", datePrevue: new Date("2026-02-18"), dateRealisee: new Date("2026-02-19"), statut: "CLOS", rapport: "2 écarts mineurs, actions en cours.", auditeur: "Aissatou Ndiaye" },
      { code: "AUD-2026-MOCK-01", type: "MOCK", libelle: "Mock inspection ARP (préparation licence)", datePrevue: new Date("2026-05-25"), statut: "PLANIFIE", auditeur: "Consultant externe PhD. Diallo" },
      { code: "AUD-2026-ARP-01", type: "ARP", libelle: "Inspection ARP — octroi licence d'exploitation", datePrevue: new Date("2026-06-15"), statut: "PLANIFIE", auditeur: "Autorité de Régulation Pharmaceutique" },
      { code: "AUD-2026-MOCK-02", type: "MOCK", libelle: "Mock inspection GMP (préparation T1-2027)", datePrevue: new Date("2026-11-10"), statut: "PLANIFIE" },
    ],
  });

  // ═════════ RISQUES ═════════

  await prisma.risk.deleteMany();
  await prisma.risk.createMany({
    data: [
      { code: "RSK-CONT-01", categorie: "CONTAMINATION", libelle: "Contamination Pseudomonas eau EPPI", description: "Risque microbiologique critique — monitoring hebdomadaire.", probabilite: 3, impact: 5, score: 15, mitigation: "Monitoring environnemental renforcé + seuils alertes IoT.", statut: "EN_MITIGATION", responsable: "Aissatou Ndiaye" },
      { code: "RSK-CONT-02", categorie: "CONTAMINATION", libelle: "Contamination croisée zones classées", description: "Risque transferts entre zones A/B/C.", probabilite: 2, impact: 5, score: 10, mitigation: "Flux matériel/personnel séparés + sas pressurisés.", statut: "SOUS_CONTROLE", responsable: "Aissatou Ndiaye" },
      { code: "RSK-ENE-01", categorie: "ENERGIE", libelle: "Coupures Senelec prolongées", description: "Historique de coupures récurrentes sur Diamniadio.", probabilite: 4, impact: 4, score: 16, mitigation: "UPS + groupe électrogène + ligne sécurisée Senelec en cours.", statut: "EN_MITIGATION", responsable: "Cheikh Diop" },
      { code: "RSK-ENE-02", categorie: "ENERGIE", libelle: "Défaillance UPS critique", probabilite: 2, impact: 5, score: 10, mitigation: "Maintenance préventive trimestrielle, redondance N+1.", statut: "SOUS_CONTROLE", responsable: "Cheikh Diop" },
      { code: "RSK-SUP-01", categorie: "SUPPLY", libelle: "Rupture Drug Substance Biomanguinhos", description: "Dépendance fournisseur unique pour DS fièvre jaune.", probabilite: 3, impact: 5, score: 15, mitigation: "Stock de sécurité 6 mois + back-up fournisseur en qualification.", statut: "EN_MITIGATION", responsable: "Moussa Fall" },
      { code: "RSK-SUP-02", categorie: "SUPPLY", libelle: "Rupture consommables (flacons, bouchons)", probabilite: 2, impact: 3, score: 6, mitigation: "Double sourcing actif.", statut: "SOUS_CONTROLE", responsable: "Moussa Fall" },
      { code: "RSK-QUA-01", categorie: "QUALITE", libelle: "Rejet de lots post-production", probabilite: 2, impact: 4, score: 8, mitigation: "Contrôles in-process renforcés, libération paramétrique.", statut: "EN_MITIGATION", responsable: "Aissatou Ndiaye" },
      { code: "RSK-QUA-02", categorie: "QUALITE", libelle: "Retard préqualification OMS", probabilite: 3, impact: 4, score: 12, mitigation: "Pré-submission meeting OMS T3-2026, dossier anticipé.", statut: "EN_MITIGATION", responsable: "Aissatou Ndiaye" },
      { code: "RSK-QUA-03", categorie: "QUALITE", libelle: "Écart stabilité produit fini", probabilite: 2, impact: 4, score: 8, mitigation: "Études stabilité temps réel + accéléré.", statut: "IDENTIFIE", responsable: "Aissatou Ndiaye" },
      { code: "RSK-AUTRE-01", categorie: "AUTRE", libelle: "Turn-over équipes GMP qualifiées", probabilite: 3, impact: 3, score: 9, mitigation: "Plan de rétention + académie interne GMP.", statut: "EN_MITIGATION", responsable: "Amadou Bao" },
    ],
  });

  // Relevés environnementaux — 30 jours
  await prisma.environmentalReading.deleteMany();
  const zones = ["Zone A — Remplissage", "Zone B — Stérilisation", "Zone C — Utilités"];
  const params = [
    { parametre: "TEMP", unite: "°C", base: 20, spread: 2, min: 18, max: 22 },
    { parametre: "HUMIDITE", unite: "%", base: 45, spread: 8, min: 30, max: 60 },
    { parametre: "PRESSION", unite: "Pa", base: 15, spread: 3, min: 10, max: 20 },
    { parametre: "PARTICULES", unite: "/m³", base: 1500, spread: 800, min: 0, max: 3520 },
  ];
  const readings: Parameters<typeof prisma.environmentalReading.createMany>[0]["data"] = [];
  const now = new Date();
  for (let d = 29; d >= 0; d--) {
    const ts = new Date(now);
    ts.setDate(ts.getDate() - d);
    ts.setHours(12, 0, 0, 0);
    for (const zone of zones) {
      for (const p of params) {
        const valeur = Number((p.base + (Math.random() - 0.5) * p.spread * 2).toFixed(1));
        readings.push({
          zone, parametre: p.parametre, valeur, unite: p.unite,
          seuilMin: p.min, seuilMax: p.max, timestamp: ts,
        });
      }
    }
  }
  await prisma.environmentalReading.createMany({ data: readings });

  await prisma.powerIncident.deleteMany();
  await prisma.powerIncident.createMany({
    data: [
      { date: new Date("2026-02-03T14:22:00"), dureeMin: 42, source: "SENELEC", impact: "MINEUR", zones: "Zone C", notes: "Basculement UPS + groupe OK, aucun impact production." },
      { date: new Date("2026-03-11T09:05:00"), dureeMin: 180, source: "SENELEC", impact: "MAJEUR", zones: "Zone A, Zone B", notes: "UPS 30 min + groupe 2h30, lot en cours mis en attente." },
      { date: new Date("2026-04-02T21:40:00"), dureeMin: 15, source: "SENELEC", impact: "AUCUN", zones: "Zone C", notes: "Micro-coupure, UPS a basculé sans incident." },
    ],
  });

  await prisma.stockLevel.deleteMany();
  await prisma.stockLevel.createMany({
    data: [
      { produit: "Drug Substance Fièvre Jaune", lot: "BM-2026-011", quantite: 12_000, unite: "flacons DS", seuilAlerte: 8_000, fournisseur: "BIOMANGUINHOS", dateExpiration: new Date("2027-06-30") },
      { produit: "Drug Substance Fièvre Jaune", lot: "BM-2026-012", quantite: 6_200, unite: "flacons DS", seuilAlerte: 8_000, fournisseur: "BIOMANGUINHOS", dateExpiration: new Date("2027-09-30") },
      { produit: "Flacons 2R stériles", quantite: 180_000, unite: "unités", seuilAlerte: 100_000, fournisseur: "AUTRE" },
      { produit: "Bouchons caoutchouc 13mm", quantite: 95_000, unite: "unités", seuilAlerte: 100_000, fournisseur: "AUTRE" },
      { produit: "Capsules aluminium", quantite: 210_000, unite: "unités", seuilAlerte: 100_000, fournisseur: "AUTRE" },
      { produit: "Filtres 0,22 µm (stérilisants)", quantite: 340, unite: "cartouches", seuilAlerte: 150, fournisseur: "AUTRE" },
    ],
  });

  // ═════════ PRODUCTION ═════════

  await prisma.productionTarget.deleteMany();
  await prisma.productionTarget.createMany({
    data: [
      { annee: 2027, cibleDoses: 3_000_000, realisDoses: 0, revenusEurCible: 18_000_000, revenusEurRealise: 0, commentaire: "Année de démarrage GMP — 20 M$ selon OGSM, valorisation ~18 M€." },
      { annee: 2028, cibleDoses: 10_000_000, realisDoses: 0, revenusEurCible: 32_000_000, revenusEurRealise: 0, commentaire: "Montée en cadence." },
      { annee: 2029, cibleDoses: 14_000_000, realisDoses: 0, revenusEurCible: 37_000_000, revenusEurRealise: 0, commentaire: "41 M$ OGSM ≈ 37 M€." },
    ],
  });

  await prisma.productionBatch.deleteMany();
  const batchData: Parameters<typeof prisma.productionBatch.createMany>[0]["data"] = [];
  for (let i = 0; i < 14; i++) {
    const dateProd = new Date();
    dateProd.setDate(dateProd.getDate() - i * 5);
    const statut = i < 2 ? "EN_COURS" : i % 7 === 0 ? "REJETE" : i % 5 === 0 ? "REPRISE" : "CONFORME";
    batchData.push({
      numeroLot: `LOT-2026-${String(100 - i).padStart(3, "0")}`,
      dateProduction: dateProd,
      volumeDoses: 45_000 + Math.floor(Math.random() * 15_000),
      statut,
      rendement: statut === "REJETE" ? 62 + Math.random() * 10 : 88 + Math.random() * 10,
      operateur: i % 2 === 0 ? "Moussa Fall" : "Équipe B",
    });
  }
  await prisma.productionBatch.createMany({ data: batchData });

  // OEE — 30 jours pour les 4 équipements critiques
  await prisma.oEEMetric.deleteMany();
  const oeeEq = [eppi, ro, combi, laveuse];
  const oeeData: Parameters<typeof prisma.oEEMetric.createMany>[0]["data"] = [];
  for (let d = 29; d >= 0; d--) {
    const ts = new Date();
    ts.setDate(ts.getDate() - d);
    ts.setHours(0, 0, 0, 0);
    for (const eq of oeeEq) {
      const base = eq.code === "EQ-COMBI-01" ? 70 : 85;
      const dispo = Math.min(100, base + (Math.random() - 0.3) * 15);
      const perf = Math.min(100, base + (Math.random() - 0.3) * 12);
      const qual = Math.min(100, 92 + (Math.random() - 0.3) * 8);
      const oee = (dispo * perf * qual) / 10_000;
      oeeData.push({
        date: ts,
        equipmentId: eq.id,
        disponibilite: Number(dispo.toFixed(1)),
        performance: Number(perf.toFixed(1)),
        qualite: Number(qual.toFixed(1)),
        oee: Number(oee.toFixed(1)),
      });
    }
  }
  await prisma.oEEMetric.createMany({ data: oeeData });

  // ═════════ COMMENTAIRES PÉRIODIQUES ═════════

  await prisma.comment.deleteMany();

  const admin = await prisma.user.findUnique({ where: { email: "admin@afm-diamniadio.sn" } });
  const qa = await prisma.user.findUnique({ where: { email: "qa@afm-diamniadio.sn" } });
  const indus = await prisma.user.findUnique({ where: { email: "indus@afm-diamniadio.sn" } });

  const fullName = (u: { prenom: string; nom: string }) => `${u.prenom} ${u.nom}`;

  // Récupérer quelques entités pour leur attacher des commentaires
  const devCritique = await prisma.deviation.findUnique({ where: { code: "DEV-2026-005" } });
  const devParticules = await prisma.deviation.findUnique({ where: { code: "DEV-2026-003" } });
  const jalonLicence = await prisma.regulatoryMilestone.findUnique({ where: { code: "JALON-LICENCE-ARP" } });
  const jalonGmp = await prisma.regulatoryMilestone.findUnique({ where: { code: "JALON-GMP-CERTIF" } });
  const riskSenelec = await prisma.risk.findUnique({ where: { code: "RSK-ENE-01" } });
  const riskBioman = await prisma.risk.findUnique({ where: { code: "RSK-SUP-01" } });
  const eqCombi = await prisma.equipment.findUnique({ where: { code: "EQ-COMBI-01" } });
  const fundJuin = await prisma.fundingRound.findUnique({ where: { code: "LEVEE-JUIN-2026" } });

  const comments: Parameters<typeof prisma.comment.createMany>[0]["data"] = [];

  if (devCritique && qa) {
    comments.push(
      { entityType: "deviation", entityId: devCritique.id, periode: "2026-04", auteurId: qa.id, auteurNom: fullName(qa), contenu: "Lot en quarantaine confirmée. Investigation démarrée avec équipe production + fournisseur filtre." },
      { entityType: "deviation", entityId: devCritique.id, periode: "2026-04", auteurId: admin!.id, auteurNom: fullName(admin!), contenu: "Revue hebdo qualité : prévoir revue comité avant clôture. Impact potentiel sur validation OQ COMBI." }
    );
  }
  if (devParticules && qa && indus) {
    comments.push(
      { entityType: "deviation", entityId: devParticules.id, periode: "2026-03", auteurId: qa.id, auteurNom: fullName(qa), contenu: "Alerte particules récurrente depuis 2 semaines. Filtres HEPA à auditer." },
      { entityType: "deviation", entityId: devParticules.id, periode: "2026-04", auteurId: indus.id, auteurNom: fullName(indus), contenu: "Diagnostic HVAC en cours. Commande filtres H14 passée, livraison prévue S18." }
    );
  }
  if (jalonLicence && admin && qa) {
    comments.push(
      { entityType: "milestone", entityId: jalonLicence.id, periode: "2026-T1", auteurId: admin.id, auteurNom: fullName(admin), contenu: "T1 : dossier technique finalisé. Échanges préliminaires avec ARP positifs." },
      { entityType: "milestone", entityId: jalonLicence.id, periode: "2026-T2", auteurId: qa.id, auteurNom: fullName(qa), contenu: "Mock inspection planifiée 25 mai. Préparation équipe QA + documentation site master file." }
    );
  }
  if (jalonGmp && qa) {
    comments.push(
      { entityType: "milestone", entityId: jalonGmp.id, periode: "2026-T2", auteurId: qa.id, auteurNom: fullName(qa), contenu: "Dépend de l'obtention de la licence. Plan de montée en maturité GMP élaboré." }
    );
  }
  if (riskSenelec && indus) {
    comments.push(
      { entityType: "risk", entityId: riskSenelec.id, periode: "2026-03", auteurId: indus.id, auteurNom: fullName(indus), contenu: "Incident du 11 mars (3h) : UPS + groupe OK mais lot en attente. Accélérer demande ligne sécurisée." },
      { entityType: "risk", entityId: riskSenelec.id, periode: "2026-04", auteurId: indus.id, auteurNom: fullName(indus), contenu: "Ligne sécurisée Senelec : étude de faisabilité reçue. Budget complémentaire à valider T2." }
    );
  }
  if (riskBioman && admin) {
    comments.push(
      { entityType: "risk", entityId: riskBioman.id, periode: "2026-T1", auteurId: admin.id, auteurNom: fullName(admin), contenu: "Revue stock Biomanguinhos : 18 200 flacons DS au total, 6 mois de visibilité. Back-up fournisseur en négociation." }
    );
  }
  if (eqCombi && indus) {
    comments.push(
      { entityType: "equipment", entityId: eqCombi.id, periode: "2026-03", auteurId: indus.id, auteurNom: fullName(indus), contenu: "Incident joint détecté en maintenance préventive. Remplacement effectué, test étanchéité OK." },
      { entityType: "equipment", entityId: eqCombi.id, periode: "2026-04", auteurId: indus.id, auteurNom: fullName(indus), contenu: "Qualification OQ suspendue suite à dérive stabilité. Investigation en cours avec fournisseur." }
    );
  }
  if (fundJuin && admin) {
    comments.push(
      { entityType: "funding_round", entityId: fundJuin.id, periode: "2026-04", auteurId: admin.id, auteurNom: fullName(admin), contenu: "5.4 M€ sécurisés. Deux investisseurs en due diligence pour combler les 3.6 M€ restants." }
    );
  }

  // Commentaires budgétaires — revues mensuelles sur postes sensibles
  const fin = await prisma.user.findUnique({ where: { email: "fin@afm-diamniadio.sn" } });
  const budgetLabo = await prisma.budgetLine.findFirst({ where: { poste: "Laboratoire contrôle qualité" } });
  const budgetCombi = await prisma.budgetLine.findFirst({ where: { poste: "Ligne de remplissage aseptique" } });
  const budgetConsultants = await prisma.budgetLine.findFirst({ where: { poste: "Consultants GMP & validation" } });

  if (budgetLabo && fin && admin) {
    comments.push(
      { entityType: "budget_line", entityId: budgetLabo.id, periode: "2026-03", auteurId: fin.id, auteurNom: fullName(fin), contenu: "Dépassement de 50 k€ constaté : équipements spectro plus coûteux qu'estimé. Demande validation budget additionnel." },
      { entityType: "budget_line", entityId: budgetLabo.id, periode: "2026-04", auteurId: admin.id, auteurNom: fullName(admin), contenu: "DG valide dépassement. Revoir les quotas du poste lors de la revue T2." }
    );
  }
  if (budgetCombi && fin) {
    comments.push(
      { entityType: "budget_line", entityId: budgetCombi.id, periode: "2026-04", auteurId: fin.id, auteurNom: fullName(fin), contenu: "26 % de consommation à J120. Tendance saine, acompte fournisseur à payer fin avril." }
    );
  }
  if (budgetConsultants && fin) {
    comments.push(
      { entityType: "budget_line", entityId: budgetConsultants.id, periode: "2026-04", auteurId: fin.id, auteurNom: fullName(fin), contenu: "73 % consommés — anticiper renforts pour préparation mock inspection ARP Q2." }
    );
  }

  // Qualifications COMBI OQ
  const prod = await prisma.user.findUnique({ where: { email: "prod@afm-diamniadio.sn" } });
  const combiRef = await prisma.equipment.findUnique({ where: { code: "EQ-COMBI-01" } });
  if (combiRef) {
    const oqCombi = await prisma.qualification.findFirst({ where: { equipmentId: combiRef.id, phase: "OQ" } });
    if (oqCombi && qa) {
      comments.push(
        { entityType: "qualification", entityId: oqCombi.id, periode: "2026-03", auteurId: qa.id, auteurNom: fullName(qa), contenu: "Essais OQ en cours : 2 tests sur 6 validés. Problème de stabilité identifié sur le test d'endurance." },
        { entityType: "qualification", entityId: oqCombi.id, periode: "2026-04", auteurId: qa.id, auteurNom: fullName(qa), contenu: "Tests OQ suspendus temporairement. Attente retour fournisseur sur la déviation DEV-2026-005." }
      );
    }
  }

  // SOP (revues trimestrielles)
  const sopRempl = await prisma.sOP.findFirst({ where: { code: "SOP-PROD-001" } });
  const sopDeviations = await prisma.sOP.findFirst({ where: { code: "SOP-QUAL-003" } });
  if (sopRempl && qa) {
    comments.push(
      { entityType: "sop", entityId: sopRempl.id, periode: "2026-T1", auteurId: qa.id, auteurNom: fullName(qa), contenu: "Revue annuelle validée. Version 2.1 approuvée, mise en application au 15 janvier 2026." }
    );
  }
  if (sopDeviations && qa && admin) {
    comments.push(
      { entityType: "sop", entityId: sopDeviations.id, periode: "2026-T2", auteurId: qa.id, auteurNom: fullName(qa), contenu: "SOP en brouillon — à finaliser avant mock inspection ARP du 25 mai." },
      { entityType: "sop", entityId: sopDeviations.id, periode: "2026-T2", auteurId: admin.id, auteurNom: fullName(admin), contenu: "Priorité haute : cette SOP est requise pour la licence d'exploitation." }
    );
  }

  // Audits
  const auditMock = await prisma.audit.findFirst({ where: { code: "AUD-2026-MOCK-01" } });
  const auditArp = await prisma.audit.findFirst({ where: { code: "AUD-2026-ARP-01" } });
  if (auditMock && qa) {
    comments.push(
      { entityType: "audit", entityId: auditMock.id, periode: "2026-T2", auteurId: qa.id, auteurNom: fullName(qa), contenu: "Préparation en cours : revue documentaire site master file, plan de réponse aux observations." }
    );
  }
  if (auditArp && admin && qa) {
    comments.push(
      { entityType: "audit", entityId: auditArp.id, periode: "2026-T2", auteurId: admin.id, auteurNom: fullName(admin), contenu: "Date confirmée par l'ARP : 15 juin 2026. Répétition mock inspection prévue 5 juin." },
      { entityType: "audit", entityId: auditArp.id, periode: "2026-T2", auteurId: qa.id, auteurNom: fullName(qa), contenu: "Équipes QA + Production mobilisées 10-17 juin. Walkthrough prévu J-1." }
    );
  }

  // Incidents électriques
  const incidentMajeur = await prisma.powerIncident.findFirst({ where: { dureeMin: 180 } });
  if (incidentMajeur && indus) {
    comments.push(
      { entityType: "power_incident", entityId: incidentMajeur.id, periode: "2026-03", auteurId: indus.id, auteurNom: fullName(indus), contenu: "REX : procédure de repli UPS → groupe validée mais lot LOT-2026-089 mis en attente 2h. Revoir contrat Senelec." }
    );
  }

  // Stocks Biomanguinhos
  const stockBiomBas = await prisma.stockLevel.findFirst({
    where: { fournisseur: "BIOMANGUINHOS", lot: "BM-2026-012" },
  });
  if (stockBiomBas && prod) {
    comments.push(
      { entityType: "stock_level", entityId: stockBiomBas.id, periode: "2026-04", auteurId: prod.id, auteurNom: fullName(prod), contenu: "Lot BM-2026-012 sous seuil d'alerte. Commande complémentaire à passer avant fin avril." }
    );
  }

  // Cibles de production
  const target2027 = await prisma.productionTarget.findFirst({ where: { annee: 2027 } });
  if (target2027 && admin) {
    comments.push(
      { entityType: "production_target", entityId: target2027.id, periode: "2026-T2", auteurId: admin.id, auteurNom: fullName(admin), contenu: "Cible 2027 confirmée à 3 M doses après revue OGSM. Dépend du certificat GMP Q1 2027 et PQ OMS Q4 2027." }
    );
  }

  // Lot rejeté
  const lotRejete = await prisma.productionBatch.findFirst({ where: { statut: "REJETE" } });
  if (lotRejete && qa) {
    comments.push(
      { entityType: "production_batch", entityId: lotRejete.id, periode: "2026-04", auteurId: qa.id, auteurNom: fullName(qa), contenu: "Rejet suite à échec test intégrité filtre (DEV-2026-005). Lot mis en quarantaine, pas de libération." }
    );
  }

  await prisma.comment.createMany({ data: comments });

  // ═════════ OGSM — Matrice stratégique ═════════

  await prisma.ogsmMesure.deleteMany();
  await prisma.ogsmAction.deleteMany();
  await prisma.ogsmAxe.deleteMany();
  await prisma.ogsmGoal.deleteMany();
  await prisma.ogsmObjective.deleteMany();

  // Objectif global (cahier §1.1)
  const objective = await prisma.ogsmObjective.create({
    data: {
      libelle: "Lancement de la production GMP de routine en 2027",
      description:
        "Industrialisation pharmaceutique continentale — unité AFM vaccins fièvre jaune, Vaccinopole de Diamniadio.",
      annee: 2027,
      dateCible: new Date("2027-12-31"),
    },
  });

  // Buts quantifiés (BUTS / Goals) — source : OGSM officiel AFM 19.04.2026
  await prisma.ogsmGoal.createMany({
    data: [
      { objectiveId: objective.id, code: "BUT-DOSES-2027", libelle: "Produire 3 millions de doses en 2027", cibleValeur: 3_000_000, cibleUnite: "doses", realiseValeur: 0, dateCible: new Date("2027-12-31"), statut: "A_FAIRE" },
      { objectiveId: objective.id, code: "BUT-AVMA-2027", libelle: "Obtenir ≥ 20 MUSD via l'initiative AVMA en 2027", cibleValeur: 20, cibleUnite: "MUSD", realiseValeur: 0, dateCible: new Date("2027-12-31"), statut: "A_FAIRE" },
      { objectiveId: objective.id, code: "BUT-DOSES-2028", libelle: "Produire ≥ 10 millions de doses en 2028", cibleValeur: 10_000_000, cibleUnite: "doses", realiseValeur: 0, dateCible: new Date("2028-12-31"), statut: "A_FAIRE" },
      { objectiveId: objective.id, code: "BUT-REV-2029", libelle: "Générer ≥ 41 M€ de revenus cumulés à horizon 2029", cibleValeur: 41, cibleUnite: "M€", realiseValeur: 0, dateCible: new Date("2029-12-31"), statut: "A_FAIRE" },
      { objectiveId: objective.id, code: "BUT-PQ-OMS", libelle: "Obtenir la PQ OMS en 2027 (priorité stratégique majeure)", cibleValeur: 100, cibleUnite: "%", realiseValeur: 10, dateCible: new Date("2027-12-31"), statut: "EN_COURS" },
      { objectiveId: objective.id, code: "BUT-FINANCEMENT", libelle: "Sécuriser le gap de financement 9–17 M€ + bonus AVMA 20 M€", cibleValeur: 30, cibleUnite: "M€", realiseValeur: 6.15, dateCible: new Date("2027-03-31"), statut: "EN_COURS" },
    ],
  });

  // 7 axes stratégiques (source : OGSM GLOBAL AFM)
  const axeFin = await prisma.ogsmAxe.create({
    data: { objectiveId: objective.id, code: "AXE-FIN", libelle: "Sécuriser le financement (CRITIQUE)", description: "Lever 30 M€ : 0,75 M€ + 9 M€ BIS + 20 M€ AVMA", ordre: 1, couleur: "#0089D0" },
  });
  const axeIndus = await prisma.ogsmAxe.create({
    data: { objectiveId: objective.id, code: "AXE-INDUS", libelle: "Rendre l'usine pleinement opérationnelle (excellence industrielle)", description: "Corrections techniques, qualifications IQ/OQ/PQ, SOP, transfert technologique", ordre: 2, couleur: "#052A62" },
  });
  const axeRisq = await prisma.ogsmAxe.create({
    data: { objectiveId: objective.id, code: "AXE-RISQ", libelle: "Mitiger les risques (qualité, techniques, opérationnels)", description: "Alimentation Senelec, back-up DS Biomanguinhos, QMS, gouvernance", ordre: 3, couleur: "#ea580c" },
  });
  const axePq = await prisma.ogsmAxe.create({
    data: { objectiveId: objective.id, code: "AXE-PQ", libelle: "Obtenir la PQ OMS en 2027 (priorité stratégique majeure)", description: "Licence Q2 2026 · GMP Q1 2027 · AMM Q1 2027 · PPQ juin 2027 · PQ OMS oct. 2027", ordre: 4, couleur: "#16a34a" },
  });
  const axeRev = await prisma.ogsmAxe.create({
    data: { objectiveId: objective.id, code: "AXE-REV", libelle: "Diversifier les opportunités de revenus", description: "CMO Fill & Finish, Madiba, UNICEF, épidémies, ERP SAP/ENNOV", ordre: 5, couleur: "#86B4DD" },
  });
  const axeConf = await prisma.ogsmAxe.create({
    data: { objectiveId: objective.id, code: "AXE-CONF", libelle: "Restaurer et renforcer la confiance des partenaires", description: "Engagements, communication, reporting, quick wins, gouvernance", ordre: 6, couleur: "#8b5cf6" },
  });
  const axeForm = await prisma.ogsmAxe.create({
    data: { objectiveId: objective.id, code: "AXE-FORM", libelle: "Formation & Recrutement", description: "Managers expérimentés, consultants GMP, culture BPF durable", ordre: 7, couleur: "#f59e0b" },
  });

  // Actions + mesures
  type ActionSeed = {
    axeId: string;
    code: string;
    libelle: string;
    description?: string;
    statut: string;
    progression: number;
    priorite: string;
    dateDebut: Date;
    dateFin: Date;
    responsableEmail: string;
    mesures: { libelle: string; cibleValeur?: number; valeurActuelle?: number; unite?: string; frequence?: string }[];
  };

  // 33 actions extraites du fichier OGSM officiel AFM (OGSM GLOBAL AFM — 19.04.2026)
  const actionsData: ActionSeed[] = [
    // ═══ AXE 1 : FINANCEMENT (CRITIQUE) ═══
    {
      axeId: axeFin.id, code: "ACT-FIN-01",
      libelle: "Lever 0,75 M€ via BIS avant fin avril 2026 (urgence court terme)",
      description: "Première tranche sécurisation du gap 9–17 M€ — subvention BIS.",
      statut: "FAIT", progression: 100, priorite: "HAUTE",
      dateDebut: new Date("2026-01-15"), dateFin: new Date("2026-04-30"),
      responsableEmail: "fin@afm-diamniadio.sn",
      mesures: [{ libelle: "Montant levé", cibleValeur: 0.75, valeurActuelle: 0.75, unite: "M€", frequence: "ponctuelle" }],
    },
    {
      axeId: axeFin.id, code: "ACT-FIN-02",
      libelle: "Lever 9 M€ via BIS avant fin juin 2026 (phase 1 Fill & Finish)",
      description: "Deuxième tranche du gap 9–17 M€ — deux investisseurs en due diligence.",
      statut: "EN_COURS", progression: 60, priorite: "HAUTE",
      dateDebut: new Date("2026-03-01"), dateFin: new Date("2026-06-30"),
      responsableEmail: "fin@afm-diamniadio.sn",
      mesures: [
        { libelle: "Montant levé vs objectif", cibleValeur: 9, valeurActuelle: 5.4, unite: "M€", frequence: "mensuelle" },
        { libelle: "Respect calendrier décaissement", cibleValeur: 100, valeurActuelle: 85, unite: "%", frequence: "mensuelle" },
      ],
    },
    {
      axeId: axeFin.id, code: "ACT-FIN-03",
      libelle: "Structurer levée complémentaire 20 M€ (bonus AVMA) pour finalisation end-to-end",
      description: "Drug Substance + Drug Product. Déblocage conditionné PQ OMS 2027.",
      statut: "EN_COURS", progression: 20, priorite: "HAUTE",
      dateDebut: new Date("2026-09-01"), dateFin: new Date("2027-03-31"),
      responsableEmail: "fin@afm-diamniadio.sn",
      mesures: [{ libelle: "% couverture besoins critiques", cibleValeur: 100, valeurActuelle: 20, unite: "%", frequence: "trimestrielle" }],
    },
    {
      axeId: axeFin.id, code: "ACT-FIN-04",
      libelle: "Prioriser les dépenses critiques : GMP, validations, prestataires, RH",
      description: "Arbitrage budgétaire mensuel + comité de validation CAPEX/OPEX.",
      statut: "EN_COURS", progression: 70, priorite: "HAUTE",
      dateDebut: new Date("2026-01-01"), dateFin: new Date("2027-12-31"),
      responsableEmail: "fin@afm-diamniadio.sn",
      mesures: [{ libelle: "Taux de consommation budgétaire vs planning", cibleValeur: 100, valeurActuelle: 40, unite: "%", frequence: "mensuelle" }],
    },
    {
      axeId: axeFin.id, code: "ACT-FIN-05",
      libelle: "Mettre en place un pilotage financier strict (cash-flow, CAPEX/OPEX)",
      description: "Tableau de bord hebdo trésorerie + revue mensuelle CAPEX/OPEX.",
      statut: "EN_COURS", progression: 80, priorite: "HAUTE",
      dateDebut: new Date("2026-01-01"), dateFin: new Date("2026-06-30"),
      responsableEmail: "fin@afm-diamniadio.sn",
      mesures: [{ libelle: "Fréquence reporting", cibleValeur: 4, valeurActuelle: 4, unite: "reviews/mois", frequence: "mensuelle" }],
    },

    // ═══ AXE 2 : EXCELLENCE INDUSTRIELLE ═══
    {
      axeId: axeIndus.id, code: "ACT-INDUS-01",
      libelle: "Atteindre un bâtiment zéro non-conformité en finalisant les corrections techniques",
      description: "Réparation portes + interlockage · fourniture climatisation · sols · étanchéité plafonds/murs.",
      statut: "EN_COURS", progression: 65, priorite: "HAUTE",
      dateDebut: new Date("2025-11-01"), dateFin: new Date("2026-05-31"),
      responsableEmail: "indus@afm-diamniadio.sn",
      mesures: [{ libelle: "% non-conformités bâtiment corrigées", cibleValeur: 100, valeurActuelle: 65, unite: "%", frequence: "mensuelle" }],
    },
    {
      axeId: axeIndus.id, code: "ACT-INDUS-02",
      libelle: "Réaliser les qualifications IQ/OQ/PQ des locaux et équipements",
      description: "EPPI, RO, COMBI, laveuse flacons, autoclave — IQ → OQ → PQ.",
      statut: "EN_COURS", progression: 55, priorite: "HAUTE",
      dateDebut: new Date("2026-01-01"), dateFin: new Date("2026-10-31"),
      responsableEmail: "qa@afm-diamniadio.sn",
      mesures: [
        { libelle: "% équipements qualifiés (IQ/OQ/PQ)", cibleValeur: 100, valeurActuelle: 53, unite: "%", frequence: "mensuelle" },
      ],
    },
    {
      axeId: axeIndus.id, code: "ACT-INDUS-03",
      libelle: "Finaliser la documentation de production (SOP, IT)",
      description: "10+ SOP critiques · instructions de travail · procédures de libération.",
      statut: "EN_COURS", progression: 70, priorite: "HAUTE",
      dateDebut: new Date("2025-12-01"), dateFin: new Date("2026-05-31"),
      responsableEmail: "qa@afm-diamniadio.sn",
      mesures: [
        { libelle: "% SOP validées", cibleValeur: 100, valeurActuelle: 70, unite: "%", frequence: "mensuelle" },
        { libelle: "Nombre de déviations critiques", cibleValeur: 0, valeurActuelle: 1, unite: "déviations", frequence: "mensuelle" },
      ],
    },
    {
      axeId: axeIndus.id, code: "ACT-INDUS-04",
      libelle: "Réaliser le Transfert de Technologie UVFJ (Garap) → AFM (Diamniadio)",
      description: "Formation équipes, documentation process, essais conformité.",
      statut: "EN_COURS", progression: 55, priorite: "HAUTE",
      dateDebut: new Date("2026-01-15"), dateFin: new Date("2026-09-30"),
      responsableEmail: "indus@afm-diamniadio.sn",
      mesures: [{ libelle: "Respect planning industriel (%)", cibleValeur: 100, valeurActuelle: 55, unite: "%", frequence: "mensuelle" }],
    },

    // ═══ AXE 3 : MITIGATION DES RISQUES ═══
    {
      axeId: axeRisq.id, code: "ACT-RISQ-01",
      libelle: "Stabiliser l'alimentation électrique avec Senelec (ligne sécurisée + UPS)",
      description: "Ligne dédiée Senelec + UPS + groupe électrogène.",
      statut: "EN_COURS", progression: 35, priorite: "HAUTE",
      dateDebut: new Date("2026-02-01"), dateFin: new Date("2026-10-31"),
      responsableEmail: "indus@afm-diamniadio.sn",
      mesures: [
        { libelle: "Nombre d'incidents Senelec/mois", cibleValeur: 0, valeurActuelle: 1, unite: "incidents", frequence: "mensuelle" },
        { libelle: "Disponibilité UPS", cibleValeur: 99.9, valeurActuelle: 99.45, unite: "%", frequence: "mensuelle" },
      ],
    },
    {
      axeId: axeRisq.id, code: "ACT-RISQ-02",
      libelle: "Mettre en place un back-up Drug Substance avec Biomanguinhos (Brésil) d'ici 2027",
      description: "Stock sécurité 6 mois + qualification fournisseur Biomanguinhos.",
      statut: "EN_COURS", progression: 50, priorite: "HAUTE",
      dateDebut: new Date("2026-02-15"), dateFin: new Date("2027-06-30"),
      responsableEmail: "prod@afm-diamniadio.sn",
      mesures: [{ libelle: "Mois de stock DS sécurisés", cibleValeur: 6, valeurActuelle: 4.5, unite: "mois", frequence: "mensuelle" }],
    },
    {
      axeId: axeRisq.id, code: "ACT-RISQ-03",
      libelle: "Corriger les risques qualité critiques (boucle d'eau, cabine lavage, Pseudomonas)",
      description: "Élimination contamination Pseudomonas · alimentation cabine de lavage · boucle d'eau.",
      statut: "EN_COURS", progression: 45, priorite: "HAUTE",
      dateDebut: new Date("2026-01-15"), dateFin: new Date("2026-07-31"),
      responsableEmail: "qa@afm-diamniadio.sn",
      mesures: [
        { libelle: "Non-conformités critiques", cibleValeur: 0, valeurActuelle: 1, unite: "NC", frequence: "mensuelle" },
        { libelle: "Taux contamination microbio", cibleValeur: 0, valeurActuelle: 0.3, unite: "%", frequence: "hebdo" },
        { libelle: "Incidents opérationnels majeurs", cibleValeur: 0, valeurActuelle: 1, unite: "incidents", frequence: "mensuelle" },
      ],
    },
    {
      axeId: axeRisq.id, code: "ACT-RISQ-04",
      libelle: "Renforcer le système qualité (QMS, monitoring environnemental)",
      description: "Capteurs IoT Pseudomonas + T°/HR/pression/particules avec alertes.",
      statut: "EN_COURS", progression: 70, priorite: "HAUTE",
      dateDebut: new Date("2026-01-01"), dateFin: new Date("2026-06-30"),
      responsableEmail: "qa@afm-diamniadio.sn",
      mesures: [{ libelle: "Taux de conformité GMP", cibleValeur: 98, valeurActuelle: 87, unite: "%", frequence: "mensuelle" }],
    },
    {
      axeId: axeRisq.id, code: "ACT-RISQ-05",
      libelle: "Mettre en place une gouvernance risques projet",
      description: "Matrice risques, comité mensuel, plan de mitigation, responsable dédié.",
      statut: "EN_COURS", progression: 60, priorite: "MOYENNE",
      dateDebut: new Date("2026-01-01"), dateFin: new Date("2026-05-31"),
      responsableEmail: "admin@afm-diamniadio.sn",
      mesures: [{ libelle: "Revues comité risques", cibleValeur: 12, valeurActuelle: 4, unite: "revues", frequence: "mensuelle" }],
    },

    // ═══ AXE 4 : PQ OMS ═══
    {
      axeId: axePq.id, code: "ACT-PQ-01",
      libelle: "Obtenir la licence d'exploitation (Q2 2026)",
      description: "Dossier technique déposé, inspection ARP juin 2026.",
      statut: "EN_COURS", progression: 70, priorite: "HAUTE",
      dateDebut: new Date("2025-11-01"), dateFin: new Date("2026-06-30"),
      responsableEmail: "qa@afm-diamniadio.sn",
      mesures: [{ libelle: "Succès inspection ARP", cibleValeur: 1, valeurActuelle: 0, unite: "oui/non", frequence: "ponctuelle" }],
    },
    {
      axeId: axePq.id, code: "ACT-PQ-02",
      libelle: "Obtenir le certificat GMP (Q1 2027)",
      description: "Suite à licence d'exploitation. Mock inspection T4-2026.",
      statut: "A_FAIRE", progression: 20, priorite: "HAUTE",
      dateDebut: new Date("2026-07-01"), dateFin: new Date("2027-03-31"),
      responsableEmail: "qa@afm-diamniadio.sn",
      mesures: [{ libelle: "Nombre d'écarts critiques lors audit", cibleValeur: 0, valeurActuelle: 0, unite: "écarts", frequence: "ponctuelle" }],
    },
    {
      axeId: axePq.id, code: "ACT-PQ-03",
      libelle: "Obtenir l'AMM (Q1 2027) intégrant AFM comme site",
      description: "Variation AMM UVFJ → inclusion site AFM Diamniadio.",
      statut: "A_FAIRE", progression: 15, priorite: "HAUTE",
      dateDebut: new Date("2026-06-01"), dateFin: new Date("2027-03-31"),
      responsableEmail: "qa@afm-diamniadio.sn",
      mesures: [{ libelle: "Progression dossier variation", cibleValeur: 100, valeurActuelle: 15, unite: "%", frequence: "trimestrielle" }],
    },
    {
      axeId: axePq.id, code: "ACT-PQ-04",
      libelle: "Réaliser lots PPQ et soumettre PQ OMS en juin 2027",
      description: "3 lots de validation Process Performance Qualification + soumission OMS.",
      statut: "A_FAIRE", progression: 5, priorite: "HAUTE",
      dateDebut: new Date("2026-11-01"), dateFin: new Date("2027-06-30"),
      responsableEmail: "qa@afm-diamniadio.sn",
      mesures: [{ libelle: "Lots PPQ validés", cibleValeur: 3, valeurActuelle: 0, unite: "lots", frequence: "mensuelle" }],
    },
    {
      axeId: axePq.id, code: "ACT-PQ-05",
      libelle: "Obtenir PQ OMS en octobre 2027",
      description: "Aboutissement du parcours réglementaire OMS — dossier soumis juin 2027.",
      statut: "A_FAIRE", progression: 0, priorite: "HAUTE",
      dateDebut: new Date("2027-06-01"), dateFin: new Date("2027-10-31"),
      responsableEmail: "qa@afm-diamniadio.sn",
      mesures: [{ libelle: "Obtention PQ OMS", cibleValeur: 1, valeurActuelle: 0, unite: "oui/non", frequence: "ponctuelle" }],
    },
    {
      axeId: axePq.id, code: "ACT-PQ-06",
      libelle: "Mettre en place audits internes et mock inspections",
      description: "Programme annuel · mock inspection ARP Q2 2026 · mock GMP T4 2026.",
      statut: "EN_COURS", progression: 60, priorite: "HAUTE",
      dateDebut: new Date("2026-01-15"), dateFin: new Date("2027-03-31"),
      responsableEmail: "qa@afm-diamniadio.sn",
      mesures: [{ libelle: "Audits réalisés", cibleValeur: 6, valeurActuelle: 1, unite: "audits", frequence: "trimestrielle" }],
    },

    // ═══ AXE 5 : DIVERSIFICATION REVENUS ═══
    {
      axeId: axeRev.id, code: "ACT-REV-01",
      libelle: "Développer activité Fill & Finish pour tiers (CMO)",
      description: "Offre commerciale F&F capacitaire + prospection partenaires.",
      statut: "EN_COURS", progression: 30, priorite: "MOYENNE",
      dateDebut: new Date("2026-03-01"), dateFin: new Date("2026-12-31"),
      responsableEmail: "admin@afm-diamniadio.sn",
      mesures: [{ libelle: "Nombre de contrats CMO signés", cibleValeur: 2, valeurActuelle: 0, unite: "contrats", frequence: "trimestrielle" }],
    },
    {
      axeId: axeRev.id, code: "ACT-REV-02",
      libelle: "Sous-traitance pour usine Madiba",
      description: "Accord cadre + plan de charge capacité excédentaire.",
      statut: "A_FAIRE", progression: 5, priorite: "BASSE",
      dateDebut: new Date("2026-06-01"), dateFin: new Date("2027-06-30"),
      responsableEmail: "admin@afm-diamniadio.sn",
      mesures: [{ libelle: "Revenus hors vaccin fièvre jaune", cibleValeur: 5, valeurActuelle: 0, unite: "M€/an", frequence: "trimestrielle" }],
    },
    {
      axeId: axeRev.id, code: "ACT-REV-03",
      libelle: "Sécuriser volumes UNICEF (2027-2029)",
      description: "Appels d'offres UNICEF conditionnés à PQ OMS.",
      statut: "A_FAIRE", progression: 15, priorite: "HAUTE",
      dateDebut: new Date("2027-01-01"), dateFin: new Date("2029-12-31"),
      responsableEmail: "admin@afm-diamniadio.sn",
      mesures: [{ libelle: "Volume production contractualisé", cibleValeur: 10, valeurActuelle: 0, unite: "M doses/an", frequence: "trimestrielle" }],
    },
    {
      axeId: axeRev.id, code: "ACT-REV-04",
      libelle: "Positionner AFM pour réponses épidémiques (pandémies)",
      description: "Dossier capacités en réserve — CEPI, OMS, Gavi.",
      statut: "A_FAIRE", progression: 10, priorite: "BASSE",
      dateDebut: new Date("2027-01-01"), dateFin: new Date("2028-12-31"),
      responsableEmail: "admin@afm-diamniadio.sn",
      mesures: [{ libelle: "Taux d'utilisation capacités industrielles", cibleValeur: 85, valeurActuelle: 0, unite: "%", frequence: "trimestrielle" }],
    },
    {
      axeId: axeRev.id, code: "ACT-REV-05",
      libelle: "Structurer une offre industrielle compétitive",
      description: "Grille tarifaire F&F + documentation technique prospects.",
      statut: "A_FAIRE", progression: 10, priorite: "MOYENNE",
      dateDebut: new Date("2026-04-01"), dateFin: new Date("2026-10-31"),
      responsableEmail: "admin@afm-diamniadio.sn",
      mesures: [{ libelle: "Opportunités qualifiées", cibleValeur: 10, valeurActuelle: 3, unite: "prospects", frequence: "trimestrielle" }],
    },
    {
      axeId: axeRev.id, code: "ACT-REV-06",
      libelle: "Structurer warehouse et ERP (SAP, ENNOV)",
      description: "Déploiement ERP SAP + gestion documentaire ENNOV + intégration LIMS.",
      statut: "EN_COURS", progression: 25, priorite: "MOYENNE",
      dateDebut: new Date("2026-02-01"), dateFin: new Date("2026-12-31"),
      responsableEmail: "indus@afm-diamniadio.sn",
      mesures: [{ libelle: "Modules déployés", cibleValeur: 4, valeurActuelle: 1, unite: "modules", frequence: "trimestrielle" }],
    },

    // ═══ AXE 6 : CONFIANCE PARTENAIRES ═══
    {
      axeId: axeConf.id, code: "ACT-CONF-01",
      libelle: "Tenir les engagements (planning, budget, qualité)",
      description: "Suivi disciplinaire OTIF-like · jalons critiques · alerte dérive.",
      statut: "EN_COURS", progression: 75, priorite: "HAUTE",
      dateDebut: new Date("2026-01-01"), dateFin: new Date("2027-12-31"),
      responsableEmail: "admin@afm-diamniadio.sn",
      mesures: [{ libelle: "Niveau de satisfaction partenaires", cibleValeur: 85, valeurActuelle: 72, unite: "%", frequence: "trimestrielle" }],
    },
    {
      axeId: axeConf.id, code: "ACT-CONF-02",
      libelle: "Mettre en place une communication transparente et régulière",
      description: "Lettre d'information mensuelle bailleurs · comité d'investisseurs trimestriel.",
      statut: "EN_COURS", progression: 65, priorite: "MOYENNE",
      dateDebut: new Date("2026-01-01"), dateFin: new Date("2027-12-31"),
      responsableEmail: "admin@afm-diamniadio.sn",
      mesures: [{ libelle: "Nombre de retards critiques", cibleValeur: 0, valeurActuelle: 1, unite: "retards", frequence: "mensuelle" }],
    },
    {
      axeId: axeConf.id, code: "ACT-CONF-03",
      libelle: "Assurer un reporting structuré aux bailleurs",
      description: "Dashboard partagé + rapports mensuels normalisés IPD/BIS/AVMA.",
      statut: "EN_COURS", progression: 80, priorite: "HAUTE",
      dateDebut: new Date("2026-01-01"), dateFin: new Date("2027-12-31"),
      responsableEmail: "fin@afm-diamniadio.sn",
      mesures: [{ libelle: "Nouvelles opportunités financement obtenues", cibleValeur: 2, valeurActuelle: 1, unite: "opportunités", frequence: "trimestrielle" }],
    },
    {
      axeId: axeConf.id, code: "ACT-CONF-04",
      libelle: "Démontrer des quick wins (mise en production 2026)",
      description: "Premier lot pilote Q3 2026 · libération premiers flacons avant fin 2026.",
      statut: "EN_COURS", progression: 40, priorite: "HAUTE",
      dateDebut: new Date("2026-04-01"), dateFin: new Date("2026-12-31"),
      responsableEmail: "prod@afm-diamniadio.sn",
      mesures: [{ libelle: "Réputation projet (feedback bailleurs)", cibleValeur: 4, valeurActuelle: 3.2, unite: "/5", frequence: "trimestrielle" }],
    },
    {
      axeId: axeConf.id, code: "ACT-CONF-05",
      libelle: "Renforcer la gouvernance projet et la crédibilité opérationnelle",
      description: "Comité exécutif mensuel · reporting KPI · PMO dédié.",
      statut: "EN_COURS", progression: 70, priorite: "HAUTE",
      dateDebut: new Date("2026-01-01"), dateFin: new Date("2026-12-31"),
      responsableEmail: "admin@afm-diamniadio.sn",
      mesures: [{ libelle: "Réunions comité exécutif", cibleValeur: 12, valeurActuelle: 4, unite: "réunions", frequence: "mensuelle" }],
    },

    // ═══ AXE 7 : FORMATION & RECRUTEMENT ═══
    {
      axeId: axeForm.id, code: "ACT-FORM-01",
      libelle: "Recruter managers/superviseurs expérimentés",
      description: "Chef de production, responsable QA, ingénieur maintenance GMP.",
      statut: "EN_COURS", progression: 65, priorite: "HAUTE",
      dateDebut: new Date("2025-11-01"), dateFin: new Date("2026-06-30"),
      responsableEmail: "admin@afm-diamniadio.sn",
      mesures: [
        { libelle: "% postes critiques pourvus", cibleValeur: 100, valeurActuelle: 65, unite: "%", frequence: "mensuelle" },
      ],
    },
    {
      axeId: axeForm.id, code: "ACT-FORM-02",
      libelle: "Mobiliser consultants GMP",
      description: "Cabinets externes GMP · transfert de compétences · coaching équipes locales.",
      statut: "EN_COURS", progression: 80, priorite: "HAUTE",
      dateDebut: new Date("2025-12-01"), dateFin: new Date("2026-12-31"),
      responsableEmail: "qa@afm-diamniadio.sn",
      mesures: [
        { libelle: "% personnel formé aux BPF (GMP)", cibleValeur: 100, valeurActuelle: 68, unite: "%", frequence: "mensuelle" },
      ],
    },
    {
      axeId: axeForm.id, code: "ACT-FORM-03",
      libelle: "Former équipes locales pour culture GMP durable",
      description: "Plan de formation pluri-annuel · habilitations aseptiques · équipements critiques.",
      statut: "EN_COURS", progression: 55, priorite: "HAUTE",
      dateDebut: new Date("2026-01-01"), dateFin: new Date("2027-06-30"),
      responsableEmail: "qa@afm-diamniadio.sn",
      mesures: [
        { libelle: "% personnel qualifié équipements critiques", cibleValeur: 100, valeurActuelle: 55, unite: "%", frequence: "mensuelle" },
        { libelle: "% personnel habilité pratiques aseptiques", cibleValeur: 100, valeurActuelle: 48, unite: "%", frequence: "mensuelle" },
        { libelle: "% dossiers formation/habilitation traçables", cibleValeur: 100, valeurActuelle: 75, unite: "%", frequence: "mensuelle" },
      ],
    },
  ];

  const userCache: Record<string, string | null> = {};
  for (const a of actionsData) {
    if (!(a.responsableEmail in userCache)) {
      const u = await prisma.user.findUnique({ where: { email: a.responsableEmail } });
      userCache[a.responsableEmail] = u?.id ?? null;
    }
    const createdAction = await prisma.ogsmAction.create({
      data: {
        axeId: a.axeId,
        code: a.code,
        libelle: a.libelle,
        description: a.description,
        statut: a.statut,
        progression: a.progression,
        priorite: a.priorite,
        dateDebut: a.dateDebut,
        dateFin: a.dateFin,
        responsableId: userCache[a.responsableEmail],
      },
    });
    for (const m of a.mesures) {
      await prisma.ogsmMesure.create({
        data: {
          actionId: createdAction.id,
          libelle: m.libelle,
          cibleValeur: m.cibleValeur,
          valeurActuelle: m.valeurActuelle,
          unite: m.unite,
          frequence: m.frequence,
        },
      });
    }
  }

  // Quelques commentaires OGSM
  const ogsmActionBloque = await prisma.ogsmAction.findUnique({ where: { code: "ACT-INDUS-02" } });
  const ogsmActionSenelec = await prisma.ogsmAction.findUnique({ where: { code: "ACT-RISQ-01" } });
  const ogsmActionCmo = await prisma.ogsmAction.findUnique({ where: { code: "ACT-REV-01" } });
  const ogsmComments: Parameters<typeof prisma.comment.createMany>[0]["data"] = [];
  if (ogsmActionBloque && qa) {
    ogsmComments.push(
      { entityType: "ogsm_action", entityId: ogsmActionBloque.id, periode: "2026-04", auteurId: qa.id, auteurNom: fullName(qa), contenu: "Action bloquée suite DEV-2026-005. Réunion escalade prévue semaine 17 avec fournisseur." }
    );
  }
  if (ogsmActionSenelec && indus && admin) {
    ogsmComments.push(
      { entityType: "ogsm_action", entityId: ogsmActionSenelec.id, periode: "2026-T2", auteurId: indus.id, auteurNom: fullName(indus), contenu: "Étude faisabilité validée. Budget CAPEX complémentaire à chiffrer T2." },
      { entityType: "ogsm_action", entityId: ogsmActionSenelec.id, periode: "2026-T2", auteurId: admin.id, auteurNom: fullName(admin), contenu: "Escalader direction Senelec : enjeu GMP critique pour la licence d'exploitation." }
    );
  }
  if (ogsmActionCmo && admin) {
    ogsmComments.push(
      { entityType: "ogsm_action", entityId: ogsmActionCmo.id, periode: "2026-T2", auteurId: admin.id, auteurNom: fullName(admin), contenu: "3 prospects identifiés. Commercial priorisé pour closing T3." }
    );
  }
  if (ogsmComments.length) await prisma.comment.createMany({ data: ogsmComments });

  console.log("✅ Seed terminé");
  console.log(`   Commentaires créés : ${comments.length}`);
  console.log("   Login : pasteur@afm-diamniadio.sn / passer");
  console.log("   (alt) : admin@afm-diamniadio.sn / passer");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
