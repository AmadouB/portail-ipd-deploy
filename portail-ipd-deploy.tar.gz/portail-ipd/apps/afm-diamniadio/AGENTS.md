# AFM Diamniadio — notes pour agents

## Contexte
Dashboard de pilotage de l'unité de production vaccinale AFM au Vaccinopole de Diamniadio (Sénégal).
Cahier des charges : `Cahier_des_charges_Dashboard_AFM_Diamniadio_1.docx` (20 avril 2026).
5 modules : Financier, Industriel, Conformité, Risques, Production.

## Stack
Next.js 16 App Router + TypeScript strict + Tailwind v4 + Prisma 6 + SQLite (dev) / PostgreSQL (prod) + jose JWT + Recharts + Zustand + Leaflet.

## Next.js 16 — attention
Next.js 16 contient des breaking changes par rapport aux versions antérieures. Avant d'écrire du code de routing/API, consulter `node_modules/next/dist/docs/`. `cookies()` et `headers()` sont asynchrones.

## Commandes
```
pnpm install
pnpm db:migrate       # applique les migrations (dev)
pnpm db:seed          # injecte les données du cahier des charges
pnpm dev              # serveur de développement
pnpm build            # typecheck + build de production
```

## Langue
Toute l'UI est en français (organisation sénégalaise).

## Roadmap
Voir README.md section Évolutions pour les phases 2/3 (intégrations SCADA/LIMS/MES, IA, PWA, Docker, monitoring).
