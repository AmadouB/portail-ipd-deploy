import type { SessionPayload } from "./auth";

/**
 * Rôles AFM Diamniadio — §7.2 cahier des charges
 */

export const ROLE_LABELS: Record<string, string> = {
  DG: "Direction Générale",
  DIR_FIN: "Direction Financière",
  DIR_INDUS: "Direction Industrielle",
  QA: "Assurance Qualité",
  PROD: "Production",
  LECTEUR: "Lecture seule",
};

export const MODULE_ACCESS: Record<string, string[]> = {
  DG: ["*"],
  DIR_FIN: ["dashboard", "financier", "admin"],
  DIR_INDUS: ["dashboard", "industriel", "production", "risques"],
  QA: ["dashboard", "conformite", "risques", "industriel"],
  PROD: ["dashboard", "production", "industriel"],
  LECTEUR: ["dashboard", "financier", "industriel", "conformite", "risques", "production"],
};

export function canAccessModule(role: string, module: string): boolean {
  const perms = MODULE_ACCESS[role] ?? [];
  return perms.includes("*") || perms.includes(module);
}

export function canEdit(role: string): boolean {
  return ["DG", "DIR_FIN", "DIR_INDUS", "QA", "PROD"].includes(role);
}

export function canAdmin(role: string): boolean {
  return role === "DG";
}

export function requirePermission(session: SessionPayload, module: string): void {
  if (!canAccessModule(session.role, module)) {
    throw new Error(`FORBIDDEN: role ${session.role} cannot access ${module}`);
  }
}
