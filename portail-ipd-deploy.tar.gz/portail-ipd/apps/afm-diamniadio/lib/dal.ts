import { prisma } from "./prisma";

/**
 * Data Access Layer — agrégats par module pour le dashboard et les pages.
 */

// ───────── Dashboard overview ─────────

export async function getOverview() {
  const [
    levees,
    derniereCashflow,
    equipements,
    qualifications,
    jalons,
    deviationsOuvertes,
    risquesActifs,
    targetCourant,
    oeeRecent,
  ] = await Promise.all([
    prisma.fundingRound.aggregate({ _sum: { montantLeveEur: true, montantCibleEur: true } }),
    prisma.cashflowSnapshot.findFirst({ orderBy: { date: "desc" } }),
    prisma.equipment.count(),
    prisma.qualification.groupBy({ by: ["statut"], _count: true }),
    prisma.regulatoryMilestone.findMany({ orderBy: { dateCible: "asc" } }),
    prisma.deviation.count({ where: { statut: { in: ["OUVERTE", "EN_TRAITEMENT"] } } }),
    prisma.risk.findMany({ where: { statut: { not: "CLOS" } }, orderBy: { score: "desc" } }),
    prisma.productionTarget.findFirst({ orderBy: { annee: "asc" } }),
    prisma.oEEMetric.aggregate({ _avg: { oee: true } }),
  ]);

  const qualifFait = qualifications.find((q) => q.statut === "FAIT")?._count ?? 0;
  const qualifTotal = qualifications.reduce((s, q) => s + q._count, 0);

  return {
    financier: {
      montantLeve: levees._sum.montantLeveEur ?? 0,
      montantCible: levees._sum.montantCibleEur ?? 0,
      cashPosition: derniereCashflow?.positionEur ?? 0,
    },
    industriel: {
      equipements,
      qualifFait,
      qualifTotal,
      pctQualif: qualifTotal ? Math.round((qualifFait / qualifTotal) * 100) : 0,
    },
    conformite: {
      jalons,
      deviationsOuvertes,
    },
    risques: {
      total: risquesActifs.length,
      critiques: risquesActifs.filter((r) => r.score >= 15).length,
      top3: risquesActifs.slice(0, 3),
    },
    production: {
      cibleDoses: targetCourant?.cibleDoses ?? 0,
      realisDoses: targetCourant?.realisDoses ?? 0,
      annee: targetCourant?.annee,
      oeeMoyen: Math.round(oeeRecent._avg.oee ?? 0),
    },
  };
}

// ───────── Financier ─────────

export async function getFundingRounds() {
  return prisma.fundingRound.findMany({ orderBy: { dateCible: "asc" } });
}

export async function getCashflow(months = 12) {
  return prisma.cashflowSnapshot.findMany({
    orderBy: { date: "asc" },
    take: months,
  });
}

export async function getBudgetLines() {
  return prisma.budgetLine.findMany({ orderBy: [{ categorie: "asc" }, { poste: "asc" }] });
}

// ───────── Industriel ─────────

export async function getEquipments() {
  return prisma.equipment.findMany({
    include: { qualifications: true },
    orderBy: { criticite: "asc" },
  });
}

export async function getQualifications() {
  return prisma.qualification.findMany({
    include: { equipment: true },
    orderBy: [{ equipment: { code: "asc" } }, { phase: "asc" }],
  });
}

export async function getSops() {
  return prisma.sOP.findMany({ orderBy: { dateRevision: "desc" } });
}

// ───────── Conformité ─────────

export async function getMilestones() {
  return prisma.regulatoryMilestone.findMany({ orderBy: { dateCible: "asc" } });
}

export async function getDeviations() {
  return prisma.deviation.findMany({ orderBy: { dateDetection: "desc" } });
}

export async function getAudits() {
  return prisma.audit.findMany({ orderBy: { datePrevue: "asc" } });
}

// ───────── Risques ─────────

export async function getRisks() {
  return prisma.risk.findMany({ orderBy: { score: "desc" } });
}

export async function getEnvironmentalReadings(zone?: string) {
  return prisma.environmentalReading.findMany({
    where: zone ? { zone } : undefined,
    orderBy: { timestamp: "asc" },
    take: 500,
  });
}

export async function getPowerIncidents() {
  return prisma.powerIncident.findMany({ orderBy: { date: "desc" } });
}

export async function getStockLevels() {
  return prisma.stockLevel.findMany({ orderBy: { produit: "asc" } });
}

// ───────── Production ─────────

export async function getProductionTargets() {
  return prisma.productionTarget.findMany({ orderBy: { annee: "asc" } });
}

export async function getProductionBatches() {
  return prisma.productionBatch.findMany({ orderBy: { dateProduction: "desc" } });
}

export async function getOEEMetrics(equipmentId?: string) {
  return prisma.oEEMetric.findMany({
    where: equipmentId ? { equipmentId } : undefined,
    include: { equipment: true },
    orderBy: { date: "asc" },
  });
}

// ───────── Commentaires périodiques ─────────

export async function getComments(entityType: string, entityId: string) {
  return prisma.comment.findMany({
    where: { entityType, entityId },
    orderBy: { createdAt: "desc" },
  });
}

/** Période actuelle par défaut, format "YYYY-MM" */
export function currentPeriode(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}

/** Trimestre courant, format "YYYY-TN" */
export function currentTrimestre(): string {
  const d = new Date();
  return `${d.getFullYear()}-T${Math.floor(d.getMonth() / 3) + 1}`;
}

// ───────── OGSM ─────────

export async function getOgsmMatrix() {
  const [objective, goals, axes, actions, users] = await Promise.all([
    prisma.ogsmObjective.findFirst({ orderBy: { createdAt: "asc" } }),
    prisma.ogsmGoal.findMany({ orderBy: { dateCible: "asc" } }),
    prisma.ogsmAxe.findMany({ orderBy: { ordre: "asc" } }),
    prisma.ogsmAction.findMany({
      include: {
        responsable: { select: { id: true, prenom: true, nom: true, email: true } },
        mesures: true,
        axe: true,
      },
      orderBy: [{ axe: { ordre: "asc" } }, { dateFin: "asc" }],
    }),
    prisma.user.findMany({
      where: { actif: true },
      select: { id: true, prenom: true, nom: true, email: true, roleCode: true },
      orderBy: { prenom: "asc" },
    }),
  ]);

  return { objective, goals, axes, actions, users };
}
