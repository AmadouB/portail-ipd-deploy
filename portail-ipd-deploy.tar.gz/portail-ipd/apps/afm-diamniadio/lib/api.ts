/**
 * Helper côté client pour préfixer les chemins API avec le basePath
 * (déploiement sous-chemin nginx, ex : /AFM).
 *
 * En dev sans BASE_PATH : `apiPath("/api/auth/login")` → `/api/auth/login`
 * En prod sous /AFM : `apiPath("/api/auth/login")` → `/AFM/api/auth/login`
 */
export const BASE_PATH = process.env.NEXT_PUBLIC_BASE_PATH ?? "";

export function apiPath(path: string): string {
  if (!path.startsWith("/")) path = `/${path}`;
  return `${BASE_PATH}${path}`;
}
