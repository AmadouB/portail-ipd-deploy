# Déploiement AFM Diamniadio

## GitHub

Repo privé : **https://github.com/AmadouB/afm-diamniadio**

## Vercel

Projet : **afm-diamniadio** (team `amadoubao-5484s-projects`)

## Brancher la base Postgres (Neon) — étape manuelle requise

La plateforme est déployée mais la base Postgres doit être provisionnée pour que les pages fonctionnent en runtime. Deux options :

### Option A — via l'intégration Vercel Marketplace (recommandé)

1. Aller sur https://vercel.com/amadoubao-5484s-projects/afm-diamniadio/stores
2. Cliquer sur **Create Database** → choisir **Neon**
3. Suivre l'assistant (gratuit : 3 Go, 100 h compute/mois)
4. Vercel injecte automatiquement `DATABASE_URL` sur les 3 environnements (prod, preview, dev)
5. Vercel relance un build → les tables sont créées automatiquement via `prisma db push`

### Option B — via Neon directement + CLI Vercel

```bash
# 1. Créer un projet sur https://neon.tech (OAuth GitHub en 30s)
# 2. Copier la "Connection string" depuis le dashboard Neon

# 3. Configurer la variable sur Vercel
vercel env add DATABASE_URL production --scope amadoubao-5484s-projects
# coller l'URL Neon

# 4. Forcer un nouveau déploiement pour recharger les variables
vercel deploy --prod --yes --scope amadoubao-5484s-projects
```

## Seed initial (une seule fois)

Après que les tables soient créées par le build Vercel, il faut injecter les données (utilisateurs, OGSM, etc.) :

```bash
# Depuis votre machine locale, avec DATABASE_URL Neon dans .env
cp .env.example .env
# Éditer .env : DATABASE_URL = URL Neon (copier depuis Vercel env ou Neon dashboard)

pnpm install
pnpm db:seed
# ✅ Seed terminé · Admin : admin@afm-diamniadio.sn / afm2027!
```

## Connexion à l'app

Une fois DB + seed OK :
- **URL prod** : affichée après `vercel deploy --prod`
- **Login** : `pasteur@afm-diamniadio.sn` / `passer`

⚠️ Changer tous les mots de passe avant mise en production réelle.

## Variables d'environnement Vercel

| Variable | Environnements | Notes |
|---|---|---|
| `DATABASE_URL` | prod · preview · dev | URL Postgres Neon (ou Vercel Postgres) |
| `AUTH_SECRET` | prod · preview · dev | ✅ Configuré (JWT) |

## Flow de mise à jour

Git push → Vercel build auto → `prisma db push --accept-data-loss` applique le schéma → next build → déploiement

Le seed n'est **pas ré-exécuté** automatiquement (préserve les données). Pour re-seeder manuellement : `pnpm db:seed` depuis local avec le DATABASE_URL prod.
