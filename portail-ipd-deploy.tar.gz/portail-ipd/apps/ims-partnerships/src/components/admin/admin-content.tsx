"use client";

import { useEffect, useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { formatDate } from "@/lib/utils";
import { Users, Shield, UserPlus } from "lucide-react";

interface User {
  id: string;
  name: string;
  email: string;
  role: string;
  department: string | null;
  telephone: string | null;
  poste: string | null;
  actif: boolean;
  lastLoginAt: string | null;
  createdAt: string;
}

const roleLabels: Record<string, string> = {
  ADMIN_NATIONAL: "Administrateur National",
  CHARGE_SUIVI: "Charge de Suivi",
  PARTENAIRE_TECHNIQUE: "Partenaire Technique",
  OBSERVATEUR: "Observateur",
};

const roleColors: Record<string, string> = {
  ADMIN_NATIONAL: "bg-red-500/10 text-red-500",
  CHARGE_SUIVI: "bg-[#0089D0]/10 text-[#0089D0]",
  PARTENAIRE_TECHNIQUE: "bg-purple-500/10 text-purple-500",
  OBSERVATEUR: "bg-emerald-500/10 text-emerald-500",
};

export function AdminContent() {
  const [users, setUsers] = useState<User[]>([]);

  useEffect(() => {
    fetch("/api/users").then(r => r.json()).then(setUsers);
  }, []);

  const grouped = Object.entries(
    users.reduce((acc, u) => {
      acc[u.role] = acc[u.role] || [];
      acc[u.role].push(u);
      return acc;
    }, {} as Record<string, User[]>)
  );

  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {Object.entries(roleLabels).map(([role, label]) => {
          const count = users.filter(u => u.role === role).length;
          return (
            <Card key={role} className="glass p-4">
              <div className="flex items-center gap-2">
                <Shield className="w-5 h-5 text-muted-foreground" />
                <div>
                  <p className="text-xs text-muted-foreground">{label}</p>
                  <p className="text-xl font-bold" style={{ fontFamily: "'Poppins', sans-serif" }}>{count}</p>
                </div>
              </div>
            </Card>
          );
        })}
      </div>

      {/* Users Table */}
      <Card className="glass p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-semibold" style={{ fontFamily: "'Poppins', sans-serif" }}>
            <Users className="w-4 h-4 inline mr-1" /> Utilisateurs ({users.length})
          </h3>
          <Button size="sm" variant="outline"><UserPlus className="w-4 h-4 mr-1" /> Ajouter</Button>
        </div>
        <div className="space-y-2">
          {users.map(user => (
            <div key={user.id} className="glass p-3 rounded-lg flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-sm font-bold text-primary">
                {user.name.split(" ").map(n => n[0]).join("").slice(0, 2)}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium">{user.name}</p>
                <p className="text-xs text-muted-foreground">{user.email}</p>
              </div>
              <Badge className={`text-[10px] ${roleColors[user.role] || ""}`}>
                {roleLabels[user.role]}
              </Badge>
              {user.department && <Badge variant="secondary" className="text-[10px]">{user.department}</Badge>}
              {!user.actif && <Badge variant="destructive" className="text-[10px]">Inactif</Badge>}
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
