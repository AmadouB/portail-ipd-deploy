"use client";

import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { FileText, Download, Calendar, BarChart3, Map, Globe } from "lucide-react";

const reportTypes = [
  { id: "weekly", label: "Rapport Hebdomadaire", description: "Synthese des activites de la semaine", icon: Calendar, frequency: "Chaque lundi" },
  { id: "monthly", label: "Rapport Mensuel", description: "Bilan mensuel du portefeuille", icon: BarChart3, frequency: "1er du mois" },
  { id: "quarterly", label: "Rapport Trimestriel", description: "Rapport detaille avec indicateurs", icon: FileText, frequency: "Fin de trimestre" },
  { id: "geographic", label: "Rapport Geographique", description: "Cartographie des interventions", icon: Map, frequency: "A la demande" },
  { id: "partner", label: "Rapport Partenaire", description: "Rapport specifique par partenaire", icon: Globe, frequency: "A la demande" },
];

export function RapportContent() {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {reportTypes.map(report => (
          <Card key={report.id} className="glass p-5 hover:glow-cyan transition-all">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                <report.icon className="w-5 h-5 text-primary" />
              </div>
              <div className="flex-1">
                <h3 className="text-sm font-semibold" style={{ fontFamily: "'Poppins', sans-serif" }}>{report.label}</h3>
                <p className="text-xs text-muted-foreground mt-1">{report.description}</p>
                <Badge variant="secondary" className="mt-2 text-[10px]">{report.frequency}</Badge>
              </div>
            </div>
            <Button className="w-full mt-4" variant="outline" size="sm">
              <Download className="w-4 h-4 mr-2" /> Generer PDF
            </Button>
          </Card>
        ))}
      </div>

      <Card className="glass p-6">
        <h3 className="text-sm font-semibold mb-4" style={{ fontFamily: "'Poppins', sans-serif" }}>Rapports Recents</h3>
        <p className="text-sm text-muted-foreground">Les rapports generes apparaitront ici.</p>
      </Card>
    </div>
  );
}
