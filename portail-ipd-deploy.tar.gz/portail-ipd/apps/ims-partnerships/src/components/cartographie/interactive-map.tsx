"use client";

import { MapContainer, TileLayer, CircleMarker, Popup } from "react-leaflet";
import { PILLAR_COLORS, PILLAR_LABELS, formatCurrency } from "@/lib/utils";
import { useTheme } from "@/components/theme-provider";
import "leaflet/dist/leaflet.css";

interface Project {
  id: string;
  projectName: string;
  pillar: string;
  status: string;
  totalAmount: number;
  latitude: number | null;
  longitude: number | null;
  departmentLead: string | null;
  partner: { name: string; acronym: string | null; type: string };
}

const TILES = {
  dark: "https://{s}.basemaps.cartocdn.com/light_nolabels/{z}/{x}/{y}{r}.png",
  light: "https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png",
};

function getMarkerRadius(amount: number): number {
  if (amount >= 20_000_000) return 14;
  if (amount >= 10_000_000) return 11;
  if (amount >= 5_000_000) return 9;
  if (amount >= 1_000_000) return 7;
  return 5;
}

export default function InteractiveMap({ projects }: { projects: Project[] }) {
  const { theme } = useTheme();

  return (
    <MapContainer
      center={[14.5, -14.5]}
      zoom={7}
      className="w-full h-full"
      style={{ background: theme === "dark" ? "#052A62" : "#F2F3F5" }}
    >
      <TileLayer
        attribution='&copy; <a href="https://carto.com/">CARTO</a>'
        url={TILES[theme]}
      />
      {projects.map(project => {
        if (!project.latitude || !project.longitude) return null;
        const color = PILLAR_COLORS[project.pillar] || "#0089D0";
        const radius = getMarkerRadius(project.totalAmount);
        return (
          <CircleMarker
            key={project.id}
            center={[project.latitude, project.longitude]}
            radius={radius}
            pathOptions={{
              color: color,
              fillColor: color,
              fillOpacity: 0.6,
              weight: 2,
              opacity: 0.8,
            }}
          >
            <Popup>
              <div className="min-w-[200px]">
                <h4 className="font-bold text-sm mb-1" style={{ fontFamily: "'Poppins', sans-serif" }}>
                  {project.projectName}
                </h4>
                <p className="text-xs opacity-60 mb-2">
                  {project.partner.acronym || project.partner.name}
                </p>
                <div className="grid grid-cols-2 gap-1 text-xs">
                  <div>
                    <span className="opacity-50">Pilier</span>
                    <p className="font-medium" style={{ color }}>{PILLAR_LABELS[project.pillar]}</p>
                  </div>
                  <div>
                    <span className="opacity-50">Montant</span>
                    <p className="font-medium">{formatCurrency(project.totalAmount)}</p>
                  </div>
                  <div>
                    <span className="opacity-50">Statut</span>
                    <p className="font-medium">{project.status}</p>
                  </div>
                  <div>
                    <span className="opacity-50">Dept</span>
                    <p className="font-medium">{project.departmentLead || "—"}</p>
                  </div>
                </div>
                <a href={`/projets/${project.id}`} className="block mt-2 text-xs text-[#0089D0] hover:underline">
                  Voir la fiche projet →
                </a>
              </div>
            </Popup>
          </CircleMarker>
        );
      })}
    </MapContainer>
  );
}
