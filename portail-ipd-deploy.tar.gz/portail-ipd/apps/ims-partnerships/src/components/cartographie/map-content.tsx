"use client";

import { useEffect, useState } from "react";
import dynamic from "next/dynamic";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { formatCurrency, PILLAR_COLORS, PILLAR_LABELS } from "@/lib/utils";
import { MapPin, DollarSign, FolderKanban, Layers } from "lucide-react";
import { StatusToggle } from "@/components/ui/status-toggle";

const InteractiveMap = dynamic(() => import("./interactive-map"), { ssr: false });

interface Project {
  id: string;
  projectName: string;
  pillar: string;
  status: string;
  totalAmount: number;
  latitude: number | null;
  longitude: number | null;
  departmentLead: string | null;
  partner: { name: string; acronym: string | null; type: string };
}

export function MapContent() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [activePillar, setActivePillar] = useState<string | null>(null);
  const [statusToggle, setStatusToggle] = useState<"ALL" | "ACTIF" | "INACTIF">("ALL");

  useEffect(() => {
    fetch("/api/projects")
      .then(r => r.json())
      .then((data: Project[]) => setProjects(data.filter(p => p.latitude && p.longitude)));
  }, []);

  const filtered = projects.filter(p => {
    if (statusToggle === "ACTIF" && p.status !== "ACTIF") return false;
    if (statusToggle === "INACTIF" && p.status === "ACTIF") return false;
    if (activePillar && p.pillar !== activePillar) return false;
    return true;
  });

  const totalFinancial = filtered.reduce((s, p) => s + p.totalAmount, 0);

  const pillarCounts = Object.entries(
    filtered.reduce((acc, p) => {
      acc[p.pillar] = (acc[p.pillar] || 0) + 1;
      return acc;
    }, {} as Record<string, number>)
  );

  return (
    <div className="flex gap-4 h-[calc(100vh-180px)]">
      {/* Map */}
      <div className="flex-1 rounded-xl overflow-hidden glass">
        <InteractiveMap projects={filtered} />
      </div>

      {/* Sidebar */}
      <div className="w-[300px] space-y-4 overflow-y-auto">
        {/* Status Toggle */}
        <StatusToggle value={statusToggle} onChange={setStatusToggle} />

        {/* Stats */}
        <Card className="glass p-4">
          <h3 className="text-sm font-semibold mb-3" style={{ fontFamily: "'Poppins', sans-serif" }}>
            <MapPin className="w-4 h-4 inline mr-1" /> Statistiques
          </h3>
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Projets visibles</span>
              <span className="font-bold text-[#0089D0]">{filtered.length}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Volume financier</span>
              <span className="font-bold text-[#0089D0]">{formatCurrency(totalFinancial)}</span>
            </div>
          </div>
        </Card>

        {/* Pillar Filter */}
        <Card className="glass p-4">
          <h3 className="text-sm font-semibold mb-3" style={{ fontFamily: "'Poppins', sans-serif" }}>
            <Layers className="w-4 h-4 inline mr-1" /> Couches Thematiques
          </h3>
          <div className="space-y-1.5">
            <button
              onClick={() => setActivePillar(null)}
              className={`w-full text-left px-3 py-2 rounded-lg text-xs transition-colors ${!activePillar ? "bg-primary/10 text-primary font-semibold" : "hover:bg-accent"}`}
            >
              Tous les piliers
            </button>
            {Object.entries(PILLAR_LABELS).map(([key, label]) => {
              const count = projects.filter(p => p.pillar === key).length;
              return (
                <button
                  key={key}
                  onClick={() => setActivePillar(activePillar === key ? null : key)}
                  className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg text-xs transition-colors ${activePillar === key ? "bg-primary/10 font-semibold" : "hover:bg-accent"}`}
                >
                  <div className="w-3 h-3 rounded-full flex-shrink-0" style={{ backgroundColor: PILLAR_COLORS[key] }} />
                  <span className="flex-1 text-left">{label}</span>
                  <Badge variant="secondary" className="text-[10px]">{count}</Badge>
                </button>
              );
            })}
          </div>
        </Card>

        {/* Projects List */}
        <Card className="glass p-4">
          <h3 className="text-sm font-semibold mb-3" style={{ fontFamily: "'Poppins', sans-serif" }}>
            <FolderKanban className="w-4 h-4 inline mr-1" /> Projets ({filtered.length})
          </h3>
          <div className="space-y-2 max-h-[300px] overflow-y-auto">
            {filtered.map(p => (
              <a key={p.id} href={`/projets/${p.id}`} className="block glass p-2 rounded-lg hover:bg-accent/50 transition-colors">
                <p className="text-xs font-medium truncate">{p.projectName}</p>
                <div className="flex items-center gap-1 mt-0.5">
                  <div className="w-2 h-2 rounded-full" style={{ backgroundColor: PILLAR_COLORS[p.pillar] }} />
                  <span className="text-[10px] text-muted-foreground">{p.partner.acronym}</span>
                  <span className="text-[10px] text-[#0089D0] ml-auto">{formatCurrency(p.totalAmount)}</span>
                </div>
              </a>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}
