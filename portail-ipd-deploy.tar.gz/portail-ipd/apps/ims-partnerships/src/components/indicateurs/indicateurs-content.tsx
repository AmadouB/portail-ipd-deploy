"use client";

import { useEffect, useState, useMemo } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Progress } from "@/components/ui/progress";
import { formatCurrency, PILLAR_COLORS, PILLAR_LABELS } from "@/lib/utils";
import {
  Search, Target, TrendingUp, BarChart3, Building2, Send, CheckCircle2,
  AlertTriangle, Clock, ArrowUpRight, ChevronRight, Gauge, Sparkles,
} from "lucide-react";

interface Indicator {
  id: string;
  code: string;
  category: string;
  pillar: string | null;
  department: string | null;
  subUnit: string | null;
  initiative: string | null;
  name: string;
  description: string | null;
  formula: string | null;
  frequency: string | null;
  source: string | null;
  responsible: string | null;
  baseline: string | null;
  target2025: string | null;
  target2027: string | null;
  target2032: string | null;
  unit: string | null;
  values: Array<{ id: string; period: string; targetValue: string | null; actualValue: string | null; status: string; comments: string | null }>;
  _count: { values: number };
}

const CATEGORY_CONFIG: Record<string, { label: string; color: string; icon: typeof Target }> = {
  EFFECT: { label: "Effets (Outcomes)", color: "#0089D0", icon: TrendingUp },
  IMPACT: { label: "Impacts", color: "#10b981", icon: Sparkles },
  OPERATIONAL: { label: "Operationnels", color: "#EF7A16", icon: BarChart3 },
};

const STATUS_CONFIG: Record<string, { label: string; color: string }> = {
  PENDING: { label: "En attente", color: "#6b7280" },
  ON_TRACK: { label: "En bonne voie", color: "#10b981" },
  AT_RISK: { label: "A risque", color: "#EF7A16" },
  OFF_TRACK: { label: "Hors piste", color: "#ef4444" },
  ACHIEVED: { label: "Atteint", color: "#0089D0" },
};

const DEPT_LABELS: Record<string, string> = {
  DPC: "Partenariats & Communication",
  DREI: "Recherche, Education & Innovation",
  DCH: "Capital Humain",
  DOI: "Operations Industrielles",
  DSP: "Sante Publique",
  CARE: "Centre CARE / Education",
  DFC: "Direction Financiere",
  DDSI: "Digital & SI",
  DAL: "Achats & Logistique",
  DC: "Direction Commerciale",
  DRO: "Ressources Operationnelles",
  GOV: "Gouvernance & Qualite",
  PROJETS: "Projets Strategiques",
};

export function IndicateursContent() {
  const [indicators, setIndicators] = useState<Indicator[]>([]);
  const [search, setSearch] = useState("");
  const [filterCategory, setFilterCategory] = useState("ALL");
  const [filterPillar, setFilterPillar] = useState("ALL");
  const [filterDept, setFilterDept] = useState("ALL");
  const [filterInitiative, setFilterInitiative] = useState("ALL");
  const [filterFrequency, setFilterFrequency] = useState("ALL");
  const [filterSaisie, setFilterSaisie] = useState("ALL"); // ALL, WITH_VALUES, WITHOUT_VALUES
  const [selectedIndicator, setSelectedIndicator] = useState<Indicator | null>(null);
  const [saving, setSaving] = useState(false);
  const [success, setSuccess] = useState("");

  // Value form
  const [valForm, setValForm] = useState({
    period: "2025",
    targetValue: "",
    actualValue: "",
    status: "PENDING",
    comments: "",
  });

  useEffect(() => {
    fetch("/api/indicators").then(r => r.json()).then(setIndicators);
  }, []);

  const initiatives = useMemo(() => {
    const set = new Set<string>();
    indicators.forEach(i => { if (i.initiative) i.initiative.split(",").map((s: string) => s.trim()).forEach((s: string) => set.add(s)); });
    return Array.from(set).sort();
  }, [indicators]);

  const frequencies = useMemo(() => {
    const set = new Set<string>();
    indicators.forEach(i => { if (i.frequency) set.add(i.frequency); });
    return Array.from(set).sort();
  }, [indicators]);

  const FREQ_LABELS: Record<string, string> = { MONTHLY: "Mensuel", QUARTERLY: "Trimestriel", SEMI_ANNUAL: "Semestriel", ANNUAL: "Annuel" };

  const filtered = useMemo(() => {
    return indicators.filter(ind => {
      if (search) {
        const s = search.toLowerCase();
        if (!ind.name.toLowerCase().includes(s) && !ind.code.toLowerCase().includes(s) && !(ind.initiative || "").toLowerCase().includes(s) && !(ind.responsible || "").toLowerCase().includes(s) && !(ind.subUnit || "").toLowerCase().includes(s)) return false;
      }
      if (filterCategory !== "ALL" && ind.category !== filterCategory) return false;
      if (filterPillar !== "ALL" && ind.pillar !== filterPillar) return false;
      if (filterDept !== "ALL" && ind.department !== filterDept) return false;
      if (filterInitiative !== "ALL" && !(ind.initiative || "").includes(filterInitiative)) return false;
      if (filterFrequency !== "ALL" && ind.frequency !== filterFrequency) return false;
      if (filterSaisie === "WITH_VALUES" && ind._count.values === 0) return false;
      if (filterSaisie === "WITHOUT_VALUES" && ind._count.values > 0) return false;
      return true;
    });
  }, [indicators, search, filterCategory, filterPillar, filterDept, filterInitiative, filterFrequency, filterSaisie]);

  const hasFilters = search || filterCategory !== "ALL" || filterPillar !== "ALL" || filterDept !== "ALL" || filterInitiative !== "ALL" || filterFrequency !== "ALL" || filterSaisie !== "ALL";

  // Stats
  const stats = useMemo(() => {
    const effects = filtered.filter(i => i.category === "EFFECT").length;
    const impacts = filtered.filter(i => i.category === "IMPACT").length;
    const ops = filtered.filter(i => i.category === "OPERATIONAL").length;
    const withValues = filtered.filter(i => i._count.values > 0).length;
    return { effects, impacts, ops, total: filtered.length, withValues };
  }, [filtered]);

  // Group by pillar for strategic indicators
  const strategicByPillar = useMemo(() => {
    const pillars: Record<string, { effects: Indicator[]; impacts: Indicator[] }> = {};
    filtered.filter(i => i.category !== "OPERATIONAL").forEach(ind => {
      const p = ind.pillar || "TRANSVERSAL";
      if (!pillars[p]) pillars[p] = { effects: [], impacts: [] };
      if (ind.category === "EFFECT") pillars[p].effects.push(ind);
      else pillars[p].impacts.push(ind);
    });
    return pillars;
  }, [filtered]);

  // Group by department for operational
  const opsByDept = useMemo(() => {
    const depts: Record<string, Indicator[]> = {};
    filtered.filter(i => i.category === "OPERATIONAL").forEach(ind => {
      const d = ind.department || "Autre";
      if (!depts[d]) depts[d] = [];
      depts[d].push(ind);
    });
    return depts;
  }, [filtered]);

  const submitValue = async () => {
    if (!selectedIndicator || !valForm.period) return;
    setSaving(true);
    try {
      await fetch(`/api/indicators/${selectedIndicator.id}/values`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(valForm),
      });
      setSuccess("Valeur enregistree !");
      setValForm(f => ({ ...f, targetValue: "", actualValue: "", comments: "" }));
      // Refresh
      const updated = await fetch("/api/indicators").then(r => r.json());
      setIndicators(updated);
      setSelectedIndicator(updated.find((i: Indicator) => i.id === selectedIndicator.id) || null);
    } catch {} finally {
      setSaving(false);
    }
  };

  const renderIndicatorRow = (ind: Indicator) => {
    const catConf = CATEGORY_CONFIG[ind.category];
    const latestValue = ind.values[0];
    const statusConf = latestValue ? STATUS_CONFIG[latestValue.status] : null;

    return (
      <div
        key={ind.id}
        className="glass p-3 rounded-lg cursor-pointer hover:bg-accent/50 transition-all group"
        onClick={() => { setSelectedIndicator(ind); setSuccess(""); }}
      >
        <div className="flex items-start gap-3">
          <Badge className="text-[10px] flex-shrink-0 mt-0.5" style={{ backgroundColor: `${catConf.color}20`, color: catConf.color }}>
            {ind.code}
          </Badge>
          <div className="flex-1 min-w-0">
            <p className="text-xs font-medium group-hover:text-primary transition-colors">{ind.name}</p>
            <div className="flex items-center gap-2 mt-1 flex-wrap">
              {ind.pillar && (
                <span className="text-[9px] px-1.5 py-0.5 rounded" style={{ backgroundColor: `${PILLAR_COLORS[ind.pillar] || "#6b7280"}15`, color: PILLAR_COLORS[ind.pillar] }}>
                  {PILLAR_LABELS[ind.pillar] || ind.pillar}
                </span>
              )}
              {ind.initiative && <span className="text-[9px] text-muted-foreground">{ind.initiative}</span>}
              {ind.frequency && <span className="text-[9px] text-muted-foreground">{ind.frequency}</span>}
            </div>
          </div>
          <div className="text-right flex-shrink-0">
            {latestValue ? (
              <div>
                <span className="text-xs font-bold" style={{ color: statusConf?.color }}>{latestValue.actualValue || "—"}</span>
                <p className="text-[9px]" style={{ color: statusConf?.color }}>{statusConf?.label}</p>
              </div>
            ) : (
              <span className="text-[9px] text-muted-foreground">Aucune saisie</span>
            )}
          </div>
          <ChevronRight className="w-3.5 h-3.5 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity flex-shrink-0 mt-1" />
        </div>
        {/* Targets row */}
        <div className="flex gap-4 mt-2 text-[9px] text-muted-foreground ml-12">
          {ind.baseline && <span>Base: <strong className="text-foreground">{ind.baseline}</strong></span>}
          {ind.target2025 && <span>2025: <strong className="text-foreground">{ind.target2025}</strong></span>}
          {ind.target2027 && <span>2027: <strong className="text-[#0089D0]">{ind.target2027}</strong></span>}
          {ind.target2032 && <span>2032: <strong className="text-emerald-500">{ind.target2032}</strong></span>}
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-5">
      {/* KPI Bar */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        {[
          { label: "Total", value: stats.total, color: "#0089D0", icon: Gauge },
          { label: "Effets", value: stats.effects, color: "#0089D0", icon: TrendingUp },
          { label: "Impacts", value: stats.impacts, color: "#10b981", icon: Sparkles },
          { label: "Operationnels", value: stats.ops, color: "#EF7A16", icon: BarChart3 },
          { label: "Avec saisie", value: stats.withValues, color: "#8b5cf6", icon: CheckCircle2 },
        ].map((kpi, i) => (
          <Card key={i} className="glass p-3">
            <div className="flex items-center gap-2">
              <kpi.icon className="w-4 h-4" style={{ color: kpi.color }} />
              <div>
                <p className="text-lg font-bold" style={{ fontFamily: "'Poppins', sans-serif", color: kpi.color }}>{kpi.value}</p>
                <p className="text-[9px] text-muted-foreground">{kpi.label}</p>
              </div>
            </div>
          </Card>
        ))}
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-2.5 items-center">
        <div className="relative flex-1 min-w-[200px] max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input placeholder="Rechercher par code, nom, initiative..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9 glass" />
        </div>
        <Select value={filterCategory} onValueChange={v => setFilterCategory(v || "ALL")}>
          <SelectTrigger className="w-[160px] glass"><SelectValue placeholder="Categorie" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="ALL">Toutes</SelectItem>
            {Object.entries(CATEGORY_CONFIG).map(([k, v]) => <SelectItem key={k} value={k}>{v.label}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={filterPillar} onValueChange={v => setFilterPillar(v || "ALL")}>
          <SelectTrigger className="w-[155px] glass"><SelectValue placeholder="Pilier" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="ALL">Tous piliers</SelectItem>
            {Object.entries(PILLAR_LABELS).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}
            <SelectItem value="TRANSVERSAL">Transversal</SelectItem>
          </SelectContent>
        </Select>
        <Select value={filterDept} onValueChange={v => setFilterDept(v || "ALL")}>
          <SelectTrigger className="w-[150px] glass"><SelectValue placeholder="Service" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="ALL">Tous services</SelectItem>
            {Object.entries(DEPT_LABELS).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={filterInitiative} onValueChange={v => setFilterInitiative(v || "ALL")}>
          <SelectTrigger className="w-[140px] glass"><SelectValue placeholder="Initiative" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="ALL">Toutes initiatives</SelectItem>
            {initiatives.map(i => <SelectItem key={i} value={i}>{i}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={filterFrequency} onValueChange={v => setFilterFrequency(v || "ALL")}>
          <SelectTrigger className="w-[140px] glass"><SelectValue placeholder="Frequence" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="ALL">Toutes frequences</SelectItem>
            {frequencies.map(f => <SelectItem key={f} value={f}>{FREQ_LABELS[f] || f}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={filterSaisie} onValueChange={v => setFilterSaisie(v || "ALL")}>
          <SelectTrigger className="w-[135px] glass"><SelectValue placeholder="Saisie" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="ALL">Tous</SelectItem>
            <SelectItem value="WITH_VALUES">Avec saisie</SelectItem>
            <SelectItem value="WITHOUT_VALUES">Sans saisie</SelectItem>
          </SelectContent>
        </Select>
        {hasFilters && (
          <button onClick={() => { setSearch(""); setFilterCategory("ALL"); setFilterPillar("ALL"); setFilterDept("ALL"); setFilterInitiative("ALL"); setFilterFrequency("ALL"); setFilterSaisie("ALL"); }} className="text-[10px] text-primary hover:underline">
            Reinitialiser
          </button>
        )}
      </div>

      {/* Content */}
      <Tabs defaultValue="strategic" className="space-y-4">
        <TabsList className="glass">
          <TabsTrigger value="strategic" className="gap-1.5">
            <Target className="w-3.5 h-3.5" /> Strategiques ({stats.effects + stats.impacts})
          </TabsTrigger>
          <TabsTrigger value="operational" className="gap-1.5">
            <BarChart3 className="w-3.5 h-3.5" /> Operationnels ({stats.ops})
          </TabsTrigger>
          <TabsTrigger value="table" className="gap-1.5">
            <Gauge className="w-3.5 h-3.5" /> Table croisee
          </TabsTrigger>
        </TabsList>

        {/* Strategic Tab */}
        <TabsContent value="strategic">
          <div className="space-y-6">
            {Object.entries(strategicByPillar).map(([pillar, data]) => (
              <Card key={pillar} className="glass p-5">
                <div className="flex items-center gap-2 mb-4">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: PILLAR_COLORS[pillar] || "#6b7280" }} />
                  <h3 className="text-sm font-semibold" style={{ fontFamily: "'Poppins', sans-serif" }}>
                    {PILLAR_LABELS[pillar] || pillar}
                  </h3>
                  <Badge variant="secondary" className="text-[10px]">{data.effects.length + data.impacts.length} indicateurs</Badge>
                </div>
                {data.effects.length > 0 && (
                  <div className="mb-4">
                    <p className="text-[10px] text-[#0089D0] font-semibold uppercase tracking-wider mb-2">Indicateurs d'effets (outcomes)</p>
                    <div className="space-y-1.5">{data.effects.map(renderIndicatorRow)}</div>
                  </div>
                )}
                {data.impacts.length > 0 && (
                  <div>
                    <p className="text-[10px] text-emerald-500 font-semibold uppercase tracking-wider mb-2">Indicateurs d'impacts</p>
                    <div className="space-y-1.5">{data.impacts.map(renderIndicatorRow)}</div>
                  </div>
                )}
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Operational Tab */}
        <TabsContent value="operational">
          <div className="space-y-6">
            {Object.entries(opsByDept).map(([dept, inds]) => (
              <Card key={dept} className="glass p-5">
                <div className="flex items-center gap-2 mb-4">
                  <Building2 className="w-4 h-4 text-[#EF7A16]" />
                  <h3 className="text-sm font-semibold" style={{ fontFamily: "'Poppins', sans-serif" }}>
                    {dept} — {DEPT_LABELS[dept] || ""}
                  </h3>
                  <Badge variant="secondary" className="text-[10px]">{inds.length}</Badge>
                </div>
                <div className="space-y-1.5">{inds.map(renderIndicatorRow)}</div>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Cross-Table Tab */}
        <TabsContent value="table">
          <Card className="glass p-5 overflow-x-auto">
            <h3 className="text-sm font-semibold mb-4" style={{ fontFamily: "'Poppins', sans-serif" }}>
              Table croisee Piliers / Initiatives / Indicateurs
            </h3>
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left p-2 font-semibold">Pilier</th>
                  <th className="text-left p-2 font-semibold">Initiative</th>
                  <th className="text-center p-2 font-semibold">Effets</th>
                  <th className="text-center p-2 font-semibold">Impacts</th>
                  <th className="text-center p-2 font-semibold">Operationnels</th>
                  <th className="text-center p-2 font-semibold">Total</th>
                </tr>
              </thead>
              <tbody>
                {Object.entries(PILLAR_LABELS).map(([pillar, label]) => {
                  const pillarInds = indicators.filter(i => i.pillar === pillar);
                  const initiatives = [...new Set(pillarInds.map(i => i.initiative).filter(Boolean))];
                  if (pillarInds.length === 0) return null;

                  return (
                    <tr key={pillar} className="border-b border-border/50 hover:bg-accent/30">
                      <td className="p-2 font-medium" style={{ color: PILLAR_COLORS[pillar] }}>
                        <div className="flex items-center gap-1.5">
                          <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: PILLAR_COLORS[pillar] }} />
                          {label}
                        </div>
                      </td>
                      <td className="p-2 text-muted-foreground">
                        {initiatives.length > 0 ? initiatives.join(", ") : "—"}
                      </td>
                      <td className="p-2 text-center font-bold text-[#0089D0]">
                        {pillarInds.filter(i => i.category === "EFFECT").length || "—"}
                      </td>
                      <td className="p-2 text-center font-bold text-emerald-500">
                        {pillarInds.filter(i => i.category === "IMPACT").length || "—"}
                      </td>
                      <td className="p-2 text-center font-bold text-[#EF7A16]">
                        {indicators.filter(i => i.category === "OPERATIONAL" && (
                          (pillar === "PRODUCTION" && ["DOI"].includes(i.department || "")) ||
                          (pillar === "RECHERCHE" && ["DREI"].includes(i.department || "")) ||
                          (pillar === "SANTE_PUBLIQUE" && ["DSP"].includes(i.department || "")) ||
                          (pillar === "EDUCATION" && ["CARE"].includes(i.department || ""))
                        )).length || "—"}
                      </td>
                      <td className="p-2 text-center font-bold">{pillarInds.length}</td>
                    </tr>
                  );
                })}
                {/* Transversal */}
                <tr className="border-b border-border/50 hover:bg-accent/30">
                  <td className="p-2 font-medium text-muted-foreground">Transversal</td>
                  <td className="p-2 text-muted-foreground">IPD DU</td>
                  <td className="p-2 text-center">—</td>
                  <td className="p-2 text-center font-bold text-emerald-500">{indicators.filter(i => i.pillar === "TRANSVERSAL").length}</td>
                  <td className="p-2 text-center">—</td>
                  <td className="p-2 text-center font-bold">{indicators.filter(i => i.pillar === "TRANSVERSAL").length}</td>
                </tr>
                {/* Total row */}
                <tr className="bg-accent/30 font-semibold">
                  <td className="p-2" colSpan={2}>TOTAL</td>
                  <td className="p-2 text-center text-[#0089D0]">{indicators.filter(i => i.category === "EFFECT").length}</td>
                  <td className="p-2 text-center text-emerald-500">{indicators.filter(i => i.category === "IMPACT").length}</td>
                  <td className="p-2 text-center text-[#EF7A16]">{indicators.filter(i => i.category === "OPERATIONAL").length}</td>
                  <td className="p-2 text-center">{indicators.length}</td>
                </tr>
              </tbody>
            </table>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Detail / Saisie Dialog */}
      <Dialog open={!!selectedIndicator} onOpenChange={() => setSelectedIndicator(null)}>
        <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
          {selectedIndicator && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <Badge style={{ backgroundColor: `${CATEGORY_CONFIG[selectedIndicator.category]?.color}20`, color: CATEGORY_CONFIG[selectedIndicator.category]?.color }}>
                    {selectedIndicator.code}
                  </Badge>
                  {selectedIndicator.name}
                </DialogTitle>
              </DialogHeader>

              <div className="space-y-5">
                {/* Details */}
                <div className="grid grid-cols-2 gap-3 text-xs">
                  {selectedIndicator.description && <div className="col-span-2"><span className="text-muted-foreground">Description:</span> {selectedIndicator.description}</div>}
                  {selectedIndicator.formula && <div className="col-span-2"><span className="text-muted-foreground">Formule:</span> <code className="glass px-1 py-0.5 rounded text-[10px]">{selectedIndicator.formula}</code></div>}
                  {selectedIndicator.source && <div><span className="text-muted-foreground">Source:</span> {selectedIndicator.source}</div>}
                  {selectedIndicator.responsible && <div><span className="text-muted-foreground">Responsable:</span> {selectedIndicator.responsible}</div>}
                  {selectedIndicator.frequency && <div><span className="text-muted-foreground">Frequence:</span> {selectedIndicator.frequency}</div>}
                  {selectedIndicator.unit && <div><span className="text-muted-foreground">Unite:</span> {selectedIndicator.unit}</div>}
                </div>

                {/* Targets */}
                <div className="grid grid-cols-4 gap-3">
                  {[
                    { label: "Baseline", value: selectedIndicator.baseline, color: "#6b7280" },
                    { label: "Cible 2025", value: selectedIndicator.target2025, color: "#EF7A16" },
                    { label: "Cible 2027", value: selectedIndicator.target2027, color: "#0089D0" },
                    { label: "Cible 2032", value: selectedIndicator.target2032, color: "#10b981" },
                  ].map((t, i) => (
                    <div key={i} className="glass rounded-lg p-3 text-center">
                      <p className="text-[9px] text-muted-foreground">{t.label}</p>
                      <p className="text-sm font-bold mt-1" style={{ color: t.color, fontFamily: "'Poppins', sans-serif" }}>
                        {t.value || "—"}
                      </p>
                    </div>
                  ))}
                </div>

                {/* Existing values */}
                {selectedIndicator.values.length > 0 && (
                  <div>
                    <p className="text-[10px] text-muted-foreground uppercase tracking-wider mb-2">Historique des saisies</p>
                    <div className="space-y-1.5">
                      {selectedIndicator.values.map(v => (
                        <div key={v.id} className="glass p-2.5 rounded-lg flex items-center gap-3">
                          <Badge variant="outline" className="text-[10px]">{v.period}</Badge>
                          <div className="flex-1 text-xs">
                            {v.targetValue && <span className="text-muted-foreground">Cible: <strong>{v.targetValue}</strong></span>}
                            {v.targetValue && v.actualValue && <span className="mx-2">|</span>}
                            {v.actualValue && <span>Realise: <strong className="text-primary">{v.actualValue}</strong></span>}
                          </div>
                          <Badge className="text-[9px]" style={{ backgroundColor: `${STATUS_CONFIG[v.status]?.color}20`, color: STATUS_CONFIG[v.status]?.color }}>
                            {STATUS_CONFIG[v.status]?.label}
                          </Badge>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Saisie form */}
                {success && (
                  <div className="flex items-center gap-2 text-emerald-500 text-sm">
                    <CheckCircle2 className="w-4 h-4" /> {success}
                  </div>
                )}
                <Card className="p-4 border-primary/20">
                  <h4 className="text-sm font-semibold mb-3" style={{ fontFamily: "'Poppins', sans-serif" }}>Saisir une valeur</h4>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <Label className="text-xs">Periode *</Label>
                      <Select value={valForm.period} onValueChange={v => setValForm(f => ({ ...f, period: v || "2025" }))}>
                        <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          {["2025", "2025-Q1", "2025-Q2", "2025-Q3", "2025-Q4", "2026", "2026-Q1", "2026-Q2", "2027"].map(p => (
                            <SelectItem key={p} value={p}>{p}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label className="text-xs">Statut</Label>
                      <Select value={valForm.status} onValueChange={v => setValForm(f => ({ ...f, status: v || "PENDING" }))}>
                        <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          {Object.entries(STATUS_CONFIG).map(([k, v]) => <SelectItem key={k} value={k}>{v.label}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label className="text-xs">Valeur cible {selectedIndicator.unit ? `(${selectedIndicator.unit})` : ""}</Label>
                      <Input value={valForm.targetValue} onChange={e => setValForm(f => ({ ...f, targetValue: e.target.value }))} className="mt-1" placeholder={selectedIndicator.target2025 || ""} />
                    </div>
                    <div>
                      <Label className="text-xs">Valeur realisee {selectedIndicator.unit ? `(${selectedIndicator.unit})` : ""}</Label>
                      <Input value={valForm.actualValue} onChange={e => setValForm(f => ({ ...f, actualValue: e.target.value }))} className="mt-1" />
                    </div>
                    <div className="col-span-2">
                      <Label className="text-xs">Commentaires</Label>
                      <Textarea value={valForm.comments} onChange={e => setValForm(f => ({ ...f, comments: e.target.value }))} className="mt-1" rows={2} placeholder="Observations, source des donnees..." />
                    </div>
                  </div>
                  <Button onClick={submitValue} disabled={saving} className="mt-3">
                    <Send className="w-4 h-4 mr-2" />{saving ? "Enregistrement..." : "Enregistrer"}
                  </Button>
                </Card>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
