"use client";

import { cn } from "@/lib/utils";

interface StatusToggleProps {
  value: "ALL" | "ACTIF" | "INACTIF";
  onChange: (value: "ALL" | "ACTIF" | "INACTIF") => void;
}

const OPTIONS = [
  { key: "ALL" as const, label: "Tous", color: "#6b7280" },
  { key: "ACTIF" as const, label: "Actifs", color: "#10b981" },
  { key: "INACTIF" as const, label: "Inactifs", color: "#EF7A16" },
];

export function StatusToggle({ value, onChange }: StatusToggleProps) {
  return (
    <div className="flex gap-0.5 glass rounded-lg p-0.5">
      {OPTIONS.map(opt => (
        <button
          key={opt.key}
          onClick={() => onChange(opt.key)}
          className={cn(
            "px-3 py-1.5 rounded-md text-xs font-medium transition-all",
            value === opt.key
              ? "bg-primary/10 text-primary shadow-sm"
              : "text-muted-foreground hover:text-foreground hover:bg-accent/50"
          )}
        >
          <div className="flex items-center gap-1.5">
            <div
              className={cn("w-2 h-2 rounded-full", value === opt.key ? "opacity-100" : "opacity-40")}
              style={{ backgroundColor: opt.color }}
            />
            {opt.label}
          </div>
        </button>
      ))}
    </div>
  );
}
