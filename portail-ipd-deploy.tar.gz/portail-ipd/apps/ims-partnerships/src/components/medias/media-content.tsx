"use client";

import { useEffect, useState, useRef } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { formatDate } from "@/lib/utils";
import { Upload, Image as ImageIcon, Video, FileText, Music, Search, MapPin, Calendar, X } from "lucide-react";

interface MediaFile {
  id: string;
  type: string;
  fileName: string;
  filePath: string;
  mimeType: string | null;
  fileSize: number;
  latitude: number | null;
  longitude: number | null;
  capturedAt: string | null;
  description: string | null;
  uploadedAt: string;
  project: { projectName: string; pillar: string };
  uploadedBy: { name: string } | null;
}

export function MediaContent() {
  const [media, setMedia] = useState<MediaFile[]>([]);
  const [search, setSearch] = useState("");
  const [filterType, setFilterType] = useState("ALL");
  const [selectedMedia, setSelectedMedia] = useState<MediaFile | null>(null);
  const [dragOver, setDragOver] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    fetch("/api/media").then(r => r.json()).then(setMedia);
  }, []);

  const filtered = media.filter(m => {
    if (search && !m.fileName.toLowerCase().includes(search.toLowerCase()) && !m.project.projectName.toLowerCase().includes(search.toLowerCase())) return false;
    if (filterType !== "ALL" && m.type !== filterType) return false;
    return true;
  });

  const typeIcons: Record<string, React.ReactNode> = {
    PHOTO: <ImageIcon className="w-5 h-5 text-[#0089D0]" />,
    VIDEO: <Video className="w-5 h-5 text-purple-500" />,
    DOCUMENT: <FileText className="w-5 h-5 text-[#EF7A16]" />,
    AUDIO: <Music className="w-5 h-5 text-emerald-500" />,
  };

  const formatFileSize = (bytes: number) => {
    if (bytes >= 1_000_000) return `${(bytes / 1_000_000).toFixed(1)} MB`;
    if (bytes >= 1_000) return `${(bytes / 1_000).toFixed(0)} KB`;
    return `${bytes} B`;
  };

  return (
    <div className="space-y-4">
      {/* Upload Zone */}
      <Card
        className={`glass p-8 text-center border-2 border-dashed transition-colors cursor-pointer ${dragOver ? "border-primary bg-primary/5" : "border-border"}`}
        onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
        onDragLeave={() => setDragOver(false)}
        onDrop={(e) => { e.preventDefault(); setDragOver(false); }}
        onClick={() => fileInputRef.current?.click()}
      >
        <Upload className="w-10 h-10 text-muted-foreground mx-auto mb-2" />
        <p className="text-sm text-muted-foreground">
          Glissez vos fichiers ici ou <span className="text-primary">parcourez</span>
        </p>
        <p className="text-xs text-muted-foreground mt-1">
          JPEG, PNG, MP4, MOV, PDF, XLSX, PPTX, Audio
        </p>
        <input ref={fileInputRef} type="file" multiple className="hidden" accept="image/*,video/*,.pdf,.xlsx,.pptx,.doc,.docx,audio/*" />
      </Card>

      {/* Filters */}
      <div className="flex gap-3 items-center">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input placeholder="Rechercher..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9 glass" />
        </div>
        <Select value={filterType} onValueChange={(v) => setFilterType(v || "ALL")}>
          <SelectTrigger className="w-[140px] glass"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="ALL">Tous</SelectItem>
            <SelectItem value="PHOTO">Photos</SelectItem>
            <SelectItem value="VIDEO">Videos</SelectItem>
            <SelectItem value="DOCUMENT">Documents</SelectItem>
            <SelectItem value="AUDIO">Audio</SelectItem>
          </SelectContent>
        </Select>
        <Badge variant="secondary">{filtered.length} fichiers</Badge>
      </div>

      {/* Media Grid */}
      {filtered.length === 0 ? (
        <Card className="glass p-12 text-center">
          <ImageIcon className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
          <p className="text-sm text-muted-foreground">Aucun media enregistre</p>
          <p className="text-xs text-muted-foreground mt-1">Les medias seront affiches ici une fois telecharges</p>
        </Card>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3">
          {filtered.map(m => (
            <Card
              key={m.id}
              className="glass overflow-hidden cursor-pointer hover:glow-cyan transition-all"
              onClick={() => setSelectedMedia(m)}
            >
              <div className="aspect-square bg-muted flex items-center justify-center">
                {m.type === "PHOTO" && m.filePath ? (
                  <img src={m.filePath} alt={m.fileName} className="w-full h-full object-cover" />
                ) : (
                  typeIcons[m.type] || <FileText className="w-8 h-8 text-muted-foreground" />
                )}
              </div>
              <div className="p-2">
                <p className="text-xs font-medium truncate">{m.fileName}</p>
                <p className="text-[10px] text-muted-foreground truncate">{m.project.projectName}</p>
                <div className="flex items-center gap-1 mt-1">
                  <Badge variant="secondary" className="text-[10px]">{m.type}</Badge>
                  {m.latitude && <MapPin className="w-3 h-3 text-muted-foreground" />}
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}

      {/* Lightbox */}
      <Dialog open={!!selectedMedia} onOpenChange={() => setSelectedMedia(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{selectedMedia?.fileName}</DialogTitle>
          </DialogHeader>
          {selectedMedia && (
            <div className="space-y-3">
              {selectedMedia.type === "PHOTO" && (
                <img src={selectedMedia.filePath} alt={selectedMedia.fileName} className="w-full rounded-lg" />
              )}
              <div className="grid grid-cols-2 gap-2 text-sm">
                <div><span className="text-muted-foreground">Projet:</span> {selectedMedia.project.projectName}</div>
                <div><span className="text-muted-foreground">Taille:</span> {formatFileSize(selectedMedia.fileSize)}</div>
                <div><span className="text-muted-foreground">Upload:</span> {formatDate(selectedMedia.uploadedAt)}</div>
                {selectedMedia.capturedAt && <div><span className="text-muted-foreground">Capture:</span> {formatDate(selectedMedia.capturedAt)}</div>}
                {selectedMedia.latitude && <div><span className="text-muted-foreground">GPS:</span> {selectedMedia.latitude.toFixed(4)}, {selectedMedia.longitude?.toFixed(4)}</div>}
                {selectedMedia.description && <div className="col-span-2"><span className="text-muted-foreground">Description:</span> {selectedMedia.description}</div>}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
