"use client";

import { useMemo, useState } from "react";
import Link from "next/link";

interface WordItem {
  id: string;
  name: string;
  fullName: string;
  count: number;
  type: string;
  color: string;
}

interface WordCloudProps {
  partners: WordItem[];
}

export function WordCloud({ partners }: WordCloudProps) {
  const [hoveredId, setHoveredId] = useState<string | null>(null);

  const words = useMemo(() => {
    if (partners.length === 0) return [];

    // Sort by project count (most projects = biggest)
    const sorted = [...partners].sort((a, b) => b.count - a.count);

    const maxCount = sorted[0]?.count || 1;
    const minCount = sorted[sorted.length - 1]?.count || 0;
    const range = Math.max(maxCount - minCount, 1);

    return sorted.map((p, i) => {
      // Font size: min 11px, max 48px, proportional to project count
      const ratio = (p.count - minCount) / range;
      const fontSize = Math.round(11 + ratio * 37);

      // Opacity: more projects = more opaque
      const opacity = 0.45 + ratio * 0.55;

      return {
        ...p,
        fontSize,
        opacity,
        rank: i,
      };
    });
  }, [partners]);

  if (words.length === 0) {
    return <p className="text-sm text-muted-foreground text-center py-12">Aucun partenaire a afficher</p>;
  }

  return (
    <div className="relative min-h-[400px] flex flex-wrap items-center justify-center gap-x-3 gap-y-1 py-6 px-4">
      {words.map((word) => (
        <Link
          key={word.id}
          href={`/partenaires/${word.id}`}
          className="inline-block transition-all duration-200 cursor-pointer relative"
          style={{
            fontSize: `${word.fontSize}px`,
            fontFamily: "'Poppins', sans-serif",
            fontWeight: word.fontSize > 30 ? 700 : word.fontSize > 20 ? 600 : 400,
            color: word.color,
            opacity: hoveredId && hoveredId !== word.id ? 0.2 : word.opacity,
            transform: hoveredId === word.id ? "scale(1.15)" : "scale(1)",
            lineHeight: 1.3,
            padding: "2px 6px",
          }}
          onMouseEnter={() => setHoveredId(word.id)}
          onMouseLeave={() => setHoveredId(null)}
        >
          {word.name}
          {/* Tooltip on hover */}
          {hoveredId === word.id && (
            <div className="absolute left-1/2 -translate-x-1/2 bottom-full mb-2 glass rounded-lg p-3 z-50 min-w-[200px] pointer-events-none shadow-lg">
              <p className="text-xs font-bold text-foreground whitespace-nowrap">{word.fullName}</p>
              <div className="flex items-center gap-3 mt-1">
                <span className="text-[10px] text-muted-foreground">{word.count} projet{word.count > 1 ? "s" : ""}</span>
                <span className="text-[10px] px-1.5 py-0.5 rounded" style={{ backgroundColor: `${word.color}20`, color: word.color }}>
                  {word.type.replace(/_/g, " ")}
                </span>
              </div>
            </div>
          )}
        </Link>
      ))}
    </div>
  );
}
