"use client";

import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Save, Loader2 } from "lucide-react";

const TYPE_OPTIONS = [
  { value: "FONDATION", label: "Fondation" },
  { value: "INSTITUTION_FINANCIERE", label: "Institution financiere" },
  { value: "GOUVERNEMENT", label: "Gouvernement" },
  { value: "ONG_SANTE", label: "ONG Sante" },
  { value: "ACADEMIE", label: "Academie" },
  { value: "INDUSTRIE", label: "Industrie" },
];

const TIER_OPTIONS = [
  { value: "TIER1", label: "Tier 1 (>=20M$)" },
  { value: "TIER2", label: "Tier 2 (1-5M$)" },
  { value: "TIER3", label: "Tier 3 (<1M$)" },
];

interface PartnerData {
  id: string;
  name: string;
  acronym: string | null;
  type: string;
  country: string;
  city: string | null;
  tier: string;
  website: string | null;
}

export function EditPartnerModal({
  partner,
  open,
  onClose,
  onSaved,
}: {
  partner: PartnerData;
  open: boolean;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [form, setForm] = useState({
    name: partner.name,
    acronym: partner.acronym || "",
    type: partner.type,
    country: partner.country,
    city: partner.city || "",
    tier: partner.tier,
    website: partner.website || "",
  });
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    setSaving(true);
    try {
      await fetch(`/api/partners/${partner.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...form,
          acronym: form.acronym || null,
          city: form.city || null,
          website: form.website || null,
        }),
      });
      onSaved();
      onClose();
    } catch {} finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>Modifier le partenaire</DialogTitle>
        </DialogHeader>
        <div className="grid grid-cols-2 gap-4">
          <div className="col-span-2">
            <Label className="text-xs">Nom complet</Label>
            <Input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} className="mt-1" />
          </div>
          <div>
            <Label className="text-xs">Acronyme</Label>
            <Input value={form.acronym} onChange={e => setForm(f => ({ ...f, acronym: e.target.value }))} className="mt-1" placeholder="Ex: BMGF" />
          </div>
          <div>
            <Label className="text-xs">Type</Label>
            <Select value={form.type} onValueChange={v => setForm(f => ({ ...f, type: v || f.type }))}>
              <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
              <SelectContent>
                {TYPE_OPTIONS.map(o => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-xs">Pays</Label>
            <Input value={form.country} onChange={e => setForm(f => ({ ...f, country: e.target.value }))} className="mt-1" />
          </div>
          <div>
            <Label className="text-xs">Ville</Label>
            <Input value={form.city} onChange={e => setForm(f => ({ ...f, city: e.target.value }))} className="mt-1" />
          </div>
          <div>
            <Label className="text-xs">Tier</Label>
            <Select value={form.tier} onValueChange={v => setForm(f => ({ ...f, tier: v || f.tier }))}>
              <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
              <SelectContent>
                {TIER_OPTIONS.map(o => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-xs">Site web</Label>
            <Input value={form.website} onChange={e => setForm(f => ({ ...f, website: e.target.value }))} className="mt-1" placeholder="https://..." />
          </div>
        </div>
        <div className="flex justify-end gap-2 mt-4">
          <Button variant="outline" onClick={onClose}>Annuler</Button>
          <Button onClick={handleSave} disabled={saving}>
            {saving ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
            Enregistrer
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
