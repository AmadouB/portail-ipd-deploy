"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { formatCurrency, formatDate, PILLAR_COLORS, PILLAR_LABELS, STATUS_COLORS } from "@/lib/utils";
import { EditPartnerModal } from "./edit-partner-modal";
import { EditProjectModal } from "../projets/edit-project-modal";
import {
  Building2, Globe, DollarSign, Calendar, TrendingUp, AlertTriangle,
  FolderKanban, ArrowUpRight, CheckCircle2, Clock, Target, ChevronRight, Pencil,
} from "lucide-react";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, BarChart, Bar, XAxis, YAxis } from "recharts";

const TYPE_LABELS: Record<string, string> = {
  FONDATION: "Fondation",
  INSTITUTION_FINANCIERE: "Institution financiere",
  GOUVERNEMENT: "Gouvernement",
  ONG_SANTE: "ONG Sante",
  ACADEMIE: "Academie",
  INDUSTRIE: "Industrie",
};

const TYPE_COLORS: Record<string, string> = {
  FONDATION: "#0089D0",
  INSTITUTION_FINANCIERE: "#FFD500",
  GOUVERNEMENT: "#EF7A16",
  ONG_SANTE: "#10b981",
  ACADEMIE: "#8b5cf6",
  INDUSTRIE: "#ec4899",
};

interface PartnerData {
  id: string;
  name: string;
  acronym: string | null;
  type: string;
  country: string;
  city: string | null;
  tier: string;
  website: string | null;
  projects: Array<{
    id: string;
    streamId: string | null;
    projectName: string;
    pillar: string;
    status: string;
    totalAmount: number;
    annualAmount: number;
    departmentLead: string | null;
    startDate: string | null;
    endDate: string | null;
    objectives: string | null;
    pastActivities: string | null;
    upcomingActions: string | null;
    deliverables: string | null;
    contractType: string | null;
    duration: string | null;
    risks: Array<{ description: string; criticality: string; mitigationActions: string | null; status: string }>;
    monitoringEntries: Array<{ period: string; physicalRate: number; financialRate: number }>;
    _count: { mediaFiles: number };
  }>;
  stats: {
    totalProjects: number;
    activeProjects: number;
    totalFinancial: number;
    avgPhysicalRate: number;
    avgFinancialRate: number;
    earliestStart: string | null;
    latestEnd: string | null;
    byPillar: Array<{ pillar: string; count: number; amount: number }>;
  };
  achievements: Array<{ projectName: string; text: string }>;
  difficulties: Array<{ projectName: string; description: string; criticality: string; mitigation: string | null }>;
  upcoming: Array<{ projectName: string; text: string }>;
}

export function PartnerDetail({ partnerId }: { partnerId: string }) {
  const [data, setData] = useState<PartnerData | null>(null);
  const [editPartner, setEditPartner] = useState(false);
  const [editProject, setEditProject] = useState<string | null>(null);

  const reload = () => fetch(`/api/partners/${partnerId}`).then(r => r.json()).then(setData);

  useEffect(() => {
    reload();
  }, [partnerId]);

  if (!data) {
    return <div className="space-y-4">{[...Array(3)].map((_, i) => <Card key={i} className="glass p-6 animate-pulse h-48" />)}</div>;
  }

  const color = TYPE_COLORS[data.type] || "#0089D0";

  const pillarChartData = data.stats.byPillar.map(p => ({
    name: PILLAR_LABELS[p.pillar] || p.pillar,
    value: p.count,
    amount: p.amount,
    fill: PILLAR_COLORS[p.pillar] || "#6b7280",
  }));

  const projectsByAmount = [...data.projects].sort((a, b) => b.totalAmount - a.totalAmount);

  return (
    <div className="space-y-6">
      {/* Header Card */}
      <Card className="glass p-6 glow-cyan">
        <div className="flex items-start gap-5">
          <div
            className="w-16 h-16 rounded-xl flex items-center justify-center text-white text-xl font-bold flex-shrink-0"
            style={{ backgroundColor: color }}
          >
            {(data.acronym || data.name).substring(0, 2).toUpperCase()}
          </div>
          <div className="flex-1">
            <h2 className="text-xl font-bold" style={{ fontFamily: "'Poppins', sans-serif" }}>{data.name}</h2>
            {data.acronym && <p className="text-sm text-muted-foreground">{data.acronym}</p>}
            <div className="flex flex-wrap gap-2 mt-2">
              <Badge style={{ backgroundColor: color, color: "#fff" }}>{TYPE_LABELS[data.type]}</Badge>
              <Badge variant="outline">{data.tier.replace("TIER", "Tier ")}</Badge>
              <Badge variant="secondary"><Globe className="w-3 h-3 mr-1 inline" />{data.city ? `${data.city}, ` : ""}{data.country}</Badge>
            </div>
          </div>
          <div className="text-right flex-shrink-0">
            <p className="text-3xl font-bold text-primary" style={{ fontFamily: "'Poppins', sans-serif" }}>
              {formatCurrency(data.stats.totalFinancial)}
            </p>
            <p className="text-xs text-muted-foreground">Volume financier global</p>
            <Button variant="outline" size="sm" className="mt-2" onClick={() => setEditPartner(true)}>
              <Pencil className="w-3.5 h-3.5 mr-1" /> Modifier
            </Button>
          </div>
        </div>
      </Card>

      {/* Edit Partner Modal */}
      {editPartner && (
        <EditPartnerModal partner={data} open={editPartner} onClose={() => setEditPartner(false)} onSaved={reload} />
      )}

      {/* KPI Row */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
        {[
          { label: "Projets", value: data.stats.totalProjects, icon: FolderKanban, color: "#0089D0" },
          { label: "Actifs", value: data.stats.activeProjects, icon: CheckCircle2, color: "#10b981" },
          { label: "Exec. Physique", value: `${data.stats.avgPhysicalRate}%`, icon: TrendingUp, color: "#0089D0" },
          { label: "Exec. Financiere", value: `${data.stats.avgFinancialRate}%`, icon: DollarSign, color: "#EF7A16" },
          { label: "Debut", value: data.stats.earliestStart ? formatDate(data.stats.earliestStart) : "—", icon: Calendar, color: "#8b5cf6" },
          { label: "Fin", value: data.stats.latestEnd ? formatDate(data.stats.latestEnd) : "—", icon: Clock, color: "#ec4899" },
        ].map((kpi, i) => (
          <Card key={i} className="glass p-4 animate-fade-up" style={{ animationDelay: `${i * 0.05}s` }}>
            <div className="flex items-center gap-2 mb-1">
              <kpi.icon className="w-4 h-4" style={{ color: kpi.color }} />
              <span className="text-[10px] text-muted-foreground uppercase tracking-wider">{kpi.label}</span>
            </div>
            <p className="text-lg font-bold" style={{ fontFamily: "'Poppins', sans-serif", color: kpi.color }}>
              {kpi.value}
            </p>
          </Card>
        ))}
      </div>

      <Tabs defaultValue="projets" className="space-y-4">
        <TabsList className="glass">
          <TabsTrigger value="projets">Projets ({data.projects.length})</TabsTrigger>
          <TabsTrigger value="resultats">Resultats ({data.achievements.length})</TabsTrigger>
          <TabsTrigger value="difficultes">Difficultes ({data.difficulties.length})</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>

        {/* Projects Tab */}
        <TabsContent value="projets">
          <div className="space-y-3">
            {projectsByAmount.map((project, i) => (
              <Link key={project.id} href={`/projets/${project.id}`}>
                <Card className="glass p-4 hover:glow-cyan transition-all cursor-pointer group animate-fade-up" style={{ animationDelay: `${i * 0.03}s` }}>
                  <div className="flex items-start gap-4">
                    {/* Pillar indicator */}
                    <div className="w-1.5 h-full min-h-[60px] rounded-full flex-shrink-0" style={{ backgroundColor: PILLAR_COLORS[project.pillar] }} />

                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-3">
                        <div className="min-w-0">
                          <p className="text-sm font-semibold group-hover:text-primary transition-colors" style={{ fontFamily: "'Poppins', sans-serif" }}>
                            {project.projectName}
                          </p>
                          <div className="flex flex-wrap gap-1.5 mt-1.5">
                            <Badge variant="outline" className="text-[10px]" style={{ borderColor: PILLAR_COLORS[project.pillar], color: PILLAR_COLORS[project.pillar] }}>
                              {PILLAR_LABELS[project.pillar]}
                            </Badge>
                            <Badge variant="outline" className="text-[10px]" style={{ borderColor: STATUS_COLORS[project.status], color: STATUS_COLORS[project.status] }}>
                              {project.status}
                            </Badge>
                            {project.departmentLead && <Badge variant="secondary" className="text-[10px]">{project.departmentLead}</Badge>}
                            {project.contractType && <Badge variant="secondary" className="text-[10px]">{project.contractType}</Badge>}
                            {project.streamId && <Badge variant="secondary" className="text-[10px]">{project.streamId}</Badge>}
                          </div>
                        </div>
                        <div className="text-right flex-shrink-0">
                          <p className="text-sm font-bold text-primary">{formatCurrency(project.totalAmount)}</p>
                          {project.annualAmount > 0 && <p className="text-[10px] text-muted-foreground">{formatCurrency(project.annualAmount)}/an</p>}
                        </div>
                      </div>

                      {/* Execution bars */}
                      {project.monitoringEntries.length > 0 && (
                        <div className="grid grid-cols-2 gap-4 mt-3">
                          <div>
                            <div className="flex justify-between text-[10px] mb-0.5">
                              <span className="text-muted-foreground">Physique</span>
                              <span className="font-medium">{project.monitoringEntries[0].physicalRate}%</span>
                            </div>
                            <Progress value={project.monitoringEntries[0].physicalRate} className="h-1.5" />
                          </div>
                          <div>
                            <div className="flex justify-between text-[10px] mb-0.5">
                              <span className="text-muted-foreground">Financier</span>
                              <span className="font-medium">{project.monitoringEntries[0].financialRate}%</span>
                            </div>
                            <Progress value={project.monitoringEntries[0].financialRate} className="h-1.5" />
                          </div>
                        </div>
                      )}

                      {/* Dates */}
                      <div className="flex items-center gap-4 mt-2 text-[10px] text-muted-foreground">
                        {project.startDate && <span><Calendar className="w-3 h-3 inline mr-0.5" />{formatDate(project.startDate)}</span>}
                        {project.endDate && <span>→ {formatDate(project.endDate)}</span>}
                        {project.duration && <span>({project.duration})</span>}
                        {project.risks.length > 0 && (
                          <span className="text-red-500">
                            <AlertTriangle className="w-3 h-3 inline mr-0.5" />{project.risks.length} risque{project.risks.length > 1 ? "s" : ""}
                          </span>
                        )}
                      </div>

                      {/* Objectives summary */}
                      {project.objectives && (
                        <p className="text-xs text-muted-foreground mt-2 line-clamp-2">{project.objectives}</p>
                      )}
                    </div>
                    <div className="flex flex-col gap-1 flex-shrink-0">
                      <button onClick={(e) => { e.preventDefault(); setEditProject(project.id); }} className="p-1 rounded hover:bg-accent/50 opacity-0 group-hover:opacity-100 transition-opacity">
                        <Pencil className="w-3.5 h-3.5 text-muted-foreground" />
                      </button>
                      <ArrowUpRight className="w-4 h-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
                    </div>
                  </div>
                </Card>
              </Link>
            ))}
          </div>
        </TabsContent>

        {/* Results Tab */}
        <TabsContent value="resultats">
          <Card className="glass p-5">
            <h3 className="text-sm font-semibold mb-4" style={{ fontFamily: "'Poppins', sans-serif" }}>
              <CheckCircle2 className="w-4 h-4 inline mr-1 text-emerald-500" /> Principaux Resultats et Realisations
            </h3>
            {data.achievements.length === 0 ? (
              <p className="text-sm text-muted-foreground">Aucun resultat enregistre pour le moment.</p>
            ) : (
              <div className="space-y-3">
                {data.achievements.map((a, i) => (
                  <div key={i} className="glass p-4 rounded-lg">
                    <Badge variant="secondary" className="text-[10px] mb-2">{a.projectName}</Badge>
                    <p className="text-sm">{a.text}</p>
                  </div>
                ))}
              </div>
            )}

            {data.upcoming.length > 0 && (
              <>
                <h3 className="text-sm font-semibold mt-6 mb-4" style={{ fontFamily: "'Poppins', sans-serif" }}>
                  <Target className="w-4 h-4 inline mr-1 text-primary" /> Actions a Venir
                </h3>
                <div className="space-y-3">
                  {data.upcoming.map((u, i) => (
                    <div key={i} className="glass p-4 rounded-lg border-l-2 border-primary">
                      <Badge variant="secondary" className="text-[10px] mb-2">{u.projectName}</Badge>
                      <p className="text-sm">{u.text}</p>
                    </div>
                  ))}
                </div>
              </>
            )}
          </Card>
        </TabsContent>

        {/* Difficulties Tab */}
        <TabsContent value="difficultes">
          <Card className="glass p-5">
            <h3 className="text-sm font-semibold mb-4" style={{ fontFamily: "'Poppins', sans-serif" }}>
              <AlertTriangle className="w-4 h-4 inline mr-1 text-red-500" /> Difficultes et Risques
            </h3>
            {data.difficulties.length === 0 ? (
              <p className="text-sm text-muted-foreground">Aucune difficulte ou risque enregistre.</p>
            ) : (
              <div className="space-y-3">
                {data.difficulties.map((d, i) => {
                  const critColor = d.criticality === "HIGH" ? "text-red-500 bg-red-500/10" : d.criticality === "MEDIUM" ? "text-[#EF7A16] bg-[#EF7A16]/10" : "text-emerald-500 bg-emerald-500/10";
                  return (
                    <div key={i} className="glass p-4 rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <Badge variant="secondary" className="text-[10px]">{d.projectName}</Badge>
                        <Badge className={`text-[10px] ${critColor}`}>{d.criticality}</Badge>
                      </div>
                      <p className="text-sm">{d.description}</p>
                      {d.mitigation && (
                        <p className="text-xs text-muted-foreground mt-2">
                          <strong>Attenuation :</strong> {d.mitigation}
                        </p>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </Card>
        </TabsContent>

        {/* Analytics Tab */}
        <TabsContent value="analytics">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Pillar Distribution */}
            <Card className="glass p-5">
              <h3 className="text-sm font-semibold mb-4" style={{ fontFamily: "'Poppins', sans-serif" }}>Repartition par Pilier</h3>
              <div className="flex items-center gap-4">
                <ResponsiveContainer width={160} height={160}>
                  <PieChart>
                    <Pie data={pillarChartData} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={40} outerRadius={70} paddingAngle={2}>
                      {pillarChartData.map((entry, i) => <Cell key={i} fill={entry.fill} />)}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
                <div className="flex-1 space-y-2">
                  {pillarChartData.map((p, i) => (
                    <div key={i} className="flex items-center gap-2 text-xs">
                      <div className="w-3 h-3 rounded-full flex-shrink-0" style={{ backgroundColor: p.fill }} />
                      <span className="text-muted-foreground flex-1">{p.name}</span>
                      <span className="font-medium">{p.value}</span>
                      <span className="text-muted-foreground">{formatCurrency(p.amount)}</span>
                    </div>
                  ))}
                </div>
              </div>
            </Card>

            {/* Top Projects by Amount */}
            <Card className="glass p-5">
              <h3 className="text-sm font-semibold mb-4" style={{ fontFamily: "'Poppins', sans-serif" }}>Top Projets par Montant</h3>
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={projectsByAmount.slice(0, 8).map(p => ({ name: p.projectName.substring(0, 20), amount: p.totalAmount }))} layout="vertical">
                  <XAxis type="number" tickFormatter={(v) => `${(v / 1e6).toFixed(0)}M`} fontSize={10} />
                  <YAxis type="category" dataKey="name" width={120} fontSize={10} />
                  <Tooltip formatter={(value) => formatCurrency(Number(value))} />
                  <Bar dataKey="amount" fill="#0089D0" radius={[0, 6, 6, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </Card>

            {/* Execution Summary */}
            <Card className="glass p-5 lg:col-span-2">
              <h3 className="text-sm font-semibold mb-4" style={{ fontFamily: "'Poppins', sans-serif" }}>Execution Globale</h3>
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span className="text-muted-foreground">Taux d'execution physique moyen</span>
                    <span className="font-bold text-primary">{data.stats.avgPhysicalRate}%</span>
                  </div>
                  <Progress value={data.stats.avgPhysicalRate} className="h-4" />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span className="text-muted-foreground">Taux d'absorption financiere moyen</span>
                    <span className="font-bold text-[#EF7A16]">{data.stats.avgFinancialRate}%</span>
                  </div>
                  <Progress value={data.stats.avgFinancialRate} className="h-4" />
                </div>
              </div>
              <div className="grid grid-cols-4 gap-4 mt-6">
                <div className="text-center">
                  <p className="text-2xl font-bold text-primary" style={{ fontFamily: "'Poppins', sans-serif" }}>{data.stats.totalProjects}</p>
                  <p className="text-[10px] text-muted-foreground">Projets total</p>
                </div>
                <div className="text-center">
                  <p className="text-2xl font-bold text-emerald-500" style={{ fontFamily: "'Poppins', sans-serif" }}>{data.stats.activeProjects}</p>
                  <p className="text-[10px] text-muted-foreground">Projets actifs</p>
                </div>
                <div className="text-center">
                  <p className="text-2xl font-bold text-primary" style={{ fontFamily: "'Poppins', sans-serif" }}>{formatCurrency(data.stats.totalFinancial)}</p>
                  <p className="text-[10px] text-muted-foreground">Cout global</p>
                </div>
                <div className="text-center">
                  <p className="text-sm font-bold" style={{ fontFamily: "'Poppins', sans-serif" }}>
                    {data.stats.earliestStart ? formatDate(data.stats.earliestStart) : "—"}
                    <br />
                    <span className="text-muted-foreground">→</span>
                    <br />
                    {data.stats.latestEnd ? formatDate(data.stats.latestEnd) : "—"}
                  </p>
                  <p className="text-[10px] text-muted-foreground">Periode</p>
                </div>
              </div>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      {/* Edit Project Modal */}
      {editProject && (() => {
        const proj = data.projects.find(p => p.id === editProject);
        if (!proj) return null;
        return <EditProjectModal project={proj} open={true} onClose={() => setEditProject(null)} onSaved={reload} />;
      })()}
    </div>
  );
}
