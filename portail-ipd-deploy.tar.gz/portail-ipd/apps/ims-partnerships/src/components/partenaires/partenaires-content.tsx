"use client";

import { useEffect, useState, useMemo } from "react";
import Link from "next/link";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { formatCurrency } from "@/lib/utils";
import { Search, Building2, ArrowUpRight, Globe, LayoutGrid, Cloud, List, Users, FolderKanban, Link2 } from "lucide-react";
import { WordCloud } from "./word-cloud";

import { StatusToggle } from "@/components/ui/status-toggle";

interface Partner {
  id: string;
  name: string;
  acronym: string | null;
  type: string;
  country: string;
  city: string | null;
  tier: string;
  groupId: string | null;
  groupName: string | null;
  activeProjects: number;
  inactiveProjects: number;
  _count: { projects: number };
}

interface PartnerGroupData {
  id: string;
  name: string;
  partners: Array<{ id: string; name: string; acronym: string | null }>;
}

const TYPE_LABELS: Record<string, string> = {
  FONDATION: "Fondations",
  INSTITUTION_FINANCIERE: "Institutions financieres",
  GOUVERNEMENT: "Gouvernements",
  ONG_SANTE: "ONG Sante",
  ACADEMIE: "Academie",
  INDUSTRIE: "Industrie",
};

const TYPE_COLORS: Record<string, string> = {
  FONDATION: "#0089D0",
  INSTITUTION_FINANCIERE: "#FFD500",
  GOUVERNEMENT: "#EF7A16",
  ONG_SANTE: "#10b981",
  ACADEMIE: "#8b5cf6",
  INDUSTRIE: "#ec4899",
};

const TIER_LABELS: Record<string, string> = {
  TIER1: "Tier 1 (>=20M$)",
  TIER2: "Tier 2 (1-5M$)",
  TIER3: "Tier 3 (<1M$)",
};

const COUNTRY_REGIONS: Record<string, string> = {
  "USA": "Amerique",
  "Canada": "Amerique",
  "France": "Europe",
  "Suisse": "Europe",
  "UK": "Europe",
  "Belgique": "Europe",
  "Norvege": "Europe",
  "Luxembourg": "Europe",
  "Allemagne": "Europe",
  "Senegal": "Afrique",
  "Cote d'Ivoire": "Afrique",
  "Ethiopie": "Afrique",
  "Afrique du Sud": "Afrique",
  "Coree du Sud": "Asie",
  "Japon": "Asie",
};

export function PartenairesContent() {
  const [partners, setPartners] = useState<Partner[]>([]);
  const [groups, setGroups] = useState<PartnerGroupData[]>([]);
  const [search, setSearch] = useState("");
  const [filterType, setFilterType] = useState("ALL");
  const [filterTier, setFilterTier] = useState("ALL");
  const [filterRegion, setFilterRegion] = useState("ALL");
  const [filterGroup, setFilterGroup] = useState("ALL"); // ALL, GROUPED, UNGROUPED, or group id
  const [statusToggle, setStatusToggle] = useState<"ALL" | "ACTIF" | "INACTIF">("ALL");
  const [viewMode, setViewMode] = useState<"grid" | "cloud" | "list">("grid");

  useEffect(() => {
    fetch("/api/partners").then(r => r.json()).then((data: any) => {
      // Handle both old format (array) and new format ({partners, groups})
      if (Array.isArray(data)) {
        setPartners(data);
      } else {
        setPartners(data.partners);
        setGroups(data.groups || []);
      }
    });
  }, []);

  const regions = useMemo(() => {
    const set = new Set<string>();
    partners.forEach(p => {
      const region = COUNTRY_REGIONS[p.country] || "Autre";
      set.add(region);
    });
    return Array.from(set).sort();
  }, [partners]);

  const countries = useMemo(() => {
    const set = new Set<string>();
    partners.forEach(p => set.add(p.country));
    return Array.from(set).sort();
  }, [partners]);

  const filtered = useMemo(() => {
    return partners.filter(p => {
      if (search) {
        const s = search.toLowerCase();
        if (
          !p.name.toLowerCase().includes(s) &&
          !(p.acronym || "").toLowerCase().includes(s) &&
          !p.country.toLowerCase().includes(s)
        )
          return false;
      }
      if (filterType !== "ALL" && p.type !== filterType) return false;
      if (filterTier !== "ALL" && p.tier !== filterTier) return false;
      if (statusToggle === "ACTIF" && p.activeProjects === 0) return false;
      if (statusToggle === "INACTIF" && p.activeProjects > 0) return false;
      if (filterGroup === "GROUPED" && !p.groupId) return false;
      if (filterGroup === "UNGROUPED" && p.groupId) return false;
      if (filterGroup !== "ALL" && filterGroup !== "GROUPED" && filterGroup !== "UNGROUPED" && p.groupId !== filterGroup) return false;
      if (filterRegion !== "ALL") {
        const region = COUNTRY_REGIONS[p.country] || "Autre";
        if (region !== filterRegion) return false;
      }
      return true;
    });
  }, [partners, search, filterType, filterTier, filterRegion, statusToggle, filterGroup]);

  // Stats
  const typeCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    filtered.forEach(p => {
      counts[p.type] = (counts[p.type] || 0) + 1;
    });
    return counts;
  }, [filtered]);

  // Total projects across filtered partners
  const totalProjects = useMemo(() => filtered.reduce((s, p) => s + p._count.projects, 0), [filtered]);
  const totalCountries = useMemo(() => new Set(filtered.map(p => p.country)).size, [filtered]);
  const tierCounts = useMemo(() => {
    const c: Record<string, number> = {};
    filtered.forEach(p => { c[p.tier] = (c[p.tier] || 0) + 1; });
    return c;
  }, [filtered]);

  return (
    <div className="space-y-5">
      {/* Total Partners Hero */}
      <div className="flex gap-4 items-stretch">
        {/* Main counter */}
        <Card className="glass p-5 glow-cyan flex items-center gap-5 flex-shrink-0">
          <div className="relative w-24 h-24">
            <svg viewBox="0 0 36 36" className="w-full h-full -rotate-90">
              <path
                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                fill="none" stroke="currentColor" className="text-muted/20" strokeWidth="3"
              />
              <path
                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                fill="none" stroke="#0089D0" strokeWidth="3"
                strokeDasharray={`${partners.length > 0 ? (filtered.length / partners.length) * 100 : 100}, 100`}
                strokeLinecap="round"
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-3xl font-bold text-[#0089D0]" style={{ fontFamily: "'Poppins', sans-serif" }}>
                {filtered.length}
              </span>
              <span className="text-[9px] text-muted-foreground">partenaires</span>
            </div>
          </div>
          <div>
            <h3 className="text-sm font-bold" style={{ fontFamily: "'Poppins', sans-serif" }}>
              {filtered.length === partners.length ? "Total Partenaires" : "Partenaires filtres"}
            </h3>
            {filtered.length !== partners.length && (
              <p className="text-[10px] text-muted-foreground">sur {partners.length} au total</p>
            )}
            <div className="flex gap-3 mt-2">
              <div className="text-center">
                <p className="text-sm font-bold text-emerald-500" style={{ fontFamily: "'Poppins', sans-serif" }}>{totalProjects}</p>
                <p className="text-[9px] text-muted-foreground">projets</p>
              </div>
              <div className="text-center">
                <p className="text-sm font-bold text-[#EF7A16]" style={{ fontFamily: "'Poppins', sans-serif" }}>{totalCountries}</p>
                <p className="text-[9px] text-muted-foreground">pays</p>
              </div>
            </div>
          </div>
        </Card>

        {/* Tier breakdown */}
        <div className="grid grid-cols-3 gap-3 flex-1">
          {(["TIER1", "TIER2", "TIER3"] as const).map(tier => {
            const count = tierCounts[tier] || 0;
            const pct = filtered.length > 0 ? Math.round((count / filtered.length) * 100) : 0;
            const colors: Record<string, string> = { TIER1: "#0089D0", TIER2: "#EF7A16", TIER3: "#8b5cf6" };
            return (
              <Card
                key={tier}
                className={`glass p-4 cursor-pointer transition-all ${filterTier === tier ? "glow-cyan ring-1 ring-primary" : "hover:bg-accent/50"}`}
                onClick={() => setFilterTier(filterTier === tier ? "ALL" : tier)}
              >
                <p className="text-2xl font-bold" style={{ fontFamily: "'Poppins', sans-serif", color: colors[tier] }}>
                  {count}
                </p>
                <p className="text-[10px] text-muted-foreground">{TIER_LABELS[tier]}</p>
                <div className="h-1.5 rounded-full bg-muted overflow-hidden mt-2">
                  <div className="h-full rounded-full transition-all duration-500" style={{ width: `${pct}%`, backgroundColor: colors[tier] }} />
                </div>
                <p className="text-[9px] text-muted-foreground mt-1">{pct}% du total</p>
              </Card>
            );
          })}
        </div>
      </div>

      {/* Status Toggle */}
      <StatusToggle value={statusToggle} onChange={setStatusToggle} />

      {/* Groups info + filter */}
      {groups.length > 0 && (
        <div className="flex items-center gap-3 flex-wrap">
          <div className="flex items-center gap-1.5">
            <Link2 className="w-4 h-4 text-[#0089D0]" />
            <span className="text-xs font-medium">{groups.length} groupes de partenaires</span>
            <span className="text-[10px] text-muted-foreground">({partners.filter(p => p.groupId).length} partenaires regroupes)</span>
          </div>
          <Select value={filterGroup} onValueChange={v => setFilterGroup(v || "ALL")}>
            <SelectTrigger className="w-[200px] glass h-8 text-xs">
              <Link2 className="w-3.5 h-3.5 mr-1.5 text-[#0089D0]" />
              <SelectValue placeholder="Regroupement" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="ALL">Tous les partenaires</SelectItem>
              <SelectItem value="GROUPED">Partenaires regroupes</SelectItem>
              <SelectItem value="UNGROUPED">Partenaires uniques</SelectItem>
              {groups.map(g => (
                <SelectItem key={g.id} value={g.id}>
                  {g.name} ({g.partners.length})
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          {filterGroup !== "ALL" && filterGroup !== "GROUPED" && filterGroup !== "UNGROUPED" && (
            <div className="flex gap-1 flex-wrap">
              {groups.find(g => g.id === filterGroup)?.partners.map(p => (
                <Badge key={p.id} variant="outline" className="text-[9px]">
                  {p.acronym || p.name.substring(0, 15)}
                </Badge>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Stats Bar by Type */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        {Object.entries(TYPE_LABELS).map(([key, label]) => (
          <Card
            key={key}
            className={`glass p-3 cursor-pointer transition-all ${filterType === key ? "glow-cyan ring-1 ring-primary" : "hover:bg-accent/50"}`}
            onClick={() => setFilterType(filterType === key ? "ALL" : key)}
          >
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full flex-shrink-0" style={{ backgroundColor: TYPE_COLORS[key] }} />
              <div>
                <p className="text-lg font-bold" style={{ fontFamily: "'Poppins', sans-serif" }}>
                  {typeCounts[key] || 0}
                </p>
                <p className="text-[10px] text-muted-foreground leading-tight">{label}</p>
              </div>
            </div>
          </Card>
        ))}
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-3 items-center">
        <div className="relative flex-1 min-w-[240px] max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Rechercher par nom, acronyme ou pays..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9 glass"
          />
        </div>
        <Select value={filterType} onValueChange={(v) => setFilterType(v || "ALL")}>
          <SelectTrigger className="w-[180px] glass"><SelectValue placeholder="Type" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="ALL">Tous les types</SelectItem>
            {Object.entries(TYPE_LABELS).map(([k, v]) => (
              <SelectItem key={k} value={k}>{v}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={filterTier} onValueChange={(v) => setFilterTier(v || "ALL")}>
          <SelectTrigger className="w-[160px] glass"><SelectValue placeholder="Tier" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="ALL">Tous les tiers</SelectItem>
            {Object.entries(TIER_LABELS).map(([k, v]) => (
              <SelectItem key={k} value={k}>{v}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={filterRegion} onValueChange={(v) => setFilterRegion(v || "ALL")}>
          <SelectTrigger className="w-[150px] glass"><SelectValue placeholder="Region" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="ALL">Toutes les regions</SelectItem>
            {regions.map(r => (
              <SelectItem key={r} value={r}>{r}</SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Badge variant="secondary">{filtered.length} partenaires</Badge>

        {/* View toggle */}
        <div className="flex gap-1 ml-auto glass rounded-lg p-1">
          <Button variant={viewMode === "grid" ? "default" : "ghost"} size="sm" className="h-7 w-7 p-0" onClick={() => setViewMode("grid")}>
            <LayoutGrid className="w-3.5 h-3.5" />
          </Button>
          <Button variant={viewMode === "cloud" ? "default" : "ghost"} size="sm" className="h-7 w-7 p-0" onClick={() => setViewMode("cloud")}>
            <Cloud className="w-3.5 h-3.5" />
          </Button>
          <Button variant={viewMode === "list" ? "default" : "ghost"} size="sm" className="h-7 w-7 p-0" onClick={() => setViewMode("list")}>
            <List className="w-3.5 h-3.5" />
          </Button>
        </div>
      </div>

      {/* Content */}
      {viewMode === "cloud" && (
        <Card className="glass p-6">
          <h3 className="text-sm font-semibold mb-4" style={{ fontFamily: "'Poppins', sans-serif" }}>
            <Cloud className="w-4 h-4 inline mr-1" /> WordCloud des Partenaires
          </h3>
          <WordCloud
            partners={filtered.map(p => ({
              id: p.id,
              name: p.acronym || p.name.split(" ").slice(0, 2).join(" "),
              fullName: p.name,
              count: p._count.projects,
              type: p.type,
              color: TYPE_COLORS[p.type] || "#0089D0",
            }))}
          />
        </Card>
      )}

      {viewMode === "grid" && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
          {filtered.map((partner, i) => (
            <Link key={partner.id} href={`/partenaires/${partner.id}`}>
              <Card
                className="glass p-4 hover:glow-cyan transition-all cursor-pointer group animate-fade-up h-full"
                style={{ animationDelay: `${Math.min(i, 20) * 0.02}s` }}
              >
                <div className="flex items-start gap-3">
                  <div
                    className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 text-white text-xs font-bold"
                    style={{ backgroundColor: TYPE_COLORS[partner.type] || "#0089D0" }}
                  >
                    {(partner.acronym || partner.name).substring(0, 2).toUpperCase()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold truncate group-hover:text-primary transition-colors" style={{ fontFamily: "'Poppins', sans-serif" }}>
                      {partner.acronym || partner.name}
                    </p>
                    <p className="text-[11px] text-muted-foreground truncate">{partner.name}</p>
                  </div>
                  <ArrowUpRight className="w-4 h-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity flex-shrink-0" />
                </div>

                <div className="flex flex-wrap gap-1.5 mt-3">
                  <Badge variant="outline" className="text-[10px]" style={{ borderColor: TYPE_COLORS[partner.type], color: TYPE_COLORS[partner.type] }}>
                    {TYPE_LABELS[partner.type]}
                  </Badge>
                  <Badge variant="secondary" className="text-[10px]">
                    {partner.tier.replace("TIER", "Tier ")}
                  </Badge>
                </div>

                {partner.groupName && (
                  <div className="flex items-center gap-1 mt-2">
                    <Link2 className="w-3 h-3 text-[#0089D0]" />
                    <span className="text-[9px] text-[#0089D0] font-medium">Groupe: {partner.groupName}</span>
                  </div>
                )}

                <div className="flex items-center justify-between mt-2 text-xs text-muted-foreground">
                  <div className="flex items-center gap-1">
                    <Globe className="w-3 h-3" />
                    <span>{partner.country}</span>
                  </div>
                  <span className="font-medium text-foreground">{partner._count.projects} projet{partner._count.projects > 1 ? "s" : ""}</span>
                </div>
              </Card>
            </Link>
          ))}
        </div>
      )}

      {viewMode === "list" && (
        <Card className="glass overflow-hidden">
          <div className="divide-y divide-border">
            {filtered.map(partner => (
              <Link key={partner.id} href={`/partenaires/${partner.id}`} className="flex items-center gap-4 px-5 py-3 hover:bg-accent/50 transition-colors">
                <div
                  className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 text-white text-[10px] font-bold"
                  style={{ backgroundColor: TYPE_COLORS[partner.type] || "#0089D0" }}
                >
                  {(partner.acronym || partner.name).substring(0, 2).toUpperCase()}
                </div>
                <div className="flex-1 min-w-0">
                  <span className="text-sm font-medium">{partner.acronym && `${partner.acronym} — `}{partner.name}</span>
                </div>
                <Badge variant="outline" className="text-[10px]" style={{ borderColor: TYPE_COLORS[partner.type], color: TYPE_COLORS[partner.type] }}>
                  {TYPE_LABELS[partner.type]}
                </Badge>
                <Badge variant="secondary" className="text-[10px]">{partner.tier.replace("TIER", "T")}</Badge>
                {partner.groupName && <Badge className="text-[8px] bg-[#0089D0]/10 text-[#0089D0]"><Link2 className="w-2.5 h-2.5 mr-0.5" />{partner.groupName}</Badge>}
                <span className="text-xs text-muted-foreground w-20">{partner.country}</span>
                <span className="text-xs font-medium w-16 text-right">{partner._count.projects} flux</span>
                <ArrowUpRight className="w-4 h-4 text-muted-foreground" />
              </Link>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
}
