"use client";

import { useEffect, useState, useMemo } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { formatCurrency, PILLAR_COLORS, PILLAR_LABELS } from "@/lib/utils";
import {
  Search, Gauge, Send, CheckCircle2, ChevronRight, TrendingUp,
  ArrowUp, ArrowDown, Minus, Building2, Target,
} from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell, LabelList, LineChart, Line, CartesianGrid } from "recharts";

interface Indicator {
  id: string;
  code: string;
  category: string;
  pillar: string | null;
  department: string | null;
  name: string;
  description: string | null;
  formula: string | null;
  baseline: string | null;
  target2025: string | null;
  target2027: string | null;
  target2032: string | null;
  unit: string | null;
  frequency: string | null;
  values: Array<{ id: string; period: string; targetValue: string | null; actualValue: string | null; status: string; projectId: string | null; comments: string | null }>;
}

interface Project {
  id: string;
  projectName: string;
  pillar: string;
  status: string;
  departmentLead: string | null;
  partner: { name: string; acronym: string | null };
}

const STATUS_CONFIG: Record<string, { label: string; color: string }> = {
  PENDING: { label: "En attente", color: "#6b7280" },
  ON_TRACK: { label: "En bonne voie", color: "#10b981" },
  AT_RISK: { label: "A risque", color: "#EF7A16" },
  OFF_TRACK: { label: "Hors piste", color: "#ef4444" },
  ACHIEVED: { label: "Atteint", color: "#0089D0" },
};

const CATEGORY_COLORS: Record<string, string> = {
  EFFECT: "#0089D0",
  IMPACT: "#10b981",
  OPERATIONAL: "#EF7A16",
};

export function IndicateursSaisieForm() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [indicators, setIndicators] = useState<Indicator[]>([]);
  const [search, setSearch] = useState("");
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [selectedIndicator, setSelectedIndicator] = useState<Indicator | null>(null);
  const [saving, setSaving] = useState(false);
  const [success, setSuccess] = useState("");

  const [valForm, setValForm] = useState({
    period: "2025-Q2",
    targetValue: "",
    actualValue: "",
    status: "PENDING",
    comments: "",
  });

  useEffect(() => {
    Promise.all([
      fetch("/api/projects").then(r => r.json()),
      fetch("/api/indicators").then(r => r.json()),
    ]).then(([p, i]) => {
      setProjects(p.filter((proj: Project) => proj.status === "ACTIF"));
      setIndicators(i);
    });
  }, []);

  // Filter indicators relevant to the selected project (by pillar/department)
  const relevantIndicators = useMemo(() => {
    if (!selectedProject) return [];
    return indicators.filter(ind => {
      if (search) {
        const s = search.toLowerCase();
        if (!ind.name.toLowerCase().includes(s) && !ind.code.toLowerCase().includes(s)) return false;
      }
      // Strategic indicators matching project pillar
      if (ind.category !== "OPERATIONAL" && ind.pillar) {
        return ind.pillar === selectedProject.pillar || ind.pillar === "TRANSVERSAL";
      }
      // Operational indicators matching project department
      if (ind.category === "OPERATIONAL" && ind.department) {
        const deptMap: Record<string, string[]> = {
          DOI: ["DOI", "Diatropix"],
          DREI: ["DREI"],
          DSP: ["DSP"],
          CARE: ["DCH", "CARE"],
          DPC: ["DPC", "UVFJ"],
          DFC: ["DFC", "CAS"],
        };
        for (const [dept, matches] of Object.entries(deptMap)) {
          if (ind.department === dept && matches.includes(selectedProject.departmentLead || "")) return true;
        }
      }
      return false;
    });
  }, [indicators, selectedProject, search]);

  // Values for the selected indicator linked to the selected project
  const projectValues = useMemo(() => {
    if (!selectedIndicator || !selectedProject) return [];
    return selectedIndicator.values.filter(v => v.projectId === selectedProject.id);
  }, [selectedIndicator, selectedProject]);

  // All values for the selected indicator (global evolution)
  const allValues = useMemo(() => {
    if (!selectedIndicator) return [];
    return [...selectedIndicator.values].sort((a, b) => a.period.localeCompare(b.period));
  }, [selectedIndicator]);

  const submitValue = async () => {
    if (!selectedIndicator || !selectedProject || !valForm.period) return;
    setSaving(true);
    try {
      await fetch(`/api/indicators/${selectedIndicator.id}/values`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...valForm, projectId: selectedProject.id }),
      });
      setSuccess("Valeur enregistree !");
      setValForm(f => ({ ...f, targetValue: "", actualValue: "", comments: "" }));
      const updated = await fetch("/api/indicators").then(r => r.json());
      setIndicators(updated);
      setSelectedIndicator(updated.find((i: Indicator) => i.id === selectedIndicator.id) || null);
    } catch {} finally {
      setSaving(false);
    }
  };

  const departments = [...new Set(projects.map(p => p.departmentLead).filter(Boolean))];
  const [filterDept, setFilterDept] = useState("ALL");

  const filteredProjects = projects.filter(p => {
    if (filterDept !== "ALL" && p.departmentLead !== filterDept) return false;
    return true;
  });

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
      {/* Col 1: Project selector */}
      <div className="lg:col-span-3 space-y-3">
        <Select value={filterDept} onValueChange={v => setFilterDept(v || "ALL")}>
          <SelectTrigger className="glass"><SelectValue placeholder="Departement" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="ALL">Tous departements</SelectItem>
            {departments.map(d => <SelectItem key={d!} value={d!}>{d}</SelectItem>)}
          </SelectContent>
        </Select>

        <p className="text-[10px] text-muted-foreground">{filteredProjects.length} projets actifs</p>

        <div className="space-y-1.5 max-h-[calc(100vh-330px)] overflow-y-auto">
          {filteredProjects.map(project => {
            const isSelected = selectedProject?.id === project.id;
            return (
              <Card
                key={project.id}
                className={`glass p-2.5 cursor-pointer transition-all ${isSelected ? "glow-cyan ring-1 ring-primary" : "hover:bg-accent/50"}`}
                onClick={() => { setSelectedProject(project); setSelectedIndicator(null); setSuccess(""); }}
              >
                <div className="flex items-center gap-2">
                  <div className="w-1.5 h-7 rounded-full" style={{ backgroundColor: PILLAR_COLORS[project.pillar] }} />
                  <div className="flex-1 min-w-0">
                    <p className="text-[11px] font-semibold truncate">{project.projectName}</p>
                    <span className="text-[9px] text-muted-foreground">{project.partner.acronym || project.partner.name}</span>
                  </div>
                  <ChevronRight className="w-3 h-3 text-muted-foreground" />
                </div>
              </Card>
            );
          })}
        </div>
      </div>

      {/* Col 2: Indicator list for selected project */}
      <div className="lg:col-span-3 space-y-3">
        {!selectedProject ? (
          <Card className="glass p-8 text-center">
            <Building2 className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
            <p className="text-xs text-muted-foreground">Selectionnez un projet</p>
          </Card>
        ) : (
          <>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
              <Input placeholder="Filtrer indicateurs..." value={search} onChange={e => setSearch(e.target.value)} className="pl-8 glass text-xs h-8" />
            </div>
            <p className="text-[10px] text-muted-foreground">
              {relevantIndicators.length} indicateurs lies a <strong>{PILLAR_LABELS[selectedProject.pillar]}</strong>
              {selectedProject.departmentLead && <> / <strong>{selectedProject.departmentLead}</strong></>}
            </p>
            <div className="space-y-1 max-h-[calc(100vh-370px)] overflow-y-auto">
              {relevantIndicators.map(ind => {
                const isSelected = selectedIndicator?.id === ind.id;
                const hasValues = ind.values.length > 0;
                const catColor = CATEGORY_COLORS[ind.category];
                return (
                  <div
                    key={ind.id}
                    className={`glass p-2.5 rounded-lg cursor-pointer transition-all ${isSelected ? "ring-1 ring-primary glow-cyan" : "hover:bg-accent/50"}`}
                    onClick={() => { setSelectedIndicator(ind); setSuccess(""); }}
                  >
                    <div className="flex items-start gap-2">
                      <Badge className="text-[8px] mt-0.5 flex-shrink-0" style={{ backgroundColor: `${catColor}20`, color: catColor }}>
                        {ind.code}
                      </Badge>
                      <div className="flex-1 min-w-0">
                        <p className="text-[11px] font-medium leading-tight">{ind.name}</p>
                        <div className="flex items-center gap-1 mt-0.5">
                          {hasValues && <CheckCircle2 className="w-3 h-3 text-emerald-500" />}
                          {ind.unit && <span className="text-[9px] text-muted-foreground">{ind.unit}</span>}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </>
        )}
      </div>

      {/* Col 3: Saisie + Evolution */}
      <div className="lg:col-span-6">
        {!selectedIndicator ? (
          <Card className="glass p-12 text-center">
            <Gauge className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
            <p className="text-sm text-muted-foreground">Selectionnez un indicateur pour saisir ses valeurs et voir son evolution</p>
          </Card>
        ) : (
          <div className="space-y-4">
            {success && (
              <div className="flex items-center gap-2 text-emerald-500 text-sm glass p-2 rounded-lg">
                <CheckCircle2 className="w-4 h-4" /> {success}
              </div>
            )}

            {/* Indicator header */}
            <Card className="glass p-4" style={{ borderLeft: `3px solid ${CATEGORY_COLORS[selectedIndicator.category]}` }}>
              <div className="flex items-start justify-between gap-3">
                <div>
                  <Badge className="text-[10px]" style={{ backgroundColor: `${CATEGORY_COLORS[selectedIndicator.category]}20`, color: CATEGORY_COLORS[selectedIndicator.category] }}>
                    {selectedIndicator.code}
                  </Badge>
                  <h4 className="text-sm font-bold mt-1" style={{ fontFamily: "'Poppins', sans-serif" }}>{selectedIndicator.name}</h4>
                  {selectedIndicator.description && <p className="text-[10px] text-muted-foreground mt-1">{selectedIndicator.description}</p>}
                  {selectedIndicator.formula && <p className="text-[10px] text-muted-foreground mt-0.5">Formule: <code className="glass px-1 rounded">{selectedIndicator.formula}</code></p>}
                </div>
              </div>
              {/* Targets */}
              <div className="grid grid-cols-4 gap-2 mt-3">
                {[
                  { label: "Baseline", val: selectedIndicator.baseline, color: "#6b7280" },
                  { label: "Cible 2025", val: selectedIndicator.target2025, color: "#EF7A16" },
                  { label: "Cible 2027", val: selectedIndicator.target2027, color: "#0089D0" },
                  { label: "Cible 2032", val: selectedIndicator.target2032, color: "#10b981" },
                ].map((t, i) => (
                  <div key={i} className="glass rounded p-2 text-center">
                    <p className="text-[8px] text-muted-foreground">{t.label}</p>
                    <p className="text-xs font-bold" style={{ color: t.color }}>{t.val || "—"}</p>
                  </div>
                ))}
              </div>
            </Card>

            {/* Evolution chart */}
            {allValues.length > 0 && (
              <Card className="glass p-4">
                <h5 className="text-xs font-semibold mb-3" style={{ fontFamily: "'Poppins', sans-serif" }}>
                  <TrendingUp className="w-3.5 h-3.5 inline mr-1" /> Evolution des valeurs
                </h5>
                <ResponsiveContainer width="100%" height={160}>
                  <LineChart data={allValues.map(v => ({ period: v.period, cible: v.targetValue ? parseFloat(v.targetValue) || 0 : null, realise: v.actualValue ? parseFloat(v.actualValue) || 0 : null }))}>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                    <XAxis dataKey="period" fontSize={10} />
                    <YAxis fontSize={10} />
                    <Tooltip contentStyle={{ background: "var(--card)", border: "1px solid var(--border)", borderRadius: 8, fontSize: 11 }} />
                    <Line type="monotone" dataKey="cible" stroke="#EF7A16" strokeWidth={2} strokeDasharray="5 5" dot={false} name="Cible" />
                    <Line type="monotone" dataKey="realise" stroke="#0089D0" strokeWidth={2} dot={{ r: 4 }} name="Realise" />
                  </LineChart>
                </ResponsiveContainer>
              </Card>
            )}

            {/* Historique saisies pour ce projet */}
            {projectValues.length > 0 && (
              <Card className="glass p-4">
                <h5 className="text-xs font-semibold mb-2" style={{ fontFamily: "'Poppins', sans-serif" }}>
                  Saisies pour ce projet ({projectValues.length})
                </h5>
                <div className="space-y-1.5">
                  {projectValues.map((v, i) => {
                    const sc = STATUS_CONFIG[v.status];
                    return (
                      <div key={v.id} className="glass p-2 rounded flex items-center gap-3 text-xs">
                        <Badge variant="outline" className="text-[9px]">{v.period}</Badge>
                        <div className="flex-1">
                          {v.targetValue && <span className="text-muted-foreground">Cible: <strong>{v.targetValue}</strong></span>}
                          {v.targetValue && v.actualValue && <span className="mx-1.5">|</span>}
                          {v.actualValue && <span>Realise: <strong className="text-primary">{v.actualValue}</strong></span>}
                        </div>
                        <Badge className="text-[9px]" style={{ backgroundColor: `${sc.color}20`, color: sc.color }}>{sc.label}</Badge>
                        {v.comments && <span className="text-[9px] text-muted-foreground truncate max-w-[120px]">{v.comments}</span>}
                      </div>
                    );
                  })}
                </div>
              </Card>
            )}

            {/* Saisie form */}
            <Card className="p-4 border-primary/20">
              <h5 className="text-xs font-semibold mb-3" style={{ fontFamily: "'Poppins', sans-serif" }}>
                Saisir une nouvelle valeur
              </h5>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-[10px]">Periode *</Label>
                  <Select value={valForm.period} onValueChange={v => setValForm(f => ({ ...f, period: v || "2025-Q2" }))}>
                    <SelectTrigger className="mt-1 h-8 text-xs"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {["2025-Q1", "2025-Q2", "2025-Q3", "2025-Q4", "2025", "2026-Q1", "2026-Q2", "2026-Q3", "2026-Q4", "2026", "2027"].map(p => (
                        <SelectItem key={p} value={p}>{p}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-[10px]">Statut</Label>
                  <Select value={valForm.status} onValueChange={v => setValForm(f => ({ ...f, status: v || "PENDING" }))}>
                    <SelectTrigger className="mt-1 h-8 text-xs"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {Object.entries(STATUS_CONFIG).map(([k, v]) => <SelectItem key={k} value={k}>{v.label}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-[10px]">Valeur cible {selectedIndicator.unit && `(${selectedIndicator.unit})`}</Label>
                  <Input value={valForm.targetValue} onChange={e => setValForm(f => ({ ...f, targetValue: e.target.value }))} className="mt-1 h-8 text-xs" placeholder={selectedIndicator.target2025 || ""} />
                </div>
                <div>
                  <Label className="text-[10px]">Valeur realisee {selectedIndicator.unit && `(${selectedIndicator.unit})`}</Label>
                  <Input value={valForm.actualValue} onChange={e => setValForm(f => ({ ...f, actualValue: e.target.value }))} className="mt-1 h-8 text-xs" />
                </div>
                <div className="col-span-2">
                  <Label className="text-[10px]">Commentaires</Label>
                  <Textarea value={valForm.comments} onChange={e => setValForm(f => ({ ...f, comments: e.target.value }))} className="mt-1 text-xs" rows={2} placeholder="Source des donnees, observations..." />
                </div>
              </div>
              <Button onClick={submitValue} disabled={saving} size="sm" className="mt-3">
                <Send className="w-3.5 h-3.5 mr-1.5" />{saving ? "Enregistrement..." : "Enregistrer la valeur"}
              </Button>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}
