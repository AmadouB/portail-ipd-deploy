"use client";

import { useEffect, useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Progress } from "@/components/ui/progress";
import { formatCurrency, PILLAR_COLORS, PILLAR_LABELS, STATUS_COLORS } from "@/lib/utils";
import { Search, Target, Send, CheckCircle2, MessageSquare, Phone, Mail, Calendar, ChevronRight, ArrowRight } from "lucide-react";

const PIPELINE_STAGES = [
  { key: "IDENTIFICATION", label: "Identification" },
  { key: "CONTACT", label: "Contact" },
  { key: "DISCUSSION", label: "Discussion" },
  { key: "ACCORD", label: "Accord" },
  { key: "NEGOCIATION", label: "Negociation" },
  { key: "SIGNATURE", label: "Signature" },
];

interface Project {
  id: string;
  projectName: string;
  pillar: string;
  status: string;
  totalAmount: number;
  maturationScore: number;
  departmentLead: string | null;
  hasFeasibilityStudy: boolean;
  hasImpactAssessment: boolean;
  hasFinancialStructure: boolean;
  hasIntentionLetter: boolean;
  hasLegalValidation: boolean;
  hasPillarConformity: boolean;
  partner: { name: string; acronym: string | null };
  prospectionNotes: Array<{ id: string; type: string; content: string; date: string; author: { name: string } | null }>;
}

export function ProspectionForm() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [search, setSearch] = useState("");
  const [filterStage, setFilterStage] = useState("ALL");
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [saving, setSaving] = useState(false);
  const [success, setSuccess] = useState("");

  // Note form
  const [noteForm, setNoteForm] = useState({
    type: "REUNION",
    content: "",
    date: new Date().toISOString().slice(0, 10),
  });

  // Status change
  const [newStatus, setNewStatus] = useState("");

  // Maturation toggles
  const [maturation, setMaturation] = useState({
    hasFeasibilityStudy: false,
    hasImpactAssessment: false,
    hasFinancialStructure: false,
    hasIntentionLetter: false,
    hasLegalValidation: false,
    hasPillarConformity: false,
  });

  useEffect(() => {
    fetch("/api/projects")
      .then(r => r.json())
      .then((data: Project[]) => {
        setProjects(data.filter(p => PIPELINE_STAGES.some(s => s.key === p.status)));
      });
  }, []);

  const filtered = projects.filter(p => {
    if (search) {
      const s = search.toLowerCase();
      if (!p.projectName.toLowerCase().includes(s) && !(p.partner.acronym || p.partner.name).toLowerCase().includes(s)) return false;
    }
    if (filterStage !== "ALL" && p.status !== filterStage) return false;
    return true;
  });

  const selectProject = (project: Project) => {
    setSelectedProject(project);
    setSuccess("");
    setNewStatus(project.status);
    setMaturation({
      hasFeasibilityStudy: project.hasFeasibilityStudy,
      hasImpactAssessment: project.hasImpactAssessment,
      hasFinancialStructure: project.hasFinancialStructure,
      hasIntentionLetter: project.hasIntentionLetter,
      hasLegalValidation: project.hasLegalValidation,
      hasPillarConformity: project.hasPillarConformity,
    });
    setNoteForm({ type: "REUNION", content: "", date: new Date().toISOString().slice(0, 10) });
  };

  const maturationScore =
    (maturation.hasFeasibilityStudy ? 20 : 0) +
    (maturation.hasImpactAssessment ? 15 : 0) +
    (maturation.hasFinancialStructure ? 25 : 0) +
    (maturation.hasIntentionLetter ? 15 : 0) +
    (maturation.hasLegalValidation ? 15 : 0) +
    (maturation.hasPillarConformity ? 10 : 0);

  const submitNote = async () => {
    if (!selectedProject || !noteForm.content) return;
    setSaving(true);
    try {
      await fetch(`/api/projects/${selectedProject.id}/notes`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type: noteForm.type,
          content: noteForm.content,
          date: new Date(noteForm.date).toISOString(),
        }),
      });
      setSuccess("Note ajoutee !");
      setNoteForm(f => ({ ...f, content: "" }));
      // Refresh
      const updated = await fetch("/api/projects").then(r => r.json());
      setProjects(updated.filter((p: Project) => PIPELINE_STAGES.some(s => s.key === p.status)));
      const refreshed = updated.find((p: Project) => p.id === selectedProject.id);
      if (refreshed) setSelectedProject(refreshed);
    } catch {} finally {
      setSaving(false);
    }
  };

  const submitUpdate = async () => {
    if (!selectedProject) return;
    setSaving(true);
    try {
      await fetch(`/api/projects/${selectedProject.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          status: newStatus,
          ...maturation,
          maturationScore,
        }),
      });
      setSuccess("Projet mis a jour !");
      // Refresh
      const updated = await fetch("/api/projects").then(r => r.json());
      const prospectionProjects = updated.filter((p: Project) => PIPELINE_STAGES.some(s => s.key === p.status));
      setProjects(prospectionProjects);
      const refreshed = prospectionProjects.find((p: Project) => p.id === selectedProject.id);
      if (refreshed) {
        setSelectedProject(refreshed);
        setNewStatus(refreshed.status);
      } else {
        setSelectedProject(null);
        setSuccess("Projet passe au statut Actif !");
      }
    } catch {} finally {
      setSaving(false);
    }
  };

  const noteIcons: Record<string, React.ReactNode> = {
    REUNION: <Calendar className="w-3.5 h-3.5 text-[#0089D0]" />,
    APPEL: <Phone className="w-3.5 h-3.5 text-emerald-500" />,
    EMAIL: <Mail className="w-3.5 h-3.5 text-[#EF7A16]" />,
    COMMENTAIRE: <MessageSquare className="w-3.5 h-3.5 text-purple-500" />,
  };

  const getScoreColor = (score: number) => score >= 75 ? "#10b981" : score >= 40 ? "#EF7A16" : "#ef4444";

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Left: Pipeline list */}
      <div className="space-y-4">
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input placeholder="Rechercher..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9 glass" />
          </div>
          <Select value={filterStage} onValueChange={v => setFilterStage(v || "ALL")}>
            <SelectTrigger className="w-[130px] glass"><SelectValue placeholder="Etape" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="ALL">Toutes</SelectItem>
              {PIPELINE_STAGES.map(s => <SelectItem key={s.key} value={s.key}>{s.label}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>

        {/* Stage summary */}
        <div className="flex gap-1 flex-wrap">
          {PIPELINE_STAGES.map(stage => {
            const count = projects.filter(p => p.status === stage.key).length;
            return (
              <Badge
                key={stage.key}
                variant={filterStage === stage.key ? "default" : "secondary"}
                className="text-[10px] cursor-pointer"
                onClick={() => setFilterStage(filterStage === stage.key ? "ALL" : stage.key)}
                style={filterStage === stage.key ? { backgroundColor: STATUS_COLORS[stage.key] } : {}}
              >
                {stage.label} ({count})
              </Badge>
            );
          })}
        </div>

        <div className="space-y-1.5 max-h-[calc(100vh-350px)] overflow-y-auto">
          {filtered.map(project => {
            const isSelected = selectedProject?.id === project.id;
            return (
              <Card
                key={project.id}
                className={`glass p-3 cursor-pointer transition-all ${isSelected ? "glow-cyan ring-1 ring-primary" : "hover:bg-accent/50"}`}
                onClick={() => selectProject(project)}
              >
                <div className="flex items-center gap-2">
                  <div className="w-1.5 h-8 rounded-full flex-shrink-0" style={{ backgroundColor: PILLAR_COLORS[project.pillar] }} />
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-semibold truncate">{project.projectName}</p>
                    <div className="flex items-center gap-1 mt-0.5">
                      <span className="text-[10px] text-muted-foreground">{project.partner.acronym || project.partner.name}</span>
                      <Badge variant="outline" className="text-[9px] h-4" style={{ borderColor: STATUS_COLORS[project.status], color: STATUS_COLORS[project.status] }}>
                        {project.status}
                      </Badge>
                    </div>
                  </div>
                  <div className="text-right flex-shrink-0">
                    <span className="text-xs font-bold" style={{ color: getScoreColor(project.maturationScore) }}>{project.maturationScore}%</span>
                  </div>
                  <ChevronRight className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0" />
                </div>
              </Card>
            );
          })}
        </div>
      </div>

      {/* Right: Forms */}
      <div className="lg:col-span-2">
        {!selectedProject ? (
          <Card className="glass p-12 text-center">
            <Target className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
            <p className="text-sm text-muted-foreground">Selectionnez un projet en prospection pour mettre a jour son etat</p>
          </Card>
        ) : (
          <div className="space-y-5">
            {success && (
              <Card className="glass p-3 border-emerald-500/30 bg-emerald-500/5">
                <div className="flex items-center gap-2 text-emerald-500">
                  <CheckCircle2 className="w-4 h-4" />
                  <span className="text-sm font-medium">{success}</span>
                </div>
              </Card>
            )}

            {/* Project header */}
            <Card className="glass p-4" style={{ borderLeft: `3px solid ${PILLAR_COLORS[selectedProject.pillar]}` }}>
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold" style={{ fontFamily: "'Poppins', sans-serif" }}>{selectedProject.projectName}</h3>
                  <p className="text-xs text-muted-foreground">{selectedProject.partner.acronym || selectedProject.partner.name} | {formatCurrency(selectedProject.totalAmount)}</p>
                </div>
                <div className="text-right">
                  <Badge style={{ backgroundColor: STATUS_COLORS[selectedProject.status], color: "#fff" }}>{selectedProject.status}</Badge>
                </div>
              </div>
            </Card>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {/* Pipeline advancement */}
              <Card className="glass p-5">
                <h4 className="text-sm font-semibold mb-4" style={{ fontFamily: "'Poppins', sans-serif" }}>
                  <ArrowRight className="w-4 h-4 inline mr-1" /> Avancer dans le Pipeline
                </h4>
                <div className="space-y-2 mb-4">
                  {PIPELINE_STAGES.map((stage, i) => {
                    const isCurrent = newStatus === stage.key;
                    const isPast = PIPELINE_STAGES.findIndex(s => s.key === newStatus) > i;
                    return (
                      <button
                        key={stage.key}
                        onClick={() => setNewStatus(stage.key)}
                        className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-xs transition-all ${isCurrent ? "glass glow-cyan font-semibold" : isPast ? "text-muted-foreground" : "hover:bg-accent/50"}`}
                      >
                        <div className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold ${isCurrent ? "bg-primary text-primary-foreground" : isPast ? "bg-emerald-500/20 text-emerald-500" : "bg-muted text-muted-foreground"}`}>
                          {isPast ? "✓" : i + 1}
                        </div>
                        <span>{stage.label}</span>
                        {isCurrent && <Badge variant="default" className="ml-auto text-[9px]">Actuel</Badge>}
                      </button>
                    );
                  })}
                  <button
                    onClick={() => setNewStatus("ACTIF")}
                    className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-xs transition-all ${newStatus === "ACTIF" ? "glass glow-emerald font-semibold" : "hover:bg-accent/50"}`}
                  >
                    <div className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold ${newStatus === "ACTIF" ? "bg-emerald-500 text-white" : "bg-muted text-muted-foreground"}`}>✓</div>
                    <span>Actif (signe)</span>
                  </button>
                </div>
                <Button onClick={submitUpdate} disabled={saving || newStatus === selectedProject.status} className="w-full" variant={newStatus !== selectedProject.status ? "default" : "outline"}>
                  <Send className="w-4 h-4 mr-2" />
                  {newStatus !== selectedProject.status ? "Appliquer le changement" : "Aucun changement"}
                </Button>
              </Card>

              {/* Maturation */}
              <Card className="glass p-5">
                <h4 className="text-sm font-semibold mb-3" style={{ fontFamily: "'Poppins', sans-serif" }}>Score de Maturation</h4>
                <div className="flex items-center gap-3 mb-4">
                  <div className="relative w-16 h-16">
                    <svg viewBox="0 0 36 36" className="w-full h-full -rotate-90">
                      <path d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" fill="none" stroke="currentColor" className="text-muted" strokeWidth="3" />
                      <path d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" fill="none" stroke={getScoreColor(maturationScore)} strokeWidth="3" strokeDasharray={`${maturationScore}, 100`} strokeLinecap="round" />
                    </svg>
                    <span className="absolute inset-0 flex items-center justify-center text-sm font-bold">{maturationScore}</span>
                  </div>
                  <Progress value={maturationScore} className="flex-1 h-2" />
                </div>
                <div className="space-y-2.5">
                  {[
                    { key: "hasFeasibilityStudy" as const, label: "Faisabilite", pts: 20 },
                    { key: "hasImpactAssessment" as const, label: "Impact E&S", pts: 15 },
                    { key: "hasFinancialStructure" as const, label: "Structure fin.", pts: 25 },
                    { key: "hasIntentionLetter" as const, label: "Lettre intention", pts: 15 },
                    { key: "hasLegalValidation" as const, label: "Valid. juridique", pts: 15 },
                    { key: "hasPillarConformity" as const, label: "Conformite piliers", pts: 10 },
                  ].map(item => (
                    <div key={item.key} className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Switch
                          checked={maturation[item.key]}
                          onCheckedChange={v => setMaturation(m => ({ ...m, [item.key]: v }))}
                        />
                        <span className="text-[11px]">{item.label}</span>
                      </div>
                      <Badge variant="secondary" className="text-[9px]">{item.pts}pts</Badge>
                    </div>
                  ))}
                </div>
                <Button onClick={submitUpdate} disabled={saving} variant="outline" size="sm" className="w-full mt-4">
                  Sauvegarder la maturation
                </Button>
              </Card>
            </div>

            {/* Notes de prospection */}
            <Card className="glass p-5">
              <h4 className="text-sm font-semibold mb-4" style={{ fontFamily: "'Poppins', sans-serif" }}>
                <MessageSquare className="w-4 h-4 inline mr-1" /> Ajouter une Note de Prospection
              </h4>

              <div className="grid grid-cols-3 gap-3 mb-4">
                <div>
                  <Label>Type</Label>
                  <Select value={noteForm.type} onValueChange={v => setNoteForm(f => ({ ...f, type: v || "REUNION" }))}>
                    <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="REUNION">Reunion</SelectItem>
                      <SelectItem value="APPEL">Appel</SelectItem>
                      <SelectItem value="EMAIL">Email</SelectItem>
                      <SelectItem value="COMMENTAIRE">Commentaire</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Date</Label>
                  <Input type="date" value={noteForm.date} onChange={e => setNoteForm(f => ({ ...f, date: e.target.value }))} className="mt-1" />
                </div>
                <div className="flex items-end">
                  <Button onClick={submitNote} disabled={saving || !noteForm.content} className="w-full">
                    <Send className="w-4 h-4 mr-2" />Ajouter
                  </Button>
                </div>
              </div>
              <div>
                <Label>Contenu de la note *</Label>
                <Textarea
                  value={noteForm.content}
                  onChange={e => setNoteForm(f => ({ ...f, content: e.target.value }))}
                  placeholder="Compte-rendu de la reunion, retour d'appel, echange email..."
                  rows={3}
                  className="mt-1"
                />
              </div>

              {/* Existing notes */}
              {selectedProject.prospectionNotes && selectedProject.prospectionNotes.length > 0 && (
                <div className="mt-5 border-t border-border pt-4">
                  <p className="text-[10px] text-muted-foreground uppercase tracking-wider mb-3">Historique ({selectedProject.prospectionNotes.length} notes)</p>
                  <div className="space-y-2 max-h-[300px] overflow-y-auto">
                    {selectedProject.prospectionNotes.map(note => (
                      <div key={note.id} className="glass p-3 rounded-lg">
                        <div className="flex items-center gap-2 mb-1">
                          {noteIcons[note.type]}
                          <Badge variant="outline" className="text-[9px]">{note.type}</Badge>
                          <span className="text-[10px] text-muted-foreground">{new Date(note.date).toLocaleDateString("fr-FR")}</span>
                          {note.author && <span className="text-[10px] text-muted-foreground ml-auto">{note.author.name}</span>}
                        </div>
                        <p className="text-xs">{note.content}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}
