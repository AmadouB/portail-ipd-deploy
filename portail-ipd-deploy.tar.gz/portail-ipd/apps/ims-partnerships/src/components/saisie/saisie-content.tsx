"use client";

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { PlusCircle, TrendingUp, Target, Gauge } from "lucide-react";
import { NouveauProjetForm } from "./nouveau-projet-form";
import { AvancementForm } from "./avancement-form";
import { ProspectionForm } from "./prospection-form";
import { IndicateursSaisieForm } from "./indicateurs-saisie-form";

export function SaisieContent() {
  return (
    <Tabs defaultValue="nouveau" className="space-y-5">
      <TabsList className="glass h-auto p-1 flex flex-wrap gap-1">
        <TabsTrigger value="nouveau" className="gap-2 data-[state=active]:glow-cyan">
          <PlusCircle className="w-4 h-4" />
          Nouveau Projet
        </TabsTrigger>
        <TabsTrigger value="avancement" className="gap-2 data-[state=active]:glow-emerald">
          <TrendingUp className="w-4 h-4" />
          Avancement Projets Actifs
        </TabsTrigger>
        <TabsTrigger value="prospection" className="gap-2 data-[state=active]:glow-purple">
          <Target className="w-4 h-4" />
          Suivi Prospection
        </TabsTrigger>
        <TabsTrigger value="indicateurs" className="gap-2 data-[state=active]:glow-amber">
          <Gauge className="w-4 h-4" />
          Indicateurs par Projet
        </TabsTrigger>
      </TabsList>

      <TabsContent value="nouveau">
        <NouveauProjetForm />
      </TabsContent>

      <TabsContent value="avancement">
        <AvancementForm />
      </TabsContent>

      <TabsContent value="prospection">
        <ProspectionForm />
      </TabsContent>

      <TabsContent value="indicateurs">
        <IndicateursSaisieForm />
      </TabsContent>
    </Tabs>
  );
}
