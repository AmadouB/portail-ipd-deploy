"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Progress } from "@/components/ui/progress";
import { PILLAR_LABELS, DEPARTMENT_LIST, PILLAR_COLORS } from "@/lib/utils";
import { SENEGAL_REGIONS } from "@/lib/regions";
import { Save, CheckCircle2, AlertCircle, Building2, MapPin, Gauge } from "lucide-react";

interface Partner {
  id: string;
  name: string;
  acronym: string | null;
  type: string;
  tier: string;
}

interface Indicator {
  id: string;
  code: string;
  category: string;
  pillar: string | null;
  name: string;
  target2025: string | null;
  target2027: string | null;
  unit: string | null;
}

const CONTRACT_TYPES = [
  "Grant Agreement", "MOU", "Cooperative Agreement", "Sub-grant",
  "Supply Agreement", "Convention", "Fellowship Grant", "Collaboration Agreement",
  "Accord-cadre", "Loan/Grant", "Contrat de service",
];

const STATUS_OPTIONS = [
  { value: "IDENTIFICATION", label: "Identification" },
  { value: "CONTACT", label: "Prise de contact" },
  { value: "DISCUSSION", label: "En discussion" },
  { value: "ACCORD", label: "Accord de principe" },
  { value: "NEGOCIATION", label: "Negociation contractuelle" },
  { value: "SIGNATURE", label: "Signature" },
  { value: "ACTIF", label: "Actif" },
];

export function NouveauProjetForm() {
  const router = useRouter();
  const [partners, setPartners] = useState<Partner[]>([]);
  const [allIndicators, setAllIndicators] = useState<Indicator[]>([]);
  const [selectedRegions, setSelectedRegions] = useState<string[]>([]);
  const [indicatorTargets, setIndicatorTargets] = useState<Record<string, string>>({}); // indicatorId -> target value
  const [saving, setSaving] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState("");

  // Form state
  const [form, setForm] = useState({
    partnerId: "",
    streamId: "",
    projectName: "",
    pillar: "",
    subPillar: "",
    contractType: "",
    totalAmount: "",
    annualAmount: "",
    departmentLead: "",
    divisionLead: "",
    status: "IDENTIFICATION",
    signatureYear: "",
    duration: "",
    startDate: "",
    endDate: "",
    grantType: "",
    budgetCode: "",
    objectives: "",
    deliverables: "",
    // Maturation criteria
    hasFeasibilityStudy: false,
    hasImpactAssessment: false,
    hasFinancialStructure: false,
    hasIntentionLetter: false,
    hasLegalValidation: false,
    hasPillarConformity: false,
    // Contacts
    partnershipLead: "",
    financeManager: "",
    grantManager: "",
    partnerRepresentative: "",
    partnerRepContact: "",
    // Risks
    riskDescription: "",
    riskMitigation: "",
    riskCriticality: "MEDIUM",
  });

  useEffect(() => {
    Promise.all([
      fetch("/api/partners").then(r => r.json()),
      fetch("/api/indicators").then(r => r.json()),
    ]).then(([p, i]) => { setPartners(p); setAllIndicators(i); });
  }, []);

  // Indicators relevant to the selected pillar
  const relevantIndicators = allIndicators.filter(ind =>
    ind.category !== "OPERATIONAL" && (ind.pillar === form.pillar || ind.pillar === "TRANSVERSAL")
  );

  const toggleRegion = (code: string) => {
    setSelectedRegions(prev => prev.includes(code) ? prev.filter(r => r !== code) : [...prev, code]);
  };

  const maturationScore =
    (form.hasFeasibilityStudy ? 20 : 0) +
    (form.hasImpactAssessment ? 15 : 0) +
    (form.hasFinancialStructure ? 25 : 0) +
    (form.hasIntentionLetter ? 15 : 0) +
    (form.hasLegalValidation ? 15 : 0) +
    (form.hasPillarConformity ? 10 : 0);

  const update = (field: string, value: any) => {
    setForm(prev => ({ ...prev, [field]: value }));
    setError("");
    setSuccess(false);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.partnerId || !form.projectName || !form.pillar) {
      setError("Partenaire, nom du projet et pilier sont obligatoires.");
      return;
    }

    setSaving(true);
    setError("");
    try {
      // Create project
      const res = await fetch("/api/projects", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          partnerId: form.partnerId,
          streamId: form.streamId || null,
          projectName: form.projectName,
          pillar: form.pillar,
          subPillar: form.subPillar || null,
          contractType: form.contractType || null,
          totalAmount: parseFloat(form.totalAmount) * 1_000_000 || 0,
          annualAmount: parseFloat(form.annualAmount) * 1_000_000 || 0,
          departmentLead: form.departmentLead || null,
          divisionLead: form.divisionLead || null,
          status: form.status,
          maturationScore,
          signatureYear: parseInt(form.signatureYear) || null,
          duration: form.duration || null,
          startDate: form.startDate ? new Date(form.startDate).toISOString() : null,
          endDate: form.endDate ? new Date(form.endDate).toISOString() : null,
          grantType: form.grantType || null,
          budgetCode: form.budgetCode || null,
          objectives: form.objectives || null,
          deliverables: form.deliverables || null,
          hasFeasibilityStudy: form.hasFeasibilityStudy,
          hasImpactAssessment: form.hasImpactAssessment,
          hasFinancialStructure: form.hasFinancialStructure,
          hasIntentionLetter: form.hasIntentionLetter,
          hasLegalValidation: form.hasLegalValidation,
          hasPillarConformity: form.hasPillarConformity,
          regions: selectedRegions.length > 0 ? selectedRegions.join(",") : "DAKAR",
          latitude: (() => { const r = SENEGAL_REGIONS.find(rg => rg.code === (selectedRegions[0] || "DAKAR")); return (r?.lat || 14.69) + (Math.random() - 0.5) * 0.2; })(),
          longitude: (() => { const r = SENEGAL_REGIONS.find(rg => rg.code === (selectedRegions[0] || "DAKAR")); return (r?.lng || -17.44) + (Math.random() - 0.5) * 0.2; })(),
        }),
      });

      if (!res.ok) throw new Error("Erreur lors de la creation");
      const project = await res.json();

      // Create contacts
      const contacts = [
        { role: "RESPONSABLE_IPD", name: form.partnershipLead },
        { role: "DIRECTEUR_FINANCIER", name: form.financeManager },
        { role: "GESTIONNAIRE_SUBVENTION", name: form.grantManager },
        { role: "REPRESENTANT_PARTENAIRE", name: form.partnerRepresentative, email: form.partnerRepContact },
      ].filter(c => c.name);

      for (const c of contacts) {
        await fetch(`/api/projects/${project.id}/contacts`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(c),
        }).catch(() => {});
      }

      // Create risk if provided
      if (form.riskDescription) {
        await fetch(`/api/projects/${project.id}/risks`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            description: form.riskDescription,
            mitigationActions: form.riskMitigation || null,
            criticality: form.riskCriticality,
          }),
        }).catch(() => {});
      }

      // Create indicator targets
      for (const [indId, targetVal] of Object.entries(indicatorTargets)) {
        if (targetVal) {
          await fetch(`/api/indicators/${indId}/values`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ projectId: project.id, period: "2025", targetValue: targetVal, status: "PENDING" }),
          }).catch(() => {});
        }
      }

      setSuccess(true);
      setTimeout(() => router.push(`/projets/${project.id}`), 1500);
    } catch (e: any) {
      setError(e.message || "Erreur lors de la creation du projet");
    } finally {
      setSaving(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Status messages */}
      {success && (
        <Card className="glass p-4 border-emerald-500/30 bg-emerald-500/5">
          <div className="flex items-center gap-2 text-emerald-500">
            <CheckCircle2 className="w-5 h-5" />
            <span className="text-sm font-medium">Projet cree avec succes ! Redirection...</span>
          </div>
        </Card>
      )}
      {error && (
        <Card className="glass p-4 border-red-500/30 bg-red-500/5">
          <div className="flex items-center gap-2 text-red-500">
            <AlertCircle className="w-5 h-5" />
            <span className="text-sm">{error}</span>
          </div>
        </Card>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Col 1: Infos cles */}
        <div className="lg:col-span-2 space-y-6">
          <Card className="glass p-5">
            <h3 className="text-sm font-semibold mb-4" style={{ fontFamily: "'Poppins', sans-serif" }}>
              Informations Cles
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="md:col-span-2">
                <Label>Nom du projet *</Label>
                <Input value={form.projectName} onChange={e => update("projectName", e.target.value)} placeholder="Ex: Genomic Surveillance Network" className="mt-1" />
              </div>
              <div>
                <Label>Partenaire *</Label>
                <Select value={form.partnerId} onValueChange={v => update("partnerId", v || "")}>
                  <SelectTrigger className="mt-1"><SelectValue placeholder="Selectionner..." /></SelectTrigger>
                  <SelectContent>
                    {partners.map(p => (
                      <SelectItem key={p.id} value={p.id}>{p.acronym ? `${p.acronym} — ` : ""}{p.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Identifiant flux</Label>
                <Input value={form.streamId} onChange={e => update("streamId", e.target.value)} placeholder="Ex: BMGF-R01" className="mt-1" />
              </div>
              <div>
                <Label>Pilier strategique *</Label>
                <Select value={form.pillar} onValueChange={v => update("pillar", v || "")}>
                  <SelectTrigger className="mt-1"><SelectValue placeholder="Selectionner..." /></SelectTrigger>
                  <SelectContent>
                    {Object.entries(PILLAR_LABELS).map(([k, v]) => (
                      <SelectItem key={k} value={k}>{v}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Sous-pilier</Label>
                <Input value={form.subPillar} onChange={e => update("subPillar", e.target.value)} placeholder="Ex: Genomique, Biomanufacturing..." className="mt-1" />
              </div>
              <div>
                <Label>Type de contrat</Label>
                <Select value={form.contractType} onValueChange={v => update("contractType", v || "")}>
                  <SelectTrigger className="mt-1"><SelectValue placeholder="Type..." /></SelectTrigger>
                  <SelectContent>
                    {CONTRACT_TYPES.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Statut</Label>
                <Select value={form.status} onValueChange={v => update("status", v || "IDENTIFICATION")}>
                  <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {STATUS_OPTIONS.map(s => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Montant total (M$)</Label>
                <Input type="number" step="0.1" value={form.totalAmount} onChange={e => update("totalAmount", e.target.value)} placeholder="Ex: 8.5" className="mt-1" />
              </div>
              <div>
                <Label>Montant annuel (M$)</Label>
                <Input type="number" step="0.1" value={form.annualAmount} onChange={e => update("annualAmount", e.target.value)} placeholder="Ex: 1.7" className="mt-1" />
              </div>
              <div>
                <Label>Departement lead</Label>
                <Select value={form.departmentLead} onValueChange={v => update("departmentLead", v || "")}>
                  <SelectTrigger className="mt-1"><SelectValue placeholder="Departement..." /></SelectTrigger>
                  <SelectContent>
                    {DEPARTMENT_LIST.map(d => <SelectItem key={d} value={d}>{d}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Division lead</Label>
                <Input value={form.divisionLead} onChange={e => update("divisionLead", e.target.value)} className="mt-1" />
              </div>
            </div>
          </Card>

          {/* Duration & Finance */}
          <Card className="glass p-5">
            <h3 className="text-sm font-semibold mb-4" style={{ fontFamily: "'Poppins', sans-serif" }}>Duree et Finances</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div>
                <Label>Annee signature</Label>
                <Input type="number" value={form.signatureYear} onChange={e => update("signatureYear", e.target.value)} placeholder="2026" className="mt-1" />
              </div>
              <div>
                <Label>Duree</Label>
                <Input value={form.duration} onChange={e => update("duration", e.target.value)} placeholder="3 ans" className="mt-1" />
              </div>
              <div>
                <Label>Date debut</Label>
                <Input type="date" value={form.startDate} onChange={e => update("startDate", e.target.value)} className="mt-1" />
              </div>
              <div>
                <Label>Date fin</Label>
                <Input type="date" value={form.endDate} onChange={e => update("endDate", e.target.value)} className="mt-1" />
              </div>
              <div>
                <Label>Type subvention</Label>
                <Input value={form.grantType} onChange={e => update("grantType", e.target.value)} className="mt-1" />
              </div>
              <div>
                <Label>Code budgetaire</Label>
                <Input value={form.budgetCode} onChange={e => update("budgetCode", e.target.value)} className="mt-1" />
              </div>
            </div>
          </Card>

          {/* Objectives */}
          <Card className="glass p-5">
            <h3 className="text-sm font-semibold mb-4" style={{ fontFamily: "'Poppins', sans-serif" }}>Objectifs et Livrables</h3>
            <div className="space-y-4">
              <div>
                <Label>Objectifs cles</Label>
                <Textarea value={form.objectives} onChange={e => update("objectives", e.target.value)} placeholder="Decrire les objectifs principaux du projet..." rows={3} className="mt-1" />
              </div>
              <div>
                <Label>Livrables attendus</Label>
                <Textarea value={form.deliverables} onChange={e => update("deliverables", e.target.value)} placeholder="Liste des livrables avec echeances..." rows={3} className="mt-1" />
              </div>
            </div>
          </Card>

          {/* Contacts */}
          <Card className="glass p-5">
            <h3 className="text-sm font-semibold mb-4" style={{ fontFamily: "'Poppins', sans-serif" }}>Contacts Cles</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label>Responsable partenariat IPD</Label>
                <Input value={form.partnershipLead} onChange={e => update("partnershipLead", e.target.value)} placeholder="Nom complet" className="mt-1" />
              </div>
              <div>
                <Label>Directeur financier</Label>
                <Input value={form.financeManager} onChange={e => update("financeManager", e.target.value)} placeholder="Nom complet" className="mt-1" />
              </div>
              <div>
                <Label>Gestionnaire subvention</Label>
                <Input value={form.grantManager} onChange={e => update("grantManager", e.target.value)} placeholder="Nom complet" className="mt-1" />
              </div>
              <div>
                <Label>Representant partenaire</Label>
                <Input value={form.partnerRepresentative} onChange={e => update("partnerRepresentative", e.target.value)} placeholder="Nom complet" className="mt-1" />
              </div>
              <div className="md:col-span-2">
                <Label>Contact representant (email)</Label>
                <Input value={form.partnerRepContact} onChange={e => update("partnerRepContact", e.target.value)} placeholder="email@partenaire.org" className="mt-1" />
              </div>
            </div>
          </Card>

          {/* Zones d'intervention */}
          <Card className="glass p-5">
            <h3 className="text-sm font-semibold mb-2" style={{ fontFamily: "'Poppins', sans-serif" }}>
              <MapPin className="w-4 h-4 inline mr-1 text-emerald-500" /> Zones d'Intervention
            </h3>
            <p className="text-[10px] text-muted-foreground mb-3">Selectionnez les regions du Senegal couvertes par ce projet</p>
            <div className="grid grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-2">
              {SENEGAL_REGIONS.map(region => {
                const isSelected = selectedRegions.includes(region.code);
                return (
                  <button
                    key={region.code}
                    type="button"
                    onClick={() => toggleRegion(region.code)}
                    className={`px-2.5 py-2 rounded-lg text-xs transition-all text-left ${isSelected ? "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 ring-1 ring-emerald-500/30 font-semibold" : "glass hover:bg-accent/50"}`}
                  >
                    <div className="flex items-center gap-1.5">
                      <div className={`w-2.5 h-2.5 rounded-full flex-shrink-0 ${isSelected ? "bg-emerald-500" : "bg-muted-foreground/30"}`} />
                      {region.name}
                    </div>
                  </button>
                );
              })}
            </div>
            {selectedRegions.length > 0 && (
              <p className="text-[10px] text-emerald-500 mt-2 font-medium">{selectedRegions.length} region{selectedRegions.length > 1 ? "s" : ""} selectionnee{selectedRegions.length > 1 ? "s" : ""}</p>
            )}
          </Card>

          {/* Indicateurs cibles */}
          {form.pillar && relevantIndicators.length > 0 && (
            <Card className="glass p-5">
              <h3 className="text-sm font-semibold mb-2" style={{ fontFamily: "'Poppins', sans-serif" }}>
                <Gauge className="w-4 h-4 inline mr-1 text-[#0089D0]" /> Indicateurs Strategiques
              </h3>
              <p className="text-[10px] text-muted-foreground mb-3">
                Definissez les cibles pour les indicateurs lies au pilier <strong>{PILLAR_LABELS[form.pillar]}</strong>
              </p>
              <div className="space-y-2 max-h-[350px] overflow-y-auto pr-1">
                {relevantIndicators.map(ind => (
                  <div key={ind.id} className="glass p-3 rounded-lg">
                    <div className="flex items-start gap-2 mb-2">
                      <Badge variant="outline" className="text-[9px] flex-shrink-0 mt-0.5">{ind.code}</Badge>
                      <div className="flex-1 min-w-0">
                        <p className="text-[11px] font-medium leading-tight">{ind.name}</p>
                        <div className="flex gap-3 mt-1 text-[9px] text-muted-foreground">
                          {ind.target2025 && <span>2025: <strong>{ind.target2025}</strong></span>}
                          {ind.target2027 && <span>2027: <strong className="text-[#0089D0]">{ind.target2027}</strong></span>}
                          {ind.unit && <span className="ml-auto">{ind.unit}</span>}
                        </div>
                      </div>
                    </div>
                    <Input
                      value={indicatorTargets[ind.id] || ""}
                      onChange={e => setIndicatorTargets(prev => ({ ...prev, [ind.id]: e.target.value }))}
                      placeholder={`Cible pour ce projet ${ind.unit ? `(${ind.unit})` : ""}`}
                      className="h-7 text-xs"
                    />
                  </div>
                ))}
              </div>
            </Card>
          )}

          {/* Risks */}
          <Card className="glass p-5">
            <h3 className="text-sm font-semibold mb-4" style={{ fontFamily: "'Poppins', sans-serif" }}>Risques Identifies</h3>
            <div className="space-y-4">
              <div>
                <Label>Description du risque</Label>
                <Textarea value={form.riskDescription} onChange={e => update("riskDescription", e.target.value)} placeholder="Decrire le risque principal..." rows={2} className="mt-1" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Actions d'attenuation</Label>
                  <Textarea value={form.riskMitigation} onChange={e => update("riskMitigation", e.target.value)} placeholder="Mesures de mitigation..." rows={2} className="mt-1" />
                </div>
                <div>
                  <Label>Niveau de criticite</Label>
                  <Select value={form.riskCriticality} onValueChange={v => update("riskCriticality", v || "MEDIUM")}>
                    <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="LOW">Faible</SelectItem>
                      <SelectItem value="MEDIUM">Moyen</SelectItem>
                      <SelectItem value="HIGH">Eleve</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
          </Card>
        </div>

        {/* Col 2: Maturation + Actions */}
        <div className="space-y-6">
          {/* Maturation Score */}
          <Card className="glass p-5 sticky top-6">
            <h3 className="text-sm font-semibold mb-4" style={{ fontFamily: "'Poppins', sans-serif" }}>Score de Maturation</h3>
            <div className="flex items-center gap-3 mb-4">
              <div className="relative w-20 h-20">
                <svg viewBox="0 0 36 36" className="w-full h-full -rotate-90">
                  <path d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" fill="none" stroke="currentColor" className="text-muted" strokeWidth="3" />
                  <path d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" fill="none" stroke={maturationScore >= 75 ? "#10b981" : maturationScore >= 40 ? "#EF7A16" : "#ef4444"} strokeWidth="3" strokeDasharray={`${maturationScore}, 100`} strokeLinecap="round" />
                </svg>
                <span className="absolute inset-0 flex items-center justify-center text-lg font-bold" style={{ fontFamily: "'Poppins', sans-serif" }}>
                  {maturationScore}
                </span>
              </div>
              <div className="flex-1">
                <p className="text-xs text-muted-foreground">
                  {maturationScore >= 75 ? "Projet mature" : maturationScore >= 40 ? "En cours de maturation" : "Maturation initiale"}
                </p>
                <Progress value={maturationScore} className="h-2 mt-1" />
              </div>
            </div>

            <div className="space-y-3">
              {[
                { key: "hasFeasibilityStudy", label: "Etude de faisabilite", pts: 20 },
                { key: "hasImpactAssessment", label: "Evaluation d'impact E&S", pts: 15 },
                { key: "hasFinancialStructure", label: "Structure financiere validee", pts: 25 },
                { key: "hasIntentionLetter", label: "Lettre d'intention signee", pts: 15 },
                { key: "hasLegalValidation", label: "Validation juridique", pts: 15 },
                { key: "hasPillarConformity", label: "Conformite piliers IPD", pts: 10 },
              ].map(item => (
                <div key={item.key} className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Switch
                      checked={(form as any)[item.key]}
                      onCheckedChange={v => update(item.key, v)}
                    />
                    <span className="text-xs">{item.label}</span>
                  </div>
                  <Badge variant="secondary" className="text-[10px]">{item.pts} pts</Badge>
                </div>
              ))}
            </div>
          </Card>

          {/* Pillar preview */}
          {form.pillar && (
            <Card className="glass p-4" style={{ borderLeft: `3px solid ${PILLAR_COLORS[form.pillar]}` }}>
              <p className="text-xs text-muted-foreground">Pilier selectionne</p>
              <p className="text-sm font-semibold" style={{ color: PILLAR_COLORS[form.pillar] }}>
                {PILLAR_LABELS[form.pillar]}
              </p>
            </Card>
          )}

          {/* Submit */}
          <Button type="submit" className="w-full h-12 text-sm font-semibold" disabled={saving}>
            <Save className="w-4 h-4 mr-2" />
            {saving ? "Enregistrement..." : "Creer le projet"}
          </Button>
        </div>
      </div>
    </form>
  );
}
