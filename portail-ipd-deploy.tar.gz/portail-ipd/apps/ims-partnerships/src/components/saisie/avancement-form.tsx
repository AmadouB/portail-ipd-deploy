"use client";

import { useEffect, useState, useMemo } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { formatCurrency, formatDate, PILLAR_COLORS, PILLAR_LABELS, DEPARTMENT_LIST } from "@/lib/utils";
import { SENEGAL_REGIONS, REGION_LABELS } from "@/lib/regions";
import {
  Search, CheckCircle2, TrendingUp, Calendar, Send, Building2, ChevronRight,
  MapPin, Gauge, FileSignature, Hourglass, Save, AlertTriangle,
} from "lucide-react";

interface Project {
  id: string;
  projectName: string;
  pillar: string;
  status: string;
  totalAmount: number;
  departmentLead: string | null;
  divisionLead: string | null;
  contractType: string | null;
  regions: string | null;
  startDate: string | null;
  endDate: string | null;
  partner: { name: string; acronym: string | null; tier: string };
  monitoringEntries: Array<{ period: string; physicalRate: number; financialRate: number; validationStatus: string }>;
  milestones: Array<{ id: string; title: string; status: string; dueDate: string }>;
}

interface Indicator {
  id: string;
  code: string;
  category: string;
  pillar: string | null;
  department: string | null;
  name: string;
  unit: string | null;
  baseline: string | null;
  target2025: string | null;
  target2027: string | null;
  frequency: string | null;
  values: Array<{ id: string; period: string; targetValue: string | null; actualValue: string | null; status: string; projectId: string | null }>;
}

const STATUS_IND: Record<string, { label: string; color: string }> = {
  PENDING: { label: "En attente", color: "#6b7280" },
  ON_TRACK: { label: "En bonne voie", color: "#10b981" },
  AT_RISK: { label: "A risque", color: "#EF7A16" },
  OFF_TRACK: { label: "Hors piste", color: "#ef4444" },
  ACHIEVED: { label: "Atteint", color: "#0089D0" },
};

const CATEGORY_COLORS: Record<string, string> = { EFFECT: "#0089D0", IMPACT: "#10b981", OPERATIONAL: "#EF7A16" };
const CATEGORY_LABELS: Record<string, string> = { EFFECT: "Effet", IMPACT: "Impact", OPERATIONAL: "Operationnel" };

const PERIODS = ["2025-Q1", "2025-Q2", "2025-Q3", "2025-Q4", "2025", "2026-Q1", "2026-Q2", "2026-Q3", "2026-Q4", "2026", "2027"];

export function AvancementForm() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [allIndicators, setAllIndicators] = useState<Indicator[]>([]);
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [saving, setSaving] = useState(false);
  const [success, setSuccess] = useState("");
  const [activeTab, setActiveTab] = useState<"suivi" | "indicateurs" | "regions">("indicateurs");

  // Project filters
  const [search, setSearch] = useState("");
  const [filterDept, setFilterDept] = useState("ALL");
  const [filterPillar, setFilterPillar] = useState("ALL");
  const [filterRegion, setFilterRegion] = useState("ALL");

  // Indicator saisie period
  const [saisePeriod, setSaisePeriod] = useState("2025-Q2");

  // Bulk indicator values: { [indicatorId]: { actualValue, status, comments } }
  const [bulkValues, setBulkValues] = useState<Record<string, { actualValue: string; status: string; comments: string }>>({});

  // Regions edit
  const [editRegions, setEditRegions] = useState<string[]>([]);

  // Monitoring form
  const [monForm, setMonForm] = useState({ period: "", periodType: "QUARTERLY", physicalRate: "", financialRate: "", physicalTarget: "", financialTarget: "", observations: "" });

  useEffect(() => {
    Promise.all([
      fetch("/api/projects").then(r => r.json()),
      fetch("/api/indicators").then(r => r.json()),
    ]).then(([pData, iData]) => {
      setProjects(pData.filter((p: Project) => p.status === "ACTIF"));
      setAllIndicators(iData);
    });
  }, []);

  // Filtered project list
  const filteredProjects = useMemo(() => {
    return projects.filter(p => {
      if (search) {
        const s = search.toLowerCase();
        if (!p.projectName.toLowerCase().includes(s) && !(p.partner.acronym || p.partner.name).toLowerCase().includes(s)) return false;
      }
      if (filterDept !== "ALL" && p.departmentLead !== filterDept) return false;
      if (filterPillar !== "ALL" && p.pillar !== filterPillar) return false;
      if (filterRegion !== "ALL" && !(p.regions || "").split(",").includes(filterRegion)) return false;
      return true;
    });
  }, [projects, search, filterDept, filterPillar, filterRegion]);

  // Indicators relevant to selected project
  const relevantIndicators = useMemo(() => {
    if (!selectedProject) return [];
    return allIndicators.filter(ind => {
      // Strategic: match pillar or transversal
      if (ind.category !== "OPERATIONAL") {
        return ind.pillar === selectedProject.pillar || ind.pillar === "TRANSVERSAL";
      }
      // Operational: match department
      if (ind.department) {
        const deptMap: Record<string, string[]> = {
          DOI: ["DOI", "Diatropix"], DREI: ["DREI"], DSP: ["DSP"], CARE: ["DCH", "CARE"],
          DPC: ["DPC", "UVFJ"], DFC: ["DFC", "CAS"], DDSI: ["DDSI"],
        };
        for (const [dept, matches] of Object.entries(deptMap)) {
          if (ind.department === dept && matches.includes(selectedProject.departmentLead || "")) return true;
        }
      }
      return false;
    });
  }, [allIndicators, selectedProject]);

  const selectProject = (project: Project) => {
    setSelectedProject(project);
    setSuccess("");
    setEditRegions(project.regions ? project.regions.split(",") : []);
    setBulkValues({});
    const now = new Date();
    const quarter = Math.ceil((now.getMonth() + 1) / 3);
    setMonForm({ period: `${now.getFullYear()}-Q${quarter}`, periodType: "QUARTERLY", physicalRate: "", financialRate: "", physicalTarget: "", financialTarget: "", observations: "" });
  };

  // ── Submit functions ──

  const submitMonitoring = async () => {
    if (!selectedProject || !monForm.period) return;
    setSaving(true);
    try {
      await fetch(`/api/projects/${selectedProject.id}/monitoring`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ period: monForm.period, periodType: monForm.periodType, physicalRate: parseFloat(monForm.physicalRate) || 0, financialRate: parseFloat(monForm.financialRate) || 0, physicalTarget: parseFloat(monForm.physicalTarget) || 0, financialTarget: parseFloat(monForm.financialTarget) || 0, observations: monForm.observations || null }),
      });
      setSuccess("Fiche de suivi enregistree !");
    } catch {} finally { setSaving(false); }
  };

  const submitBulkIndicators = async () => {
    if (!selectedProject) return;
    const entries = Object.entries(bulkValues).filter(([, v]) => v.actualValue || v.comments);
    if (entries.length === 0) return;
    setSaving(true);
    try {
      for (const [indId, val] of entries) {
        await fetch(`/api/indicators/${indId}/values`, {
          method: "POST", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ projectId: selectedProject.id, period: saisePeriod, targetValue: null, actualValue: val.actualValue || null, status: val.status, comments: val.comments || null }),
        });
      }
      setSuccess(`${entries.length} indicateur(s) enregistre(s) pour ${saisePeriod} !`);
      setBulkValues({});
      const updated = await fetch("/api/indicators").then(r => r.json());
      setAllIndicators(updated);
    } catch {} finally { setSaving(false); }
  };

  const saveRegions = async () => {
    if (!selectedProject) return;
    setSaving(true);
    try {
      const primary = SENEGAL_REGIONS.find(r => r.code === (editRegions[0] || "DAKAR"));
      await fetch(`/api/projects/${selectedProject.id}`, {
        method: "PUT", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ regions: editRegions.join(","), latitude: (primary?.lat || 14.69) + (Math.random() - 0.5) * 0.2, longitude: (primary?.lng || -17.44) + (Math.random() - 0.5) * 0.2 }),
      });
      setSuccess("Zones d'intervention mises a jour !");
    } catch {} finally { setSaving(false); }
  };

  const departments = [...new Set(projects.map(p => p.departmentLead).filter(Boolean))];
  const lastEntry = selectedProject?.monitoringEntries?.[0];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
      {/* ── LEFT: Project selector with filters ── */}
      <div className="space-y-3">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input placeholder="Rechercher projet ou partenaire..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9 glass" />
        </div>
        <div className="flex flex-wrap gap-2">
          <Select value={filterPillar} onValueChange={v => setFilterPillar(v || "ALL")}>
            <SelectTrigger className="flex-1 min-w-[100px] glass h-8 text-xs"><SelectValue placeholder="Pilier" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="ALL">Tous piliers</SelectItem>
              {Object.entries(PILLAR_LABELS).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}
            </SelectContent>
          </Select>
          <Select value={filterDept} onValueChange={v => setFilterDept(v || "ALL")}>
            <SelectTrigger className="flex-1 min-w-[80px] glass h-8 text-xs"><SelectValue placeholder="Dept" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="ALL">Tous</SelectItem>
              {departments.map(d => <SelectItem key={d!} value={d!}>{d}</SelectItem>)}
            </SelectContent>
          </Select>
          <Select value={filterRegion} onValueChange={v => setFilterRegion(v || "ALL")}>
            <SelectTrigger className="flex-1 min-w-[90px] glass h-8 text-xs">
              <MapPin className="w-3 h-3 mr-1 text-emerald-500" />
              <SelectValue placeholder="Region" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="ALL">Toutes regions</SelectItem>
              {SENEGAL_REGIONS.map(r => <SelectItem key={r.code} value={r.code}>{r.name}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>

        <p className="text-[10px] text-muted-foreground">{filteredProjects.length} projets actifs</p>

        <div className="space-y-1.5 max-h-[calc(100vh-380px)] overflow-y-auto">
          {filteredProjects.map(project => {
            const isSelected = selectedProject?.id === project.id;
            const latest = project.monitoringEntries?.[0];
            return (
              <Card
                key={project.id}
                className={`glass p-3 cursor-pointer transition-all ${isSelected ? "glow-cyan ring-1 ring-primary" : "hover:bg-accent/50"}`}
                onClick={() => selectProject(project)}
              >
                <div className="flex items-center gap-2">
                  <div className="w-1.5 h-10 rounded-full flex-shrink-0" style={{ backgroundColor: PILLAR_COLORS[project.pillar] }} />
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-semibold truncate">{project.projectName}</p>
                    <div className="flex items-center gap-1 mt-0.5">
                      <span className="text-[10px] text-muted-foreground">{project.partner.acronym || project.partner.name}</span>
                      {project.departmentLead && <Badge variant="secondary" className="text-[8px] h-3.5">{project.departmentLead}</Badge>}
                    </div>
                    {project.regions && (
                      <div className="flex items-center gap-0.5 mt-0.5">
                        <MapPin className="w-2.5 h-2.5 text-emerald-500" />
                        <span className="text-[9px] text-muted-foreground truncate">{project.regions.split(",").map(r => REGION_LABELS[r] || r).slice(0, 3).join(", ")}</span>
                      </div>
                    )}
                  </div>
                  {latest && (
                    <div className="text-right flex-shrink-0">
                      <p className="text-[10px] font-medium">{latest.physicalRate}%</p>
                      <p className="text-[8px] text-muted-foreground">{latest.period}</p>
                    </div>
                  )}
                  <ChevronRight className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0" />
                </div>
              </Card>
            );
          })}
        </div>
      </div>

      {/* ── RIGHT: Forms ── */}
      <div className="lg:col-span-2">
        {!selectedProject ? (
          <Card className="glass p-12 text-center">
            <TrendingUp className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
            <p className="text-sm text-muted-foreground">Selectionnez un projet actif pour saisir son avancement</p>
            <p className="text-xs text-muted-foreground mt-1">Utilisez les filtres pilier, departement et region pour affiner</p>
          </Card>
        ) : (
          <div className="space-y-4">
            {success && (
              <Card className="glass p-3 border-emerald-500/30 bg-emerald-500/5">
                <div className="flex items-center gap-2 text-emerald-500">
                  <CheckCircle2 className="w-4 h-4" />
                  <span className="text-sm font-medium">{success}</span>
                </div>
              </Card>
            )}

            {/* Project header */}
            <Card className="glass p-4" style={{ borderLeft: `3px solid ${PILLAR_COLORS[selectedProject.pillar]}` }}>
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold" style={{ fontFamily: "'Poppins', sans-serif" }}>{selectedProject.projectName}</h3>
                  <div className="flex items-center gap-2 mt-1 flex-wrap">
                    <span className="text-xs text-muted-foreground">{selectedProject.partner.acronym || selectedProject.partner.name}</span>
                    <Badge variant="outline" className="text-[9px]" style={{ borderColor: PILLAR_COLORS[selectedProject.pillar], color: PILLAR_COLORS[selectedProject.pillar] }}>{PILLAR_LABELS[selectedProject.pillar]}</Badge>
                    {selectedProject.departmentLead && <Badge variant="secondary" className="text-[9px]">{selectedProject.departmentLead}</Badge>}
                    <span className="text-[10px] text-muted-foreground">{formatCurrency(selectedProject.totalAmount)}</span>
                  </div>
                </div>
                {lastEntry && (
                  <div className="text-right">
                    <p className="text-xs text-muted-foreground">Dernier suivi: {lastEntry.period}</p>
                    <div className="flex gap-3 mt-0.5">
                      <span className="text-xs">Phys: <strong>{lastEntry.physicalRate}%</strong></span>
                      <span className="text-xs">Fin: <strong>{lastEntry.financialRate}%</strong></span>
                    </div>
                  </div>
                )}
              </div>
            </Card>

            {/* Tab bar */}
            <div className="flex gap-1 glass rounded-lg p-1">
              {[
                { key: "indicateurs" as const, label: "Indicateurs", icon: Gauge, count: relevantIndicators.length, color: "#0089D0" },
                { key: "suivi" as const, label: "Suivi periodique", icon: TrendingUp, color: "#10b981" },
                { key: "regions" as const, label: "Zones d'intervention", icon: MapPin, count: editRegions.length, color: "#EF7A16" },
              ].map(tab => (
                <button
                  key={tab.key}
                  onClick={() => setActiveTab(tab.key)}
                  className={`flex items-center gap-1.5 px-3 py-2 rounded-md text-xs transition-all flex-1 justify-center ${activeTab === tab.key ? "bg-primary/10 text-primary font-semibold" : "hover:bg-accent/50 text-muted-foreground"}`}
                >
                  <tab.icon className="w-3.5 h-3.5" style={{ color: activeTab === tab.key ? tab.color : undefined }} />
                  {tab.label}
                  {tab.count !== undefined && <Badge variant="secondary" className="text-[8px] h-4 ml-1">{tab.count}</Badge>}
                </button>
              ))}
            </div>

            {/* ── TAB: Indicateurs (bulk saisie) ── */}
            {activeTab === "indicateurs" && (
              <Card className="glass p-5">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h4 className="text-sm font-semibold" style={{ fontFamily: "'Poppins', sans-serif" }}>
                      <Gauge className="w-4 h-4 inline mr-1 text-[#0089D0]" />
                      Saisie des indicateurs — {PILLAR_LABELS[selectedProject.pillar]}
                    </h4>
                    <p className="text-[10px] text-muted-foreground mt-0.5">
                      Renseignez les valeurs realisees pour chaque indicateur a la date selectionnee
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Label className="text-[10px] text-muted-foreground">Periode :</Label>
                    <Select value={saisePeriod} onValueChange={v => setSaisePeriod(v || "2025-Q2")}>
                      <SelectTrigger className="w-[110px] h-8 text-xs"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {PERIODS.map(p => <SelectItem key={p} value={p}>{p}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Indicator list with inline saisie */}
                <div className="space-y-2 max-h-[calc(100vh-450px)] overflow-y-auto pr-1">
                  {relevantIndicators.map(ind => {
                    const catColor = CATEGORY_COLORS[ind.category];
                    const projectVals = ind.values.filter(v => v.projectId === selectedProject.id);
                    const lastVal = projectVals[0]; // latest
                    const currentBulk = bulkValues[ind.id] || { actualValue: "", status: "PENDING", comments: "" };

                    return (
                      <div key={ind.id} className="glass rounded-lg p-3">
                        <div className="flex items-start gap-2 mb-2">
                          <Badge className="text-[8px] mt-0.5 flex-shrink-0" style={{ backgroundColor: `${catColor}20`, color: catColor }}>
                            {ind.code}
                          </Badge>
                          <div className="flex-1 min-w-0">
                            <p className="text-[11px] font-medium leading-tight">{ind.name}</p>
                            <div className="flex items-center gap-2 mt-0.5 text-[9px] text-muted-foreground flex-wrap">
                              <span>{CATEGORY_LABELS[ind.category]}</span>
                              {ind.unit && <span>| {ind.unit}</span>}
                              {ind.baseline && <span>| Base: <strong className="text-foreground">{ind.baseline}</strong></span>}
                              {ind.target2025 && <span>| 2025: <strong className="text-foreground">{ind.target2025}</strong></span>}
                              {ind.target2027 && <span>| 2027: <strong className="text-[#0089D0]">{ind.target2027}</strong></span>}
                            </div>
                          </div>
                          {/* Last recorded value */}
                          {lastVal && (
                            <div className="text-right flex-shrink-0">
                              <p className="text-[10px] font-bold" style={{ color: STATUS_IND[lastVal.status]?.color }}>{lastVal.actualValue || "—"}</p>
                              <p className="text-[8px] text-muted-foreground">{lastVal.period}</p>
                            </div>
                          )}
                        </div>

                        {/* Inline saisie row */}
                        <div className="flex items-center gap-2">
                          <Input
                            value={currentBulk.actualValue}
                            onChange={e => setBulkValues(prev => ({ ...prev, [ind.id]: { ...currentBulk, actualValue: e.target.value } }))}
                            placeholder={`Valeur ${saisePeriod}${ind.unit ? ` (${ind.unit})` : ""}`}
                            className="h-7 text-xs flex-1"
                          />
                          <Select value={currentBulk.status} onValueChange={v => setBulkValues(prev => ({ ...prev, [ind.id]: { ...currentBulk, status: v || "PENDING" } }))}>
                            <SelectTrigger className="h-7 text-[10px] w-[120px]"><SelectValue /></SelectTrigger>
                            <SelectContent>
                              {Object.entries(STATUS_IND).map(([k, v]) => <SelectItem key={k} value={k}>{v.label}</SelectItem>)}
                            </SelectContent>
                          </Select>
                          <Input
                            value={currentBulk.comments}
                            onChange={e => setBulkValues(prev => ({ ...prev, [ind.id]: { ...currentBulk, comments: e.target.value } }))}
                            placeholder="Commentaire..."
                            className="h-7 text-xs flex-1"
                          />
                        </div>

                        {/* History mini */}
                        {projectVals.length > 0 && (
                          <div className="flex gap-1 mt-2 flex-wrap">
                            {projectVals.slice(0, 4).map(v => (
                              <div key={v.id} className="flex items-center gap-1 text-[8px] glass px-1.5 py-0.5 rounded">
                                <span className="text-muted-foreground">{v.period}:</span>
                                <span className="font-medium">{v.actualValue || "—"}</span>
                                <div className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: STATUS_IND[v.status]?.color }} />
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>

                {/* Bulk submit */}
                <div className="flex items-center justify-between mt-4 pt-4 border-t border-border">
                  <p className="text-[10px] text-muted-foreground">
                    {Object.values(bulkValues).filter(v => v.actualValue).length} indicateur(s) renseigne(s) pour <strong>{saisePeriod}</strong>
                  </p>
                  <Button onClick={submitBulkIndicators} disabled={saving || Object.values(bulkValues).filter(v => v.actualValue).length === 0}>
                    <Save className="w-4 h-4 mr-2" />
                    {saving ? "Enregistrement..." : "Enregistrer tous les indicateurs"}
                  </Button>
                </div>
              </Card>
            )}

            {/* ── TAB: Suivi periodique ── */}
            {activeTab === "suivi" && (
              <Card className="glass p-5">
                <h4 className="text-sm font-semibold mb-4" style={{ fontFamily: "'Poppins', sans-serif" }}>
                  <Calendar className="w-4 h-4 inline mr-1" /> Fiche de Suivi Periodique
                </h4>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  <div>
                    <Label>Periode *</Label>
                    <Input value={monForm.period} onChange={e => setMonForm(f => ({ ...f, period: e.target.value }))} placeholder="2026-Q2" className="mt-1" />
                  </div>
                  <div>
                    <Label>Type</Label>
                    <Select value={monForm.periodType} onValueChange={v => setMonForm(f => ({ ...f, periodType: v || "QUARTERLY" }))}>
                      <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="MONTHLY">Mensuel</SelectItem>
                        <SelectItem value="QUARTERLY">Trimestriel</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Taux exec. physique (%)</Label>
                    <Input type="number" min="0" max="100" value={monForm.physicalRate} onChange={e => setMonForm(f => ({ ...f, physicalRate: e.target.value }))} className="mt-1" />
                  </div>
                  <div>
                    <Label>Cible physique (%)</Label>
                    <Input type="number" min="0" max="100" value={monForm.physicalTarget} onChange={e => setMonForm(f => ({ ...f, physicalTarget: e.target.value }))} className="mt-1" />
                  </div>
                  <div>
                    <Label>Taux absorption financiere (%)</Label>
                    <Input type="number" min="0" max="100" value={monForm.financialRate} onChange={e => setMonForm(f => ({ ...f, financialRate: e.target.value }))} className="mt-1" />
                  </div>
                  <div>
                    <Label>Cible financiere (%)</Label>
                    <Input type="number" min="0" max="100" value={monForm.financialTarget} onChange={e => setMonForm(f => ({ ...f, financialTarget: e.target.value }))} className="mt-1" />
                  </div>
                  <div className="col-span-full">
                    <Label>Observations</Label>
                    <Textarea value={monForm.observations} onChange={e => setMonForm(f => ({ ...f, observations: e.target.value }))} placeholder="Commentaires, ecarts plan/reel..." rows={3} className="mt-1" />
                  </div>
                </div>
                <Button onClick={submitMonitoring} disabled={saving} className="mt-4">
                  <Send className="w-4 h-4 mr-2" />{saving ? "Enregistrement..." : "Enregistrer la fiche de suivi"}
                </Button>
              </Card>
            )}

            {/* ── TAB: Zones d'intervention ── */}
            {activeTab === "regions" && (
              <Card className="glass p-5">
                <h4 className="text-sm font-semibold mb-3" style={{ fontFamily: "'Poppins', sans-serif" }}>
                  <MapPin className="w-4 h-4 inline mr-1 text-emerald-500" /> Zones d'Intervention
                </h4>
                {selectedProject.regions && (
                  <div className="flex flex-wrap gap-1 mb-3">
                    <span className="text-[10px] text-muted-foreground mr-1">Actuelles:</span>
                    {selectedProject.regions.split(",").map(r => (
                      <span key={r} className="text-[9px] px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">{REGION_LABELS[r] || r}</span>
                    ))}
                  </div>
                )}
                <div className="grid grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-2">
                  {SENEGAL_REGIONS.map(region => {
                    const isSelected = editRegions.includes(region.code);
                    return (
                      <button
                        key={region.code}
                        onClick={() => setEditRegions(prev => prev.includes(region.code) ? prev.filter(r => r !== region.code) : [...prev, region.code])}
                        className={`px-2.5 py-2 rounded-lg text-xs transition-all text-left ${isSelected ? "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 ring-1 ring-emerald-500/30 font-semibold" : "glass hover:bg-accent/50"}`}
                      >
                        <div className="flex items-center gap-1.5">
                          <div className={`w-2.5 h-2.5 rounded-full ${isSelected ? "bg-emerald-500" : "bg-muted-foreground/30"}`} />
                          {region.name}
                        </div>
                      </button>
                    );
                  })}
                </div>
                <Button onClick={saveRegions} disabled={saving} className="mt-4">
                  <MapPin className="w-4 h-4 mr-2" />Sauvegarder ({editRegions.length} region{editRegions.length > 1 ? "s" : ""})
                </Button>
              </Card>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
