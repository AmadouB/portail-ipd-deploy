"use client";

import { MapContainer, TileLayer, CircleMarker, Tooltip as MapTooltip } from "react-leaflet";
import { formatCurrency } from "@/lib/utils";
import { useTheme } from "@/components/theme-provider";
import "leaflet/dist/leaflet.css";

interface CountryData {
  country: string;
  count: number;
  lat: number;
  lng: number;
  projects: number;
  amount: number;
}

const TILES = {
  dark: "https://{s}.basemaps.cartocdn.com/light_nolabels/{z}/{x}/{y}{r}.png",
  light: "https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png",
};

function getRadius(count: number): number {
  if (count >= 50) return 22;
  if (count >= 20) return 18;
  if (count >= 10) return 14;
  if (count >= 5) return 11;
  if (count >= 2) return 8;
  return 6;
}

function getColor(count: number): string {
  if (count >= 50) return "#0089D0";
  if (count >= 10) return "#10b981";
  if (count >= 5) return "#EF7A16";
  return "#8b5cf6";
}

export default function PartnersMap({ data }: { data: CountryData[] }) {
  const { theme } = useTheme();

  return (
    <MapContainer
      center={[20, 0]}
      zoom={2}
      className="w-full h-full rounded-lg"
      style={{ background: theme === "dark" ? "#052A62" : "#F2F3F5", minHeight: 300 }}
      scrollWheelZoom={false}
    >
      <TileLayer
        attribution='&copy; <a href="https://carto.com/">CARTO</a>'
        url={TILES[theme]}
      />
      {data.map((d, i) => {
        const radius = getRadius(d.count);
        const color = getColor(d.count);
        return (
          <CircleMarker
            key={i}
            center={[d.lat, d.lng]}
            radius={radius}
            pathOptions={{
              color,
              fillColor: color,
              fillOpacity: 0.55,
              weight: 2,
              opacity: 0.9,
            }}
          >
            <MapTooltip direction="top" offset={[0, -radius]}>
              <div className="text-xs min-w-[140px]">
                <p className="font-bold text-sm" style={{ color }}>{d.country}</p>
                <div className="mt-1 space-y-0.5">
                  <div className="flex justify-between gap-4">
                    <span className="opacity-60">Partenaires</span>
                    <strong>{d.count}</strong>
                  </div>
                  <div className="flex justify-between gap-4">
                    <span className="opacity-60">Projets</span>
                    <strong>{d.projects}</strong>
                  </div>
                  <div className="flex justify-between gap-4">
                    <span className="opacity-60">Volume</span>
                    <strong>{formatCurrency(d.amount)}</strong>
                  </div>
                </div>
              </div>
            </MapTooltip>
          </CircleMarker>
        );
      })}
    </MapContainer>
  );
}
