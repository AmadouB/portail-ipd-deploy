"use client";

import { useEffect, useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Building2, Globe, TrendingUp, AlertTriangle, Users, FolderKanban, DollarSign, CheckCircle2, Clock, Hourglass, FileSignature, Network, MapPin } from "lucide-react";
import { REGION_LABELS } from "@/lib/regions";
import { formatCurrency, PILLAR_COLORS, PILLAR_LABELS } from "@/lib/utils";
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, LabelList } from "recharts";
import dynamic from "next/dynamic";

const PartnersMap = dynamic(() => import("./partners-map"), { ssr: false });

interface KpiData {
  summary: {
    totalProjects: number;
    activeProjects: number;
    prospectionProjects: number;
    closedProjects: number;
    totalPartners: number;
    totalFinancial: number;
    activeFinancial: number;
    totalMedia: number;
    avgPhysicalRate: number;
    avgFinancialRate: number;
    milestonesApproved: number;
    milestonesPending: number;
    risksHigh: number;
    risksMedium: number;
  };
  byPillar: Array<{ pillar: string; count: number; amount: number }>;
  byDepartment: Array<{ department: string; count: number; amount: number }>;
  byPartnerType: Array<{ type: string; count: number; amount: number }>;
  byTier: Array<{ tier: string; count: number; amount: number }>;
  pipelineStatus: Array<{ status: string; count: number }>;
  topPartners: Array<{ name: string; amount: number }>;
  byRegion: Array<{ region: string; count: number; amount: number }>;
  byCountry: Array<{ country: string; count: number; lat: number; lng: number; projects: number; amount: number }>;
  byContractType: Array<{ contractType: string; count: number; amount: number }>;
  byDivisionLead: Array<{ division: string; count: number; amount: number }>;
  byFundingBracket: Array<{
    label: string;
    color: string;
    count: number;
    activeCount: number;
    amount: number;
    pillarBreakdown: Record<string, number>;
  }>;
  projectAge: {
    avgMonths: number;
    medianMonths: number;
    minMonths: number;
    maxMonths: number;
    totalWithDates: number;
    distribution: Array<{
      label: string;
      count: number;
      amount: number;
      pillarBreakdown: Record<string, number>;
    }>;
  };
}

import { StatusToggle } from "@/components/ui/status-toggle";

export function DashboardContent() {
  const [data, setData] = useState<KpiData | null>(null);
  const [statusFilter, setStatusFilter] = useState<"ALL" | "ACTIF" | "INACTIF">("ALL");

  useEffect(() => {
    const params = statusFilter !== "ALL" ? `?status=${statusFilter}` : "";
    fetch(`/api/kpi${params}`).then(r => r.json()).then(setData);
  }, [statusFilter]);

  if (!data) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {[...Array(8)].map((_, i) => (
          <Card key={i} className="glass p-6 animate-pulse h-32" />
        ))}
      </div>
    );
  }

  const { summary } = data;

  const kpiCards = [
    { label: "Projets Actifs", value: summary.activeProjects, total: summary.totalProjects, icon: FolderKanban, color: "glow-cyan", textColor: "text-[#0089D0]" },
    { label: "Partenaires", value: summary.totalPartners, icon: Building2, color: "glow-emerald", textColor: "text-emerald-500" },
    { label: "Volume Financier", value: formatCurrency(summary.totalFinancial), icon: DollarSign, color: "glow-amber", textColor: "text-[#EF7A16]" },
    { label: "En Prospection", value: summary.prospectionProjects, icon: TrendingUp, color: "glow-purple", textColor: "text-purple-500" },
    { label: "Jalons Approuves", value: summary.milestonesApproved, total: summary.milestonesApproved + summary.milestonesPending, icon: CheckCircle2, color: "glow-emerald", textColor: "text-emerald-500" },
    { label: "Risques Eleves", value: summary.risksHigh, icon: AlertTriangle, color: "glow-red", textColor: "text-red-500" },
    { label: "Exec. Physique", value: `${summary.avgPhysicalRate}%`, icon: TrendingUp, color: "glow-cyan", textColor: "text-[#0089D0]" },
    { label: "Exec. Financiere", value: `${summary.avgFinancialRate}%`, icon: DollarSign, color: "glow-amber", textColor: "text-[#EF7A16]" },
  ];

  const pillarChartData = data.byPillar.map(p => ({
    name: PILLAR_LABELS[p.pillar] || p.pillar,
    value: p.amount,
    count: p.count,
    fill: PILLAR_COLORS[p.pillar] || "#6b7280",
  }));

  const treemapData = data.topPartners.map(p => ({
    name: p.name,
    size: p.amount,
    fill: "#0089D0",
  }));

  return (
    <div className="space-y-6">
      {/* Status Toggle */}
      <div className="flex items-center justify-between">
        <StatusToggle value={statusFilter} onChange={setStatusFilter} />
        {statusFilter !== "ALL" && (
          <span className="text-[10px] text-muted-foreground">
            Filtre : <strong className={statusFilter === "ACTIF" ? "text-emerald-500" : "text-[#EF7A16]"}>{statusFilter === "ACTIF" ? "Projets actifs" : "Projets inactifs"}</strong>
          </span>
        )}
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {kpiCards.map((card, i) => (
          <Card key={i} className={`glass p-5 ${card.color} animate-fade-up`} style={{ animationDelay: `${i * 0.05}s` }}>
            <div className="flex items-start justify-between">
              <div>
                <p className="text-xs text-muted-foreground uppercase tracking-wider">{card.label}</p>
                <p className={`text-2xl font-bold mt-1 ${card.textColor}`} style={{ fontFamily: "'Poppins', sans-serif" }}>
                  {card.value}
                </p>
                {card.total && (
                  <p className="text-xs text-muted-foreground mt-1">sur {card.total}</p>
                )}
              </div>
              <card.icon className={`w-8 h-8 ${card.textColor} opacity-50`} />
            </div>
          </Card>
        ))}
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Pillar Distribution */}
        <Card className="glass p-6">
          <h3 className="text-sm font-semibold mb-4" style={{ fontFamily: "'Poppins', sans-serif" }}>
            Repartition par Pilier Strategique
          </h3>
          <div className="flex items-center gap-6">
            <ResponsiveContainer width={180} height={180}>
              <PieChart>
                <Pie data={pillarChartData} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={50} outerRadius={80} paddingAngle={2} label={(props: any) => { const { cx, cy, midAngle, outerRadius: or, payload } = props; const rad = Math.PI / 180; const x = cx + (or + 14) * Math.cos(-midAngle * rad); const y = cy + (or + 14) * Math.sin(-midAngle * rad); return <text x={x} y={y} textAnchor="middle" dominantBaseline="central" fontSize={11} fontWeight={700} fill="currentColor">{payload.count}</text>; }}>
                  {pillarChartData.map((entry, i) => (
                    <Cell key={i} fill={entry.fill} />
                  ))}
                </Pie>
                <Tooltip formatter={(value) => formatCurrency(Number(value))} />
              </PieChart>
            </ResponsiveContainer>
            <div className="flex-1 space-y-2">
              {pillarChartData.map((p, i) => (
                <div key={i} className="flex items-center gap-2 text-sm">
                  <div className="w-3 h-3 rounded-full flex-shrink-0" style={{ backgroundColor: p.fill }} />
                  <span className="text-muted-foreground flex-1 truncate">{p.name}</span>
                  <span className="font-medium">{p.count}</span>
                </div>
              ))}
            </div>
          </div>
        </Card>

        {/* Financial by Pillar */}
        <Card className="glass p-6">
          <h3 className="text-sm font-semibold mb-4" style={{ fontFamily: "'Poppins', sans-serif" }}>
            Volume Financier par Pilier
          </h3>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={pillarChartData} layout="vertical">
              <XAxis type="number" tickFormatter={(v) => `${(v / 1_000_000).toFixed(0)}M`} fontSize={11} />
              <YAxis type="category" dataKey="name" width={110} fontSize={11} />
              <Tooltip formatter={(value) => formatCurrency(Number(value))} />
              <Bar dataKey="value" radius={[0, 6, 6, 0]}>
                {pillarChartData.map((entry, i) => (
                  <Cell key={i} fill={entry.fill} />
                ))}
                <LabelList dataKey="value" position="right" fontSize={10} fontWeight={600} formatter={(v: any) => `${(Number(v) / 1e6).toFixed(1)}M`} />
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </Card>
      </div>

      {/* Partners World Map */}
      <Card className="glass p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-sm font-semibold" style={{ fontFamily: "'Poppins', sans-serif" }}>
              <Globe className="w-4 h-4 inline mr-1.5 text-[#0089D0]" />
              Origine Geographique des Partenaires
            </h3>
            <p className="text-[10px] text-muted-foreground mt-0.5">
              {data.byCountry.length} pays | {summary.totalPartners} partenaires | Taille proportionnelle au nombre de partenaires
            </p>
          </div>
          <div className="flex gap-4 text-[10px]">
            {[
              { label: ">=50", color: "#0089D0" },
              { label: "10-49", color: "#10b981" },
              { label: "5-9", color: "#EF7A16" },
              { label: "1-4", color: "#8b5cf6" },
            ].map((l, i) => (
              <div key={i} className="flex items-center gap-1">
                <div className="w-3 h-3 rounded-full" style={{ backgroundColor: l.color, opacity: 0.7 }} />
                <span className="text-muted-foreground">{l.label}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
          <div className="lg:col-span-3 h-[350px] rounded-xl overflow-hidden">
            <PartnersMap data={data.byCountry} />
          </div>
          <div className="space-y-2 max-h-[350px] overflow-y-auto pr-1">
            <p className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1 sticky top-0 bg-card/80 backdrop-blur py-1">
              Top pays ({data.byCountry.length})
            </p>
            {data.byCountry.map((c, i) => (
              <div key={i} className="glass rounded-lg p-2.5">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-medium">{c.country}</span>
                  <span className="text-sm font-bold text-[#0089D0]" style={{ fontFamily: "'Poppins', sans-serif" }}>{c.count}</span>
                </div>
                <div className="flex items-center justify-between text-[10px] text-muted-foreground">
                  <span>{c.projects} projets</span>
                  <span>{formatCurrency(c.amount)}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </Card>

      {/* Funding Bracket Distribution */}
      <Card className="glass p-6">
        <h3 className="text-sm font-semibold mb-1" style={{ fontFamily: "'Poppins', sans-serif" }}>
          <DollarSign className="w-4 h-4 inline mr-1.5 text-[#0089D0]" />
          Projets par Tranche de Financement
        </h3>
        <p className="text-[10px] text-muted-foreground mb-5">
          Repartition des {summary.totalProjects} projets selon le montant total du financement
        </p>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-center">
          {/* Bar chart */}
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={data.byFundingBracket} barCategoryGap="25%">
              <XAxis dataKey="label" fontSize={11} tickLine={false} axisLine={false} />
              <YAxis fontSize={11} tickLine={false} axisLine={false} allowDecimals={false} />
              <Tooltip
                content={({ active, payload, label }) => {
                  if (!active || !payload?.length) return null;
                  const d = payload[0].payload as typeof data.byFundingBracket[0];
                  return (
                    <div className="glass rounded-lg p-3 shadow-lg border border-border text-xs min-w-[180px]">
                      <p className="font-semibold mb-1.5" style={{ color: d.color }}>{label}</p>
                      <div className="space-y-1">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Total projets</span>
                          <strong>{d.count}</strong>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Dont actifs</span>
                          <strong className="text-emerald-500">{d.activeCount}</strong>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Volume</span>
                          <strong>{formatCurrency(d.amount)}</strong>
                        </div>
                      </div>
                      {Object.keys(d.pillarBreakdown).length > 0 && (
                        <div className="mt-2 pt-2 border-t border-border space-y-0.5">
                          {Object.entries(d.pillarBreakdown)
                            .sort((a, b) => b[1] - a[1])
                            .map(([pillar, count]) => (
                              <div key={pillar} className="flex items-center gap-1.5">
                                <div className="w-2 h-2 rounded-full" style={{ backgroundColor: PILLAR_COLORS[pillar] || "#6b7280" }} />
                                <span className="text-muted-foreground flex-1">{PILLAR_LABELS[pillar] || pillar}</span>
                                <span className="font-medium">{count}</span>
                              </div>
                            ))}
                        </div>
                      )}
                    </div>
                  );
                }}
              />
              <Bar dataKey="count" radius={[6, 6, 0, 0]} maxBarSize={60}>
                {data.byFundingBracket.map((entry, i) => (
                  <Cell key={i} fill={entry.color} fillOpacity={0.85} />
                ))}
                <LabelList dataKey="count" position="top" fontSize={11} fontWeight={700} fill="currentColor" />
              </Bar>
            </BarChart>
          </ResponsiveContainer>

          {/* Detail cards */}
          <div className="space-y-3">
            {data.byFundingBracket.map((bracket, i) => {
              const pct = summary.totalProjects > 0 ? Math.round((bracket.count / summary.totalProjects) * 100) : 0;
              return (
                <div key={i} className="glass rounded-lg p-3.5 flex items-center gap-4">
                  <div
                    className="w-12 h-12 rounded-lg flex items-center justify-center text-white text-lg font-bold flex-shrink-0"
                    style={{ backgroundColor: bracket.color, fontFamily: "'Poppins', sans-serif" }}
                  >
                    {bracket.count}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm font-semibold" style={{ color: bracket.color }}>{bracket.label}</span>
                      <span className="text-xs text-muted-foreground">{pct}%</span>
                    </div>
                    <div className="h-2 rounded-full bg-muted overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all duration-700"
                        style={{ width: `${pct}%`, backgroundColor: bracket.color }}
                      />
                    </div>
                    <div className="flex items-center justify-between mt-1.5 text-[10px] text-muted-foreground">
                      <span>{bracket.activeCount} actif{bracket.activeCount > 1 ? "s" : ""}</span>
                      <span className="font-medium" style={{ color: bracket.color }}>{formatCurrency(bracket.amount)}</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </Card>

      {/* Regions du Senegal */}
      <Card className="glass p-6">
        <h3 className="text-sm font-semibold mb-1" style={{ fontFamily: "'Poppins', sans-serif" }}>
          <MapPin className="w-4 h-4 inline mr-1.5 text-[#10b981]" />
          Zones d'Intervention au Senegal
        </h3>
        <p className="text-[10px] text-muted-foreground mb-4">
          Nombre de projets par region d'intervention (un projet peut couvrir plusieurs regions)
        </p>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-center">
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={data.byRegion.slice(0, 14)} layout="vertical">
              <XAxis type="number" fontSize={10} tickLine={false} axisLine={false} allowDecimals={false} />
              <YAxis type="category" dataKey="region" width={100} fontSize={10} tickLine={false} axisLine={false} tickFormatter={(v: string) => REGION_LABELS[v] || v} />
              <Tooltip
                content={({ active, payload, label }) => {
                  if (!active || !payload?.length) return null;
                  const d = payload[0].payload as typeof data.byRegion[0];
                  return (
                    <div className="glass rounded-lg p-3 shadow-lg border border-border text-xs">
                      <p className="font-semibold mb-1">{REGION_LABELS[d.region] || d.region}</p>
                      <p><span className="text-muted-foreground">Projets :</span> <strong>{d.count}</strong></p>
                      <p><span className="text-muted-foreground">Volume :</span> <strong>{formatCurrency(d.amount)}</strong></p>
                    </div>
                  );
                }}
              />
              <Bar dataKey="count" radius={[0, 6, 6, 0]} maxBarSize={20}>
                {data.byRegion.slice(0, 14).map((_, i) => {
                  const colors = ["#10b981", "#0089D0", "#EF7A16", "#8b5cf6", "#ec4899", "#FFD500", "#06b6d4", "#ef4444", "#84cc16", "#f97316", "#a855f7", "#14b8a6", "#f43f5e", "#6366f1"];
                  return <Cell key={i} fill={colors[i % colors.length]} fillOpacity={0.8} />;
                })}
                <LabelList dataKey="count" position="right" fontSize={10} fontWeight={700} fill="currentColor" />
              </Bar>
            </BarChart>
          </ResponsiveContainer>

          <div className="space-y-2">
            {data.byRegion.slice(0, 14).map((r, i) => {
              const maxCount = data.byRegion[0]?.count || 1;
              const pct = Math.round((r.count / maxCount) * 100);
              const colors = ["#10b981", "#0089D0", "#EF7A16", "#8b5cf6", "#ec4899", "#FFD500", "#06b6d4", "#ef4444", "#84cc16", "#f97316", "#a855f7", "#14b8a6", "#f43f5e", "#6366f1"];
              const color = colors[i % colors.length];
              return (
                <div key={i} className="flex items-center gap-3">
                  <span className="text-xs font-medium w-24 truncate" style={{ color }}>{REGION_LABELS[r.region] || r.region}</span>
                  <div className="flex-1 h-2 rounded-full bg-muted overflow-hidden">
                    <div className="h-full rounded-full transition-all duration-500" style={{ width: `${pct}%`, backgroundColor: color }} />
                  </div>
                  <span className="text-[10px] text-muted-foreground w-16 text-right">{formatCurrency(r.amount)}</span>
                </div>
              );
            })}
          </div>
        </div>
      </Card>

      {/* Contract Type, Department Lead, Division Lead */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Contract Type */}
        <Card className="glass p-6">
          <h3 className="text-sm font-semibold mb-1" style={{ fontFamily: "'Poppins', sans-serif" }}>
            <FileSignature className="w-4 h-4 inline mr-1.5 text-[#0089D0]" />
            Par Type de Contrat
          </h3>
          <p className="text-[10px] text-muted-foreground mb-4">Repartition des projets par type contractuel</p>
          <div className="space-y-2 max-h-[280px] overflow-y-auto pr-1">
            {data.byContractType.slice(0, 10).map((ct, i) => {
              const pct = summary.totalProjects > 0 ? Math.round((ct.count / summary.totalProjects) * 100) : 0;
              const colors = ["#0089D0", "#10b981", "#EF7A16", "#8b5cf6", "#ec4899", "#FFD500", "#ef4444", "#06b6d4", "#84cc16", "#f97316"];
              const color = colors[i % colors.length];
              return (
                <div key={i} className="glass rounded-lg p-2.5">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-medium truncate flex-1 mr-2">{ct.contractType}</span>
                    <span className="text-xs font-bold flex-shrink-0" style={{ color }}>{ct.count}</span>
                  </div>
                  <div className="h-1.5 rounded-full bg-muted overflow-hidden">
                    <div className="h-full rounded-full transition-all duration-500" style={{ width: `${pct}%`, backgroundColor: color }} />
                  </div>
                  <p className="text-[9px] text-muted-foreground mt-1">{formatCurrency(ct.amount)}</p>
                </div>
              );
            })}
          </div>
        </Card>

        {/* Department Lead */}
        <Card className="glass p-6">
          <h3 className="text-sm font-semibold mb-1" style={{ fontFamily: "'Poppins', sans-serif" }}>
            <Building2 className="w-4 h-4 inline mr-1.5 text-[#10b981]" />
            Par Departement Lead
          </h3>
          <p className="text-[10px] text-muted-foreground mb-4">Projets pilotes par chaque departement IPD</p>
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={data.byDepartment.sort((a, b) => b.count - a.count).slice(0, 11)}>
              <XAxis dataKey="department" fontSize={10} tickLine={false} axisLine={false} angle={-35} textAnchor="end" height={50} />
              <YAxis fontSize={10} tickLine={false} axisLine={false} allowDecimals={false} />
              <Tooltip
                content={({ active, payload, label }) => {
                  if (!active || !payload?.length) return null;
                  const d = payload[0].payload as typeof data.byDepartment[0];
                  return (
                    <div className="glass rounded-lg p-3 shadow-lg border border-border text-xs">
                      <p className="font-semibold mb-1">{label}</p>
                      <p><span className="text-muted-foreground">Projets :</span> <strong>{d.count}</strong></p>
                      <p><span className="text-muted-foreground">Volume :</span> <strong>{formatCurrency(d.amount)}</strong></p>
                    </div>
                  );
                }}
              />
              <Bar dataKey="count" radius={[4, 4, 0, 0]} maxBarSize={35}>
                {data.byDepartment.sort((a, b) => b.count - a.count).slice(0, 11).map((_, i) => {
                  const colors = ["#10b981", "#0089D0", "#EF7A16", "#8b5cf6", "#ec4899", "#FFD500", "#06b6d4", "#ef4444", "#84cc16", "#f97316", "#a855f7"];
                  return <Cell key={i} fill={colors[i % colors.length]} fillOpacity={0.8} />;
                })}
                <LabelList dataKey="count" position="top" fontSize={10} fontWeight={700} fill="currentColor" />
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </Card>

        {/* Division Lead */}
        <Card className="glass p-6">
          <h3 className="text-sm font-semibold mb-1" style={{ fontFamily: "'Poppins', sans-serif" }}>
            <Network className="w-4 h-4 inline mr-1.5 text-[#8b5cf6]" />
            Par Division Lead
          </h3>
          <p className="text-[10px] text-muted-foreground mb-4">Top divisions pilotant des projets</p>
          <div className="space-y-2 max-h-[280px] overflow-y-auto pr-1">
            {data.byDivisionLead.filter(d => d.division !== "Non defini").slice(0, 10).map((div, i) => {
              const maxCount = data.byDivisionLead[0]?.count || 1;
              const pct = Math.round((div.count / maxCount) * 100);
              const colors = ["#8b5cf6", "#0089D0", "#10b981", "#EF7A16", "#ec4899", "#FFD500", "#ef4444", "#06b6d4", "#84cc16", "#f97316"];
              const color = colors[i % colors.length];
              return (
                <div key={i} className="flex items-center gap-3">
                  <span className="text-[10px] text-muted-foreground w-4 text-right flex-shrink-0">{i + 1}</span>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-0.5">
                      <span className="text-xs font-medium truncate">{div.division}</span>
                      <div className="flex items-center gap-2 flex-shrink-0">
                        <span className="text-[10px] text-muted-foreground">{formatCurrency(div.amount)}</span>
                        <span className="text-xs font-bold" style={{ color }}>{div.count}</span>
                      </div>
                    </div>
                    <div className="h-1.5 rounded-full bg-muted overflow-hidden">
                      <div className="h-full rounded-full transition-all duration-500" style={{ width: `${pct}%`, backgroundColor: color }} />
                    </div>
                  </div>
                </div>
              );
            })}
            {data.byDivisionLead.find(d => d.division === "Non defini") && (
              <div className="text-[10px] text-muted-foreground mt-2 pt-2 border-t border-border">
                {data.byDivisionLead.find(d => d.division === "Non defini")!.count} projets sans division assignee
              </div>
            )}
          </div>
        </Card>
      </div>

      {/* Age Analytics Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Average Age Gauge */}
        <Card className="glass p-6">
          <h3 className="text-sm font-semibold mb-2" style={{ fontFamily: "'Poppins', sans-serif" }}>
            <Hourglass className="w-4 h-4 inline mr-1.5 text-[#8b5cf6]" />
            Age Moyen des Projets
          </h3>
          <p className="text-[10px] text-muted-foreground mb-4">{data.projectAge.totalWithDates} projets actifs avec date de debut</p>
          <div className="flex items-center justify-center mb-4">
            <div className="relative w-36 h-36">
              <svg viewBox="0 0 36 36" className="w-full h-full -rotate-90">
                <path
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                  fill="none" stroke="currentColor" className="text-muted/30" strokeWidth="3.5"
                />
                <path
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                  fill="none" stroke="#8b5cf6" strokeWidth="3.5"
                  strokeDasharray={`${Math.min(data.projectAge.avgMonths, 60) / 60 * 100}, 100`}
                  strokeLinecap="round"
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-3xl font-bold text-[#8b5cf6]" style={{ fontFamily: "'Poppins', sans-serif" }}>
                  {data.projectAge.avgMonths < 12
                    ? data.projectAge.avgMonths
                    : (data.projectAge.avgMonths / 12).toFixed(1)}
                </span>
                <span className="text-[10px] text-muted-foreground">
                  {data.projectAge.avgMonths < 12 ? "mois" : "ans"}
                </span>
              </div>
            </div>
          </div>
          <div className="grid grid-cols-3 gap-2 text-center">
            <div className="glass rounded-lg p-2">
              <p className="text-xs font-bold" style={{ fontFamily: "'Poppins', sans-serif" }}>
                {data.projectAge.minMonths < 12 ? `${data.projectAge.minMonths}m` : `${(data.projectAge.minMonths / 12).toFixed(1)}a`}
              </p>
              <p className="text-[9px] text-muted-foreground">Min</p>
            </div>
            <div className="glass rounded-lg p-2">
              <p className="text-xs font-bold text-[#8b5cf6]" style={{ fontFamily: "'Poppins', sans-serif" }}>
                {data.projectAge.medianMonths < 12 ? `${data.projectAge.medianMonths}m` : `${(data.projectAge.medianMonths / 12).toFixed(1)}a`}
              </p>
              <p className="text-[9px] text-muted-foreground">Mediane</p>
            </div>
            <div className="glass rounded-lg p-2">
              <p className="text-xs font-bold" style={{ fontFamily: "'Poppins', sans-serif" }}>
                {data.projectAge.maxMonths < 12 ? `${data.projectAge.maxMonths}m` : `${(data.projectAge.maxMonths / 12).toFixed(1)}a`}
              </p>
              <p className="text-[9px] text-muted-foreground">Max</p>
            </div>
          </div>
        </Card>

        {/* Age Distribution Bar Chart */}
        <Card className="glass p-6 lg:col-span-2">
          <h3 className="text-sm font-semibold mb-2" style={{ fontFamily: "'Poppins', sans-serif" }}>
            <Clock className="w-4 h-4 inline mr-1.5 text-[#0089D0]" />
            Projets Actifs par Tranche d'Age
          </h3>
          <p className="text-[10px] text-muted-foreground mb-4">Distribution des projets en cours selon leur anciennete</p>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={data.projectAge.distribution} barCategoryGap="20%">
              <XAxis dataKey="label" fontSize={11} tickLine={false} axisLine={false} />
              <YAxis fontSize={11} tickLine={false} axisLine={false} allowDecimals={false} />
              <Tooltip
                content={({ active, payload, label }) => {
                  if (!active || !payload?.length) return null;
                  const d = payload[0].payload as typeof data.projectAge.distribution[0];
                  return (
                    <div className="glass rounded-lg p-3 shadow-lg border border-border text-xs">
                      <p className="font-semibold mb-1">{label}</p>
                      <p><span className="text-muted-foreground">Projets :</span> <strong>{d.count}</strong></p>
                      <p><span className="text-muted-foreground">Volume :</span> <strong>{formatCurrency(d.amount)}</strong></p>
                      {Object.keys(d.pillarBreakdown).length > 0 && (
                        <div className="mt-1.5 pt-1.5 border-t border-border space-y-0.5">
                          {Object.entries(d.pillarBreakdown).map(([pillar, count]) => (
                            <div key={pillar} className="flex items-center gap-1.5">
                              <div className="w-2 h-2 rounded-full" style={{ backgroundColor: PILLAR_COLORS[pillar] || "#6b7280" }} />
                              <span className="text-muted-foreground">{PILLAR_LABELS[pillar] || pillar}</span>
                              <span className="ml-auto font-medium">{count}</span>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  );
                }}
              />
              <Bar dataKey="count" radius={[6, 6, 0, 0]} maxBarSize={50}>
                {data.projectAge.distribution.map((entry, i) => {
                  const colors = ["#10b981", "#0089D0", "#8b5cf6", "#EF7A16", "#ec4899", "#ef4444"];
                  return <Cell key={i} fill={colors[i % colors.length]} fillOpacity={entry.count > 0 ? 0.85 : 0.15} />;
                })}
                <LabelList dataKey="count" position="top" fontSize={11} fontWeight={700} fill="currentColor" formatter={(v: any) => Number(v) > 0 ? v : ""} />
              </Bar>
            </BarChart>
          </ResponsiveContainer>
          {/* Mini legend inline */}
          <div className="flex flex-wrap gap-3 mt-3 justify-center">
            {data.projectAge.distribution.filter(d => d.count > 0).map((d, i) => {
              const colors = ["#10b981", "#0089D0", "#8b5cf6", "#EF7A16", "#ec4899", "#ef4444"];
              return (
                <div key={i} className="flex items-center gap-1.5 text-[10px]">
                  <div className="w-2.5 h-2.5 rounded" style={{ backgroundColor: colors[i % colors.length] }} />
                  <span className="text-muted-foreground">{d.label}</span>
                  <span className="font-semibold">{d.count}</span>
                </div>
              );
            })}
          </div>
        </Card>
      </div>

      {/* Bottom Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Execution Rates */}
        <Card className="glass p-6">
          <h3 className="text-sm font-semibold mb-4" style={{ fontFamily: "'Poppins', sans-serif" }}>
            Taux d'Execution Global
          </h3>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-muted-foreground">Execution Physique</span>
                <span className="font-medium text-[#0089D0]">{summary.avgPhysicalRate}%</span>
              </div>
              <Progress value={summary.avgPhysicalRate} className="h-3" />
            </div>
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-muted-foreground">Execution Financiere</span>
                <span className="font-medium text-[#EF7A16]">{summary.avgFinancialRate}%</span>
              </div>
              <Progress value={summary.avgFinancialRate} className="h-3" />
            </div>
          </div>
          <div className="mt-6">
            <h4 className="text-xs text-muted-foreground uppercase tracking-wider mb-3">Pipeline des Projets</h4>
            <div className="flex gap-1">
              {data.pipelineStatus.map((s, i) => (
                <div key={i} className="flex-1 text-center">
                  <div className="text-lg font-bold" style={{ fontFamily: "'Poppins', sans-serif" }}>{s.count}</div>
                  <div className="text-[10px] text-muted-foreground">{s.status}</div>
                </div>
              ))}
            </div>
          </div>
        </Card>

        {/* Top Partners Treemap */}
        <Card className="glass p-6">
          <h3 className="text-sm font-semibold mb-4" style={{ fontFamily: "'Poppins', sans-serif" }}>
            Top 10 Partenaires par Volume Financier
          </h3>
          <div className="space-y-2">
            {data.topPartners.map((p, i) => (
              <div key={i} className="flex items-center gap-3">
                <span className="text-xs text-muted-foreground w-4">{i + 1}</span>
                <div className="flex-1">
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-sm font-medium truncate">{p.name}</span>
                    <span className="text-sm text-[#0089D0] font-medium">{formatCurrency(p.amount)}</span>
                  </div>
                  <div className="h-1.5 rounded-full bg-muted overflow-hidden">
                    <div
                      className="h-full rounded-full bg-[#0089D0]"
                      style={{ width: `${(p.amount / data.topPartners[0].amount) * 100}%` }}
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}
