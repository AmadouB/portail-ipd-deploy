"use client";

import { useEffect, useState, useMemo } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { formatCurrency, PILLAR_COLORS, PILLAR_LABELS, DEPARTMENT_LIST } from "@/lib/utils";
import { GripVertical, Building2, DollarSign, Search, FileSignature, Network } from "lucide-react";

const PIPELINE_STAGES = [
  { key: "IDENTIFICATION", label: "Identification", color: "#86B4DD" },
  { key: "CONTACT", label: "Prise de contact", color: "#0089D0" },
  { key: "DISCUSSION", label: "En discussion", color: "#8b5cf6" },
  { key: "ACCORD", label: "Accord de principe", color: "#FFD500" },
  { key: "NEGOCIATION", label: "Negociation", color: "#EF7A16" },
  { key: "SIGNATURE", label: "Signature", color: "#10b981" },
];

interface Project {
  id: string;
  projectName: string;
  status: string;
  pillar: string;
  totalAmount: number;
  maturationScore: number;
  departmentLead: string | null;
  divisionLead: string | null;
  contractType: string | null;
  partner: { name: string; acronym: string | null; type: string };
}

export function ProspectionContent() {
  const [allProjects, setAllProjects] = useState<Project[]>([]);
  const [draggedId, setDraggedId] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [filterPillar, setFilterPillar] = useState("ALL");
  const [filterDept, setFilterDept] = useState("ALL");
  const [filterContract, setFilterContract] = useState("ALL");
  const [filterDivision, setFilterDivision] = useState("ALL");

  useEffect(() => {
    fetch("/api/projects")
      .then(r => r.json())
      .then((data: Project[]) => {
        setAllProjects(data.filter(p =>
          PIPELINE_STAGES.some(s => s.key === p.status)
        ));
      });
  }, []);

  const contractTypes = useMemo(() => {
    const set = new Set<string>();
    allProjects.forEach(p => { if (p.contractType) set.add(p.contractType); });
    return Array.from(set).sort();
  }, [allProjects]);

  const divisions = useMemo(() => {
    const set = new Set<string>();
    allProjects.forEach(p => { if (p.divisionLead) set.add(p.divisionLead); });
    return Array.from(set).sort();
  }, [allProjects]);

  const projects = useMemo(() => {
    return allProjects.filter(p => {
      if (search) {
        const s = search.toLowerCase();
        if (!p.projectName.toLowerCase().includes(s) && !(p.partner.acronym || p.partner.name).toLowerCase().includes(s)) return false;
      }
      if (filterPillar !== "ALL" && p.pillar !== filterPillar) return false;
      if (filterDept !== "ALL" && p.departmentLead !== filterDept) return false;
      if (filterContract !== "ALL" && p.contractType !== filterContract) return false;
      if (filterDivision !== "ALL" && p.divisionLead !== filterDivision) return false;
      return true;
    });
  }, [allProjects, search, filterPillar, filterDept, filterContract, filterDivision]);

  const handleDragStart = (e: React.DragEvent, projectId: string) => {
    setDraggedId(projectId);
    e.dataTransfer.effectAllowed = "move";
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = "move";
    (e.currentTarget as HTMLElement).classList.add("drag-over");
  };

  const handleDragLeave = (e: React.DragEvent) => {
    (e.currentTarget as HTMLElement).classList.remove("drag-over");
  };

  const handleDrop = async (e: React.DragEvent, newStatus: string) => {
    e.preventDefault();
    (e.currentTarget as HTMLElement).classList.remove("drag-over");
    if (!draggedId) return;

    setAllProjects(prev =>
      prev.map(p => p.id === draggedId ? { ...p, status: newStatus } : p)
    );

    await fetch(`/api/projects/${draggedId}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status: newStatus }),
    });

    setDraggedId(null);
  };

  const getScoreColor = (score: number) => {
    if (score >= 75) return "text-emerald-500";
    if (score >= 40) return "text-[#EF7A16]";
    return "text-red-500";
  };

  const hasFilters = search || filterPillar !== "ALL" || filterDept !== "ALL" || filterContract !== "ALL" || filterDivision !== "ALL";

  return (
    <div className="space-y-4">
      {/* Filters */}
      <div className="flex flex-wrap gap-2.5 items-center">
        <div className="relative flex-1 min-w-[180px] max-w-xs">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input placeholder="Rechercher..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9 glass" />
        </div>
        <Select value={filterPillar} onValueChange={v => setFilterPillar(v || "ALL")}>
          <SelectTrigger className="w-[155px] glass"><SelectValue placeholder="Pilier" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="ALL">Tous piliers</SelectItem>
            {Object.entries(PILLAR_LABELS).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={filterDept} onValueChange={v => setFilterDept(v || "ALL")}>
          <SelectTrigger className="w-[130px] glass"><SelectValue placeholder="Dept" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="ALL">Tous depts</SelectItem>
            {DEPARTMENT_LIST.map(d => <SelectItem key={d} value={d}>{d}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={filterContract} onValueChange={v => setFilterContract(v || "ALL")}>
          <SelectTrigger className="w-[155px] glass">
            <FileSignature className="w-3.5 h-3.5 mr-1.5 text-[#0089D0]" />
            <SelectValue placeholder="Contrat" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="ALL">Tous contrats</SelectItem>
            {contractTypes.map(ct => <SelectItem key={ct} value={ct}>{ct}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={filterDivision} onValueChange={v => setFilterDivision(v || "ALL")}>
          <SelectTrigger className="w-[150px] glass">
            <Network className="w-3.5 h-3.5 mr-1.5 text-[#8b5cf6]" />
            <SelectValue placeholder="Division" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="ALL">Toutes divisions</SelectItem>
            {divisions.map(d => <SelectItem key={d} value={d}>{d}</SelectItem>)}
          </SelectContent>
        </Select>
        <Badge variant="secondary">{projects.length} projets</Badge>
        {hasFilters && (
          <button onClick={() => { setSearch(""); setFilterPillar("ALL"); setFilterDept("ALL"); setFilterContract("ALL"); setFilterDivision("ALL"); }} className="text-[10px] text-primary hover:underline">
            Reinitialiser
          </button>
        )}
      </div>

      {/* Kanban */}
      <div className="flex gap-3 overflow-x-auto pb-4">
      {PIPELINE_STAGES.map(stage => {
        const stageProjects = projects.filter(p => p.status === stage.key);
        return (
          <div
            key={stage.key}
            className="kanban-column flex-shrink-0 w-[280px]"
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={(e) => handleDrop(e, stage.key)}
          >
            {/* Column Header */}
            <div className="flex items-center gap-2 mb-3 px-1">
              <div className="w-3 h-3 rounded-full" style={{ backgroundColor: stage.color }} />
              <h3 className="text-sm font-semibold" style={{ fontFamily: "'Poppins', sans-serif" }}>
                {stage.label}
              </h3>
              <Badge variant="secondary" className="ml-auto text-xs">
                {stageProjects.length}
              </Badge>
            </div>

            {/* Cards */}
            <div className="space-y-2 min-h-[400px]">
              {stageProjects.map(project => (
                <Card
                  key={project.id}
                  draggable
                  onDragStart={(e) => handleDragStart(e, project.id)}
                  className={`kanban-card glass p-3 cursor-grab active:cursor-grabbing ${draggedId === project.id ? "dragging" : ""}`}
                >
                  <div className="flex items-start gap-2 mb-2">
                    <GripVertical className="w-4 h-4 text-muted-foreground mt-0.5 flex-shrink-0" />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{project.projectName}</p>
                      <div className="flex items-center gap-1 mt-1">
                        <Building2 className="w-3 h-3 text-muted-foreground" />
                        <span className="text-xs text-muted-foreground truncate">
                          {project.partner.acronym || project.partner.name}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 mb-2">
                    <Badge
                      variant="outline"
                      className="text-[10px]"
                      style={{ borderColor: PILLAR_COLORS[project.pillar], color: PILLAR_COLORS[project.pillar] }}
                    >
                      {PILLAR_LABELS[project.pillar]}
                    </Badge>
                    {project.departmentLead && (
                      <Badge variant="secondary" className="text-[10px]">
                        {project.departmentLead}
                      </Badge>
                    )}
                  </div>

                  <div className="flex items-center justify-between text-xs mb-2">
                    <div className="flex items-center gap-1">
                      <DollarSign className="w-3 h-3 text-muted-foreground" />
                      <span className="text-muted-foreground">{formatCurrency(project.totalAmount)}</span>
                    </div>
                    <span className={`font-bold ${getScoreColor(project.maturationScore)}`}>
                      {project.maturationScore}%
                    </span>
                  </div>

                  <Progress
                    value={project.maturationScore}
                    className="h-1.5"
                  />
                </Card>
              ))}
            </div>
          </div>
        );
      })}
      </div>
    </div>
  );
}
