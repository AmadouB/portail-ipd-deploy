"use client";

import { useEffect, useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { formatDate } from "@/lib/utils";
import { Search, Clock } from "lucide-react";

interface AuditEntry {
  id: string;
  userId: string;
  action: string;
  tableName: string;
  recordId: string;
  fieldName: string;
  oldValue: string;
  newValue: string;
  timestamp: string;
  user: { name: string; email: string };
}

export function AuditContent() {
  const [logs, setLogs] = useState<AuditEntry[]>([]);
  const [search, setSearch] = useState("");

  useEffect(() => {
    fetch("/api/audit").then(r => r.json()).then(setLogs);
  }, []);

  const filtered = logs.filter(l =>
    !search || l.user.name.toLowerCase().includes(search.toLowerCase()) || l.tableName.toLowerCase().includes(search.toLowerCase()) || l.action.toLowerCase().includes(search.toLowerCase())
  );

  const actionColors: Record<string, string> = {
    CREATE: "bg-emerald-500/10 text-emerald-500",
    UPDATE: "bg-[#0089D0]/10 text-[#0089D0]",
    DELETE: "bg-red-500/10 text-red-500",
    VALIDATE: "bg-purple-500/10 text-purple-500",
  };

  return (
    <div className="space-y-4">
      <div className="relative max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input placeholder="Filtrer par utilisateur, table, action..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9 glass" />
      </div>

      {filtered.length === 0 ? (
        <Card className="glass p-12 text-center">
          <Clock className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
          <p className="text-sm text-muted-foreground">Aucune entree d'audit</p>
        </Card>
      ) : (
        <div className="space-y-2">
          {filtered.map(log => (
            <Card key={log.id} className="glass p-4">
              <div className="flex items-center gap-3">
                <Badge className={`text-xs ${actionColors[log.action] || ""}`}>{log.action}</Badge>
                <span className="text-sm font-medium">{log.user.name}</span>
                <Badge variant="outline" className="text-[10px]">{log.tableName}</Badge>
                {log.fieldName && <span className="text-xs text-muted-foreground">champ: {log.fieldName}</span>}
                <span className="text-xs text-muted-foreground ml-auto">{formatDate(log.timestamp)}</span>
              </div>
              {(log.oldValue || log.newValue) && (
                <div className="mt-2 text-xs space-y-1">
                  {log.oldValue && <div className="text-red-400/70"><span className="text-muted-foreground">Avant:</span> {log.oldValue}</div>}
                  {log.newValue && <div className="text-emerald-400/70"><span className="text-muted-foreground">Apres:</span> {log.newValue}</div>}
                </div>
              )}
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
