"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import {
  LayoutDashboard,
  Target,
  FolderKanban,
  Building2,
  Map,
  Image,
  FileText,
  Settings,
  ClipboardList,
  PenSquare,
  Gauge,
  UserCog,
  ChevronLeft,
  ChevronRight,
  Sun,
  Moon,
  LogOut,
} from "lucide-react";
import { useRouter } from "next/navigation";
import { cn } from "@/lib/utils";
import { useTheme } from "@/components/theme-provider";

const navItems = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/prospection", label: "Prospection", icon: Target },
  { href: "/partenaires", label: "Partenaires", icon: Building2 },
  { href: "/projets", label: "Projets", icon: FolderKanban },
  { href: "/saisie", label: "Saisie", icon: PenSquare },
  { href: "/indicateurs", label: "Indicateurs", icon: Gauge },
  { href: "/cartographie", label: "Cartographie", icon: Map },
  { href: "/medias", label: "Medias", icon: Image },
  { href: "/gestionnaire", label: "Gestionnaire", icon: UserCog },
  { href: "/rapports", label: "Rapports", icon: FileText },
  { href: "/audit", label: "Audit Trail", icon: ClipboardList },
  { href: "/administration", label: "Administration", icon: Settings },
];

export function AppSidebar() {
  const pathname = usePathname();
  const [collapsed, setCollapsed] = useState(false);
  const { theme, toggleTheme } = useTheme();
  const router = useRouter();

  const handleLogout = async () => {
    await fetch("/api/auth/logout", { method: "POST" });
    localStorage.removeItem("ims-user");
    router.push("/login");
  };

  return (
    <aside
      className={cn(
        "fixed left-0 top-0 z-50 h-screen flex flex-col border-r border-sidebar-border bg-sidebar transition-all duration-300",
        collapsed ? "w-[72px]" : "w-[240px]"
      )}
    >
      {/* Logo */}
      <div className="flex items-center gap-3 px-3 py-4 border-b border-sidebar-border">
        <img
          src={theme === "dark" ? "/logo-ipd-dark.png" : "/logo-ipd-light.png"}
          alt="Institut Pasteur de Dakar"
          className={cn("flex-shrink-0 object-contain transition-all", collapsed ? "w-10 h-10" : "w-[180px] h-[48px]")}
        />
        {!collapsed && (
          <div className="overflow-hidden sr-only">
            <h1>Suivi des Partenariats</h1>
          </div>
        )}
      </div>
      {!collapsed && (
        <div className="px-4 py-2 border-b border-sidebar-border">
          <p className="text-[10px] font-semibold text-primary uppercase tracking-widest" style={{ fontFamily: "'Poppins', sans-serif" }}>
            Suivi des Partenariats
          </p>
        </div>
      )}

      {/* Navigation */}
      <nav className="flex-1 px-2 py-4 space-y-1 overflow-y-auto">
        {navItems.map((item) => {
          const isActive = pathname === item.href || pathname.startsWith(item.href + "/");
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all duration-200",
                isActive
                  ? "bg-sidebar-accent text-sidebar-primary font-semibold glow-cyan"
                  : "text-sidebar-foreground hover:bg-sidebar-accent/50 hover:text-sidebar-primary"
              )}
              title={collapsed ? item.label : undefined}
            >
              <item.icon className={cn("w-5 h-5 flex-shrink-0", isActive && "text-sidebar-primary")} />
              {!collapsed && <span className="truncate">{item.label}</span>}
            </Link>
          );
        })}
      </nav>

      {/* Bottom actions */}
      <div className="px-2 py-3 border-t border-sidebar-border space-y-1">
        <button
          onClick={toggleTheme}
          className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-sidebar-foreground hover:bg-sidebar-accent/50 w-full transition-colors"
          title={collapsed ? (theme === "dark" ? "Mode clair" : "Mode sombre") : undefined}
        >
          {theme === "dark" ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
          {!collapsed && <span>{theme === "dark" ? "Mode clair" : "Mode sombre"}</span>}
        </button>

        <button
          onClick={() => setCollapsed(!collapsed)}
          className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-sidebar-foreground hover:bg-sidebar-accent/50 w-full transition-colors"
        >
          {collapsed ? <ChevronRight className="w-5 h-5" /> : <ChevronLeft className="w-5 h-5" />}
          {!collapsed && <span>Reduire</span>}
        </button>

        <button
          onClick={handleLogout}
          className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-red-500 hover:bg-red-500/10 w-full transition-colors"
          title={collapsed ? "Deconnexion" : undefined}
        >
          <LogOut className="w-5 h-5" />
          {!collapsed && <span>Deconnexion</span>}
        </button>
      </div>

      {/* Status indicator */}
      <div className="px-4 py-3 border-t border-sidebar-border">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-emerald-500 pulse-dot" />
          {!collapsed && (
            <span className="text-[10px] text-muted-foreground">Systeme operationnel</span>
          )}
        </div>
      </div>
    </aside>
  );
}
