"use client";

import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { PILLAR_LABELS, DEPARTMENT_LIST } from "@/lib/utils";
import { Save, Loader2 } from "lucide-react";

const STATUS_OPTIONS = [
  "IDENTIFICATION", "CONTACT", "DISCUSSION", "ACCORD", "NEGOCIATION", "SIGNATURE", "ACTIF", "CLOTURE",
];

interface ProjectData {
  id: string;
  projectName: string;
  pillar: string;
  subPillar?: string | null;
  status: string;
  totalAmount: number;
  annualAmount: number;
  departmentLead?: string | null;
  divisionLead?: string | null;
  contractType?: string | null;
  objectives?: string | null;
  deliverables?: string | null;
  pastActivities?: string | null;
  upcomingActions?: string | null;
  duration?: string | null;
  budgetCode?: string | null;
}

export function EditProjectModal({
  project,
  open,
  onClose,
  onSaved,
}: {
  project: ProjectData;
  open: boolean;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [form, setForm] = useState({
    projectName: project.projectName,
    pillar: project.pillar,
    subPillar: project.subPillar || "",
    status: project.status,
    totalAmount: String(project.totalAmount / 1_000_000),
    annualAmount: String(project.annualAmount / 1_000_000),
    departmentLead: project.departmentLead || "",
    divisionLead: project.divisionLead || "",
    contractType: project.contractType || "",
    objectives: project.objectives || "",
    deliverables: project.deliverables || "",
    pastActivities: project.pastActivities || "",
    upcomingActions: project.upcomingActions || "",
    duration: project.duration || "",
    budgetCode: project.budgetCode || "",
  });
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    setSaving(true);
    try {
      await fetch(`/api/projects/${project.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          projectName: form.projectName,
          pillar: form.pillar,
          subPillar: form.subPillar || null,
          status: form.status,
          totalAmount: parseFloat(form.totalAmount) * 1_000_000 || 0,
          annualAmount: parseFloat(form.annualAmount) * 1_000_000 || 0,
          departmentLead: form.departmentLead || null,
          divisionLead: form.divisionLead || null,
          contractType: form.contractType || null,
          objectives: form.objectives || null,
          deliverables: form.deliverables || null,
          pastActivities: form.pastActivities || null,
          upcomingActions: form.upcomingActions || null,
          duration: form.duration || null,
          budgetCode: form.budgetCode || null,
        }),
      });
      onSaved();
      onClose();
    } catch {} finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Modifier le projet</DialogTitle>
        </DialogHeader>
        <div className="grid grid-cols-2 gap-4">
          <div className="col-span-2">
            <Label className="text-xs">Nom du projet</Label>
            <Input value={form.projectName} onChange={e => setForm(f => ({ ...f, projectName: e.target.value }))} className="mt-1" />
          </div>
          <div>
            <Label className="text-xs">Pilier strategique</Label>
            <Select value={form.pillar} onValueChange={v => setForm(f => ({ ...f, pillar: v || f.pillar }))}>
              <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
              <SelectContent>
                {Object.entries(PILLAR_LABELS).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-xs">Sous-pilier</Label>
            <Input value={form.subPillar} onChange={e => setForm(f => ({ ...f, subPillar: e.target.value }))} className="mt-1" />
          </div>
          <div>
            <Label className="text-xs">Statut</Label>
            <Select value={form.status} onValueChange={v => setForm(f => ({ ...f, status: v || f.status }))}>
              <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
              <SelectContent>
                {STATUS_OPTIONS.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-xs">Type contrat</Label>
            <Input value={form.contractType} onChange={e => setForm(f => ({ ...f, contractType: e.target.value }))} className="mt-1" />
          </div>
          <div>
            <Label className="text-xs">Montant total (M$)</Label>
            <Input type="number" step="0.1" value={form.totalAmount} onChange={e => setForm(f => ({ ...f, totalAmount: e.target.value }))} className="mt-1" />
          </div>
          <div>
            <Label className="text-xs">Montant annuel (M$)</Label>
            <Input type="number" step="0.1" value={form.annualAmount} onChange={e => setForm(f => ({ ...f, annualAmount: e.target.value }))} className="mt-1" />
          </div>
          <div>
            <Label className="text-xs">Departement lead</Label>
            <Select value={form.departmentLead} onValueChange={v => setForm(f => ({ ...f, departmentLead: v || "" }))}>
              <SelectTrigger className="mt-1"><SelectValue placeholder="Departement..." /></SelectTrigger>
              <SelectContent>
                {DEPARTMENT_LIST.map(d => <SelectItem key={d} value={d}>{d}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-xs">Division lead</Label>
            <Input value={form.divisionLead} onChange={e => setForm(f => ({ ...f, divisionLead: e.target.value }))} className="mt-1" />
          </div>
          <div>
            <Label className="text-xs">Duree</Label>
            <Input value={form.duration} onChange={e => setForm(f => ({ ...f, duration: e.target.value }))} className="mt-1" placeholder="3 ans" />
          </div>
          <div>
            <Label className="text-xs">Code budgetaire</Label>
            <Input value={form.budgetCode} onChange={e => setForm(f => ({ ...f, budgetCode: e.target.value }))} className="mt-1" />
          </div>
          <div className="col-span-2">
            <Label className="text-xs">Objectifs cles</Label>
            <Textarea value={form.objectives} onChange={e => setForm(f => ({ ...f, objectives: e.target.value }))} className="mt-1" rows={2} />
          </div>
          <div className="col-span-2">
            <Label className="text-xs">Livrables attendus</Label>
            <Textarea value={form.deliverables} onChange={e => setForm(f => ({ ...f, deliverables: e.target.value }))} className="mt-1" rows={2} />
          </div>
          <div className="col-span-2">
            <Label className="text-xs">Activites realisees</Label>
            <Textarea value={form.pastActivities} onChange={e => setForm(f => ({ ...f, pastActivities: e.target.value }))} className="mt-1" rows={2} />
          </div>
          <div className="col-span-2">
            <Label className="text-xs">Actions a venir</Label>
            <Textarea value={form.upcomingActions} onChange={e => setForm(f => ({ ...f, upcomingActions: e.target.value }))} className="mt-1" rows={2} />
          </div>
        </div>
        <div className="flex justify-end gap-2 mt-4">
          <Button variant="outline" onClick={onClose}>Annuler</Button>
          <Button onClick={handleSave} disabled={saving}>
            {saving ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
            Enregistrer
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
