"use client";

import { useEffect, useState, useMemo } from "react";
import Link from "next/link";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { formatCurrency, formatDate, PILLAR_COLORS, PILLAR_LABELS, STATUS_COLORS, DEPARTMENT_LIST } from "@/lib/utils";
import {
  Search, Building2, ArrowUpRight, FolderKanban, DollarSign, TrendingUp,
  Hourglass, Clock, CheckCircle2, AlertTriangle, Calendar, FileSignature, Network, MapPin,
} from "lucide-react";
import { SENEGAL_REGIONS, REGION_LABELS } from "@/lib/regions";

interface Project {
  id: string;
  streamId: string | null;
  projectName: string;
  status: string;
  pillar: string;
  totalAmount: number;
  annualAmount: number;
  maturationScore: number;
  departmentLead: string | null;
  divisionLead: string | null;
  contractType: string | null;
  regions: string | null;
  startDate: string | null;
  endDate: string | null;
  partner: { name: string; acronym: string | null; tier: string; type: string };
  risks: Array<{ criticality: string; status: string }>;
  milestones: Array<{ status: string }>;
  _count: { mediaFiles: number; monitoringEntries: number };
}

const AGE_BRACKETS = [
  { key: "ALL", label: "Toutes", min: -1, max: 9999 },
  { key: "0-6", label: "< 6 mois", min: 0, max: 5 },
  { key: "6-12", label: "6-12 mois", min: 6, max: 12 },
  { key: "12-24", label: "1-2 ans", min: 13, max: 24 },
  { key: "24-36", label: "2-3 ans", min: 25, max: 36 },
  { key: "36-60", label: "3-5 ans", min: 37, max: 60 },
  { key: "60+", label: "> 5 ans", min: 61, max: 9999 },
];

const STATUS_LABELS: Record<string, string> = {
  IDENTIFICATION: "Identification", CONTACT: "Contact", DISCUSSION: "Discussion",
  ACCORD: "Accord", NEGOCIATION: "Negociation", SIGNATURE: "Signature",
  ACTIF: "Actif", CLOTURE: "Cloture",
};

const TIER_LABELS: Record<string, string> = {
  TIER1: "Tier 1", TIER2: "Tier 2", TIER3: "Tier 3",
};

function getProjectAgeMonths(startDate: string | null): number | null {
  if (!startDate) return null;
  const now = new Date();
  const start = new Date(startDate);
  return Math.max(0, (now.getFullYear() - start.getFullYear()) * 12 + (now.getMonth() - start.getMonth()));
}

function formatAge(months: number | null): string {
  if (months === null) return "—";
  if (months < 1) return "< 1 mois";
  if (months < 12) return `${months} mois`;
  const years = months / 12;
  return years % 1 === 0 ? `${years} an${years > 1 ? "s" : ""}` : `${years.toFixed(1)} ans`;
}

function getAgeColor(months: number | null): string {
  if (months === null) return "text-muted-foreground";
  if (months <= 12) return "text-emerald-500";
  if (months <= 36) return "text-[#0089D0]";
  if (months <= 60) return "text-[#EF7A16]";
  return "text-red-500";
}

import { StatusToggle } from "@/components/ui/status-toggle";

export function ProjetsContent() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [search, setSearch] = useState("");
  const [filterPillar, setFilterPillar] = useState("ALL");
  const [filterDept, setFilterDept] = useState("ALL");
  const [filterStatus, setFilterStatus] = useState("ALL");
  const [statusToggle, setStatusToggle] = useState<"ALL" | "ACTIF" | "INACTIF">("ALL");
  const [filterTier, setFilterTier] = useState("ALL");
  const [filterAge, setFilterAge] = useState("ALL");
  const [filterContract, setFilterContract] = useState("ALL");
  const [filterDivision, setFilterDivision] = useState("ALL");
  const [filterRegion, setFilterRegion] = useState("ALL");

  useEffect(() => {
    fetch("/api/projects").then(r => r.json()).then(setProjects);
  }, []);

  // Extract unique contract types and divisions for filter dropdowns
  const contractTypes = useMemo(() => {
    const set = new Set<string>();
    projects.forEach(p => { if (p.contractType) set.add(p.contractType); });
    return Array.from(set).sort();
  }, [projects]);

  const divisions = useMemo(() => {
    const set = new Set<string>();
    projects.forEach(p => { if (p.divisionLead) set.add(p.divisionLead); });
    return Array.from(set).sort();
  }, [projects]);

  // Enrich projects with age
  const enriched = useMemo(() => {
    return projects.map(p => ({
      ...p,
      ageMonths: getProjectAgeMonths(p.startDate),
    }));
  }, [projects]);

  // Filter
  const filtered = useMemo(() => {
    return enriched.filter(p => {
      if (search) {
        const s = search.toLowerCase();
        if (
          !p.projectName.toLowerCase().includes(s) &&
          !(p.partner.acronym || p.partner.name).toLowerCase().includes(s) &&
          !(p.streamId || "").toLowerCase().includes(s)
        ) return false;
      }
      if (statusToggle === "ACTIF" && p.status !== "ACTIF") return false;
      if (statusToggle === "INACTIF" && p.status === "ACTIF") return false;
      if (filterPillar !== "ALL" && p.pillar !== filterPillar) return false;
      if (filterDept !== "ALL" && p.departmentLead !== filterDept) return false;
      if (filterStatus !== "ALL" && p.status !== filterStatus) return false;
      if (filterTier !== "ALL" && p.partner.tier !== filterTier) return false;
      if (filterContract !== "ALL" && p.contractType !== filterContract) return false;
      if (filterDivision !== "ALL" && p.divisionLead !== filterDivision) return false;
      if (filterRegion !== "ALL" && !(p.regions || "").split(",").includes(filterRegion)) return false;
      if (filterAge !== "ALL") {
        const bracket = AGE_BRACKETS.find(b => b.key === filterAge);
        if (bracket) {
          if (p.ageMonths === null) return false;
          if (p.ageMonths < bracket.min || p.ageMonths > bracket.max) return false;
        }
      }
      return true;
    });
  }, [enriched, search, filterPillar, filterDept, filterStatus, filterTier, filterAge, filterContract, filterDivision, filterRegion, statusToggle]);

  // Dynamic KPIs computed from filtered results
  const kpis = useMemo(() => {
    const total = filtered.length;
    const active = filtered.filter(p => p.status === "ACTIF").length;
    const prospection = filtered.filter(p => ["IDENTIFICATION", "CONTACT", "DISCUSSION", "ACCORD", "NEGOCIATION", "SIGNATURE"].includes(p.status)).length;
    const totalAmount = filtered.reduce((s, p) => s + p.totalAmount, 0);
    const avgAmount = total > 0 ? totalAmount / total : 0;

    // Age stats
    const withAge = filtered.filter(p => p.ageMonths !== null);
    const avgAge = withAge.length > 0
      ? Math.round(withAge.reduce((s, p) => s + p.ageMonths!, 0) / withAge.length)
      : null;
    const medianAge = withAge.length > 0
      ? (() => {
          const sorted = [...withAge].sort((a, b) => a.ageMonths! - b.ageMonths!);
          const mid = Math.floor(sorted.length / 2);
          return sorted.length % 2 ? sorted[mid].ageMonths! : Math.round((sorted[mid - 1].ageMonths! + sorted[mid].ageMonths!) / 2);
        })()
      : null;

    // Risks
    const highRisks = filtered.reduce((s, p) => s + p.risks.filter(r => r.criticality === "HIGH" && r.status === "OPEN").length, 0);

    // Milestones
    const milestonesTotal = filtered.reduce((s, p) => s + p.milestones.length, 0);
    const milestonesApproved = filtered.reduce((s, p) => s + p.milestones.filter(m => m.status === "L3_APPROVED").length, 0);

    // Partners count
    const uniquePartners = new Set(filtered.map(p => p.partner.name)).size;

    // Pillar breakdown
    const byPillar: Record<string, number> = {};
    filtered.forEach(p => { byPillar[p.pillar] = (byPillar[p.pillar] || 0) + 1; });

    return {
      total, active, prospection, totalAmount, avgAmount,
      avgAge, medianAge, highRisks, milestonesTotal, milestonesApproved,
      uniquePartners, byPillar,
    };
  }, [filtered]);

  // Count by age bracket for badge display
  const ageCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    AGE_BRACKETS.forEach(b => {
      if (b.key === "ALL") return;
      counts[b.key] = enriched.filter(p => {
        if (p.ageMonths === null) return false;
        return p.ageMonths >= b.min && p.ageMonths <= b.max;
      }).length;
    });
    return counts;
  }, [enriched]);

  const hasActiveFilters = filterPillar !== "ALL" || filterDept !== "ALL" || filterStatus !== "ALL" || filterTier !== "ALL" || filterAge !== "ALL" || filterContract !== "ALL" || filterDivision !== "ALL" || filterRegion !== "ALL" || statusToggle !== "ALL" || search;

  return (
    <div className="space-y-5">
      {/* Status Toggle */}
      <StatusToggle value={statusToggle} onChange={setStatusToggle} />

      {/* ── KPI Cards (reactive to filters) ── */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-3">
        {[
          { label: "Projets", value: kpis.total, icon: FolderKanban, color: "#0089D0" },
          { label: "Actifs", value: kpis.active, icon: CheckCircle2, color: "#10b981" },
          { label: "Prospection", value: kpis.prospection, icon: TrendingUp, color: "#8b5cf6" },
          { label: "Partenaires", value: kpis.uniquePartners, icon: Building2, color: "#EF7A16" },
          { label: "Volume Total", value: formatCurrency(kpis.totalAmount), icon: DollarSign, color: "#0089D0", small: true },
          { label: "Moy./Projet", value: formatCurrency(kpis.avgAmount), icon: DollarSign, color: "#FFD500", small: true },
          { label: "Age Moyen", value: formatAge(kpis.avgAge), icon: Hourglass, color: "#8b5cf6" },
          { label: "Risques Eleves", value: kpis.highRisks, icon: AlertTriangle, color: kpis.highRisks > 0 ? "#ef4444" : "#10b981" },
        ].map((kpi, i) => (
          <Card key={i} className="glass p-3 animate-fade-up" style={{ animationDelay: `${i * 0.03}s` }}>
            <div className="flex items-center gap-2 mb-1">
              <kpi.icon className="w-3.5 h-3.5 flex-shrink-0" style={{ color: kpi.color }} />
              <span className="text-[9px] text-muted-foreground uppercase tracking-wider truncate">{kpi.label}</span>
            </div>
            <p className={`${kpi.small ? "text-sm" : "text-lg"} font-bold truncate`} style={{ fontFamily: "'Poppins', sans-serif", color: kpi.color }}>
              {kpi.value}
            </p>
          </Card>
        ))}
      </div>

      {/* Pillar mini-bar (reactive) */}
      {Object.keys(kpis.byPillar).length > 0 && (
        <div className="flex gap-1 h-2.5 rounded-full overflow-hidden">
          {Object.entries(kpis.byPillar).map(([pillar, count]) => (
            <div
              key={pillar}
              className="h-full rounded-full transition-all duration-500"
              style={{
                backgroundColor: PILLAR_COLORS[pillar] || "#6b7280",
                width: `${(count / kpis.total) * 100}%`,
              }}
              title={`${PILLAR_LABELS[pillar]}: ${count} projets`}
            />
          ))}
        </div>
      )}

      {/* ── Filters ── */}
      <div className="flex flex-wrap gap-2.5 items-center">
        <div className="relative flex-1 min-w-[200px] max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Rechercher projet, partenaire, flux..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9 glass"
          />
        </div>
        <Select value={filterPillar} onValueChange={(v) => setFilterPillar(v || "ALL")}>
          <SelectTrigger className="w-[165px] glass"><SelectValue placeholder="Pilier" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="ALL">Tous les piliers</SelectItem>
            {Object.entries(PILLAR_LABELS).map(([k, v]) => (
              <SelectItem key={k} value={k}>{v}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={filterDept} onValueChange={(v) => setFilterDept(v || "ALL")}>
          <SelectTrigger className="w-[140px] glass"><SelectValue placeholder="Dept" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="ALL">Tous depts</SelectItem>
            {DEPARTMENT_LIST.map(d => <SelectItem key={d} value={d}>{d}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={filterStatus} onValueChange={(v) => setFilterStatus(v || "ALL")}>
          <SelectTrigger className="w-[140px] glass"><SelectValue placeholder="Statut" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="ALL">Tous statuts</SelectItem>
            {Object.entries(STATUS_LABELS).map(([k, v]) => (
              <SelectItem key={k} value={k}>{v}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={filterTier} onValueChange={(v) => setFilterTier(v || "ALL")}>
          <SelectTrigger className="w-[120px] glass"><SelectValue placeholder="Tier" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="ALL">Tous tiers</SelectItem>
            {Object.entries(TIER_LABELS).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={filterContract} onValueChange={(v) => setFilterContract(v || "ALL")}>
          <SelectTrigger className="w-[160px] glass">
            <FileSignature className="w-3.5 h-3.5 mr-1.5 text-[#0089D0]" />
            <SelectValue placeholder="Contrat" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="ALL">Tous contrats</SelectItem>
            {contractTypes.map(ct => <SelectItem key={ct} value={ct}>{ct}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={filterDivision} onValueChange={(v) => setFilterDivision(v || "ALL")}>
          <SelectTrigger className="w-[150px] glass">
            <Network className="w-3.5 h-3.5 mr-1.5 text-[#8b5cf6]" />
            <SelectValue placeholder="Division" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="ALL">Toutes divisions</SelectItem>
            {divisions.map(d => <SelectItem key={d} value={d}>{d}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={filterRegion} onValueChange={(v) => setFilterRegion(v || "ALL")}>
          <SelectTrigger className="w-[150px] glass">
            <MapPin className="w-3.5 h-3.5 mr-1.5 text-[#10b981]" />
            <SelectValue placeholder="Region" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="ALL">Toutes regions</SelectItem>
            {SENEGAL_REGIONS.map(r => <SelectItem key={r.code} value={r.code}>{r.name}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={filterAge} onValueChange={(v) => setFilterAge(v || "ALL")}>
          <SelectTrigger className="w-[145px] glass">
            <Hourglass className="w-3.5 h-3.5 mr-1.5 text-[#EF7A16]" />
            <SelectValue placeholder="Age" />
          </SelectTrigger>
          <SelectContent>
            {AGE_BRACKETS.map(b => (
              <SelectItem key={b.key} value={b.key}>
                {b.label}{b.key !== "ALL" && ageCounts[b.key] !== undefined ? ` (${ageCounts[b.key]})` : ""}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        {hasActiveFilters && (
          <button
            onClick={() => { setSearch(""); setFilterPillar("ALL"); setFilterDept("ALL"); setFilterStatus("ALL"); setFilterTier("ALL"); setFilterAge("ALL"); setFilterContract("ALL"); setFilterDivision("ALL"); setFilterRegion("ALL"); setStatusToggle("ALL"); }}
            className="text-[10px] text-primary hover:underline"
          >
            Reinitialiser
          </button>
        )}
      </div>

      {/* ── Project Grid ── */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {filtered.map((project, i) => (
          <Link key={project.id} href={`/projets/${project.id}`}>
            <Card className="glass p-5 hover:glow-cyan transition-all duration-300 cursor-pointer group animate-fade-up h-full" style={{ animationDelay: `${Math.min(i, 30) * 0.02}s` }}>
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-bold truncate group-hover:text-[#0089D0] transition-colors" style={{ fontFamily: "'Poppins', sans-serif" }}>
                    {project.projectName}
                  </p>
                  <div className="flex items-center gap-1 mt-1">
                    <Building2 className="w-3 h-3 text-muted-foreground" />
                    <span className="text-xs text-muted-foreground">{project.partner.acronym || project.partner.name}</span>
                  </div>
                </div>
                <ArrowUpRight className="w-4 h-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity flex-shrink-0" />
              </div>

              <div className="flex flex-wrap gap-1.5 mb-3">
                <Badge variant="outline" className="text-[10px]" style={{ borderColor: PILLAR_COLORS[project.pillar], color: PILLAR_COLORS[project.pillar] }}>
                  {PILLAR_LABELS[project.pillar]}
                </Badge>
                <Badge variant="outline" className="text-[10px]" style={{ borderColor: STATUS_COLORS[project.status], color: STATUS_COLORS[project.status] }}>
                  {STATUS_LABELS[project.status] || project.status}
                </Badge>
                {project.departmentLead && (
                  <Badge variant="secondary" className="text-[10px]">{project.departmentLead}</Badge>
                )}
                {project.contractType && (
                  <Badge variant="secondary" className="text-[10px]">{project.contractType}</Badge>
                )}
              </div>

              <div className="grid grid-cols-3 gap-2 text-xs">
                <div>
                  <span className="text-muted-foreground">Montant</span>
                  <p className="font-semibold text-[#0089D0]">{formatCurrency(project.totalAmount)}</p>
                </div>
                <div>
                  <span className="text-muted-foreground">Tier</span>
                  <p className="font-medium">{project.partner.tier.replace("TIER", "T")}</p>
                </div>
                <div>
                  <span className="text-muted-foreground flex items-center gap-0.5">
                    <Hourglass className="w-3 h-3" /> Age
                  </span>
                  <p className={`font-semibold ${getAgeColor(project.ageMonths)}`}>
                    {formatAge(project.ageMonths)}
                  </p>
                </div>
              </div>

              {/* Regions */}
              {project.regions && (
                <div className="flex items-center gap-1 mt-2 flex-wrap">
                  <MapPin className="w-3 h-3 text-emerald-500 flex-shrink-0" />
                  {project.regions.split(",").slice(0, 4).map(r => (
                    <span key={r} className="text-[9px] px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">
                      {REGION_LABELS[r] || r}
                    </span>
                  ))}
                  {project.regions.split(",").length > 4 && (
                    <span className="text-[9px] text-muted-foreground">+{project.regions.split(",").length - 4}</span>
                  )}
                </div>
              )}

              {/* Date bar */}
              {project.startDate && (
                <div className="flex items-center gap-1.5 mt-2.5 text-[10px] text-muted-foreground">
                  <Calendar className="w-3 h-3" />
                  <span>{formatDate(project.startDate)}</span>
                  {project.endDate && (
                    <>
                      <span>→</span>
                      <span>{formatDate(project.endDate)}</span>
                    </>
                  )}
                </div>
              )}
            </Card>
          </Link>
        ))}
      </div>

      {filtered.length === 0 && (
        <Card className="glass p-12 text-center">
          <FolderKanban className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
          <p className="text-sm text-muted-foreground">Aucun projet ne correspond aux filtres</p>
          <button
            onClick={() => { setSearch(""); setFilterPillar("ALL"); setFilterDept("ALL"); setFilterStatus("ALL"); setFilterTier("ALL"); setFilterAge("ALL"); setFilterContract("ALL"); setFilterDivision("ALL"); setFilterRegion("ALL"); setStatusToggle("ALL"); }}
            className="text-sm text-primary hover:underline mt-2"
          >
            Reinitialiser les filtres
          </button>
        </Card>
      )}
    </div>
  );
}
