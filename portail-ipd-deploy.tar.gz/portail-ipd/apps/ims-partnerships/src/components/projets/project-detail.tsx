"use client";

import { useEffect, useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { formatCurrency, formatDate, PILLAR_COLORS, PILLAR_LABELS } from "@/lib/utils";
import { Building2, Calendar, DollarSign, Target, Users, AlertTriangle, CheckCircle2, Clock, FileText, MessageSquare } from "lucide-react";

interface ProjectData {
  id: string;
  streamId: string | null;
  projectName: string;
  status: string;
  pillar: string;
  subPillar: string | null;
  contractType: string | null;
  totalAmount: number;
  annualAmount: number;
  maturationScore: number;
  departmentLead: string | null;
  divisionLead: string | null;
  signatureYear: number | null;
  duration: string | null;
  startDate: string | null;
  endDate: string | null;
  grantType: string | null;
  grantLink: string | null;
  budgetCode: string | null;
  objectives: string | null;
  deliverables: string | null;
  pastActivities: string | null;
  upcomingActions: string | null;
  hasFeasibilityStudy: boolean;
  hasImpactAssessment: boolean;
  hasFinancialStructure: boolean;
  hasIntentionLetter: boolean;
  hasLegalValidation: boolean;
  hasPillarConformity: boolean;
  partner: { name: string; acronym: string | null; type: string; tier: string; country: string };
  contacts: Array<{ id: string; role: string; name: string; email: string | null; telephone: string | null }>;
  milestones: Array<{ id: string; title: string; dueDate: string; status: string; comments: string | null }>;
  risks: Array<{ id: string; description: string; mitigationActions: string | null; criticality: string; status: string }>;
  monitoringEntries: Array<{ id: string; period: string; periodType: string; physicalRate: number; financialRate: number; observations: string | null; validationStatus: string; author: { name: string } | null }>;
  prospectionNotes: Array<{ id: string; type: string; content: string; date: string; author: { name: string } | null }>;
  mediaFiles: Array<{ id: string; type: string; fileName: string; filePath: string; uploadedAt: string }>;
}

export function ProjectDetail({ projectId }: { projectId: string }) {
  const [project, setProject] = useState<ProjectData | null>(null);

  useEffect(() => {
    fetch(`/api/projects/${projectId}`).then(r => r.json()).then(setProject);
  }, [projectId]);

  if (!project) {
    return <div className="space-y-4">{[...Array(3)].map((_, i) => <Card key={i} className="glass p-6 animate-pulse h-48" />)}</div>;
  }

  const milestoneStatusIcons: Record<string, React.ReactNode> = {
    PENDING: <Clock className="w-4 h-4 text-muted-foreground" />,
    L1_VALIDATED: <CheckCircle2 className="w-4 h-4 text-blue-500" />,
    L2_VALIDATED: <CheckCircle2 className="w-4 h-4 text-[#EF7A16]" />,
    L3_APPROVED: <CheckCircle2 className="w-4 h-4 text-emerald-500" />,
    REJECTED: <AlertTriangle className="w-4 h-4 text-red-500" />,
  };

  const riskColors: Record<string, string> = { HIGH: "text-red-500 bg-red-500/10", MEDIUM: "text-[#EF7A16] bg-[#EF7A16]/10", LOW: "text-emerald-500 bg-emerald-500/10" };

  return (
    <div className="space-y-6">
      {/* Header Card */}
      <Card className="glass p-6 glow-cyan">
        <div className="flex items-start justify-between mb-4">
          <div>
            <h2 className="text-xl font-bold" style={{ fontFamily: "'Poppins', sans-serif" }}>{project.projectName}</h2>
            <div className="flex items-center gap-2 mt-1">
              <Building2 className="w-4 h-4 text-muted-foreground" />
              <span className="text-sm text-muted-foreground">{project.partner.name} ({project.partner.acronym})</span>
              <span className="text-xs text-muted-foreground">| {project.partner.country}</span>
            </div>
          </div>
          <div className="text-right">
            <div className="text-2xl font-bold text-[#0089D0]" style={{ fontFamily: "'Poppins', sans-serif" }}>{formatCurrency(project.totalAmount)}</div>
            <p className="text-xs text-muted-foreground">Annuel: {formatCurrency(project.annualAmount)}</p>
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          <Badge style={{ backgroundColor: PILLAR_COLORS[project.pillar], color: "#fff" }}>{PILLAR_LABELS[project.pillar]}</Badge>
          <Badge variant="outline">{project.status}</Badge>
          <Badge variant="secondary">{project.departmentLead}</Badge>
          <Badge variant="secondary">{project.partner.tier.replace("TIER", "Tier ")}</Badge>
          {project.contractType && <Badge variant="outline">{project.contractType}</Badge>}
          {project.streamId && <Badge variant="outline">{project.streamId}</Badge>}
        </div>
      </Card>

      <Tabs defaultValue="info" className="space-y-4">
        <TabsList className="glass">
          <TabsTrigger value="info">Informations</TabsTrigger>
          <TabsTrigger value="monitoring">Suivi</TabsTrigger>
          <TabsTrigger value="milestones">Jalons ({project.milestones.length})</TabsTrigger>
          <TabsTrigger value="risks">Risques ({project.risks.length})</TabsTrigger>
          <TabsTrigger value="contacts">Contacts ({project.contacts.length})</TabsTrigger>
          <TabsTrigger value="notes">Notes ({project.prospectionNotes.length})</TabsTrigger>
        </TabsList>

        {/* Informations Tab */}
        <TabsContent value="info">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="glass p-5">
              <h3 className="text-sm font-semibold mb-3" style={{ fontFamily: "'Poppins', sans-serif" }}>Objectifs & Progression</h3>
              {project.objectives && <div className="mb-3"><p className="text-xs text-muted-foreground mb-1">Objectifs</p><p className="text-sm">{project.objectives}</p></div>}
              {project.deliverables && <div className="mb-3"><p className="text-xs text-muted-foreground mb-1">Livrables</p><p className="text-sm">{project.deliverables}</p></div>}
              {project.pastActivities && <div className="mb-3"><p className="text-xs text-muted-foreground mb-1">Activites passees</p><p className="text-sm">{project.pastActivities}</p></div>}
              {project.upcomingActions && <div><p className="text-xs text-muted-foreground mb-1">Actions a venir</p><p className="text-sm">{project.upcomingActions}</p></div>}
            </Card>
            <Card className="glass p-5">
              <h3 className="text-sm font-semibold mb-3" style={{ fontFamily: "'Poppins', sans-serif" }}>Duree & Finances</h3>
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div><p className="text-xs text-muted-foreground">Annee signature</p><p className="font-medium">{project.signatureYear || "—"}</p></div>
                <div><p className="text-xs text-muted-foreground">Duree</p><p className="font-medium">{project.duration || "—"}</p></div>
                <div><p className="text-xs text-muted-foreground">Debut</p><p className="font-medium">{formatDate(project.startDate)}</p></div>
                <div><p className="text-xs text-muted-foreground">Fin</p><p className="font-medium">{formatDate(project.endDate)}</p></div>
                <div><p className="text-xs text-muted-foreground">Type subvention</p><p className="font-medium">{project.grantType || "—"}</p></div>
                <div><p className="text-xs text-muted-foreground">Code budgetaire</p><p className="font-medium">{project.budgetCode || "—"}</p></div>
              </div>
              <div className="mt-4">
                <h4 className="text-xs text-muted-foreground mb-2">Score de Maturation</h4>
                <div className="flex items-center gap-3">
                  <Progress value={project.maturationScore} className="h-3 flex-1" />
                  <span className="text-sm font-bold">{project.maturationScore}%</span>
                </div>
                <div className="grid grid-cols-2 gap-1 mt-2 text-xs">
                  {[
                    { label: "Faisabilite (20pts)", checked: project.hasFeasibilityStudy },
                    { label: "Impact env. (15pts)", checked: project.hasImpactAssessment },
                    { label: "Structure fin. (25pts)", checked: project.hasFinancialStructure },
                    { label: "Lettre intention (15pts)", checked: project.hasIntentionLetter },
                    { label: "Valid. juridique (15pts)", checked: project.hasLegalValidation },
                    { label: "Conformite piliers (10pts)", checked: project.hasPillarConformity },
                  ].map((c, i) => (
                    <div key={i} className="flex items-center gap-1">
                      <div className={`w-2 h-2 rounded-full ${c.checked ? "bg-emerald-500" : "bg-muted-foreground/30"}`} />
                      <span className={c.checked ? "" : "text-muted-foreground"}>{c.label}</span>
                    </div>
                  ))}
                </div>
              </div>
            </Card>
          </div>
        </TabsContent>

        {/* Monitoring Tab */}
        <TabsContent value="monitoring">
          <Card className="glass p-5">
            <h3 className="text-sm font-semibold mb-4" style={{ fontFamily: "'Poppins', sans-serif" }}>Suivi Periodique</h3>
            {project.monitoringEntries.length === 0 ? (
              <p className="text-sm text-muted-foreground">Aucune entree de suivi</p>
            ) : (
              <div className="space-y-3">
                {project.monitoringEntries.map(m => (
                  <div key={m.id} className="glass p-4 rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <Badge variant="outline">{m.period} ({m.periodType})</Badge>
                      <Badge variant={m.validationStatus === "L3_APPROVED" ? "default" : "secondary"}>{m.validationStatus}</Badge>
                    </div>
                    <div className="grid grid-cols-2 gap-3 mb-2">
                      <div>
                        <div className="flex justify-between text-xs mb-1">
                          <span className="text-muted-foreground">Physique</span>
                          <span>{m.physicalRate}%</span>
                        </div>
                        <Progress value={m.physicalRate} className="h-2" />
                      </div>
                      <div>
                        <div className="flex justify-between text-xs mb-1">
                          <span className="text-muted-foreground">Financier</span>
                          <span>{m.financialRate}%</span>
                        </div>
                        <Progress value={m.financialRate} className="h-2" />
                      </div>
                    </div>
                    {m.observations && <p className="text-xs text-muted-foreground">{m.observations}</p>}
                    {m.author && <p className="text-[10px] text-muted-foreground mt-1">Par {m.author.name}</p>}
                  </div>
                ))}
              </div>
            )}
          </Card>
        </TabsContent>

        {/* Milestones Tab */}
        <TabsContent value="milestones">
          <Card className="glass p-5">
            <h3 className="text-sm font-semibold mb-4" style={{ fontFamily: "'Poppins', sans-serif" }}>Jalons et Livrables</h3>
            <div className="space-y-3">
              {project.milestones.map(m => (
                <div key={m.id} className="flex items-start gap-3 glass p-3 rounded-lg">
                  {milestoneStatusIcons[m.status]}
                  <div className="flex-1">
                    <p className="text-sm font-medium">{m.title}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <Calendar className="w-3 h-3 text-muted-foreground" />
                      <span className="text-xs text-muted-foreground">{formatDate(m.dueDate)}</span>
                      <Badge variant="outline" className="text-[10px]">{m.status.replace(/_/g, " ")}</Badge>
                    </div>
                    {m.comments && <p className="text-xs text-muted-foreground mt-1">{m.comments}</p>}
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </TabsContent>

        {/* Risks Tab */}
        <TabsContent value="risks">
          <Card className="glass p-5">
            <h3 className="text-sm font-semibold mb-4" style={{ fontFamily: "'Poppins', sans-serif" }}>Registre des Risques</h3>
            <div className="space-y-3">
              {project.risks.map(r => (
                <div key={r.id} className="glass p-3 rounded-lg">
                  <div className="flex items-start gap-2">
                    <AlertTriangle className={`w-4 h-4 mt-0.5 ${r.criticality === "HIGH" ? "text-red-500" : r.criticality === "MEDIUM" ? "text-[#EF7A16]" : "text-emerald-500"}`} />
                    <div className="flex-1">
                      <p className="text-sm">{r.description}</p>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge className={`text-[10px] ${riskColors[r.criticality]}`}>{r.criticality}</Badge>
                        <Badge variant="outline" className="text-[10px]">{r.status}</Badge>
                      </div>
                      {r.mitigationActions && <p className="text-xs text-muted-foreground mt-2"><strong>Attenuation:</strong> {r.mitigationActions}</p>}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </TabsContent>

        {/* Contacts Tab */}
        <TabsContent value="contacts">
          <Card className="glass p-5">
            <h3 className="text-sm font-semibold mb-4" style={{ fontFamily: "'Poppins', sans-serif" }}>Contacts Cles</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {project.contacts.map(c => (
                <div key={c.id} className="glass p-3 rounded-lg flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                    <Users className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <p className="text-sm font-medium">{c.name}</p>
                    <Badge variant="outline" className="text-[10px]">{c.role.replace(/_/g, " ")}</Badge>
                    {c.email && <p className="text-xs text-muted-foreground mt-0.5">{c.email}</p>}
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </TabsContent>

        {/* Notes Tab */}
        <TabsContent value="notes">
          <Card className="glass p-5">
            <h3 className="text-sm font-semibold mb-4" style={{ fontFamily: "'Poppins', sans-serif" }}>Notes de Prospection</h3>
            <div className="space-y-3">
              {project.prospectionNotes.map(n => (
                <div key={n.id} className="glass p-3 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <MessageSquare className="w-4 h-4 text-muted-foreground" />
                    <Badge variant="outline" className="text-[10px]">{n.type}</Badge>
                    <span className="text-xs text-muted-foreground">{formatDate(n.date)}</span>
                    {n.author && <span className="text-xs text-muted-foreground ml-auto">{n.author.name}</span>}
                  </div>
                  <p className="text-sm">{n.content}</p>
                </div>
              ))}
            </div>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
