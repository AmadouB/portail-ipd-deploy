"use client";

import { useEffect, useState, useMemo } from "react";
import Link from "next/link";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { formatCurrency, formatDate, PILLAR_COLORS, PILLAR_LABELS, DEPARTMENT_LIST } from "@/lib/utils";
import { SENEGAL_REGIONS, REGION_LABELS } from "@/lib/regions";
import {
  LayoutDashboard, FolderKanban, TrendingUp, Target, Shield, Building2,
  DollarSign, CheckCircle2, AlertTriangle, Clock, Calendar, Send, MapPin,
  ArrowUpRight, ChevronRight, Upload, Hourglass, Gauge, Save,
  GripVertical, FileText, Users, Eye, EyeOff,
} from "lucide-react";
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, LabelList } from "recharts";

interface Project {
  id: string;
  streamId: string | null;
  projectName: string;
  pillar: string;
  status: string;
  totalAmount: number;
  annualAmount: number;
  maturationScore: number;
  departmentLead: string | null;
  contractType: string | null;
  regions: string | null;
  startDate: string | null;
  endDate: string | null;
  objectives: string | null;
  pastActivities: string | null;
  upcomingActions: string | null;
  partner: { name: string; acronym: string | null; tier: string };
  risks: Array<{ id: string; description: string; criticality: string; mitigationActions: string | null; status: string }>;
  milestones: Array<{ id: string; title: string; status: string; dueDate: string }>;
  monitoringEntries: Array<{ id: string; period: string; physicalRate: number; financialRate: number; validationStatus: string; observations: string | null }>;
  _count: { mediaFiles: number; monitoringEntries: number };
}

const VALIDATION_STATUS: Record<string, { label: string; color: string; icon: typeof Clock }> = {
  DRAFT: { label: "Brouillon", color: "#6b7280", icon: Clock },
  L1_VALIDATED: { label: "L1 — Charge de suivi", color: "#0089D0", icon: CheckCircle2 },
  L2_VALIDATED: { label: "L2 — Resp. departemental", color: "#EF7A16", icon: CheckCircle2 },
  L3_APPROVED: { label: "L3 — Direction UVFJ", color: "#10b981", icon: CheckCircle2 },
};

const STATUS_LABELS: Record<string, string> = {
  IDENTIFICATION: "Identification", CONTACT: "Contact", DISCUSSION: "Discussion",
  ACCORD: "Accord", NEGOCIATION: "Negociation", SIGNATURE: "Signature",
  ACTIF: "Actif", CLOTURE: "Cloture",
};

export function GestionnaireContent() {
  const [allProjects, setAllProjects] = useState<Project[]>([]);
  const [department, setDepartment] = useState("DOI");
  const [activeTab, setActiveTab] = useState("dashboard");
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [saving, setSaving] = useState(false);
  const [success, setSuccess] = useState("");

  // Monitoring form
  const [monForm, setMonForm] = useState({ period: "", periodType: "QUARTERLY", physicalRate: "", financialRate: "", physicalTarget: "", financialTarget: "", observations: "" });

  // Risk form
  const [riskForm, setRiskForm] = useState({ description: "", mitigationActions: "", criticality: "MEDIUM" });

  useEffect(() => {
    fetch("/api/projects").then(r => r.json()).then(setAllProjects);
  }, []);

  // Projects for selected department
  const deptProjects = useMemo(() =>
    allProjects.filter(p => p.departmentLead === department),
  [allProjects, department]);

  const activeProjects = deptProjects.filter(p => p.status === "ACTIF");
  const prospectionProjects = deptProjects.filter(p => ["IDENTIFICATION", "CONTACT", "DISCUSSION", "ACCORD", "NEGOCIATION", "SIGNATURE"].includes(p.status));

  // KPIs
  const kpis = useMemo(() => {
    const total = deptProjects.length;
    const active = activeProjects.length;
    const prospection = prospectionProjects.length;
    const totalAmount = deptProjects.reduce((s, p) => s + p.totalAmount, 0);
    const highRisks = deptProjects.reduce((s, p) => s + p.risks.filter(r => r.criticality === "HIGH" && r.status === "OPEN").length, 0);
    const milestonesTotal = deptProjects.reduce((s, p) => s + p.milestones.length, 0);
    const milestonesApproved = deptProjects.reduce((s, p) => s + p.milestones.filter(m => m.status === "L3_APPROVED").length, 0);
    const latestMonitoring = activeProjects.filter(p => p.monitoringEntries.length > 0).map(p => p.monitoringEntries[0]);
    const avgPhysical = latestMonitoring.length > 0 ? Math.round(latestMonitoring.reduce((s, m) => s + m.physicalRate, 0) / latestMonitoring.length) : 0;
    const avgFinancial = latestMonitoring.length > 0 ? Math.round(latestMonitoring.reduce((s, m) => s + m.financialRate, 0) / latestMonitoring.length) : 0;

    const byPillar: Record<string, number> = {};
    deptProjects.forEach(p => { byPillar[p.pillar] = (byPillar[p.pillar] || 0) + 1; });

    const byStatus: Record<string, number> = {};
    deptProjects.forEach(p => { byStatus[p.status] = (byStatus[p.status] || 0) + 1; });

    const byRegion: Record<string, number> = {};
    deptProjects.forEach(p => {
      if (p.regions) p.regions.split(",").forEach(r => { byRegion[r] = (byRegion[r] || 0) + 1; });
    });

    return { total, active, prospection, totalAmount, highRisks, milestonesTotal, milestonesApproved, avgPhysical, avgFinancial, byPillar, byStatus, byRegion };
  }, [deptProjects, activeProjects, prospectionProjects]);

  const selectProject = (project: Project) => {
    setSelectedProject(project);
    setSuccess("");
    const now = new Date();
    const q = Math.ceil((now.getMonth() + 1) / 3);
    setMonForm({ period: `${now.getFullYear()}-Q${q}`, periodType: "QUARTERLY", physicalRate: "", financialRate: "", physicalTarget: "", financialTarget: "", observations: "" });
    setRiskForm({ description: "", mitigationActions: "", criticality: "MEDIUM" });
  };

  const submitMonitoring = async () => {
    if (!selectedProject || !monForm.period) return;
    setSaving(true);
    try {
      await fetch(`/api/projects/${selectedProject.id}/monitoring`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...monForm, physicalRate: parseFloat(monForm.physicalRate) || 0, financialRate: parseFloat(monForm.financialRate) || 0, physicalTarget: parseFloat(monForm.physicalTarget) || 0, financialTarget: parseFloat(monForm.financialTarget) || 0, observations: monForm.observations || null }),
      });
      setSuccess("Fiche de suivi enregistree !");
      const updated = await fetch("/api/projects").then(r => r.json());
      setAllProjects(updated);
    } catch {} finally { setSaving(false); }
  };

  const submitRisk = async () => {
    if (!selectedProject || !riskForm.description) return;
    setSaving(true);
    try {
      await fetch(`/api/projects/${selectedProject.id}/risks`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify(riskForm),
      });
      setSuccess("Probleme/risque enregistre !");
      setRiskForm({ description: "", mitigationActions: "", criticality: "MEDIUM" });
      const updated = await fetch("/api/projects").then(r => r.json());
      setAllProjects(updated);
    } catch {} finally { setSaving(false); }
  };

  const submitProjectUpdate = async (field: string, value: string) => {
    if (!selectedProject) return;
    setSaving(true);
    try {
      await fetch(`/api/projects/${selectedProject.id}`, {
        method: "PUT", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ [field]: value }),
      });
      setSuccess(`Champ "${field}" mis a jour !`);
      const updated = await fetch("/api/projects").then(r => r.json());
      setAllProjects(updated);
    } catch {} finally { setSaving(false); }
  };

  const pillarChartData = Object.entries(kpis.byPillar).map(([pillar, count]) => ({
    name: PILLAR_LABELS[pillar] || pillar, value: count, fill: PILLAR_COLORS[pillar] || "#6b7280",
  }));

  const statusChartData = Object.entries(kpis.byStatus).map(([status, count]) => ({
    name: STATUS_LABELS[status] || status, value: count,
  }));

  const regionChartData = Object.entries(kpis.byRegion).sort((a, b) => b[1] - a[1]).slice(0, 8).map(([region, count]) => ({
    name: REGION_LABELS[region] || region, value: count,
  }));

  return (
    <div className="space-y-5">
      {/* Department selector */}
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2">
          <Shield className="w-5 h-5 text-primary" />
          <Label className="text-sm font-semibold" style={{ fontFamily: "'Poppins', sans-serif" }}>Departement :</Label>
        </div>
        <Select value={department} onValueChange={v => { setDepartment(v || "DOI"); setSelectedProject(null); }}>
          <SelectTrigger className="w-[200px] glass"><SelectValue /></SelectTrigger>
          <SelectContent>
            {DEPARTMENT_LIST.map(d => <SelectItem key={d} value={d}>{d}</SelectItem>)}
          </SelectContent>
        </Select>
        <Badge variant="secondary">{deptProjects.length} projets</Badge>
        <Badge className="bg-emerald-500/10 text-emerald-500">{kpis.active} actifs</Badge>
        <Badge className="bg-purple-500/10 text-purple-500">{kpis.prospection} en prospection</Badge>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="glass h-auto p-1 flex flex-wrap gap-1">
          <TabsTrigger value="dashboard" className="gap-1.5">
            <LayoutDashboard className="w-3.5 h-3.5" /> Dashboard
          </TabsTrigger>
          <TabsTrigger value="projets" className="gap-1.5">
            <FolderKanban className="w-3.5 h-3.5" /> Projets actifs ({kpis.active})
          </TabsTrigger>
          <TabsTrigger value="prospection" className="gap-1.5">
            <Target className="w-3.5 h-3.5" /> Prospection ({kpis.prospection})
          </TabsTrigger>
          <TabsTrigger value="suivi" className="gap-1.5">
            <TrendingUp className="w-3.5 h-3.5" /> Saisie & Suivi
          </TabsTrigger>
        </TabsList>

        {/* ── DASHBOARD DEPARTEMENTAL ── */}
        <TabsContent value="dashboard">
          <div className="space-y-5">
            {/* KPI Cards */}
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
              {[
                { label: "Projets", value: kpis.total, icon: FolderKanban, color: "#0089D0" },
                { label: "Actifs", value: kpis.active, icon: CheckCircle2, color: "#10b981" },
                { label: "Volume", value: formatCurrency(kpis.totalAmount), icon: DollarSign, color: "#EF7A16", small: true },
                { label: "Exec. Physique", value: `${kpis.avgPhysical}%`, icon: TrendingUp, color: "#0089D0" },
                { label: "Exec. Financiere", value: `${kpis.avgFinancial}%`, icon: DollarSign, color: "#EF7A16" },
                { label: "Risques eleves", value: kpis.highRisks, icon: AlertTriangle, color: kpis.highRisks > 0 ? "#ef4444" : "#10b981" },
              ].map((kpi, i) => (
                <Card key={i} className="glass p-4 animate-fade-up" style={{ animationDelay: `${i * 0.04}s` }}>
                  <div className="flex items-center gap-2 mb-1">
                    <kpi.icon className="w-4 h-4" style={{ color: kpi.color }} />
                    <span className="text-[9px] text-muted-foreground uppercase tracking-wider">{kpi.label}</span>
                  </div>
                  <p className={`${kpi.small ? "text-sm" : "text-xl"} font-bold`} style={{ fontFamily: "'Poppins', sans-serif", color: kpi.color }}>{kpi.value}</p>
                </Card>
              ))}
            </div>

            {/* Execution bars */}
            <div className="grid grid-cols-2 gap-4">
              <Card className="glass p-4">
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-muted-foreground">Execution physique moyenne</span>
                  <span className="font-bold text-[#0089D0]">{kpis.avgPhysical}%</span>
                </div>
                <Progress value={kpis.avgPhysical} className="h-3" />
              </Card>
              <Card className="glass p-4">
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-muted-foreground">Absorption financiere moyenne</span>
                  <span className="font-bold text-[#EF7A16]">{kpis.avgFinancial}%</span>
                </div>
                <Progress value={kpis.avgFinancial} className="h-3" />
              </Card>
            </div>

            {/* Charts */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
              {/* Pillar */}
              <Card className="glass p-5">
                <h4 className="text-sm font-semibold mb-3" style={{ fontFamily: "'Poppins', sans-serif" }}>Par Pilier</h4>
                <ResponsiveContainer width="100%" height={160}>
                  <PieChart>
                    <Pie data={pillarChartData} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={35} outerRadius={60} paddingAngle={3}>
                      {pillarChartData.map((e, i) => <Cell key={i} fill={e.fill} />)}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
                <div className="space-y-1 mt-2">
                  {pillarChartData.map((p, i) => (
                    <div key={i} className="flex items-center gap-2 text-xs">
                      <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: p.fill }} />
                      <span className="text-muted-foreground flex-1">{p.name}</span>
                      <span className="font-bold">{p.value}</span>
                    </div>
                  ))}
                </div>
              </Card>

              {/* Status */}
              <Card className="glass p-5">
                <h4 className="text-sm font-semibold mb-3" style={{ fontFamily: "'Poppins', sans-serif" }}>Pipeline</h4>
                <ResponsiveContainer width="100%" height={200}>
                  <BarChart data={statusChartData}>
                    <XAxis dataKey="name" fontSize={9} tickLine={false} axisLine={false} angle={-30} textAnchor="end" height={50} />
                    <YAxis fontSize={10} tickLine={false} axisLine={false} allowDecimals={false} />
                    <Bar dataKey="value" fill="#0089D0" radius={[4, 4, 0, 0]} maxBarSize={30}>
                      <LabelList dataKey="value" position="top" fontSize={10} fontWeight={700} fill="currentColor" />
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </Card>

              {/* Regions */}
              <Card className="glass p-5">
                <h4 className="text-sm font-semibold mb-3" style={{ fontFamily: "'Poppins', sans-serif" }}>
                  <MapPin className="w-3.5 h-3.5 inline mr-1 text-emerald-500" /> Zones
                </h4>
                {regionChartData.length > 0 ? (
                  <div className="space-y-2">
                    {regionChartData.map((r, i) => {
                      const max = regionChartData[0]?.value || 1;
                      const colors = ["#10b981", "#0089D0", "#EF7A16", "#8b5cf6", "#ec4899", "#FFD500", "#06b6d4", "#ef4444"];
                      return (
                        <div key={i} className="flex items-center gap-2">
                          <span className="text-xs w-20 truncate">{r.name}</span>
                          <div className="flex-1 h-2 rounded-full bg-muted overflow-hidden">
                            <div className="h-full rounded-full" style={{ width: `${(r.value / max) * 100}%`, backgroundColor: colors[i % colors.length] }} />
                          </div>
                          <span className="text-xs font-bold w-6 text-right">{r.value}</span>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <p className="text-xs text-muted-foreground">Aucune zone d'intervention definie</p>
                )}
              </Card>
            </div>

            {/* Timeline */}
            <Card className="glass p-5">
              <h4 className="text-sm font-semibold mb-3" style={{ fontFamily: "'Poppins', sans-serif" }}>
                <Clock className="w-3.5 h-3.5 inline mr-1" /> Derniers suivis — {department}
              </h4>
              <div className="space-y-2">
                {activeProjects.filter(p => p.monitoringEntries.length > 0).slice(0, 6).map(p => {
                  const m = p.monitoringEntries[0];
                  const vConf = VALIDATION_STATUS[m.validationStatus];
                  return (
                    <div key={p.id} className="glass p-3 rounded-lg flex items-center gap-3">
                      <div className="w-1.5 h-8 rounded-full" style={{ backgroundColor: PILLAR_COLORS[p.pillar] }} />
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-medium truncate">{p.projectName}</p>
                        <span className="text-[9px] text-muted-foreground">{m.period} — Phys: {m.physicalRate}% | Fin: {m.financialRate}%</span>
                      </div>
                      <Badge className="text-[8px]" style={{ backgroundColor: `${vConf.color}20`, color: vConf.color }}>{vConf.label}</Badge>
                    </div>
                  );
                })}
              </div>
            </Card>
          </div>
        </TabsContent>

        {/* ── PROJETS ACTIFS ── */}
        <TabsContent value="projets">
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
            {activeProjects.map((p, i) => {
              const latest = p.monitoringEntries[0];
              return (
                <Link key={p.id} href={`/projets/${p.id}`}>
                  <Card className="glass p-4 hover:glow-cyan transition-all cursor-pointer group animate-fade-up h-full" style={{ animationDelay: `${i * 0.03}s` }}>
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-bold truncate group-hover:text-primary transition-colors" style={{ fontFamily: "'Poppins', sans-serif" }}>{p.projectName}</p>
                        <span className="text-xs text-muted-foreground">{p.partner.acronym || p.partner.name}</span>
                      </div>
                      <ArrowUpRight className="w-4 h-4 text-muted-foreground opacity-0 group-hover:opacity-100" />
                    </div>
                    <div className="flex flex-wrap gap-1 mb-2">
                      <Badge variant="outline" className="text-[9px]" style={{ borderColor: PILLAR_COLORS[p.pillar], color: PILLAR_COLORS[p.pillar] }}>{PILLAR_LABELS[p.pillar]}</Badge>
                      {p.contractType && <Badge variant="secondary" className="text-[9px]">{p.contractType}</Badge>}
                    </div>
                    <div className="grid grid-cols-2 gap-2 text-xs mb-2">
                      <div><span className="text-muted-foreground">Montant</span><p className="font-semibold text-primary">{formatCurrency(p.totalAmount)}</p></div>
                      <div><span className="text-muted-foreground">Debut</span><p className="font-medium">{formatDate(p.startDate)}</p></div>
                    </div>
                    {latest && (
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <div className="flex justify-between text-[9px] mb-0.5"><span className="text-muted-foreground">Physique</span><span>{latest.physicalRate}%</span></div>
                          <Progress value={latest.physicalRate} className="h-1.5" />
                        </div>
                        <div>
                          <div className="flex justify-between text-[9px] mb-0.5"><span className="text-muted-foreground">Financier</span><span>{latest.financialRate}%</span></div>
                          <Progress value={latest.financialRate} className="h-1.5" />
                        </div>
                      </div>
                    )}
                    {p.risks.filter(r => r.criticality === "HIGH" && r.status === "OPEN").length > 0 && (
                      <div className="flex items-center gap-1 mt-2 text-[9px] text-red-500">
                        <AlertTriangle className="w-3 h-3" /> {p.risks.filter(r => r.criticality === "HIGH").length} risque(s) eleve(s)
                      </div>
                    )}
                  </Card>
                </Link>
              );
            })}
          </div>
        </TabsContent>

        {/* ── PROSPECTION ── */}
        <TabsContent value="prospection">
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
            {prospectionProjects.map((p, i) => (
              <Link key={p.id} href={`/projets/${p.id}`}>
                <Card className="glass p-4 hover:glow-purple transition-all cursor-pointer group animate-fade-up" style={{ animationDelay: `${i * 0.03}s` }}>
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-bold truncate group-hover:text-primary transition-colors" style={{ fontFamily: "'Poppins', sans-serif" }}>{p.projectName}</p>
                      <span className="text-xs text-muted-foreground">{p.partner.acronym || p.partner.name}</span>
                    </div>
                    <Badge variant="outline" className="text-[9px]">{STATUS_LABELS[p.status]}</Badge>
                  </div>
                  <div className="flex items-center justify-between text-xs mt-2">
                    <span className="text-muted-foreground">{formatCurrency(p.totalAmount)}</span>
                    <div className="flex items-center gap-1">
                      <span className={`font-bold ${p.maturationScore >= 75 ? "text-emerald-500" : p.maturationScore >= 40 ? "text-[#EF7A16]" : "text-red-500"}`}>
                        {p.maturationScore}%
                      </span>
                      <Progress value={p.maturationScore} className="w-16 h-1.5" />
                    </div>
                  </div>
                </Card>
              </Link>
            ))}
          </div>
        </TabsContent>

        {/* ── SAISIE & SUIVI ── */}
        <TabsContent value="suivi">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
            {/* Left: project list */}
            <div className="space-y-2">
              <p className="text-[10px] text-muted-foreground">{activeProjects.length} projets actifs — {department}</p>
              <div className="space-y-1.5 max-h-[calc(100vh-350px)] overflow-y-auto">
                {activeProjects.map(p => {
                  const isSelected = selectedProject?.id === p.id;
                  const latest = p.monitoringEntries[0];
                  return (
                    <Card
                      key={p.id}
                      className={`glass p-3 cursor-pointer transition-all ${isSelected ? "glow-cyan ring-1 ring-primary" : "hover:bg-accent/50"}`}
                      onClick={() => selectProject(p)}
                    >
                      <div className="flex items-center gap-2">
                        <div className="w-1.5 h-8 rounded-full" style={{ backgroundColor: PILLAR_COLORS[p.pillar] }} />
                        <div className="flex-1 min-w-0">
                          <p className="text-xs font-semibold truncate">{p.projectName}</p>
                          <span className="text-[9px] text-muted-foreground">{p.partner.acronym}</span>
                        </div>
                        {latest && <span className="text-[10px] font-medium">{latest.physicalRate}%</span>}
                        <ChevronRight className="w-3 h-3 text-muted-foreground" />
                      </div>
                    </Card>
                  );
                })}
              </div>
            </div>

            {/* Right: forms */}
            <div className="lg:col-span-2">
              {!selectedProject ? (
                <Card className="glass p-12 text-center">
                  <TrendingUp className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
                  <p className="text-sm text-muted-foreground">Selectionnez un projet pour saisir son avancement</p>
                </Card>
              ) : (
                <div className="space-y-4">
                  {success && (
                    <Card className="glass p-3 border-emerald-500/30 bg-emerald-500/5">
                      <div className="flex items-center gap-2 text-emerald-500"><CheckCircle2 className="w-4 h-4" /><span className="text-sm">{success}</span></div>
                    </Card>
                  )}

                  {/* Project header */}
                  <Card className="glass p-4" style={{ borderLeft: `3px solid ${PILLAR_COLORS[selectedProject.pillar]}` }}>
                    <h3 className="text-sm font-bold" style={{ fontFamily: "'Poppins', sans-serif" }}>{selectedProject.projectName}</h3>
                    <p className="text-xs text-muted-foreground">{selectedProject.partner.acronym} | {formatCurrency(selectedProject.totalAmount)} | {PILLAR_LABELS[selectedProject.pillar]}</p>
                    {/* Workflow status */}
                    <div className="flex items-center gap-1 mt-2">
                      {Object.entries(VALIDATION_STATUS).map(([key, conf], i) => {
                        const latestM = selectedProject.monitoringEntries[0];
                        const currentLevel = latestM ? Object.keys(VALIDATION_STATUS).indexOf(latestM.validationStatus) : -1;
                        const thisLevel = i;
                        const isReached = thisLevel <= currentLevel;
                        return (
                          <div key={key} className="flex items-center gap-1">
                            <div className={`w-5 h-5 rounded-full flex items-center justify-center text-[8px] font-bold ${isReached ? "text-white" : "text-muted-foreground bg-muted"}`} style={isReached ? { backgroundColor: conf.color } : {}}>
                              {isReached ? "✓" : i + 1}
                            </div>
                            {i < 3 && <div className={`w-6 h-0.5 ${isReached ? "bg-primary" : "bg-muted"}`} />}
                          </div>
                        );
                      })}
                      <span className="text-[9px] text-muted-foreground ml-2">
                        {selectedProject.monitoringEntries[0] ? VALIDATION_STATUS[selectedProject.monitoringEntries[0].validationStatus]?.label : "Aucune saisie"}
                      </span>
                    </div>
                  </Card>

                  {/* Fiche de suivi */}
                  <Card className="glass p-5">
                    <h4 className="text-sm font-semibold mb-3" style={{ fontFamily: "'Poppins', sans-serif" }}>
                      <Calendar className="w-4 h-4 inline mr-1" /> Nouvelle Fiche de Suivi
                    </h4>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                      <div><Label className="text-xs">Periode</Label><Input value={monForm.period} onChange={e => setMonForm(f => ({ ...f, period: e.target.value }))} className="mt-1 h-8 text-xs" /></div>
                      <div><Label className="text-xs">Taux physique (%)</Label><Input type="number" value={monForm.physicalRate} onChange={e => setMonForm(f => ({ ...f, physicalRate: e.target.value }))} className="mt-1 h-8 text-xs" /></div>
                      <div><Label className="text-xs">Taux financier (%)</Label><Input type="number" value={monForm.financialRate} onChange={e => setMonForm(f => ({ ...f, financialRate: e.target.value }))} className="mt-1 h-8 text-xs" /></div>
                      <div><Label className="text-xs">Cible physique (%)</Label><Input type="number" value={monForm.physicalTarget} onChange={e => setMonForm(f => ({ ...f, physicalTarget: e.target.value }))} className="mt-1 h-8 text-xs" /></div>
                      <div><Label className="text-xs">Cible financiere (%)</Label><Input type="number" value={monForm.financialTarget} onChange={e => setMonForm(f => ({ ...f, financialTarget: e.target.value }))} className="mt-1 h-8 text-xs" /></div>
                      <div className="col-span-full"><Label className="text-xs">Observations</Label><Textarea value={monForm.observations} onChange={e => setMonForm(f => ({ ...f, observations: e.target.value }))} className="mt-1 text-xs" rows={2} /></div>
                    </div>
                    <Button onClick={submitMonitoring} disabled={saving} size="sm" className="mt-3"><Send className="w-3.5 h-3.5 mr-1" />{saving ? "..." : "Enregistrer"}</Button>
                  </Card>

                  {/* Problemes / Risques */}
                  <Card className="glass p-5">
                    <h4 className="text-sm font-semibold mb-3" style={{ fontFamily: "'Poppins', sans-serif" }}>
                      <AlertTriangle className="w-4 h-4 inline mr-1 text-red-500" /> Problemes, Risques et Solutions
                    </h4>
                    {selectedProject.risks.length > 0 && (
                      <div className="space-y-1.5 mb-4">
                        {selectedProject.risks.map(r => (
                          <div key={r.id} className="glass p-2.5 rounded-lg text-xs">
                            <div className="flex items-center gap-2 mb-1">
                              <Badge className="text-[8px]" style={{ backgroundColor: `${r.criticality === "HIGH" ? "#ef4444" : r.criticality === "MEDIUM" ? "#EF7A16" : "#10b981"}20`, color: r.criticality === "HIGH" ? "#ef4444" : r.criticality === "MEDIUM" ? "#EF7A16" : "#10b981" }}>{r.criticality}</Badge>
                              <Badge variant="outline" className="text-[8px]">{r.status}</Badge>
                            </div>
                            <p>{r.description}</p>
                            {r.mitigationActions && <p className="text-muted-foreground mt-1">Solution: {r.mitigationActions}</p>}
                          </div>
                        ))}
                      </div>
                    )}
                    <div className="space-y-2">
                      <div><Label className="text-xs">Nouveau probleme / risque</Label><Textarea value={riskForm.description} onChange={e => setRiskForm(f => ({ ...f, description: e.target.value }))} className="mt-1 text-xs" rows={2} placeholder="Description du probleme..." /></div>
                      <div className="grid grid-cols-2 gap-2">
                        <div><Label className="text-xs">Solution proposee</Label><Textarea value={riskForm.mitigationActions} onChange={e => setRiskForm(f => ({ ...f, mitigationActions: e.target.value }))} className="mt-1 text-xs" rows={2} /></div>
                        <div>
                          <Label className="text-xs">Criticite</Label>
                          <Select value={riskForm.criticality} onValueChange={v => setRiskForm(f => ({ ...f, criticality: v || "MEDIUM" }))}>
                            <SelectTrigger className="mt-1 h-8 text-xs"><SelectValue /></SelectTrigger>
                            <SelectContent>
                              <SelectItem value="LOW">Faible</SelectItem>
                              <SelectItem value="MEDIUM">Moyen</SelectItem>
                              <SelectItem value="HIGH">Eleve</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                      <Button onClick={submitRisk} disabled={saving} variant="outline" size="sm"><Send className="w-3.5 h-3.5 mr-1" />Ajouter</Button>
                    </div>
                  </Card>

                  {/* Historique suivi */}
                  {selectedProject.monitoringEntries.length > 0 && (
                    <Card className="glass p-5">
                      <h4 className="text-sm font-semibold mb-3" style={{ fontFamily: "'Poppins', sans-serif" }}>
                        <FileText className="w-4 h-4 inline mr-1" /> Historique des suivis
                      </h4>
                      <div className="space-y-2">
                        {selectedProject.monitoringEntries.map(m => {
                          const vConf = VALIDATION_STATUS[m.validationStatus];
                          return (
                            <div key={m.id} className="glass p-3 rounded-lg">
                              <div className="flex items-center justify-between mb-1">
                                <Badge variant="outline" className="text-[9px]">{m.period}</Badge>
                                <Badge className="text-[8px]" style={{ backgroundColor: `${vConf.color}20`, color: vConf.color }}>{vConf.label}</Badge>
                              </div>
                              <div className="grid grid-cols-2 gap-3">
                                <div><div className="flex justify-between text-[9px] mb-0.5"><span className="text-muted-foreground">Physique</span><span>{m.physicalRate}%</span></div><Progress value={m.physicalRate} className="h-1.5" /></div>
                                <div><div className="flex justify-between text-[9px] mb-0.5"><span className="text-muted-foreground">Financier</span><span>{m.financialRate}%</span></div><Progress value={m.financialRate} className="h-1.5" /></div>
                              </div>
                              {m.observations && <p className="text-[10px] text-muted-foreground mt-1.5">{m.observations}</p>}
                            </div>
                          );
                        })}
                      </div>
                    </Card>
                  )}
                </div>
              )}
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
