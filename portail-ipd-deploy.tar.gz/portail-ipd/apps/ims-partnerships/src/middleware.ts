import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

const PUBLIC_PATHS = ["/login", "/api/auth/login", "/api/auth/sso", "/api/auth/logout"];
const STATIC_PATHS = ["/_next", "/logo-ipd", "/uploads", "/favicon"];

export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;

  // Allow public paths, static assets, and API routes (except auth check)
  if (
    PUBLIC_PATHS.some(p => pathname.startsWith(p)) ||
    STATIC_PATHS.some(p => pathname.startsWith(p)) ||
    pathname.startsWith("/api/") // Allow all API routes (they handle their own auth)
  ) {
    return NextResponse.next();
  }

  // Check for session cookie
  const sessionToken = request.cookies.get("ims-session")?.value;

  if (!sessionToken) {
    // Redirect to login
    const loginUrl = new URL("/login", request.url);
    loginUrl.searchParams.set("redirect", pathname);
    return NextResponse.redirect(loginUrl);
  }

  // Basic JWT structure validation (full verification done server-side)
  const parts = sessionToken.split(".");
  if (parts.length !== 3) {
    const loginUrl = new URL("/login", request.url);
    loginUrl.searchParams.set("error", "session_expired");
    const response = NextResponse.redirect(loginUrl);
    response.cookies.set("ims-session", "", { maxAge: 0, path: "/" });
    return response;
  }

  // Check expiration from payload (without crypto verification — that's for API routes)
  try {
    const decoded = Buffer.from(parts[1], "base64url").toString("utf-8");
    const payload = JSON.parse(decoded);
    if (payload.exp && payload.exp < Math.floor(Date.now() / 1000)) {
      const loginUrl = new URL("/login", request.url);
      loginUrl.searchParams.set("error", "session_expired");
      const response = NextResponse.redirect(loginUrl);
      response.cookies.set("ims-session", "", { maxAge: 0, path: "/" });
      return response;
    }
  } catch {
    // Invalid token format
  }

  return NextResponse.next();
}

export const config = {
  matcher: [
    // Match all paths except static files
    "/((?!_next/static|_next/image|favicon.ico).*)",
  ],
};
