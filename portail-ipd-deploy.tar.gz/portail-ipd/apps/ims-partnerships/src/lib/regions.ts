// Les 14 régions du Sénégal avec coordonnées centrales et métadonnées
export interface Region {
  code: string;
  name: string;
  capital: string;
  lat: number;
  lng: number;
  population: number; // estimation 2023
}

export const SENEGAL_REGIONS: Region[] = [
  { code: "DAKAR", name: "Dakar", capital: "Dakar", lat: 14.7167, lng: -17.4677, population: 4_042_225 },
  { code: "THIES", name: "Thies", capital: "Thies", lat: 14.7886, lng: -16.9260, population: 2_310_487 },
  { code: "DIOURBEL", name: "Diourbel", capital: "Diourbel", lat: 14.6553, lng: -16.2314, population: 1_924_945 },
  { code: "SAINT_LOUIS", name: "Saint-Louis", capital: "Saint-Louis", lat: 16.0326, lng: -16.4818, population: 1_115_340 },
  { code: "TAMBACOUNDA", name: "Tambacounda", capital: "Tambacounda", lat: 13.7707, lng: -13.6673, population: 960_360 },
  { code: "KAOLACK", name: "Kaolack", capital: "Kaolack", lat: 14.1520, lng: -16.0726, population: 1_218_027 },
  { code: "LOUGA", name: "Louga", capital: "Louga", lat: 15.6167, lng: -16.2333, population: 1_034_051 },
  { code: "FATICK", name: "Fatick", capital: "Fatick", lat: 14.3333, lng: -16.4000, population: 919_768 },
  { code: "KOLDA", name: "Kolda", capital: "Kolda", lat: 12.8833, lng: -14.9500, population: 821_386 },
  { code: "MATAM", name: "Matam", capital: "Matam", lat: 15.6559, lng: -13.2554, population: 756_105 },
  { code: "KAFFRINE", name: "Kaffrine", capital: "Kaffrine", lat: 14.1058, lng: -15.5500, population: 762_347 },
  { code: "KEDOUGOU", name: "Kedougou", capital: "Kedougou", lat: 12.5605, lng: -12.1747, population: 222_898 },
  { code: "SEDHIOU", name: "Sedhiou", capital: "Sedhiou", lat: 12.7081, lng: -15.5569, population: 580_433 },
  { code: "ZIGUINCHOR", name: "Ziguinchor", capital: "Ziguinchor", lat: 12.5833, lng: -16.2719, population: 695_755 },
];

export const REGION_MAP = Object.fromEntries(
  SENEGAL_REGIONS.map(r => [r.code, r])
);

export const REGION_LABELS = Object.fromEntries(
  SENEGAL_REGIONS.map(r => [r.code, r.name])
);

// Color scale for region intensity
export function getRegionColor(projectCount: number): string {
  if (projectCount >= 20) return "#0089D0";
  if (projectCount >= 10) return "#10b981";
  if (projectCount >= 5) return "#EF7A16";
  if (projectCount >= 1) return "#8b5cf6";
  return "#374151";
}
