import { createHmac, randomBytes } from "crypto";

const SSO_SECRET = process.env.SSO_SECRET || "ipd-sso-shared-secret-2026-partnerships";
const JWT_SECRET = process.env.JWT_SECRET || "ims-jwt-secret-partnerships-2026";

// ─── SSO Token Verification ────────────────────────────────
// The IPD portal signs a JWT-like token with HMAC-SHA256 using the shared SSO_SECRET.
// The token payload contains: { sub, email, name, role, department, iat, exp }

export interface SSOPayload {
  sub: string;       // User ID from portal
  email: string;
  name: string;
  role?: string;     // ADMIN_NATIONAL | CHARGE_SUIVI | PARTENAIRE_TECHNIQUE | OBSERVATEUR
  department?: string;
  iat: number;       // Issued at (unix timestamp)
  exp: number;       // Expiration (unix timestamp)
}

/**
 * Verify an SSO token signed by the IPD portal
 */
export function verifySSOToken(token: string): SSOPayload | null {
  try {
    const parts = token.split(".");
    if (parts.length !== 3) return null;

    const [headerB64, payloadB64, signatureB64] = parts;

    // Verify signature
    const expectedSignature = createHmac("sha256", SSO_SECRET)
      .update(`${headerB64}.${payloadB64}`)
      .digest("base64url");

    if (signatureB64 !== expectedSignature) return null;

    // Decode payload
    const payload = JSON.parse(
      Buffer.from(payloadB64, "base64url").toString("utf-8")
    ) as SSOPayload;

    // Check expiration
    if (payload.exp && payload.exp < Math.floor(Date.now() / 1000)) {
      return null;
    }

    return payload;
  } catch {
    return null;
  }
}

/**
 * Generate an SSO token (for testing / portal simulation)
 */
export function generateSSOToken(payload: Omit<SSOPayload, "iat" | "exp">, expiresInSeconds = 300): string {
  const now = Math.floor(Date.now() / 1000);
  const fullPayload: SSOPayload = {
    ...payload,
    iat: now,
    exp: now + expiresInSeconds,
  };

  const header = Buffer.from(JSON.stringify({ alg: "HS256", typ: "JWT" })).toString("base64url");
  const body = Buffer.from(JSON.stringify(fullPayload)).toString("base64url");
  const signature = createHmac("sha256", SSO_SECRET)
    .update(`${header}.${body}`)
    .digest("base64url");

  return `${header}.${body}.${signature}`;
}

// ─── Session Token (internal JWT for the app) ──────────────

export interface SessionPayload {
  userId: string;
  email: string;
  name: string;
  role: string;
  department: string | null;
  iat: number;
  exp: number;
}

/**
 * Create an internal session token after successful login
 */
export function createSessionToken(user: {
  id: string;
  email: string;
  name: string;
  role: string;
  department: string | null;
}): string {
  const now = Math.floor(Date.now() / 1000);
  const payload: SessionPayload = {
    userId: user.id,
    email: user.email,
    name: user.name,
    role: user.role,
    department: user.department,
    iat: now,
    exp: now + 86400, // 24 hours
  };

  const header = Buffer.from(JSON.stringify({ alg: "HS256", typ: "JWT" })).toString("base64url");
  const body = Buffer.from(JSON.stringify(payload)).toString("base64url");
  const signature = createHmac("sha256", JWT_SECRET)
    .update(`${header}.${body}`)
    .digest("base64url");

  return `${header}.${body}.${signature}`;
}

/**
 * Verify an internal session token
 */
export function verifySessionToken(token: string): SessionPayload | null {
  try {
    const parts = token.split(".");
    if (parts.length !== 3) return null;

    const [headerB64, payloadB64, signatureB64] = parts;

    const expectedSignature = createHmac("sha256", JWT_SECRET)
      .update(`${headerB64}.${payloadB64}`)
      .digest("base64url");

    if (signatureB64 !== expectedSignature) return null;

    const payload = JSON.parse(
      Buffer.from(payloadB64, "base64url").toString("utf-8")
    ) as SessionPayload;

    if (payload.exp && payload.exp < Math.floor(Date.now() / 1000)) return null;

    return payload;
  } catch {
    return null;
  }
}
