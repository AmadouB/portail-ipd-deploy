import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatCurrency(amount: number, currency = "USD"): string {
  if (amount >= 1_000_000) {
    return `${(amount / 1_000_000).toFixed(1)}M $`;
  }
  if (amount >= 1_000) {
    return `${(amount / 1_000).toFixed(0)}K $`;
  }
  return new Intl.NumberFormat("fr-FR", { style: "currency", currency }).format(amount);
}

export function formatDate(date: Date | string | null): string {
  if (!date) return "—";
  const d = typeof date === "string" ? new Date(date) : date;
  return d.toLocaleDateString("fr-FR", { day: "2-digit", month: "short", year: "numeric" });
}

export const PILLAR_COLORS: Record<string, string> = {
  RECHERCHE: "#0089D0",
  PRODUCTION: "#10b981",
  SANTE_PUBLIQUE: "#EF7A16",
  EDUCATION: "#8b5cf6",
  SOLUTIONS_SANITAIRES: "#FFD500",
  TRANSFORMATION: "#ec4899",
};

export const PILLAR_LABELS: Record<string, string> = {
  RECHERCHE: "Recherche",
  PRODUCTION: "Production",
  SANTE_PUBLIQUE: "Sante publique",
  EDUCATION: "Education",
  SOLUTIONS_SANITAIRES: "Solutions sanitaires",
  TRANSFORMATION: "Transformation",
};

export const STATUS_COLORS: Record<string, string> = {
  PROSPECTION: "#86B4DD",
  IDENTIFICATION: "#86B4DD",
  CONTACT: "#0089D0",
  DISCUSSION: "#8b5cf6",
  ACCORD: "#FFD500",
  NEGOCIATION: "#EF7A16",
  SIGNATURE: "#10b981",
  ACTIF: "#10b981",
  CLOTURE: "#6b7280",
};

export const TIER_LABELS: Record<string, string> = {
  TIER1: "Tier 1 (>=20M$)",
  TIER2: "Tier 2 (1-5M$)",
  TIER3: "Tier 3 (<1M$)",
};

export const DEPARTMENT_LIST = [
  "DOI", "Diatropix", "DSP", "VRC", "DCH",
  "DREI", "DPC", "CAS", "MWDI", "VaxSen", "UVFJ",
] as const;
