import { prisma } from "./prisma";

export async function logAudit({
  userId,
  action,
  tableName,
  recordId,
  fieldName,
  oldValue,
  newValue,
}: {
  userId: string;
  action: "CREATE" | "UPDATE" | "DELETE" | "VALIDATE";
  tableName: string;
  recordId: string;
  fieldName?: string;
  oldValue?: string;
  newValue?: string;
}) {
  await prisma.auditLog.create({
    data: {
      userId,
      action,
      tableName,
      recordId,
      fieldName: fieldName ?? "",
      oldValue: oldValue ?? "",
      newValue: newValue ?? "",
    },
  });
}

export function diffFields(
  oldObj: Record<string, any>,
  newObj: Record<string, any>,
  fields: string[]
): Array<{ field: string; oldValue: string; newValue: string }> {
  const diffs: Array<{ field: string; oldValue: string; newValue: string }> = [];
  for (const field of fields) {
    const oldVal = String(oldObj[field] ?? "");
    const newVal = String(newObj[field] ?? "");
    if (oldVal !== newVal) {
      diffs.push({ field, oldValue: oldVal, newValue: newVal });
    }
  }
  return diffs;
}
