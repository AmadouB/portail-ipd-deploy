import { Header } from "@/components/layout/header";
import { ProjectDetail } from "@/components/projets/project-detail";

export default async function ProjectDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  return (
    <>
      <Header title="Fiche Projet" subtitle="Detail complet du projet et suivi" />
      <ProjectDetail projectId={id} />
    </>
  );
}
