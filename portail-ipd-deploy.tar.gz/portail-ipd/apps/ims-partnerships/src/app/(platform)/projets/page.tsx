import { Header } from "@/components/layout/header";
import { ProjetsContent } from "@/components/projets/projets-content";

export default function ProjetsPage() {
  return (
    <>
      <Header
        title="Portefeuille de Projets"
        subtitle="Gestion du cycle de vie des partenariats actifs"
      />
      <ProjetsContent />
    </>
  );
}
