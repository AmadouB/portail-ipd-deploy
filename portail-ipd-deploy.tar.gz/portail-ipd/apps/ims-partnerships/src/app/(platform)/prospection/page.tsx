import { Header } from "@/components/layout/header";
import { ProspectionContent } from "@/components/prospection/prospection-content";

export default function ProspectionPage() {
  return (
    <>
      <Header
        title="Pipeline de Prospection"
        subtitle="Suivi des partenaires potentiels et maturation des projets"
      />
      <ProspectionContent />
    </>
  );
}
