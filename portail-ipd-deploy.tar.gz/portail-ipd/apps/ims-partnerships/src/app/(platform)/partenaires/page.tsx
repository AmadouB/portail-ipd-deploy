import { Header } from "@/components/layout/header";
import { PartenairesContent } from "@/components/partenaires/partenaires-content";

export default function PartenairesPage() {
  return (
    <>
      <Header
        title="Partenaires"
        subtitle="Repertoire des 164 partenaires de l'IPD — filtrage, wordcloud et fiches detaillees"
      />
      <PartenairesContent />
    </>
  );
}
