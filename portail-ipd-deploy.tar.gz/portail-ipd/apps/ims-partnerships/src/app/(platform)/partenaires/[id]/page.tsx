import { Header } from "@/components/layout/header";
import { PartnerDetail } from "@/components/partenaires/partner-detail";

export default async function PartnerDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  return (
    <>
      <Header title="Fiche Partenaire" subtitle="Detail complet du partenaire et de ses projets" />
      <PartnerDetail partnerId={id} />
    </>
  );
}
