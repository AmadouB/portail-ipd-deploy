import { Header } from "@/components/layout/header";
import { DashboardContent } from "@/components/dashboard/dashboard-content";

export default function DashboardPage() {
  return (
    <>
      <Header
        title="Dashboard de Pilotage"
        subtitle="Vue d'ensemble du portefeuille de partenariats IPD"
      />
      <DashboardContent />
    </>
  );
}
