import { Header } from "@/components/layout/header";
import { GestionnaireContent } from "@/components/gestionnaire/gestionnaire-content";

export default function GestionnairePage() {
  return (
    <>
      <Header
        title="Gestionnaire de Projets"
        subtitle="Pilotage decentralise par departement — Suivi, saisie et validation"
      />
      <GestionnaireContent />
    </>
  );
}
