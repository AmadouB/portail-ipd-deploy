import { AppSidebar } from "@/components/layout/app-sidebar";

export default function PlatformLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="flex min-h-screen">
      <AppSidebar />
      <main className="flex-1 ml-[240px] p-6 bg-grid bg-background/50 transition-all duration-300">
        {children}
      </main>
    </div>
  );
}
