import { Header } from "@/components/layout/header";
import { RapportContent } from "@/components/rapports/rapport-content";

export default function RapportsPage() {
  return (
    <>
      <Header
        title="Rapports & Analytics"
        subtitle="Generation automatique de rapports et analyses avancees"
      />
      <RapportContent />
    </>
  );
}
