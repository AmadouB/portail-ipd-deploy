import { Header } from "@/components/layout/header";
import { MapContent } from "@/components/cartographie/map-content";

export default function CartographiePage() {
  return (
    <>
      <Header
        title="Cartographie des Interventions"
        subtitle="Territorialisation des partenariats au Senegal, en Afrique et dans le monde"
      />
      <MapContent />
    </>
  );
}
