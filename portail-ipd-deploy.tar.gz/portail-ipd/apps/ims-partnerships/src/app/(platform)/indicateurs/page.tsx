import { Header } from "@/components/layout/header";
import { IndicateursContent } from "@/components/indicateurs/indicateurs-content";

export default function IndicateursPage() {
  return (
    <>
      <Header
        title="Referentiel des Indicateurs"
        subtitle="119 indicateurs d'effets, d'impacts et de performance operationnelle — Alignes sur le Plan Strategique 2022-2032"
      />
      <IndicateursContent />
    </>
  );
}
