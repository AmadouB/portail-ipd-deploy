import { Header } from "@/components/layout/header";
import { MediaContent } from "@/components/medias/media-content";

export default function MediasPage() {
  return (
    <>
      <Header
        title="Medias & Preuves de Terrain"
        subtitle="Coffre-fort numerique des documents, photos et videos de terrain"
      />
      <MediaContent />
    </>
  );
}
