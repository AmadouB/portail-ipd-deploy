import { Header } from "@/components/layout/header";
import { SaisieContent } from "@/components/saisie/saisie-content";

export default function SaisiePage() {
  return (
    <>
      <Header
        title="Saisie & Mise a jour"
        subtitle="Creation de projets, suivi d'avancement et gestion de la prospection"
      />
      <SaisieContent />
    </>
  );
}
