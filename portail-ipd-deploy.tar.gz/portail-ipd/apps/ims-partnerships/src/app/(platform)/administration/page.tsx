import { Header } from "@/components/layout/header";
import { AdminContent } from "@/components/admin/admin-content";

export default function AdminPage() {
  return (
    <>
      <Header
        title="Administration"
        subtitle="Gestion des utilisateurs et des acces"
      />
      <AdminContent />
    </>
  );
}
