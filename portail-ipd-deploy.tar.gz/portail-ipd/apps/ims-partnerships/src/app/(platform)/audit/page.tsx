import { Header } from "@/components/layout/header";
import { AuditContent } from "@/components/audit/audit-content";

export default function AuditPage() {
  return (
    <>
      <Header
        title="Journal d'Audit"
        subtitle="Tracabilite immuable de toutes les modifications"
      />
      <AuditContent />
    </>
  );
}
