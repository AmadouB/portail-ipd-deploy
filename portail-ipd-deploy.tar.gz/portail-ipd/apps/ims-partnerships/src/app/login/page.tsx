"use client";

import { useState, useEffect, Suspense } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Lock, Mail, Globe, Shield, AlertCircle, ArrowRight, Loader2 } from "lucide-react";
import { useTheme } from "@/components/theme-provider";

const SSO_PORTAL_URL = process.env.NEXT_PUBLIC_SSO_PORTAL_URL || "https://portail.institutpasteurdakar.sn";

const ERROR_MESSAGES: Record<string, string> = {
  sso_invalid: "Le jeton SSO est invalide ou a expire. Veuillez reessayer depuis le portail IPD.",
  session_expired: "Votre session a expire. Veuillez vous reconnecter.",
  account_disabled: "Votre compte a ete desactive. Contactez l'administrateur.",
};

export default function LoginPage() {
  return (
    <Suspense fallback={<div className="min-h-screen flex items-center justify-center"><div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" /></div>}>
      <LoginForm />
    </Suspense>
  );
}

function LoginForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { theme } = useTheme();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [ssoLoading, setSsoLoading] = useState(false);

  const redirectTo = searchParams.get("redirect") || "/dashboard";
  const urlError = searchParams.get("error");

  useEffect(() => {
    if (urlError && ERROR_MESSAGES[urlError]) {
      setError(ERROR_MESSAGES[urlError]);
    }
  }, [urlError]);

  // ── Login with email/password ──
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      setError("Veuillez remplir tous les champs.");
      return;
    }

    setLoading(true);
    setError("");

    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });

      const data = await res.json();

      if (!res.ok) {
        setError(data.error || "Identifiants invalides");
        return;
      }

      // Store user info in localStorage for client-side use
      localStorage.setItem("ims-user", JSON.stringify(data.user));

      // Full page redirect to ensure cookie is sent with next request
      window.location.href = redirectTo;
    } catch {
      setError("Erreur de connexion. Verifiez votre reseau.");
    } finally {
      setLoading(false);
    }
  };

  // ── SSO Login ──
  const handleSSO = () => {
    setSsoLoading(true);
    // Redirect to SSO portal with callback URL
    const callbackUrl = `${window.location.origin}/api/auth/sso`;
    const ssoUrl = `${SSO_PORTAL_URL}/auth/sso?app=partnerships&callback=${encodeURIComponent(callbackUrl)}`;
    window.location.href = ssoUrl;
  };

  // ── SSO Demo (for testing) ──
  const handleSSODemo = async () => {
    setSsoLoading(true);
    setError("");
    try {
      const demoUrl = `/api/auth/sso?demo=true&email=${encodeURIComponent(email || "amadou.bao@ipd.sn")}&name=Demo+User&role=ADMIN_NATIONAL&department=DOI`;
      window.location.href = demoUrl;
    } catch {
      setError("Erreur SSO demo");
      setSsoLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8 animate-fade-up">
          <img
            src={theme === "dark" ? "/logo-ipd-dark.png" : "/logo-ipd-light.png"}
            alt="Institut Pasteur de Dakar"
            className="h-16 mx-auto mb-4 object-contain"
          />
          <h1 className="text-xl font-bold shimmer-text" style={{ fontFamily: "'Poppins', sans-serif" }}>
            Suivi des Partenariats
          </h1>
          <p className="text-xs text-muted-foreground mt-1">
            Institut Pasteur de Dakar
          </p>
        </div>

        {/* Error message */}
        {error && (
          <Card className="glass p-3 mb-4 border-red-500/30 bg-red-500/5 animate-fade-up">
            <div className="flex items-start gap-2 text-red-500">
              <AlertCircle className="w-4 h-4 mt-0.5 flex-shrink-0" />
              <span className="text-xs">{error}</span>
            </div>
          </Card>
        )}

        {/* Login Card */}
        <Card className="glass p-6 glow-border animate-fade-up-delay">
          {/* SSO Button */}
          <Button
            onClick={handleSSO}
            disabled={ssoLoading}
            className="w-full h-12 mb-4 bg-[#052A62] hover:bg-[#052A62]/90 text-white"
          >
            {ssoLoading ? (
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            ) : (
              <Shield className="w-4 h-4 mr-2" />
            )}
            Se connecter via le Portail IPD (SSO)
          </Button>

          {/* SSO Demo (dev only) */}
          <Button
            onClick={handleSSODemo}
            disabled={ssoLoading}
            variant="outline"
            className="w-full mb-4 text-xs h-9"
          >
            <Globe className="w-3.5 h-3.5 mr-1.5" />
            Connexion SSO Demo
          </Button>

          {/* Divider */}
          <div className="relative my-5">
            <Separator />
            <span className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-card px-3 text-[10px] text-muted-foreground uppercase tracking-widest">
              ou avec vos identifiants
            </span>
          </div>

          {/* Email/Password form */}
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <Label htmlFor="email" className="text-xs">Email</Label>
              <div className="relative mt-1">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  id="email"
                  type="email"
                  placeholder="prenom.nom@ipd.sn"
                  value={email}
                  onChange={(e) => { setEmail(e.target.value); setError(""); }}
                  className="pl-9"
                  autoComplete="email"
                />
              </div>
            </div>
            <div>
              <Label htmlFor="password" className="text-xs">Mot de passe</Label>
              <div className="relative mt-1">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  id="password"
                  type="password"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => { setPassword(e.target.value); setError(""); }}
                  className="pl-9"
                  autoComplete="current-password"
                />
              </div>
            </div>
            <Button type="submit" variant="outline" className="w-full" disabled={loading}>
              {loading ? (
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              ) : (
                <ArrowRight className="w-4 h-4 mr-2" />
              )}
              {loading ? "Connexion..." : "Se connecter"}
            </Button>
          </form>

          {/* Help text */}
          <p className="text-[10px] text-muted-foreground text-center mt-4">
            Mot de passe par defaut : <code className="glass px-1 py-0.5 rounded">ims2026</code>
          </p>
        </Card>

        {/* Footer */}
        <div className="text-center mt-6 space-y-1 animate-fade-up-delay2">
          <p className="text-[10px] text-muted-foreground">
            <Shield className="w-3 h-3 inline mr-1" />
            Connexion securisee | RBAC 4 niveaux | Journal d'audit
          </p>
          <p className="text-[10px] text-muted-foreground">
            www.institutpasteurdakar.sn
          </p>
        </div>
      </div>
    </div>
  );
}
