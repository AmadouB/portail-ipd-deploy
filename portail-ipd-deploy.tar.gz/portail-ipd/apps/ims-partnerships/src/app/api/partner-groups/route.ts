import { prisma } from "@/lib/prisma";
import { NextResponse } from "next/server";

// Force runtime DB access — pas de pre-rendering au build
export const dynamic = 'force-dynamic';

export async function GET() {
  const groups = await prisma.partnerGroup.findMany({
    include: {
      partners: {
        select: { id: true, name: true, acronym: true, _count: { select: { projects: true } } },
      },
    },
    orderBy: { name: "asc" },
  });
  return NextResponse.json(groups);
}

// Create a new group or add partners to existing
export async function POST(request: Request) {
  const { name, partnerIds } = await request.json();

  if (!name) {
    return NextResponse.json({ error: "Nom du groupe requis" }, { status: 400 });
  }

  // Create or find group
  let group = await prisma.partnerGroup.findUnique({ where: { name } });
  if (!group) {
    group = await prisma.partnerGroup.create({ data: { name } });
  }

  // Assign partners
  if (partnerIds?.length) {
    for (const pid of partnerIds) {
      await prisma.partner.update({
        where: { id: pid },
        data: { groupId: group.id },
      });
    }
  }

  const updated = await prisma.partnerGroup.findUnique({
    where: { id: group.id },
    include: { partners: { select: { id: true, name: true, acronym: true } } },
  });

  return NextResponse.json(updated, { status: 201 });
}

// Remove a partner from its group
export async function PUT(request: Request) {
  const { partnerId } = await request.json();
  if (!partnerId) return NextResponse.json({ error: "partnerId requis" }, { status: 400 });

  await prisma.partner.update({
    where: { id: partnerId },
    data: { groupId: null },
  });

  return NextResponse.json({ success: true });
}
