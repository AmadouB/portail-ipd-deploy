import { prisma } from "@/lib/prisma";
import { NextResponse } from "next/server";

export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const values = await prisma.indicatorValue.findMany({
    where: { indicatorId: id },
    include: { project: { select: { projectName: true } } },
    orderBy: { period: "desc" },
  });
  return NextResponse.json(values);
}

export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const body = await request.json();
  const value = await prisma.indicatorValue.create({
    data: { ...body, indicatorId: id },
  });
  return NextResponse.json(value, { status: 201 });
}
