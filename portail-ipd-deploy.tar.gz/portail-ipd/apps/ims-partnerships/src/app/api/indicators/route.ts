import { prisma } from "@/lib/prisma";
import { NextResponse } from "next/server";

export async function GET() {
  const indicators = await prisma.indicator.findMany({
    include: {
      values: { orderBy: { period: "desc" }, take: 5 },
      _count: { select: { values: true } },
    },
    orderBy: { code: "asc" },
  });
  return NextResponse.json(indicators);
}
