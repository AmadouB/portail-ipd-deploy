import { prisma } from "@/lib/prisma";
import { NextResponse } from "next/server";

// Force runtime DB access — pas de pre-rendering au build
export const dynamic = 'force-dynamic';

export async function GET() {
  const indicators = await prisma.indicator.findMany({
    include: {
      values: { orderBy: { period: "desc" }, take: 5 },
      _count: { select: { values: true } },
    },
    orderBy: { code: "asc" },
  });
  return NextResponse.json(indicators);
}
