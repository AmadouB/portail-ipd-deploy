import { prisma } from "@/lib/prisma";
import { NextResponse } from "next/server";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const statusFilter = searchParams.get("status"); // ACTIF, INACTIF, or null (all)

  const [allProjects, partners, milestones, risks, monitoring, media] = await Promise.all([
    prisma.project.findMany({ include: { partner: true } }),
    prisma.partner.findMany(),
    prisma.milestone.findMany(),
    prisma.risk.findMany(),
    prisma.monitoringEntry.findMany(),
    prisma.mediaFile.findMany(),
  ]);

  const projects = statusFilter === "ACTIF"
    ? allProjects.filter(p => p.status === "ACTIF")
    : statusFilter === "INACTIF"
      ? allProjects.filter(p => p.status !== "ACTIF")
      : allProjects;

  const totalProjects = projects.length;
  const activeProjects = projects.filter(p => p.status === "ACTIF").length;
  const prospectionProjects = projects.filter(p => ["IDENTIFICATION", "CONTACT", "DISCUSSION", "ACCORD", "NEGOCIATION", "SIGNATURE"].includes(p.status)).length;
  const closedProjects = projects.filter(p => p.status === "CLOTURE").length;

  const totalFinancial = projects.reduce((sum, p) => sum + p.totalAmount, 0);
  const activeFinancial = projects.filter(p => p.status === "ACTIF").reduce((sum, p) => sum + p.totalAmount, 0);

  // By pillar
  const byPillar = Object.entries(
    projects.reduce((acc, p) => {
      acc[p.pillar] = acc[p.pillar] || { count: 0, amount: 0 };
      acc[p.pillar].count++;
      acc[p.pillar].amount += p.totalAmount;
      return acc;
    }, {} as Record<string, { count: number; amount: number }>)
  ).map(([pillar, data]) => ({ pillar, ...data }));

  // By department
  const byDepartment = Object.entries(
    projects.reduce((acc, p) => {
      const dept = p.departmentLead || "Non assigne";
      acc[dept] = acc[dept] || { count: 0, amount: 0 };
      acc[dept].count++;
      acc[dept].amount += p.totalAmount;
      return acc;
    }, {} as Record<string, { count: number; amount: number }>)
  ).map(([department, data]) => ({ department, ...data }));

  // By partner type
  const byPartnerType = Object.entries(
    projects.reduce((acc, p) => {
      const type = p.partner.type;
      acc[type] = acc[type] || { count: 0, amount: 0 };
      acc[type].count++;
      acc[type].amount += p.totalAmount;
      return acc;
    }, {} as Record<string, { count: number; amount: number }>)
  ).map(([type, data]) => ({ type, ...data }));

  // By tier
  const byTier = Object.entries(
    projects.reduce((acc, p) => {
      const tier = p.partner.tier;
      acc[tier] = acc[tier] || { count: 0, amount: 0 };
      acc[tier].count++;
      acc[tier].amount += p.totalAmount;
      return acc;
    }, {} as Record<string, { count: number; amount: number }>)
  ).map(([tier, data]) => ({ tier, ...data }));

  // By contract type
  const byContractType = Object.entries(
    projects.reduce((acc, p) => {
      const ct = p.contractType || "Non defini";
      acc[ct] = acc[ct] || { count: 0, amount: 0 };
      acc[ct].count++;
      acc[ct].amount += p.totalAmount;
      return acc;
    }, {} as Record<string, { count: number; amount: number }>)
  ).map(([contractType, d]) => ({ contractType, ...d })).sort((a, b) => b.count - a.count);

  // By division lead
  const byDivisionLead = Object.entries(
    projects.reduce((acc, p) => {
      const div = p.divisionLead || "Non defini";
      acc[div] = acc[div] || { count: 0, amount: 0 };
      acc[div].count++;
      acc[div].amount += p.totalAmount;
      return acc;
    }, {} as Record<string, { count: number; amount: number }>)
  ).map(([division, d]) => ({ division, ...d })).sort((a, b) => b.count - a.count);

  // Pipeline status breakdown
  const pipelineStatus = Object.entries(
    projects.reduce((acc, p) => {
      acc[p.status] = (acc[p.status] || 0) + 1;
      return acc;
    }, {} as Record<string, number>)
  ).map(([status, count]) => ({ status, count }));

  // Milestones summary
  const milestonesApproved = milestones.filter(m => m.status === "L3_APPROVED").length;
  const milestonesPending = milestones.filter(m => m.status === "PENDING").length;

  // Risks summary
  const risksHigh = risks.filter(r => r.criticality === "HIGH" && r.status === "OPEN").length;
  const risksMedium = risks.filter(r => r.criticality === "MEDIUM" && r.status === "OPEN").length;

  // Average execution rates from latest monitoring
  const latestMonitoring = new Map<string, typeof monitoring[0]>();
  for (const m of monitoring) {
    const existing = latestMonitoring.get(m.projectId);
    if (!existing || m.period > existing.period) {
      latestMonitoring.set(m.projectId, m);
    }
  }
  const monitoringValues = Array.from(latestMonitoring.values());
  const avgPhysicalRate = monitoringValues.length > 0
    ? monitoringValues.reduce((s, m) => s + m.physicalRate, 0) / monitoringValues.length
    : 0;
  const avgFinancialRate = monitoringValues.length > 0
    ? monitoringValues.reduce((s, m) => s + m.financialRate, 0) / monitoringValues.length
    : 0;

  // ── Projects by region (Senegal) ──
  const regionCounts: Record<string, { count: number; amount: number }> = {};
  for (const p of projects) {
    if (p.regions) {
      for (const r of (p.regions as string).split(",")) {
        if (!regionCounts[r]) regionCounts[r] = { count: 0, amount: 0 };
        regionCounts[r].count++;
        regionCounts[r].amount += p.totalAmount;
      }
    }
  }
  const byRegion = Object.entries(regionCounts)
    .map(([region, d]) => ({ region, ...d }))
    .sort((a, b) => b.count - a.count);

  // ── Partners by country (for map) ──
  const byCountry = Object.entries(
    partners.reduce((acc, p) => {
      const key = p.country || "Unknown";
      if (!acc[key]) acc[key] = { count: 0, lat: 0, lng: 0, hasCoords: false };
      acc[key].count++;
      if (p.latitude && p.longitude) {
        acc[key].lat = p.latitude;
        acc[key].lng = p.longitude;
        acc[key].hasCoords = true;
      }
      return acc;
    }, {} as Record<string, { count: number; lat: number; lng: number; hasCoords: boolean }>)
  )
    .filter(([, d]) => d.hasCoords)
    .map(([country, d]) => ({
      country,
      count: d.count,
      lat: d.lat,
      lng: d.lng,
      projects: projects.filter(p => p.partner.country === country).length,
      amount: projects.filter(p => p.partner.country === country).reduce((s, p) => s + p.totalAmount, 0),
    }))
    .sort((a, b) => b.count - a.count);

  // ── Funding bracket distribution ──
  const fundingBrackets = [
    { label: "Fund>=20M", min: 20_000_000, max: Infinity, color: "#0089D0" },
    { label: "5<=Fund<20M", min: 5_000_000, max: 19_999_999, color: "#10b981" },
    { label: "1M<=Fund<5M", min: 1_000_000, max: 4_999_999, color: "#EF7A16" },
    { label: "Fund<1M", min: 0, max: 999_999, color: "#8b5cf6" },
  ];

  const byFundingBracket = fundingBrackets.map(bracket => {
    const inBracket = projects.filter(p => p.totalAmount >= bracket.min && p.totalAmount <= bracket.max);
    const totalAmount = inBracket.reduce((s, p) => s + p.totalAmount, 0);
    const activeCount = inBracket.filter(p => p.status === "ACTIF").length;

    // Pillar breakdown
    const pillarBreakdown: Record<string, number> = {};
    inBracket.forEach(p => { pillarBreakdown[p.pillar] = (pillarBreakdown[p.pillar] || 0) + 1; });

    return {
      label: bracket.label,
      color: bracket.color,
      count: inBracket.length,
      activeCount,
      amount: totalAmount,
      pillarBreakdown,
    };
  });

  // ── Project age analytics ──
  const now = new Date();
  const activeWithDates = projects.filter(p => p.status === "ACTIF" && p.startDate);

  // Compute age in months for each active project
  const projectAges = activeWithDates.map(p => {
    const start = new Date(p.startDate!);
    const months = (now.getFullYear() - start.getFullYear()) * 12 + (now.getMonth() - start.getMonth());
    return { id: p.id, months: Math.max(0, months), pillar: p.pillar };
  });

  const avgAgeMonths = projectAges.length > 0
    ? Math.round(projectAges.reduce((s, p) => s + p.months, 0) / projectAges.length)
    : 0;

  const minAgeMonths = projectAges.length > 0 ? Math.min(...projectAges.map(p => p.months)) : 0;
  const maxAgeMonths = projectAges.length > 0 ? Math.max(...projectAges.map(p => p.months)) : 0;
  const medianAgeMonths = projectAges.length > 0
    ? (() => { const sorted = [...projectAges].sort((a, b) => a.months - b.months); const mid = Math.floor(sorted.length / 2); return sorted.length % 2 ? sorted[mid].months : Math.round((sorted[mid - 1].months + sorted[mid].months) / 2); })()
    : 0;

  // Age brackets (tranches)
  const ageBrackets = [
    { label: "< 6 mois", min: 0, max: 5 },
    { label: "6-12 mois", min: 6, max: 12 },
    { label: "1-2 ans", min: 13, max: 24 },
    { label: "2-3 ans", min: 25, max: 36 },
    { label: "3-5 ans", min: 37, max: 60 },
    { label: "> 5 ans", min: 61, max: 999 },
  ];

  const ageDistribution = ageBrackets.map(bracket => {
    const inBracket = projectAges.filter(p => p.months >= bracket.min && p.months <= bracket.max);
    const totalAmount = inBracket.reduce((s, p) => {
      const proj = projects.find(pr => pr.id === p.id);
      return s + (proj?.totalAmount || 0);
    }, 0);

    // Breakdown by pillar within this bracket
    const pillarBreakdown: Record<string, number> = {};
    for (const p of inBracket) {
      pillarBreakdown[p.pillar] = (pillarBreakdown[p.pillar] || 0) + 1;
    }

    return {
      label: bracket.label,
      count: inBracket.length,
      amount: totalAmount,
      pillarBreakdown,
    };
  });

  // Top partners by financial volume
  const topPartners = Object.entries(
    projects.reduce((acc, p) => {
      const name = p.partner.acronym || p.partner.name;
      acc[name] = (acc[name] || 0) + p.totalAmount;
      return acc;
    }, {} as Record<string, number>)
  )
    .sort((a, b) => b[1] - a[1])
    .slice(0, 10)
    .map(([name, amount]) => ({ name, amount }));

  return NextResponse.json({
    summary: {
      totalProjects,
      activeProjects,
      prospectionProjects,
      closedProjects,
      totalPartners: partners.length,
      totalFinancial,
      activeFinancial,
      totalMedia: media.length,
      avgPhysicalRate: Math.round(avgPhysicalRate),
      avgFinancialRate: Math.round(avgFinancialRate),
      milestonesApproved,
      milestonesPending,
      risksHigh,
      risksMedium,
    },
    byPillar,
    byDepartment,
    byPartnerType,
    byTier,
    pipelineStatus,
    topPartners,
    byRegion,
    byCountry,
    byContractType,
    byDivisionLead,
    byFundingBracket,
    projectAge: {
      avgMonths: avgAgeMonths,
      medianMonths: medianAgeMonths,
      minMonths: minAgeMonths,
      maxMonths: maxAgeMonths,
      totalWithDates: projectAges.length,
      distribution: ageDistribution,
    },
  });
}
