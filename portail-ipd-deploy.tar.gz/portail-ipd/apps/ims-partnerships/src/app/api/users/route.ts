import { prisma } from "@/lib/prisma";
import { NextResponse } from "next/server";
import { hashSync } from "bcryptjs";

// Force runtime DB access — pas de pre-rendering au build
export const dynamic = 'force-dynamic';

export async function GET() {
  const users = await prisma.user.findMany({
    select: { id: true, name: true, email: true, role: true, department: true, telephone: true, poste: true, actif: true, lastLoginAt: true, createdAt: true },
    orderBy: { name: "asc" },
  });
  return NextResponse.json(users);
}

export async function POST(request: Request) {
  const body = await request.json();
  const user = await prisma.user.create({
    data: {
      ...body,
      password: hashSync(body.password || "ims2026", 10),
    },
  });
  return NextResponse.json({ ...user, password: undefined }, { status: 201 });
}
