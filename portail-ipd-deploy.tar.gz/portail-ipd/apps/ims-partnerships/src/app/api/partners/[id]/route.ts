import { prisma } from "@/lib/prisma";
import { NextResponse } from "next/server";

// Force runtime DB access — pas de pre-rendering au build
export const dynamic = 'force-dynamic';

export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;

  const partner = await prisma.partner.findUnique({
    where: { id },
    include: {
      projects: {
        include: {
          contacts: true,
          milestones: true,
          risks: true,
          monitoringEntries: { orderBy: { period: "desc" } },
          _count: { select: { mediaFiles: true } },
        },
        orderBy: { totalAmount: "desc" },
      },
    },
  });

  if (!partner) {
    return NextResponse.json({ error: "Partner not found" }, { status: 404 });
  }

  // Compute aggregated stats
  const totalProjects = partner.projects.length;
  const activeProjects = partner.projects.filter(p => p.status === "ACTIF").length;
  const totalFinancial = partner.projects.reduce((s, p) => s + p.totalAmount, 0);

  // Average execution from latest monitoring entries
  const latestMonitoring = new Map<string, { physicalRate: number; financialRate: number }>();
  for (const project of partner.projects) {
    if (project.monitoringEntries.length > 0) {
      const latest = project.monitoringEntries[0];
      latestMonitoring.set(project.id, {
        physicalRate: latest.physicalRate,
        financialRate: latest.financialRate,
      });
    }
  }
  const monitoringValues = Array.from(latestMonitoring.values());
  const avgPhysicalRate = monitoringValues.length > 0
    ? Math.round(monitoringValues.reduce((s, m) => s + m.physicalRate, 0) / monitoringValues.length)
    : 0;
  const avgFinancialRate = monitoringValues.length > 0
    ? Math.round(monitoringValues.reduce((s, m) => s + m.financialRate, 0) / monitoringValues.length)
    : 0;

  // Earliest start, latest end
  const dates = partner.projects
    .filter(p => p.startDate || p.endDate)
    .reduce(
      (acc, p) => {
        if (p.startDate && (!acc.earliest || new Date(p.startDate) < new Date(acc.earliest))) acc.earliest = p.startDate as unknown as string;
        if (p.endDate && (!acc.latest || new Date(p.endDate) > new Date(acc.latest))) acc.latest = p.endDate as unknown as string;
        return acc;
      },
      { earliest: null as string | null, latest: null as string | null }
    );

  // Pillar distribution
  const byPillar = Object.entries(
    partner.projects.reduce((acc, p) => {
      acc[p.pillar] = acc[p.pillar] || { count: 0, amount: 0 };
      acc[p.pillar].count++;
      acc[p.pillar].amount += p.totalAmount;
      return acc;
    }, {} as Record<string, { count: number; amount: number }>)
  ).map(([pillar, data]) => ({ pillar, ...data }));

  // Key achievements (pastActivities from projects)
  const achievements = partner.projects
    .filter(p => p.pastActivities)
    .map(p => ({ projectName: p.projectName, text: p.pastActivities! }));

  // Difficulties (risks)
  const difficulties = partner.projects.flatMap(p =>
    p.risks.map(r => ({ projectName: p.projectName, description: r.description, criticality: r.criticality, mitigation: r.mitigationActions }))
  );

  // Upcoming actions
  const upcoming = partner.projects
    .filter(p => p.upcomingActions)
    .map(p => ({ projectName: p.projectName, text: p.upcomingActions! }));

  return NextResponse.json({
    ...partner,
    stats: {
      totalProjects,
      activeProjects,
      totalFinancial,
      avgPhysicalRate,
      avgFinancialRate,
      earliestStart: dates.earliest,
      latestEnd: dates.latest,
      byPillar,
    },
    achievements,
    difficulties,
    upcoming,
  });
}

export async function PUT(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const body = await request.json();

  // Only allow safe fields
  const allowed = ["name", "acronym", "type", "country", "city", "tier", "website", "latitude", "longitude", "groupId"];
  const data: Record<string, any> = {};
  for (const key of allowed) {
    if (body[key] !== undefined) data[key] = body[key];
  }

  const updated = await prisma.partner.update({ where: { id }, data });
  return NextResponse.json(updated);
}
