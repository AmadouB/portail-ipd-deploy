import { prisma } from "@/lib/prisma";
import { NextResponse } from "next/server";

export async function GET() {
  const [partners, groups] = await Promise.all([
    prisma.partner.findMany({
      include: {
        projects: { select: { status: true } },
        group: true,
        _count: { select: { projects: true } },
      },
      orderBy: { name: "asc" },
    }),
    prisma.partnerGroup.findMany({
      include: {
        partners: {
          select: { id: true, name: true, acronym: true },
        },
      },
      orderBy: { name: "asc" },
    }),
  ]);

  const result = partners.map(p => {
    const activeProjects = p.projects.filter(pr => pr.status === "ACTIF").length;
    const { projects: _, ...rest } = p;
    return {
      ...rest,
      activeProjects,
      inactiveProjects: p._count.projects - activeProjects,
      groupName: p.group?.name || null,
    };
  });

  return NextResponse.json({ partners: result, groups });
}

export async function POST(request: Request) {
  const body = await request.json();
  const partner = await prisma.partner.create({ data: body });
  return NextResponse.json(partner, { status: 201 });
}
