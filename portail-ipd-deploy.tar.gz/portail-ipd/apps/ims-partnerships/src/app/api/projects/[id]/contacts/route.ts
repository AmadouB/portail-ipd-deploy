import { prisma } from "@/lib/prisma";
import { NextResponse } from "next/server";

export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const contacts = await prisma.contact.findMany({
    where: { projectId: id },
  });
  return NextResponse.json(contacts);
}

export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const body = await request.json();
  const contact = await prisma.contact.create({
    data: { ...body, projectId: id },
  });
  return NextResponse.json(contact, { status: 201 });
}
