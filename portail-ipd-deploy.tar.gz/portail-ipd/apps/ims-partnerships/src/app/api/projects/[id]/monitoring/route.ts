import { prisma } from "@/lib/prisma";
import { NextResponse } from "next/server";

// Force runtime DB access — pas de pre-rendering au build
export const dynamic = 'force-dynamic';

export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const entries = await prisma.monitoringEntry.findMany({
    where: { projectId: id },
    include: { author: true },
    orderBy: { period: "desc" },
  });
  return NextResponse.json(entries);
}

export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const body = await request.json();
  const entry = await prisma.monitoringEntry.create({
    data: { ...body, projectId: id },
  });
  return NextResponse.json(entry, { status: 201 });
}
