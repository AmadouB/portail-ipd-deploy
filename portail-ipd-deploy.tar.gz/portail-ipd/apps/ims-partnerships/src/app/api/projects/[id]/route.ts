import { prisma } from "@/lib/prisma";
import { NextResponse } from "next/server";

// Force runtime DB access — pas de pre-rendering au build
export const dynamic = 'force-dynamic';

export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const project = await prisma.project.findUnique({
    where: { id },
    include: {
      partner: true,
      contacts: true,
      milestones: { orderBy: { dueDate: "asc" } },
      risks: { orderBy: { criticality: "asc" } },
      mediaFiles: { orderBy: { uploadedAt: "desc" } },
      monitoringEntries: { orderBy: { period: "desc" }, include: { author: true } },
      prospectionNotes: { orderBy: { date: "desc" }, include: { author: true } },
    },
  });

  if (!project) {
    return NextResponse.json({ error: "Project not found" }, { status: 404 });
  }

  return NextResponse.json(project);
}

export async function PUT(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const body = await request.json();

  // Compute maturation score from boolean fields
  if (body.hasFeasibilityStudy !== undefined) {
    body.maturationScore =
      (body.hasFeasibilityStudy ? 20 : 0) +
      (body.hasImpactAssessment ? 15 : 0) +
      (body.hasFinancialStructure ? 25 : 0) +
      (body.hasIntentionLetter ? 15 : 0) +
      (body.hasLegalValidation ? 15 : 0) +
      (body.hasPillarConformity ? 10 : 0);
  }

  const project = await prisma.project.update({
    where: { id },
    data: body,
  });

  return NextResponse.json(project);
}
