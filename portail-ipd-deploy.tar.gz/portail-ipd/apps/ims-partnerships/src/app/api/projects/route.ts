import { prisma } from "@/lib/prisma";
import { NextResponse } from "next/server";

// Force runtime DB access — pas de pre-rendering au build
export const dynamic = 'force-dynamic';

export async function GET() {
  const projects = await prisma.project.findMany({
    include: {
      partner: true,
      contacts: true,
      milestones: { orderBy: { dueDate: "asc" } },
      risks: true,
      _count: { select: { mediaFiles: true, monitoringEntries: true } },
    },
    orderBy: { updatedAt: "desc" },
  });

  return NextResponse.json(projects);
}

export async function POST(request: Request) {
  const body = await request.json();
  const project = await prisma.project.create({ data: body });
  return NextResponse.json(project, { status: 201 });
}
