import { prisma } from "@/lib/prisma";
import { NextResponse } from "next/server";

export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const notes = await prisma.prospectionNote.findMany({
    where: { projectId: id },
    include: { author: true },
    orderBy: { date: "desc" },
  });
  return NextResponse.json(notes);
}

export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const body = await request.json();
  const note = await prisma.prospectionNote.create({
    data: { ...body, projectId: id },
  });
  return NextResponse.json(note, { status: 201 });
}
