import { prisma } from "@/lib/prisma";
import { NextResponse } from "next/server";

// Force runtime DB access — pas de pre-rendering au build
export const dynamic = 'force-dynamic';

export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const risks = await prisma.risk.findMany({
    where: { projectId: id },
    orderBy: { criticality: "asc" },
  });
  return NextResponse.json(risks);
}

export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const body = await request.json();
  const risk = await prisma.risk.create({
    data: { ...body, projectId: id },
  });
  return NextResponse.json(risk, { status: 201 });
}
