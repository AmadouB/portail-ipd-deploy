import { prisma } from "@/lib/prisma";
import { NextResponse } from "next/server";

export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const risks = await prisma.risk.findMany({
    where: { projectId: id },
    orderBy: { criticality: "asc" },
  });
  return NextResponse.json(risks);
}

export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const body = await request.json();
  const risk = await prisma.risk.create({
    data: { ...body, projectId: id },
  });
  return NextResponse.json(risk, { status: 201 });
}
