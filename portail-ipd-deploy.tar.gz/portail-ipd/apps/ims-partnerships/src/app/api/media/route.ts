import { prisma } from "@/lib/prisma";
import { NextResponse } from "next/server";
import { writeFile, mkdir } from "fs/promises";
import path from "path";

export async function GET() {
  const media = await prisma.mediaFile.findMany({
    include: { project: { select: { projectName: true, pillar: true } }, uploadedBy: { select: { name: true } } },
    orderBy: { uploadedAt: "desc" },
  });
  return NextResponse.json(media);
}

export async function POST(request: Request) {
  const formData = await request.formData();
  const file = formData.get("file") as File;
  const projectId = formData.get("projectId") as string;
  const description = formData.get("description") as string;
  const type = formData.get("type") as string;
  const uploadedById = formData.get("uploadedById") as string | null;

  if (!file || !projectId) {
    return NextResponse.json({ error: "File and projectId required" }, { status: 400 });
  }

  const uploadDir = path.join(process.cwd(), "public", "uploads", projectId);
  await mkdir(uploadDir, { recursive: true });

  const fileName = `${Date.now()}-${file.name}`;
  const filePath = `/uploads/${projectId}/${fileName}`;
  const buffer = Buffer.from(await file.arrayBuffer());
  await writeFile(path.join(uploadDir, fileName), buffer);

  // Parse EXIF for GPS if image
  let latitude: number | null = null;
  let longitude: number | null = null;
  let capturedAt: Date | null = null;

  if (type === "PHOTO" && (file.type === "image/jpeg" || file.type === "image/png")) {
    try {
      const ExifReader = (await import("exifreader")).default;
      const tags = ExifReader.load(buffer);
      if (tags.GPSLatitude && tags.GPSLongitude) {
        latitude = tags.GPSLatitude.description as unknown as number;
        longitude = tags.GPSLongitude.description as unknown as number;
      }
      if (tags.DateTimeOriginal) {
        capturedAt = new Date(tags.DateTimeOriginal.description as string);
      }
    } catch {
      // EXIF parsing failed, continue without GPS data
    }
  }

  const mediaFile = await prisma.mediaFile.create({
    data: {
      projectId,
      type: type || "DOCUMENT",
      fileName: file.name,
      filePath,
      mimeType: file.type,
      fileSize: file.size,
      latitude,
      longitude,
      capturedAt,
      description: description || null,
      uploadedById: uploadedById || null,
    },
  });

  return NextResponse.json(mediaFile, { status: 201 });
}
