import { prisma } from "@/lib/prisma";
import { createSessionToken } from "@/lib/sso";
import { NextResponse } from "next/server";
import { compareSync } from "bcryptjs";

export async function POST(request: Request) {
  const { email, password } = await request.json();

  if (!email || !password) {
    return NextResponse.json({ error: "Email et mot de passe requis" }, { status: 400 });
  }

  const user = await prisma.user.findUnique({ where: { email } });

  if (!user || !user.actif) {
    return NextResponse.json({ error: "Identifiants invalides" }, { status: 401 });
  }

  const validPassword = compareSync(password, user.password);
  if (!validPassword) {
    return NextResponse.json({ error: "Identifiants invalides" }, { status: 401 });
  }

  // Update last login
  await prisma.user.update({
    where: { id: user.id },
    data: { lastLoginAt: new Date() },
  });

  // Create session token
  const token = createSessionToken({
    id: user.id,
    email: user.email,
    name: user.name,
    role: user.role,
    department: user.department,
  });

  const response = NextResponse.json({
    user: {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
      department: user.department,
      poste: user.poste,
    },
    token,
  });

  // Set cookie
  response.cookies.set("ims-session", token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    maxAge: 86400, // 24h
    path: "/",
  });

  return response;
}
