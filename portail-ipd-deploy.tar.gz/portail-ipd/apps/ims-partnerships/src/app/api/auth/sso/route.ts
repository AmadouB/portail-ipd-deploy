import { prisma } from "@/lib/prisma";
import { verifySSOToken, createSessionToken, generateSSOToken } from "@/lib/sso";
import { NextResponse } from "next/server";
import { hashSync } from "bcryptjs";

/**
 * SSO Authentication Endpoint
 *
 * The IPD portal redirects here with a signed token:
 *   GET /api/auth/sso?token=<sso_token>
 *
 * Or the portal POSTs the token:
 *   POST /api/auth/sso { token: "<sso_token>" }
 *
 * The token is verified against SSO_SECRET. If valid, the user is
 * auto-provisioned (created if not exists) and a session is established.
 */

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const token = searchParams.get("token");

  // ── Demo mode: generate a test SSO token ──
  if (searchParams.get("demo") === "true") {
    const email = searchParams.get("email") || "amadou.bao@ipd.sn";
    const demoToken = generateSSOToken({
      sub: "sso-demo-user",
      email,
      name: searchParams.get("name") || "Utilisateur SSO",
      role: searchParams.get("role") || "CHARGE_SUIVI",
      department: searchParams.get("department") || "DOI",
    });
    // Redirect to self with the generated token
    const redirectUrl = new URL(request.url);
    redirectUrl.searchParams.delete("demo");
    redirectUrl.searchParams.delete("email");
    redirectUrl.searchParams.delete("name");
    redirectUrl.searchParams.delete("role");
    redirectUrl.searchParams.delete("department");
    redirectUrl.searchParams.set("token", demoToken);
    return NextResponse.redirect(redirectUrl);
  }

  if (!token) {
    return NextResponse.json({ error: "Token SSO manquant" }, { status: 400 });
  }

  return handleSSOAuth(token, request);
}

export async function POST(request: Request) {
  const body = await request.json();
  const token = body.token;

  if (!token) {
    return NextResponse.json({ error: "Token SSO manquant" }, { status: 400 });
  }

  return handleSSOAuth(token, request);
}

async function handleSSOAuth(ssoToken: string, request: Request) {
  // Verify SSO token
  const ssoPayload = verifySSOToken(ssoToken);

  if (!ssoPayload) {
    // Redirect to login with error
    const loginUrl = new URL("/login", request.url);
    loginUrl.searchParams.set("error", "sso_invalid");
    return NextResponse.redirect(loginUrl);
  }

  // Find or create user
  let user = await prisma.user.findUnique({
    where: { email: ssoPayload.email },
  });

  if (!user) {
    // Auto-provision user from SSO data
    user = await prisma.user.create({
      data: {
        name: ssoPayload.name,
        email: ssoPayload.email,
        password: hashSync(`sso-${ssoPayload.sub}-${Date.now()}`, 10), // Random password (unused with SSO)
        role: mapSSORole(ssoPayload.role),
        department: ssoPayload.department || null,
        poste: "Utilisateur SSO",
        actif: true,
      },
    });
  }

  if (!user.actif) {
    const loginUrl = new URL("/login", request.url);
    loginUrl.searchParams.set("error", "account_disabled");
    return NextResponse.redirect(loginUrl);
  }

  // Update last login
  await prisma.user.update({
    where: { id: user.id },
    data: { lastLoginAt: new Date() },
  });

  // Create internal session
  const sessionToken = createSessionToken({
    id: user.id,
    email: user.email,
    name: user.name,
    role: user.role,
    department: user.department,
  });

  // Redirect to dashboard with session cookie
  const dashboardUrl = new URL("/dashboard", request.url);
  const response = NextResponse.redirect(dashboardUrl);

  response.cookies.set("ims-session", sessionToken, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    maxAge: 86400,
    path: "/",
  });

  return response;
}

function mapSSORole(role?: string): string {
  const roleMap: Record<string, string> = {
    admin: "ADMIN_NATIONAL",
    administrator: "ADMIN_NATIONAL",
    ADMIN: "ADMIN_NATIONAL",
    ADMIN_NATIONAL: "ADMIN_NATIONAL",
    manager: "CHARGE_SUIVI",
    CHARGE_SUIVI: "CHARGE_SUIVI",
    partner: "PARTENAIRE_TECHNIQUE",
    PARTENAIRE_TECHNIQUE: "PARTENAIRE_TECHNIQUE",
    observer: "OBSERVATEUR",
    OBSERVATEUR: "OBSERVATEUR",
  };
  return roleMap[role || ""] || "CHARGE_SUIVI";
}
