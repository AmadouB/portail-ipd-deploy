import type { NextConfig } from "next";

// Multi-app portal IPD : basePath injecte au build via NEXT_BASE_PATH.
const basePath = process.env.NEXT_BASE_PATH ?? "";

const nextConfig: NextConfig = {
  output: "standalone",
  basePath: basePath || undefined,
  assetPrefix: basePath || undefined,
  serverExternalPackages: ["better-sqlite3"],
};

export default nextConfig;
