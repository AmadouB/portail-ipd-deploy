import { PrismaClient } from "../src/generated/prisma/client";
import { PrismaBetterSqlite3 } from "@prisma/adapter-better-sqlite3";
import { hashSync } from "bcryptjs";
import path from "path";

const dbPath = path.resolve(__dirname, "..", "dev.db");
const adapter = new PrismaBetterSqlite3({ url: dbPath });
const prisma = new PrismaClient({ adapter } as any);

const hash = (pwd: string) => hashSync(pwd, 10);

async function main() {
  console.log("Seeding database...");

  // ─── USERS ─────────────────────────────────────────────
  const users = await Promise.all([
    prisma.user.create({ data: { name: "Admin IMS", email: "admin@ipd.sn", password: hash("ims2026"), role: "ADMIN_NATIONAL", department: "UVFJ", poste: "Administrateur systeme" } }),
    prisma.user.create({ data: { name: "Amadou BAO", email: "amadou.bao@ipd.sn", password: hash("ims2026"), role: "ADMIN_NATIONAL", department: "UVFJ", poste: "Chef de projet IMS" } }),
    prisma.user.create({ data: { name: "Fatou Diallo", email: "fatou.diallo@ipd.sn", password: hash("ims2026"), role: "CHARGE_SUIVI", department: "DOI", poste: "Chargee de suivi partenariats" } }),
    prisma.user.create({ data: { name: "Moussa Ndiaye", email: "moussa.ndiaye@ipd.sn", password: hash("ims2026"), role: "CHARGE_SUIVI", department: "DSP", poste: "Charge de suivi terrain" } }),
    prisma.user.create({ data: { name: "Aissatou Sow", email: "aissatou.sow@ipd.sn", password: hash("ims2026"), role: "CHARGE_SUIVI", department: "VRC", poste: "Coordinatrice projets" } }),
    prisma.user.create({ data: { name: "Ibrahima Fall", email: "ibrahima.fall@ipd.sn", password: hash("ims2026"), role: "CHARGE_SUIVI", department: "Diatropix", poste: "Charge de production" } }),
    prisma.user.create({ data: { name: "Marie Faye", email: "marie.faye@ipd.sn", password: hash("ims2026"), role: "CHARGE_SUIVI", department: "DREI", poste: "Responsable recherche" } }),
    prisma.user.create({ data: { name: "Dr. Jean Dupont", email: "jean.dupont@path.org", password: hash("ims2026"), role: "PARTENAIRE_TECHNIQUE", department: null, poste: "Representant PATH" } }),
    prisma.user.create({ data: { name: "Sarah Johnson", email: "sarah.johnson@gatesfoundation.org", password: hash("ims2026"), role: "PARTENAIRE_TECHNIQUE", department: null, poste: "Program Officer BMGF" } }),
    prisma.user.create({ data: { name: "Dr. Oumar Sy", email: "oumar.sy@observateur.sn", password: hash("ims2026"), role: "OBSERVATEUR", department: null, poste: "Observateur externe" } }),
  ]);

  console.log(`Created ${users.length} users`);

  // ─── PARTNERS ──────────────────────────────────────────
  const partnersData = [
    { name: "Bill & Melinda Gates Foundation", acronym: "BMGF", type: "FONDATION", country: "USA", city: "Seattle", tier: "TIER1", website: "https://www.gatesfoundation.org", latitude: 47.6062, longitude: -122.3321 },
    { name: "PATH", acronym: "PATH", type: "ONG_SANTE", country: "USA", city: "Seattle", tier: "TIER1", website: "https://www.path.org", latitude: 47.6205, longitude: -122.3493 },
    { name: "Organisation Mondiale de la Sante", acronym: "OMS", type: "ONG_SANTE", country: "Suisse", city: "Geneve", tier: "TIER1", website: "https://www.who.int", latitude: 46.2276, longitude: 6.0910 },
    { name: "National Institutes of Health", acronym: "NIH", type: "GOUVERNEMENT", country: "USA", city: "Bethesda", tier: "TIER1", website: "https://www.nih.gov", latitude: 38.9959, longitude: -77.0964 },
    { name: "BARDA", acronym: "BARDA", type: "GOUVERNEMENT", country: "USA", city: "Washington DC", tier: "TIER1", website: "https://www.medicalcountermeasures.gov", latitude: 38.8951, longitude: -77.0364 },
    { name: "GAVI, The Vaccine Alliance", acronym: "GAVI", type: "ONG_SANTE", country: "Suisse", city: "Geneve", tier: "TIER1", website: "https://www.gavi.org", latitude: 46.2100, longitude: 6.1400 },
    { name: "Fondation Merieux", acronym: "FMx", type: "FONDATION", country: "France", city: "Lyon", tier: "TIER2", website: "https://www.fondation-merieux.org", latitude: 45.7640, longitude: 4.8357 },
    { name: "Institut de Recherche pour le Developpement", acronym: "IRD", type: "ACADEMIE", country: "France", city: "Marseille", tier: "TIER2", website: "https://www.ird.fr", latitude: 43.2965, longitude: 5.3698 },
    { name: "Centers for Disease Control and Prevention", acronym: "CDC", type: "GOUVERNEMENT", country: "USA", city: "Atlanta", tier: "TIER1", website: "https://www.cdc.gov", latitude: 33.7990, longitude: -84.3285 },
    { name: "USAID", acronym: "USAID", type: "GOUVERNEMENT", country: "USA", city: "Washington DC", tier: "TIER1", website: "https://www.usaid.gov", latitude: 38.8930, longitude: -77.0170 },
    { name: "Wellcome Trust", acronym: "WT", type: "FONDATION", country: "UK", city: "Londres", tier: "TIER1", website: "https://wellcome.org", latitude: 51.5267, longitude: -0.1290 },
    { name: "Agence Francaise de Developpement", acronym: "AFD", type: "INSTITUTION_FINANCIERE", country: "France", city: "Paris", tier: "TIER2", website: "https://www.afd.fr", latitude: 48.8566, longitude: 2.3522 },
    { name: "Union Europeenne", acronym: "UE", type: "GOUVERNEMENT", country: "Belgique", city: "Bruxelles", tier: "TIER1", website: "https://europa.eu", latitude: 50.8503, longitude: 4.3517 },
    { name: "Banque Mondiale", acronym: "BM", type: "INSTITUTION_FINANCIERE", country: "USA", city: "Washington DC", tier: "TIER1", website: "https://www.worldbank.org", latitude: 38.8990, longitude: -77.0420 },
    { name: "CEPI", acronym: "CEPI", type: "ONG_SANTE", country: "Norvege", city: "Oslo", tier: "TIER1", website: "https://cepi.net", latitude: 59.9139, longitude: 10.7522 },
    { name: "FIND", acronym: "FIND", type: "ONG_SANTE", country: "Suisse", city: "Geneve", tier: "TIER2", website: "https://www.finddx.org", latitude: 46.2180, longitude: 6.1290 },
    { name: "Unitaid", acronym: "Unitaid", type: "ONG_SANTE", country: "Suisse", city: "Geneve", tier: "TIER2", website: "https://unitaid.org", latitude: 46.2300, longitude: 6.1500 },
    { name: "Global Fund", acronym: "GF", type: "ONG_SANTE", country: "Suisse", city: "Geneve", tier: "TIER1", website: "https://www.theglobalfund.org", latitude: 46.2200, longitude: 6.1350 },
    { name: "AUDA-NEPAD", acronym: "NEPAD", type: "GOUVERNEMENT", country: "Afrique du Sud", city: "Johannesburg", tier: "TIER2", website: "https://www.nepad.org", latitude: -26.2041, longitude: 28.0473 },
    { name: "Banque Africaine de Developpement", acronym: "BAD", type: "INSTITUTION_FINANCIERE", country: "Cote d'Ivoire", city: "Abidjan", tier: "TIER1", website: "https://www.afdb.org", latitude: 5.3600, longitude: -4.0083 },
  ];

  const partners = await Promise.all(
    partnersData.map(p => prisma.partner.create({ data: p }))
  );
  console.log(`Created ${partners.length} partners`);

  // ─── PROJECTS ──────────────────────────────────────────
  const projectsData = [
    // RECHERCHE
    { partnerId: partners[0].id, streamId: "BMGF-R01", pillar: "RECHERCHE", subPillar: "Genomique", contractType: "Grant", totalAmount: 25000000, annualAmount: 5000000, projectName: "Genomic Surveillance Network for Emerging Pathogens", departmentLead: "DOI", status: "ACTIF", signatureYear: 2024, duration: "5 ans", latitude: 14.6928, longitude: -17.4467, objectives: "Renforcer la surveillance genomique des pathogenes emergents en Afrique de l'Ouest", hasFeasibilityStudy: true, hasImpactAssessment: true, hasFinancialStructure: true, hasIntentionLetter: true, hasLegalValidation: true, hasPillarConformity: true, maturationScore: 100 },
    { partnerId: partners[3].id, streamId: "NIH-R01", pillar: "RECHERCHE", subPillar: "Virologie", contractType: "Research Grant", totalAmount: 8500000, annualAmount: 1700000, projectName: "West African Arbovirus Research Initiative", departmentLead: "DOI", status: "ACTIF", signatureYear: 2023, duration: "5 ans", latitude: 14.6937, longitude: -17.4441, objectives: "Etude des arbovirus circulant en Afrique de l'Ouest", hasFeasibilityStudy: true, hasImpactAssessment: true, hasFinancialStructure: true, hasIntentionLetter: true, hasLegalValidation: true, hasPillarConformity: true, maturationScore: 100 },
    { partnerId: partners[7].id, streamId: "IRD-R01", pillar: "RECHERCHE", subPillar: "Epidemiologie", contractType: "Accord-cadre", totalAmount: 3200000, annualAmount: 640000, projectName: "Programme conjoint epidemiologie moleculaire", departmentLead: "DOI", status: "ACTIF", signatureYear: 2024, duration: "5 ans", latitude: 14.6920, longitude: -17.4480, objectives: "Recherche collaborative en epidemiologie moleculaire", hasFeasibilityStudy: true, hasImpactAssessment: true, hasFinancialStructure: true, hasIntentionLetter: true, hasLegalValidation: false, hasPillarConformity: true, maturationScore: 85 },
    // PRODUCTION
    { partnerId: partners[5].id, streamId: "GAVI-P01", pillar: "PRODUCTION", subPillar: "Vaccins", contractType: "Supply Agreement", totalAmount: 45000000, annualAmount: 15000000, projectName: "MADNAFRIQUE - Production de vaccins fievre jaune", departmentLead: "Diatropix", status: "ACTIF", signatureYear: 2022, duration: "5 ans", latitude: 14.7167, longitude: -17.4677, objectives: "Production a grande echelle du vaccin fievre jaune pour l'Afrique", hasFeasibilityStudy: true, hasImpactAssessment: true, hasFinancialStructure: true, hasIntentionLetter: true, hasLegalValidation: true, hasPillarConformity: true, maturationScore: 100 },
    { partnerId: partners[14].id, streamId: "CEPI-P01", pillar: "PRODUCTION", subPillar: "Plateforme mRNA", contractType: "Grant", totalAmount: 30000000, annualAmount: 10000000, projectName: "mRNA Vaccine Manufacturing Hub", departmentLead: "Diatropix", status: "ACTIF", signatureYear: 2023, duration: "3 ans", latitude: 14.7180, longitude: -17.4650, objectives: "Etablir un hub de production de vaccins ARNm en Afrique", hasFeasibilityStudy: true, hasImpactAssessment: true, hasFinancialStructure: true, hasIntentionLetter: true, hasLegalValidation: true, hasPillarConformity: true, maturationScore: 100 },
    // SANTE PUBLIQUE
    { partnerId: partners[2].id, streamId: "OMS-SP01", pillar: "SANTE_PUBLIQUE", subPillar: "Surveillance", contractType: "MOU", totalAmount: 5000000, annualAmount: 1000000, projectName: "Reseau sentinelle de surveillance epidemiologique", departmentLead: "DSP", status: "ACTIF", signatureYear: 2024, duration: "5 ans", latitude: 14.7500, longitude: -17.3300, objectives: "Renforcement du reseau sentinelle au Senegal", hasFeasibilityStudy: true, hasImpactAssessment: true, hasFinancialStructure: true, hasIntentionLetter: true, hasLegalValidation: true, hasPillarConformity: true, maturationScore: 100 },
    { partnerId: partners[8].id, streamId: "CDC-SP01", pillar: "SANTE_PUBLIQUE", subPillar: "Preparedness", contractType: "Cooperative Agreement", totalAmount: 12000000, annualAmount: 3000000, projectName: "Global Health Security Agenda - Senegal", departmentLead: "DSP", status: "ACTIF", signatureYear: 2023, duration: "4 ans", latitude: 14.7600, longitude: -17.3667, objectives: "Securite sanitaire mondiale - volet Senegal", hasFeasibilityStudy: true, hasImpactAssessment: true, hasFinancialStructure: true, hasIntentionLetter: true, hasLegalValidation: true, hasPillarConformity: true, maturationScore: 100 },
    { partnerId: partners[9].id, streamId: "USAID-SP01", pillar: "SANTE_PUBLIQUE", subPillar: "Diagnostics", contractType: "Sub-grant", totalAmount: 7500000, annualAmount: 2500000, projectName: "Strengthening Laboratory Diagnostic Capacity", departmentLead: "DSP", status: "ACTIF", signatureYear: 2024, duration: "3 ans", latitude: 14.7000, longitude: -17.4500, objectives: "Renforcement des capacites diagnostiques laboratoire", hasFeasibilityStudy: true, hasImpactAssessment: false, hasFinancialStructure: true, hasIntentionLetter: true, hasLegalValidation: true, hasPillarConformity: true, maturationScore: 85 },
    // EDUCATION
    { partnerId: partners[6].id, streamId: "FMx-E01", pillar: "EDUCATION", subPillar: "Formation", contractType: "Convention", totalAmount: 2000000, annualAmount: 400000, projectName: "Programme de formation RESAOLAB+", departmentLead: "DCH", status: "ACTIF", signatureYear: 2023, duration: "5 ans", latitude: 14.6850, longitude: -17.4400, objectives: "Formation des biologistes et techniciens de laboratoire", hasFeasibilityStudy: true, hasImpactAssessment: true, hasFinancialStructure: true, hasIntentionLetter: true, hasLegalValidation: true, hasPillarConformity: true, maturationScore: 100 },
    { partnerId: partners[10].id, streamId: "WT-E01", pillar: "EDUCATION", subPillar: "Bourses", contractType: "Fellowship Grant", totalAmount: 4500000, annualAmount: 900000, projectName: "African Research Leaders Programme", departmentLead: "DREI", status: "ACTIF", signatureYear: 2024, duration: "5 ans", latitude: 14.6900, longitude: -17.4450, objectives: "Bourses de recherche pour jeunes chercheurs africains", hasFeasibilityStudy: true, hasImpactAssessment: true, hasFinancialStructure: true, hasIntentionLetter: true, hasLegalValidation: false, hasPillarConformity: true, maturationScore: 85 },
    // SOLUTIONS SANITAIRES
    { partnerId: partners[15].id, streamId: "FIND-SS01", pillar: "SOLUTIONS_SANITAIRES", subPillar: "Diagnostics rapides", contractType: "Collaboration Agreement", totalAmount: 3500000, annualAmount: 1166000, projectName: "Developpement de tests diagnostiques rapides", departmentLead: "Diatropix", status: "ACTIF", signatureYear: 2024, duration: "3 ans", latitude: 14.7100, longitude: -17.4600, objectives: "Developpement et validation de tests rapides pour maladies tropicales", hasFeasibilityStudy: true, hasImpactAssessment: true, hasFinancialStructure: true, hasIntentionLetter: true, hasLegalValidation: true, hasPillarConformity: true, maturationScore: 100 },
    { partnerId: partners[16].id, streamId: "UA-SS01", pillar: "SOLUTIONS_SANITAIRES", subPillar: "Access", contractType: "Grant", totalAmount: 6000000, annualAmount: 2000000, projectName: "Access to Innovative Diagnostics Initiative", departmentLead: "DPC", status: "ACTIF", signatureYear: 2023, duration: "3 ans", latitude: 14.7050, longitude: -17.4550, objectives: "Acces aux diagnostics innovants en Afrique subsaharienne", hasFeasibilityStudy: true, hasImpactAssessment: true, hasFinancialStructure: true, hasIntentionLetter: true, hasLegalValidation: true, hasPillarConformity: true, maturationScore: 100 },
    // TRANSFORMATION
    { partnerId: partners[13].id, streamId: "BM-T01", pillar: "TRANSFORMATION", subPillar: "Infrastructure", contractType: "Loan/Grant", totalAmount: 20000000, annualAmount: 5000000, projectName: "Modernisation infrastructure IPD", departmentLead: "CAS", status: "ACTIF", signatureYear: 2024, duration: "4 ans", latitude: 14.6950, longitude: -17.4470, objectives: "Modernisation des infrastructures et equipements de l'IPD", hasFeasibilityStudy: true, hasImpactAssessment: true, hasFinancialStructure: true, hasIntentionLetter: true, hasLegalValidation: true, hasPillarConformity: true, maturationScore: 100 },
    { partnerId: partners[19].id, streamId: "BAD-T01", pillar: "TRANSFORMATION", subPillar: "Capacites", contractType: "Grant", totalAmount: 15000000, annualAmount: 5000000, projectName: "African Vaccine Manufacturing Acceleration", departmentLead: "MWDI", status: "ACTIF", signatureYear: 2023, duration: "3 ans", latitude: 14.7200, longitude: -17.4700, objectives: "Acceleration de la capacite de production vaccinale", hasFeasibilityStudy: true, hasImpactAssessment: true, hasFinancialStructure: true, hasIntentionLetter: true, hasLegalValidation: true, hasPillarConformity: true, maturationScore: 100 },
    // PROSPECTION (en cours)
    { partnerId: partners[1].id, streamId: "PATH-NEW01", pillar: "SANTE_PUBLIQUE", subPillar: "mHealth", contractType: "Grant", totalAmount: 8000000, annualAmount: 2000000, projectName: "Digital Health Platform for Disease Surveillance", departmentLead: "DSP", status: "DISCUSSION", latitude: 14.7300, longitude: -17.3900, objectives: "Plateforme numerique de surveillance sanitaire", hasFeasibilityStudy: true, hasImpactAssessment: false, hasFinancialStructure: false, hasIntentionLetter: false, hasLegalValidation: false, hasPillarConformity: true, maturationScore: 30 },
    { partnerId: partners[11].id, streamId: "AFD-NEW01", pillar: "EDUCATION", subPillar: "Capacites RH", contractType: "Subvention", totalAmount: 4000000, annualAmount: 1000000, projectName: "Renforcement des capacites humaines IPD", departmentLead: "DCH", status: "NEGOCIATION", latitude: 14.6850, longitude: -17.4400, objectives: "Programme de renforcement RH et formation continue", hasFeasibilityStudy: true, hasImpactAssessment: true, hasFinancialStructure: true, hasIntentionLetter: true, hasLegalValidation: false, hasPillarConformity: true, maturationScore: 75 },
    { partnerId: partners[12].id, streamId: "UE-NEW01", pillar: "RECHERCHE", subPillar: "One Health", contractType: "EU Grant", totalAmount: 12000000, annualAmount: 3000000, projectName: "One Health Approach for Zoonotic Diseases", departmentLead: "DOI", status: "CONTACT", latitude: 14.7000, longitude: -17.4500, objectives: "Approche One Health pour les maladies zoonotiques", hasFeasibilityStudy: false, hasImpactAssessment: false, hasFinancialStructure: false, hasIntentionLetter: false, hasLegalValidation: false, hasPillarConformity: true, maturationScore: 10 },
    { partnerId: partners[17].id, streamId: "GF-NEW01", pillar: "SANTE_PUBLIQUE", subPillar: "Malaria", contractType: "Grant", totalAmount: 18000000, annualAmount: 6000000, projectName: "Malaria Elimination through Diagnostics", departmentLead: "DSP", status: "ACCORD", latitude: 14.7400, longitude: -17.3500, objectives: "Elimination du paludisme par les diagnostics", hasFeasibilityStudy: true, hasImpactAssessment: true, hasFinancialStructure: true, hasIntentionLetter: true, hasLegalValidation: false, hasPillarConformity: true, maturationScore: 75 },
    { partnerId: partners[18].id, streamId: "NEPAD-NEW01", pillar: "PRODUCTION", subPillar: "Transfer technologique", contractType: "MOU", totalAmount: 5000000, annualAmount: 1250000, projectName: "Technology Transfer Programme for African Manufacturers", departmentLead: "VaxSen", status: "IDENTIFICATION", latitude: 14.7150, longitude: -17.4630, objectives: "Transfert de technologie vaccinale intra-africain", hasFeasibilityStudy: false, hasImpactAssessment: false, hasFinancialStructure: false, hasIntentionLetter: false, hasLegalValidation: false, hasPillarConformity: false, maturationScore: 0 },
  ];

  const projects = [];
  for (const p of projectsData) {
    const project = await prisma.project.create({ data: p });
    projects.push(project);
  }
  console.log(`Created ${projects.length} projects`);

  // ─── CONTACTS ──────────────────────────────────────────
  for (const project of projects.slice(0, 14)) {
    await prisma.contact.create({ data: { projectId: project.id, role: "RESPONSABLE_IPD", name: "Dr. Amadou Sall", email: "asall@ipd.sn", telephone: "+221 33 839 92 00" } });
    await prisma.contact.create({ data: { projectId: project.id, role: "GESTIONNAIRE_SUBVENTION", name: "Mame Diarra Mbaye", email: "mdmbaye@ipd.sn", telephone: "+221 77 123 45 67" } });
  }
  console.log("Created contacts");

  // ─── MILESTONES ────────────────────────────────────────
  const milestoneData = [
    { projectId: projects[0].id, title: "Rapport intermediaire annee 1", dueDate: new Date("2025-06-30"), status: "L3_APPROVED" },
    { projectId: projects[0].id, title: "Installation equipements sequencage", dueDate: new Date("2025-03-15"), status: "L3_APPROVED" },
    { projectId: projects[0].id, title: "Rapport annuel 2025", dueDate: new Date("2026-01-31"), status: "L1_VALIDATED" },
    { projectId: projects[0].id, title: "Publication resultats phase 1", dueDate: new Date("2026-06-30"), status: "PENDING" },
    { projectId: projects[3].id, title: "Validation lot pilote vaccin FJ", dueDate: new Date("2025-09-30"), status: "L3_APPROVED" },
    { projectId: projects[3].id, title: "Certification OMS", dueDate: new Date("2026-03-31"), status: "L2_VALIDATED" },
    { projectId: projects[4].id, title: "Transfert technologie mRNA phase 1", dueDate: new Date("2025-12-31"), status: "L1_VALIDATED" },
    { projectId: projects[4].id, title: "Production lot clinique", dueDate: new Date("2026-06-30"), status: "PENDING" },
    { projectId: projects[5].id, title: "Deploiement sites sentinelles (5/14)", dueDate: new Date("2025-06-30"), status: "L3_APPROVED" },
    { projectId: projects[5].id, title: "Deploiement sites sentinelles (14/14)", dueDate: new Date("2026-06-30"), status: "PENDING" },
  ];

  await Promise.all(milestoneData.map(m => prisma.milestone.create({ data: m })));
  console.log("Created milestones");

  // ─── RISKS ─────────────────────────────────────────────
  const riskData = [
    { projectId: projects[0].id, description: "Retard dans la livraison des sequenceurs", mitigationActions: "Plan B avec fournisseur alternatif, stock de reactifs", criticality: "MEDIUM" },
    { projectId: projects[0].id, description: "Difficulte de recrutement de bioinformaticiens", mitigationActions: "Partenariat avec UCAD, formation interne", criticality: "HIGH" },
    { projectId: projects[3].id, description: "Interruption chaine d'approvisionnement matieres premieres", mitigationActions: "Diversification fournisseurs, stock strategique 6 mois", criticality: "HIGH" },
    { projectId: projects[4].id, description: "Complexite reglementaire transfert technologie mRNA", mitigationActions: "Accompagnement juridique specialise, dialogue regulier avec ANRP", criticality: "HIGH" },
    { projectId: projects[5].id, description: "Instabilite reseau internet dans les zones rurales", mitigationActions: "Solutions offline-first, synchronisation differee", criticality: "MEDIUM" },
    { projectId: projects[6].id, description: "Turnover du personnel forme", mitigationActions: "Plan de retention, formation continue", criticality: "LOW" },
    { projectId: projects[12].id, description: "Fluctuation taux de change USD/XOF", mitigationActions: "Couverture de change, facturation en EUR", criticality: "MEDIUM" },
  ];

  await Promise.all(riskData.map(r => prisma.risk.create({ data: r })));
  console.log("Created risks");

  // ─── MONITORING ENTRIES ────────────────────────────────
  const monitoringData = [
    { projectId: projects[0].id, period: "2025-Q1", periodType: "QUARTERLY", physicalRate: 25, financialRate: 22, physicalTarget: 25, financialTarget: 25, observations: "Avancement conforme au planning", authorId: users[2].id, validationStatus: "L3_APPROVED" },
    { projectId: projects[0].id, period: "2025-Q2", periodType: "QUARTERLY", physicalRate: 48, financialRate: 45, physicalTarget: 50, financialTarget: 50, observations: "Leger retard sur livraison equipements, rattrapage prevu Q3", authorId: users[2].id, validationStatus: "L2_VALIDATED" },
    { projectId: projects[0].id, period: "2025-Q3", periodType: "QUARTERLY", physicalRate: 72, financialRate: 68, physicalTarget: 75, financialTarget: 75, observations: "Rattrapage en cours, recrutement bioinformaticien finalise", authorId: users[2].id, validationStatus: "DRAFT" },
    { projectId: projects[3].id, period: "2025-Q1", periodType: "QUARTERLY", physicalRate: 30, financialRate: 28, physicalTarget: 25, financialTarget: 25, observations: "Production en avance sur le calendrier", authorId: users[5].id, validationStatus: "L3_APPROVED" },
    { projectId: projects[3].id, period: "2025-Q2", periodType: "QUARTERLY", physicalRate: 55, financialRate: 52, physicalTarget: 50, financialTarget: 50, observations: "Lot pilote valide avec succes", authorId: users[5].id, validationStatus: "L3_APPROVED" },
    { projectId: projects[4].id, period: "2025-Q1", periodType: "QUARTERLY", physicalRate: 15, financialRate: 18, physicalTarget: 20, financialTarget: 20, observations: "Phase de conception en cours", authorId: users[5].id, validationStatus: "L3_APPROVED" },
    { projectId: projects[5].id, period: "2025-Q1", periodType: "QUARTERLY", physicalRate: 20, financialRate: 15, physicalTarget: 20, financialTarget: 20, observations: "5 sites sentinelles deployes sur 14", authorId: users[3].id, validationStatus: "L3_APPROVED" },
  ];

  await Promise.all(monitoringData.map(m => prisma.monitoringEntry.create({ data: m })));
  console.log("Created monitoring entries");

  // ─── PROSPECTION NOTES ─────────────────────────────────
  const notesData = [
    { projectId: projects[14].id, type: "REUNION", content: "Reunion de cadrage avec PATH sur la plateforme de sante numerique. Interet confirme pour un pilote au Senegal.", authorId: users[2].id, date: new Date("2025-11-15") },
    { projectId: projects[14].id, type: "EMAIL", content: "Envoi de la note conceptuelle v2 a PATH. Attente retour sous 2 semaines.", authorId: users[2].id, date: new Date("2025-12-01") },
    { projectId: projects[15].id, type: "REUNION", content: "Presentation du projet a l'AFD Paris. Feedback positif, demande de budget detaille.", authorId: users[1].id, date: new Date("2025-10-20") },
    { projectId: projects[15].id, type: "COMMENTAIRE", content: "Budget detaille soumis. L'AFD demande une lettre de soutien du ministere de la Sante.", authorId: users[1].id, date: new Date("2026-01-10") },
    { projectId: projects[16].id, type: "APPEL", content: "Premier contact telephonique avec le bureau UE a Dakar. Proposition de rdv en fevrier.", authorId: users[6].id, date: new Date("2026-01-05") },
  ];

  await Promise.all(notesData.map(n => prisma.prospectionNote.create({ data: n })));
  console.log("Created prospection notes");

  console.log("Database seeded successfully!");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
