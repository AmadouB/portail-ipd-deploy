/**
 * Enrich partners with country/city/coordinates based on known organizations
 */
import { PrismaClient } from "../src/generated/prisma/client";
import { PrismaBetterSqlite3 } from "@prisma/adapter-better-sqlite3";
import path from "path";

const dbPath = path.resolve(__dirname, "..", "dev.db");
const adapter = new PrismaBetterSqlite3({ url: dbPath });
const prisma = new PrismaClient({ adapter } as any);

// Known organizations geocoding
const ORG_GEO: Record<string, { country: string; city: string; lat: number; lng: number }> = {
  // Foundations
  "Gates Foundation (BMGF)": { country: "USA", city: "Seattle", lat: 47.606, lng: -122.332 },
  "Susan Thompson Buffett Foundation": { country: "USA", city: "Omaha", lat: 41.256, lng: -95.934 },
  "Mastercard Foundation": { country: "Canada", city: "Toronto", lat: 43.653, lng: -79.383 },
  "Fondation Mérieux": { country: "France", city: "Lyon", lat: 45.764, lng: 4.836 },
  "Wellcome Trust": { country: "UK", city: "Londres", lat: 51.527, lng: -0.129 },
  "Open Philanthropy": { country: "USA", city: "San Francisco", lat: 37.775, lng: -122.418 },
  "Rockefeller Foundation": { country: "USA", city: "New York", lat: 40.758, lng: -73.978 },
  // Government agencies
  "European Union  - European Commission": { country: "Belgique", city: "Bruxelles", lat: 50.850, lng: 4.352 },
  "Foreign, Commonwealth & Development Office": { country: "UK", city: "Londres", lat: 51.502, lng: -0.125 },
  "Agence française de Développement  (AFD)": { country: "France", city: "Paris", lat: 48.857, lng: 2.352 },
  "BARDA": { country: "USA", city: "Washington DC", lat: 38.895, lng: -77.036 },
  "USAID": { country: "USA", city: "Washington DC", lat: 38.893, lng: -77.017 },
  "Centers for Disease Control and Prevention (CDC)": { country: "USA", city: "Atlanta", lat: 33.799, lng: -84.329 },
  "National Institutes of Health (NIH)": { country: "USA", city: "Bethesda", lat: 38.996, lng: -77.096 },
  "Lux-Development S.A.": { country: "Luxembourg", city: "Luxembourg", lat: 49.612, lng: 6.132 },
  "Korean International Cooperation Agency (KOICA)": { country: "Coree du Sud", city: "Seoul", lat: 37.567, lng: 126.978 },
  "Japan International Cooperation Agency (JICA)": { country: "Japon", city: "Tokyo", lat: 35.676, lng: 139.650 },
  "Ministère de la Santé et de l'Action Sociale du Sénégal (MSAS)": { country: "Senegal", city: "Dakar", lat: 14.717, lng: -17.468 },
  // International orgs
  "World Health Organization (WHO)": { country: "Suisse", city: "Geneve", lat: 46.228, lng: 6.091 },
  "GAVI": { country: "Suisse", city: "Geneve", lat: 46.210, lng: 6.140 },
  "CEPI": { country: "Norvege", city: "Oslo", lat: 59.914, lng: 10.752 },
  "UNICEF": { country: "USA", city: "New York", lat: 40.749, lng: -73.968 },
  "The Global Fund": { country: "Suisse", city: "Geneve", lat: 46.220, lng: 6.135 },
  "Unitaid": { country: "Suisse", city: "Geneve", lat: 46.230, lng: 6.150 },
  "FIND": { country: "Suisse", city: "Geneve", lat: 46.218, lng: 6.129 },
  "World Bank": { country: "USA", city: "Washington DC", lat: 38.899, lng: -77.042 },
  "African Development Bank (AfDB)": { country: "Cote d'Ivoire", city: "Abidjan", lat: 5.360, lng: -4.008 },
  "Islamic Development Bank (IsDB)": { country: "Arabie Saoudite", city: "Jeddah", lat: 21.486, lng: 39.177 },
  "West African health Organization (WAHO)/OOAS": { country: "Burkina Faso", city: "Bobo-Dioulasso", lat: 11.177, lng: -4.298 },
  // African orgs
  "African Union  - Africa Center for disease control + PAVM": { country: "Ethiopie", city: "Addis Abeba", lat: 9.005, lng: 38.764 },
  "Partnerships for African Vaccine Manufacturing (PAVM)": { country: "Ethiopie", city: "Addis Abeba", lat: 9.010, lng: 38.760 },
  "AUDA-NEPAD": { country: "Afrique du Sud", city: "Johannesburg", lat: -26.204, lng: 28.047 },
  // Academic / Research
  "Institut de Recherche pour le Développement (IRD)": { country: "France", city: "Marseille", lat: 43.297, lng: 5.370 },
  "International Vaccine Institute (IVI)": { country: "Coree du Sud", city: "Seoul", lat: 37.460, lng: 126.952 },
  "London School of Hygiene & Tropical Medicine (LSHTM)": { country: "UK", city: "Londres", lat: 51.521, lng: -0.131 },
  "University of Oxford": { country: "UK", city: "Oxford", lat: 51.755, lng: -1.254 },
  "Harvard University": { country: "USA", city: "Boston", lat: 42.377, lng: -71.117 },
  "Emory University": { country: "USA", city: "Atlanta", lat: 33.791, lng: -84.323 },
  "University of Pittsburgh": { country: "USA", city: "Pittsburgh", lat: 40.444, lng: -79.953 },
  // Industry / Pharma
  "Novavax": { country: "USA", city: "Gaithersburg", lat: 39.084, lng: -77.154 },
  "bioMérieux": { country: "France", city: "Marcy-l'Etoile", lat: 45.780, lng: 4.708 },
  "Sanofi": { country: "France", city: "Paris", lat: 48.841, lng: 2.276 },
  "Merck": { country: "USA", city: "Kenilworth", lat: 40.677, lng: -74.293 },
  "Pfizer": { country: "USA", city: "New York", lat: 40.750, lng: -73.975 },
  // NGOs
  "PATH": { country: "USA", city: "Seattle", lat: 47.621, lng: -122.349 },
  "Clinton Health Access Initiative (CHAI)": { country: "USA", city: "Boston", lat: 42.360, lng: -71.059 },
  "Médecins Sans Frontières (MSF)": { country: "Suisse", city: "Geneve", lat: 46.224, lng: 6.116 },
  "DNDi": { country: "Suisse", city: "Geneve", lat: 46.215, lng: 6.145 },
  "Grand Challenges Canada": { country: "Canada", city: "Toronto", lat: 43.660, lng: -79.395 },
};

// Keyword-based fallback geocoding
const KEYWORD_GEO: Array<{ keywords: string[]; geo: { country: string; city: string; lat: number; lng: number } }> = [
  { keywords: ["sénégal", "senegal", "dakar", "ucad", "pasteur de dakar"], geo: { country: "Senegal", city: "Dakar", lat: 14.693, lng: -17.447 } },
  { keywords: ["france", "français", "inserm", "anrs", "cnrs", "pasteur"], geo: { country: "France", city: "Paris", lat: 48.857, lng: 2.352 } },
  { keywords: ["usa", "american", "u.s.", "united states", "nih", "cdc"], geo: { country: "USA", city: "Washington DC", lat: 38.895, lng: -77.036 } },
  { keywords: ["uk", "british", "england", "london"], geo: { country: "UK", city: "Londres", lat: 51.507, lng: -0.128 } },
  { keywords: ["suisse", "swiss", "geneva", "geneve", "genève"], geo: { country: "Suisse", city: "Geneve", lat: 46.205, lng: 6.142 } },
  { keywords: ["african", "africa", "afrique"], geo: { country: "Senegal", city: "Dakar", lat: 14.693, lng: -17.447 } },
  { keywords: ["japan", "japon"], geo: { country: "Japon", city: "Tokyo", lat: 35.676, lng: 139.650 } },
  { keywords: ["korea", "corée", "coree"], geo: { country: "Coree du Sud", city: "Seoul", lat: 37.567, lng: 126.978 } },
  { keywords: ["india", "inde"], geo: { country: "Inde", city: "New Delhi", lat: 28.614, lng: 77.209 } },
  { keywords: ["germany", "allemagne", "german"], geo: { country: "Allemagne", city: "Berlin", lat: 52.520, lng: 13.405 } },
  { keywords: ["belgium", "belgique", "bruxelles", "brussels"], geo: { country: "Belgique", city: "Bruxelles", lat: 50.850, lng: 4.352 } },
  { keywords: ["norway", "norvège", "norvege"], geo: { country: "Norvege", city: "Oslo", lat: 59.914, lng: 10.752 } },
  { keywords: ["canada", "canadian"], geo: { country: "Canada", city: "Ottawa", lat: 45.421, lng: -75.690 } },
  { keywords: ["gambia", "gambie"], geo: { country: "Gambie", city: "Banjul", lat: 13.453, lng: -16.577 } },
  { keywords: ["burkina"], geo: { country: "Burkina Faso", city: "Ouagadougou", lat: 12.372, lng: -1.524 } },
  { keywords: ["mali"], geo: { country: "Mali", city: "Bamako", lat: 12.640, lng: -8.000 } },
  { keywords: ["guinea", "guinée", "guinee"], geo: { country: "Guinee", city: "Conakry", lat: 9.509, lng: -13.712 } },
  { keywords: ["côte d'ivoire", "cote d'ivoire", "ivory coast"], geo: { country: "Cote d'Ivoire", city: "Abidjan", lat: 5.360, lng: -4.008 } },
  { keywords: ["south africa", "afrique du sud"], geo: { country: "Afrique du Sud", city: "Johannesburg", lat: -26.204, lng: 28.047 } },
  { keywords: ["ethiopia", "éthiopie", "ethiopie"], geo: { country: "Ethiopie", city: "Addis Abeba", lat: 9.005, lng: 38.764 } },
  { keywords: ["china", "chine"], geo: { country: "Chine", city: "Beijing", lat: 39.904, lng: 116.407 } },
  { keywords: ["australia", "australie"], geo: { country: "Australie", city: "Melbourne", lat: -37.814, lng: 144.963 } },
  { keywords: ["netherlands", "pays-bas", "dutch"], geo: { country: "Pays-Bas", city: "Amsterdam", lat: 52.370, lng: 4.895 } },
  { keywords: ["spain", "espagne"], geo: { country: "Espagne", city: "Madrid", lat: 40.417, lng: -3.704 } },
  { keywords: ["italy", "italie"], geo: { country: "Italie", city: "Rome", lat: 41.903, lng: 12.496 } },
];

function findGeo(name: string): { country: string; city: string; lat: number; lng: number } | null {
  // Exact match
  if (ORG_GEO[name]) return ORG_GEO[name];

  // Partial match on keys
  for (const [key, geo] of Object.entries(ORG_GEO)) {
    if (name.includes(key) || key.includes(name)) return geo;
  }

  // Keyword match
  const lower = name.toLowerCase();
  for (const entry of KEYWORD_GEO) {
    if (entry.keywords.some(kw => lower.includes(kw))) return entry.geo;
  }

  // Default: Dakar (IPD is Senegalese, most unknown partners are local/regional)
  return { country: "Senegal", city: "Dakar", lat: 14.693 + (Math.random() - 0.5) * 0.05, lng: -17.447 + (Math.random() - 0.5) * 0.05 };
}

async function main() {
  const partners = await prisma.partner.findMany();
  let updated = 0;

  for (const partner of partners) {
    if (partner.country !== "Unknown" && partner.latitude) continue;

    const geo = findGeo(partner.name);
    if (!geo) continue;

    await prisma.partner.update({
      where: { id: partner.id },
      data: {
        country: geo.country,
        city: geo.city,
        latitude: geo.lat,
        longitude: geo.lng,
      },
    });
    updated++;
  }

  // Print summary
  const byCountry = await prisma.$queryRawUnsafe<Array<{ country: string; _count: number }>>(
    "SELECT country, COUNT(*) as _count FROM Partner GROUP BY country ORDER BY COUNT(*) DESC"
  );

  console.log(`Updated ${updated} partners\n`);
  console.log("=== PARTNERS BY COUNTRY ===");
  for (const row of byCountry as any[]) {
    console.log(`  ${row.country}: ${row._count}`);
  }
}

main()
  .catch(console.error)
  .finally(() => prisma.$disconnect());
