import { PrismaClient } from "../src/generated/prisma/client";
import { PrismaBetterSqlite3 } from "@prisma/adapter-better-sqlite3";
import path from "path";

const dbPath = path.resolve(__dirname, "..", "dev.db");
const adapter = new PrismaBetterSqlite3({ url: dbPath });
const prisma = new PrismaClient({ adapter } as any);

const MISSING = [
  // DPC Communication (manquants)
  { code: "OP-DPC-09", category: "OPERATIONAL", department: "DPC", subUnit: "Communication", name: "Newsletter trimestrielle publiee", formula: "(Nb newsletters publiees / 4) x 100", frequency: "QUARTERLY", responsible: "DPC / RPCEM", target2025: "4/an (100%)", target2027: "4/an (100%)", source: "Archives DPC" },
  { code: "OP-DPC-10", category: "OPERATIONAL", department: "DPC", subUnit: "Communication", name: "Supports de communication produits", formula: "Comptage supports produits", frequency: "QUARTERLY", responsible: "DPC / RICCM", target2025: ">=5 000", target2027: ">=8 000", source: "Inventaire supports DPC" },
  { code: "OP-DPC-11", category: "OPERATIONAL", department: "DPC", subUnit: "Communication", name: "Productions multimedias", formula: "Comptage infographies, videos, photos", frequency: "QUARTERLY", responsible: "DPC / ICM", target2025: ">=8 000", target2027: ">=12 000", source: "Mediatheque IPD" },
  { code: "OP-DPC-12", category: "OPERATIONAL", department: "DPC", subUnit: "Communication", name: "Taux d'utilisation charte graphique", formula: "(Supports conformes / Total) x 100", frequency: "SEMI_ANNUAL", responsible: "DPC / RICCM", target2025: ">=80%", target2027: "100%", unit: "%", source: "Audit visuel DPC" },
  // DPC Subventions (manquants)
  { code: "OP-DPC-16", category: "OPERATIONAL", department: "DPC", subUnit: "Subventions et Projets", name: "Dashboard performance grants", formula: "Binaire : Operationnel / Non", frequency: "QUARTERLY", responsible: "DPC / RPSEID", target2025: "Operationnel", target2027: "Automatise", source: "Plateforme SEID" },
  { code: "OP-DPC-17", category: "OPERATIONAL", department: "DPC", subUnit: "Subventions et Projets", name: "Cartographie des projets actualisee", formula: "Date derniere mise a jour < 3 mois", frequency: "QUARTERLY", responsible: "DPC / CGPS", target2025: "Trimestrielle", target2027: "Trimestrielle", source: "Fichier consolidation DPC" },
  // DPC SEID (manquants)
  { code: "OP-DPC-20", category: "OPERATIONAL", department: "DPC", subUnit: "SEID", name: "Taux de recommandations mises en oeuvre", formula: "(Reco implementees / Total) x 100", frequency: "ANNUAL", responsible: "DPC / RPSEID", target2025: ">=60%", target2027: ">=75%", unit: "%", source: "Registre suivi reco" },
  { code: "OP-DPC-21", category: "OPERATIONAL", department: "DPC", subUnit: "SEID", name: "Qualite et precision des donnees", formula: "Score audit qualite (1-5)", frequency: "ANNUAL", responsible: "DPC / RPSEID", target2025: ">=3/5", target2027: ">=4/5", unit: "score /5", source: "Audits qualite donnees" },
  // DREI (manquants)
  { code: "OP-DREI-26", category: "OPERATIONAL", department: "DREI", name: "Chercheurs MNT recrutes", formula: "Comptage recrutements", frequency: "ANNUAL", responsible: "DREI / DCH", target2025: "5 ETP", target2027: "10 ETP", unit: "ETP", source: "Registre RH / DCH" },
  { code: "OP-DREI-27", category: "OPERATIONAL", department: "DREI", name: "Taux de conformite anti-plagiat", formula: "(Publications controlees / Total) x 100", frequency: "ANNUAL", responsible: "DREI", target2025: "100%", target2027: "100%", unit: "%", source: "Logiciel anti-plagiat" },
  // DCH (manquants)
  { code: "OP-DCH-32", category: "OPERATIONAL", department: "DCH", name: "Index d'egalite professionnelle", formula: "Index composite (ratio H/F, remuneration, promotions)", frequency: "ANNUAL", responsible: "DCH", target2025: "Mesure", target2027: "En progression", source: "Rapport egalite DCH" },
  { code: "OP-DCH-33", category: "OPERATIONAL", department: "DCH", name: "HoShin actualise par direction", formula: "(Directions avec HoShin / Total) x 100", frequency: "ANNUAL", responsible: "DCH / CAS", target2025: "100%", target2027: "100%", unit: "%", source: "Documents HoShin annuels" },
  // CARE (manquant)
  { code: "OP-CARE-48", category: "OPERATIONAL", department: "CARE", name: "Ratio beneficiaires femmes", formula: "(Femmes / Total) x 100", frequency: "ANNUAL", responsible: "CARE / DCH", target2025: ">=40%", target2027: ">=45%", unit: "%", source: "Registre CARE" },
  // DFC (manquant)
  { code: "OP-DFC-52", category: "OPERATIONAL", department: "DFC", name: "Rapport financier audite publie", formula: "Publie avant mars O/N", frequency: "ANNUAL", responsible: "DFC", target2025: "Avant mars", target2027: "Avant mars", source: "Rapport annuel audite" },
  // DDSI (manquant)
  { code: "OP-DDSI-55", category: "OPERATIONAL", department: "DDSI", name: "Incidents de cybersecurite", formula: "Comptage incidents reportes", frequency: "QUARTERLY", responsible: "DDSI", target2025: "<5/an", target2027: "<3/an", source: "SIEM / Registre incidents" },
  // DAL (manquant)
  { code: "OP-DAL-57", category: "OPERATIONAL", department: "DAL", name: "Taux conformite procedures achats", formula: "(Achats conformes / Total) x 100", frequency: "SEMI_ANNUAL", responsible: "DAL", target2025: ">=90%", target2027: ">=95%", unit: "%", source: "Audit interne achats" },
  // DC (manquant)
  { code: "OP-DC-60", category: "OPERATIONAL", department: "DC", name: "Taux de satisfaction clients", formula: "Enquete satisfaction, score sur 5", frequency: "SEMI_ANNUAL", responsible: "DC", target2025: ">=4/5", target2027: ">=4.3/5", unit: "score /5", source: "Enquete clients DC" },
  // GOV (manquants)
  { code: "OP-GOV-64", category: "OPERATIONAL", department: "GOV", name: "Taux de preuves disponibles (grille COR)", formula: "(Preuves fournies / Preuves requises) x 100", frequency: "ANNUAL", responsible: "CI / CAS", target2025: ">=75%", target2027: ">=85%", unit: "%", source: "Grille suivi interne" },
  { code: "OP-GOV-66", category: "OPERATIONAL", department: "GOV", name: "Audit interne qualite realise", formula: "Comptage audits realises", frequency: "ANNUAL", responsible: "CI", target2025: ">=1/an", target2027: ">=1/an", source: "Rapport Controle Interne" },
  { code: "OP-GOV-67", category: "OPERATIONAL", department: "GOV", name: "Revue semestrielle CDP realisee", formula: "Comptage revues realisees", frequency: "SEMI_ANNUAL", responsible: "CAS / AG", target2025: "2/an", target2027: "2/an", source: "CR reunions de revue" },
  // PROJETS (manquant)
  { code: "OP-PROJ-72", category: "OPERATIONAL", department: "PROJETS", initiative: "CARE, DREI", name: "Impact des formations bio-production", formula: "Score pre/post sur echelle 1-5", frequency: "ANNUAL", responsible: "CARE / DREI", target2025: ">=+1 point", target2027: ">=+1.5 pts", unit: "points", source: "Enquetes CARE" },
];

async function main() {
  let added = 0;
  for (const ind of MISSING) {
    const exists = await prisma.indicator.findUnique({ where: { code: ind.code } });
    if (!exists) {
      await prisma.indicator.create({ data: ind });
      added++;
    }
  }
  const total = await prisma.indicator.count();
  const ops = await prisma.indicator.count({ where: { category: "OPERATIONAL" } });
  console.log(`Added ${added} missing indicators. Total: ${total} (${ops} operational)`);
}

main().catch(console.error).finally(() => prisma.$disconnect());
