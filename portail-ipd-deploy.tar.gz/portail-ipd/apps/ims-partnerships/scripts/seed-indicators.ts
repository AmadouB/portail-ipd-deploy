import { PrismaClient } from "../src/generated/prisma/client";
import { PrismaBetterSqlite3 } from "@prisma/adapter-better-sqlite3";
import path from "path";

const dbPath = path.resolve(__dirname, "..", "dev.db");
const adapter = new PrismaBetterSqlite3({ url: dbPath });
const prisma = new PrismaClient({ adapter } as any);

interface IndDef {
  code: string; category: string; pillar?: string; department?: string; subUnit?: string;
  initiative?: string; name: string; description?: string; formula?: string;
  frequency?: string; source?: string; responsible?: string;
  baseline?: string; target2025?: string; target2027?: string; target2032?: string; unit?: string;
}

const INDICATORS: IndDef[] = [
  // ═══════════════════════════════════════════════════════════════
  // PARTIE I — INDICATEURS STRATEGIQUES D'EFFETS ET D'IMPACTS
  // ═══════════════════════════════════════════════════════════════

  // ── Pilier 1 : Fabrication vaccins & diagnostics ─── EFFETS
  { code: "E1.1", category: "EFFECT", pillar: "PRODUCTION", initiative: "Madiba, AfricAmaril", name: "Population couverte par les vaccins IPD", description: "Nombre de personnes vaccinees grace aux doses produites par l'IPD", formula: "Nb doses x taux administration", baseline: "~5 Mn", target2027: "~10 Mn", target2032: ">=30 Mn", unit: "personnes", source: "OMS / IPD", frequency: "ANNUAL" },
  { code: "E1.2", category: "EFFECT", pillar: "PRODUCTION", initiative: "DOI", name: "Reduction du cout unitaire vaccin", formula: "(Prix N - Prix N-1) / Prix N-1 x 100", baseline: "Reference", target2027: "-10%", target2032: "-30%", unit: "%", source: "Comptabilite analytique DOI", frequency: "ANNUAL" },
  { code: "E1.3", category: "EFFECT", pillar: "PRODUCTION", initiative: "DOI", name: "Pays africains approvisionnes en vaccins IPD", formula: "Comptage pays destinataires", baseline: "~15", target2027: ">=20", target2032: ">=30", unit: "pays", source: "Registre commercial DOI", frequency: "ANNUAL" },
  { code: "E1.4", category: "EFFECT", pillar: "PRODUCTION", initiative: "Diatropix, SEDAR", name: "Taux de couverture diagnostique TDR", formula: "(TDR distribues / Population cible) x 100", baseline: "<5%", target2027: ">=15%", target2032: ">=40%", unit: "%", source: "Diatropix / SEDAR / OMS", frequency: "ANNUAL" },
  { code: "E1.5", category: "EFFECT", pillar: "PRODUCTION", initiative: "DOI", name: "Delai de mise a disposition des vaccins", formula: "Moyenne delais chaine logistique (jours)", baseline: "~60 jours", target2027: "<45 jours", target2032: "<30 jours", unit: "jours", source: "Registre logistique DOI", frequency: "ANNUAL" },
  // IMPACTS
  { code: "I1.1", category: "IMPACT", pillar: "PRODUCTION", initiative: "Madiba, AfricAmaril", name: "Vies sauvees grace aux vaccins IPD", formula: "Modele epidemiologique", baseline: "A etablir", target2027: "~50 000", target2032: "~200 000", unit: "vies", source: "Modele DREI / OMS", frequency: "ANNUAL" },
  { code: "I1.2", category: "IMPACT", pillar: "PRODUCTION", name: "DALY evitees", formula: "Modele OMS", baseline: "A etablir", target2027: "~500 000", target2032: "~2 Mn", unit: "DALY", source: "Modele DREI / GBD", frequency: "ANNUAL" },
  { code: "I1.3", category: "IMPACT", pillar: "PRODUCTION", name: "Economies pour les systemes de sante africains", formula: "DALY evitees x cout moyen par DALY", baseline: "A etablir", target2027: "~25 M USD", target2032: "~100 M USD", unit: "M USD", source: "Etudes d'impact economique", frequency: "ANNUAL" },
  { code: "I1.4", category: "IMPACT", pillar: "PRODUCTION", name: "Reduction de la dependance vaccinale africaine", formula: "(Doses IPD / Total doses Afrique) x 100", baseline: "<1%", target2027: "~3%", target2032: ">=10%", unit: "%", source: "UA / OMS / Gavi", frequency: "ANNUAL" },
  { code: "I1.5", category: "IMPACT", pillar: "PRODUCTION", name: "Impact sur les revenus des menages", formula: "Reduction cout unitaire x volume x population", baseline: "A etablir", target2027: "~5 USD/menage", target2032: "~15 USD/menage", unit: "USD/menage", source: "Enquetes menages", frequency: "ANNUAL" },

  // ── Pilier 2 : Recherche & innovation ─── EFFETS
  { code: "E2.1", category: "EFFECT", pillar: "RECHERCHE", initiative: "DREI, VRC", name: "Innovations translatees en produits de sante", formula: "Comptage transferts recherche-application", baseline: "~2", target2027: ">=5", target2032: ">=15", unit: "nombre", source: "DREI / VRC / Brevets", frequency: "ANNUAL" },
  { code: "E2.2", category: "EFFECT", pillar: "RECHERCHE", initiative: "VRC", name: "Nouveaux candidats vaccins en developpement", formula: "Comptage molecules en pipeline", baseline: "0", target2027: ">=2", target2032: ">=5", unit: "nombre", source: "Registre VRC", frequency: "ANNUAL" },
  { code: "E2.3", category: "EFFECT", pillar: "RECHERCHE", name: "Recommandations de politique sanitaire influencees", formula: "Comptage citations guidelines OMS/ministeres", baseline: "~3", target2027: ">=8", target2032: ">=15", unit: "nombre", source: "OMS / Ministeres sante", frequency: "ANNUAL" },
  { code: "E2.4", category: "EFFECT", pillar: "RECHERCHE", name: "Indice de notoriete scientifique (H-index)", formula: "H-index Scopus", baseline: "A mesurer", target2027: "+20%", target2032: "+50%", unit: "index", source: "Scopus / Web of Science", frequency: "ANNUAL" },
  // IMPACTS
  { code: "I2.1", category: "IMPACT", pillar: "RECHERCHE", name: "Maladies pour lesquelles l'IPD contribue a des solutions", baseline: "~5", target2027: ">=10", target2032: ">=20", unit: "nombre", source: "Cartographie DREI", frequency: "ANNUAL" },
  { code: "I2.2", category: "IMPACT", pillar: "RECHERCHE", name: "Patients beneficiaires d'innovations IPD", baseline: "A etablir", target2027: "~100 000", target2032: "~1 Mn", unit: "patients", source: "Etudes DREI", frequency: "ANNUAL" },
  { code: "I2.3", category: "IMPACT", pillar: "RECHERCHE", initiative: "MNT", name: "Contribution a la reduction des MNT en Afrique", formula: "Nb protocoles cliniques adoptes", baseline: "0", target2027: ">=2", target2032: ">=8", unit: "protocoles", source: "Ministeres sante / OMS AFRO", frequency: "ANNUAL" },

  // ── Pilier 3 : Epidemies & pandemies ─── EFFETS
  { code: "E3.1", category: "EFFECT", pillar: "SANTE_PUBLIQUE", initiative: "4S", name: "Epidemies detectees precocement", formula: "(Detections <48h / Total) x 100", baseline: "~60%", target2027: ">=80%", target2032: ">=95%", unit: "%", source: "Systeme 4S / DSP", frequency: "ANNUAL" },
  { code: "E3.2", category: "EFFECT", pillar: "SANTE_PUBLIQUE", name: "Delai moyen d'alerte aux autorites", formula: "Moyenne delais (heures)", baseline: "~72h", target2027: "<24h", target2032: "<12h", unit: "heures", source: "Registre alertes DSP", frequency: "QUARTERLY" },
  { code: "E3.3", category: "EFFECT", pillar: "SANTE_PUBLIQUE", name: "Pays disposant de capacites renforcees par l'IPD", baseline: "~5", target2027: ">=10", target2032: ">=20", unit: "pays", source: "Rapports DSP / OMS AFRO", frequency: "ANNUAL" },
  { code: "E3.4", category: "EFFECT", pillar: "SANTE_PUBLIQUE", name: "Personnel de sante forme en gestion des epidemies", baseline: "~500", target2027: "~1 500", target2032: "~5 000", unit: "personnes", source: "Registre formations DSP", frequency: "ANNUAL" },
  // IMPACTS
  { code: "I3.1", category: "IMPACT", pillar: "SANTE_PUBLIQUE", name: "Deces epidemiques evites", formula: "Modele comparatif", baseline: "A etablir", target2027: "~10 000", target2032: "~50 000", unit: "deces evites", source: "Modeles epidemiologiques DREI", frequency: "ANNUAL" },
  { code: "I3.2", category: "IMPACT", pillar: "SANTE_PUBLIQUE", name: "Impact economique des epidemies evitees", formula: "Cout moyen epidemie x nb epidemies contenues", baseline: "A etablir", target2027: "~50 M USD", target2032: "~200 M USD", unit: "M USD", source: "Etudes BM / OMS", frequency: "ANNUAL" },
  { code: "I3.3", category: "IMPACT", pillar: "SANTE_PUBLIQUE", name: "Reduction de l'impact sur les revenus des menages", baseline: "A etablir", target2027: "~15 USD/menage", target2032: "~30 USD/menage", unit: "USD/menage", source: "Enquetes post-epidemie", frequency: "ANNUAL" },
  { code: "I3.4", category: "IMPACT", pillar: "SANTE_PUBLIQUE", name: "Amelioration de la resilience sanitaire regionale (JEE/SPAR)", baseline: "A mesurer", target2027: "+15 pts", target2032: "+30 pts", unit: "points", source: "OMS JEE / IHR", frequency: "ANNUAL" },

  // ── Pilier 4 : Solutions soins de sante ─── EFFETS
  { code: "E4.1", category: "EFFECT", pillar: "SOLUTIONS_SANITAIRES", name: "Patients diagnostiques par les laboratoires IPD", baseline: "~200 000", target2027: "~400 000", target2032: "~1 Mn", unit: "patients", source: "Registres laboratoires DC", frequency: "ANNUAL" },
  { code: "E4.2", category: "EFFECT", pillar: "SOLUTIONS_SANITAIRES", name: "Couverture geographique des services laboratoires", formula: "(Regions couvertes / 14) x 100", baseline: "~25%", target2027: "~50%", target2032: ">=70%", unit: "%", source: "Carte plateformes DC", frequency: "ANNUAL" },
  { code: "E4.3", category: "EFFECT", pillar: "SOLUTIONS_SANITAIRES", name: "Delai moyen de rendu des resultats", baseline: "~48h", target2027: "<24h", target2032: "<12h", unit: "heures", source: "SIL / Registre DC", frequency: "QUARTERLY" },
  { code: "E4.4", category: "EFFECT", pillar: "SOLUTIONS_SANITAIRES", name: "Analyses de securite alimentaire realisees", baseline: "~5 000", target2027: "~15 000", target2032: "~40 000", unit: "analyses", source: "Registre labo securite alim.", frequency: "ANNUAL" },
  // IMPACTS
  { code: "I4.1", category: "IMPACT", pillar: "SOLUTIONS_SANITAIRES", name: "Detection precoce de pathologies", baseline: "A etablir", target2027: "~20 000", target2032: "~80 000", unit: "cas", source: "Etudes DC / DREI", frequency: "ANNUAL" },
  { code: "I4.2", category: "IMPACT", pillar: "SOLUTIONS_SANITAIRES", name: "Economies realisees par les patients", baseline: "A etablir", target2027: "~3 M USD", target2032: "~15 M USD", unit: "M USD", source: "Etudes medico-economiques", frequency: "ANNUAL" },
  { code: "I4.3", category: "IMPACT", pillar: "SOLUTIONS_SANITAIRES", name: "Emplois generes dans les communautes locales", baseline: "~100", target2027: "~300", target2032: "~700", unit: "emplois", source: "Registre RH + enquetes", frequency: "ANNUAL" },
  { code: "I4.4", category: "IMPACT", pillar: "SOLUTIONS_SANITAIRES", name: "Amelioration de la securite sanitaire alimentaire", baseline: "A etablir", target2027: "-20%", target2032: "-40%", unit: "% incidents", source: "Ministere Sante / Commerce", frequency: "ANNUAL" },

  // ── Pilier 5 : Education ─── EFFETS
  { code: "E5.1", category: "EFFECT", pillar: "EDUCATION", initiative: "CARE", name: "Taux d'insertion professionnelle des diplomes", formula: "(Diplomes en emploi / Total) x 100", baseline: "A mesurer", target2027: ">=75%", target2032: ">=85%", unit: "%", source: "Enquetes alumni CARE", frequency: "ANNUAL" },
  { code: "E5.2", category: "EFFECT", pillar: "EDUCATION", initiative: "CARE", name: "Amelioration des competences post-formation", formula: "Evaluation pre/post (score moyen)", baseline: "A etablir", target2027: "+30%", target2032: "+40%", unit: "%", source: "Evaluations CARE", frequency: "ANNUAL" },
  { code: "E5.3", category: "EFFECT", pillar: "EDUCATION", initiative: "CARE", name: "Pays beneficiant de cadres formes par l'IPD", baseline: "~8", target2027: ">=15", target2032: ">=25", unit: "pays", source: "Base alumni CARE", frequency: "ANNUAL" },
  { code: "E5.4", category: "EFFECT", pillar: "EDUCATION", initiative: "CARE", name: "Taux de satisfaction employeurs", formula: "Enquete employeurs, score moyen sur 5", baseline: "A mesurer", target2027: ">=4/5", target2032: ">=4.5/5", unit: "score /5", source: "Enquetes employeurs CARE", frequency: "ANNUAL" },
  // IMPACTS
  { code: "I5.1", category: "IMPACT", pillar: "EDUCATION", name: "Augmentation des revenus des diplomes", formula: "((Salaire post - pre) / pre) x 100", baseline: "A mesurer", target2027: "+25%", target2032: "+40%", unit: "%", source: "Enquetes alumni", frequency: "ANNUAL" },
  { code: "I5.2", category: "IMPACT", pillar: "EDUCATION", name: "Valeur economique cumulee des formations", formula: "Nb diplomes x differentiel salarial x duree", baseline: "A etablir", target2027: "~2 M USD", target2032: "~15 M USD", unit: "M USD", source: "Modele economique CARE", frequency: "ANNUAL" },
  { code: "I5.3", category: "IMPACT", pillar: "EDUCATION", name: "Renforcement des systemes de sante nationaux", formula: "Comptage postes cles occupes par alumni IPD", baseline: "A etablir", target2027: ">=50", target2032: ">=200", unit: "postes", source: "Base alumni CARE", frequency: "ANNUAL" },
  { code: "I5.4", category: "IMPACT", pillar: "EDUCATION", name: "Effet multiplicateur sur les communautes", formula: "Nb personnes formees en cascade par alumni", baseline: "A etablir", target2027: "~500", target2032: "~3 000", unit: "personnes", source: "Enquetes impact CARE", frequency: "ANNUAL" },

  // ── Impacts transversaux ───
  { code: "IT.1", category: "IMPACT", pillar: "TRANSVERSAL", name: "Contribution au PIB national", baseline: "~19 M USD", target2027: "~55 M USD", target2032: "~200 M USD", unit: "M USD", source: "Etude d'impact economique", frequency: "ANNUAL" },
  { code: "IT.2", category: "IMPACT", pillar: "TRANSVERSAL", name: "Emplois totaux generes (directs + indirects)", baseline: "~1 500", target2027: "~3 000", target2032: "~6 000", unit: "emplois", source: "ANSD / IPD DU", frequency: "ANNUAL" },
  { code: "IT.3", category: "IMPACT", pillar: "TRANSVERSAL", name: "Souverainete sanitaire africaine (indice composite)", baseline: "A etablir", target2027: "Indice defini", target2032: "Score eleve", unit: "indice", source: "UA / CDC Afrique", frequency: "ANNUAL" },
  { code: "IT.4", category: "IMPACT", pillar: "TRANSVERSAL", name: "Reduction des inegalites d'acces aux soins", formula: "(Pop rurale avec acces IPD / Pop rurale totale) x 100", baseline: "<5%", target2027: ">=15%", target2032: ">=35%", unit: "%", source: "Enquetes / ANSD", frequency: "ANNUAL" },
  { code: "IT.5", category: "IMPACT", pillar: "TRANSVERSAL", name: "Impact environnemental positif", formula: "(Emissions N - N-1) / N-1 par unite", baseline: "A etablir", target2027: "-10%/unite", target2032: "-25%/unite", unit: "%/unite", source: "Bilan carbone IPD", frequency: "ANNUAL" },
  { code: "IT.6", category: "IMPACT", pillar: "TRANSVERSAL", name: "Egalite de genre dans l'impact", formula: "(Beneficiaires femmes / Total) x 100", baseline: "A mesurer", target2027: ">=45%", target2032: ">=50%", unit: "%", source: "Rapports genre IPD", frequency: "ANNUAL" },

  // ═══════════════════════════════════════════════════════════════
  // PARTIE II — INDICATEURS OPERATIONNELS PAR SERVICE
  // ═══════════════════════════════════════════════════════════════

  // ── DPC — Partenariats et Mobilisation ──
  { code: "OP-DPC-01", category: "OPERATIONAL", department: "DPC", subUnit: "Partenariats et Mobilisation", name: "Nombre de partenariats strategiques etablis", formula: "Comptage accords signes", frequency: "ANNUAL", responsible: "DPC / RPPMR", target2025: ">=5", target2027: ">=8", source: "CRM Zoho / Base DPC" },
  { code: "OP-DPC-02", category: "OPERATIONAL", department: "DPC", subUnit: "Partenariats et Mobilisation", name: "Montant des ressources financieres mobilisees", formula: "Somme decaissements + engagements", frequency: "ANNUAL", responsible: "DPC / RPPMR", target2025: ">=3 M USD", target2027: ">=5 M USD", unit: "M USD", source: "Rapport financier / DFC" },
  { code: "OP-DPC-03", category: "OPERATIONAL", department: "DPC", subUnit: "Partenariats et Mobilisation", name: "Taux de satisfaction des partenaires", formula: "Moyenne scores echelle 1-5, en %", frequency: "ANNUAL", responsible: "DPC / RPSEID", target2025: ">=75%", target2027: ">=85%", unit: "%", source: "Enquete satisfaction SEID" },
  { code: "OP-DPC-04", category: "OPERATIONAL", department: "DPC", subUnit: "Partenariats et Mobilisation", name: "Pipeline d'opportunites de financement", formula: "Comptage dossiers dans pipeline CRM", frequency: "QUARTERLY", responsible: "DPC / RPPMR", target2025: ">=10", target2027: ">=15", source: "CRM Zoho" },
  { code: "OP-DPC-05", category: "OPERATIONAL", department: "DPC", subUnit: "Partenariats et Mobilisation", name: "Taux de conversion des propositions", formula: "(Financements obtenus / Propositions soumises) x 100", frequency: "ANNUAL", responsible: "DPC / CGPS", target2025: ">=30%", target2027: ">=40%", unit: "%", source: "Registre projets DPC" },
  // ── DPC — Communication ──
  { code: "OP-DPC-06", category: "OPERATIONAL", department: "DPC", subUnit: "Communication", name: "Nombre d'evenements organises", frequency: "QUARTERLY", responsible: "DPC / RPCEM", target2025: ">=4/an", target2027: ">=6/an", source: "Calendrier evenementiel DPC" },
  { code: "OP-DPC-07", category: "OPERATIONAL", department: "DPC", subUnit: "Communication", name: "Engagement reseaux sociaux", formula: "Somme interactions toutes plateformes", frequency: "MONTHLY", responsible: "DPC / ICM", target2025: ">=600/an", target2027: ">=744/an", source: "Analytics reseaux sociaux" },
  { code: "OP-DPC-08", category: "OPERATIONAL", department: "DPC", subUnit: "Communication", name: "Couverture mediatique", formula: "Comptage mentions via outils de veille", frequency: "QUARTERLY", responsible: "DPC / RPCEM", target2025: ">=70", target2027: ">=100", source: "Outils monitoring medias" },
  // ── DPC — Subventions et Projets ──
  { code: "OP-DPC-13", category: "OPERATIONAL", department: "DPC", subUnit: "Subventions et Projets", name: "Nombre de projets finances et actifs", frequency: "QUARTERLY", responsible: "DPC / CGPS", target2025: ">=7", target2027: ">=7", source: "CRM Zoho Projects" },
  { code: "OP-DPC-14", category: "OPERATIONAL", department: "DPC", subUnit: "Subventions et Projets", name: "Taux de realisation des objectifs projets", formula: "(Objectifs atteints / Objectifs planifies) x 100", frequency: "SEMI_ANNUAL", responsible: "DPC / CGPS", target2025: ">=70%", target2027: ">=80%", unit: "%", source: "Rapports projets" },
  { code: "OP-DPC-15", category: "OPERATIONAL", department: "DPC", subUnit: "Subventions et Projets", name: "Respect des delais et budgets", formula: "(Projets conformes / Total) x 100", frequency: "QUARTERLY", responsible: "DPC / CGPS", target2025: ">=70%", target2027: ">=80%", unit: "%", source: "Rapports financiers projets" },
  // ── DPC — SEID ──
  { code: "OP-DPC-18", category: "OPERATIONAL", department: "DPC", subUnit: "SEID", name: "Nombre de rapports d'evaluation produits", frequency: "QUARTERLY", responsible: "DPC / RPSEID", target2025: ">=4/an", target2027: ">=8/an", source: "Archives SEID" },
  { code: "OP-DPC-19", category: "OPERATIONAL", department: "DPC", subUnit: "SEID", name: "Tableaux de bord d'aide a la decision", frequency: "SEMI_ANNUAL", responsible: "DPC / RPSEID", target2025: ">=2", target2027: ">=4", source: "Command Center SEID" },

  // ── DREI ──
  { code: "OP-DREI-22", category: "OPERATIONAL", department: "DREI", name: "Publications scientifiques indexees", formula: "Comptage PubMed/Scopus", frequency: "ANNUAL", responsible: "DREI", target2025: ">=80", target2027: ">=90", source: "Base Publications IPD" },
  { code: "OP-DREI-23", category: "OPERATIONAL", department: "DREI", name: "Facteur d'impact moyen", formula: "Somme IF / Nb publications", frequency: "ANNUAL", responsible: "DREI", target2025: ">=5", target2027: ">=6", unit: "IF", source: "JCR / Scopus" },
  { code: "OP-DREI-24", category: "OPERATIONAL", department: "DREI", name: "Essais cliniques actifs", frequency: "SEMI_ANNUAL", responsible: "DREI / VRC", target2025: "1", target2027: "2-3", source: "Registre essais cliniques" },
  { code: "OP-DREI-25", category: "OPERATIONAL", department: "DREI", name: "Projets financement international soumis", frequency: "ANNUAL", responsible: "DREI / GO", target2025: ">=5", target2027: ">=8", source: "Grant Office" },
  { code: "OP-DREI-28", category: "OPERATIONAL", department: "DREI", name: "Co-publications internationales", formula: "Comptage co-publications affiliation etrangere", frequency: "ANNUAL", responsible: "DREI", target2025: ">=40%", target2027: ">=50%", unit: "%", source: "Scopus / Web of Science" },

  // ── DCH ──
  { code: "OP-DCH-29", category: "OPERATIONAL", department: "DCH", name: "ETP permanents recrutes", frequency: "ANNUAL", responsible: "DCH", target2025: ">=50 cumules", target2027: ">=100 cumules", source: "Registre RH / DCH" },
  { code: "OP-DCH-30", category: "OPERATIONAL", department: "DCH", name: "Effectifs totaux IPD", frequency: "ANNUAL", responsible: "DCH", target2025: "~620", target2027: "~700", unit: "ETP", source: "SIRH IPD" },
  { code: "OP-DCH-31", category: "OPERATIONAL", department: "DCH", name: "Taux de formation du personnel", formula: "(Staff forme / Effectif total) x 100", frequency: "ANNUAL", responsible: "DCH", target2025: ">=75%", target2027: ">=85%", unit: "%", source: "Plans de formation DCH" },
  { code: "OP-DCH-34", category: "OPERATIONAL", department: "DCH", name: "Taux de retention du personnel cle", formula: "(Personnel cle en poste / Total) x 100", frequency: "ANNUAL", responsible: "DCH", target2025: ">=90%", target2027: ">=92%", unit: "%", source: "SIRH IPD" },

  // ── DOI ──
  { code: "OP-DOI-35", category: "OPERATIONAL", department: "DOI", name: "Production vaccins fievre jaune", formula: "Comptage doses (lot release)", frequency: "ANNUAL", responsible: "DOI", target2025: ">=8 Mn doses", target2027: ">=10 Mn doses", unit: "doses", source: "Dir. Production / OMS" },
  { code: "OP-DOI-36", category: "OPERATIONAL", department: "DOI", name: "Production diagnostics (SEDAR)", formula: "Comptage unites liberees", frequency: "ANNUAL", responsible: "DOI / Diatropix", target2025: ">=10 Mn unites", target2027: ">=30 Mn unites", unit: "unites", source: "Diatropix / SEDAR" },
  { code: "OP-DOI-37", category: "OPERATIONAL", department: "DOI", name: "Conformite BPF / OMS", formula: "Score audit BPF", frequency: "ANNUAL", responsible: "DOI", target2025: "Conforme", target2027: "Conforme", source: "Rapport audit OMS / BPF" },
  { code: "OP-DOI-38", category: "OPERATIONAL", department: "DOI", name: "Taux de rejet de lots", formula: "(Lots rejetes / Total lots) x 100", frequency: "QUARTERLY", responsible: "DOI", target2025: "<5%", target2027: "<3%", unit: "%", source: "Registre production DOI" },
  { code: "OP-DOI-39", category: "OPERATIONAL", department: "DOI", initiative: "Madiba", name: "Avancement projet Madiba", formula: "% jalons atteints", frequency: "SEMI_ANNUAL", responsible: "DOI / CAS", target2025: "30%", target2027: "60%", unit: "%", source: "Comite pilotage Madiba" },
  { code: "OP-DOI-40", category: "OPERATIONAL", department: "DOI", initiative: "AfricAmaril", name: "Avancement projet AfricAmaril", formula: "% jalons atteints", frequency: "SEMI_ANNUAL", responsible: "DOI / CAS", target2025: "50%", target2027: "85%", unit: "%", source: "Comite pilotage AfricAmaril" },

  // ── DSP ──
  { code: "OP-DSP-41", category: "OPERATIONAL", department: "DSP", initiative: "4S", name: "Sites de surveillance actifs", formula: "Comptage sites fonctionnels", frequency: "ANNUAL", responsible: "DSP", target2025: ">=40", target2027: ">=60", source: "Direction Epidemies" },
  { code: "OP-DSP-42", category: "OPERATIONAL", department: "DSP", name: "Pays africains soutenus", formula: "Comptage pays avec accord actif", frequency: "ANNUAL", responsible: "DSP", target2025: ">=25", target2027: ">=30", unit: "pays", source: "Registre DSP" },
  { code: "OP-DSP-43", category: "OPERATIONAL", department: "DSP", name: "Alertes epidemiques traitees", formula: "Comptage alertes traitees", frequency: "QUARTERLY", responsible: "DSP", target2025: ">=50", target2027: ">=75", source: "Systeme 4S" },
  { code: "OP-DSP-44", category: "OPERATIONAL", department: "DSP", name: "Delai moyen de reponse", formula: "Moyenne delais (heures)", frequency: "QUARTERLY", responsible: "DSP", target2025: "<48h", target2027: "<24h", unit: "heures", source: "Registre interventions DSP" },

  // ── CARE / Education ──
  { code: "OP-CARE-45", category: "OPERATIONAL", department: "CARE", initiative: "CARE", name: "Etudiants formes par an", formula: "Comptage inscrits valides", frequency: "ANNUAL", responsible: "CARE / DREI", target2025: ">=50", target2027: ">=100", source: "Registre Centre CARE" },
  { code: "OP-CARE-46", category: "OPERATIONAL", department: "CARE", initiative: "CARE", name: "Programmes de formation offerts", frequency: "ANNUAL", responsible: "CARE / DREI", target2025: ">=5", target2027: ">=10", source: "Catalogue CARE" },
  { code: "OP-CARE-47", category: "OPERATIONAL", department: "CARE", name: "Taux de satisfaction des formes", formula: "Enquete post-formation sur 5", frequency: "ANNUAL", responsible: "CARE / DREI", target2025: ">=4/5", target2027: ">=4.5/5", unit: "score /5", source: "Enquetes CARE" },

  // ── DFC ──
  { code: "OP-DFC-49", category: "OPERATIONAL", department: "DFC", name: "Revenu annuel total", formula: "Consolidation revenus audites", frequency: "ANNUAL", responsible: "DFC", target2025: "~35 M USD", target2027: "~55 M USD", unit: "M USD", source: "Rapport financier annuel" },
  { code: "OP-DFC-50", category: "OPERATIONAL", department: "DFC", name: "Taux d'execution budgetaire", formula: "(Depenses / Budget) x 100", frequency: "QUARTERLY", responsible: "DFC", target2025: ">=85%", target2027: ">=90%", unit: "%", source: "Comptabilite analytique" },
  { code: "OP-DFC-51", category: "OPERATIONAL", department: "DFC", name: "Delai de cloture comptable", formula: "Comptage jours calendaires", frequency: "ANNUAL", responsible: "DFC", target2025: "<90 jours", target2027: "<60 jours", unit: "jours", source: "Calendrier comptable DFC" },

  // ── DDSI ──
  { code: "OP-DDSI-53", category: "OPERATIONAL", department: "DDSI", name: "Taux de disponibilite SI", formula: "(Temps fonctionnement / Total) x 100", frequency: "MONTHLY", responsible: "DDSI", target2025: ">=99%", target2027: ">=99.5%", unit: "%", source: "Monitoring DDSI" },
  { code: "OP-DDSI-54", category: "OPERATIONAL", department: "DDSI", name: "Avancement ERP", formula: "% modules deployes", frequency: "SEMI_ANNUAL", responsible: "DDSI / CAS", target2025: "40%", target2027: "80%", unit: "%", source: "Comite pilotage ERP" },

  // ── DAL ──
  { code: "OP-DAL-56", category: "OPERATIONAL", department: "DAL", name: "Delai moyen traitement achats", formula: "Moyenne delais (jours)", frequency: "QUARTERLY", responsible: "DAL", target2025: "<30 jours", target2027: "<21 jours", unit: "jours", source: "Registre achats DAL" },

  // ── DC ──
  { code: "OP-DC-58", category: "OPERATIONAL", department: "DC", name: "Chiffre d'affaires solutions sante", frequency: "QUARTERLY", responsible: "DC", target2025: "En progression", target2027: "+15% vs N-1", source: "Comptabilite analytique DC" },
  { code: "OP-DC-59", category: "OPERATIONAL", department: "DC", name: "Plateformes laboratoires operationnelles", frequency: "ANNUAL", responsible: "DC / DRO", target2025: "~6", target2027: "~8", source: "Registre DC" },

  // ── DRO ──
  { code: "OP-DRO-61", category: "OPERATIONAL", department: "DRO", name: "Taux de maintenance preventive", formula: "(Equip maintenus / Total) x 100", frequency: "SEMI_ANNUAL", responsible: "DRO", target2025: ">=80%", target2027: ">=90%", unit: "%", source: "Plan maintenance DRO" },
  { code: "OP-DRO-62", category: "OPERATIONAL", department: "DRO", name: "Disponibilite equipements critiques", formula: "(Temps fonctionnel / Total) x 100", frequency: "QUARTERLY", responsible: "DRO", target2025: ">=95%", target2027: ">=97%", unit: "%", source: "Registre DRO" },

  // ── Gouvernance ──
  { code: "OP-GOV-63", category: "OPERATIONAL", department: "GOV", name: "Score global ANAQSup (COR)", frequency: "ANNUAL", responsible: "CI / CAS", target2025: "En cours", target2027: "Accredite", source: "Rapport audit ANAQSup" },
  { code: "OP-GOV-65", category: "OPERATIONAL", department: "GOV", name: "Rapport annuel IPD publie", frequency: "ANNUAL", responsible: "DPC / AG", target2025: "Avant mars", target2027: "Avant mars", source: "Rapport annuel officiel" },
  { code: "OP-GOV-68", category: "OPERATIONAL", department: "GOV", name: "Taux de conformite GFGP", formula: "(Projets conformes / Total) x 100", frequency: "ANNUAL", responsible: "DPC / DFC", target2025: ">=70%", target2027: ">=85%", unit: "%", source: "Audits GFGP" },

  // ── Projets strategiques ──
  { code: "OP-PROJ-69", category: "OPERATIONAL", department: "PROJETS", initiative: "Madiba", name: "Recrutements pour MADIBA", frequency: "SEMI_ANNUAL", responsible: "DCH / CAS", target2025: "Selon plan", target2027: "Selon plan", source: "Registre RH Madiba" },
  { code: "OP-PROJ-70", category: "OPERATIONAL", department: "PROJETS", initiative: "RTH", name: "Centre africain bio-production (RTH)", formula: "Jalons atteints", frequency: "ANNUAL", responsible: "DOI / CAS", target2025: "Inaugure", target2027: "Operationnel", source: "Comite pilotage Madiba" },
  { code: "OP-PROJ-71", category: "OPERATIONAL", department: "PROJETS", initiative: "RTH, CARE", name: "Formations bio-production dispensees", frequency: "SEMI_ANNUAL", responsible: "CARE / DOI", target2025: ">=4", target2027: ">=8", source: "Registre formations RTH" },
];

async function main() {
  console.log("Seeding indicators...");

  // Clear existing
  await prisma.indicatorValue.deleteMany();
  await prisma.indicator.deleteMany();

  let count = 0;
  for (const ind of INDICATORS) {
    await prisma.indicator.create({ data: ind });
    count++;
  }

  console.log(`Created ${count} indicators`);

  // Summary
  const effects = INDICATORS.filter(i => i.category === "EFFECT").length;
  const impacts = INDICATORS.filter(i => i.category === "IMPACT").length;
  const ops = INDICATORS.filter(i => i.category === "OPERATIONAL").length;

  console.log(`
  Effets (outcomes):   ${effects}
  Impacts:             ${impacts}
  Operationnels:       ${ops}
  Total:               ${count}
  `);
}

main().catch(console.error).finally(() => prisma.$disconnect());
