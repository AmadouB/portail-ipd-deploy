import { PrismaClient } from "../src/generated/prisma/client";
import { PrismaBetterSqlite3 } from "@prisma/adapter-better-sqlite3";
import path from "path";

const dbPath = path.resolve(__dirname, "..", "dev.db");
const adapter = new PrismaBetterSqlite3({ url: dbPath });
const prisma = new PrismaClient({ adapter } as any);

const ALL_REGIONS = ["DAKAR","THIES","DIOURBEL","SAINT_LOUIS","TAMBACOUNDA","KAOLACK","LOUGA","FATICK","KOLDA","MATAM","KAFFRINE","KEDOUGOU","SEDHIOU","ZIGUINCHOR"];

// Region coordinates for project location
const REGION_COORDS: Record<string, { lat: number; lng: number }> = {
  DAKAR: { lat: 14.7167, lng: -17.4677 },
  THIES: { lat: 14.7886, lng: -16.9260 },
  DIOURBEL: { lat: 14.6553, lng: -16.2314 },
  SAINT_LOUIS: { lat: 16.0326, lng: -16.4818 },
  TAMBACOUNDA: { lat: 13.7707, lng: -13.6673 },
  KAOLACK: { lat: 14.1520, lng: -16.0726 },
  LOUGA: { lat: 15.6167, lng: -16.2333 },
  FATICK: { lat: 14.3333, lng: -16.4000 },
  KOLDA: { lat: 12.8833, lng: -14.9500 },
  MATAM: { lat: 15.6559, lng: -13.2554 },
  KAFFRINE: { lat: 14.1058, lng: -15.5500 },
  KEDOUGOU: { lat: 12.5605, lng: -12.1747 },
  SEDHIOU: { lat: 12.7081, lng: -15.5569 },
  ZIGUINCHOR: { lat: 12.5833, lng: -16.2719 },
};

// Assignment logic based on pillar and department
function getRegions(pillar: string, dept: string | null, name: string): string[] {
  const n = name.toLowerCase();

  // Production projects: mainly Dakar (factories) + some distribution
  if (pillar === "PRODUCTION") {
    if (n.includes("madiba") || n.includes("sedar") || n.includes("africamaril")) return ["DAKAR"];
    if (n.includes("diatropix")) return ["DAKAR", "THIES"];
    if (n.includes("mrna") || n.includes("avbl")) return ["DAKAR"];
    // Distribution projects cover more regions
    return pick(["DAKAR", "THIES", "SAINT_LOUIS"], 1, 3);
  }

  // Sante publique: surveillance covers many regions
  if (pillar === "SANTE_PUBLIQUE") {
    if (n.includes("4s") || n.includes("sentinelle") || n.includes("surveillance")) {
      return pick(ALL_REGIONS, 5, 10); // Wide surveillance network
    }
    if (n.includes("malaria") || n.includes("paludisme")) {
      return pick(["TAMBACOUNDA", "KEDOUGOU", "KOLDA", "SEDHIOU", "ZIGUINCHOR", "FATICK", "KAOLACK", "KAFFRINE"], 3, 6);
    }
    if (n.includes("epidemic") || n.includes("global health") || n.includes("ghsa")) {
      return pick(ALL_REGIONS, 4, 8);
    }
    return pick(["DAKAR", "THIES", "SAINT_LOUIS", "KAOLACK", "ZIGUINCHOR", "TAMBACOUNDA"], 2, 4);
  }

  // Recherche: mostly Dakar-based labs
  if (pillar === "RECHERCHE") {
    if (n.includes("terrain") || n.includes("field")) return pick(["DAKAR", "THIES", "SAINT_LOUIS", "KEDOUGOU", "TAMBACOUNDA"], 2, 4);
    if (n.includes("arbo") || n.includes("zoonot")) return pick(["DAKAR", "KEDOUGOU", "TAMBACOUNDA", "KOLDA", "ZIGUINCHOR"], 2, 4);
    return pick(["DAKAR"], 1, 1); // Lab-based
  }

  // Education: CARE center in Dakar + some regional training
  if (pillar === "EDUCATION") {
    if (n.includes("resaolab") || n.includes("formation")) return pick(["DAKAR", "THIES", "SAINT_LOUIS", "KAOLACK"], 2, 4);
    return pick(["DAKAR", "THIES"], 1, 2);
  }

  // Solutions sanitaires: labs expanding across regions
  if (pillar === "SOLUTIONS_SANITAIRES") {
    return pick(["DAKAR", "THIES", "SAINT_LOUIS", "KAOLACK", "ZIGUINCHOR", "TAMBACOUNDA", "DIOURBEL"], 2, 5);
  }

  // Transformation: institutional, mainly Dakar
  if (pillar === "TRANSFORMATION") {
    return ["DAKAR"];
  }

  // Default
  return pick(["DAKAR", "THIES"], 1, 2);
}

function pick(arr: string[], min: number, max: number): string[] {
  const n = Math.floor(Math.random() * (max - min + 1)) + min;
  const shuffled = [...arr].sort(() => Math.random() - 0.5);
  return shuffled.slice(0, Math.min(n, arr.length));
}

async function main() {
  const projects = await prisma.project.findMany();
  let updated = 0;

  for (const p of projects) {
    const regions = getRegions(p.pillar, p.departmentLead, p.projectName);
    const primaryRegion = regions[0];
    const coords = REGION_COORDS[primaryRegion];

    await prisma.project.update({
      where: { id: p.id },
      data: {
        regions: regions.join(","),
        latitude: coords.lat + (Math.random() - 0.5) * 0.3,
        longitude: coords.lng + (Math.random() - 0.5) * 0.3,
      },
    });
    updated++;
  }

  // Summary
  const regionCounts: Record<string, number> = {};
  const updatedProjects = await prisma.project.findMany();
  for (const p of updatedProjects) {
    if (p.regions) {
      for (const r of p.regions.split(",")) {
        regionCounts[r] = (regionCounts[r] || 0) + 1;
      }
    }
  }

  console.log(`Updated ${updated} projects with regions\n`);
  console.log("=== PROJETS PAR REGION ===");
  for (const [region, count] of Object.entries(regionCounts).sort((a, b) => b[1] - a[1])) {
    const bar = "█".repeat(Math.min(count, 40));
    console.log(`  ${region.padEnd(15)} ${String(count).padStart(3)}  ${bar}`);
  }
}

main().catch(console.error).finally(() => prisma.$disconnect());
