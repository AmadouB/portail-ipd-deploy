/**
 * Import script for IPD Partnerships Tracking Dashboard Excel
 * Imports 163 partners and 249 project streams from the Excel tracker
 */
import { PrismaClient } from "../src/generated/prisma/client";
import { PrismaBetterSqlite3 } from "@prisma/adapter-better-sqlite3";
import { hashSync } from "bcryptjs";
import path from "path";
import * as XLSX from "xlsx";

const dbPath = path.resolve(__dirname, "..", "dev.db");
const adapter = new PrismaBetterSqlite3({ url: dbPath });
const prisma = new PrismaClient({ adapter } as any);

const EXCEL_PATH = "/Users/amadou/Downloads/20250528 - Partnerships tracking dashboard23012026.xlsx";

// ─── MAPPING TABLES ──────────────────────────────────────
const PILLAR_MAP: Record<string, string> = {
  "Biomedical research & Innovation": "RECHERCHE",
  "Vaccine and Diagnostic Production": "PRODUCTION",
  "Vaccine and Diagnostic Production\u00a0": "PRODUCTION",
  "Public Health, Epidemiological Surveillance, and Epidemic Response": "SANTE_PUBLIQUE",
  "Public Health, Epidemiological Surveillance, and Epidemic Response\u00a0": "SANTE_PUBLIQUE",
  "Education, Training, and Talent Development": "EDUCATION",
  "Education, Training, and Talent Development\u00a0": "EDUCATION",
  "Healthcare Solutions and Specialized Laboratories": "SOLUTIONS_SANITAIRES",
  "Healthcare Solutions and Specialized Laboratories\u00a0": "SOLUTIONS_SANITAIRES",
  "Institutional transformation & Operational Excellence": "TRANSFORMATION",
};

const TYPE_MAP: Record<string, string> = {
  "Foundations and Corporate Philanthropy": "FONDATION",
  "Foundations and Corporate Philanthropy ": "FONDATION",
  "Financial Institutions": "INSTITUTION_FINANCIERE",
  "Financial Institutions ": "INSTITUTION_FINANCIERE",
  "Governments and Government Agencies": "GOUVERNEMENT",
  "Governments and Government Agencies ": "GOUVERNEMENT",
  "Non-profit public health organisations and alliances": "ONG_SANTE",
  "Non-profit public health organisations and alliances ": "ONG_SANTE",
  "Academia": "ACADEMIE",
  "Industry": "INDUSTRIE",
};

const TIER_MAP: Record<string, string> = {
  "Fund>=20": "TIER1",
  "5=<Fund<20M": "TIER1",
  "1M=<Fund<5M": "TIER2",
  "Fund<1M": "TIER3",
};

const CRITICALITY_MAP: Record<string, string> = {
  "High": "HIGH",
  "Medium": "MEDIUM",
  "Low": "LOW",
  "high": "HIGH",
  "medium": "MEDIUM",
  "low": "LOW",
};

// Known partner coordinates (manual geocoding for key partners)
const PARTNER_COORDS: Record<string, { lat: number; lng: number; city: string; country: string }> = {
  "Gates Foundation (BMGF)": { lat: 47.6062, lng: -122.3321, city: "Seattle", country: "USA" },
  "GAVI": { lat: 46.2100, lng: 6.1400, city: "Geneve", country: "Suisse" },
  "CEPI": { lat: 59.9139, lng: 10.7522, city: "Oslo", country: "Norvege" },
  "PATH": { lat: 47.6205, lng: -122.3493, city: "Seattle", country: "USA" },
  "FIND": { lat: 46.2180, lng: 6.1290, city: "Geneve", country: "Suisse" },
  "Unitaid": { lat: 46.2300, lng: 6.1500, city: "Geneve", country: "Suisse" },
  "World Health Organisation (WHO/OMS)": { lat: 46.2276, lng: 6.0910, city: "Geneve", country: "Suisse" },
  "National Institutes of Health (NIH)": { lat: 38.9959, lng: -77.0964, city: "Bethesda", country: "USA" },
  "European Union  - European Commission": { lat: 50.8503, lng: 4.3517, city: "Bruxelles", country: "Belgique" },
  "Mastercard Foundation": { lat: 43.6532, lng: -79.3832, city: "Toronto", country: "Canada" },
  "Fondation Mérieux": { lat: 45.7640, lng: 4.8357, city: "Lyon", country: "France" },
  "Institut de Recherche pour le Développement (IRD)": { lat: 43.2965, lng: 5.3698, city: "Marseille", country: "France" },
  "Agence française de Développement  (AFD)": { lat: 48.8566, lng: 2.3522, city: "Paris", country: "France" },
  "BARDA": { lat: 38.8951, lng: -77.0364, city: "Washington DC", country: "USA" },
  "USAID": { lat: 38.8930, lng: -77.0170, city: "Washington DC", country: "USA" },
  "Centers for Disease Control and Prevention (CDC)": { lat: 33.7990, lng: -84.3285, city: "Atlanta", country: "USA" },
  "Wellcome Trust": { lat: 51.5267, lng: -0.1290, city: "Londres", country: "UK" },
  "World Bank": { lat: 38.8990, lng: -77.0420, city: "Washington DC", country: "USA" },
  "The Global Fund": { lat: 46.2200, lng: 6.1350, city: "Geneve", country: "Suisse" },
  "Ministère de la Santé et de l'Action Sociale du Sénégal (MSAS)": { lat: 14.7167, lng: -17.4677, city: "Dakar", country: "Senegal" },
  "Foreign, Commonwealth & Development Office": { lat: 51.5074, lng: -0.1278, city: "Londres", country: "UK" },
  "Africa Center for disease control": { lat: 9.0054, lng: 38.7636, city: "Addis Abeba", country: "Ethiopie" },
  "African Union  - Africa Center for disease control + PAVM": { lat: 9.0054, lng: 38.7636, city: "Addis Abeba", country: "Ethiopie" },
  "African Development Bank (AfDB)": { lat: 5.3600, lng: -4.0083, city: "Abidjan", country: "Cote d'Ivoire" },
  "Lux-Development S.A.": { lat: 49.6117, lng: 6.1319, city: "Luxembourg", country: "Luxembourg" },
  "Korean International Cooperation Agency (KOICA)": { lat: 37.5665, lng: 126.9780, city: "Seoul", country: "Coree du Sud" },
  "Japan International Cooperation Agency (JICA)": { lat: 35.6762, lng: 139.6503, city: "Tokyo", country: "Japon" },
  "Novavax": { lat: 39.0437, lng: -77.1141, city: "Gaithersburg", country: "USA" },
  "bioMérieux": { lat: 45.7640, lng: 4.8357, city: "Lyon", country: "France" },
  "Clinton Health Access Initiative (CHAI)": { lat: 42.3601, lng: -71.0589, city: "Boston", country: "USA" },
};

// Default Dakar coordinates for Senegalese/unknown partners
const DAKAR = { lat: 14.6928, lng: -17.4467 };

function clean(val: any): string {
  if (val === null || val === undefined) return "";
  return String(val).replace(/\u00a0/g, " ").trim();
}

function cleanNum(val: any): number {
  if (val === null || val === undefined || val === "") return 0;
  const n = Number(val);
  return isNaN(n) ? 0 : n;
}

function parseDate(val: any): Date | null {
  if (!val) return null;
  if (val instanceof Date) return val;

  // Excel serial number (number between ~1 and ~60000)
  if (typeof val === "number" && val > 1 && val < 100000) {
    // Excel epoch: Jan 0, 1900 (with the Lotus 1-2-3 leap year bug)
    const excelEpoch = new Date(1899, 11, 30); // Dec 30, 1899
    const d = new Date(excelEpoch.getTime() + val * 86400000);
    if (!isNaN(d.getTime()) && d.getFullYear() >= 1990 && d.getFullYear() <= 2040) {
      return d;
    }
    return null;
  }

  const s = String(val).trim();
  if (s.length === 4 && /^\d{4}$/.test(s)) return new Date(`${s}-01-01`);
  const d = new Date(s);
  return isNaN(d.getTime()) ? null : d;
}

async function main() {
  console.log("Starting import from Excel...\n");

  const wb = XLSX.readFile(EXCEL_PATH, { cellDates: true });

  // ─── STEP 1: Clear existing data ──────────────────────
  console.log("Clearing existing data...");
  await prisma.prospectionNote.deleteMany();
  await prisma.monitoringEntry.deleteMany();
  await prisma.mediaFile.deleteMany();
  await prisma.risk.deleteMany();
  await prisma.milestone.deleteMany();
  await prisma.contact.deleteMany();
  await prisma.auditLog.deleteMany();
  await prisma.project.deleteMany();
  await prisma.partner.deleteMany();
  // Keep users

  // ─── STEP 2: Import Partners ──────────────────────────
  console.log("\nImporting partners...");
  const partnersSheet = wb.Sheets["List of partners"];
  const partnersData = XLSX.utils.sheet_to_json<any>(partnersSheet, { header: 1, range: 6 });

  const partnerMap = new Map<string, string>(); // partner name -> id
  const partnerIdMap = new Map<number, string>(); // excel id -> prisma id
  let partnerCount = 0;

  for (const row of partnersData) {
    const acronym = clean(row[1]);
    const name = clean(row[2]);
    const idPartner = cleanNum(row[3]);
    const contribution = clean(row[4]);
    const partnerType = clean(row[5]);
    const city = clean(row[8]);
    const country = clean(row[9]);

    if (!name || name === "nan") continue;

    const coords = PARTNER_COORDS[name] || (country === "Sénégal" || country === "Senegal" ? { ...DAKAR, city: city || "Dakar", country: "Senegal" } : null);

    const tier = TIER_MAP[contribution] || "TIER3";
    const type = TYPE_MAP[partnerType] || "ONG_SANTE";

    try {
      const partner = await prisma.partner.create({
        data: {
          name,
          acronym: acronym || null,
          type,
          country: coords?.country || country || "Unknown",
          city: coords?.city || city || null,
          tier,
          latitude: coords?.lat || null,
          longitude: coords?.lng || null,
        },
      });

      partnerMap.set(name, partner.id);
      if (idPartner) partnerIdMap.set(idPartner, partner.id);
      partnerCount++;
    } catch (e: any) {
      // Skip duplicates
    }
  }

  console.log(`  Imported ${partnerCount} partners`);

  // ─── STEP 3: Import Projects/Streams ──────────────────
  console.log("\nImporting projects/streams...");
  const trackerSheet = wb.Sheets["Partnerships Tracker - Extented"];
  const trackerData = XLSX.utils.sheet_to_json<any>(trackerSheet, { header: 1, range: 5 });

  let projectCount = 0;
  let skipped = 0;

  for (const row of trackerData) {
    const idPartner = cleanNum(row[1]);
    const idStream = clean(row[2]);
    const tier = clean(row[3]);
    const partnerName = clean(row[4]);
    const pillar = clean(row[5]);
    const subPillar = clean(row[6]);
    const partnerType = clean(row[7]);
    const contractType = clean(row[8]);
    const totalGrantM = cleanNum(row[9]);
    const projectName = clean(row[10]);
    const departmentLead = clean(row[11]);
    const divisionLead = clean(row[12]);

    // Contacts
    const partnershipLead = clean(row[13]);
    const financeManager = clean(row[14]);
    const grantManager = clean(row[15]);
    const partnershipTeam = clean(row[16]);
    const partnerRep = clean(row[17]);
    const partnerRepContact = clean(row[18]);

    // Objectives
    const objectives = clean(row[19]);
    const deliverables = clean(row[20]);
    const pastActivities = clean(row[21]);
    const upcomingActions = clean(row[22]);

    // Risks
    const risksList = clean(row[23]);
    const mitigationActions = clean(row[24]);
    const criticality = clean(row[25]);

    // Duration
    let yearOfSignature: number | null = null;
    const rawYear = row[26];
    if (rawYear instanceof Date) {
      yearOfSignature = rawYear.getFullYear();
    } else if (typeof rawYear === "number") {
      yearOfSignature = rawYear > 2000 && rawYear < 2050 ? rawYear : null;
    } else if (typeof rawYear === "string" && /^\d{4}$/.test(rawYear.trim())) {
      yearOfSignature = parseInt(rawYear.trim());
    }
    const duration = clean(row[27]);
    const beginDate = parseDate(row[28]);
    const endDate = parseDate(row[29]);
    const grantType = clean(row[30]);
    const grantLink = clean(row[31]);
    const budgetCode = clean(row[32]);
    const annualAmount = cleanNum(row[33]);

    if (!partnerName) {
      skipped++;
      continue;
    }

    // Find partner by name or by ID
    let partnerId = partnerMap.get(partnerName);
    if (!partnerId && idPartner) {
      partnerId = partnerIdMap.get(idPartner);
    }
    if (!partnerId) {
      // Try partial match
      for (const [name, id] of partnerMap.entries()) {
        if (name.includes(partnerName) || partnerName.includes(name)) {
          partnerId = id;
          break;
        }
      }
    }
    if (!partnerId) {
      // Create partner on the fly
      const type = TYPE_MAP[partnerType] || "ONG_SANTE";
      const t = TIER_MAP[tier] || "TIER3";
      try {
        const newPartner = await prisma.partner.create({
          data: { name: partnerName, type, country: "Unknown", tier: t },
        });
        partnerId = newPartner.id;
        partnerMap.set(partnerName, partnerId);
        partnerCount++;
      } catch {
        skipped++;
        continue;
      }
    }

    const mappedPillar = PILLAR_MAP[pillar] || "RECHERCHE";
    const mappedTier = TIER_MAP[tier] || "TIER3";
    const totalAmount = totalGrantM * 1_000_000; // Convert M$ to $
    const status = beginDate ? "ACTIF" : "IDENTIFICATION";

    // Debug first few dates
    if (beginDate && projectCount < 5) {
      console.log(`  [date] ${projectName?.substring(0, 30)} | begin=${beginDate.toISOString().slice(0, 10)} | end=${endDate?.toISOString().slice(0, 10) || "—"} | year=${yearOfSignature}`);
    }

    // Dakar-area coordinates with slight randomization
    const lat = DAKAR.lat + (Math.random() - 0.5) * 0.15;
    const lng = DAKAR.lng + (Math.random() - 0.5) * 0.15;

    try {
      const project = await prisma.project.create({
        data: {
          partnerId,
          streamId: idStream || null,
          pillar: mappedPillar,
          subPillar: subPillar || null,
          contractType: contractType || null,
          totalAmount,
          annualAmount: annualAmount || totalAmount / 3,
          projectName: projectName || `${partnerName} - ${mappedPillar}`,
          departmentLead: departmentLead || null,
          divisionLead: divisionLead || null,
          status,
          maturationScore: status === "ACTIF" ? 100 : 30,
          signatureYear: yearOfSignature || null,
          duration: duration || null,
          startDate: beginDate,
          endDate,
          grantType: grantType || null,
          grantLink: grantLink || null,
          budgetCode: budgetCode || null,
          objectives: objectives || null,
          deliverables: deliverables || null,
          pastActivities: pastActivities || null,
          upcomingActions: upcomingActions || null,
          latitude: lat,
          longitude: lng,
          hasFeasibilityStudy: status === "ACTIF",
          hasImpactAssessment: status === "ACTIF",
          hasFinancialStructure: status === "ACTIF",
          hasIntentionLetter: status === "ACTIF",
          hasLegalValidation: status === "ACTIF",
          hasPillarConformity: true,
        },
      });

      // Create contacts
      const contacts = [];
      if (partnershipLead) contacts.push({ projectId: project.id, role: "RESPONSABLE_IPD", name: partnershipLead });
      if (financeManager) contacts.push({ projectId: project.id, role: "DIRECTEUR_FINANCIER", name: financeManager });
      if (grantManager) contacts.push({ projectId: project.id, role: "GESTIONNAIRE_SUBVENTION", name: grantManager });
      if (partnershipTeam) contacts.push({ projectId: project.id, role: "EQUIPE", name: partnershipTeam });
      if (partnerRep) contacts.push({ projectId: project.id, role: "REPRESENTANT_PARTENAIRE", name: partnerRep, email: partnerRepContact || null });

      for (const c of contacts) {
        await prisma.contact.create({ data: c });
      }

      // Create risks
      if (risksList) {
        await prisma.risk.create({
          data: {
            projectId: project.id,
            description: risksList,
            mitigationActions: mitigationActions || null,
            criticality: CRITICALITY_MAP[criticality] || "MEDIUM",
          },
        });
      }

      projectCount++;
    } catch (e: any) {
      console.error(`  Error importing stream ${idStream}: ${e.message?.substring(0, 80)}`);
      skipped++;
    }
  }

  console.log(`  Imported ${projectCount} projects/streams`);
  console.log(`  Skipped ${skipped} rows`);

  // ─── Summary ──────────────────────────────────────────
  const finalPartners = await prisma.partner.count();
  const finalProjects = await prisma.project.count();
  const finalContacts = await prisma.contact.count();
  const finalRisks = await prisma.risk.count();

  console.log(`
╔══════════════════════════════════════════╗
║     IMPORT TERMINÉ AVEC SUCCÈS          ║
╠══════════════════════════════════════════╣
║  Partenaires:  ${String(finalPartners).padStart(4)}                     ║
║  Projets/Flux: ${String(finalProjects).padStart(4)}                     ║
║  Contacts:     ${String(finalContacts).padStart(4)}                     ║
║  Risques:      ${String(finalRisks).padStart(4)}                     ║
╚══════════════════════════════════════════╝
`);
}

main()
  .catch((e) => {
    console.error("Import failed:", e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
