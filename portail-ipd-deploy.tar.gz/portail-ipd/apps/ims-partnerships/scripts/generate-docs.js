const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  HeadingLevel, AlignmentType, WidthType, BorderStyle, PageBreak,
  Header, Footer, PageNumber, NumberFormat, ShadingType,
  TableOfContents, LevelFormat, convertInchesToTwip, TabStopPosition,
  TabStopType, UnderlineType, ImageRun, VerticalAlign
} = require("docx");
const fs = require("fs");
const path = require("path");

// ─── Brand constants ───────────────────────────────────────────
const IPD_BLUE = "0089D0";
const IPD_DARK = "052A62";
const WHITE = "FFFFFF";
const LIGHT_GRAY = "F2F7FB";
const MED_GRAY = "E8E8E8";

const FONT = "Arial";
const OUTPUT_DIR = path.join(require("os").homedir(), "Downloads");

// ─── Reusable helpers ──────────────────────────────────────────

function heading1(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_1,
    spacing: { before: 400, after: 200 },
    children: [new TextRun({ text, font: FONT, size: 32, bold: true, color: IPD_BLUE })],
  });
}

function heading2(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_2,
    spacing: { before: 300, after: 150 },
    children: [new TextRun({ text, font: FONT, size: 26, bold: true, color: IPD_DARK })],
  });
}

function heading3(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_3,
    spacing: { before: 200, after: 100 },
    children: [new TextRun({ text, font: FONT, size: 22, bold: true, color: IPD_DARK })],
  });
}

function para(text, opts = {}) {
  return new Paragraph({
    spacing: { after: 120 },
    alignment: opts.center ? AlignmentType.CENTER : AlignmentType.JUSTIFIED,
    children: [new TextRun({ text, font: FONT, size: 24, ...opts })],
  });
}

function bold(text) {
  return new TextRun({ text, font: FONT, size: 24, bold: true });
}

function normal(text) {
  return new TextRun({ text, font: FONT, size: 24 });
}

function bullet(text, level = 0) {
  return new Paragraph({
    bullet: { level },
    spacing: { after: 60 },
    children: [new TextRun({ text, font: FONT, size: 24 })],
  });
}

function emptyLine() {
  return new Paragraph({ spacing: { after: 200 }, children: [] });
}

function pageBreak() {
  return new Paragraph({ children: [new PageBreak()] });
}

function headerCell(text) {
  return new TableCell({
    shading: { type: ShadingType.SOLID, color: IPD_BLUE, fill: IPD_BLUE },
    verticalAlign: VerticalAlign.CENTER,
    children: [new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 60, after: 60 },
      children: [new TextRun({ text, font: FONT, size: 20, bold: true, color: WHITE })],
    })],
  });
}

function cell(text, shade) {
  return new TableCell({
    shading: shade ? { type: ShadingType.SOLID, color: LIGHT_GRAY, fill: LIGHT_GRAY } : undefined,
    verticalAlign: VerticalAlign.CENTER,
    children: [new Paragraph({
      spacing: { before: 40, after: 40 },
      children: [new TextRun({ text, font: FONT, size: 20 })],
    })],
  });
}

function makeTable(headers, rows) {
  return new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    rows: [
      new TableRow({ children: headers.map(h => headerCell(h)), tableHeader: true }),
      ...rows.map((r, i) => new TableRow({
        children: r.map(c => cell(c, i % 2 === 0)),
      })),
    ],
  });
}

function codeBlock(lines) {
  return lines.map(line => new Paragraph({
    spacing: { after: 0 },
    shading: { type: ShadingType.SOLID, color: "F5F5F5", fill: "F5F5F5" },
    children: [new TextRun({ text: line, font: "Courier New", size: 18 })],
  }));
}

function coverPage(title, subtitle, version) {
  return [
    emptyLine(), emptyLine(), emptyLine(), emptyLine(),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { after: 100 },
      children: [new TextRun({ text: "INSTITUT PASTEUR DE DAKAR", font: FONT, size: 44, bold: true, color: IPD_BLUE })],
    }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { after: 60 },
      children: [new TextRun({ text: "Direction de l'Innovation et du Numerique", font: FONT, size: 28, color: IPD_DARK })],
    }),
    emptyLine(),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { after: 40 },
      border: { top: { style: BorderStyle.SINGLE, size: 6, color: IPD_BLUE }, bottom: { style: BorderStyle.SINGLE, size: 6, color: IPD_BLUE } },
      children: [new TextRun({ text: " ", size: 12 })],
    }),
    emptyLine(),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { after: 200 },
      children: [new TextRun({ text: "PLATEFORME IMS PARTNERSHIPS", font: FONT, size: 36, bold: true, color: IPD_DARK })],
    }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { after: 100 },
      children: [new TextRun({ text: title, font: FONT, size: 32, bold: true, color: IPD_BLUE })],
    }),
    emptyLine(),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { after: 80 },
      children: [new TextRun({ text: subtitle, font: FONT, size: 24, italics: true, color: IPD_DARK })],
    }),
    emptyLine(), emptyLine(), emptyLine(),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      children: [new TextRun({ text: `Version ${version}`, font: FONT, size: 22, color: IPD_DARK })],
    }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      children: [new TextRun({ text: "Avril 2026", font: FONT, size: 22, color: IPD_DARK })],
    }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { after: 100 },
      children: [new TextRun({ text: "CONFIDENTIEL", font: FONT, size: 22, bold: true, color: "CC0000" })],
    }),
    pageBreak(),
  ];
}

function makeHeader() {
  return new Header({
    children: [new Paragraph({
      alignment: AlignmentType.RIGHT,
      children: [new TextRun({ text: "Institut Pasteur de Dakar — IMS Partnerships", font: FONT, size: 16, italics: true, color: IPD_BLUE })],
    })],
  });
}

function makeFooter() {
  return new Footer({
    children: [new Paragraph({
      alignment: AlignmentType.CENTER,
      children: [
        new TextRun({ text: "Page ", font: FONT, size: 16 }),
        new TextRun({ children: [PageNumber.CURRENT], font: FONT, size: 16 }),
        new TextRun({ text: " / ", font: FONT, size: 16 }),
        new TextRun({ children: [PageNumber.TOTAL_PAGES], font: FONT, size: 16 }),
      ],
    })],
  });
}

function docDefaults() {
  return {
    sections: [],
    styles: {
      default: {
        document: {
          run: { font: FONT, size: 24 },
          paragraph: { spacing: { after: 120 } },
        },
      },
    },
  };
}

// ═══════════════════════════════════════════════════════════════
// DOCUMENT 1 — Specifications Techniques de Deploiement
// ═══════════════════════════════════════════════════════════════
function buildDoc1() {
  const children = [];
  const c = children;

  // Cover
  c.push(...coverPage(
    "Specifications Techniques de Deploiement",
    "Architecture, Infrastructure et Procedures de Mise en Production",
    "1.0"
  ));

  // TOC placeholder
  c.push(heading1("Table des matieres"));
  c.push(para("1. Introduction"));
  c.push(para("2. Architecture de deploiement"));
  c.push(para("3. Pre-requis serveur"));
  c.push(para("4. Configuration VPN"));
  c.push(para("5. Configuration JumpServer (Bastion SSH)"));
  c.push(para("6. Docker Compose — Configuration complete"));
  c.push(para("7. Variables d'environnement production"));
  c.push(para("8. Migration SQLite vers PostgreSQL"));
  c.push(para("9. Configuration SSL/TLS avec Let's Encrypt"));
  c.push(para("10. Sauvegarde automatisee"));
  c.push(para("11. Monitoring et Health Checks"));
  c.push(para("12. Securite applicative"));
  c.push(para("13. Plan de Reprise d'Activite (PRA)"));
  c.push(para("14. Procedures de mise a jour"));
  c.push(para("15. Annexes"));
  c.push(pageBreak());

  // ── 1. Introduction ──
  c.push(heading1("1. Introduction"));
  c.push(para("Ce document definit l'ensemble des specifications techniques necessaires au deploiement de la plateforme IMS Partnerships de l'Institut Pasteur de Dakar (IPD) sur une infrastructure securisee via JumpServer et VPN. La plateforme gere actuellement 247 projets, 164 partenaires, 119 indicateurs repartis sur les 14 regions du Senegal."));
  c.push(para("L'objectif est de fournir un guide exhaustif et reproductible permettant a l'equipe DevOps de deployer, maintenir et faire evoluer la plateforme en environnement de production avec un niveau de securite conforme aux standards de l'IPD."));
  c.push(emptyLine());
  c.push(heading2("1.1 Portee du document"));
  c.push(bullet("Architecture reseau et deploiement"));
  c.push(bullet("Configuration de l'infrastructure serveur"));
  c.push(bullet("Conteneurisation avec Docker"));
  c.push(bullet("Securisation des acces (VPN, bastion SSH)"));
  c.push(bullet("Procedures de migration de base de donnees"));
  c.push(bullet("Strategie de sauvegarde et restauration"));
  c.push(bullet("Monitoring et alerting"));
  c.push(bullet("Plan de reprise d'activite (PRA)"));
  c.push(emptyLine());
  c.push(heading2("1.2 Documents de reference"));
  c.push(makeTable(["Document", "Version", "Description"], [
    ["Cahier des Charges Technique", "1.0", "Specifications fonctionnelles et techniques"],
    ["Guide Utilisateur", "1.0", "Manuel utilisateur de la plateforme"],
    ["Politique de Securite IPD", "2.3", "Politique de securite informatique de l'IPD"],
    ["Plan de Continuite", "1.1", "Plan de continuite d'activite de l'IPD"],
  ]));
  c.push(pageBreak());

  // ── 2. Architecture ──
  c.push(heading1("2. Architecture de deploiement"));
  c.push(para("L'architecture de deploiement suit un modele multi-couches securise, avec un acces VPN obligatoire pour atteindre le JumpServer, qui sert de point d'entree unique vers l'infrastructure de production."));
  c.push(emptyLine());
  c.push(heading2("2.1 Diagramme d'architecture"));
  c.push(emptyLine());
  c.push(...codeBlock([
    "┌─────────────────────────────────────────────────────────────────┐",
    "│                     RESEAU INTERNET                            │",
    "│   Utilisateurs (HTTPS :443)                                    │",
    "└──────────────────────┬──────────────────────────────────────────┘",
    "                       │",
    "                       ▼",
    "┌──────────────────────────────────────────────────────────────────┐",
    "│                    PASSERELLE VPN                                │",
    "│              WireGuard / OpenVPN                                 │",
    "│          Subnet: 10.8.0.0/24                                    │",
    "│          Port: 51820 (WG) / 1194 (OVPN)                        │",
    "└──────────────────────┬───────────────────────────────────────────┘",
    "                       │ Tunnel chiffre",
    "                       ▼",
    "┌──────────────────────────────────────────────────────────────────┐",
    "│                  JUMPSERVER (Bastion SSH)                        │",
    "│              IP interne: 10.8.0.1                                │",
    "│              Port SSH: 2222 (non standard)                       │",
    "│              fail2ban + UFW + auditd                             │",
    "└──────────────────────┬───────────────────────────────────────────┘",
    "                       │ Reseau Docker interne",
    "                       ▼",
    "┌──────────────────────────────────────────────────────────────────┐",
    "│                   DOCKER COMPOSE STACK                           │",
    "│  ┌───────────┐  ┌───────────────┐  ┌──────────────────────┐     │",
    "│  │  Nginx     │  │  Next.js App  │  │  PostgreSQL 15       │     │",
    "│  │  (Reverse  │──│  (Node.js 24) │──│  (Donnees metier)    │     │",
    "│  │   Proxy)   │  │  Port 3000    │  │  Port 5432           │     │",
    "│  │  :80/:443  │  └───────────────┘  └──────────────────────┘     │",
    "│  └───────────┘                                                   │",
    "│  ┌───────────┐                                                   │",
    "│  │  Certbot   │ (Renouvellement SSL automatique)                 │",
    "│  └───────────┘                                                   │",
    "└──────────────────────────────────────────────────────────────────┘",
  ]));
  c.push(emptyLine());
  c.push(heading2("2.2 Flux reseau"));
  c.push(makeTable(["Source", "Destination", "Port", "Protocole", "Description"], [
    ["Internet", "Serveur", "443", "HTTPS", "Acces utilisateurs a la plateforme"],
    ["Internet", "Serveur", "80", "HTTP", "Redirection vers HTTPS"],
    ["Admin", "VPN Gateway", "51820", "UDP", "Tunnel WireGuard"],
    ["VPN", "JumpServer", "2222", "TCP/SSH", "Administration serveur"],
    ["Next.js App", "PostgreSQL", "5432", "TCP", "Connexion base de donnees"],
    ["Certbot", "Let's Encrypt", "443", "HTTPS", "Renouvellement certificats"],
  ]));
  c.push(pageBreak());

  // ── 3. Pre-requis serveur ──
  c.push(heading1("3. Pre-requis serveur"));
  c.push(para("Le serveur de production doit repondre aux specifications minimales suivantes pour garantir les performances et la fiabilite de la plateforme IMS Partnerships."));
  c.push(emptyLine());
  c.push(heading2("3.1 Specifications materielles"));
  c.push(makeTable(["Composant", "Minimum requis", "Recommande", "Notes"], [
    ["Systeme d'exploitation", "Ubuntu 22.04 LTS", "Ubuntu 22.04 LTS", "Support LTS jusqu'en avril 2027"],
    ["Processeur (vCPU)", "4 vCPU", "8 vCPU", "Architecture x86_64"],
    ["Memoire vive (RAM)", "8 Go", "16 Go", "Pour Next.js SSR + PostgreSQL"],
    ["Stockage", "100 Go SSD NVMe", "200 Go SSD NVMe", "IOPS > 3000"],
    ["Bande passante", "100 Mbps", "1 Gbps", "Symetrique recommande"],
    ["IP Publique", "1 IPv4 fixe", "1 IPv4 + 1 IPv6", "DNS A/AAAA configure"],
  ]));
  c.push(emptyLine());
  c.push(heading2("3.2 Logiciels requis"));
  c.push(makeTable(["Logiciel", "Version", "Utilisation"], [
    ["Docker Engine", ">= 24.0", "Conteneurisation des services"],
    ["Docker Compose", ">= 2.20", "Orchestration multi-conteneurs"],
    ["Node.js", "24 LTS", "Runtime Next.js (build uniquement)"],
    ["PostgreSQL", "15.x", "Base de donnees relationnelle"],
    ["Nginx", ">= 1.24", "Reverse proxy et terminaison SSL"],
    ["WireGuard", ">= 1.0", "VPN pour l'acces d'administration"],
    ["Certbot", ">= 2.0", "Gestion automatique des certificats SSL"],
    ["fail2ban", ">= 0.11", "Protection contre le brute-force"],
    ["UFW", ">= 0.36", "Pare-feu simplifie"],
    ["Git", ">= 2.40", "Gestion du code source"],
  ]));
  c.push(emptyLine());
  c.push(heading2("3.3 Installation des dependances"));
  c.push(...codeBlock([
    "# Mise a jour du systeme",
    "sudo apt update && sudo apt upgrade -y",
    "",
    "# Installation Docker",
    "curl -fsSL https://get.docker.com | sh",
    "sudo usermod -aG docker $USER",
    "",
    "# Installation Docker Compose V2",
    "sudo apt install docker-compose-plugin -y",
    "",
    "# Installation WireGuard",
    "sudo apt install wireguard -y",
    "",
    "# Installation fail2ban et UFW",
    "sudo apt install fail2ban ufw -y",
    "",
    "# Installation Certbot",
    "sudo apt install certbot python3-certbot-nginx -y",
  ]));
  c.push(pageBreak());

  // ── 4. Configuration VPN ──
  c.push(heading1("4. Configuration VPN"));
  c.push(para("L'acces a l'administration du serveur est exclusivement autorise via un tunnel VPN chiffre. Deux options sont supportees : WireGuard (recommande) et OpenVPN."));
  c.push(emptyLine());
  c.push(heading2("4.1 WireGuard (Recommande)"));
  c.push(para("WireGuard offre de meilleures performances et une configuration simplifiee par rapport a OpenVPN. Il utilise des algorithmes cryptographiques modernes (ChaCha20, Curve25519, BLAKE2s)."));
  c.push(emptyLine());
  c.push(heading3("4.1.1 Configuration serveur (/etc/wireguard/wg0.conf)"));
  c.push(...codeBlock([
    "[Interface]",
    "PrivateKey = <CLE_PRIVEE_SERVEUR>",
    "Address = 10.8.0.1/24",
    "ListenPort = 51820",
    "PostUp = iptables -A FORWARD -i wg0 -j ACCEPT; iptables -t nat -A POSTROUTING -o eth0 -j MASQUERADE",
    "PostDown = iptables -D FORWARD -i wg0 -j ACCEPT; iptables -t nat -D POSTROUTING -o eth0 -j MASQUERADE",
    "",
    "# Administrateur 1",
    "[Peer]",
    "PublicKey = <CLE_PUBLIQUE_ADMIN1>",
    "AllowedIPs = 10.8.0.2/32",
    "",
    "# Administrateur 2",
    "[Peer]",
    "PublicKey = <CLE_PUBLIQUE_ADMIN2>",
    "AllowedIPs = 10.8.0.3/32",
  ]));
  c.push(emptyLine());
  c.push(heading3("4.1.2 Configuration client"));
  c.push(...codeBlock([
    "[Interface]",
    "PrivateKey = <CLE_PRIVEE_CLIENT>",
    "Address = 10.8.0.2/32",
    "DNS = 1.1.1.1, 8.8.8.8",
    "",
    "[Peer]",
    "PublicKey = <CLE_PUBLIQUE_SERVEUR>",
    "Endpoint = <IP_PUBLIQUE_SERVEUR>:51820",
    "AllowedIPs = 10.8.0.0/24",
    "PersistentKeepalive = 25",
  ]));
  c.push(emptyLine());
  c.push(heading2("4.2 OpenVPN (Alternative)"));
  c.push(para("Si WireGuard n'est pas disponible, OpenVPN peut etre utilise en mode UDP sur le port 1194. La configuration utilise des certificats x509 generes via easy-rsa."));
  c.push(emptyLine());
  c.push(heading2("4.3 Regles de securite VPN"));
  c.push(bullet("Rotation des cles tous les 90 jours"));
  c.push(bullet("Journalisation de toutes les connexions VPN"));
  c.push(bullet("Revocation immediate en cas de compromission"));
  c.push(bullet("Authentification a deux facteurs (2FA) recommandee"));
  c.push(bullet("Liste blanche des IP autorisees a se connecter au VPN"));
  c.push(pageBreak());

  // ── 5. Configuration JumpServer ──
  c.push(heading1("5. Configuration JumpServer (Bastion SSH)"));
  c.push(para("Le JumpServer sert de point d'acces unique pour l'administration de l'infrastructure. Aucune connexion SSH directe au serveur de production n'est autorisee en dehors du tunnel VPN."));
  c.push(emptyLine());
  c.push(heading2("5.1 Durcissement SSH (/etc/ssh/sshd_config)"));
  c.push(...codeBlock([
    "Port 2222",
    "PermitRootLogin no",
    "PasswordAuthentication no",
    "PubkeyAuthentication yes",
    "MaxAuthTries 3",
    "ClientAliveInterval 300",
    "ClientAliveCountMax 2",
    "AllowUsers deploy admin",
    "X11Forwarding no",
    "AllowTcpForwarding no",
    "PermitTunnel no",
  ]));
  c.push(emptyLine());
  c.push(heading2("5.2 Configuration fail2ban (/etc/fail2ban/jail.local)"));
  c.push(...codeBlock([
    "[sshd]",
    "enabled = true",
    "port = 2222",
    "filter = sshd",
    "logpath = /var/log/auth.log",
    "maxretry = 3",
    "bantime = 3600",
    "findtime = 600",
  ]));
  c.push(emptyLine());
  c.push(heading2("5.3 Regles UFW (Pare-feu)"));
  c.push(...codeBlock([
    "# Politique par defaut",
    "sudo ufw default deny incoming",
    "sudo ufw default allow outgoing",
    "",
    "# Autoriser SSH uniquement depuis le VPN",
    "sudo ufw allow from 10.8.0.0/24 to any port 2222 proto tcp",
    "",
    "# Autoriser HTTP/HTTPS depuis Internet",
    "sudo ufw allow 80/tcp",
    "sudo ufw allow 443/tcp",
    "",
    "# Autoriser WireGuard",
    "sudo ufw allow 51820/udp",
    "",
    "# Activer le pare-feu",
    "sudo ufw enable",
  ]));
  c.push(emptyLine());
  c.push(heading2("5.4 Audit et journalisation"));
  c.push(bullet("Installation de auditd pour la trace des commandes systeme"));
  c.push(bullet("Centralisation des logs via rsyslog ou journald"));
  c.push(bullet("Conservation des logs pendant 12 mois minimum"));
  c.push(bullet("Alertes par email pour les connexions SSH reussies"));
  c.push(pageBreak());

  // ── 6. Docker Compose ──
  c.push(heading1("6. Docker Compose — Configuration complete"));
  c.push(para("L'ensemble de la pile applicative est conteneurise avec Docker Compose pour garantir la reproductibilite et faciliter les mises a jour."));
  c.push(emptyLine());
  c.push(heading2("6.1 Fichier docker-compose.yml"));
  c.push(...codeBlock([
    "version: '3.9'",
    "",
    "services:",
    "  next-app:",
    "    build:",
    "      context: .",
    "      dockerfile: Dockerfile",
    "    container_name: ims-partnerships-app",
    "    restart: always",
    "    ports:",
    "      - '3000:3000'",
    "    environment:",
    "      - DATABASE_URL=postgresql://ims_user:${DB_PASSWORD}@postgres:5432/ims_partnerships",
    "      - NEXTAUTH_URL=${NEXTAUTH_URL}",
    "      - NEXTAUTH_SECRET=${NEXTAUTH_SECRET}",
    "      - SSO_SHARED_SECRET=${SSO_SHARED_SECRET}",
    "      - NODE_ENV=production",
    "    depends_on:",
    "      postgres:",
    "        condition: service_healthy",
    "    networks:",
    "      - ims-network",
    "    healthcheck:",
    "      test: ['CMD', 'curl', '-f', 'http://localhost:3000/api/health']",
    "      interval: 30s",
    "      timeout: 10s",
    "      retries: 3",
    "      start_period: 40s",
    "",
    "  postgres:",
    "    image: postgres:15-alpine",
    "    container_name: ims-partnerships-db",
    "    restart: always",
    "    environment:",
    "      - POSTGRES_DB=ims_partnerships",
    "      - POSTGRES_USER=ims_user",
    "      - POSTGRES_PASSWORD=${DB_PASSWORD}",
    "    volumes:",
    "      - postgres_data:/var/lib/postgresql/data",
    "      - ./backups:/backups",
    "    ports:",
    "      - '127.0.0.1:5432:5432'",
    "    networks:",
    "      - ims-network",
    "    healthcheck:",
    "      test: ['CMD-SHELL', 'pg_isready -U ims_user -d ims_partnerships']",
    "      interval: 10s",
    "      timeout: 5s",
    "      retries: 5",
    "",
    "  nginx:",
    "    image: nginx:1.25-alpine",
    "    container_name: ims-partnerships-nginx",
    "    restart: always",
    "    ports:",
    "      - '80:80'",
    "      - '443:443'",
    "    volumes:",
    "      - ./nginx/nginx.conf:/etc/nginx/nginx.conf:ro",
    "      - ./nginx/conf.d:/etc/nginx/conf.d:ro",
    "      - ./certbot/conf:/etc/letsencrypt:ro",
    "      - ./certbot/www:/var/www/certbot:ro",
    "    depends_on:",
    "      - next-app",
    "    networks:",
    "      - ims-network",
    "",
    "  certbot:",
    "    image: certbot/certbot",
    "    container_name: ims-partnerships-certbot",
    "    volumes:",
    "      - ./certbot/conf:/etc/letsencrypt",
    "      - ./certbot/www:/var/www/certbot",
    "    entrypoint: \"/bin/sh -c 'trap exit TERM; while :; do sleep 12h & wait $${!}; certbot renew; done'\"",
    "",
    "volumes:",
    "  postgres_data:",
    "",
    "networks:",
    "  ims-network:",
    "    driver: bridge",
  ]));
  c.push(emptyLine());
  c.push(heading2("6.2 Dockerfile (Application Next.js)"));
  c.push(...codeBlock([
    "FROM node:24-alpine AS base",
    "",
    "FROM base AS deps",
    "WORKDIR /app",
    "COPY package.json package-lock.json ./",
    "RUN npm ci --only=production",
    "",
    "FROM base AS builder",
    "WORKDIR /app",
    "COPY --from=deps /app/node_modules ./node_modules",
    "COPY . .",
    "RUN npx prisma generate",
    "RUN npm run build",
    "",
    "FROM base AS runner",
    "WORKDIR /app",
    "ENV NODE_ENV=production",
    "RUN addgroup --system --gid 1001 nodejs",
    "RUN adduser --system --uid 1001 nextjs",
    "COPY --from=builder /app/public ./public",
    "COPY --from=builder --chown=nextjs:nodejs /app/.next/standalone ./",
    "COPY --from=builder --chown=nextjs:nodejs /app/.next/static ./.next/static",
    "COPY --from=builder /app/prisma ./prisma",
    "USER nextjs",
    "EXPOSE 3000",
    "CMD [\"node\", \"server.js\"]",
  ]));
  c.push(emptyLine());
  c.push(heading2("6.3 Configuration Nginx"));
  c.push(...codeBlock([
    "server {",
    "    listen 80;",
    "    server_name ims.pasteur.sn;",
    "    location /.well-known/acme-challenge/ {",
    "        root /var/www/certbot;",
    "    }",
    "    location / {",
    "        return 301 https://$host$request_uri;",
    "    }",
    "}",
    "",
    "server {",
    "    listen 443 ssl http2;",
    "    server_name ims.pasteur.sn;",
    "",
    "    ssl_certificate /etc/letsencrypt/live/ims.pasteur.sn/fullchain.pem;",
    "    ssl_certificate_key /etc/letsencrypt/live/ims.pasteur.sn/privkey.pem;",
    "    ssl_protocols TLSv1.2 TLSv1.3;",
    "    ssl_ciphers HIGH:!aNULL:!MD5;",
    "",
    "    client_max_body_size 50M;",
    "",
    "    location / {",
    "        proxy_pass http://next-app:3000;",
    "        proxy_http_version 1.1;",
    "        proxy_set_header Upgrade $http_upgrade;",
    "        proxy_set_header Connection 'upgrade';",
    "        proxy_set_header Host $host;",
    "        proxy_set_header X-Real-IP $remote_addr;",
    "        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;",
    "        proxy_set_header X-Forwarded-Proto $scheme;",
    "        proxy_cache_bypass $http_upgrade;",
    "    }",
    "}",
  ]));
  c.push(pageBreak());

  // ── 7. Variables d'environnement ──
  c.push(heading1("7. Variables d'environnement production"));
  c.push(para("Les variables d'environnement sont stockees dans un fichier .env a la racine du projet. Ce fichier ne doit jamais etre versionne dans Git."));
  c.push(emptyLine());
  c.push(makeTable(["Variable", "Description", "Exemple"], [
    ["DATABASE_URL", "URL de connexion PostgreSQL", "postgresql://ims_user:***@postgres:5432/ims_partnerships"],
    ["NEXTAUTH_URL", "URL publique de l'application", "https://ims.pasteur.sn"],
    ["NEXTAUTH_SECRET", "Secret de session (min 32 car.)", "Generer avec: openssl rand -base64 32"],
    ["SSO_SHARED_SECRET", "Cle partagee HMAC-SHA256 pour SSO", "Definie avec le portail IPD"],
    ["DB_PASSWORD", "Mot de passe PostgreSQL", "Min 24 caracteres, aleatoire"],
    ["NODE_ENV", "Environnement d'execution", "production"],
    ["UPLOAD_MAX_SIZE", "Taille max des uploads (Mo)", "50"],
    ["LOG_LEVEL", "Niveau de journalisation", "info"],
    ["RATE_LIMIT_MAX", "Requetes max par minute/IP", "100"],
    ["BACKUP_RETENTION_DAYS", "Jours de retention des sauvegardes", "30"],
  ]));
  c.push(emptyLine());
  c.push(heading2("7.1 Generation des secrets"));
  c.push(...codeBlock([
    "# Secret NextAuth",
    "openssl rand -base64 32",
    "",
    "# Mot de passe PostgreSQL",
    "openssl rand -base64 24",
    "",
    "# Secret SSO (a partager avec le portail IPD)",
    "openssl rand -hex 32",
  ]));
  c.push(pageBreak());

  // ── 8. Migration SQLite → PostgreSQL ──
  c.push(heading1("8. Migration SQLite vers PostgreSQL"));
  c.push(para("La plateforme utilise actuellement SQLite en developpement. La migration vers PostgreSQL est obligatoire pour la production afin de garantir la concurrence, les performances et la fiabilite."));
  c.push(emptyLine());
  c.push(heading2("8.1 Etapes de migration"));
  c.push(new Paragraph({
    spacing: { after: 60 },
    children: [bold("Etape 1 : "), normal("Modifier le provider Prisma dans schema.prisma")],
  }));
  c.push(...codeBlock([
    "datasource db {",
    "  provider = \"postgresql\"",
    "  url      = env(\"DATABASE_URL\")",
    "}",
  ]));
  c.push(emptyLine());
  c.push(new Paragraph({
    spacing: { after: 60 },
    children: [bold("Etape 2 : "), normal("Generer et appliquer les migrations")],
  }));
  c.push(...codeBlock([
    "npx prisma migrate dev --name init_postgresql",
    "npx prisma generate",
  ]));
  c.push(emptyLine());
  c.push(new Paragraph({
    spacing: { after: 60 },
    children: [bold("Etape 3 : "), normal("Exporter les donnees SQLite")],
  }));
  c.push(...codeBlock([
    "sqlite3 prisma/dev.db .dump > dump_sqlite.sql",
  ]));
  c.push(emptyLine());
  c.push(new Paragraph({
    spacing: { after: 60 },
    children: [bold("Etape 4 : "), normal("Convertir et importer dans PostgreSQL")],
  }));
  c.push(para("Utiliser l'outil pgloader pour une migration automatique des types de donnees :"));
  c.push(...codeBlock([
    "pgloader sqlite:///path/to/dev.db postgresql://ims_user:password@localhost/ims_partnerships",
  ]));
  c.push(emptyLine());
  c.push(new Paragraph({
    spacing: { after: 60 },
    children: [bold("Etape 5 : "), normal("Verification post-migration")],
  }));
  c.push(bullet("Verifier le nombre d'enregistrements par table"));
  c.push(bullet("Tester les requetes critiques (dashboard, rapports)"));
  c.push(bullet("Valider les relations et contraintes d'integrite"));
  c.push(bullet("Executer la suite de tests si disponible"));
  c.push(emptyLine());
  c.push(heading2("8.2 Points d'attention"));
  c.push(bullet("Les types de donnees BOOLEAN SQLite (0/1) doivent etre convertis en TRUE/FALSE PostgreSQL"));
  c.push(bullet("Les AUTOINCREMENT deviennent des SERIAL ou GENERATED ALWAYS AS IDENTITY"));
  c.push(bullet("Les dates stockees comme TEXT doivent etre converties en TIMESTAMP WITH TIME ZONE"));
  c.push(bullet("Les index SQLite doivent etre recrees dans PostgreSQL"));
  c.push(pageBreak());

  // ── 9. SSL/TLS ──
  c.push(heading1("9. Configuration SSL/TLS avec Let's Encrypt"));
  c.push(para("Le certificat SSL est fourni gratuitement par Let's Encrypt et renouvele automatiquement par Certbot."));
  c.push(emptyLine());
  c.push(heading2("9.1 Obtention initiale du certificat"));
  c.push(...codeBlock([
    "sudo certbot certonly --webroot -w /var/www/certbot \\",
    "  -d ims.pasteur.sn \\",
    "  --email admin@pasteur.sn \\",
    "  --agree-tos \\",
    "  --no-eff-email",
  ]));
  c.push(emptyLine());
  c.push(heading2("9.2 Renouvellement automatique"));
  c.push(...codeBlock([
    "# Crontab pour le renouvellement (2x par jour)",
    "0 0,12 * * * /usr/bin/certbot renew --quiet && docker exec ims-partnerships-nginx nginx -s reload",
  ]));
  c.push(emptyLine());
  c.push(heading2("9.3 Configuration TLS renforcee"));
  c.push(bullet("Protocoles : TLSv1.2 et TLSv1.3 uniquement"));
  c.push(bullet("Suites de chiffrement : ECDHE-ECDSA-AES128-GCM-SHA256, ECDHE-RSA-AES128-GCM-SHA256"));
  c.push(bullet("HSTS active avec max-age=31536000"));
  c.push(bullet("OCSP Stapling active"));
  c.push(bullet("Score SSL Labs : A+ vise"));
  c.push(pageBreak());

  // ── 10. Sauvegarde ──
  c.push(heading1("10. Sauvegarde automatisee"));
  c.push(para("Les sauvegardes sont essentielles pour la protection des donnees. La strategie suit le principe 3-2-1 : 3 copies, 2 supports differents, 1 copie hors site."));
  c.push(emptyLine());
  c.push(heading2("10.1 Script de sauvegarde (backup.sh)"));
  c.push(...codeBlock([
    "#!/bin/bash",
    "set -euo pipefail",
    "",
    "BACKUP_DIR=/opt/ims-partnerships/backups",
    "DATE=$(date +%Y%m%d_%H%M%S)",
    "RETENTION_DAYS=30",
    "",
    "# Sauvegarde PostgreSQL",
    "docker exec ims-partnerships-db pg_dump -U ims_user -Fc ims_partnerships \\",
    "  > ${BACKUP_DIR}/db_${DATE}.dump",
    "",
    "# Sauvegarde des fichiers uploades",
    "tar -czf ${BACKUP_DIR}/uploads_${DATE}.tar.gz /opt/ims-partnerships/uploads/",
    "",
    "# Sauvegarde de la configuration",
    "tar -czf ${BACKUP_DIR}/config_${DATE}.tar.gz /opt/ims-partnerships/.env \\",
    "  /opt/ims-partnerships/docker-compose.yml \\",
    "  /opt/ims-partnerships/nginx/",
    "",
    "# Suppression des anciennes sauvegardes",
    "find ${BACKUP_DIR} -type f -mtime +${RETENTION_DAYS} -delete",
    "",
    "# Copie hors site (S3 ou rsync)",
    "# aws s3 sync ${BACKUP_DIR} s3://ipd-backups/ims-partnerships/",
    "",
    "echo \"[$(date)] Sauvegarde terminee avec succes\"",
  ]));
  c.push(emptyLine());
  c.push(heading2("10.2 Planification cron"));
  c.push(...codeBlock([
    "# Sauvegarde quotidienne a 2h du matin",
    "0 2 * * * /opt/ims-partnerships/scripts/backup.sh >> /var/log/ims-backup.log 2>&1",
  ]));
  c.push(emptyLine());
  c.push(heading2("10.3 Procedure de restauration"));
  c.push(...codeBlock([
    "# Restauration de la base de donnees",
    "docker exec -i ims-partnerships-db pg_restore -U ims_user -d ims_partnerships \\",
    "  --clean --if-exists < /backups/db_YYYYMMDD_HHMMSS.dump",
  ]));
  c.push(emptyLine());
  c.push(heading2("10.4 Matrice de sauvegarde"));
  c.push(makeTable(["Element", "Frequence", "Retention", "Methode", "Stockage"], [
    ["Base de donnees", "Quotidienne", "30 jours", "pg_dump -Fc", "Local + S3"],
    ["Fichiers uploades", "Quotidienne", "30 jours", "tar.gz", "Local + S3"],
    ["Configuration", "Hebdomadaire", "90 jours", "tar.gz", "Local + S3"],
    ["Logs applicatifs", "Quotidienne", "90 jours", "rotation logrotate", "Local"],
  ]));
  c.push(pageBreak());

  // ── 11. Monitoring ──
  c.push(heading1("11. Monitoring et Health Checks"));
  c.push(para("Le monitoring assure la disponibilite et la detection proactive des incidents sur la plateforme."));
  c.push(emptyLine());
  c.push(heading2("11.1 Endpoint Health Check"));
  c.push(para("L'application expose un endpoint /api/health qui retourne l'etat de sante de tous les composants :"));
  c.push(...codeBlock([
    "GET /api/health",
    "",
    "Response 200:",
    "{",
    "  \"status\": \"healthy\",",
    "  \"version\": \"1.0.0\",",
    "  \"uptime\": 86400,",
    "  \"database\": \"connected\",",
    "  \"memory\": { \"used\": \"256MB\", \"total\": \"512MB\" },",
    "  \"timestamp\": \"2026-04-05T10:00:00Z\"",
    "}",
  ]));
  c.push(emptyLine());
  c.push(heading2("11.2 Metriques a surveiller"));
  c.push(makeTable(["Metrique", "Seuil d'alerte", "Seuil critique", "Action"], [
    ["CPU utilisation", "> 70%", "> 90%", "Notification + investigation"],
    ["Memoire utilisee", "> 75%", "> 90%", "Notification + redemarrage"],
    ["Espace disque", "> 80%", "> 95%", "Notification + nettoyage"],
    ["Temps de reponse API", "> 2s", "> 5s", "Notification + analyse"],
    ["Connexions DB actives", "> 80", "> 95", "Notification + pool review"],
    ["Taux d'erreur HTTP 5xx", "> 1%", "> 5%", "Notification + rollback"],
    ["Certificat SSL expiration", "< 30j", "< 7j", "Renouvellement force"],
  ]));
  c.push(emptyLine());
  c.push(heading2("11.3 Monitoring externe"));
  c.push(bullet("UptimeRobot ou Better Uptime pour la surveillance HTTP/HTTPS"));
  c.push(bullet("Alertes par email et SMS en cas d'indisponibilite"));
  c.push(bullet("Verification toutes les 5 minutes"));
  c.push(bullet("Pages de statut publiques pour les partenaires"));
  c.push(pageBreak());

  // ── 12. Securite ──
  c.push(heading1("12. Securite applicative"));
  c.push(para("La securite de la plateforme IMS Partnerships couvre plusieurs couches : reseau, transport, application et donnees."));
  c.push(emptyLine());
  c.push(heading2("12.1 En-tetes de securite HTTP"));
  c.push(...codeBlock([
    "# Configuration Nginx - En-tetes de securite",
    "add_header X-Frame-Options \"SAMEORIGIN\" always;",
    "add_header X-Content-Type-Options \"nosniff\" always;",
    "add_header X-XSS-Protection \"1; mode=block\" always;",
    "add_header Referrer-Policy \"strict-origin-when-cross-origin\" always;",
    "add_header Content-Security-Policy \"default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval'; style-src 'self' 'unsafe-inline'; img-src 'self' data: https:; font-src 'self' data:; connect-src 'self' https://tile.openstreetmap.org;\" always;",
    "add_header Strict-Transport-Security \"max-age=31536000; includeSubDomains; preload\" always;",
    "add_header Permissions-Policy \"camera=(), microphone=(), geolocation=(self)\" always;",
  ]));
  c.push(emptyLine());
  c.push(heading2("12.2 Rate Limiting"));
  c.push(...codeBlock([
    "# Nginx rate limiting",
    "limit_req_zone $binary_remote_addr zone=api:10m rate=10r/s;",
    "limit_req_zone $binary_remote_addr zone=auth:10m rate=5r/m;",
    "",
    "location /api/ {",
    "    limit_req zone=api burst=20 nodelay;",
    "}",
    "",
    "location /api/auth/ {",
    "    limit_req zone=auth burst=3 nodelay;",
    "}",
  ]));
  c.push(emptyLine());
  c.push(heading2("12.3 Securite de la base de donnees"));
  c.push(bullet("PostgreSQL accessible uniquement depuis le reseau Docker interne"));
  c.push(bullet("Utilisateur dedie avec privileges minimaux (pas de SUPERUSER)"));
  c.push(bullet("Chiffrement des connexions avec SSL"));
  c.push(bullet("Requetes parametrees via Prisma (prevention injection SQL)"));
  c.push(bullet("Audit des acces via pg_stat_activity"));
  c.push(emptyLine());
  c.push(heading2("12.4 Securite applicative"));
  c.push(bullet("Authentification SSO via HMAC-SHA256 avec secret partage"));
  c.push(bullet("Hachage des mots de passe avec bcrypt (cost factor 12)"));
  c.push(bullet("Tokens JWT signes avec RS256"));
  c.push(bullet("Sessions securisees (HttpOnly, Secure, SameSite=Strict)"));
  c.push(bullet("RBAC a 4 niveaux : ADMIN_NATIONAL, CHARGE_SUIVI, PARTENAIRE_TECHNIQUE, OBSERVATEUR"));
  c.push(bullet("Protection CSRF integree a Next.js"));
  c.push(bullet("Validation des entrees cote serveur (Zod)"));
  c.push(pageBreak());

  // ── 13. PRA ──
  c.push(heading1("13. Plan de Reprise d'Activite (PRA)"));
  c.push(para("Le PRA definit les procedures a suivre en cas de sinistre majeur pour retablir le service dans les meilleurs delais."));
  c.push(emptyLine());
  c.push(heading2("13.1 Objectifs"));
  c.push(makeTable(["Indicateur", "Objectif", "Description"], [
    ["RTO (Recovery Time Objective)", "< 4 heures", "Duree maximale d'indisponibilite acceptable"],
    ["RPO (Recovery Point Objective)", "< 24 heures", "Perte de donnees maximale acceptable"],
    ["Disponibilite annuelle", "> 99.5%", "Soit < 43.8 heures d'indisponibilite par an"],
  ]));
  c.push(emptyLine());
  c.push(heading2("13.2 Scenarios de sinistre"));
  c.push(makeTable(["Scenario", "Probabilite", "Impact", "Procedure"], [
    ["Panne serveur", "Moyenne", "Critique", "Redemarrage Docker / migration vers serveur de secours"],
    ["Corruption de donnees", "Faible", "Critique", "Restauration depuis la derniere sauvegarde"],
    ["Attaque DDoS", "Moyenne", "Eleve", "Activation du mode maintenance + CDN"],
    ["Compromission de compte", "Faible", "Eleve", "Revocation des acces + audit + notification"],
    ["Perte du certificat SSL", "Faible", "Moyen", "Renouvellement force via Certbot"],
    ["Saturation disque", "Moyenne", "Moyen", "Nettoyage + extension du volume"],
  ]));
  c.push(emptyLine());
  c.push(heading2("13.3 Procedure de reprise"));
  c.push(new Paragraph({ spacing: { after: 60 }, children: [bold("Phase 1 — Detection et diagnostic (0-30 min)")] }));
  c.push(bullet("Identification du type de panne via les alertes monitoring"));
  c.push(bullet("Evaluation de l'impact et notification de l'equipe"));
  c.push(emptyLine());
  c.push(new Paragraph({ spacing: { after: 60 }, children: [bold("Phase 2 — Actions correctives (30 min - 2h)")] }));
  c.push(bullet("Tentative de redemarrage des services Docker"));
  c.push(bullet("Si echec : deploiement sur serveur de secours"));
  c.push(bullet("Restauration de la derniere sauvegarde si necessaire"));
  c.push(emptyLine());
  c.push(new Paragraph({ spacing: { after: 60 }, children: [bold("Phase 3 — Verification et communication (2h - 4h)")] }));
  c.push(bullet("Tests de validation post-restauration"));
  c.push(bullet("Communication aux utilisateurs"));
  c.push(bullet("Redaction du rapport d'incident"));
  c.push(pageBreak());

  // ── 14. Procedures de mise a jour ──
  c.push(heading1("14. Procedures de mise a jour"));
  c.push(para("Les mises a jour de la plateforme suivent un processus rigoureux pour minimiser les risques d'interruption de service."));
  c.push(emptyLine());
  c.push(heading2("14.1 Processus de deploiement"));
  c.push(...codeBlock([
    "# 1. Connexion VPN + SSH au JumpServer",
    "ssh -p 2222 deploy@10.8.0.1",
    "",
    "# 2. Se placer dans le repertoire de l'application",
    "cd /opt/ims-partnerships",
    "",
    "# 3. Sauvegarde pre-deploiement",
    "./scripts/backup.sh",
    "",
    "# 4. Recuperation du code",
    "git pull origin main",
    "",
    "# 5. Rebuild et redemarrage (zero-downtime)",
    "docker compose build next-app",
    "docker compose up -d --no-deps next-app",
    "",
    "# 6. Migration de la base si necessaire",
    "docker exec ims-partnerships-app npx prisma migrate deploy",
    "",
    "# 7. Verification",
    "curl -s https://ims.pasteur.sn/api/health | jq .",
    "",
    "# 8. Rollback si erreur",
    "# docker compose down",
    "# git checkout HEAD~1",
    "# docker compose build && docker compose up -d",
  ]));
  c.push(emptyLine());
  c.push(heading2("14.2 Checklist de deploiement"));
  c.push(makeTable(["Etape", "Responsable", "Verification"], [
    ["Sauvegarde pre-deploiement", "DevOps", "Fichier de sauvegarde cree"],
    ["Tests en staging", "Developpeur", "Tous les tests passent"],
    ["Revue de code", "Tech Lead", "PR approuvee"],
    ["Deploiement", "DevOps", "Conteneurs demarres"],
    ["Migration BDD", "DevOps", "Schema mis a jour"],
    ["Health check", "DevOps", "Endpoint /api/health OK"],
    ["Tests fonctionnels", "QA", "Scenarios critiques valides"],
    ["Communication", "Chef de projet", "Equipe notifiee"],
  ]));
  c.push(pageBreak());

  // ── 15. Annexes ──
  c.push(heading1("15. Annexes"));
  c.push(heading2("15.1 Contacts d'urgence"));
  c.push(makeTable(["Role", "Nom", "Email", "Telephone"], [
    ["Administrateur systeme", "A definir", "admin@pasteur.sn", "+221 XX XXX XX XX"],
    ["Developpeur principal", "A definir", "dev@pasteur.sn", "+221 XX XXX XX XX"],
    ["Responsable securite", "A definir", "security@pasteur.sn", "+221 XX XXX XX XX"],
    ["Chef de projet", "A definir", "pm@pasteur.sn", "+221 XX XXX XX XX"],
  ]));
  c.push(emptyLine());
  c.push(heading2("15.2 Ports et protocoles"));
  c.push(makeTable(["Port", "Protocole", "Service", "Acces"], [
    ["80", "TCP", "HTTP (redirection)", "Public"],
    ["443", "TCP", "HTTPS", "Public"],
    ["2222", "TCP", "SSH (non standard)", "VPN uniquement"],
    ["3000", "TCP", "Next.js (interne)", "Docker network"],
    ["5432", "TCP", "PostgreSQL", "Docker network"],
    ["51820", "UDP", "WireGuard VPN", "Restreint"],
  ]));
  c.push(emptyLine());
  c.push(heading2("15.3 Glossaire"));
  c.push(makeTable(["Terme", "Definition"], [
    ["VPN", "Virtual Private Network — Reseau prive virtuel"],
    ["JumpServer", "Serveur bastion servant de point d'entree unique securise"],
    ["Docker", "Plateforme de conteneurisation d'applications"],
    ["Prisma", "ORM (Object-Relational Mapping) pour Node.js"],
    ["SSO", "Single Sign-On — Authentification unique"],
    ["RBAC", "Role-Based Access Control — Controle d'acces base sur les roles"],
    ["PRA", "Plan de Reprise d'Activite"],
    ["RTO", "Recovery Time Objective — Duree maximale d'indisponibilite"],
    ["RPO", "Recovery Point Objective — Perte de donnees maximale"],
    ["CSP", "Content Security Policy — Politique de securite du contenu"],
    ["HSTS", "HTTP Strict Transport Security"],
  ]));

  return new Document({
    ...docDefaults(),
    sections: [{
      headers: { default: makeHeader() },
      footers: { default: makeFooter() },
      children,
    }],
  });
}

// ═══════════════════════════════════════════════════════════════
// DOCUMENT 2 — Cahier des Charges Technique
// ═══════════════════════════════════════════════════════════════
function buildDoc2() {
  const children = [];
  const c = children;

  // Cover
  c.push(...coverPage(
    "Cahier des Charges Technique",
    "Specifications Fonctionnelles et Techniques de la Plateforme",
    "1.0"
  ));

  // TOC
  c.push(heading1("Table des matieres"));
  c.push(para("1. Introduction et contexte"));
  c.push(para("2. Objectifs de la plateforme"));
  c.push(para("3. Perimetre fonctionnel"));
  c.push(para("4. Architecture technique"));
  c.push(para("5. Modele de donnees"));
  c.push(para("6. APIs REST"));
  c.push(para("7. Securite et RBAC"));
  c.push(para("8. Performance et scalabilite"));
  c.push(para("9. Contraintes techniques"));
  c.push(para("10. Planning de deploiement"));
  c.push(para("11. Matrice de responsabilites RACI"));
  c.push(para("12. Annexes"));
  c.push(pageBreak());

  // ── 1. Introduction ──
  c.push(heading1("1. Introduction et contexte"));
  c.push(heading2("1.1 Presentation de l'Institut Pasteur de Dakar"));
  c.push(para("L'Institut Pasteur de Dakar (IPD) est une fondation senegalaise a but non lucratif reconnue d'utilite publique, membre du Reseau International des Instituts Pasteur. L'IPD intervient dans les domaines de la recherche biomedicale, de la sante publique, de la formation et de la production de vaccins."));
  c.push(para("Dans le cadre de sa strategie de partenariats, l'IPD collabore avec de nombreux partenaires techniques et financiers au niveau national et international. La gestion efficace de ces partenariats est devenue un enjeu strategique necessitant un outil numerique dedie."));
  c.push(emptyLine());
  c.push(heading2("1.2 Contexte du projet"));
  c.push(para("La plateforme IMS Partnerships (Information Management System for Partnerships) a ete concue pour centraliser, suivre et analyser l'ensemble des partenariats de l'IPD. Elle couvre le cycle de vie complet d'un partenariat, de la prospection a la cloture, en passant par le suivi des indicateurs de performance."));
  c.push(emptyLine());
  c.push(heading2("1.3 Donnees cles de la plateforme"));
  c.push(makeTable(["Indicateur", "Valeur", "Description"], [
    ["Projets", "247", "Projets actifs et archives dans le portefeuille"],
    ["Partenaires", "164", "Partenaires techniques et financiers"],
    ["Indicateurs", "119", "Indicateurs de suivi et de performance"],
    ["Regions", "14", "Regions administratives du Senegal couvertes"],
    ["Modules", "12", "Modules fonctionnels de la plateforme"],
    ["Roles", "4", "Niveaux d'acces RBAC"],
  ]));
  c.push(pageBreak());

  // ── 2. Objectifs ──
  c.push(heading1("2. Objectifs de la plateforme"));
  c.push(heading2("2.1 Objectifs strategiques"));
  c.push(bullet("Centraliser l'information relative aux partenariats de l'IPD dans un systeme unique"));
  c.push(bullet("Faciliter la prise de decision grace a des tableaux de bord et des indicateurs en temps reel"));
  c.push(bullet("Ameliorer la transparence et la tracabilite des activites partenariales"));
  c.push(bullet("Renforcer la collaboration entre les equipes internes et les partenaires externes"));
  c.push(bullet("Automatiser la generation de rapports pour les bailleurs de fonds"));
  c.push(emptyLine());
  c.push(heading2("2.2 Objectifs operationnels"));
  c.push(bullet("Offrir un suivi en temps reel de l'avancement des 247 projets"));
  c.push(bullet("Permettre la saisie decentralisee des donnees par les gestionnaires departementaux"));
  c.push(bullet("Visualiser la repartition geographique des projets sur une carte interactive"));
  c.push(bullet("Gerer le pipeline de prospection avec un systeme Kanban"));
  c.push(bullet("Suivre les 119 indicateurs de performance avec historisation des valeurs"));
  c.push(bullet("Assurer la tracabilite complete des actions via un journal d'audit immuable"));
  c.push(pageBreak());

  // ── 3. Perimetre fonctionnel ──
  c.push(heading1("3. Perimetre fonctionnel"));
  c.push(para("La plateforme IMS Partnerships comprend 12 modules fonctionnels couvrant l'ensemble des besoins de gestion des partenariats."));
  c.push(emptyLine());

  c.push(heading2("3.1 Module Dashboard"));
  c.push(para("Le tableau de bord principal offre une vue synthetique de l'activite partenariale de l'IPD. Il constitue la page d'accueil de la plateforme."));
  c.push(bullet("Cartes KPI : nombre de projets, partenaires, budget total, taux de realisation"));
  c.push(bullet("Graphiques interactifs (Recharts) : repartition par statut, par region, par type de partenaire"));
  c.push(bullet("Filtres dynamiques : periode, region, type de projet, statut"));
  c.push(bullet("Toggle pour afficher les projets actifs uniquement ou inclure les inactifs"));
  c.push(bullet("Actualisation des donnees en temps reel"));
  c.push(emptyLine());

  c.push(heading2("3.2 Module Prospection"));
  c.push(para("Le module de prospection permet de gerer le pipeline d'opportunites de partenariat selon une methodologie Kanban."));
  c.push(bullet("Tableau Kanban avec colonnes configurables (Identification, Contact, Negociation, Finalisation, Signe)"));
  c.push(bullet("Drag-and-drop pour deplacer les opportunites entre les colonnes"));
  c.push(bullet("Score de maturation automatique base sur les criteres definis"));
  c.push(bullet("Systeme de notes et commentaires sur chaque opportunite"));
  c.push(bullet("Historique des interactions avec le partenaire potentiel"));
  c.push(bullet("Alertes pour les opportunites stagnantes"));
  c.push(emptyLine());

  c.push(heading2("3.3 Module Partenaires"));
  c.push(para("Ce module centralise toutes les informations relatives aux 164 partenaires de l'IPD."));
  c.push(bullet("Repertoire complet des partenaires avec filtres multi-criteres"));
  c.push(bullet("Visualisation en nuage de mots (wordcloud) par type, secteur ou region"));
  c.push(bullet("Fiche detaillee de chaque partenaire : coordonnees, projets associes, historique"));
  c.push(bullet("Categorisation par type : technique, financier, institutionnel, academique"));
  c.push(bullet("Suivi du statut de la relation (actif, en pause, termine)"));
  c.push(emptyLine());

  c.push(heading2("3.4 Module Portefeuille Projets"));
  c.push(para("Le portefeuille projets offre une vue complete des 247 projets avec des capacites de filtrage avancees."));
  c.push(bullet("9 filtres combinables : statut, region, departement, partenaire, type, annee, budget, indicateur, theme"));
  c.push(bullet("KPI dynamiques recalcules selon les filtres appliques"));
  c.push(bullet("Cartes projets avec resume, progression et partenaire associe"));
  c.push(bullet("Vue liste et vue cartes interchangeables"));
  c.push(bullet("Export des resultats filtres"));
  c.push(bullet("Tri par date, budget, taux d'avancement"));
  c.push(emptyLine());

  c.push(heading2("3.5 Module Saisie et Mise a jour"));
  c.push(para("Ce module est le point d'entree principal pour la saisie et la mise a jour des donnees. Il comprend 4 onglets :"));
  c.push(emptyLine());
  c.push(heading3("3.5.1 Onglet Nouveau Projet"));
  c.push(bullet("Formulaire complet de creation de projet"));
  c.push(bullet("Champs : titre, description, partenaire, region, departement, dates, budget, objectifs"));
  c.push(bullet("Validation des champs obligatoires en temps reel"));
  c.push(bullet("Attribution automatique d'un identifiant unique"));
  c.push(emptyLine());
  c.push(heading3("3.5.2 Onglet Avancement"));
  c.push(bullet("Mise a jour du taux d'avancement des projets existants"));
  c.push(bullet("Selection du projet via recherche ou filtres"));
  c.push(bullet("Historique des mises a jour avec horodatage et auteur"));
  c.push(emptyLine());
  c.push(heading3("3.5.3 Onglet Prospection"));
  c.push(bullet("Saisie des nouvelles opportunites de prospection"));
  c.push(bullet("Formulaire adapte avec score de maturation"));
  c.push(emptyLine());
  c.push(heading3("3.5.4 Onglet Indicateurs par Projet"));
  c.push(bullet("Saisie des valeurs d'indicateurs associes a un projet specifique"));
  c.push(bullet("Affichage de l'historique des valeurs precedentes"));
  c.push(bullet("Calcul automatique des ecarts par rapport aux cibles"));
  c.push(emptyLine());

  c.push(heading2("3.6 Module Indicateurs"));
  c.push(para("Le module de gestion des 119 indicateurs permet le suivi et l'analyse des performances."));
  c.push(bullet("Table croisee dynamique des indicateurs par projet, region et periode"));
  c.push(bullet("Saisie directe des valeurs avec validation"));
  c.push(bullet("Visualisation graphique de l'evolution temporelle"));
  c.push(bullet("Comparaison valeur realisee vs valeur cible"));
  c.push(bullet("Export des donnees d'indicateurs"));
  c.push(emptyLine());

  c.push(heading2("3.7 Module Gestionnaire Departemental"));
  c.push(para("Ce module permet aux gestionnaires departementaux de gerer les projets de leur zone geographique."));
  c.push(bullet("Selection du departement d'affectation"));
  c.push(bullet("Dashboard departemental avec KPI locaux"));
  c.push(bullet("Saisie et mise a jour des projets du departement"));
  c.push(bullet("Vue restreinte aux donnees du perimetre geographique de l'utilisateur"));
  c.push(emptyLine());

  c.push(heading2("3.8 Module Cartographie"));
  c.push(para("La cartographie interactive permet de visualiser la repartition geographique des projets sur le territoire senegalais."));
  c.push(bullet("Carte Leaflet avec fond OpenStreetMap"));
  c.push(bullet("Couches thematiques : projets par region, par type, par statut"));
  c.push(bullet("Marqueurs interactifs avec popup d'informations"));
  c.push(bullet("Zoom sur les 14 regions du Senegal"));
  c.push(bullet("Heatmap de densite des projets"));
  c.push(bullet("Legende dynamique selon la couche active"));
  c.push(emptyLine());

  c.push(heading2("3.9 Module Medias"));
  c.push(para("Le module medias gere les fichiers multimedia associes aux projets."));
  c.push(bullet("Upload de photos et documents (drag & drop)"));
  c.push(bullet("Galerie avec vignettes et previsualisation"));
  c.push(bullet("Extraction automatique des coordonnees GPS depuis les metadonnees EXIF"));
  c.push(bullet("Association des medias aux projets et regions"));
  c.push(bullet("Formats supportes : JPEG, PNG, PDF, DOCX"));
  c.push(emptyLine());

  c.push(heading2("3.10 Module Rapports"));
  c.push(para("Le module de generation de rapports permet de produire des documents formalises pour les differentes parties prenantes."));
  c.push(bullet("Rapports d'activite par periode"));
  c.push(bullet("Rapports par partenaire"));
  c.push(bullet("Rapports par region"));
  c.push(bullet("Rapports d'indicateurs"));
  c.push(bullet("Export en formats PDF et Excel"));
  c.push(emptyLine());

  c.push(heading2("3.11 Module Administration"));
  c.push(para("Le module d'administration est reserve aux utilisateurs ayant le role ADMIN_NATIONAL."));
  c.push(bullet("Gestion des utilisateurs : creation, modification, desactivation"));
  c.push(bullet("Attribution et gestion des roles RBAC"));
  c.push(bullet("Configuration des parametres systeme"));
  c.push(bullet("Gestion des donnees de reference (regions, departements, types)"));
  c.push(emptyLine());

  c.push(heading2("3.12 Module Audit Trail"));
  c.push(para("Le journal d'audit assure la tracabilite complete de toutes les actions effectuees sur la plateforme."));
  c.push(bullet("Enregistrement immuable de chaque creation, modification et suppression"));
  c.push(bullet("Informations enregistrees : utilisateur, action, entite, ancienne/nouvelle valeur, horodatage, adresse IP"));
  c.push(bullet("Filtres de recherche par utilisateur, type d'action, periode et entite"));
  c.push(bullet("Export du journal d'audit"));
  c.push(bullet("Retention des logs d'audit pendant 5 ans minimum"));
  c.push(pageBreak());

  // ── 4. Architecture technique ──
  c.push(heading1("4. Architecture technique"));
  c.push(heading2("4.1 Vue d'ensemble"));
  c.push(para("La plateforme IMS Partnerships repose sur une architecture full-stack moderne basee sur Next.js 16. Le choix de cette architecture monolithique permet de simplifier le deploiement tout en offrant les avantages du Server-Side Rendering (SSR) et des API Routes integrees."));
  c.push(emptyLine());
  c.push(heading2("4.2 Stack technique"));
  c.push(makeTable(["Couche", "Technologie", "Version", "Role"], [
    ["Frontend", "React", "19", "Interface utilisateur reactive"],
    ["Framework", "Next.js", "16", "SSR, routing, API routes"],
    ["CSS", "Tailwind CSS", "4", "Utility-first CSS framework"],
    ["UI Components", "shadcn/ui", "Latest", "Composants accessibles et personnalisables"],
    ["Graphiques", "Recharts", "Latest", "Visualisations de donnees"],
    ["Cartographie", "Leaflet", "Latest", "Cartes interactives"],
    ["ORM", "Prisma", "7", "Acces base de donnees type-safe"],
    ["BDD (dev)", "SQLite", "-", "Base de donnees de developpement"],
    ["BDD (prod)", "PostgreSQL", "15", "Base de donnees de production"],
    ["Auth", "NextAuth.js", "Latest", "Authentification et sessions"],
    ["Theme", "Dark mode", "-", "Glassmorphism avec couleurs IPD"],
    ["Runtime", "Node.js", "24", "Environnement d'execution JavaScript"],
  ]));
  c.push(emptyLine());
  c.push(heading2("4.3 Architecture frontend"));
  c.push(para("Le frontend est construit avec React 19 et utilise les Server Components de Next.js 16 pour optimiser les performances. L'interface adopte un design dark mode glassmorphism avec les couleurs de marque de l'IPD (#0089D0 bleu principal, #052A62 bleu fonce)."));
  c.push(emptyLine());
  c.push(heading3("4.3.1 Structure des composants"));
  c.push(bullet("Layout principal avec sidebar de navigation"));
  c.push(bullet("Composants shadcn/ui pour la coherence visuelle"));
  c.push(bullet("Gestion d'etat avec React hooks (useState, useEffect, useContext)"));
  c.push(bullet("Formulaires avec validation cote client"));
  c.push(bullet("Responsive design pour tablettes et desktop"));
  c.push(emptyLine());
  c.push(heading2("4.4 Architecture backend"));
  c.push(para("Le backend utilise les API Routes de Next.js pour exposer des endpoints REST. Prisma ORM assure l'acces type-safe a la base de donnees."));
  c.push(emptyLine());
  c.push(heading3("4.4.1 Couche API"));
  c.push(bullet("API Routes Next.js (app/api/)"));
  c.push(bullet("Middleware d'authentification et d'autorisation"));
  c.push(bullet("Validation des requetes avec Zod"));
  c.push(bullet("Gestion centralisee des erreurs"));
  c.push(bullet("Pagination et filtrage standardises"));
  c.push(emptyLine());
  c.push(heading3("4.4.2 Couche donnees"));
  c.push(bullet("Prisma ORM avec migrations versionnees"));
  c.push(bullet("Requetes optimisees avec select et include"));
  c.push(bullet("Transactions pour les operations critiques"));
  c.push(bullet("Pool de connexions gere par Prisma"));
  c.push(pageBreak());

  // ── 5. Modele de donnees ──
  c.push(heading1("5. Modele de donnees"));
  c.push(para("Le modele de donnees Prisma comprend 12 tables principales couvrant l'ensemble des entites metier de la plateforme."));
  c.push(emptyLine());
  c.push(heading2("5.1 Schema des tables"));
  c.push(makeTable(["Table", "Description", "Relations principales"], [
    ["User", "Utilisateurs de la plateforme", "Role, AuditLog, Region"],
    ["Project", "Projets et programmes", "Partner, Region, Indicator, Media"],
    ["Partner", "Partenaires techniques et financiers", "Project, Prospection"],
    ["Indicator", "Indicateurs de suivi (119)", "IndicatorValue, Project"],
    ["IndicatorValue", "Valeurs historiques des indicateurs", "Indicator, Project"],
    ["Region", "14 regions du Senegal", "Department, Project"],
    ["Department", "Departements administratifs", "Region, Project"],
    ["Prospection", "Opportunites de prospection", "Partner, User"],
    ["Media", "Fichiers multimedia", "Project, Region"],
    ["AuditLog", "Journal d'audit immuable", "User"],
    ["Report", "Rapports generes", "User, Project"],
    ["Session", "Sessions utilisateur", "User"],
  ]));
  c.push(emptyLine());
  c.push(heading2("5.2 Table User"));
  c.push(makeTable(["Champ", "Type", "Contrainte", "Description"], [
    ["id", "String (CUID)", "PK", "Identifiant unique"],
    ["email", "String", "UNIQUE, NOT NULL", "Adresse email"],
    ["name", "String", "NOT NULL", "Nom complet"],
    ["password", "String", "NULL (SSO)", "Hash bcrypt du mot de passe"],
    ["role", "Enum Role", "NOT NULL", "ADMIN_NATIONAL, CHARGE_SUIVI, PARTENAIRE_TECHNIQUE, OBSERVATEUR"],
    ["regionId", "String", "FK -> Region", "Region d'affectation"],
    ["active", "Boolean", "DEFAULT true", "Statut du compte"],
    ["createdAt", "DateTime", "DEFAULT now()", "Date de creation"],
    ["updatedAt", "DateTime", "AUTO", "Derniere modification"],
  ]));
  c.push(emptyLine());
  c.push(heading2("5.3 Table Project"));
  c.push(makeTable(["Champ", "Type", "Contrainte", "Description"], [
    ["id", "String (CUID)", "PK", "Identifiant unique"],
    ["title", "String", "NOT NULL", "Titre du projet"],
    ["description", "Text", "NULL", "Description detaillee"],
    ["status", "Enum Status", "NOT NULL", "ACTIF, EN_PAUSE, TERMINE, ANNULE"],
    ["startDate", "DateTime", "NOT NULL", "Date de debut"],
    ["endDate", "DateTime", "NULL", "Date de fin prevue"],
    ["budget", "Float", "NULL", "Budget total en FCFA"],
    ["progress", "Int", "DEFAULT 0", "Pourcentage d'avancement (0-100)"],
    ["partnerId", "String", "FK -> Partner", "Partenaire associe"],
    ["regionId", "String", "FK -> Region", "Region d'intervention"],
    ["departmentId", "String", "FK -> Department", "Departement"],
    ["createdAt", "DateTime", "DEFAULT now()", "Date de creation"],
    ["updatedAt", "DateTime", "AUTO", "Derniere modification"],
  ]));
  c.push(emptyLine());
  c.push(heading2("5.4 Diagramme des relations"));
  c.push(...codeBlock([
    "User ──┬── AuditLog",
    "       ├── Session",
    "       └── Report",
    "",
    "Partner ──┬── Project",
    "          └── Prospection",
    "",
    "Region ──┬── Department",
    "         ├── Project",
    "         └── Media",
    "",
    "Project ──┬── IndicatorValue",
    "          ├── Media",
    "          └── Report",
    "",
    "Indicator ── IndicatorValue",
  ]));
  c.push(pageBreak());

  // ── 6. APIs REST ──
  c.push(heading1("6. APIs REST"));
  c.push(para("La plateforme expose des endpoints REST via les API Routes de Next.js. Tous les endpoints sont prefixes par /api et necessitent une authentification sauf mention contraire."));
  c.push(emptyLine());
  c.push(heading2("6.1 Authentification"));
  c.push(makeTable(["Methode", "Endpoint", "Description", "Auth"], [
    ["POST", "/api/auth/login", "Connexion email/mot de passe", "Non"],
    ["POST", "/api/auth/sso", "Connexion SSO (HMAC-SHA256)", "Non"],
    ["POST", "/api/auth/logout", "Deconnexion", "Oui"],
    ["GET", "/api/auth/session", "Session courante", "Oui"],
  ]));
  c.push(emptyLine());
  c.push(heading2("6.2 Projets"));
  c.push(makeTable(["Methode", "Endpoint", "Description", "Roles autorises"], [
    ["GET", "/api/projects", "Liste des projets (paginee, filtrable)", "Tous"],
    ["GET", "/api/projects/:id", "Detail d'un projet", "Tous"],
    ["POST", "/api/projects", "Creer un projet", "ADMIN, CHARGE_SUIVI"],
    ["PUT", "/api/projects/:id", "Modifier un projet", "ADMIN, CHARGE_SUIVI"],
    ["PATCH", "/api/projects/:id/progress", "Mettre a jour l'avancement", "ADMIN, CHARGE_SUIVI"],
    ["DELETE", "/api/projects/:id", "Supprimer un projet", "ADMIN"],
    ["GET", "/api/projects/:id/indicators", "Indicateurs du projet", "Tous"],
    ["GET", "/api/projects/:id/media", "Medias du projet", "Tous"],
  ]));
  c.push(emptyLine());
  c.push(heading2("6.3 Partenaires"));
  c.push(makeTable(["Methode", "Endpoint", "Description", "Roles autorises"], [
    ["GET", "/api/partners", "Liste des partenaires", "Tous"],
    ["GET", "/api/partners/:id", "Detail d'un partenaire", "Tous"],
    ["POST", "/api/partners", "Creer un partenaire", "ADMIN, CHARGE_SUIVI"],
    ["PUT", "/api/partners/:id", "Modifier un partenaire", "ADMIN, CHARGE_SUIVI"],
    ["DELETE", "/api/partners/:id", "Supprimer un partenaire", "ADMIN"],
  ]));
  c.push(emptyLine());
  c.push(heading2("6.4 Indicateurs"));
  c.push(makeTable(["Methode", "Endpoint", "Description", "Roles autorises"], [
    ["GET", "/api/indicators", "Liste des 119 indicateurs", "Tous"],
    ["GET", "/api/indicators/:id", "Detail d'un indicateur", "Tous"],
    ["POST", "/api/indicators/:id/values", "Saisir une valeur", "ADMIN, CHARGE_SUIVI"],
    ["GET", "/api/indicators/:id/values", "Historique des valeurs", "Tous"],
    ["GET", "/api/indicators/cross-table", "Table croisee dynamique", "Tous"],
  ]));
  c.push(emptyLine());
  c.push(heading2("6.5 Prospection"));
  c.push(makeTable(["Methode", "Endpoint", "Description", "Roles autorises"], [
    ["GET", "/api/prospections", "Liste des prospections", "ADMIN, CHARGE_SUIVI"],
    ["POST", "/api/prospections", "Creer une prospection", "ADMIN, CHARGE_SUIVI"],
    ["PATCH", "/api/prospections/:id/stage", "Changer d'etape Kanban", "ADMIN, CHARGE_SUIVI"],
    ["POST", "/api/prospections/:id/notes", "Ajouter une note", "ADMIN, CHARGE_SUIVI"],
  ]));
  c.push(emptyLine());
  c.push(heading2("6.6 Autres endpoints"));
  c.push(makeTable(["Methode", "Endpoint", "Description", "Roles autorises"], [
    ["GET", "/api/regions", "Liste des 14 regions", "Tous"],
    ["GET", "/api/departments", "Liste des departements", "Tous"],
    ["GET", "/api/dashboard/stats", "Statistiques du dashboard", "Tous"],
    ["POST", "/api/media/upload", "Upload de media", "ADMIN, CHARGE_SUIVI"],
    ["GET", "/api/media", "Liste des medias", "Tous"],
    ["GET", "/api/reports", "Liste des rapports", "Tous"],
    ["POST", "/api/reports/generate", "Generer un rapport", "ADMIN, CHARGE_SUIVI"],
    ["GET", "/api/audit", "Journal d'audit", "ADMIN"],
    ["GET", "/api/users", "Liste des utilisateurs", "ADMIN"],
    ["POST", "/api/users", "Creer un utilisateur", "ADMIN"],
    ["PUT", "/api/users/:id", "Modifier un utilisateur", "ADMIN"],
    ["GET", "/api/health", "Etat de sante de l'application", "Non"],
  ]));
  c.push(pageBreak());

  // ── 7. Securite et RBAC ──
  c.push(heading1("7. Securite et RBAC"));
  c.push(heading2("7.1 Authentification"));
  c.push(para("La plateforme supporte deux methodes d'authentification complementaires :"));
  c.push(emptyLine());
  c.push(heading3("7.1.1 SSO (Single Sign-On)"));
  c.push(para("L'authentification SSO utilise un mecanisme de signature HMAC-SHA256 avec un secret partage entre le portail IPD et la plateforme IMS Partnerships. Le portail genere un token signe contenant l'identite de l'utilisateur, qui est verifie par la plateforme."));
  c.push(bullet("Algorithme : HMAC-SHA256"));
  c.push(bullet("Secret partage : configure dans les variables d'environnement"));
  c.push(bullet("Duree de validite du token : 5 minutes"));
  c.push(bullet("Verification du timestamp pour prevenir les attaques de rejeu"));
  c.push(emptyLine());
  c.push(heading3("7.1.2 Email / Mot de passe"));
  c.push(para("Pour les utilisateurs qui n'ont pas acces au portail IPD, une authentification classique par email et mot de passe est disponible."));
  c.push(bullet("Hachage des mots de passe avec bcrypt (cost factor 12)"));
  c.push(bullet("Politique de mot de passe : minimum 12 caracteres, 1 majuscule, 1 chiffre, 1 caractere special"));
  c.push(bullet("Verrouillage du compte apres 5 tentatives echouees"));
  c.push(bullet("Session securisee avec cookie HttpOnly, Secure, SameSite=Strict"));
  c.push(emptyLine());
  c.push(heading2("7.2 Modele RBAC"));
  c.push(para("Le controle d'acces repose sur 4 roles hierarchiques. Chaque endpoint et chaque fonctionnalite de l'interface verifie le role de l'utilisateur connecte."));
  c.push(emptyLine());
  c.push(makeTable(["Role", "Description", "Acces principaux"], [
    ["ADMIN_NATIONAL", "Administrateur national", "Acces total : tous les modules, gestion des utilisateurs, configuration systeme, audit trail"],
    ["CHARGE_SUIVI", "Charge de suivi", "Saisie, mise a jour, prospection, rapports, indicateurs sur toutes les regions"],
    ["PARTENAIRE_TECHNIQUE", "Partenaire technique", "Consultation des projets et indicateurs lies a son perimetre, upload de medias"],
    ["OBSERVATEUR", "Observateur", "Lecture seule : dashboard, portefeuille projets, cartographie, indicateurs"],
  ]));
  c.push(emptyLine());
  c.push(heading2("7.3 Matrice des permissions"));
  c.push(makeTable(["Module", "ADMIN_NATIONAL", "CHARGE_SUIVI", "PARTENAIRE_TECH", "OBSERVATEUR"], [
    ["Dashboard", "Lecture", "Lecture", "Lecture", "Lecture"],
    ["Prospection", "CRUD", "CRUD", "Lecture", "Aucun"],
    ["Partenaires", "CRUD", "CRUD", "Lecture", "Lecture"],
    ["Projets", "CRUD", "CRUD", "Lecture", "Lecture"],
    ["Saisie", "CRUD", "CRUD", "Lecture", "Aucun"],
    ["Indicateurs", "CRUD", "CRUD", "Lecture", "Lecture"],
    ["Gestionnaire", "CRUD", "CRUD", "Aucun", "Aucun"],
    ["Cartographie", "Lecture", "Lecture", "Lecture", "Lecture"],
    ["Medias", "CRUD", "CRUD", "Upload", "Lecture"],
    ["Rapports", "CRUD", "CRUD", "Lecture", "Lecture"],
    ["Administration", "CRUD", "Aucun", "Aucun", "Aucun"],
    ["Audit Trail", "Lecture", "Aucun", "Aucun", "Aucun"],
  ]));
  c.push(pageBreak());

  // ── 8. Performance ──
  c.push(heading1("8. Performance et scalabilite"));
  c.push(heading2("8.1 Objectifs de performance"));
  c.push(makeTable(["Metrique", "Objectif", "Mesure"], [
    ["Temps de chargement initial", "< 3 secondes", "First Contentful Paint"],
    ["Temps de reponse API", "< 500ms (P95)", "Mesure cote serveur"],
    ["Time to Interactive", "< 5 secondes", "Lighthouse"],
    ["Score Lighthouse", "> 80", "Performance"],
    ["Utilisateurs simultanes", "> 50", "Sans degradation"],
    ["Disponibilite", "> 99.5%", "Uptime annuel"],
  ]));
  c.push(emptyLine());
  c.push(heading2("8.2 Strategies d'optimisation"));
  c.push(bullet("Server-Side Rendering (SSR) avec Next.js pour un chargement rapide"));
  c.push(bullet("Mise en cache des requetes frequentes (React cache, revalidation)"));
  c.push(bullet("Pagination des listes (20 elements par page par defaut)"));
  c.push(bullet("Chargement paresseux (lazy loading) des composants lourds (Leaflet, Recharts)"));
  c.push(bullet("Optimisation des images (Next.js Image avec WebP)"));
  c.push(bullet("Compression gzip/brotli via Nginx"));
  c.push(bullet("Index de base de donnees sur les colonnes frequemment filtrees"));
  c.push(bullet("Pool de connexions PostgreSQL via Prisma"));
  c.push(pageBreak());

  // ── 9. Contraintes techniques ──
  c.push(heading1("9. Contraintes techniques"));
  c.push(heading2("9.1 Contraintes d'infrastructure"));
  c.push(bullet("Hebergement sur infrastructure IPD (JumpServer avec VPN)"));
  c.push(bullet("Connexion Internet requise pour les utilisateurs"));
  c.push(bullet("Bande passante variable selon les regions du Senegal"));
  c.push(bullet("Alimentation electrique potentiellement instable (onduleur requis)"));
  c.push(emptyLine());
  c.push(heading2("9.2 Contraintes de compatibilite"));
  c.push(bullet("Navigateurs supportes : Chrome 90+, Firefox 90+, Safari 15+, Edge 90+"));
  c.push(bullet("Resolution minimale : 1024x768 pixels"));
  c.push(bullet("Pas de support mobile natif (responsive tablette minimum)"));
  c.push(emptyLine());
  c.push(heading2("9.3 Contraintes reglementaires"));
  c.push(bullet("Conformite avec la loi senegalaise sur la protection des donnees personnelles"));
  c.push(bullet("Hebergement des donnees au Senegal ou dans un pays avec accord d'adequation"));
  c.push(bullet("Retention des donnees d'audit pendant 5 ans minimum"));
  c.push(bullet("Droit d'acces et de rectification des donnees personnelles"));
  c.push(pageBreak());

  // ── 10. Planning ──
  c.push(heading1("10. Planning de deploiement"));
  c.push(makeTable(["Phase", "Duree", "Dates", "Livrables"], [
    ["Preparation infrastructure", "2 semaines", "S1-S2", "Serveur configure, VPN operationnel"],
    ["Installation et configuration", "1 semaine", "S3", "Docker, Nginx, PostgreSQL, SSL"],
    ["Migration des donnees", "1 semaine", "S4", "BDD migree de SQLite vers PostgreSQL"],
    ["Tests d'integration", "2 semaines", "S5-S6", "Tests fonctionnels et de performance"],
    ["Formation utilisateurs", "1 semaine", "S7", "Sessions de formation, documentation"],
    ["Recette utilisateur (UAT)", "2 semaines", "S8-S9", "PV de recette signe"],
    ["Mise en production", "1 semaine", "S10", "Plateforme accessible en production"],
    ["Support post-deploiement", "4 semaines", "S11-S14", "Corrections, optimisations, support"],
  ]));
  c.push(pageBreak());

  // ── 11. RACI ──
  c.push(heading1("11. Matrice de responsabilites RACI"));
  c.push(para("R = Responsable, A = Autorite, C = Consulte, I = Informe"));
  c.push(emptyLine());
  c.push(makeTable(["Activite", "Chef Projet", "Dev Principal", "DevOps", "Resp. Securite", "Utilisateurs"], [
    ["Specification fonctionnelle", "A", "R", "I", "C", "C"],
    ["Developpement", "I", "R", "C", "C", "I"],
    ["Configuration serveur", "I", "C", "R", "A", "I"],
    ["Configuration VPN", "I", "I", "R", "A", "I"],
    ["Migration BDD", "I", "R", "C", "I", "I"],
    ["Tests fonctionnels", "A", "C", "I", "I", "R"],
    ["Tests de securite", "I", "C", "C", "R", "I"],
    ["Deploiement production", "A", "C", "R", "C", "I"],
    ["Formation", "A", "R", "I", "I", "R"],
    ["Maintenance", "I", "R", "R", "C", "I"],
    ["Sauvegarde et PRA", "I", "I", "R", "A", "I"],
    ["Monitoring", "I", "C", "R", "C", "I"],
  ]));
  c.push(pageBreak());

  // ── 12. Annexes ──
  c.push(heading1("12. Annexes"));
  c.push(heading2("12.1 Stack technique complete"));
  c.push(makeTable(["Categorie", "Technologie", "Usage"], [
    ["Language", "TypeScript", "Typage statique"],
    ["Framework", "Next.js 16", "Full-stack React"],
    ["UI", "React 19", "Composants reactifs"],
    ["CSS", "Tailwind CSS 4", "Styles utilitaires"],
    ["Composants", "shadcn/ui", "Design system"],
    ["Graphiques", "Recharts", "Visualisations"],
    ["Cartes", "Leaflet", "Cartographie"],
    ["ORM", "Prisma 7", "Acces BDD"],
    ["BDD", "PostgreSQL 15", "Stockage production"],
    ["Auth", "NextAuth.js", "Authentification"],
    ["Validation", "Zod", "Schemas de validation"],
    ["Icons", "Lucide React", "Icones SVG"],
    ["State", "React Hooks", "Gestion d'etat"],
    ["Drag & Drop", "dnd-kit", "Kanban"],
    ["Date", "date-fns", "Manipulation de dates"],
  ]));
  c.push(emptyLine());
  c.push(heading2("12.2 Glossaire"));
  c.push(makeTable(["Terme", "Definition"], [
    ["IMS", "Information Management System"],
    ["IPD", "Institut Pasteur de Dakar"],
    ["SSR", "Server-Side Rendering"],
    ["SSO", "Single Sign-On"],
    ["RBAC", "Role-Based Access Control"],
    ["CRUD", "Create, Read, Update, Delete"],
    ["ORM", "Object-Relational Mapping"],
    ["API", "Application Programming Interface"],
    ["KPI", "Key Performance Indicator"],
    ["RACI", "Responsible, Accountable, Consulted, Informed"],
    ["UAT", "User Acceptance Testing"],
    ["PRA", "Plan de Reprise d'Activite"],
    ["HMAC", "Hash-based Message Authentication Code"],
    ["CSP", "Content Security Policy"],
    ["HSTS", "HTTP Strict Transport Security"],
  ]));

  return new Document({
    ...docDefaults(),
    sections: [{
      headers: { default: makeHeader() },
      footers: { default: makeFooter() },
      children,
    }],
  });
}

// ═══════════════════════════════════════════════════════════════
// DOCUMENT 3 — Guide Utilisateur
// ═══════════════════════════════════════════════════════════════
function buildDoc3() {
  const children = [];
  const c = children;

  // Cover
  c.push(...coverPage(
    "Guide Utilisateur de la Plateforme",
    "Manuel Complet pour Tous les Profils Utilisateurs",
    "1.0"
  ));

  // TOC
  c.push(heading1("Table des matieres"));
  c.push(para("1. Introduction"));
  c.push(para("2. Connexion a la plateforme"));
  c.push(para("3. Navigation et interface"));
  c.push(para("4. Module Dashboard"));
  c.push(para("5. Module Prospection"));
  c.push(para("6. Module Partenaires"));
  c.push(para("7. Module Portefeuille Projets"));
  c.push(para("8. Module Saisie et Mise a jour"));
  c.push(para("9. Module Indicateurs"));
  c.push(para("10. Module Gestionnaire Departemental"));
  c.push(para("11. Module Cartographie"));
  c.push(para("12. Module Medias"));
  c.push(para("13. Module Rapports"));
  c.push(para("14. Module Administration"));
  c.push(para("15. Module Audit Trail"));
  c.push(para("16. FAQ et support"));
  c.push(pageBreak());

  // ── 1. Introduction ──
  c.push(heading1("1. Introduction"));
  c.push(heading2("1.1 A propos de ce guide"));
  c.push(para("Ce guide utilisateur presente l'ensemble des fonctionnalites de la plateforme IMS Partnerships de l'Institut Pasteur de Dakar. Il est destine a tous les profils d'utilisateurs, quel que soit leur role dans le systeme."));
  c.push(para("La plateforme IMS Partnerships est un outil de gestion des partenariats qui permet de centraliser, suivre et analyser l'ensemble des collaborations de l'IPD. Elle gere actuellement 247 projets, 164 partenaires et 119 indicateurs de performance repartis sur les 14 regions du Senegal."));
  c.push(emptyLine());
  c.push(heading2("1.2 Profils utilisateurs"));
  c.push(para("La plateforme distingue quatre profils d'utilisateurs avec des niveaux d'acces differents :"));
  c.push(emptyLine());
  c.push(makeTable(["Profil", "Description", "Acces principal"], [
    ["Administrateur National", "Gestionnaire global de la plateforme", "Acces complet a tous les modules, gestion des utilisateurs et configuration"],
    ["Charge de Suivi", "Agent de suivi des partenariats", "Saisie, mise a jour, prospection et rapports sur toutes les regions"],
    ["Partenaire Technique", "Representant d'un organisme partenaire", "Consultation des projets et indicateurs de son perimetre, upload de medias"],
    ["Observateur", "Utilisateur en consultation", "Lecture seule sur le dashboard, le portefeuille projets et la cartographie"],
  ]));
  c.push(emptyLine());
  c.push(heading2("1.3 Pre-requis techniques"));
  c.push(bullet("Navigateur web moderne : Google Chrome 90+, Mozilla Firefox 90+, Safari 15+ ou Microsoft Edge 90+"));
  c.push(bullet("Connexion Internet stable"));
  c.push(bullet("Resolution d'ecran minimale : 1024 x 768 pixels (tablette ou ordinateur)"));
  c.push(bullet("JavaScript active dans le navigateur"));
  c.push(pageBreak());

  // ── 2. Connexion ──
  c.push(heading1("2. Connexion a la plateforme"));
  c.push(para("La plateforme offre deux methodes de connexion pour s'adapter aux differents contextes d'utilisation."));
  c.push(emptyLine());
  c.push(heading2("2.1 Methode 1 : Connexion SSO (Single Sign-On)"));
  c.push(para("La connexion SSO est la methode recommandee pour les utilisateurs disposant d'un compte sur le portail de l'Institut Pasteur de Dakar."));
  c.push(emptyLine());
  c.push(new Paragraph({ spacing: { after: 60 }, children: [bold("Etape 1 : "), normal("Accedez au portail IPD (portail.pasteur.sn)")] }));
  c.push(new Paragraph({ spacing: { after: 60 }, children: [bold("Etape 2 : "), normal("Connectez-vous avec vos identifiants IPD habituels")] }));
  c.push(new Paragraph({ spacing: { after: 60 }, children: [bold("Etape 3 : "), normal("Cliquez sur l'icone ou le lien « IMS Partnerships » dans le menu des applications")] }));
  c.push(new Paragraph({ spacing: { after: 60 }, children: [bold("Etape 4 : "), normal("Vous etes automatiquement connecte a la plateforme sans ressaisir vos identifiants")] }));
  c.push(emptyLine());
  c.push(para("Le mecanisme SSO utilise une signature HMAC-SHA256 pour securiser l'echange d'identite entre le portail IPD et la plateforme. Le token est valide pendant 5 minutes et ne peut etre reutilise."));
  c.push(emptyLine());
  c.push(heading2("2.2 Methode 2 : Connexion par email et mot de passe"));
  c.push(para("Pour les utilisateurs externes ou ceux n'ayant pas acces au portail IPD, une connexion directe par email et mot de passe est disponible."));
  c.push(emptyLine());
  c.push(new Paragraph({ spacing: { after: 60 }, children: [bold("Etape 1 : "), normal("Accedez directement a l'URL de la plateforme (ims.pasteur.sn)")] }));
  c.push(new Paragraph({ spacing: { after: 60 }, children: [bold("Etape 2 : "), normal("Saisissez votre adresse email dans le champ « Email »")] }));
  c.push(new Paragraph({ spacing: { after: 60 }, children: [bold("Etape 3 : "), normal("Saisissez votre mot de passe dans le champ « Mot de passe »")] }));
  c.push(new Paragraph({ spacing: { after: 60 }, children: [bold("Etape 4 : "), normal("Cliquez sur le bouton « Se connecter »")] }));
  c.push(emptyLine());
  c.push(heading3("Politique de mot de passe"));
  c.push(bullet("Longueur minimale : 12 caracteres"));
  c.push(bullet("Au moins 1 lettre majuscule"));
  c.push(bullet("Au moins 1 chiffre"));
  c.push(bullet("Au moins 1 caractere special (!@#$%^&*)"));
  c.push(bullet("Le compte est verrouille apres 5 tentatives echouees"));
  c.push(emptyLine());
  c.push(heading2("2.3 Deconnexion"));
  c.push(para("Pour vous deconnecter, cliquez sur votre avatar ou votre nom en bas de la barre laterale, puis selectionnez « Deconnexion ». Votre session sera immediatement terminee."));
  c.push(pageBreak());

  // ── 3. Navigation ──
  c.push(heading1("3. Navigation et interface"));
  c.push(heading2("3.1 Interface generale"));
  c.push(para("La plateforme IMS Partnerships adopte un design moderne de type dark mode avec des effets de glassmorphism. Les couleurs principales sont le bleu IPD (#0089D0) et le bleu fonce (#052A62), garantissant une identite visuelle coherente avec la charte graphique de l'Institut Pasteur de Dakar."));
  c.push(emptyLine());
  c.push(heading2("3.2 Barre laterale de navigation (Sidebar)"));
  c.push(para("La navigation principale se fait via une barre laterale situee a gauche de l'ecran. Elle donne acces a tous les modules de la plateforme :"));
  c.push(emptyLine());
  c.push(makeTable(["Icone", "Module", "Description"], [
    ["Tableau de bord", "Dashboard", "Vue synthetique des KPI et graphiques"],
    ["Entonnoir", "Prospection", "Pipeline Kanban de prospection"],
    ["Personnes", "Partenaires", "Repertoire des partenaires"],
    ["Dossier", "Portefeuille Projets", "Liste complete des projets"],
    ["Crayon", "Saisie & Mise a jour", "Formulaires de saisie (4 onglets)"],
    ["Graphique", "Indicateurs", "Suivi des 119 indicateurs"],
    ["Carte", "Gestionnaire", "Dashboard departemental"],
    ["Globe", "Cartographie", "Carte interactive Leaflet"],
    ["Image", "Medias", "Galerie de fichiers multimedia"],
    ["Document", "Rapports", "Generation de rapports"],
    ["Bouclier", "Administration", "Gestion des utilisateurs (ADMIN)"],
    ["Historique", "Audit Trail", "Journal d'audit (ADMIN)"],
  ]));
  c.push(emptyLine());
  c.push(heading2("3.3 Elements communs de l'interface"));
  c.push(bullet("Fil d'Ariane : indique votre position dans l'arborescence des pages"));
  c.push(bullet("Boutons d'action : couleur bleue IPD pour les actions principales, gris pour les actions secondaires"));
  c.push(bullet("Notifications : affichees en haut a droite sous forme de toast"));
  c.push(bullet("Chargement : indicateur de progression lors des operations asynchrones"));
  c.push(bullet("Tableaux : tri par colonnes, pagination, recherche integree"));
  c.push(pageBreak());

  // ── 4. Dashboard ──
  c.push(heading1("4. Module Dashboard"));
  c.push(para("Le Dashboard est la page d'accueil de la plateforme. Il offre une vue synthetique et en temps reel de l'activite partenariale de l'IPD."));
  c.push(emptyLine());
  c.push(heading2("4.1 Cartes KPI"));
  c.push(para("En haut du tableau de bord, quatre cartes de KPI presentent les indicateurs cles :"));
  c.push(emptyLine());
  c.push(makeTable(["KPI", "Description", "Exemple"], [
    ["Nombre de projets", "Total des projets dans le portefeuille", "247 projets"],
    ["Nombre de partenaires", "Total des partenaires enregistres", "164 partenaires"],
    ["Budget total", "Somme des budgets de tous les projets actifs", "XX milliards FCFA"],
    ["Taux de realisation", "Moyenne du pourcentage d'avancement", "XX%"],
  ]));
  c.push(emptyLine());
  c.push(heading2("4.2 Graphiques interactifs"));
  c.push(para("Le Dashboard comprend plusieurs visualisations realisees avec la bibliotheque Recharts :"));
  c.push(bullet("Diagramme en barres : repartition des projets par region"));
  c.push(bullet("Diagramme circulaire : repartition par statut (actif, en pause, termine, annule)"));
  c.push(bullet("Courbe d'evolution : nombre de projets par annee"));
  c.push(bullet("Diagramme en barres empilees : projets par type de partenaire et region"));
  c.push(emptyLine());
  c.push(heading2("4.3 Filtres"));
  c.push(para("Les filtres permettent d'affiner les donnees affichees sur le tableau de bord :"));
  c.push(bullet("Filtre par periode : selectionnez une plage de dates"));
  c.push(bullet("Filtre par region : une ou plusieurs des 14 regions du Senegal"));
  c.push(bullet("Filtre par type de projet : technique, financier, institutionnel"));
  c.push(bullet("Filtre par statut : actif, en pause, termine, annule"));
  c.push(emptyLine());
  c.push(heading2("4.4 Toggle Actifs/Inactifs"));
  c.push(para("Un interrupteur situe en haut du dashboard permet de basculer entre deux vues :"));
  c.push(bullet("Actifs uniquement : affiche les projets en cours d'execution (par defaut)"));
  c.push(bullet("Tous les projets : inclut les projets termines, en pause et annules"));
  c.push(para("Les cartes KPI et les graphiques se mettent automatiquement a jour selon la selection."));
  c.push(pageBreak());

  // ── 5. Prospection ──
  c.push(heading1("5. Module Prospection"));
  c.push(para("Le module Prospection permet de gerer le pipeline d'opportunites de partenariat en utilisant une interface Kanban intuitive."));
  c.push(emptyLine());
  c.push(heading2("5.1 Vue Kanban"));
  c.push(para("Les opportunites de prospection sont organisees en colonnes representant les etapes du processus :"));
  c.push(emptyLine());
  c.push(makeTable(["Colonne", "Description", "Actions possibles"], [
    ["Identification", "Opportunite identifiee, recherche initiale", "Ajouter des notes, evaluer le potentiel"],
    ["Contact", "Premier contact etabli avec le partenaire potentiel", "Consigner les echanges, planifier les reunions"],
    ["Negociation", "Discussions en cours sur les termes du partenariat", "Suivre les propositions, ajuster le score"],
    ["Finalisation", "Accord de principe obtenu, formalites en cours", "Preparer les documents, valider les termes"],
    ["Signe", "Partenariat officialise et signe", "Creer le projet associe, notifier l'equipe"],
  ]));
  c.push(emptyLine());
  c.push(heading2("5.2 Drag-and-Drop"));
  c.push(para("Pour deplacer une opportunite d'une colonne a une autre :"));
  c.push(new Paragraph({ spacing: { after: 60 }, children: [bold("Etape 1 : "), normal("Cliquez et maintenez le bouton de la souris sur la carte de l'opportunite")] }));
  c.push(new Paragraph({ spacing: { after: 60 }, children: [bold("Etape 2 : "), normal("Faites glisser la carte vers la colonne souhaitee")] }));
  c.push(new Paragraph({ spacing: { after: 60 }, children: [bold("Etape 3 : "), normal("Relachez la carte a l'endroit desire dans la colonne")] }));
  c.push(para("Le changement d'etape est automatiquement enregistre et trace dans le journal d'audit."));
  c.push(emptyLine());
  c.push(heading2("5.3 Score de maturation"));
  c.push(para("Chaque opportunite dispose d'un score de maturation qui reflete la probabilite de concretisation du partenariat. Ce score est calcule automatiquement en fonction de plusieurs criteres :"));
  c.push(bullet("Niveau de l'etape actuelle dans le pipeline"));
  c.push(bullet("Anciennete de l'opportunite"));
  c.push(bullet("Nombre d'interactions enregistrees"));
  c.push(bullet("Completude des informations renseignees"));
  c.push(emptyLine());
  c.push(heading2("5.4 Notes et commentaires"));
  c.push(para("Chaque carte de prospection permet d'ajouter des notes pour consigner les interactions, les observations et les actions a mener. Les notes sont horodatees et associees a l'utilisateur qui les a creees."));
  c.push(pageBreak());

  // ── 6. Partenaires ──
  c.push(heading1("6. Module Partenaires"));
  c.push(para("Le module Partenaires centralise l'ensemble des informations relatives aux 164 partenaires de l'IPD."));
  c.push(emptyLine());
  c.push(heading2("6.1 Repertoire des partenaires"));
  c.push(para("La page principale affiche la liste des partenaires sous forme de tableau avec les informations suivantes :"));
  c.push(bullet("Nom du partenaire"));
  c.push(bullet("Type (technique, financier, institutionnel, academique)"));
  c.push(bullet("Pays d'origine"));
  c.push(bullet("Nombre de projets associes"));
  c.push(bullet("Statut de la relation (actif, en pause, termine)"));
  c.push(emptyLine());
  c.push(heading2("6.2 Filtres disponibles"));
  c.push(bullet("Recherche textuelle par nom"));
  c.push(bullet("Filtre par type de partenaire"));
  c.push(bullet("Filtre par pays"));
  c.push(bullet("Filtre par statut"));
  c.push(bullet("Filtre par region d'intervention"));
  c.push(emptyLine());
  c.push(heading2("6.3 Wordcloud (Nuage de mots)"));
  c.push(para("La visualisation en nuage de mots offre une representation graphique de la repartition des partenaires. La taille de chaque mot est proportionnelle au nombre de projets associes. Le wordcloud peut etre filtre par type, secteur ou region."));
  c.push(emptyLine());
  c.push(heading2("6.4 Fiche detaillee"));
  c.push(para("En cliquant sur un partenaire, vous accedez a sa fiche detaillee comprenant :"));
  c.push(bullet("Informations generales : nom, type, pays, coordonnees"));
  c.push(bullet("Liste des projets associes avec leur statut"));
  c.push(bullet("Historique des partenariats"));
  c.push(bullet("Documents et medias associes"));
  c.push(bullet("Statistiques : nombre de projets, budget total, taux de realisation moyen"));
  c.push(pageBreak());

  // ── 7. Portefeuille Projets ──
  c.push(heading1("7. Module Portefeuille Projets"));
  c.push(para("Le portefeuille projets offre une vue complete et filtrable de l'ensemble des 247 projets de l'IPD."));
  c.push(emptyLine());
  c.push(heading2("7.1 Les 9 filtres"));
  c.push(para("Le module dispose de 9 filtres combinables pour une recherche precise :"));
  c.push(emptyLine());
  c.push(makeTable(["Filtre", "Type", "Description"], [
    ["Statut", "Liste deroulante", "Actif, En pause, Termine, Annule"],
    ["Region", "Liste deroulante", "14 regions du Senegal"],
    ["Departement", "Liste deroulante", "Dependant de la region selectionnee"],
    ["Partenaire", "Recherche avec autocompletion", "164 partenaires disponibles"],
    ["Type de projet", "Liste deroulante", "Technique, Financier, Institutionnel"],
    ["Annee", "Selecteur de date", "Annee de debut ou de fin"],
    ["Budget", "Plage de valeurs", "Budget minimum et maximum"],
    ["Indicateur", "Liste deroulante", "119 indicateurs disponibles"],
    ["Theme", "Liste deroulante", "Thematiques transversales"],
  ]));
  c.push(emptyLine());
  c.push(heading2("7.2 KPI dynamiques"));
  c.push(para("Au-dessus de la liste des projets, des cartes KPI se recalculent automatiquement en fonction des filtres appliques :"));
  c.push(bullet("Nombre de projets correspondant aux criteres"));
  c.push(bullet("Budget total des projets filtres"));
  c.push(bullet("Taux d'avancement moyen"));
  c.push(bullet("Nombre de partenaires impliques"));
  c.push(emptyLine());
  c.push(heading2("7.3 Cartes projets"));
  c.push(para("Chaque projet est represente par une carte contenant :"));
  c.push(bullet("Titre du projet"));
  c.push(bullet("Partenaire associe"));
  c.push(bullet("Region et departement"));
  c.push(bullet("Barre de progression avec pourcentage d'avancement"));
  c.push(bullet("Statut avec code couleur (vert = actif, orange = en pause, gris = termine)"));
  c.push(bullet("Dates de debut et de fin"));
  c.push(pageBreak());

  // ── 8. Saisie & Mise a jour ──
  c.push(heading1("8. Module Saisie et Mise a jour"));
  c.push(para("Le module de saisie est le point d'entree principal pour la creation et la mise a jour des donnees dans la plateforme. Il est organise en 4 onglets."));
  c.push(emptyLine());
  c.push(heading2("8.1 Onglet « Nouveau Projet »"));
  c.push(para("Cet onglet permet de creer un nouveau projet dans le systeme."));
  c.push(emptyLine());
  c.push(heading3("Champs du formulaire"));
  c.push(makeTable(["Champ", "Type", "Obligatoire", "Description"], [
    ["Titre", "Texte", "Oui", "Nom du projet (max 200 caracteres)"],
    ["Description", "Zone de texte", "Non", "Description detaillee du projet"],
    ["Partenaire", "Selection", "Oui", "Partenaire associe (recherche avec autocompletion)"],
    ["Region", "Selection", "Oui", "Region d'intervention"],
    ["Departement", "Selection", "Oui", "Departement (filtre par region)"],
    ["Date de debut", "Calendrier", "Oui", "Date de demarrage du projet"],
    ["Date de fin", "Calendrier", "Non", "Date de fin prevue"],
    ["Budget", "Numerique", "Non", "Budget en FCFA"],
    ["Statut", "Selection", "Oui", "Statut initial du projet"],
  ]));
  c.push(emptyLine());
  c.push(heading3("Procedure de saisie"));
  c.push(new Paragraph({ spacing: { after: 60 }, children: [bold("1. "), normal("Remplissez tous les champs obligatoires (marques d'un asterisque)")] }));
  c.push(new Paragraph({ spacing: { after: 60 }, children: [bold("2. "), normal("Verifiez les informations saisies")] }));
  c.push(new Paragraph({ spacing: { after: 60 }, children: [bold("3. "), normal("Cliquez sur « Enregistrer » pour creer le projet")] }));
  c.push(new Paragraph({ spacing: { after: 60 }, children: [bold("4. "), normal("Un message de confirmation s'affiche et le projet recoit un identifiant unique")] }));
  c.push(emptyLine());
  c.push(heading2("8.2 Onglet « Avancement »"));
  c.push(para("Cet onglet permet de mettre a jour le taux d'avancement des projets existants."));
  c.push(new Paragraph({ spacing: { after: 60 }, children: [bold("1. "), normal("Recherchez le projet par titre ou identifiant")] }));
  c.push(new Paragraph({ spacing: { after: 60 }, children: [bold("2. "), normal("Selectionnez le projet dans la liste des resultats")] }));
  c.push(new Paragraph({ spacing: { after: 60 }, children: [bold("3. "), normal("Ajustez le curseur d'avancement (0 a 100%)")] }));
  c.push(new Paragraph({ spacing: { after: 60 }, children: [bold("4. "), normal("Ajoutez un commentaire optionnel pour expliquer la mise a jour")] }));
  c.push(new Paragraph({ spacing: { after: 60 }, children: [bold("5. "), normal("Cliquez sur « Mettre a jour » pour enregistrer")] }));
  c.push(emptyLine());
  c.push(heading2("8.3 Onglet « Prospection »"));
  c.push(para("Cet onglet permet de saisir de nouvelles opportunites de prospection."));
  c.push(bullet("Nom du partenaire potentiel"));
  c.push(bullet("Type de partenariat envisage"));
  c.push(bullet("Description de l'opportunite"));
  c.push(bullet("Score de maturation initial"));
  c.push(bullet("Notes et observations"));
  c.push(emptyLine());
  c.push(heading2("8.4 Onglet « Indicateurs par Projet »"));
  c.push(para("Cet onglet permet de saisir les valeurs des indicateurs pour un projet specifique."));
  c.push(new Paragraph({ spacing: { after: 60 }, children: [bold("1. "), normal("Selectionnez le projet concerne")] }));
  c.push(new Paragraph({ spacing: { after: 60 }, children: [bold("2. "), normal("La liste des indicateurs associes au projet s'affiche")] }));
  c.push(new Paragraph({ spacing: { after: 60 }, children: [bold("3. "), normal("Saisissez la valeur actuelle pour chaque indicateur")] }));
  c.push(new Paragraph({ spacing: { after: 60 }, children: [bold("4. "), normal("Le systeme affiche l'ecart par rapport a la valeur cible")] }));
  c.push(new Paragraph({ spacing: { after: 60 }, children: [bold("5. "), normal("Cliquez sur « Sauvegarder » pour enregistrer toutes les valeurs")] }));
  c.push(pageBreak());

  // ── 9. Indicateurs ──
  c.push(heading1("9. Module Indicateurs"));
  c.push(para("Le module Indicateurs permet le suivi et l'analyse des 119 indicateurs de performance de la plateforme."));
  c.push(emptyLine());
  c.push(heading2("9.1 Liste des indicateurs"));
  c.push(para("La page principale affiche la liste complete des 119 indicateurs avec :"));
  c.push(bullet("Nom de l'indicateur"));
  c.push(bullet("Unite de mesure"));
  c.push(bullet("Valeur cible"));
  c.push(bullet("Derniere valeur enregistree"));
  c.push(bullet("Ecart par rapport a la cible (en % et en valeur absolue)"));
  c.push(bullet("Tendance (hausse, baisse, stable)"));
  c.push(emptyLine());
  c.push(heading2("9.2 Table croisee dynamique"));
  c.push(para("La table croisee permet de croiser les indicateurs avec differentes dimensions :"));
  c.push(bullet("Indicateurs x Projets : valeurs de chaque indicateur par projet"));
  c.push(bullet("Indicateurs x Regions : agregation des valeurs par region"));
  c.push(bullet("Indicateurs x Periodes : evolution temporelle des valeurs"));
  c.push(para("La table est interactive : cliquez sur une cellule pour voir le detail et l'historique."));
  c.push(emptyLine());
  c.push(heading2("9.3 Saisie des valeurs"));
  c.push(para("Les utilisateurs autorises (ADMIN_NATIONAL et CHARGE_SUIVI) peuvent saisir les valeurs directement dans la table :"));
  c.push(new Paragraph({ spacing: { after: 60 }, children: [bold("1. "), normal("Cliquez sur la cellule a renseigner")] }));
  c.push(new Paragraph({ spacing: { after: 60 }, children: [bold("2. "), normal("Saisissez la valeur numerique")] }));
  c.push(new Paragraph({ spacing: { after: 60 }, children: [bold("3. "), normal("Validez avec la touche Entree ou cliquez en dehors de la cellule")] }));
  c.push(new Paragraph({ spacing: { after: 60 }, children: [bold("4. "), normal("La valeur est automatiquement sauvegardee et l'ecart recalcule")] }));
  c.push(pageBreak());

  // ── 10. Gestionnaire Departemental ──
  c.push(heading1("10. Module Gestionnaire Departemental"));
  c.push(para("Le module Gestionnaire Departemental est concu pour les agents de terrain qui gerent les projets a l'echelle departementale."));
  c.push(emptyLine());
  c.push(heading2("10.1 Selection du departement"));
  c.push(para("A l'ouverture du module, selectionnez votre departement d'affectation dans la liste deroulante. La selection est memorisee pour vos connexions futures."));
  c.push(emptyLine());
  c.push(heading2("10.2 Dashboard departemental"));
  c.push(para("Une fois le departement selectionne, un tableau de bord specifique s'affiche avec :"));
  c.push(bullet("KPI du departement : nombre de projets locaux, partenaires, avancement moyen"));
  c.push(bullet("Graphiques de repartition des projets du departement"));
  c.push(bullet("Liste des projets actifs dans le perimetre geographique"));
  c.push(bullet("Alertes sur les projets necessitant une action"));
  c.push(emptyLine());
  c.push(heading2("10.3 Saisie departementale"));
  c.push(para("Le gestionnaire departemental peut directement saisir et mettre a jour les donnees des projets de son perimetre :"));
  c.push(bullet("Creation de nouveaux projets dans le departement"));
  c.push(bullet("Mise a jour de l'avancement des projets existants"));
  c.push(bullet("Saisie des valeurs d'indicateurs"));
  c.push(bullet("Upload de medias geolocalises"));
  c.push(pageBreak());

  // ── 11. Cartographie ──
  c.push(heading1("11. Module Cartographie"));
  c.push(para("Le module Cartographie offre une visualisation geographique interactive de l'ensemble des projets sur le territoire senegalais."));
  c.push(emptyLine());
  c.push(heading2("11.1 Carte interactive Leaflet"));
  c.push(para("La carte est basee sur la bibliotheque Leaflet avec un fond de carte OpenStreetMap. Elle couvre l'ensemble du territoire senegalais avec les 14 regions administratives."));
  c.push(emptyLine());
  c.push(heading2("11.2 Navigation sur la carte"));
  c.push(bullet("Zoom : utilisez la molette de la souris ou les boutons +/- en haut a gauche"));
  c.push(bullet("Deplacement : cliquez et faites glisser la carte"));
  c.push(bullet("Recentrage : cliquez sur le bouton « Recentrer » pour revenir a la vue initiale du Senegal"));
  c.push(emptyLine());
  c.push(heading2("11.3 Couches thematiques"));
  c.push(para("Plusieurs couches thematiques sont disponibles pour personnaliser la visualisation :"));
  c.push(emptyLine());
  c.push(makeTable(["Couche", "Description", "Legende"], [
    ["Projets par region", "Nombre de projets dans chaque region", "Echelle de couleurs (vert a rouge)"],
    ["Projets par type", "Repartition par type de projet", "Couleurs par categorie"],
    ["Projets par statut", "Statut des projets", "Vert (actif), Orange (en pause), Gris (termine)"],
    ["Budget par region", "Repartition du budget", "Echelle proportionnelle"],
    ["Densite", "Heatmap de concentration des projets", "Gradient chaud/froid"],
  ]));
  c.push(emptyLine());
  c.push(heading2("11.4 Marqueurs et popups"));
  c.push(para("Chaque projet est represente par un marqueur sur la carte. En cliquant sur un marqueur, une popup s'affiche avec les informations principales : titre, partenaire, statut et avancement. Un lien permet d'acceder directement a la fiche complete du projet."));
  c.push(pageBreak());

  // ── 12. Medias ──
  c.push(heading1("12. Module Medias"));
  c.push(para("Le module Medias permet de gerer les fichiers multimedia associes aux projets et aux activites de terrain."));
  c.push(emptyLine());
  c.push(heading2("12.1 Upload de fichiers"));
  c.push(para("Pour ajouter un media a la plateforme :"));
  c.push(new Paragraph({ spacing: { after: 60 }, children: [bold("1. "), normal("Cliquez sur le bouton « Ajouter un media » ou faites glisser vos fichiers dans la zone de depot")] }));
  c.push(new Paragraph({ spacing: { after: 60 }, children: [bold("2. "), normal("Selectionnez le projet associe (obligatoire)")] }));
  c.push(new Paragraph({ spacing: { after: 60 }, children: [bold("3. "), normal("Ajoutez un titre et une description (optionnel)")] }));
  c.push(new Paragraph({ spacing: { after: 60 }, children: [bold("4. "), normal("Cliquez sur « Envoyer » pour uploader le fichier")] }));
  c.push(emptyLine());
  c.push(heading2("12.2 Formats supportes"));
  c.push(makeTable(["Format", "Type", "Taille max"], [
    ["JPEG / JPG", "Image", "50 Mo"],
    ["PNG", "Image", "50 Mo"],
    ["PDF", "Document", "50 Mo"],
    ["DOCX", "Document", "50 Mo"],
  ]));
  c.push(emptyLine());
  c.push(heading2("12.3 Galerie"));
  c.push(para("La galerie affiche les medias sous forme de vignettes avec previsualisation. Un clic sur une vignette ouvre le media en plein ecran."));
  c.push(emptyLine());
  c.push(heading2("12.4 Extraction GPS (EXIF)"));
  c.push(para("Lorsque vous uploadez une photo prise avec un smartphone ou un appareil photo GPS, la plateforme extrait automatiquement les coordonnees GPS depuis les metadonnees EXIF de l'image. Le media est alors automatiquement geolocalise et visible sur la carte du module Cartographie."));
  c.push(pageBreak());

  // ── 13. Rapports ──
  c.push(heading1("13. Module Rapports"));
  c.push(para("Le module Rapports permet de generer des documents formalises pour les differentes parties prenantes."));
  c.push(emptyLine());
  c.push(heading2("13.1 Types de rapports"));
  c.push(makeTable(["Type de rapport", "Description", "Contenu principal"], [
    ["Rapport d'activite", "Synthese periodique de l'activite", "KPI, projets en cours, faits marquants"],
    ["Rapport par partenaire", "Bilan de la collaboration avec un partenaire", "Projets, budget, indicateurs, medias"],
    ["Rapport par region", "Etat des lieux d'une region", "Projets, partenaires, avancement par departement"],
    ["Rapport d'indicateurs", "Suivi des indicateurs de performance", "Valeurs, ecarts, tendances, graphiques"],
    ["Rapport de prospection", "Etat du pipeline de prospection", "Opportunites par etape, score, previsions"],
  ]));
  c.push(emptyLine());
  c.push(heading2("13.2 Generation d'un rapport"));
  c.push(new Paragraph({ spacing: { after: 60 }, children: [bold("1. "), normal("Selectionnez le type de rapport souhaite")] }));
  c.push(new Paragraph({ spacing: { after: 60 }, children: [bold("2. "), normal("Configurez les parametres (periode, region, partenaire, etc.)")] }));
  c.push(new Paragraph({ spacing: { after: 60 }, children: [bold("3. "), normal("Cliquez sur « Generer le rapport »")] }));
  c.push(new Paragraph({ spacing: { after: 60 }, children: [bold("4. "), normal("Le rapport est genere et disponible au telechargement en PDF ou Excel")] }));
  c.push(pageBreak());

  // ── 14. Administration ──
  c.push(heading1("14. Module Administration"));
  c.push(para("Le module Administration est reserve aux utilisateurs ayant le role ADMIN_NATIONAL. Il permet de gerer les utilisateurs et les parametres du systeme."));
  c.push(emptyLine());
  c.push(heading2("14.1 Gestion des utilisateurs"));
  c.push(heading3("Creer un utilisateur"));
  c.push(new Paragraph({ spacing: { after: 60 }, children: [bold("1. "), normal("Cliquez sur « Nouvel utilisateur »")] }));
  c.push(new Paragraph({ spacing: { after: 60 }, children: [bold("2. "), normal("Remplissez le formulaire : nom, email, role, region d'affectation")] }));
  c.push(new Paragraph({ spacing: { after: 60 }, children: [bold("3. "), normal("Definissez un mot de passe temporaire ou activez l'acces SSO")] }));
  c.push(new Paragraph({ spacing: { after: 60 }, children: [bold("4. "), normal("Cliquez sur « Creer » pour enregistrer le nouvel utilisateur")] }));
  c.push(emptyLine());
  c.push(heading3("Modifier un utilisateur"));
  c.push(bullet("Changer le role RBAC"));
  c.push(bullet("Modifier la region d'affectation"));
  c.push(bullet("Activer ou desactiver le compte"));
  c.push(bullet("Reinitialiser le mot de passe"));
  c.push(emptyLine());
  c.push(heading2("14.2 Attribution des roles RBAC"));
  c.push(para("L'attribution des roles determine les permissions de l'utilisateur sur la plateforme. Lors de la creation ou de la modification d'un utilisateur, selectionnez le role approprie dans la liste :"));
  c.push(bullet("ADMIN_NATIONAL : acces complet (a attribuer avec prudence)"));
  c.push(bullet("CHARGE_SUIVI : acces en edition sur tous les modules operationnels"));
  c.push(bullet("PARTENAIRE_TECHNIQUE : acces en lecture avec possibilite d'upload"));
  c.push(bullet("OBSERVATEUR : acces en lecture seule"));
  c.push(emptyLine());
  c.push(heading2("14.3 Configuration systeme"));
  c.push(bullet("Parametres generaux de la plateforme"));
  c.push(bullet("Gestion des donnees de reference (regions, departements, types de partenaires)"));
  c.push(bullet("Configuration des notifications"));
  c.push(bullet("Parametres de sauvegarde et de maintenance"));
  c.push(pageBreak());

  // ── 15. Audit Trail ──
  c.push(heading1("15. Module Audit Trail"));
  c.push(para("Le journal d'audit est un registre immuable de toutes les actions effectuees sur la plateforme. Il est accessible uniquement aux administrateurs nationaux."));
  c.push(emptyLine());
  c.push(heading2("15.1 Informations enregistrees"));
  c.push(para("Chaque entree du journal d'audit contient les informations suivantes :"));
  c.push(emptyLine());
  c.push(makeTable(["Champ", "Description", "Exemple"], [
    ["Date et heure", "Horodatage precis de l'action", "05/04/2026 14:32:15"],
    ["Utilisateur", "Nom et email de l'auteur", "Amadou Diallo (a.diallo@pasteur.sn)"],
    ["Action", "Type d'operation effectuee", "CREATION, MODIFICATION, SUPPRESSION"],
    ["Entite", "Type d'objet concerne", "Projet, Partenaire, Indicateur, Utilisateur"],
    ["Identifiant", "ID de l'objet concerne", "PRJ-2026-0042"],
    ["Ancienne valeur", "Valeur avant modification", "Avancement: 45%"],
    ["Nouvelle valeur", "Valeur apres modification", "Avancement: 60%"],
    ["Adresse IP", "IP de l'utilisateur", "10.8.0.2"],
  ]));
  c.push(emptyLine());
  c.push(heading2("15.2 Filtres de recherche"));
  c.push(bullet("Par utilisateur : retrouvez toutes les actions d'un utilisateur specifique"));
  c.push(bullet("Par type d'action : filtrez par creation, modification ou suppression"));
  c.push(bullet("Par periode : definissez une plage de dates"));
  c.push(bullet("Par entite : filtrez par type d'objet (projet, partenaire, indicateur)"));
  c.push(bullet("Recherche textuelle : recherchez dans les valeurs"));
  c.push(emptyLine());
  c.push(heading2("15.3 Export"));
  c.push(para("Le journal d'audit peut etre exporte en format CSV ou Excel pour archivage ou analyse externe. L'export respecte les filtres appliques."));
  c.push(emptyLine());
  c.push(heading2("15.4 Retention"));
  c.push(para("Les entrees du journal d'audit sont conservees pendant 5 ans minimum, conformement a la politique de l'IPD. Les donnees d'audit ne peuvent pas etre modifiees ou supprimees, garantissant ainsi l'integrite de la trace."));
  c.push(pageBreak());

  // ── 16. FAQ ──
  c.push(heading1("16. FAQ et Support"));
  c.push(heading2("16.1 Questions frequentes"));
  c.push(emptyLine());
  c.push(new Paragraph({ spacing: { after: 60 }, children: [bold("Q : J'ai oublie mon mot de passe, comment le reinitialiser ?")] }));
  c.push(para("R : Contactez l'administrateur national de la plateforme qui pourra reinitialiser votre mot de passe depuis le module Administration. Si vous utilisez le SSO, connectez-vous via le portail IPD."));
  c.push(emptyLine());
  c.push(new Paragraph({ spacing: { after: 60 }, children: [bold("Q : Je ne vois pas tous les modules dans la barre laterale")] }));
  c.push(para("R : L'affichage des modules depend de votre role. Les observateurs n'ont acces qu'aux modules de consultation. Contactez l'administrateur si vous pensez que vos droits sont insuffisants."));
  c.push(emptyLine());
  c.push(new Paragraph({ spacing: { after: 60 }, children: [bold("Q : Comment ajouter un nouveau partenaire ?")] }));
  c.push(para("R : Accedez au module Partenaires, cliquez sur « Ajouter un partenaire » et remplissez le formulaire. Cette action necessite le role ADMIN_NATIONAL ou CHARGE_SUIVI."));
  c.push(emptyLine());
  c.push(new Paragraph({ spacing: { after: 60 }, children: [bold("Q : Les donnees de la carte ne s'affichent pas correctement")] }));
  c.push(para("R : Verifiez votre connexion Internet car les tuiles de la carte sont chargees depuis OpenStreetMap. Essayez de rafraichir la page (F5). Si le probleme persiste, videz le cache du navigateur."));
  c.push(emptyLine());
  c.push(new Paragraph({ spacing: { after: 60 }, children: [bold("Q : Comment exporter des donnees ?")] }));
  c.push(para("R : Plusieurs modules proposent un bouton d'export (icone de telechargement). Les formats disponibles sont PDF et Excel selon le contexte."));
  c.push(emptyLine());
  c.push(new Paragraph({ spacing: { after: 60 }, children: [bold("Q : Mon upload de media echoue")] }));
  c.push(para("R : Verifiez que votre fichier ne depasse pas 50 Mo et qu'il est dans un format supporte (JPEG, PNG, PDF, DOCX). Si le probleme persiste, contactez le support technique."));
  c.push(emptyLine());
  c.push(new Paragraph({ spacing: { after: 60 }, children: [bold("Q : Comment modifier un projet deja cree ?")] }));
  c.push(para("R : Accedez au Portefeuille Projets, cliquez sur le projet concerne, puis cliquez sur le bouton « Modifier ». Enregistrez vos modifications. Cette action est tracee dans le journal d'audit."));
  c.push(emptyLine());
  c.push(heading2("16.2 Support technique"));
  c.push(para("Pour toute assistance technique, contactez l'equipe support de l'IPD :"));
  c.push(bullet("Email : support-ims@pasteur.sn"));
  c.push(bullet("Telephone : +221 33 839 92 00"));
  c.push(bullet("Horaires : Lundi a Vendredi, 8h00 - 17h00 (GMT)"));
  c.push(emptyLine());
  c.push(heading2("16.3 Signaler un probleme"));
  c.push(para("Pour signaler un bug ou un dysfonctionnement, envoyez un email a support-ims@pasteur.sn en precisant :"));
  c.push(bullet("Votre nom et votre role sur la plateforme"));
  c.push(bullet("Le module concerne"));
  c.push(bullet("Une description detaillee du probleme"));
  c.push(bullet("Les etapes pour reproduire le probleme"));
  c.push(bullet("Une capture d'ecran si possible"));

  return new Document({
    ...docDefaults(),
    sections: [{
      headers: { default: makeHeader() },
      footers: { default: makeFooter() },
      children,
    }],
  });
}

// ═══════════════════════════════════════════════════════════════
// MAIN — Generate all 3 documents
// ═══════════════════════════════════════════════════════════════
async function main() {
  console.log("Generating IMS Partnerships documents...\n");

  const docs = [
    { name: "Specifications_Techniques_Deploiement.docx", builder: buildDoc1 },
    { name: "Cahier_des_Charges_Technique.docx", builder: buildDoc2 },
    { name: "Guide_Utilisateur_Plateforme.docx", builder: buildDoc3 },
  ];

  for (const { name, builder } of docs) {
    const doc = builder();
    const buffer = await Packer.toBuffer(doc);
    const filepath = path.join(OUTPUT_DIR, name);
    fs.writeFileSync(filepath, buffer);
    const sizeMB = (buffer.length / (1024 * 1024)).toFixed(2);
    console.log(`  [OK] ${name} (${sizeMB} MB) -> ${filepath}`);
  }

  console.log("\nAll 3 documents generated successfully!");
}

main().catch(err => {
  console.error("Error:", err);
  process.exit(1);
});
