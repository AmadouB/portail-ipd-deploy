/**
 * Détecte et regroupe les partenaires ayant des noms similaires.
 * Logique: normalise les noms, détecte les doublons, crée des PartnerGroup.
 */
import { PrismaClient } from "../src/generated/prisma/client";
import { PrismaBetterSqlite3 } from "@prisma/adapter-better-sqlite3";
import path from "path";

const dbPath = path.resolve(__dirname, "..", "dev.db");
const adapter = new PrismaBetterSqlite3({ url: dbPath });
const prisma = new PrismaClient({ adapter } as any);

// Normalise un nom pour la comparaison
function normalize(name: string): string {
  return name
    .toLowerCase()
    .replace(/[''`]/g, "'")
    .replace(/[""]/g, '"')
    .replace(/\s+/g, " ")
    .replace(/\(.*?\)/g, "")      // Retire les parenthèses
    .replace(/\s*[-–—]\s*/g, " ") // Normalise les tirets
    .replace(/[.,;:!?]/g, "")
    .replace(/\b(the|le|la|les|de|du|des|et|and|of|for)\b/gi, "")
    .trim();
}

// Calcule un score de similarité (0-1) entre deux chaînes
function similarity(a: string, b: string): number {
  if (a === b) return 1;
  const shorter = a.length < b.length ? a : b;
  const longer = a.length >= b.length ? a : b;
  if (longer.length === 0) return 1;

  // Contenu commun
  if (longer.includes(shorter) || shorter.includes(longer)) return 0.9;

  // Levenshtein simplifié — ratio de caractères communs
  const set1 = new Set(a.split(" "));
  const set2 = new Set(b.split(" "));
  const intersection = [...set1].filter(w => set2.has(w));
  const union = new Set([...set1, ...set2]);
  return intersection.length / union.size;
}

// Règles manuelles de regroupement (acronyme → noms canoniques)
const MANUAL_GROUPS: Record<string, string[]> = {
  "AFD": ["Agence Française de développement"],
  "BMGF / Gates Foundation": ["Gates Foundation", "Bill & Melinda Gates"],
  "OMS / WHO": ["World Health Organization", "WHO"],
  "Institut Pasteur": ["Institut Pasteur de"],
  "PAVM / UA-CDC": ["PAVM", "Africa Center for disease control"],
  "Skoll Foundation": ["SKOLL FOUNDATION", "Skoll Foundation"],
};

async function main() {
  const partners = await prisma.partner.findMany({ orderBy: { name: "asc" } });
  console.log(`Total partenaires: ${partners.length}\n`);

  // Trouver les groupes par similarité de nom
  const groups: Map<string, string[]> = new Map(); // groupName → [partnerId]
  const assigned = new Set<string>();

  // 1. Regroupement manuel
  for (const [groupName, patterns] of Object.entries(MANUAL_GROUPS)) {
    const matched = partners.filter(p =>
      patterns.some(pat => p.name.toLowerCase().includes(pat.toLowerCase()))
    );
    if (matched.length > 1) {
      groups.set(groupName, matched.map(p => p.id));
      matched.forEach(p => assigned.add(p.id));
    }
  }

  // 2. Regroupement par acronyme identique
  const byAcronym = new Map<string, typeof partners>();
  for (const p of partners) {
    if (p.acronym && !assigned.has(p.id)) {
      const key = p.acronym.toUpperCase().trim();
      if (!byAcronym.has(key)) byAcronym.set(key, []);
      byAcronym.get(key)!.push(p);
    }
  }
  for (const [acr, list] of byAcronym) {
    if (list.length > 1) {
      const groupName = acr;
      if (!groups.has(groupName)) {
        groups.set(groupName, list.map(p => p.id));
        list.forEach(p => assigned.add(p.id));
      }
    }
  }

  // 3. Regroupement par similarité de nom normalisé
  for (let i = 0; i < partners.length; i++) {
    if (assigned.has(partners[i].id)) continue;
    const norm_i = normalize(partners[i].name);
    const matchedIds = [partners[i].id];

    for (let j = i + 1; j < partners.length; j++) {
      if (assigned.has(partners[j].id)) continue;
      const norm_j = normalize(partners[j].name);
      const sim = similarity(norm_i, norm_j);
      if (sim >= 0.7) {
        matchedIds.push(partners[j].id);
        assigned.add(partners[j].id);
      }
    }

    if (matchedIds.length > 1) {
      const groupName = partners[i].acronym || partners[i].name.split("(")[0].trim().substring(0, 30);
      groups.set(groupName, matchedIds);
      assigned.add(partners[i].id);
    }
  }

  // Créer les groupes en base
  console.log(`${groups.size} groupes detectes:\n`);
  let totalGrouped = 0;

  for (const [name, partnerIds] of groups) {
    // Créer ou trouver le groupe
    let group = await prisma.partnerGroup.findUnique({ where: { name } });
    if (!group) {
      group = await prisma.partnerGroup.create({ data: { name } });
    }

    // Assigner les partenaires
    for (const pid of partnerIds) {
      await prisma.partner.update({ where: { id: pid }, data: { groupId: group.id } });
    }

    const names = partners.filter(p => partnerIds.includes(p.id)).map(p => `${p.acronym || "?"} — ${p.name}`);
    console.log(`  [${name}] (${partnerIds.length} partenaires)`);
    names.forEach(n => console.log(`    └ ${n}`));
    totalGrouped += partnerIds.length;
  }

  console.log(`\n${totalGrouped} partenaires regroupes dans ${groups.size} groupes`);
  console.log(`${partners.length - totalGrouped} partenaires sans groupe (uniques)`);
}

main().catch(console.error).finally(() => prisma.$disconnect());
