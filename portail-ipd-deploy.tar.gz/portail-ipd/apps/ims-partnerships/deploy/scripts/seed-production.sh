#!/bin/bash
# ══════════════════════════════════════════════════════════════
# IMS Partnerships — Initialisation base de donnees production
# Usage: docker compose exec app bash deploy/scripts/seed-production.sh
# ══════════════════════════════════════════════════════════════

set -e

echo "═══ Initialisation base de donnees IMS Partnerships ═══"

echo "[1/4] Push schema PostgreSQL..."
npx prisma db push

echo "[2/4] Seed utilisateurs et donnees de base..."
npx tsx prisma/seed.ts

echo "[3/4] Seed indicateurs (119)..."
npx tsx scripts/seed-indicators.ts
npx tsx scripts/seed-indicators-missing.ts

echo "[4/4] Enrichissement partenaires (geocodage)..."
npx tsx scripts/enrich-partners.ts

echo ""
echo "═══ Base de donnees initialisee ═══"
echo "  Pour importer le tracker Excel, copiez le fichier dans le container:"
echo "  docker cp fichier.xlsx ims-app:/app/"
echo "  docker compose exec app npx tsx scripts/import-excel.ts"
