#!/bin/bash
# ══════════════════════════════════════════════════════════════
# IMS Partnerships — Installation serveur via JumpServer
# ══════════════════════════════════════════════════════════════
#
# Serveur cible : 10.99.1.10 (Ubuntu)
# Acces         : VPN IPD → JumpServer → SSH serveur
# Utilisateur   : amadou.bao
# Mot de passe  : Ul16s0%[VY5#lY$}
#
# ── Procedure de connexion ──
#   1. Connectez-vous au VPN IPD
#   2. Ouvrez JumpServer (https://jumpserver.ipd.sn ou IP interne)
#   3. Authentifiez-vous avec votre compte amadou.bao
#   4. Selectionnez l'asset "10.99.1.10" dans la liste des serveurs
#   5. Cliquez "Connexion" → terminal web ou client SSH
#   6. Executez ce script:
#      curl -fsSL https://raw.githubusercontent.com/AmadouB/ims-partnerships/main/deploy/scripts/setup-server.sh | bash
#
# ══════════════════════════════════════════════════════════════

set -euo pipefail

echo "══════════════════════════════════════════════════════════"
echo "  IMS Partnerships — Installation serveur"
echo "  Serveur : $(hostname -I 2>/dev/null || echo 'N/A') | $(date)"
echo "  Utilisateur : $(whoami)"
echo "══════════════════════════════════════════════════════════"

# ── Verification pre-requis ──
echo ""
echo "[0/8] Verification de l'environnement..."
if [ "$(id -u)" -eq 0 ]; then
    echo "⚠  Vous etes root. Le script cree un user applicatif."
else
    echo "✓  Utilisateur: $(whoami)"
fi

OS=$(lsb_release -d 2>/dev/null | cut -f2 || cat /etc/os-release | grep PRETTY_NAME | cut -d'"' -f2)
echo "✓  OS: $OS"

# ── 1. Mise a jour systeme ──
echo ""
echo "[1/8] Mise a jour systeme..."
sudo apt update -qq && sudo apt upgrade -y -qq
sudo apt install -y -qq curl git ufw fail2ban htop net-tools unzip

# ── 2. Installation Docker ──
echo ""
echo "[2/8] Installation Docker..."
if ! command -v docker &> /dev/null; then
    curl -fsSL https://get.docker.com | sudo sh
    sudo usermod -aG docker $(whoami)
    echo "✓  Docker installe"
    echo "⚠  IMPORTANT: Deconnectez-vous de JumpServer et reconnectez-vous"
    echo "   pour que le groupe 'docker' soit actif."
else
    echo "✓  Docker deja installe: $(docker --version)"
fi

sudo systemctl enable docker
sudo systemctl start docker

# Docker Compose plugin
if ! docker compose version &> /dev/null 2>&1; then
    sudo apt install -y -qq docker-compose-plugin
fi
echo "✓  Docker Compose: $(docker compose version 2>/dev/null || echo 'a installer apres reconnexion')"

# ── 3. Firewall UFW ──
echo ""
echo "[3/8] Configuration firewall UFW..."
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow ssh comment "SSH via JumpServer"
sudo ufw allow 80/tcp comment "HTTP IMS Partnerships"
sudo ufw allow from 10.99.0.0/16 comment "VPN IPD subnet"
sudo ufw --force enable
echo "✓  UFW actif"
sudo ufw status numbered

# ── 4. Fail2ban ──
echo ""
echo "[4/8] Configuration fail2ban..."
sudo tee /etc/fail2ban/jail.local > /dev/null << 'JAIL'
[DEFAULT]
bantime = 3600
findtime = 600
maxretry = 5
ignoreip = 10.99.0.0/16 127.0.0.1/8

[sshd]
enabled = true
port = ssh
filter = sshd
logpath = /var/log/auth.log
maxretry = 3
JAIL
sudo systemctl enable fail2ban
sudo systemctl restart fail2ban
echo "✓  fail2ban configure (whitelist VPN 10.99.0.0/16)"

# ── 5. Repertoire application ──
echo ""
echo "[5/8] Creation repertoire application..."
APP_DIR="/opt/ims-partnerships"
sudo mkdir -p $APP_DIR
sudo chown $(whoami):$(whoami) $APP_DIR

# Repertoires persistants
mkdir -p $APP_DIR/backups
mkdir -p $APP_DIR/public/uploads

# ── 6. Clone du repository ──
echo ""
echo "[6/8] Clone du repository GitHub..."
cd $APP_DIR
if [ -d ".git" ]; then
    git pull origin main
    echo "✓  Repository mis a jour"
else
    git clone https://github.com/AmadouB/ims-partnerships.git .
    echo "✓  Repository clone"
fi

# ── 7. Configuration environnement ──
echo ""
echo "[7/8] Configuration environnement production..."
if [ ! -f "$APP_DIR/.env" ]; then
    cp deploy/.env.production .env
    echo "✓  Fichier .env cree depuis le template"
    echo ""
    echo "╔════════════════════════════════════════════════════════╗"
    echo "║  IMPORTANT: Verifiez les secrets dans .env            ║"
    echo "║  nano $APP_DIR/.env                                   ║"
    echo "╚════════════════════════════════════════════════════════╝"
else
    echo "✓  Fichier .env existant conserve"
fi

# ── 8. Cron backup automatique ──
echo ""
echo "[8/8] Configuration backup automatique..."
CRON_CMD="0 2 * * * $APP_DIR/deploy/scripts/backup.sh >> /var/log/ims-backup.log 2>&1"
(crontab -l 2>/dev/null | grep -v "ims-backup" ; echo "$CRON_CMD") | crontab -
echo "✓  Backup quotidien configure a 02h00"

# ── Resume ──
echo ""
echo "══════════════════════════════════════════════════════════"
echo "  ✓  INSTALLATION TERMINEE"
echo "══════════════════════════════════════════════════════════"
echo ""
echo "  Serveur    : $(hostname -I 2>/dev/null | awk '{print $1}')"
echo "  App dir    : $APP_DIR"
echo "  Docker     : $(docker --version 2>/dev/null || echo 'reconnexion requise')"
echo "  UFW        : actif (80/tcp, SSH, VPN 10.99.0.0/16)"
echo "  Fail2ban   : actif"
echo "  Backup     : quotidien a 02h00"
echo ""
echo "  ── Prochaines etapes ──"
echo ""
echo "  1. Si premiere installation, deconnectez-vous de JumpServer"
echo "     et reconnectez-vous (pour le groupe docker)"
echo ""
echo "  2. Editez les secrets de production:"
echo "     nano $APP_DIR/.env"
echo ""
echo "  3. Construisez et lancez l'application:"
echo "     cd $APP_DIR"
echo "     docker compose up -d --build"
echo ""
echo "  4. Initialisez la base de donnees:"
echo "     docker compose exec app npx prisma db push"
echo "     docker compose exec app bash deploy/scripts/seed-production.sh"
echo ""
echo "  5. Accedez a l'application (via VPN):"
echo "     http://10.99.1.10"
echo ""
echo "  ── Commandes JumpServer utiles ──"
echo ""
echo "  Logs app     : docker compose logs -f app"
echo "  Logs nginx   : docker compose logs -f nginx"
echo "  Logs postgres: docker compose logs -f postgres"
echo "  Status       : docker compose ps"
echo "  Redemarrer   : docker compose restart"
echo "  Backup       : bash deploy/scripts/backup.sh"
echo "  Mise a jour  : bash deploy/scripts/deploy.sh"
echo ""
