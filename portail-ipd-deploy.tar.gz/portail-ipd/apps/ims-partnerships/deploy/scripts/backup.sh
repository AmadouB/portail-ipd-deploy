#!/bin/bash
# ══════════════════════════════════════════════════════════════
# IMS Partnerships — Backup PostgreSQL
# Ajouter au cron: 0 2 * * * /opt/ims-partnerships/deploy/scripts/backup.sh
# ══════════════════════════════════════════════════════════════

BACKUP_DIR="/opt/ims-partnerships/backups"
RETENTION_DAYS=30
DATE=$(date +%Y%m%d_%H%M%S)

mkdir -p $BACKUP_DIR

echo "[$(date)] Debut backup IMS Partnerships..."

# Dump PostgreSQL
docker compose -f /opt/ims-partnerships/docker-compose.yml exec -T postgres \
    pg_dump -U ims_user ims_partnerships | gzip > "$BACKUP_DIR/ims_db_$DATE.sql.gz"

# Backup uploads
tar -czf "$BACKUP_DIR/ims_uploads_$DATE.tar.gz" -C /opt/ims-partnerships public/uploads 2>/dev/null || true

# Nettoyage anciens backups
find $BACKUP_DIR -name "*.gz" -mtime +$RETENTION_DAYS -delete

echo "[$(date)] Backup termine: $BACKUP_DIR/ims_db_$DATE.sql.gz"
ls -lh $BACKUP_DIR/*.gz 2>/dev/null | tail -5
