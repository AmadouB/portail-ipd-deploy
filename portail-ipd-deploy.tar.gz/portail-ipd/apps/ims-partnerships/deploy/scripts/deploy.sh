#!/bin/bash
# ══════════════════════════════════════════════════════════════
# IMS Partnerships — Deploiement / Mise a jour via JumpServer
# ══════════════════════════════════════════════════════════════
#
# ── Depuis JumpServer (terminal web sur 10.99.1.10) ──
#   cd /opt/ims-partnerships && bash deploy/scripts/deploy.sh
#
# ── Depuis votre poste local (si tunnel SSH via JumpServer) ──
#   ssh -J jumpserver amadou.bao@10.99.1.10 \
#       "cd /opt/ims-partnerships && bash deploy/scripts/deploy.sh"
#
# ══════════════════════════════════════════════════════════════

set -euo pipefail

APP_DIR="/opt/ims-partnerships"
cd $APP_DIR

echo "══════════════════════════════════════════════════════════"
echo "  IMS Partnerships — Deploiement"
echo "  $(date) | $(whoami)@$(hostname)"
echo "══════════════════════════════════════════════════════════"

# ── 1. Backup avant mise a jour ──
echo ""
echo "[1/5] Backup de securite..."
bash deploy/scripts/backup.sh 2>/dev/null || echo "⚠  Backup ignore (premier deploiement ?)"

# ── 2. Pull code ──
echo ""
echo "[2/5] Pull des dernieres modifications..."
git stash 2>/dev/null || true
git pull origin main
git stash pop 2>/dev/null || true
echo "✓  Code a jour: $(git log --oneline -1)"

# ── 3. Build ──
echo ""
echo "[3/5] Build des containers Docker..."
docker compose build --no-cache app
echo "✓  Build termine"

# ── 4. Redemarrage ──
echo ""
echo "[4/5] Redemarrage des services..."
docker compose down
docker compose up -d
echo "✓  Services demarres"

# ── 5. Migration BDD ──
echo ""
echo "[5/5] Migration base de donnees..."
sleep 5  # Attendre que PostgreSQL soit pret
docker compose exec -T app npx prisma db push --accept-data-loss 2>/dev/null && echo "✓  Schema BDD synchronise" || echo "⚠  Migration ignoree"

# ── Verification ──
echo ""
echo "══════════════════════════════════════════════════════════"
echo "  Verification des services"
echo "══════════════════════════════════════════════════════════"
echo ""
docker compose ps
echo ""

# Health check
sleep 3
HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" http://localhost/login 2>/dev/null || echo "000")
if [ "$HTTP_CODE" = "200" ]; then
    echo "✓  Application accessible (HTTP $HTTP_CODE)"
    echo "   URL: http://10.99.1.10"
else
    echo "⚠  Application non accessible (HTTP $HTTP_CODE)"
    echo "   Verifiez les logs: docker compose logs -f app"
fi

echo ""
echo "══════════════════════════════════════════════════════════"
echo "  Deploiement termine — $(date)"
echo "══════════════════════════════════════════════════════════"
