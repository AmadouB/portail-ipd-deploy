// Prisma client production : PostgreSQL standard (sans adapter SQLite).
// Copie en /app/src/lib/prisma.ts pendant le build Docker.
import { PrismaClient } from "@/generated/prisma/client";

const globalForPrisma = globalThis as unknown as { prisma: PrismaClient };
export const prisma = globalForPrisma.prisma ?? new PrismaClient();
if (process.env.NODE_ENV !== "production") globalForPrisma.prisma = prisma;
