// Prisma client production (Prisma 7).
// L'URL est lue depuis prisma.config.ts au runtime — pas besoin de la passer ici.
// Les routes API utilisent `export const dynamic = 'force-dynamic'` pour eviter
// l'instanciation au build (donc pas de connexion DB requise pour `next build`).
import { PrismaClient } from "@/generated/prisma/client";

const globalForPrisma = globalThis as unknown as { prisma: PrismaClient };

export const prisma = globalForPrisma.prisma ?? new PrismaClient();

if (process.env.NODE_ENV !== "production") globalForPrisma.prisma = prisma;
