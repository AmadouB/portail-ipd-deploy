# Guide de Déploiement — IMS Partnerships via JumpServer

## Informations de connexion

| Paramètre | Valeur |
|---|---|
| **Serveur cible** | `10.99.1.10` |
| **Utilisateur** | `amadou.bao` |
| **Mot de passe** | `Ul16s0%[VY5#lY$}` |
| **OS** | Ubuntu 22.04+ |
| **Accès** | VPN IPD → JumpServer → Serveur |

## Étape 1 : Connexion via JumpServer

1. **Connectez-vous au VPN IPD** (WireGuard/OpenVPN)
2. **Ouvrez JumpServer** dans votre navigateur (URL fournie par la DSI)
3. **Authentifiez-vous** avec votre compte JumpServer
4. Dans la liste des **Assets**, cherchez le serveur `10.99.1.10`
5. Cliquez sur **Connexion** → choisissez **Terminal Web** ou **SSH Client**
6. Vous êtes maintenant connecté au serveur

## Étape 2 : Installation (première fois)

```bash
# Télécharger et exécuter le script d'installation
curl -fsSL https://raw.githubusercontent.com/AmadouB/ims-partnerships/main/deploy/scripts/setup-server.sh | bash
```

Cela installe : Docker, Docker Compose, UFW (firewall), fail2ban, et clone le code.

**⚠ Après l'installation, déconnectez-vous de JumpServer et reconnectez-vous** (pour activer le groupe Docker).

## Étape 3 : Configuration

```bash
cd /opt/ims-partnerships

# Vérifier le fichier .env
nano .env
```

Les secrets sont pré-configurés. Vérifiez que les valeurs sont correctes.

## Étape 4 : Lancement

```bash
cd /opt/ims-partnerships

# Construire et démarrer tous les services
docker compose up -d --build

# Attendre ~30 secondes que tout démarre, puis :
docker compose ps
```

Vous devriez voir 3 services en état "running" :
- `ims-postgres` (base de données)
- `ims-app` (application Next.js)
- `ims-nginx` (reverse proxy)

## Étape 5 : Initialisation de la base de données

```bash
# Créer les tables
docker compose exec app npx prisma db push

# Charger les données de base (utilisateurs, indicateurs)
docker compose exec app bash deploy/scripts/seed-production.sh
```

## Étape 6 : Import des données Excel

```bash
# Copier le fichier Excel dans le container
docker cp "/chemin/vers/partnerships-tracker.xlsx" ims-app:/app/tracker.xlsx

# Lancer l'import (modifier le chemin dans le script si nécessaire)
docker compose exec app npx tsx scripts/import-excel.ts
```

## Étape 7 : Accéder à l'application

Depuis n'importe quel poste connecté au VPN IPD :

```
http://10.99.1.10
```

**Identifiants par défaut :**
- Email : `amadou.bao@ipd.sn`
- Mot de passe : `ims2026`

## Commandes de maintenance via JumpServer

| Action | Commande |
|---|---|
| Voir le statut | `cd /opt/ims-partnerships && docker compose ps` |
| Logs application | `docker compose logs -f app` |
| Logs base de données | `docker compose logs -f postgres` |
| Logs nginx | `docker compose logs -f nginx` |
| Redémarrer tout | `docker compose restart` |
| Arrêter tout | `docker compose down` |
| Mise à jour | `bash deploy/scripts/deploy.sh` |
| Backup manuel | `bash deploy/scripts/backup.sh` |
| Voir les backups | `ls -lh /opt/ims-partnerships/backups/` |
| Shell dans l'app | `docker compose exec app sh` |
| Console PostgreSQL | `docker compose exec postgres psql -U ims_user ims_partnerships` |

## Dépannage

### L'application ne démarre pas
```bash
docker compose logs app | tail -50
```

### La base de données ne répond pas
```bash
docker compose logs postgres | tail -20
docker compose restart postgres
```

### Port 80 déjà utilisé
```bash
sudo lsof -i :80
# Si un autre service occupe le port, arrêtez-le ou changez le port dans docker-compose.yml
```

### Espace disque
```bash
df -h
docker system prune -a  # Nettoyer les images Docker inutilisées
```
