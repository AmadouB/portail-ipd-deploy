import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

const COOKIE_NAME = "ipd-session";

function loginRedirect(req: NextRequest, next?: string): NextResponse {
  // Important : pas de basePath manuel — Next.js l'ajoute automatiquement
  // aux redirects depuis le proxy. Sinon double prefix (ex /cabinet-ipd/cabinet-ipd/login).
  const url = req.nextUrl.clone();
  url.pathname = "/login";
  url.search = "";
  if (next && next !== "/" && next !== "/dashboard") {
    url.searchParams.set("next", next);
  }
  return NextResponse.redirect(url);
}

function dashboardRedirect(req: NextRequest): NextResponse {
  const url = req.nextUrl.clone();
  url.pathname = "/dashboard";
  url.search = "";
  return NextResponse.redirect(url);
}

export function proxy(req: NextRequest) {
  // pathname is already stripped of basePath by Next.js
  const { pathname } = req.nextUrl;
  const session = req.cookies.get(COOKIE_NAME);

  // Si on est déjà sur /login : laisser passer (mais rediriger si déjà connecté)
  if (pathname === "/login") {
    if (session) {
      return dashboardRedirect(req);
    }
    return NextResponse.next();
  }

  // Sinon, exiger une session
  if (!session) {
    return loginRedirect(req, pathname);
  }

  return NextResponse.next();
}

export const config = {
  // Tout sauf : assets statiques, images Next, favicon, logos publics, et l'API auth
  matcher: [
    "/((?!api/auth|_next/static|_next/image|favicon.ico|icon.png|logo-ipd.*\\.png).*)",
  ],
};
