import type { MaturationProject } from "../types";

export const maturationProjects: MaturationProject[] = [
  {
    id: "m-001",
    name: "App mobile carnet de vaccination",
    stage: "ideation",
    sponsor: "Dr. Aminata Diop",
    pole: "MADIBA",
    ideationDate: "2026-03-15",
    description: "Carnet de vaccination numérique pour zones rurales avec mode hors-ligne et NFC.",
    scorecard: { vision: 0.7, technique: 0.4, financier: 0.3, risques: 0.5, equipe: 0.4, me: 0.2 },
  },
  {
    id: "m-002",
    name: "Banque de sérums climatique",
    stage: "ideation",
    sponsor: "Dr. Mamadou Ba",
    pole: "Maturation",
    ideationDate: "2026-02-01",
    description: "Conservation longue durée d'échantillons sériques pour études rétrospectives sur émergences climatiques.",
    scorecard: { vision: 0.85, technique: 0.5, financier: 0.4, risques: 0.6, equipe: 0.3, me: 0.4 },
  },
  {
    id: "m-003",
    name: "IA détection précoce arboviroses",
    stage: "validation",
    sponsor: "Dr. Souleymane Mboup",
    pole: "Cabinet AG",
    ideationDate: "2025-11-10",
    description: "Modèle prédictif d'émergence d'arboviroses basé sur données climatiques et entomologiques.",
    scorecard: { vision: 0.9, technique: 0.7, financier: 0.6, risques: 0.7, equipe: 0.65, me: 0.5 },
  },
  {
    id: "m-004",
    name: "Réseau sentinelle pharmaco-vigilance",
    stage: "validation",
    sponsor: "Dr. Khady Ndiaye",
    pole: "Cabinet AG",
    ideationDate: "2025-09-22",
    description: "Réseau de pharmacies sentinelles pour pharmaco-vigilance temps réel des médicaments anti-paludiques.",
    scorecard: { vision: 0.8, technique: 0.65, financier: 0.7, risques: 0.6, equipe: 0.7, me: 0.6 },
  },
  {
    id: "m-005",
    name: "Plateforme essais cliniques décentralisés",
    stage: "pilote",
    sponsor: "Dr. Fatou Mbaye",
    pole: "Cabinet AG",
    ideationDate: "2025-04-15",
    description: "Plateforme numérique pour essais cliniques décentralisés avec tablettes terrain et e-CRF.",
    scorecard: { vision: 0.85, technique: 0.8, financier: 0.75, risques: 0.7, equipe: 0.8, me: 0.7 },
  },
  {
    id: "m-006",
    name: "Production lipid nanoparticules ARNm",
    stage: "pilote",
    sponsor: "Dr. Souleymane Mboup",
    pole: "MADIBA",
    ideationDate: "2025-01-20",
    description: "Pilote de production de nanoparticules lipidiques pour formulations ARNm — capacité 10 L/lot.",
    scorecard: { vision: 0.95, technique: 0.85, financier: 0.8, risques: 0.75, equipe: 0.85, me: 0.8 },
  },
  {
    id: "m-007",
    name: "Test diagnostic rapide dengue",
    stage: "industrialisation",
    sponsor: "Dr. Mamadou Ba",
    pole: "MADIBA",
    ideationDate: "2024-06-01",
    description: "Test de diagnostic rapide dengue NS1 — passage de la R&D à la production de masse (objectif 500k tests/an).",
    scorecard: { vision: 0.95, technique: 0.95, financier: 0.9, risques: 0.85, equipe: 0.9, me: 0.9 },
  },
];

export const stageLabels: Record<MaturationProject["stage"], string> = {
  ideation: "Idéation",
  validation: "Validation",
  pilote: "Pilote",
  industrialisation: "Industrialisation",
};

export const stageOrder: MaturationProject["stage"][] = ["ideation", "validation", "pilote", "industrialisation"];

export function maturityScore(p: MaturationProject) {
  const s = p.scorecard;
  return (s.vision + s.technique + s.financier + s.risques + s.equipe + s.me) / 6;
}

export function getMaturationProjectById(id: string) {
  return maturationProjects.find(p => p.id === id);
}

import type { MaturationStage } from "../types";
export type { MaturationStage };
