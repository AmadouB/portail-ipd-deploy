import type { KpiCard } from "../types";

export const kpis: KpiCard[] = [
  {
    label: "Santé du portefeuille",
    value: "78 %",
    delta: 4,
    deltaLabel: "vs mois -1",
    trend: [62, 64, 68, 70, 72, 74, 78],
    hint: "Score composite : avancement, conformité, budget.",
    color: "vert",
  },
  {
    label: "Décaissement consolidé",
    value: "67 %",
    delta: -2,
    deltaLabel: "vs cible",
    trend: [55, 58, 60, 62, 65, 67, 67],
    hint: "Décaissement cumulé sur l'enveloppe pluriannuelle.",
    color: "cyan",
  },
  {
    label: "Jalons en retard",
    value: "4",
    delta: 1,
    deltaLabel: "vs semaine -1",
    trend: [2, 2, 3, 3, 4, 4, 4],
    hint: "Jalons critiques avec dérive > 14 jours.",
    color: "orange",
  },
  {
    label: "Projets en pipeline",
    value: "7",
    delta: 2,
    deltaLabel: "ce trimestre",
    trend: [4, 4, 5, 5, 6, 7, 7],
    hint: "Projets actifs en Cellule de Maturation.",
    color: "violet",
  },
];

export const portfolioByPole = [
  { pole: "MADIBA", projets: 4, budget: 21_600_000, statut: "stable" },
  { pole: "Grant Office", projets: 4, budget: 9_600_000, statut: "croissance" },
  { pole: "Maturation", projets: 7, budget: 0, statut: "expansion" },
];

export const monthlyTrend = [
  { mois: "Nov", santé: 62, décaissement: 55, jalons: 12 },
  { mois: "Déc", santé: 64, décaissement: 58, jalons: 14 },
  { mois: "Jan", santé: 68, décaissement: 60, jalons: 13 },
  { mois: "Fév", santé: 70, décaissement: 62, jalons: 11 },
  { mois: "Mar", santé: 72, décaissement: 65, jalons: 9 },
  { mois: "Avr", santé: 78, décaissement: 67, jalons: 8 },
];

export const interdependencies = [
  { source: "MAD-VAC-024", target: "MAD-VAC-031", type: "ressources partagées", strength: 0.7 },
  { source: "MAD-VAC-031", target: "MAD-RD-022", type: "équipe partagée", strength: 0.5 },
  { source: "GO-BMGF-019", target: "GO-WT-031", type: "données partagées", strength: 0.8 },
  { source: "MAD-DIA-007", target: "GO-EU-014", type: "infrastructure", strength: 0.6 },
  { source: "GO-CDC-008", target: "MAD-RD-022", type: "infrastructure BSL3", strength: 0.9 },
  { source: "GO-WT-031", target: "MAD-DIA-007", type: "formations croisées", strength: 0.4 },
];
