import "server-only";
import fs from "node:fs";
import path from "node:path";
import type { VeilleBrief } from "../types";

const DATA_DIR = path.join(process.cwd(), "data", "veille");

export function listBriefDates(): string[] {
  if (!fs.existsSync(DATA_DIR)) return [];
  return fs.readdirSync(DATA_DIR)
    .filter(f => f.endsWith(".json"))
    .map(f => f.replace(/\.json$/, ""))
    .sort()
    .reverse();
}

export function getBrief(date: string): VeilleBrief | null {
  const file = path.join(DATA_DIR, `${date}.json`);
  if (!fs.existsSync(file)) return null;
  try {
    const raw = fs.readFileSync(file, "utf-8");
    return JSON.parse(raw) as VeilleBrief;
  } catch {
    return null;
  }
}

export function getLatestBrief(): VeilleBrief | null {
  const dates = listBriefDates();
  if (dates.length === 0) return null;
  return getBrief(dates[0]);
}
