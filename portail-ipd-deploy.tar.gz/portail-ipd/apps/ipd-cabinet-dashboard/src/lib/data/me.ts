export interface MeIndicator {
  id: string;
  code: string;
  label: string;
  unit: string;
  value: number | string;
  delta?: number;
  target?: number;
  status: "validated" | "pending" | "anomaly" | "stale";
  source: string;
  sourceType: "manual" | "ERP" | "LIMS" | "mobile-form" | "API";
  pole: "MADIBA" | "Grant Office" | "Cabinet AG" | "Maturation";
  projectId?: string;
  updatedAt: string;
  pendingFor?: string;
}

export interface MeAuditEntry {
  id: string;
  indicatorId: string;
  actor: string;
  action: "submitted" | "validated" | "rejected" | "auto-imported" | "anomaly-flagged";
  comment?: string;
  at: string;
}

export const meIndicators: MeIndicator[] = [
  {
    id: "kpi-001",
    code: "MAD-DOSES-Q1",
    label: "Doses produites Q1 2026",
    unit: "k doses",
    value: 1240,
    delta: 8.5,
    target: 1500,
    status: "validated",
    source: "ERP industriel MADIBA",
    sourceType: "ERP",
    pole: "MADIBA",
    projectId: "p-001",
    updatedAt: "2026-04-25T06:30:00Z",
  },
  {
    id: "kpi-002",
    code: "GO-DEC-CUM",
    label: "Décaissement cumulé portefeuille bailleurs",
    unit: "€",
    value: 5_830_000,
    delta: 4.2,
    target: 12_000_000,
    status: "validated",
    source: "Module Grant Office",
    sourceType: "API",
    pole: "Grant Office",
    updatedAt: "2026-04-25T07:00:00Z",
  },
  {
    id: "kpi-003",
    code: "MAD-LOT-VALID",
    label: "Lots validés qualité (cumul 2026)",
    unit: "lots",
    value: 14,
    delta: 16,
    target: 20,
    status: "pending",
    source: "LIMS Vaccinopole",
    sourceType: "LIMS",
    pole: "MADIBA",
    projectId: "p-005",
    updatedAt: "2026-04-25T05:14:00Z",
    pendingFor: "Validation PM Aboubakar Sy",
  },
  {
    id: "kpi-004",
    code: "GO-CONF-BMGF",
    label: "Conformité reporting BMGF Sahel",
    unit: "%",
    value: 96,
    delta: 1,
    target: 100,
    status: "validated",
    source: "Module Grant Office",
    sourceType: "API",
    pole: "Grant Office",
    projectId: "p-002",
    updatedAt: "2026-04-25T07:00:00Z",
  },
  {
    id: "kpi-005",
    code: "GO-RECRUIT-PALU",
    label: "Patients recrutés essai paludisme",
    unit: "patients",
    value: 487,
    delta: 12,
    target: 1200,
    status: "anomaly",
    source: "e-CRF EDCTP",
    sourceType: "API",
    pole: "Grant Office",
    projectId: "p-006",
    updatedAt: "2026-04-25T03:42:00Z",
    pendingFor: "Anomalie : taux de recrutement -22% vs cible mensuelle",
  },
  {
    id: "kpi-006",
    code: "MAD-RD-MILESTONES",
    label: "Jalons R&D ARNm atteints (cumul)",
    unit: "jalons",
    value: 7,
    delta: 0,
    target: 12,
    status: "stale",
    source: "Saisie manuelle équipe R&D",
    sourceType: "manual",
    pole: "MADIBA",
    projectId: "p-007",
    updatedAt: "2026-04-18T14:20:00Z",
    pendingFor: "Données non mises à jour depuis 7 jours",
  },
  {
    id: "kpi-007",
    code: "MAT-PROJECTS-ACTIVE",
    label: "Projets actifs en maturation",
    unit: "projets",
    value: 7,
    delta: 0,
    status: "validated",
    source: "Module Maturation",
    sourceType: "API",
    pole: "Maturation",
    updatedAt: "2026-04-25T07:00:00Z",
  },
  {
    id: "kpi-008",
    code: "FIELD-CONNECT",
    label: "Synchronisations terrain reçues (24 h)",
    unit: "rapports",
    value: 38,
    delta: 5.5,
    status: "validated",
    source: "App mobile terrain",
    sourceType: "mobile-form",
    pole: "Grant Office",
    projectId: "p-002",
    updatedAt: "2026-04-25T07:30:00Z",
  },
  {
    id: "kpi-009",
    code: "MAD-COLD-CHAIN",
    label: "Excursions chaîne du froid (mois)",
    unit: "événements",
    value: 2,
    delta: -50,
    target: 0,
    status: "anomaly",
    source: "Capteurs IoT MADIBA",
    sourceType: "API",
    pole: "MADIBA",
    updatedAt: "2026-04-25T04:55:00Z",
    pendingFor: "À investiguer par responsable qualité",
  },
  {
    id: "kpi-010",
    code: "MAD-DIA-PROD",
    label: "Tests DIATROPIX produits (cumul)",
    unit: "tests",
    value: 280_000,
    delta: 12,
    target: 500_000,
    status: "pending",
    source: "ERP industriel MADIBA",
    sourceType: "ERP",
    pole: "MADIBA",
    projectId: "p-003",
    updatedAt: "2026-04-24T18:10:00Z",
    pendingFor: "Validation production manager",
  },
  {
    id: "kpi-011",
    code: "GO-NGS-RUNS",
    label: "Runs NGS effectués (mois)",
    unit: "runs",
    value: 21,
    delta: 24,
    status: "validated",
    source: "LIMS plateforme génomique",
    sourceType: "LIMS",
    pole: "Grant Office",
    projectId: "p-004",
    updatedAt: "2026-04-25T06:45:00Z",
  },
  {
    id: "kpi-012",
    code: "STRAT-GOV-MEET",
    label: "Réunions COMEX tenues (T1)",
    unit: "réunions",
    value: 12,
    status: "validated",
    source: "Saisie Cabinet AG",
    sourceType: "manual",
    pole: "Cabinet AG",
    updatedAt: "2026-04-22T16:00:00Z",
  },
];

export const meAuditTrail: MeAuditEntry[] = [
  {
    id: "a-001",
    indicatorId: "kpi-002",
    actor: "Système — connecteur Grant Office",
    action: "auto-imported",
    at: "2026-04-25T07:00:00Z",
  },
  {
    id: "a-002",
    indicatorId: "kpi-009",
    actor: "AI Predict",
    action: "anomaly-flagged",
    comment: "Variation hors écart-type historique",
    at: "2026-04-25T04:55:00Z",
  },
  {
    id: "a-003",
    indicatorId: "kpi-001",
    actor: "Dr. Aminata Diop",
    action: "validated",
    comment: "Lot Q1 conforme aux specs OMS PQ",
    at: "2026-04-25T06:30:00Z",
  },
  {
    id: "a-004",
    indicatorId: "kpi-005",
    actor: "AI Predict",
    action: "anomaly-flagged",
    comment: "Recrutement -22 % vs cible mensuelle EDCTP",
    at: "2026-04-25T03:42:00Z",
  },
  {
    id: "a-005",
    indicatorId: "kpi-010",
    actor: "Système — ERP MADIBA",
    action: "submitted",
    at: "2026-04-24T18:10:00Z",
  },
  {
    id: "a-006",
    indicatorId: "kpi-006",
    actor: "AI Predict",
    action: "anomaly-flagged",
    comment: "Aucune mise à jour depuis 7 jours",
    at: "2026-04-25T00:00:00Z",
  },
];

export const statusConfig = {
  validated: { label: "Validé", tone: "vert" as const, count: 0 },
  pending: { label: "À valider", tone: "cyan" as const, count: 0 },
  anomaly: { label: "Anomalie", tone: "rouge" as const, count: 0 },
  stale: { label: "Obsolète", tone: "orange" as const, count: 0 },
};
