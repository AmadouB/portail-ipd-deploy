export type EntityLayer = "intelligence" | "strategic" | "operational" | "units" | "maturity";
export type EntityStatus = "operational" | "transitioning" | "planned";

export interface Responsable {
  name: string;
  title: string;
}

export interface ArchEntity {
  id: string;
  label: string;
  shortLabel: string;
  layer: EntityLayer;
  role: string;
  description: string;
  responsables: Responsable[];
  status: EntityStatus;
  meIndicators?: string[];
  relatedProjects?: string[];
  relatedGrants?: string[];
}

export const entities: ArchEntity[] = [
  {
    id: "e-mel",
    label: "MEL System",
    shortLabel: "MEL",
    layer: "intelligence",
    role: "Couche d'intelligence — Monitoring, Evaluation & Learning",
    description: "Système transversal qui capte, valide et diffuse les indicateurs de performance et d'impact à travers tous les pôles. Définit les KPIs, suit la performance, mesure les résultats, analyse les déviations, capitalise les apprentissages.",
    responsables: [
      { name: "Cellule M&E IPD", title: "Coordination MEL" },
      { name: "Khady Ndiaye", title: "M&E Lead" },
    ],
    status: "transitioning",
    meIndicators: ["kpi-001", "kpi-002", "kpi-007"],
  },
  {
    id: "e-cabinet",
    label: "Cabinet AG — Hub Stratégique",
    shortLabel: "Cabinet AG",
    layer: "strategic",
    role: "PMO Stratégique — gouvernance institutionnelle, arbitrage, priorisation",
    description: "Le PMO Stratégique du Cabinet AG porte la gouvernance institutionnelle du portefeuille IPD. Pilote les projets transversaux (Transformation, Digitalisation), arbitre les priorités inter-pôles et supervise les deux PMO opérationnels.",
    responsables: [
      { name: "Dr. Souleymane Mboup", title: "Directeur Général (CEO)" },
      { name: "Executive Officer Sr.", title: "EO Senior Cabinet AG" },
      { name: "Executive Officer", title: "EO Cabinet AG" },
    ],
    status: "transitioning",
    meIndicators: ["kpi-012"],
  },
  {
    id: "e-governance",
    label: "Governance System",
    shortLabel: "Gouvernance",
    layer: "strategic",
    role: "Instances de gouvernance et comités de pilotage",
    description: "Cadre formel des comités stratégiques (COMEX, Conseil scientifique, Comité d'arbitrage) et des règles institutionnelles de validation des projets et des décaissements.",
    responsables: [
      { name: "Conseil d'administration IPD", title: "Tutelle" },
      { name: "COMEX", title: "Comité exécutif hebdo" },
    ],
    status: "operational",
  },
  {
    id: "e-cvo-cso",
    label: "CVO / CSO",
    shortLabel: "CVO / CSO",
    layer: "strategic",
    role: "Chief Vaccine Officer · Chief Scientific Officer",
    description: "Direction médicale et scientifique de l'IPD. Coordination des Flagship Initiatives Owners et des unités de recherche.",
    responsables: [
      { name: "CVO", title: "Chief Vaccine Officer" },
      { name: "CSO", title: "Chief Scientific Officer" },
    ],
    status: "operational",
  },
  {
    id: "e-madiba",
    label: "MADIBA — PMO Industriel",
    shortLabel: "MADIBA",
    layer: "operational",
    role: "PMO Opérationnel — production industrielle & R&D",
    description: "Pôle industriel et R&D de l'IPD : production de vaccins, plateforme ARNm, vaccinopole, diagnostic rapide DIATROPIX. Pilote le portefeuille des programmes industriels.",
    responsables: [
      { name: "Dr. Aminata Diop", title: "PM Vaccinopole" },
      { name: "Dr. Aboubakar Sy", title: "PM Production fièvre jaune" },
      { name: "Dr. Mamadou Ba", title: "PM DIATROPIX" },
      { name: "Dr. Souleymane Mboup", title: "PM Plateforme ARNm" },
    ],
    status: "operational",
    meIndicators: ["kpi-001", "kpi-003", "kpi-009", "kpi-010"],
    relatedProjects: ["p-001", "p-003", "p-005", "p-007"],
  },
  {
    id: "e-grant-office",
    label: "Grant Office — PMO Scientifique",
    shortLabel: "Grant Office",
    layer: "operational",
    role: "PMO Opérationnel — financements externes & projets bailleurs",
    description: "Gère le cycle de vie complet des subventions externes : veille, soumission, négociation, exécution, conformité bailleurs, reporting financier. Pilote les projets donor-funded.",
    responsables: [
      { name: "Cheikh Tidiane Sall", title: "Grant Manager BMGF" },
      { name: "Khady Ndiaye", title: "Grant Manager Wellcome" },
      { name: "Fatou Mbaye", title: "Grant Manager EDCTP" },
      { name: "Aïssatou Ndiaye", title: "Grant Manager CDC" },
    ],
    status: "operational",
    meIndicators: ["kpi-002", "kpi-004", "kpi-005", "kpi-008", "kpi-011"],
    relatedProjects: ["p-002", "p-004", "p-006", "p-008"],
    relatedGrants: ["g-001", "g-002", "g-003", "g-004"],
  },
  {
    id: "e-cellule-pmo",
    label: "Cellule PMO — Maturation",
    shortLabel: "Cellule PMO",
    layer: "maturity",
    role: "Maturité du système & incubation des projets",
    description: "Sas d'entrée institutionnel pour les nouveaux projets. Évalue la maturité (scorecard), prépare le passage au stade opérationnel. Renforce continuellement les pratiques PMO du système (formation, méthodologies, outils).",
    responsables: [
      { name: "EOs", title: "Executive Officers" },
      { name: "PMO Leads", title: "Coordination Cellule" },
      { name: "Senior PMs / GMs", title: "Mentors PMO" },
      { name: "PMI Senegal", title: "Partenaire clé" },
    ],
    status: "transitioning",
    meIndicators: ["kpi-007"],
  },
  {
    id: "e-vrc",
    label: "VRC",
    shortLabel: "VRC",
    // unit boxes are 2.2 wide — keep labels < 8 chars
    layer: "units",
    role: "Vaccine Research Center",
    description: "Centre de recherche vaccinale. Unit de R&D historique de l'IPD.",
    responsables: [{ name: "Head of VRC", title: "Direction d'unité" }],
    status: "operational",
  },
  {
    id: "e-public-health",
    label: "Public Health",
    shortLabel: "Public",
    layer: "units",
    role: "Santé publique",
    description: "Unité de santé publique. Surveillance épidémiologique, programmes communautaires.",
    responsables: [{ name: "Head of Public Health", title: "Direction d'unité" }],
    status: "operational",
  },
  {
    id: "e-clinical-trials",
    label: "Clinical Trials",
    shortLabel: "Clinical",
    layer: "units",
    role: "Essais cliniques",
    description: "Unité de gestion des essais cliniques. Coordonne les sites investigateurs et la conformité GCP.",
    responsables: [{ name: "Head of Clinical Trials", title: "Direction d'unité" }],
    status: "operational",
  },
  {
    id: "e-diatropix",
    label: "DIATROPIX",
    shortLabel: "DIATROPIX",
    layer: "units",
    role: "Tests de diagnostic rapide",
    description: "Plateforme de tests de diagnostic rapide pour pathogènes émergents.",
    responsables: [{ name: "Head of DIATROPIX", title: "Direction d'unité" }],
    status: "operational",
  },
  {
    id: "e-care",
    label: "CARE & autres",
    shortLabel: "CARE",
    layer: "units",
    role: "Programmes spéciaux",
    description: "Programmes spéciaux et initiatives transverses de l'IPD (CARE, etc.).",
    responsables: [{ name: "Heads of Units", title: "Direction" }],
    status: "operational",
  },
];

export type ActivityType = "presentation" | "priorisation" | "decision" | "jalon" | "formation";

export interface ArchActivity {
  id: string;
  date: string;
  type: ActivityType;
  title: string;
  description: string;
  presenter: string;
  audience: string;
  outcome?: string;
  entityIds: string[];
  status: "planned" | "completed" | "in-progress";
}

export const activities: ArchActivity[] = [
  {
    id: "act-001",
    date: "2026-04-22",
    type: "decision",
    title: "Validation officielle de la nouvelle architecture PMO",
    description: "Le COMEX valide le passage à l'architecture cible : 1 PMO Stratégique (Cabinet AG), 2 PMO Opérationnels (MADIBA, Grant Office), 1 Cellule de Maturation.",
    presenter: "Dr. Souleymane Mboup",
    audience: "COMEX IPD",
    outcome: "Décision actée. Lancement officiel de la phase de transition.",
    entityIds: ["e-cabinet", "e-madiba", "e-grant-office", "e-cellule-pmo"],
    status: "completed",
  },
  {
    id: "act-002",
    date: "2026-04-15",
    type: "presentation",
    title: "Présentation de l'architecture cible au Conseil d'administration",
    description: "Présentation détaillée de la transformation organisationnelle, du calendrier en 3 phases, et des bénéfices attendus pour la gouvernance institutionnelle.",
    presenter: "Cabinet AG",
    audience: "Conseil d'administration IPD",
    outcome: "Cadrage budgétaire approuvé sur 18 mois.",
    entityIds: ["e-cabinet", "e-governance"],
    status: "completed",
  },
  {
    id: "act-003",
    date: "2026-04-10",
    type: "priorisation",
    title: "Atelier de priorisation des chantiers de transformation",
    description: "Atelier de 2 jours avec EOs, PMO Leads et PMI Senegal pour prioriser les chantiers (formation, outils, méthodologies, gouvernance des données).",
    presenter: "Cellule PMO + PMI Senegal",
    audience: "Cabinet AG, EOs, PMO Leads",
    outcome: "5 chantiers prioritaires identifiés. Roadmap 18 mois validée.",
    entityIds: ["e-cellule-pmo", "e-cabinet"],
    status: "completed",
  },
  {
    id: "act-004",
    date: "2026-04-05",
    type: "formation",
    title: "Formation Project Management Institute (PMI Senegal)",
    description: "Session de formation aux standards PMI pour les Senior PMs / GMs des deux PMO opérationnels. Module sur la gouvernance institutionnelle de portefeuille.",
    presenter: "PMI Senegal",
    audience: "Senior PMs, Grant Managers",
    outcome: "12 PM formés. Certification PMI niveau 1 en cours.",
    entityIds: ["e-cellule-pmo", "e-madiba", "e-grant-office"],
    status: "completed",
  },
  {
    id: "act-005",
    date: "2026-05-08",
    type: "presentation",
    title: "Roadshow auprès des Heads of Units",
    description: "Tournée de présentation auprès des chefs d'unité (VRC, Public Health, Clinical Trials, DIATROPIX, CARE) pour expliquer le nouveau circuit de remontée projets et de validation M&E.",
    presenter: "Cabinet AG + PMO Leads",
    audience: "Heads of Units",
    entityIds: ["e-cabinet", "e-vrc", "e-public-health", "e-clinical-trials", "e-diatropix", "e-care"],
    status: "planned",
  },
  {
    id: "act-006",
    date: "2026-05-15",
    type: "jalon",
    title: "Mise en service du module M&E intégré",
    description: "Bascule effective de tous les indicateurs sur le MEL System. Fin de la double saisie historique entre M&E et reporting projet.",
    presenter: "Khady Ndiaye",
    audience: "Tous les pôles",
    entityIds: ["e-mel", "e-madiba", "e-grant-office"],
    status: "in-progress",
  },
  {
    id: "act-007",
    date: "2026-06-01",
    type: "priorisation",
    title: "Première session d'arbitrage stratégique trimestriel",
    description: "Première session formelle d'arbitrage du portefeuille avec l'outil de simulation what-if intégré au Hub Stratégique. Focus sur les arbitrages MADIBA / Grant Office.",
    presenter: "Cabinet AG",
    audience: "COMEX, EOs, PMO Leads, CVO/CSO",
    entityIds: ["e-cabinet", "e-madiba", "e-grant-office", "e-cvo-cso"],
    status: "planned",
  },
  {
    id: "act-008",
    date: "2026-04-28",
    type: "decision",
    title: "Désignation des EOs senior et junior du Cabinet AG",
    description: "Nominations officielles des Executive Officers Senior et Junior responsables de la coordination des deux PMO opérationnels.",
    presenter: "Cabinet AG",
    audience: "Direction IPD",
    entityIds: ["e-cabinet"],
    status: "in-progress",
  },
  {
    id: "act-009",
    date: "2026-04-18",
    type: "formation",
    title: "Onboarding des nouveaux Grant Managers",
    description: "Formation des 4 Grant Managers sur les standards de conformité bailleurs (BMGF, Wellcome, EDCTP, CDC).",
    presenter: "Grant Office Lead",
    audience: "Grant Managers",
    outcome: "4 GMs onboardés et opérationnels.",
    entityIds: ["e-grant-office"],
    status: "completed",
  },
  {
    id: "act-010",
    date: "2026-07-01",
    type: "jalon",
    title: "Audit externe de maturité PMO (PMI Senegal)",
    description: "Audit externe réalisé par PMI Senegal pour mesurer la maturité du système PMO institutionnel et certifier les progrès accomplis.",
    presenter: "PMI Senegal",
    audience: "Cabinet AG, COMEX",
    entityIds: ["e-cellule-pmo", "e-cabinet", "e-madiba", "e-grant-office"],
    status: "planned",
  },
];

export const layerLabels: Record<EntityLayer, string> = {
  intelligence: "Intelligence transversale",
  strategic: "Hub Stratégique",
  operational: "Pôles Opérationnels",
  units: "Unités opérationnelles",
  maturity: "Maturité du système",
};

export function getEntityById(id: string) {
  return entities.find(e => e.id === id);
}
