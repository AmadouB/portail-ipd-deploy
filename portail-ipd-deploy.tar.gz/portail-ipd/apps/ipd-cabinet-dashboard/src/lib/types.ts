export type Pole = "MADIBA" | "Grant Office" | "Maturation" | "Cabinet AG";

export type ProjectStatus = "on-track" | "at-risk" | "delayed" | "completed";

export type MaturationStage = "ideation" | "validation" | "pilote" | "industrialisation";

export interface Project {
  id: string;
  code: string;
  name: string;
  pole: Pole;
  status: ProjectStatus;
  budget: number;
  spent: number;
  currency: "EUR" | "USD" | "XOF";
  startDate: string;
  endDate: string;
  pm: string;
  bailleur?: string;
  description: string;
  progress: number;
  jalons: Jalon[];
  tags: string[];
}

export interface Jalon {
  id: string;
  label: string;
  date: string;
  status: "done" | "in-progress" | "upcoming" | "delayed";
}

export interface Grant {
  id: string;
  code: string;
  title: string;
  bailleur: string;
  bailleurType: "Fondation" | "Public" | "Multilatéral" | "Bilatéral";
  status: "pipeline" | "soumis" | "négociation" | "actif" | "clôturé";
  amount: number;
  currency: "EUR" | "USD";
  decaisse: number;
  startDate: string;
  endDate: string;
  manager: string;
  pole: "MADIBA" | "Maturation" | "Cabinet AG";
  conformity: number;
  reportingFreq: "trimestrielle" | "semestrielle" | "annuelle";
  description: string;
}

export interface MaturationProject {
  id: string;
  name: string;
  stage: MaturationStage;
  sponsor: string;
  pole: Pole;
  ideationDate: string;
  description: string;
  scorecard: {
    vision: number;
    technique: number;
    financier: number;
    risques: number;
    equipe: number;
    me: number;
  };
}

export interface Alert {
  id: string;
  type: "predictive" | "anomaly" | "info" | "success";
  severity: "high" | "medium" | "low";
  title: string;
  description: string;
  source: string;
  detectedAt: string;
  projectId?: string;
}

export interface KpiCard {
  label: string;
  value: string;
  delta: number;
  deltaLabel: string;
  trend: number[];
  hint: string;
  color: "cyan" | "vert" | "orange" | "violet" | "rouge";
}

export interface Persona {
  id: string;
  name: string;
  role: string;
  pole: Pole;
}

export type VeilleSource =
  | "OMS"
  | "Pasteur Network"
  | "BMGF"
  | "Wellcome"
  | "EDCTP"
  | "GAVI"
  | "AFD"
  | "Africa CDC"
  | "Lancet";

export type VeilleCategory =
  | "épidémie"
  | "vaccin"
  | "bailleur"
  | "réglementation"
  | "recherche"
  | "signal-faible";

export type IpdRelevance = "high" | "medium" | "low";

export interface VeilleItem {
  id: string;
  title: string;
  source: VeilleSource;
  sourceUrl: string;
  category: VeilleCategory;
  summary: string;
  ipdRelevance: IpdRelevance;
  tags: string[];
  linkedProjectId?: string;
  linkedGrantId?: string;
}

export interface VeilleBrief {
  date: string;
  generatedAt: string;
  summary: string;
  items: VeilleItem[];
}
