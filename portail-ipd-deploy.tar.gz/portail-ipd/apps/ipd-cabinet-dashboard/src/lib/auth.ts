import "server-only";
import { cookies } from "next/headers";
import crypto from "node:crypto";

export interface AuthUser {
  email: string;
  name: string;
  role: string;
  initials: string;
}

export const users: AuthUser[] = [
  {
    email: "Fatoumata.NIANG@pasteur.sn",
    name: "Fatoumata Niang",
    role: "Cabinet AG",
    initials: "FN",
  },
  {
    email: "IbrahimaSoce.FALL@pasteur.sn",
    name: "Ibrahima Soce Fall",
    role: "Cabinet AG",
    initials: "IS",
  },
  {
    email: "Ramatoulaye.Camara@pasteur.sn",
    name: "Ramatoulaye Camara",
    role: "Cabinet AG",
    initials: "RC",
  },
];

export const DEFAULT_PASSWORD = "IPD2026!";

const SECRET = process.env.AUTH_SECRET || "ipd-pmo-platform-demo-secret-2026-change-me";
const COOKIE_NAME = "ipd-session";
const MAX_AGE_SEC = 60 * 60 * 24 * 7; // 7 jours

function sign(value: string): string {
  return crypto.createHmac("sha256", SECRET).update(value).digest("hex").slice(0, 32);
}

function verify(value: string, sig: string): boolean {
  const expected = sign(value);
  if (expected.length !== sig.length) return false;
  return crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(sig));
}

export async function setSession(email: string): Promise<void> {
  const sig = sign(email);
  const value = `${email}|${sig}`;
  const c = await cookies();
  c.set(COOKIE_NAME, value, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: MAX_AGE_SEC,
  });
}

export async function clearSession(): Promise<void> {
  const c = await cookies();
  c.delete(COOKIE_NAME);
}

export async function getCurrentUser(): Promise<AuthUser | null> {
  const c = await cookies();
  const cookie = c.get(COOKIE_NAME);
  if (!cookie) return null;
  const [email, sig] = cookie.value.split("|");
  if (!email || !sig) return null;
  if (!verify(email, sig)) return null;
  return users.find(u => u.email.toLowerCase() === email.toLowerCase()) ?? null;
}

export function validateCredentials(email: string, password: string): AuthUser | null {
  const trimmed = email.trim().toLowerCase();
  const user = users.find(u => u.email.toLowerCase() === trimmed);
  if (!user) return null;
  if (password !== DEFAULT_PASSWORD) return null;
  return user;
}
