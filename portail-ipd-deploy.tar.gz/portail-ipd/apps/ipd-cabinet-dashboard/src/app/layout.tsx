import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { AppShell } from "@/components/nav/app-shell";
import { getCurrentUser } from "@/lib/auth";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "IPD — Plateforme PMO",
  description: "Plateforme de coordination et suivi stratégique de l'Institut Pasteur de Dakar",
  applicationName: "IPD PMO",
  authors: [{ name: "Institut Pasteur de Dakar — Cabinet AG" }],
  keywords: ["IPD", "Institut Pasteur de Dakar", "PMO", "Cabinet AG", "MADIBA", "Grant Office"],
};

export default async function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const user = await getCurrentUser();
  return (
    <html
      lang="fr"
      className={`${geistSans.variable} ${geistMono.variable} h-full antialiased`}
    >
      <body className="min-h-full">
        <AppShell user={user}>{children}</AppShell>
      </body>
    </html>
  );
}
