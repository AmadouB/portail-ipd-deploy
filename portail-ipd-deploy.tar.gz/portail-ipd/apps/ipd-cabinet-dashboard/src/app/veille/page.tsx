import { Suspense } from "react";
import { notFound } from "next/navigation";
import { PageHeader } from "@/components/nav/page-header";
import { GlassPanel } from "@/components/ui/glass-panel";
import { BriefTimeline } from "@/components/veille/brief-timeline";
import { BriefContent } from "@/components/veille/brief-content";
import { listBriefDates, getBrief } from "@/lib/data/veille";
import { Sparkles } from "lucide-react";

export const dynamic = "force-dynamic";

export default async function VeillePage({
  searchParams,
}: {
  searchParams: Promise<{ date?: string }>;
}) {
  const params = await searchParams;
  const dates = listBriefDates();

  if (dates.length === 0) {
    return (
      <div className="space-y-6">
        <PageHeader
          title="Veille IPD"
          subtitle="Brief automatisé chaque matin à 08:00 UTC sur les actualités santé pertinentes pour l'IPD."
          badge="Auto · 08:00 UTC"
        />
        <GlassPanel variant="strong" className="p-12 text-center">
          <Sparkles className="w-12 h-12 text-cyan/60 mx-auto mb-4" />
          <h2 className="text-xl font-semibold mb-2">Aucun brief disponible</h2>
          <p className="text-text-secondary max-w-md mx-auto">
            La routine quotidienne n&apos;a pas encore produit son premier brief. Le prochain brief sera généré demain à 08:00 UTC.
          </p>
        </GlassPanel>
      </div>
    );
  }

  const selected = params.date && dates.includes(params.date) ? params.date : dates[0];
  const brief = getBrief(selected);
  if (!brief) notFound();

  const itemCounts = Object.fromEntries(
    dates.map(d => [d, getBrief(d)?.items.length ?? 0])
  );

  const dateLabel = new Date(brief.date).toLocaleDateString("fr-FR", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  });

  return (
    <div className="space-y-6">
      <PageHeader
        title="Veille IPD"
        subtitle={`Brief du ${dateLabel} — ${brief.items.length} actualités santé sélectionnées pour leur pertinence avec les portefeuilles IPD.`}
        badge="Auto · 08:00 UTC"
      />

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <div className="lg:col-span-3">
          <Suspense fallback={null}>
            <BriefTimeline dates={dates} selected={selected} itemCounts={itemCounts} />
          </Suspense>
        </div>
        <div className="lg:col-span-9">
          <BriefContent brief={brief} />
        </div>
      </div>
    </div>
  );
}
