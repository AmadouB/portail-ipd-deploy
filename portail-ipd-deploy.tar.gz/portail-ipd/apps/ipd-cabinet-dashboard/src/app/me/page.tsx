import Link from "next/link";
import { PageHeader } from "@/components/nav/page-header";
import { GlassPanel } from "@/components/ui/glass-panel";
import { Badge } from "@/components/ui/badge";
import { meIndicators, meAuditTrail, statusConfig } from "@/lib/data/me";
import { Activity, CheckCircle2, AlertTriangle, Clock, Database, Smartphone, Server, Hand, Brain, Bot, FileCheck } from "lucide-react";
import { formatNumber, cn } from "@/lib/utils";

const sourceIcons = {
  ERP: Server,
  LIMS: Database,
  API: Bot,
  manual: Hand,
  "mobile-form": Smartphone,
} as const;

const statusIcons = {
  validated: CheckCircle2,
  pending: Clock,
  anomaly: AlertTriangle,
  stale: Activity,
} as const;

const actionLabels = {
  submitted: "a soumis",
  validated: "a validé",
  rejected: "a rejeté",
  "auto-imported": "a importé",
  "anomaly-flagged": "a signalé une anomalie sur",
} as const;

const actionTones = {
  submitted: "cyan",
  validated: "vert",
  rejected: "rouge",
  "auto-imported": "cyan",
  "anomaly-flagged": "orange",
} as const;

function timeAgo(iso: string) {
  const diff = Date.now() - new Date(iso).getTime();
  const min = Math.round(diff / 60000);
  if (min < 1) return "à l'instant";
  if (min < 60) return `il y a ${min} min`;
  const h = Math.round(min / 60);
  if (h < 24) return `il y a ${h} h`;
  const d = Math.round(h / 24);
  return `il y a ${d} j`;
}

export default function MePage() {
  const counts = {
    validated: meIndicators.filter(i => i.status === "validated").length,
    pending: meIndicators.filter(i => i.status === "pending").length,
    anomaly: meIndicators.filter(i => i.status === "anomaly").length,
    stale: meIndicators.filter(i => i.status === "stale").length,
  };
  const total = meIndicators.length;
  const validatedRate = Math.round((counts.validated / total) * 100);

  return (
    <div className="space-y-6">
      <PageHeader
        title="M&E temps réel"
        subtitle="Suivi-évaluation centralisé : indicateurs, validation, anomalies. Une saisie unique alimente tous les dashboards."
        badge="Live · M&E Engine"
      />

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <GlassPanel className="p-4">
          <p className="text-[10px] uppercase tracking-widest text-text-muted">Indicateurs suivis</p>
          <p className="text-3xl font-bold text-cyan mt-1">{total}</p>
          <p className="text-xs text-text-secondary mt-1">tous pôles confondus</p>
        </GlassPanel>
        <GlassPanel className="p-4">
          <p className="text-[10px] uppercase tracking-widest text-text-muted">Taux de validation</p>
          <p className="text-3xl font-bold text-vert mt-1">{validatedRate} %</p>
          <p className="text-xs text-text-secondary mt-1">{counts.validated} validés / {total}</p>
        </GlassPanel>
        <GlassPanel className="p-4">
          <p className="text-[10px] uppercase tracking-widest text-text-muted">À valider</p>
          <p className="text-3xl font-bold text-cyan mt-1">{counts.pending}</p>
          <p className="text-xs text-text-secondary mt-1">en file d&apos;attente</p>
        </GlassPanel>
        <GlassPanel className="p-4">
          <p className="text-[10px] uppercase tracking-widest text-text-muted">Anomalies / obsolètes</p>
          <p className="text-3xl font-bold text-orange mt-1">{counts.anomaly + counts.stale}</p>
          <p className="text-xs text-text-secondary mt-1">à investiguer</p>
        </GlassPanel>
      </div>

      {/* Status legend */}
      <div className="flex items-center gap-3 flex-wrap">
        {(Object.keys(statusConfig) as Array<keyof typeof statusConfig>).map(key => {
          const cfg = statusConfig[key];
          const Icon = statusIcons[key];
          return (
            <div key={key} className="flex items-center gap-2 px-3 py-1.5 rounded-xl glass border border-white/10 text-xs">
              <Icon className={cn("w-3.5 h-3.5",
                key === "validated" ? "text-vert" :
                key === "pending" ? "text-cyan" :
                key === "anomaly" ? "text-rouge" : "text-orange",
              )} />
              <span className="font-medium text-text-secondary">{cfg.label}</span>
              <span className="text-text-muted">·</span>
              <span className="font-bold text-text-primary">{counts[key]}</span>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Indicators list */}
        <GlassPanel variant="strong" className="p-5 lg:col-span-2">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-lg font-semibold flex items-center gap-2">
                <Activity className="w-5 h-5 text-cyan" />
                Indicateurs en cours
              </h2>
              <p className="text-xs text-text-muted mt-0.5">Une vue unifiée — sources hétérogènes, validation centralisée</p>
            </div>
          </div>

          <div className="space-y-2 max-h-[640px] overflow-y-auto pr-2 -mr-2">
            {meIndicators.map(ind => {
              const StatusIcon = statusIcons[ind.status];
              const SourceIcon = sourceIcons[ind.sourceType];
              const valueDisplay = typeof ind.value === "number" ? formatNumber(ind.value) : ind.value;
              const progressPct = ind.target ? Math.min(100, ((typeof ind.value === "number" ? ind.value : 0) / ind.target) * 100) : null;

              return (
                <div
                  key={ind.id}
                  className={cn(
                    "rounded-xl border p-3 transition hover:bg-glass-hover",
                    ind.status === "anomaly" ? "border-rouge/30 bg-rouge/5" :
                    ind.status === "stale"   ? "border-orange/30 bg-orange/5" :
                    ind.status === "pending" ? "border-cyan/25 bg-cyan/5" :
                    "border-white/5 bg-white/3",
                  )}
                >
                  <div className="flex items-start gap-3">
                    <div className={cn("mt-0.5 p-1.5 rounded-lg shrink-0",
                      ind.status === "validated" ? "bg-vert/15 text-vert" :
                      ind.status === "pending" ? "bg-cyan/15 text-cyan" :
                      ind.status === "anomaly" ? "bg-rouge/15 text-rouge" :
                      "bg-orange/15 text-orange",
                    )}>
                      <StatusIcon className="w-4 h-4" />
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0 flex-1">
                          <p className="text-sm font-semibold text-text-primary leading-tight">{ind.label}</p>
                          <p className="text-[11px] text-text-muted font-mono mt-0.5">{ind.code}</p>
                        </div>
                        <Badge tone={statusConfig[ind.status].tone}>{statusConfig[ind.status].label}</Badge>
                      </div>

                      <div className="flex items-baseline gap-2 mt-2">
                        <span className="text-2xl font-bold text-text-primary tabular-nums">{valueDisplay}</span>
                        <span className="text-xs text-text-muted">{ind.unit}</span>
                        {ind.delta !== undefined && ind.delta !== 0 && (
                          <span className={cn("text-xs font-medium ml-auto",
                            ind.delta > 0 ? "text-vert" : "text-rouge",
                          )}>
                            {ind.delta > 0 ? "+" : ""}{ind.delta}%
                          </span>
                        )}
                      </div>

                      {progressPct !== null && (
                        <div className="mt-2 flex items-center gap-2">
                          <div className="flex-1 h-1 rounded-full bg-white/5 overflow-hidden">
                            <div
                              className={cn("h-full rounded-full bg-gradient-to-r",
                                progressPct >= 80 ? "from-vert to-cyan" :
                                progressPct >= 50 ? "from-cyan to-bleu-clair" :
                                "from-orange to-cyan",
                              )}
                              style={{ width: `${progressPct}%` }}
                            />
                          </div>
                          <span className="text-[10px] text-text-muted tabular-nums">{progressPct.toFixed(0)}% / cible</span>
                        </div>
                      )}

                      <div className="mt-2.5 flex items-center justify-between gap-2 flex-wrap text-[11px]">
                        <div className="flex items-center gap-1.5 text-text-muted">
                          <SourceIcon className="w-3 h-3" />
                          <span>{ind.source}</span>
                          <span>·</span>
                          <Badge tone="neutre">{ind.pole}</Badge>
                        </div>
                        <span className="text-text-muted">{timeAgo(ind.updatedAt)}</span>
                      </div>

                      {ind.pendingFor && (
                        <p className="mt-2 text-[11px] text-text-secondary italic border-l-2 border-white/10 pl-2">
                          {ind.pendingFor}
                        </p>
                      )}

                      {ind.projectId && (
                        <Link
                          href={`/projects/${ind.projectId}`}
                          className="mt-2 inline-block text-[11px] text-bleu-clair hover:underline"
                        >
                          → Voir le projet rattaché
                        </Link>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </GlassPanel>

        {/* Audit trail */}
        <GlassPanel variant="strong" className="p-5">
          <div className="mb-4">
            <h2 className="text-lg font-semibold flex items-center gap-2">
              <FileCheck className="w-5 h-5 text-cyan" />
              Journal d&apos;activité M&amp;E
            </h2>
            <p className="text-xs text-text-muted mt-0.5">Trace inaltérable de toutes les modifications</p>
          </div>

          <div className="space-y-3 max-h-[640px] overflow-y-auto pr-2 -mr-2">
            {meAuditTrail.map(entry => {
              const indicator = meIndicators.find(i => i.id === entry.indicatorId);
              return (
                <div key={entry.id} className="border-l-2 border-white/10 pl-3 py-1">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1">
                      <p className="text-xs">
                        <span className={cn("font-semibold",
                          entry.actor.startsWith("AI") ? "text-cyan" :
                          entry.actor.startsWith("Système") ? "text-bleu-clair" : "text-text-primary",
                        )}>
                          {entry.actor.startsWith("AI") && <Brain className="w-3 h-3 inline-block mr-1" />}
                          {entry.actor}
                        </span>{" "}
                        <Badge tone={actionTones[entry.action]} className="mx-0.5">
                          {actionLabels[entry.action]}
                        </Badge>{" "}
                        <span className="text-text-secondary">{indicator?.label ?? entry.indicatorId}</span>
                      </p>
                      {entry.comment && (
                        <p className="text-[11px] text-text-muted mt-1 italic">« {entry.comment} »</p>
                      )}
                    </div>
                  </div>
                  <p className="text-[10px] text-text-muted mt-1">{timeAgo(entry.at)}</p>
                </div>
              );
            })}
          </div>

          <div className="mt-4 pt-3 border-t border-white/5 text-[11px] text-text-muted leading-relaxed">
            Toutes les actions sur les indicateurs M&amp;E sont enregistrées de façon inaltérable.
            Conformité ISO 27001, BMGF, EDCTP.
          </div>
        </GlassPanel>
      </div>
    </div>
  );
}
