import Link from "next/link";
import { PageHeader } from "@/components/nav/page-header";
import { GlassPanel } from "@/components/ui/glass-panel";
import { Badge } from "@/components/ui/badge";
import { projectsByPole } from "@/lib/data/projects";
import { Factory, FlaskRound, Truck, Snowflake, ChevronRight, Calendar, AlertTriangle, CheckCircle2, Clock } from "lucide-react";
import { formatCurrency, cn } from "@/lib/utils";

const statusConfig = {
  done: { icon: CheckCircle2, color: "text-vert", label: "Atteint" },
  "in-progress": { icon: Clock, color: "text-cyan", label: "En cours" },
  upcoming: { icon: Calendar, color: "text-text-muted", label: "À venir" },
  delayed: { icon: AlertTriangle, color: "text-rouge", label: "Retard" },
};

const projectStatusTone = {
  "on-track": "vert",
  "at-risk": "orange",
  delayed: "rouge",
  completed: "cyan",
} as const;

export default function MadibaPage() {
  const items = projectsByPole("MADIBA");
  const totalBudget = items.reduce((s, p) => s + p.budget, 0);
  const totalSpent = items.reduce((s, p) => s + p.spent, 0);

  return (
    <div className="space-y-6">
      <PageHeader
        title="MADIBA — Production & R&D"
        subtitle="Pôle industriel et R&D de l'IPD : production de vaccins, plateformes ARNm, vaccinopole, diagnostic rapide DIATROPIX."
        badge={`${items.length} projets industriels`}
      />

      {/* Capacités */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {[
          { icon: FlaskRound, label: "Lignes de production", value: "8", sub: "actives" },
          { icon: Snowflake, label: "Capacité chaîne du froid", value: "12 M doses", sub: "stockage simultané" },
          { icon: Truck, label: "Couverture logistique", value: "11 pays", sub: "Afrique de l'Ouest" },
          { icon: Factory, label: "Effectifs MADIBA", value: "247", sub: "équipes opérationnelles" },
        ].map((c, i) => {
          const Icon = c.icon;
          return (
            <GlassPanel key={i} className="p-4">
              <div className="flex items-start gap-3">
                <div className="p-2 rounded-xl bg-cyan/10 text-cyan">
                  <Icon className="w-5 h-5" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-[10px] uppercase tracking-widest text-text-muted">{c.label}</p>
                  <p className="text-xl font-bold mt-0.5">{c.value}</p>
                  <p className="text-xs text-text-secondary">{c.sub}</p>
                </div>
              </div>
            </GlassPanel>
          );
        })}
      </div>

      {/* Budget summary */}
      <GlassPanel variant="strong" className="p-5">
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div>
            <h2 className="text-lg font-semibold">Vue d&apos;ensemble industrielle</h2>
            <p className="text-xs text-text-muted">Budget consolidé MADIBA · {items.length} projets actifs</p>
          </div>
          <div className="flex items-center gap-6">
            <div className="text-right">
              <p className="text-xs text-text-muted">Budget total</p>
              <p className="text-2xl font-bold text-cyan">{formatCurrency(totalBudget)}</p>
            </div>
            <div className="text-right">
              <p className="text-xs text-text-muted">Consommé</p>
              <p className="text-2xl font-bold text-text-primary">{formatCurrency(totalSpent)}</p>
              <p className="text-xs text-vert">{((totalSpent / totalBudget) * 100).toFixed(1)} %</p>
            </div>
          </div>
        </div>
      </GlassPanel>

      {/* Projects with milestones */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
        {items.map(p => (
          <GlassPanel key={p.id} variant="strong" className="p-5">
            <div className="flex items-start justify-between mb-3 gap-3">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <Badge tone={projectStatusTone[p.status]}>
                    {p.status === "on-track" ? "En cours" : p.status === "at-risk" ? "À surveiller" : p.status === "delayed" ? "Retard" : "Terminé"}
                  </Badge>
                  <span className="text-xs text-text-muted">{p.code}</span>
                </div>
                <Link href={`/projects/${p.id}`} className="block">
                  <h3 className="font-semibold text-base hover:text-cyan transition leading-tight">{p.name}</h3>
                </Link>
                <p className="text-xs text-text-muted mt-1">{p.pm}</p>
              </div>
              <div className="text-right shrink-0">
                <p className="text-xs text-text-muted">Avancement</p>
                <p className="text-2xl font-bold text-cyan">{p.progress} %</p>
              </div>
            </div>

            <div className="h-1.5 rounded-full bg-white/5 overflow-hidden mb-4">
              <div
                className="h-full rounded-full bg-gradient-to-r from-cyan to-bleu-clair"
                style={{ width: `${p.progress}%` }}
              />
            </div>

            <div className="space-y-2">
              <p className="text-[10px] uppercase tracking-widest text-text-muted mb-1">Jalons clés</p>
              {p.jalons.map(j => {
                const cfg = statusConfig[j.status];
                const Icon = cfg.icon;
                return (
                  <div key={j.id} className="flex items-center gap-3 py-1.5 px-2 rounded-lg hover:bg-white/3 transition">
                    <Icon className={cn("w-4 h-4 shrink-0", cfg.color)} />
                    <p className="flex-1 text-sm">{j.label}</p>
                    <span className="text-xs text-text-muted whitespace-nowrap">
                      {new Date(j.date).toLocaleDateString("fr-FR", { day: "numeric", month: "short", year: "2-digit" })}
                    </span>
                  </div>
                );
              })}
            </div>

            <div className="flex items-center justify-between pt-3 mt-3 border-t border-white/5">
              <div className="flex items-center gap-3 text-xs">
                <span className="text-text-muted">Budget</span>
                <span className="font-medium tabular-nums">{formatCurrency(p.budget, p.currency)}</span>
                <span className="text-text-muted">·</span>
                <span className="text-text-muted">consommé</span>
                <span className="font-medium tabular-nums">{((p.spent / p.budget) * 100).toFixed(0)} %</span>
              </div>
              <Link href={`/projects/${p.id}`} className="text-xs text-cyan hover:underline flex items-center gap-1">
                Détail <ChevronRight className="w-3 h-3" />
              </Link>
            </div>
          </GlassPanel>
        ))}
      </div>
    </div>
  );
}
