import { PageHeader } from "@/components/nav/page-header";
import { GlassPanel } from "@/components/ui/glass-panel";
import { KanbanBoard } from "@/components/maturation/kanban-board";
import { NewProjectButton } from "@/components/maturation/new-project-button";
import { maturationProjects, maturityScore, stageOrder, stageLabels } from "@/lib/data/maturation";
import { Sprout, FlaskConical, Rocket, Factory } from "lucide-react";

const stageIcons = {
  ideation: Sprout,
  validation: FlaskConical,
  pilote: Rocket,
  industrialisation: Factory,
};

export default function MaturationPage() {
  const total = maturationProjects.length;
  const avgScore = Math.round((maturationProjects.reduce((s, p) => s + maturityScore(p), 0) / total) * 100);
  const promotable = maturationProjects.filter(p => maturityScore(p) > 0.85).length;

  return (
    <div className="space-y-6">
      <PageHeader
        title="Cellule de Maturation"
        subtitle="Pipeline d'incubation des projets IPD — de l'idéation à l'industrialisation. Évaluation par scorecard normalisée."
        badge="7 projets actifs"
        actions={<NewProjectButton />}
      />

      {/* Pipeline metrics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <GlassPanel className="p-4">
          <p className="text-[10px] uppercase tracking-widest text-text-muted">Projets actifs</p>
          <p className="text-3xl font-bold text-cyan mt-1">{total}</p>
          <p className="text-xs text-text-secondary mt-1">à travers les 4 stades</p>
        </GlassPanel>
        <GlassPanel className="p-4">
          <p className="text-[10px] uppercase tracking-widest text-text-muted">Score moyen</p>
          <p className="text-3xl font-bold text-cyan mt-1">{avgScore}<span className="text-base text-text-muted">/100</span></p>
          <p className="text-xs text-text-secondary mt-1">scorecard pondérée</p>
        </GlassPanel>
        <GlassPanel className="p-4">
          <p className="text-[10px] uppercase tracking-widest text-text-muted">Prêts à promouvoir</p>
          <p className="text-3xl font-bold text-vert mt-1">{promotable}</p>
          <p className="text-xs text-text-secondary mt-1">score &gt; 85</p>
        </GlassPanel>
        <GlassPanel className="p-4">
          <p className="text-[10px] uppercase tracking-widest text-text-muted">Délai moyen idéation → industrialisation</p>
          <p className="text-3xl font-bold text-violet-pale mt-1">14<span className="text-base text-text-muted"> mois</span></p>
          <p className="text-xs text-text-secondary mt-1">médiane historique</p>
        </GlassPanel>
      </div>

      {/* Pipeline visualization */}
      <GlassPanel variant="strong" className="p-5">
        <h2 className="text-lg font-semibold mb-4">Pipeline de maturation — 4 stades</h2>
        <div className="flex items-center gap-3 overflow-x-auto pb-2">
          {stageOrder.map((stage, i) => {
            const Icon = stageIcons[stage];
            const count = maturationProjects.filter(p => p.stage === stage).length;
            return (
              <div key={stage} className="flex items-center gap-3 shrink-0">
                <div className="flex flex-col items-center gap-2 min-w-[140px]">
                  <div className="relative">
                    <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-cyan/20 to-bleu-ipd/40 border border-cyan/30 flex items-center justify-center glow-cyan">
                      <Icon className="w-6 h-6 text-cyan" />
                    </div>
                    <div className="absolute -top-1 -right-1 w-6 h-6 rounded-full bg-cyan text-bleu-ipd font-bold text-xs flex items-center justify-center">
                      {count}
                    </div>
                  </div>
                  <p className="text-xs uppercase tracking-wider text-text-muted">Stade {i + 1}</p>
                  <p className="font-semibold text-sm text-center">{stageLabels[stage]}</p>
                </div>
                {i < stageOrder.length - 1 && (
                  <div className="flex-1 h-px bg-gradient-to-r from-cyan/30 via-cyan/10 to-cyan/30 relative">
                    <div className="absolute inset-0 shimmer" />
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </GlassPanel>

      {/* Kanban */}
      <KanbanBoard />
    </div>
  );
}
