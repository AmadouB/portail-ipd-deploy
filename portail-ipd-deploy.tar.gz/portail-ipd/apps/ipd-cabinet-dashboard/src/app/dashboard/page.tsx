import { PageHeader } from "@/components/nav/page-header";
import { StatCard } from "@/components/ui/stat-card";
import { AlertsPanel } from "@/components/dashboard/alerts-panel";
import { PortfolioTrend } from "@/components/dashboard/portfolio-trend";
import { InterdependenciesGraph } from "@/components/dashboard/interdependencies-graph";
import { ArbitrageSimulator } from "@/components/dashboard/arbitrage-simulator";
import { PortfolioTable } from "@/components/dashboard/portfolio-table";
import Link from "next/link";
import { kpis } from "@/lib/data/kpis";
import { Newspaper } from "lucide-react";

export default async function DashboardPage({ searchParams }: { searchParams: Promise<{ q?: string }> }) {
  const { q } = await searchParams;
  return (
    <div className="space-y-6">
      <PageHeader
        title="Hub Stratégique — Cabinet AG"
        subtitle="Voir, décider, agir. Vue consolidée du portefeuille IPD avec alertes prédictives et outils d'arbitrage."
        badge="Live · Cabinet AG"
        actions={
          <Link
            href="/veille"
            className="flex items-center gap-2 px-4 py-2 rounded-xl glass border border-cyan/30 text-cyan hover:bg-cyan/10 transition text-sm font-medium"
          >
            <Newspaper className="w-4 h-4" />
            Briefing du jour
          </Link>
        }
      />

      {/* KPI Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {kpis.map(kpi => (
          <StatCard key={kpi.label} {...kpi} />
        ))}
      </div>

      {/* Top zone : trend + alerts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2">
          <PortfolioTrend />
        </div>
        <div id="alerts">
          <AlertsPanel />
        </div>
      </div>

      {/* Middle zone : interdependencies + arbitrage */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-4">
        <div className="lg:col-span-2">
          <InterdependenciesGraph />
        </div>
        <div className="lg:col-span-3">
          <ArbitrageSimulator />
        </div>
      </div>

      {/* Portfolio table */}
      <PortfolioTable initialQuery={q ?? ""} />
    </div>
  );
}
