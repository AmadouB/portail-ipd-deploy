import Link from "next/link";
import { notFound } from "next/navigation";
import { getProjectById, projects } from "@/lib/data/projects";
import { GlassPanel } from "@/components/ui/glass-panel";
import { Badge } from "@/components/ui/badge";
import { Messaging } from "@/components/ui/messaging";
import { ArrowLeft, Calendar, User, Tag, CheckCircle2, Clock, AlertTriangle, Activity } from "lucide-react";
import { formatCurrency, cn } from "@/lib/utils";

const statusConfig = {
  done: { icon: CheckCircle2, color: "text-vert", bg: "bg-vert/10 border-vert/30", label: "Atteint" },
  "in-progress": { icon: Clock, color: "text-cyan", bg: "bg-cyan/10 border-cyan/30", label: "En cours" },
  upcoming: { icon: Calendar, color: "text-text-muted", bg: "bg-white/5 border-white/10", label: "À venir" },
  delayed: { icon: AlertTriangle, color: "text-rouge", bg: "bg-rouge/10 border-rouge/30", label: "Retard" },
};

const projectStatusTone = {
  "on-track": "vert",
  "at-risk": "orange",
  delayed: "rouge",
  completed: "cyan",
} as const;

const projectStatusLabel = {
  "on-track": "En cours",
  "at-risk": "À surveiller",
  delayed: "Retard",
  completed: "Terminé",
};

export function generateStaticParams() {
  return projects.map(p => ({ id: p.id }));
}

export default async function ProjectDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const p = getProjectById(id);
  if (!p) notFound();

  const tauxBudget = (p.spent / p.budget) * 100;
  const dureeTotaleJ = Math.round((new Date(p.endDate).getTime() - new Date(p.startDate).getTime()) / (1000 * 60 * 60 * 24));
  const ecouleeJ = Math.max(0, Math.round((Date.now() - new Date(p.startDate).getTime()) / (1000 * 60 * 60 * 24)));

  return (
    <div className="space-y-6">
      <Link
        href={p.pole === "MADIBA" ? "/madiba" : p.pole === "Grant Office" ? "/grants" : "/dashboard"}
        className="inline-flex items-center gap-2 text-sm text-text-muted hover:text-cyan transition"
      >
        <ArrowLeft className="w-4 h-4" /> Retour
      </Link>

      <header className="flex items-start justify-between gap-6 flex-wrap">
        <div>
          <div className="flex items-center gap-2 mb-2 flex-wrap">
            <Badge tone={projectStatusTone[p.status]}>{projectStatusLabel[p.status]}</Badge>
            <Badge tone="cyan">{p.pole}</Badge>
            {p.bailleur && <Badge tone="violet">{p.bailleur}</Badge>}
            <span className="text-xs text-text-muted">{p.code}</span>
          </div>
          <h1 className="text-3xl font-bold tracking-tight text-glow">{p.name}</h1>
          <p className="text-text-secondary mt-2 max-w-2xl">{p.description}</p>
          <div className="flex items-center gap-4 mt-3 text-sm flex-wrap">
            <div className="flex items-center gap-1.5 text-text-muted">
              <User className="w-4 h-4" /> {p.pm}
            </div>
            <div className="flex items-center gap-1.5 text-text-muted">
              <Calendar className="w-4 h-4" />
              {new Date(p.startDate).toLocaleDateString("fr-FR", { month: "short", year: "numeric" })} →{" "}
              {new Date(p.endDate).toLocaleDateString("fr-FR", { month: "short", year: "numeric" })}
            </div>
            <div className="flex items-center gap-1.5 text-text-muted">
              <Tag className="w-4 h-4" /> {p.tags.join(", ")}
            </div>
          </div>
        </div>
        <div className="text-right">
          <p className="text-xs text-text-muted">Avancement</p>
          <p className="text-4xl font-bold text-cyan">{p.progress} %</p>
        </div>
      </header>

      {/* Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <GlassPanel variant="strong" className="p-5">
          <p className="text-[10px] uppercase tracking-widest text-text-muted">Budget</p>
          <p className="text-2xl font-bold mt-1">{formatCurrency(p.budget, p.currency)}</p>
          <div className="mt-3 space-y-1.5">
            <div className="flex justify-between text-xs">
              <span className="text-text-muted">Consommé</span>
              <span className="font-medium">{formatCurrency(p.spent, p.currency)}</span>
            </div>
            <div className="h-2 rounded-full bg-white/5 overflow-hidden">
              <div
                className={cn("h-full rounded-full bg-gradient-to-r",
                  tauxBudget > p.progress + 10 ? "from-orange to-rouge" : "from-cyan to-vert"
                )}
                style={{ width: `${tauxBudget}%` }}
              />
            </div>
            <p className="text-xs text-cyan font-medium">{tauxBudget.toFixed(1)} % du budget</p>
          </div>
        </GlassPanel>

        <GlassPanel variant="strong" className="p-5">
          <p className="text-[10px] uppercase tracking-widest text-text-muted">Avancement vs budget</p>
          <div className="mt-3 space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-text-muted">Avancement physique</span>
              <span className="font-bold text-cyan">{p.progress} %</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-text-muted">Avancement budgétaire</span>
              <span className="font-bold text-text-primary">{tauxBudget.toFixed(0)} %</span>
            </div>
            <div className="flex justify-between text-sm pt-2 border-t border-white/5">
              <span className="text-text-muted">Écart</span>
              <span className={cn("font-bold", tauxBudget > p.progress + 5 ? "text-orange" : "text-vert")}>
                {tauxBudget > p.progress ? "+" : ""}{(tauxBudget - p.progress).toFixed(1)} pts
              </span>
            </div>
          </div>
        </GlassPanel>

        <GlassPanel variant="strong" className="p-5">
          <p className="text-[10px] uppercase tracking-widest text-text-muted">Calendrier</p>
          <p className="text-2xl font-bold mt-1">{Math.round(ecouleeJ / 30)} <span className="text-base text-text-muted">/ {Math.round(dureeTotaleJ / 30)} mois</span></p>
          <div className="mt-3 space-y-1.5">
            <div className="h-2 rounded-full bg-white/5 overflow-hidden">
              <div className="h-full rounded-full bg-gradient-to-r from-violet to-cyan" style={{ width: `${(ecouleeJ / dureeTotaleJ) * 100}%` }} />
            </div>
            <p className="text-xs text-violet-pale font-medium">{((ecouleeJ / dureeTotaleJ) * 100).toFixed(0)} % de la durée écoulée</p>
          </div>
        </GlassPanel>
      </div>

      {/* Milestones timeline */}
      <GlassPanel variant="strong" className="p-5">
        <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
          <Activity className="w-5 h-5 text-cyan" />
          Jalons du projet
        </h2>
        <div className="relative">
          <div className="absolute left-3 top-2 bottom-2 w-px bg-gradient-to-b from-cyan via-cyan/30 to-transparent" />
          <div className="space-y-3">
            {p.jalons.map(j => {
              const cfg = statusConfig[j.status];
              const Icon = cfg.icon;
              return (
                <div key={j.id} className="flex items-start gap-4 group">
                  <div className={cn("relative w-7 h-7 rounded-full flex items-center justify-center border-2 z-10 shrink-0", cfg.bg)}>
                    <Icon className={cn("w-3.5 h-3.5", cfg.color)} />
                  </div>
                  <div className={cn("flex-1 p-3 rounded-xl border bg-white/3 transition group-hover:bg-glass-hover", cfg.bg)}>
                    <div className="flex items-center justify-between flex-wrap gap-2">
                      <p className="font-medium text-text-primary">{j.label}</p>
                      <div className="flex items-center gap-2">
                        <Badge tone={j.status === "delayed" ? "rouge" : j.status === "done" ? "vert" : j.status === "in-progress" ? "cyan" : "neutre"}>
                          {cfg.label}
                        </Badge>
                        <span className="text-xs text-text-muted whitespace-nowrap">
                          {new Date(j.date).toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" })}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </GlassPanel>

      {/* Communication */}
      <Messaging
        initial={[
          {
            id: "m-1",
            author: p.pm,
            authorTone: "primary",
            content: "Point d'avancement validé en réunion équipe ce matin. Aucun blocage technique identifié.",
            timeAgo: "il y a 2 jours",
          },
          {
            id: "m-2",
            author: "M&E Engine",
            authorTone: "engine",
            content: "3 indicateurs M&E mis à jour automatiquement à partir des rapports terrain.",
            timeAgo: "il y a 4 jours",
          },
        ]}
      />
    </div>
  );
}
