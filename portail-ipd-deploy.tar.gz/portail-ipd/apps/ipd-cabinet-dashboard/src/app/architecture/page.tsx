import { PageHeader } from "@/components/nav/page-header";
import { GlassPanel } from "@/components/ui/glass-panel";
import { ArchitectureDiagram } from "@/components/architecture/diagram";
import { ActivitiesTimeline } from "@/components/architecture/activities-timeline";
import { entities, activities } from "@/lib/data/architecture";
import { Network, Sparkles } from "lucide-react";

export default function ArchitecturePage() {
  const stats = {
    operational: entities.filter(e => e.status === "operational").length,
    transitioning: entities.filter(e => e.status === "transitioning").length,
    planned: entities.filter(e => e.status === "planned").length,
    total: entities.length,
    actCompleted: activities.filter(a => a.status === "completed").length,
    actInProgress: activities.filter(a => a.status === "in-progress").length,
    actPlanned: activities.filter(a => a.status === "planned").length,
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Architecture institutionnelle"
        subtitle="Système de gestion de projets piloté par le Cabinet AG. Cliquez sur une entité pour explorer responsables, indicateurs M&E, projets rattachés et activités de mise en œuvre."
        badge="Cabinet AG · Pilotage"
      />

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <GlassPanel className="p-4">
          <p className="text-[10px] uppercase tracking-widest text-text-muted">Entités du système</p>
          <p className="text-3xl font-bold text-cyan mt-1">{stats.total}</p>
          <p className="text-xs text-text-secondary mt-1">tous niveaux confondus</p>
        </GlassPanel>
        <GlassPanel className="p-4">
          <p className="text-[10px] uppercase tracking-widest text-text-muted">Opérationnel</p>
          <p className="text-3xl font-bold text-vert mt-1">{stats.operational}</p>
          <p className="text-xs text-text-secondary mt-1">en service</p>
        </GlassPanel>
        <GlassPanel className="p-4">
          <p className="text-[10px] uppercase tracking-widest text-text-muted">En transition</p>
          <p className="text-3xl font-bold text-cyan mt-1">{stats.transitioning}</p>
          <p className="text-xs text-text-secondary mt-1">refonte en cours</p>
        </GlassPanel>
        <GlassPanel className="p-4">
          <p className="text-[10px] uppercase tracking-widest text-text-muted">Activités</p>
          <p className="text-3xl font-bold text-bleu-clair mt-1">{activities.length}</p>
          <p className="text-xs text-text-secondary mt-1">
            {stats.actCompleted} réalisées · {stats.actInProgress} en cours · {stats.actPlanned} planifiées
          </p>
        </GlassPanel>
      </div>

      {/* Interactive 3D diagram */}
      <GlassPanel variant="strong" className="p-5">
        <div className="flex items-center justify-between mb-3 flex-wrap gap-3">
          <div>
            <h2 className="text-lg font-semibold flex items-center gap-2">
              <Network className="w-5 h-5 text-bleu-ipd" />
              Architecture cible — vue 3D interactive
            </h2>
            <p className="text-xs text-text-muted mt-0.5">
              Hub Stratégique (Cabinet AG) · Pôles Opérationnels (MADIBA, Grant Office) · Cellule de Maturation · MEL System transverse
            </p>
          </div>
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-cyan/10 border border-cyan/30 text-cyan text-xs font-medium">
            <Sparkles className="w-3 h-3" /> Cliquez les entités
          </span>
        </div>
        <ArchitectureDiagram />
      </GlassPanel>

      {/* Activities timeline */}
      <ActivitiesTimeline />
    </div>
  );
}
