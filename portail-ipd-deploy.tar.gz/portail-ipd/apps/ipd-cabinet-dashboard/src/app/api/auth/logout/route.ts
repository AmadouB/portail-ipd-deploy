import { NextResponse } from "next/server";
import { clearSession } from "@/lib/auth";

const BASE_PATH = process.env.NEXT_BASE_PATH ?? "";

export async function POST(req: Request) {
  await clearSession();
  // Use absolute pathname including basePath so the redirect lands at
  // /cabinet-ipd/login through the upstream Nginx (instead of /login).
  return NextResponse.redirect(new URL(`${BASE_PATH}/login`, req.url), {
    status: 303,
  });
}
