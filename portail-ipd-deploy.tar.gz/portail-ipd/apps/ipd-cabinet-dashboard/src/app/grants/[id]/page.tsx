import Link from "next/link";
import { notFound } from "next/navigation";
import { getGrantById, grants } from "@/lib/data/grants";
import { GlassPanel } from "@/components/ui/glass-panel";
import { Badge } from "@/components/ui/badge";
import { Messaging } from "@/components/ui/messaging";
import { ArrowLeft, Calendar, User, Building2, FileCheck, BellRing } from "lucide-react";
import { formatCurrency, formatPct } from "@/lib/utils";
import { cn } from "@/lib/utils";

const statusTone = {
  pipeline: "violet",
  soumis: "cyan",
  négociation: "orange",
  actif: "vert",
  clôturé: "neutre",
} as const;

export function generateStaticParams() {
  return grants.map(g => ({ id: g.id }));
}

export default async function GrantDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const grant = getGrantById(id);
  if (!grant) notFound();

  const tauxDec = grant.amount > 0 ? (grant.decaisse / grant.amount) * 100 : 0;
  const restant = grant.amount - grant.decaisse;
  const dureeTotaleMois = Math.round((new Date(grant.endDate).getTime() - new Date(grant.startDate).getTime()) / (1000 * 60 * 60 * 24 * 30));
  const ecouleeMois = Math.max(0, Math.round((Date.now() - new Date(grant.startDate).getTime()) / (1000 * 60 * 60 * 24 * 30)));
  const tauxTemps = Math.min(100, (ecouleeMois / dureeTotaleMois) * 100);

  return (
    <div className="space-y-6">
      <Link href="/grants" className="inline-flex items-center gap-2 text-sm text-text-muted hover:text-cyan transition">
        <ArrowLeft className="w-4 h-4" /> Retour Grant Office
      </Link>

      <header className="flex items-start justify-between gap-6 flex-wrap">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Badge tone={statusTone[grant.status]}>{grant.status}</Badge>
            <Badge tone="neutre">{grant.bailleurType}</Badge>
            <span className="text-xs text-text-muted">{grant.code}</span>
          </div>
          <h1 className="text-3xl font-bold tracking-tight text-glow">{grant.title}</h1>
          <p className="text-text-secondary mt-1 max-w-2xl">{grant.description}</p>
        </div>
        <div className="text-right">
          <p className="text-xs text-text-muted">Montant total</p>
          <p className="text-3xl font-bold text-cyan">{formatCurrency(grant.amount, grant.currency)}</p>
        </div>
      </header>

      {/* Metrics row */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <GlassPanel variant="strong" className="p-5">
          <h3 className="text-sm font-semibold text-text-secondary mb-3">Exécution financière</h3>
          <div className="space-y-3">
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-text-muted">Décaissé</span>
                <span className="font-medium">{formatCurrency(grant.decaisse, grant.currency)}</span>
              </div>
              <div className="h-2 rounded-full bg-white/5 overflow-hidden">
                <div className="h-full bg-gradient-to-r from-cyan to-vert transition-all" style={{ width: `${tauxDec}%` }} />
              </div>
              <p className="text-xs text-cyan font-bold mt-1">{formatPct(tauxDec, 1)}</p>
            </div>
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-text-muted">Temps écoulé</span>
                <span className="font-medium">{ecouleeMois} / {dureeTotaleMois} mois</span>
              </div>
              <div className="h-2 rounded-full bg-white/5 overflow-hidden">
                <div className="h-full bg-gradient-to-r from-orange to-rouge transition-all" style={{ width: `${tauxTemps}%` }} />
              </div>
              <p className="text-xs text-orange font-bold mt-1">{formatPct(tauxTemps, 0)}</p>
            </div>
            <div className="pt-2 border-t border-white/5">
              <p className="text-xs text-text-muted">Reste à décaisser</p>
              <p className="text-lg font-bold text-text-primary">{formatCurrency(restant, grant.currency)}</p>
            </div>
          </div>
        </GlassPanel>

        <GlassPanel variant="strong" className="p-5">
          <h3 className="text-sm font-semibold text-text-secondary mb-3">Informations clés</h3>
          <div className="space-y-3 text-sm">
            <div className="flex items-start gap-2.5">
              <Building2 className="w-4 h-4 text-cyan mt-0.5" />
              <div>
                <p className="text-xs text-text-muted">Bailleur</p>
                <p className="font-medium">{grant.bailleur}</p>
              </div>
            </div>
            <div className="flex items-start gap-2.5">
              <User className="w-4 h-4 text-cyan mt-0.5" />
              <div>
                <p className="text-xs text-text-muted">Manager</p>
                <p className="font-medium">{grant.manager}</p>
              </div>
            </div>
            <div className="flex items-start gap-2.5">
              <Calendar className="w-4 h-4 text-cyan mt-0.5" />
              <div>
                <p className="text-xs text-text-muted">Période</p>
                <p className="font-medium">
                  {new Date(grant.startDate).toLocaleDateString("fr-FR", { month: "short", year: "numeric" })} →{" "}
                  {new Date(grant.endDate).toLocaleDateString("fr-FR", { month: "short", year: "numeric" })}
                </p>
              </div>
            </div>
            <div className="flex items-start gap-2.5">
              <FileCheck className="w-4 h-4 text-cyan mt-0.5" />
              <div>
                <p className="text-xs text-text-muted">Reporting</p>
                <p className="font-medium capitalize">{grant.reportingFreq}</p>
              </div>
            </div>
          </div>
        </GlassPanel>

        <GlassPanel variant="strong" className="p-5">
          <h3 className="text-sm font-semibold text-text-secondary mb-3">Conformité bailleur</h3>
          <div className="flex items-center justify-center my-4">
            <div className="relative w-32 h-32">
              <svg viewBox="0 0 100 100" className="w-full h-full -rotate-90">
                <circle cx="50" cy="50" r="42" fill="none" stroke="rgba(255,255,255,0.05)" strokeWidth="8" />
                <circle
                  cx="50" cy="50" r="42" fill="none"
                  stroke={grant.conformity > 90 ? "#5DBB63" : grant.conformity > 75 ? "#00D4FF" : "#F39200"}
                  strokeWidth="8"
                  strokeDasharray={`${grant.conformity * 2.64} 264`}
                  strokeLinecap="round"
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <p className={cn("text-2xl font-bold",
                  grant.conformity > 90 ? "text-vert" : grant.conformity > 75 ? "text-cyan" : "text-orange",
                )}>
                  {grant.conformity > 0 ? `${grant.conformity}%` : "—"}
                </p>
                <p className="text-[10px] text-text-muted">conformité</p>
              </div>
            </div>
          </div>
          {grant.status === "actif" || grant.status === "clôturé" ? (
            <ul className="text-xs text-text-secondary space-y-1.5 mt-3">
              <li className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-vert" />
                Reporting {grant.reportingFreq} à jour
              </li>
              <li className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-vert" />
                Audit financier validé
              </li>
              <li className="flex items-center gap-2">
                <span className={cn("w-1.5 h-1.5 rounded-full", grant.conformity > 90 ? "bg-vert" : "bg-orange")} />
                {grant.conformity > 90 ? "Tous les indicateurs M&E à jour" : "2 indicateurs M\u0026E en attente"}
              </li>
            </ul>
          ) : (
            <p className="text-xs text-text-muted text-center mt-3">
              Conformité non encore évaluée — grant {grant.status === "pipeline" ? "en veille / qualification" : grant.status === "soumis" ? "en attente de retour bailleur" : "en cours de négociation"}.
            </p>
          )}
        </GlassPanel>
      </div>

      {/* Activity / actions */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <GlassPanel variant="strong" className="p-5">
          <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
            <BellRing className="w-4 h-4 text-cyan" />
            Activité récente
          </h3>
          <div className="space-y-3">
            {(() => {
              const activeFlow = [
                { date: "il y a 2 jours", actor: grant.manager, action: "a soumis le rapport trimestriel au bailleur" },
                { date: "il y a 5 jours", actor: "M&E Engine", action: "a validé 4 indicateurs de performance" },
                { date: "il y a 1 semaine", actor: "Cabinet AG", action: "a approuvé une réallocation de 5 % vers le volet formation" },
                { date: "il y a 3 semaines", actor: "AI Predict", action: "a signalé un risque de retard sur le jalon mid-term" },
              ];
              const closedFlow = [
                { date: "il y a 1 mois", actor: grant.manager, action: "a clôturé le grant après audit final" },
                { date: "il y a 2 mois", actor: "M&E Engine", action: "a publié le rapport d'impact final" },
                { date: "il y a 3 mois", actor: "Cabinet AG", action: "a validé l'utilisation finale des fonds" },
              ];
              const negociationFlow = [
                { date: "il y a 3 jours", actor: grant.manager, action: "a transmis la version révisée du budget au bailleur" },
                { date: "il y a 1 semaine", actor: "Cabinet AG", action: "a validé l'orientation stratégique du grant" },
                { date: "il y a 2 semaines", actor: grant.manager, action: "a ouvert le cycle de négociation avec le bailleur" },
              ];
              const soumisFlow = [
                { date: "il y a 4 jours", actor: grant.manager, action: "a soumis la note de cadrage au bailleur" },
                { date: "il y a 1 semaine", actor: "Cabinet AG", action: "a validé la soumission" },
                { date: "il y a 2 semaines", actor: grant.manager, action: "a finalisé le dossier de candidature" },
              ];
              const pipelineFlow = [
                { date: "il y a 2 jours", actor: "AI Predict", action: "a identifié une opportunité d'alignement avec ce grant" },
                { date: "il y a 1 semaine", actor: grant.manager, action: "a inscrit le grant en veille" },
              ];
              const flow =
                grant.status === "actif" ? activeFlow :
                grant.status === "clôturé" ? closedFlow :
                grant.status === "négociation" ? negociationFlow :
                grant.status === "soumis" ? soumisFlow :
                pipelineFlow;
              return flow.map((a, i) => (
                <div key={i} className="flex items-start gap-3 text-sm pb-3 border-b border-white/5 last:border-0">
                  <div className="mt-1 w-2 h-2 rounded-full bg-cyan/60 shrink-0" />
                  <div className="flex-1">
                    <p className="text-text-primary"><span className="font-medium text-cyan">{a.actor}</span> {a.action}</p>
                    <p className="text-xs text-text-muted mt-0.5">{a.date}</p>
                  </div>
                </div>
              ));
            })()}
          </div>
        </GlassPanel>

        <Messaging
          title="Messagerie contextuelle"
          initial={(() => {
            if (grant.status === "actif") return [
              { id: "g-m-1", author: grant.manager, authorTone: "primary" as const, content: "Le rapport est prêt. Je sollicite la validation du Cabinet avant soumission demain matin.", timeAgo: "il y a 1 j" },
              { id: "g-m-2", author: "Cabinet AG", authorTone: "cabinet" as const, content: "Validé. Merci de joindre le mémo de réallocation au rapport.", timeAgo: "il y a 18 h" },
            ];
            if (grant.status === "clôturé") return [
              { id: "g-m-3", author: "Cabinet AG", authorTone: "engine" as const, content: "Grant clôturé avec succès. Merci à toute l\u0027équipe pour l\u0027exécution exemplaire.", timeAgo: "à la clôture" },
            ];
            if (grant.status === "négociation") return [
              { id: "g-m-4", author: grant.manager, authorTone: "primary" as const, content: "Le bailleur a demandé un ajustement du périmètre. Réunion de calage prévue cette semaine.", timeAgo: "il y a 2 j" },
            ];
            if (grant.status === "soumis") return [
              { id: "g-m-5", author: grant.manager, authorTone: "primary" as const, content: "Dossier soumis. Retour attendu sous 6 semaines selon le calendrier du bailleur.", timeAgo: "il y a 4 j" },
            ];
            return [
              { id: "g-m-6", author: grant.manager, authorTone: "primary" as const, content: "Grant en veille. Nous attendons l\u0027ouverture officielle de l\u0027appel à projets.", timeAgo: "il y a 1 sem." },
            ];
          })()}
        />
      </div>
    </div>
  );
}
