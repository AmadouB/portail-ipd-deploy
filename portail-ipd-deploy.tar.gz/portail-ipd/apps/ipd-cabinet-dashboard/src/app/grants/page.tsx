import Link from "next/link";
import { PageHeader } from "@/components/nav/page-header";
import { GlassPanel } from "@/components/ui/glass-panel";
import { Badge } from "@/components/ui/badge";
import { NewGrantButton } from "@/components/grants/new-grant-button";
import { grants, activeGrants, pipelineGrants } from "@/lib/data/grants";
import { formatCurrency, formatPct } from "@/lib/utils";
import { Banknote, FileSignature, ChevronRight, Calendar } from "lucide-react";
import { cn } from "@/lib/utils";

const statusTone = {
  pipeline: "violet",
  soumis: "cyan",
  négociation: "orange",
  actif: "vert",
  clôturé: "neutre",
} as const;

const statusLabel = {
  pipeline: "Pipeline",
  soumis: "Soumis",
  négociation: "Négociation",
  actif: "Actif",
  clôturé: "Clôturé",
};

export default function GrantsPage() {
  const totalActif = activeGrants().reduce((s, g) => s + g.amount, 0);
  const totalDecaisse = activeGrants().reduce((s, g) => s + g.decaisse, 0);
  const tauxExec = totalActif ? (totalDecaisse / totalActif) * 100 : 0;
  const totalPipeline = pipelineGrants().reduce((s, g) => s + g.amount, 0);

  return (
    <div className="space-y-6">
      <PageHeader
        title="Grant Office"
        subtitle="Gestion du cycle de vie des subventions — pipeline, négociation, exécution, conformité bailleurs."
        badge={`${activeGrants().length} grants actifs`}
        actions={<NewGrantButton />}
      />

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <GlassPanel className="p-4">
          <p className="text-[10px] uppercase tracking-widest text-text-muted">Enveloppe active</p>
          <p className="text-2xl font-bold text-cyan mt-1">{formatCurrency(totalActif)}</p>
          <p className="text-xs text-text-secondary mt-1">{activeGrants().length} grants</p>
        </GlassPanel>
        <GlassPanel className="p-4">
          <p className="text-[10px] uppercase tracking-widest text-text-muted">Décaissé</p>
          <p className="text-2xl font-bold text-vert mt-1">{formatCurrency(totalDecaisse)}</p>
          <p className="text-xs text-text-secondary mt-1">{formatPct(tauxExec)}</p>
        </GlassPanel>
        <GlassPanel className="p-4">
          <p className="text-[10px] uppercase tracking-widest text-text-muted">Pipeline</p>
          <p className="text-2xl font-bold text-violet-pale mt-1">{formatCurrency(totalPipeline)}</p>
          <p className="text-xs text-text-secondary mt-1">{pipelineGrants().length} en discussion</p>
        </GlassPanel>
        <GlassPanel className="p-4">
          <p className="text-[10px] uppercase tracking-widest text-text-muted">Conformité moyenne</p>
          <p className="text-2xl font-bold text-cyan mt-1">93 %</p>
          <p className="text-xs text-text-secondary mt-1">grants actifs</p>
        </GlassPanel>
      </div>

      {/* Pipeline visualization */}
      <GlassPanel variant="strong" className="p-5">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-lg font-semibold flex items-center gap-2">
              <FileSignature className="w-5 h-5 text-cyan" />
              Pipeline d&apos;appels à projets
            </h2>
            <p className="text-xs text-text-muted mt-0.5">Veille → soumission → négociation → exécution</p>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-5 gap-2">
          {(["pipeline", "soumis", "négociation", "actif", "clôturé"] as const).map(stage => {
            const items = grants.filter(g => g.status === stage);
            const total = items.reduce((s, g) => s + g.amount, 0);
            return (
              <div key={stage} className="rounded-xl border border-white/5 bg-white/3 p-3 min-h-[120px]">
                <div className="flex items-center justify-between mb-2">
                  <Badge tone={statusTone[stage]}>{statusLabel[stage]}</Badge>
                  <span className="text-xs font-bold text-text-secondary">{items.length}</span>
                </div>
                <p className="text-[10px] text-text-muted mb-2">{formatCurrency(total)}</p>
                <div className="space-y-1.5">
                  {items.slice(0, 3).map(g => (
                    <Link
                      key={g.id}
                      href={`/grants/${g.id}`}
                      className="block text-xs px-2 py-1.5 rounded-lg bg-white/5 hover:bg-cyan/10 hover:text-cyan transition truncate"
                    >
                      {g.bailleur.split(" ")[0]} · {g.code.split("-").slice(-1)}
                    </Link>
                  ))}
                  {items.length > 3 && (
                    <p className="text-[10px] text-text-muted text-center pt-1">+{items.length - 3} autres</p>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </GlassPanel>

      {/* Grants list */}
      <GlassPanel variant="strong" className="p-5">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h2 className="text-lg font-semibold flex items-center gap-2">
              <Banknote className="w-5 h-5 text-cyan" />
              Tous les grants
            </h2>
            <p className="text-xs text-text-muted mt-0.5">Tri par date de fin · cliquez pour ouvrir le détail</p>
          </div>
        </div>

        <div className="overflow-x-auto -mx-5">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-[10px] uppercase tracking-wider text-text-muted border-b border-white/5">
                <th className="px-5 py-2.5 font-medium">Code · Titre</th>
                <th className="px-3 py-2.5 font-medium">Bailleur</th>
                <th className="px-3 py-2.5 font-medium">Statut</th>
                <th className="px-3 py-2.5 font-medium text-right">Montant</th>
                <th className="px-3 py-2.5 font-medium">Décaissement</th>
                <th className="px-3 py-2.5 font-medium">Échéance</th>
                <th className="px-5 py-2.5 font-medium text-right"></th>
              </tr>
            </thead>
            <tbody>
              {grants.map(g => {
                const tauxDec = g.amount > 0 ? (g.decaisse / g.amount) * 100 : 0;
                return (
                  <tr key={g.id} className="border-b border-white/5 hover:bg-white/[0.02] transition group">
                    <td className="px-5 py-3">
                      <Link href={`/grants/${g.id}`} className="block">
                        <p className="font-medium text-text-primary group-hover:text-cyan transition truncate max-w-xs">
                          {g.title}
                        </p>
                        <p className="text-xs text-text-muted">{g.code}</p>
                      </Link>
                    </td>
                    <td className="px-3 py-3">
                      <p className="text-text-secondary text-xs">{g.bailleur}</p>
                      <Badge tone="neutre" className="mt-1">{g.bailleurType}</Badge>
                    </td>
                    <td className="px-3 py-3">
                      <Badge tone={statusTone[g.status]}>{statusLabel[g.status]}</Badge>
                    </td>
                    <td className="px-3 py-3 text-right tabular-nums">
                      <p className="font-medium">{formatCurrency(g.amount, g.currency)}</p>
                    </td>
                    <td className="px-3 py-3 min-w-[160px]">
                      {g.status === "actif" || g.status === "clôturé" ? (
                        <div className="flex items-center gap-2">
                          <div className="flex-1 h-1.5 rounded-full bg-white/5 overflow-hidden">
                            <div
                              className={cn("h-full rounded-full bg-gradient-to-r", tauxDec > 80 ? "from-vert to-cyan" : "from-cyan to-bleu-clair")}
                              style={{ width: `${tauxDec}%` }}
                            />
                          </div>
                          <span className="text-xs font-medium tabular-nums w-10 text-right">{tauxDec.toFixed(0)} %</span>
                        </div>
                      ) : (
                        <span className="text-xs text-text-muted">—</span>
                      )}
                    </td>
                    <td className="px-3 py-3">
                      <div className="flex items-center gap-1.5 text-xs text-text-secondary">
                        <Calendar className="w-3 h-3" />
                        {new Date(g.endDate).toLocaleDateString("fr-FR", { month: "short", year: "numeric" })}
                      </div>
                    </td>
                    <td className="px-5 py-3 text-right">
                      <Link href={`/grants/${g.id}`} className="text-text-muted group-hover:text-cyan transition inline-block">
                        <ChevronRight className="w-4 h-4" />
                      </Link>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </GlassPanel>
    </div>
  );
}
