"use server";

import { redirect } from "next/navigation";
import { setSession, validateCredentials } from "@/lib/auth";

export type LoginState = {
  error?: string;
  email?: string;
};

export async function loginAction(_prev: LoginState, formData: FormData): Promise<LoginState> {
  const email = String(formData.get("email") ?? "").trim();
  const password = String(formData.get("password") ?? "");
  const next = String(formData.get("next") ?? "/dashboard");

  if (!email || !password) {
    return { error: "Email et mot de passe requis.", email };
  }

  const user = validateCredentials(email, password);
  if (!user) {
    return {
      error: "Identifiants incorrects. Vérifiez votre email institutionnel et le mot de passe par défaut.",
      email,
    };
  }

  await setSession(user.email);
  redirect(next || "/dashboard");
}
