import Image from "next/image";
import { LoginForm } from "./login-form";
import { ShieldCheck, Sparkles, Lock } from "lucide-react";

export const dynamic = "force-dynamic";

export default async function LoginPage({
  searchParams,
}: {
  searchParams: Promise<{ next?: string }>;
}) {
  const { next } = await searchParams;

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Background atmosphere */}
      <div className="absolute inset-0 -z-10">
        <div className="absolute top-0 left-1/4 w-96 h-96 rounded-full bg-bleu-ipd/30 blur-3xl" />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 rounded-full bg-cyan/15 blur-3xl" />
        <svg className="absolute inset-0 w-full h-full opacity-[0.04]" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
              <path d="M 40 0 L 0 0 0 40" fill="none" stroke="white" strokeWidth="0.5" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#grid)" />
        </svg>
      </div>

      <div className="min-h-screen grid grid-cols-1 lg:grid-cols-2">
        {/* Left side — Branding & promise */}
        <div className="hidden lg:flex flex-col justify-between p-12 relative">
          <div className="flex items-center gap-3">
            <div className="rounded-xl bg-white/95 px-3 py-2 shadow-lg">
              <Image
                src="/logo-ipd.png"
                alt="Institut Pasteur de Dakar"
                width={180}
                height={75}
                className="h-12 w-auto object-contain"
                priority
              />
            </div>
          </div>

          <div className="space-y-6 max-w-md">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-cyan/10 border border-cyan/30 text-cyan text-xs font-semibold uppercase tracking-wider">
              <Sparkles className="w-3.5 h-3.5" />
              Cabinet AG · Démonstrateur
            </div>
            <h1 className="text-4xl font-bold leading-tight text-glow">
              Plateforme de Coordination & Suivi Stratégique
            </h1>
            <p className="text-text-secondary leading-relaxed">
              Voir, décider, agir. Le système nerveux de l&apos;Institut Pasteur de Dakar pour piloter
              MADIBA, le Grant Office et la Cellule de Maturation depuis un poste unique.
            </p>

            <div className="grid grid-cols-2 gap-3 pt-4">
              <Feature icon={<ShieldCheck className="w-4 h-4" />} title="MFA & souveraineté" desc="Données IPD chiffrées, hébergées au Sénégal" />
              <Feature icon={<Sparkles className="w-4 h-4" />} title="IA prédictive" desc="Alertes signaux faibles avant impact" />
              <Feature icon={<Lock className="w-4 h-4" />} title="Audit trail" desc="Trace inaltérable de chaque action" />
              <Feature icon={<ShieldCheck className="w-4 h-4" />} title="Conformité" desc="ISO 27001 · BMGF · Wellcome · EDCTP" />
            </div>
          </div>

          <p className="text-xs text-text-muted">
            Institut Pasteur de Dakar · Cabinet du Directeur Général · Avril 2026
          </p>
        </div>

        {/* Right side — Login form */}
        <div className="flex items-center justify-center p-6 lg:p-12">
          <div className="w-full max-w-md">
            {/* Mobile logo */}
            <div className="lg:hidden flex items-center justify-center mb-8">
              <div className="rounded-xl bg-white/95 px-3 py-2 shadow-lg">
                <Image
                  src="/logo-ipd.png"
                  alt="Institut Pasteur de Dakar"
                  width={180}
                  height={75}
                  className="h-12 w-auto object-contain"
                  priority
                />
              </div>
            </div>

            <div className="glass-strong rounded-2xl p-8">
              <div className="mb-6">
                <h2 className="text-2xl font-bold mb-1">Connexion</h2>
                <p className="text-sm text-text-secondary">
                  Accédez à votre tableau de bord avec votre adresse institutionnelle Pasteur.
                </p>
              </div>

              <LoginForm next={next} />
            </div>

            <p className="text-center text-[11px] text-text-muted mt-6">
              Sécurité : connexion chiffrée TLS 1.3 · session 7 jours · MFA obligatoire en production
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Feature({ icon, title, desc }: { icon: React.ReactNode; title: string; desc: string }) {
  return (
    <div className="flex gap-2.5 p-2.5 rounded-xl bg-white/3 border border-white/5">
      <div className="text-cyan mt-0.5">{icon}</div>
      <div>
        <p className="text-xs font-semibold text-text-primary leading-tight">{title}</p>
        <p className="text-[10px] text-text-muted leading-snug mt-0.5">{desc}</p>
      </div>
    </div>
  );
}
