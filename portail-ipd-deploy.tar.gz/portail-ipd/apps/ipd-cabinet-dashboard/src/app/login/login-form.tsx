"use client";

import { useActionState, useState } from "react";
import { loginAction, type LoginState } from "./actions";
import { Lock, Mail, Eye, EyeOff, ArrowRight, ShieldCheck, Info } from "lucide-react";
import { cn } from "@/lib/utils";

interface LoginFormProps {
  next?: string;
}

const initialState: LoginState = {};

export function LoginForm({ next }: LoginFormProps) {
  const [state, formAction, isPending] = useActionState(loginAction, initialState);
  const [showPwd, setShowPwd] = useState(false);

  return (
    <form action={formAction} className="space-y-4">
      <input type="hidden" name="next" value={next ?? "/dashboard"} />

      {state.error && (
        <div className="rounded-xl border border-rouge/40 bg-rouge/10 px-4 py-3 text-sm text-rouge flex items-start gap-2">
          <ShieldCheck className="w-4 h-4 mt-0.5 shrink-0" />
          <span>{state.error}</span>
        </div>
      )}

      <div>
        <label htmlFor="email" className="block text-xs font-medium text-text-secondary mb-1.5 uppercase tracking-wider">
          Adresse institutionnelle
        </label>
        <div className="relative">
          <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-text-muted" />
          <input
            id="email"
            name="email"
            type="email"
            required
            autoComplete="email"
            defaultValue={state.email}
            placeholder="prenom.NOM@pasteur.sn"
            className="w-full pl-10 pr-3 py-2.5 rounded-xl bg-white/5 border border-white/10 text-sm outline-none focus:border-bleu-ipd/60 focus:bg-white/10 transition placeholder:text-text-muted"
          />
        </div>
      </div>

      <div>
        <label htmlFor="password" className="block text-xs font-medium text-text-secondary mb-1.5 uppercase tracking-wider">
          Mot de passe
        </label>
        <div className="relative">
          <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-text-muted" />
          <input
            id="password"
            name="password"
            type={showPwd ? "text" : "password"}
            required
            autoComplete="current-password"
            placeholder="••••••••"
            className="w-full pl-10 pr-10 py-2.5 rounded-xl bg-white/5 border border-white/10 text-sm outline-none focus:border-bleu-ipd/60 focus:bg-white/10 transition placeholder:text-text-muted"
          />
          <button
            type="button"
            onClick={() => setShowPwd(p => !p)}
            tabIndex={-1}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-text-muted hover:text-text-primary transition"
            aria-label={showPwd ? "Masquer le mot de passe" : "Afficher le mot de passe"}
          >
            {showPwd ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
          </button>
        </div>
      </div>

      <button
        type="submit"
        disabled={isPending}
        className={cn(
          "w-full flex items-center justify-center gap-2 px-4 py-3 rounded-xl font-semibold text-sm transition",
          isPending
            ? "bg-bleu-ipd/40 text-white/70 cursor-wait"
            : "bg-gradient-to-r from-bleu-ipd to-cyan text-white hover:shadow-lg hover:shadow-bleu-ipd/30"
        )}
      >
        {isPending ? "Connexion en cours…" : "Se connecter"}
        {!isPending && <ArrowRight className="w-4 h-4" />}
      </button>

      <div className="rounded-xl border border-cyan/25 bg-cyan/5 px-3 py-2.5 text-[11px] text-text-secondary flex items-start gap-2">
        <Info className="w-3.5 h-3.5 mt-0.5 shrink-0 text-cyan" />
        <div>
          <p className="font-semibold text-cyan mb-0.5">Démonstrateur — accès Cabinet AG</p>
          <p>Mot de passe par défaut : <code className="font-mono text-cyan">IPD2026!</code></p>
          <p className="mt-1">À changer lors de la mise en production.</p>
        </div>
      </div>
    </form>
  );
}
