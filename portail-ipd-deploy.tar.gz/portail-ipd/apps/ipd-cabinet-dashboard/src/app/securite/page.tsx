import { PageHeader } from "@/components/nav/page-header";
import { GlassPanel } from "@/components/ui/glass-panel";
import { Badge } from "@/components/ui/badge";
import { Shield, Key, Lock, MapPin, FileCheck, AlertTriangle, CheckCircle2, Clock, LogIn, LogOut, FilePlus, Settings as SettingsIcon, Eye, ShieldCheck, ShieldAlert } from "lucide-react";
import { cn } from "@/lib/utils";

interface AuthEvent {
  id: string;
  user: string;
  role: string;
  action: "login" | "logout" | "mfa-success" | "mfa-failure" | "config-change" | "data-export" | "view-sensitive";
  ip: string;
  device: string;
  at: string;
  status: "success" | "blocked";
}

const authEvents: AuthEvent[] = [
  { id: "e-001", user: "Dr. Aminata Diop", role: "PM MADIBA", action: "login", ip: "10.42.1.18", device: "MacBook · Dakar", at: "2026-04-25T07:14:00Z", status: "success" },
  { id: "e-002", user: "Cheikh Tidiane Sall", role: "Grant Manager", action: "data-export", ip: "10.42.1.22", device: "Windows · Dakar", at: "2026-04-25T06:45:00Z", status: "success" },
  { id: "e-003", user: "—", role: "tentative", action: "mfa-failure", ip: "104.244.78.14", device: "iOS · Inconnu", at: "2026-04-25T05:32:00Z", status: "blocked" },
  { id: "e-004", user: "Dr. Souleymane Mboup", role: "Cabinet AG", action: "view-sensitive", ip: "10.42.1.5", device: "iPad · Dakar", at: "2026-04-25T05:08:00Z", status: "success" },
  { id: "e-005", user: "Système", role: "auto", action: "config-change", ip: "—", device: "AI Predict", at: "2026-04-25T04:00:00Z", status: "success" },
  { id: "e-006", user: "Dr. Aboubakar Sy", role: "PM MADIBA", action: "login", ip: "10.42.1.31", device: "Android · Dakar", at: "2026-04-25T03:42:00Z", status: "success" },
  { id: "e-007", user: "Khady Ndiaye", role: "Grant Manager", action: "logout", ip: "10.42.1.27", device: "MacBook · Dakar", at: "2026-04-24T18:55:00Z", status: "success" },
  { id: "e-008", user: "—", role: "tentative", action: "login", ip: "212.97.42.198", device: "Linux · Inconnu", at: "2026-04-24T16:11:00Z", status: "blocked" },
];

const actionLabels = {
  login: "s'est connecté",
  logout: "s'est déconnecté",
  "mfa-success": "a validé MFA",
  "mfa-failure": "a échoué la MFA",
  "config-change": "a modifié la configuration",
  "data-export": "a exporté des données",
  "view-sensitive": "a consulté un dossier sensible",
} as const;

const actionIcons = {
  login: LogIn,
  logout: LogOut,
  "mfa-success": ShieldCheck,
  "mfa-failure": ShieldAlert,
  "config-change": SettingsIcon,
  "data-export": FilePlus,
  "view-sensitive": Eye,
} as const;

interface ComplianceItem {
  id: string;
  label: string;
  scope: string;
  status: "compliant" | "in-progress" | "expiring";
  detail: string;
  validUntil?: string;
}

const compliance: ComplianceItem[] = [
  { id: "c-001", label: "ISO 27001", scope: "Sécurité de l'information", status: "compliant", detail: "Audit annuel passé sans non-conformité majeure", validUntil: "2027-03-15" },
  { id: "c-002", label: "Conformité bailleurs BMGF", scope: "Reporting & audit financier", status: "compliant", detail: "Cycle de revue trimestrielle à jour", validUntil: "2026-12-31" },
  { id: "c-003", label: "Conformité Wellcome", scope: "Open access + data sharing", status: "compliant", detail: "Politiques de partage de données alignées" },
  { id: "c-004", label: "Conformité EDCTP3", scope: "Essais cliniques GCP", status: "in-progress", detail: "Mise à jour de la SOP en cours — audit prévu en juin" },
  { id: "c-005", label: "Loi sénégalaise 2008-12 sur les données personnelles", scope: "Souveraineté", status: "compliant", detail: "Hébergement Sénégal · CDP enregistrée" },
  { id: "c-006", label: "Certificat OMS PQ — site MADIBA", scope: "Production vaccinale", status: "expiring", detail: "Renouvellement requis avant fin 2026", validUntil: "2026-11-30" },
];

function timeAgo(iso: string) {
  const diff = Date.now() - new Date(iso).getTime();
  const min = Math.round(diff / 60000);
  if (min < 1) return "à l'instant";
  if (min < 60) return `il y a ${min} min`;
  const h = Math.round(min / 60);
  if (h < 24) return `il y a ${h} h`;
  const d = Math.round(h / 24);
  return `il y a ${d} j`;
}

export default function SecuritePage() {
  const blocked = authEvents.filter(e => e.status === "blocked").length;
  const compliantCount = compliance.filter(c => c.status === "compliant").length;
  const expiring = compliance.filter(c => c.status === "expiring").length;

  return (
    <div className="space-y-6">
      <PageHeader
        title="Sécurité & souveraineté"
        subtitle="Posture de sécurité de la plateforme : authentification, audit trail, conformité bailleurs et hébergement souverain."
        badge="Live · Security"
      />

      {/* Posture summary */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <GlassPanel className="p-4">
          <div className="flex items-start gap-3">
            <div className="p-2 rounded-xl bg-vert/10 text-vert"><Lock className="w-5 h-5" /></div>
            <div>
              <p className="text-[10px] uppercase tracking-widest text-text-muted">Chiffrement</p>
              <p className="text-base font-bold text-vert mt-0.5">Bout en bout</p>
              <p className="text-xs text-text-secondary">AES-256 · TLS 1.3</p>
            </div>
          </div>
        </GlassPanel>
        <GlassPanel className="p-4">
          <div className="flex items-start gap-3">
            <div className="p-2 rounded-xl bg-cyan/10 text-cyan"><Key className="w-5 h-5" /></div>
            <div>
              <p className="text-[10px] uppercase tracking-widest text-text-muted">MFA</p>
              <p className="text-base font-bold text-cyan mt-0.5">Obligatoire</p>
              <p className="text-xs text-text-secondary">42/42 utilisateurs actifs</p>
            </div>
          </div>
        </GlassPanel>
        <GlassPanel className="p-4">
          <div className="flex items-start gap-3">
            <div className="p-2 rounded-xl bg-bleu-ipd/15 text-bleu-clair"><MapPin className="w-5 h-5" /></div>
            <div>
              <p className="text-[10px] uppercase tracking-widest text-text-muted">Hébergement</p>
              <p className="text-base font-bold text-bleu-clair mt-0.5">Souverain</p>
              <p className="text-xs text-text-secondary">Datacenter Dakar</p>
            </div>
          </div>
        </GlassPanel>
        <GlassPanel className="p-4">
          <div className="flex items-start gap-3">
            <div className={cn("p-2 rounded-xl",
              blocked > 0 ? "bg-orange/10 text-orange" : "bg-vert/10 text-vert",
            )}>
              {blocked > 0 ? <AlertTriangle className="w-5 h-5" /> : <ShieldCheck className="w-5 h-5" />}
            </div>
            <div>
              <p className="text-[10px] uppercase tracking-widest text-text-muted">Tentatives bloquées (24 h)</p>
              <p className={cn("text-base font-bold mt-0.5", blocked > 0 ? "text-orange" : "text-vert")}>
                {blocked}
              </p>
              <p className="text-xs text-text-secondary">{blocked > 0 ? "automatiquement filtrées" : "périmètre stable"}</p>
            </div>
          </div>
        </GlassPanel>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Audit trail */}
        <GlassPanel variant="strong" className="p-5 lg:col-span-2">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-lg font-semibold flex items-center gap-2">
                <FileCheck className="w-5 h-5 text-cyan" />
                Journal d&apos;authentification
              </h2>
              <p className="text-xs text-text-muted mt-0.5">Toutes les actions sensibles sont tracées</p>
            </div>
            <span className="text-xs px-2 py-1 rounded-full bg-cyan/10 border border-cyan/30 text-cyan font-medium">
              {authEvents.length} événements
            </span>
          </div>

          <div className="space-y-2 max-h-[560px] overflow-y-auto pr-2 -mr-2">
            {authEvents.map(e => {
              const Icon = actionIcons[e.action];
              const tone = e.status === "blocked" ? "rouge" : e.action.startsWith("mfa") || e.action === "view-sensitive" ? "cyan" : e.action === "data-export" || e.action === "config-change" ? "orange" : "vert";
              return (
                <div key={e.id} className={cn(
                  "rounded-xl border p-3 transition",
                  e.status === "blocked" ? "border-rouge/30 bg-rouge/5" : "border-white/5 bg-white/3",
                )}>
                  <div className="flex items-start gap-3">
                    <div className={cn("p-1.5 rounded-lg shrink-0",
                      e.status === "blocked" ? "bg-rouge/15 text-rouge" :
                      e.action.startsWith("mfa") ? "bg-cyan/15 text-cyan" :
                      e.action === "data-export" ? "bg-orange/15 text-orange" :
                      "bg-vert/15 text-vert",
                    )}>
                      <Icon className="w-4 h-4" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2">
                        <p className="text-sm">
                          <span className="font-semibold text-text-primary">{e.user === "—" ? "Tentative inconnue" : e.user}</span>
                          {" "}<span className="text-text-secondary">{actionLabels[e.action]}</span>
                          {e.status === "blocked" && <Badge tone="rouge" className="ml-2">Bloqué</Badge>}
                        </p>
                        <span className="text-[10px] text-text-muted whitespace-nowrap">{timeAgo(e.at)}</span>
                      </div>
                      <div className="mt-1.5 flex items-center gap-2 flex-wrap text-[11px] text-text-muted">
                        <span>{e.role}</span>
                        <span>·</span>
                        <span className="font-mono">{e.ip}</span>
                        <span>·</span>
                        <span>{e.device}</span>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="mt-4 pt-3 border-t border-white/5 text-[11px] text-text-muted leading-relaxed">
            Audit trail inaltérable. Stockage horodaté avec hash chaîné, exportable pour audit bailleur.
          </div>
        </GlassPanel>

        {/* Compliance */}
        <GlassPanel variant="strong" className="p-5">
          <div className="mb-4">
            <h2 className="text-lg font-semibold flex items-center gap-2">
              <Shield className="w-5 h-5 text-cyan" />
              Conformité
            </h2>
            <p className="text-xs text-text-muted mt-0.5">{compliantCount} conformes · {expiring} renouvellement</p>
          </div>

          <div className="space-y-3 max-h-[560px] overflow-y-auto pr-2 -mr-2">
            {compliance.map(c => (
              <div key={c.id} className={cn(
                "rounded-xl border p-3 transition",
                c.status === "expiring" ? "border-orange/30 bg-orange/5" :
                c.status === "in-progress" ? "border-cyan/25 bg-cyan/5" :
                "border-vert/20 bg-vert/3",
              )}>
                <div className="flex items-start justify-between gap-2 mb-1">
                  <p className="text-sm font-semibold">{c.label}</p>
                  {c.status === "compliant" && <CheckCircle2 className="w-4 h-4 text-vert shrink-0" />}
                  {c.status === "in-progress" && <Clock className="w-4 h-4 text-cyan shrink-0" />}
                  {c.status === "expiring" && <AlertTriangle className="w-4 h-4 text-orange shrink-0" />}
                </div>
                <p className="text-[11px] text-text-muted mb-2">{c.scope}</p>
                <p className="text-xs text-text-secondary leading-relaxed">{c.detail}</p>
                {c.validUntil && (
                  <p className="text-[10px] text-text-muted mt-2 font-mono">
                    Valide jusqu&apos;au {new Date(c.validUntil).toLocaleDateString("fr-FR", { day: "numeric", month: "short", year: "numeric" })}
                  </p>
                )}
              </div>
            ))}
          </div>
        </GlassPanel>
      </div>
    </div>
  );
}
