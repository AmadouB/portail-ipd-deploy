"use client";

import { GlassPanel } from "@/components/ui/glass-panel";
import { interdependencies } from "@/lib/data/kpis";
import { projects } from "@/lib/data/projects";
import { Network } from "lucide-react";
import { useMemo } from "react";

interface Node {
  id: string;
  name: string;
  pole: string;
  x: number;
  y: number;
}

const poleColors: Record<string, string> = {
  MADIBA: "#1B5FA6",
  "Grant Office": "#00D4FF",
  Maturation: "#9B7FBF",
  "Cabinet AG": "#003D7A",
};

export function InterdependenciesGraph() {
  const { nodes, links } = useMemo(() => {
    // Position nodes in a circle
    const codes = Array.from(new Set([
      ...interdependencies.map(l => l.source),
      ...interdependencies.map(l => l.target),
    ]));
    const nodes: Node[] = codes.map((code, i) => {
      const project = projects.find(p => p.code === code);
      const angle = (i / codes.length) * Math.PI * 2 - Math.PI / 2;
      return {
        id: code,
        name: project?.name.split("—")[0]?.trim() || code,
        pole: project?.pole || "Cabinet AG",
        x: 50 + 38 * Math.cos(angle),
        y: 50 + 38 * Math.sin(angle),
      };
    });
    const nodeMap = Object.fromEntries(nodes.map(n => [n.id, n]));
    const links = interdependencies.map(l => ({
      ...l,
      sourceNode: nodeMap[l.source],
      targetNode: nodeMap[l.target],
    }));
    return { nodes, links };
  }, []);

  return (
    <GlassPanel variant="strong" className="p-5">
      <div className="flex items-center justify-between mb-3">
        <div>
          <h2 className="text-lg font-semibold flex items-center gap-2">
            <Network className="w-5 h-5 text-cyan" />
            Cartographie des interdépendances
          </h2>
          <p className="text-xs text-text-muted mt-0.5">Liens entre projets — ressources, équipes, infrastructure</p>
        </div>
      </div>

      <div className="relative aspect-square max-w-md mx-auto">
        <svg viewBox="0 0 100 100" className="w-full h-full">
          {/* Background concentric rings */}
          <circle cx="50" cy="50" r="38" fill="none" stroke="rgba(0,212,255,0.08)" strokeWidth="0.2" />
          <circle cx="50" cy="50" r="25" fill="none" stroke="rgba(0,212,255,0.05)" strokeWidth="0.2" />
          <circle cx="50" cy="50" r="12" fill="none" stroke="rgba(0,212,255,0.04)" strokeWidth="0.2" />

          {/* Links */}
          {links.map((link, i) => (
            <line
              key={i}
              x1={link.sourceNode.x}
              y1={link.sourceNode.y}
              x2={link.targetNode.x}
              y2={link.targetNode.y}
              stroke="#00D4FF"
              strokeWidth={link.strength * 0.4}
              strokeOpacity={0.4 + link.strength * 0.4}
              strokeLinecap="round"
            />
          ))}

          {/* Nodes */}
          {nodes.map(node => (
            <g key={node.id}>
              <circle
                cx={node.x}
                cy={node.y}
                r="3"
                fill={poleColors[node.pole]}
                stroke="#00D4FF"
                strokeWidth="0.4"
              />
              <circle
                cx={node.x}
                cy={node.y}
                r="5"
                fill="none"
                stroke={poleColors[node.pole]}
                strokeOpacity="0.3"
                strokeWidth="0.3"
              />
            </g>
          ))}

          {/* Labels */}
          {nodes.map(node => {
            const offsetX = node.x > 50 ? 4 : -4;
            const anchor = node.x > 50 ? "start" : "end";
            return (
              <text
                key={`l-${node.id}`}
                x={node.x + offsetX}
                y={node.y + 1}
                fontSize="2.4"
                fill="#A8B8CC"
                textAnchor={anchor}
                fontWeight="500"
              >
                {node.id}
              </text>
            );
          })}
        </svg>
      </div>

      <div className="flex items-center justify-center gap-4 mt-3 flex-wrap text-xs">
        {Object.entries(poleColors).map(([pole, color]) => (
          <div key={pole} className="flex items-center gap-1.5 text-text-muted">
            <span className="w-2.5 h-2.5 rounded-full" style={{ background: color }} />
            {pole}
          </div>
        ))}
      </div>
    </GlassPanel>
  );
}
