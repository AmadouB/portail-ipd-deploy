"use client";

import { useState, useMemo, useEffect } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { GlassPanel } from "@/components/ui/glass-panel";
import { projects } from "@/lib/data/projects";
import { Badge } from "@/components/ui/badge";
import { ChevronRight, Briefcase, Search, X } from "lucide-react";
import { formatCurrency, cn } from "@/lib/utils";

const statusTone = {
  "on-track": "vert",
  "at-risk": "orange",
  delayed: "rouge",
  completed: "cyan",
} as const;

const statusLabel = {
  "on-track": "En cours",
  "at-risk": "À surveiller",
  delayed: "Retard",
  completed: "Terminé",
};

export function PortfolioTable({ initialQuery = "" }: { initialQuery?: string }) {
  const params = useSearchParams();
  const [query, setQuery] = useState(initialQuery);
  const [poleFilter, setPoleFilter] = useState<string>("all");

  // Sync with global URL search param (when navigating from header search)
  useEffect(() => {
    const urlQ = params?.get("q") ?? "";
    if (urlQ !== query) setQuery(urlQ);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [params]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return projects.filter(p => {
      if (poleFilter !== "all" && p.pole !== poleFilter) return false;
      if (!q) return true;
      return (
        p.name.toLowerCase().includes(q) ||
        p.code.toLowerCase().includes(q) ||
        p.pm.toLowerCase().includes(q) ||
        p.tags.some(t => t.toLowerCase().includes(q)) ||
        (p.bailleur?.toLowerCase().includes(q) ?? false)
      );
    });
  }, [query, poleFilter]);

  return (
    <GlassPanel variant="strong" className="p-5">
      <div className="flex items-center justify-between mb-4 gap-4 flex-wrap">
        <div>
          <h2 className="text-lg font-semibold flex items-center gap-2">
            <Briefcase className="w-5 h-5 text-bleu-ipd" />
            Portefeuille consolidé
          </h2>
          <p className="text-xs text-text-muted mt-0.5">
            {filtered.length} projet{filtered.length > 1 ? "s" : ""} {query || poleFilter !== "all" ? "filtrés" : "actifs"} · tous pôles confondus
          </p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-white/5 border border-white/10 w-64">
            <Search className="w-4 h-4 text-text-muted" />
            <input
              type="text"
              value={query}
              onChange={e => setQuery(e.target.value)}
              placeholder="Filtrer projet, PM, code, bailleur…"
              className="bg-transparent flex-1 text-sm outline-none placeholder:text-text-muted"
            />
            {query && (
              <button onClick={() => setQuery("")} className="text-text-muted hover:text-text-primary">
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
          <div className="flex items-center gap-1 p-1 rounded-xl bg-white/5 border border-white/10">
            {(["all", "MADIBA", "Grant Office"] as const).map(p => (
              <button
                key={p}
                onClick={() => setPoleFilter(p)}
                className={cn(
                  "px-2.5 py-1 rounded-lg text-xs font-medium transition",
                  poleFilter === p ? "bg-bleu-ipd/30 text-bleu-clair" : "text-text-muted hover:text-text-primary"
                )}
              >
                {p === "all" ? "Tous" : p}
              </button>
            ))}
          </div>
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="text-center py-12 text-sm text-text-muted">
          Aucun projet ne correspond à votre recherche.
        </div>
      ) : (
        <div className="overflow-x-auto -mx-5">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-[10px] uppercase tracking-wider text-text-muted border-b border-white/5">
                <th className="px-5 py-2.5 font-medium">Projet</th>
                <th className="px-3 py-2.5 font-medium">Pôle</th>
                <th className="px-3 py-2.5 font-medium">PM</th>
                <th className="px-3 py-2.5 font-medium">Avancement</th>
                <th className="px-3 py-2.5 font-medium text-right">Budget</th>
                <th className="px-3 py-2.5 font-medium">Statut</th>
                <th className="px-5 py-2.5 font-medium text-right"></th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(p => (
                <tr key={p.id} className="border-b border-white/5 hover:bg-white/[0.02] transition group">
                  <td className="px-5 py-3">
                    <Link href={`/projects/${p.id}`} className="block">
                      <p className="font-medium text-text-primary group-hover:text-bleu-clair transition truncate max-w-xs">{p.name}</p>
                      <p className="text-xs text-text-muted">{p.code}</p>
                    </Link>
                  </td>
                  <td className="px-3 py-3">
                    <Badge tone={p.pole === "MADIBA" ? "cyan" : p.pole === "Grant Office" ? "vert" : "violet"}>
                      {p.pole}
                    </Badge>
                  </td>
                  <td className="px-3 py-3 text-text-secondary text-xs">{p.pm}</td>
                  <td className="px-3 py-3 min-w-[140px]">
                    <div className="flex items-center gap-2">
                      <div className="flex-1 h-1.5 rounded-full bg-white/5 overflow-hidden">
                        <div
                          className="h-full rounded-full bg-gradient-to-r from-bleu-ipd to-cyan transition-all"
                          style={{ width: `${p.progress}%` }}
                        />
                      </div>
                      <span className="text-xs font-medium tabular-nums w-9 text-right">{p.progress} %</span>
                    </div>
                  </td>
                  <td className="px-3 py-3 text-right tabular-nums text-xs text-text-secondary">
                    {formatCurrency(p.budget, p.currency)}
                  </td>
                  <td className="px-3 py-3">
                    <Badge tone={statusTone[p.status]}>{statusLabel[p.status]}</Badge>
                  </td>
                  <td className="px-5 py-3 text-right">
                    <Link href={`/projects/${p.id}`} className="text-text-muted group-hover:text-cyan transition inline-block">
                      <ChevronRight className="w-4 h-4" />
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </GlassPanel>
  );
}
