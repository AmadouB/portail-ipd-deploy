"use client";

import { GlassPanel } from "@/components/ui/glass-panel";
import { monthlyTrend } from "@/lib/data/kpis";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend } from "recharts";
import { TrendingUp } from "lucide-react";

export function PortfolioTrend() {
  return (
    <GlassPanel variant="strong" className="p-5">
      <div className="flex items-center justify-between mb-3">
        <div>
          <h2 className="text-lg font-semibold flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-cyan" />
            Évolution portefeuille — 6 mois
          </h2>
          <p className="text-xs text-text-muted mt-0.5">Santé, décaissement, jalons en cours</p>
        </div>
      </div>
      <div className="h-72">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={monthlyTrend} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
            <XAxis dataKey="mois" stroke="#6B7A90" fontSize={11} />
            <YAxis stroke="#6B7A90" fontSize={11} />
            <Tooltip
              contentStyle={{
                background: "rgba(10,22,40,0.95)",
                border: "1px solid rgba(0,212,255,0.3)",
                borderRadius: "12px",
                fontSize: "12px",
              }}
              labelStyle={{ color: "#00D4FF" }}
            />
            <Legend iconType="circle" wrapperStyle={{ fontSize: "12px", paddingTop: "10px" }} />
            <Line type="monotone" dataKey="santé" stroke="#5DBB63" strokeWidth={2.5} dot={{ r: 3 }} activeDot={{ r: 6 }} />
            <Line type="monotone" dataKey="décaissement" stroke="#00D4FF" strokeWidth={2.5} dot={{ r: 3 }} activeDot={{ r: 6 }} />
            <Line type="monotone" dataKey="jalons" stroke="#F39200" strokeWidth={2.5} dot={{ r: 3 }} activeDot={{ r: 6 }} />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </GlassPanel>
  );
}
