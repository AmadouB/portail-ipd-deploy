"use client";

import Link from "next/link";
import { GlassPanel } from "@/components/ui/glass-panel";
import { alerts } from "@/lib/data/alerts";
import { AlertTriangle, Sparkles, CheckCircle2, Info, Brain, Activity, ArrowUpRight } from "lucide-react";
import { cn } from "@/lib/utils";

const iconBySource: Record<string, typeof AlertTriangle> = {
  "AI Predict — modèle jalons v2": Brain,
  "AI Predict — charge équipes": Brain,
  "M&E Engine": Activity,
  "Sentiment Analysis": Sparkles,
  "Project Management": CheckCircle2,
  "Grant Office Engine": Info,
};

const styleBySeverity = {
  high: "border-rouge/40 bg-rouge/5",
  medium: "border-orange/40 bg-orange/5",
  low: "border-cyan/30 bg-cyan/5",
} as const;

const colorBySeverity = {
  high: "text-rouge",
  medium: "text-orange",
  low: "text-cyan",
} as const;

const styleByType = {
  predictive: "text-cyan",
  anomaly: "text-orange",
  info: "text-text-secondary",
  success: "text-vert",
} as const;

function timeAgo(iso: string) {
  const diff = Date.now() - new Date(iso).getTime();
  const h = Math.round(diff / (1000 * 60 * 60));
  if (h < 1) return "à l'instant";
  if (h < 24) return `il y a ${h} h`;
  const d = Math.round(h / 24);
  return `il y a ${d} j`;
}

export function AlertsPanel() {
  return (
    <GlassPanel variant="strong" className="p-5">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h2 className="text-lg font-semibold flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-cyan" />
            Alertes IA prédictive
          </h2>
          <p className="text-xs text-text-muted mt-0.5">Détection de signaux faibles avant impact KPI</p>
        </div>
        <span className="text-xs px-2 py-1 rounded-full bg-cyan/10 border border-cyan/30 text-cyan font-medium">
          {alerts.length} signaux
        </span>
      </div>

      <div className="space-y-2.5 max-h-[460px] overflow-y-auto pr-2 -mr-2">
        {alerts.map(alert => {
          const Icon = iconBySource[alert.source] || AlertTriangle;
          const inner = (
            <div className="flex items-start gap-3">
              <div className={cn("mt-0.5 p-1.5 rounded-lg bg-white/5", colorBySeverity[alert.severity])}>
                <Icon className="w-4 h-4" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between gap-2">
                  <p className="text-sm font-semibold text-text-primary group-hover:text-cyan transition">{alert.title}</p>
                  <span className="text-[10px] text-text-muted whitespace-nowrap">{timeAgo(alert.detectedAt)}</span>
                </div>
                <p className="text-xs text-text-secondary mt-1 leading-relaxed">{alert.description}</p>
                <div className="flex items-center gap-3 mt-2 text-[11px]">
                  <span className={cn("font-medium", styleByType[alert.type])}>
                    {alert.source}
                  </span>
                  {alert.projectId && (
                    <span className="text-text-muted flex items-center gap-1">
                      · projet {alert.projectId.toUpperCase()}
                      <ArrowUpRight className="w-3 h-3 opacity-0 group-hover:opacity-100 transition" />
                    </span>
                  )}
                </div>
              </div>
            </div>
          );
          const baseClass = cn(
            "block rounded-xl border p-3 transition hover:bg-glass-hover group",
            styleBySeverity[alert.severity],
            alert.projectId && "cursor-pointer hover:border-cyan/50",
          );
          return alert.projectId ? (
            <Link key={alert.id} href={`/projects/${alert.projectId}`} className={baseClass}>
              {inner}
            </Link>
          ) : (
            <div key={alert.id} className={baseClass}>
              {inner}
            </div>
          );
        })}
      </div>
    </GlassPanel>
  );
}
