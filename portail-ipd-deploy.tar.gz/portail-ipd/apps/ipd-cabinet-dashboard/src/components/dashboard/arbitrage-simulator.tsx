"use client";

import { useState, useMemo } from "react";
import { GlassPanel } from "@/components/ui/glass-panel";
import { Sliders, Play } from "lucide-react";
import { cn, formatCurrency } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";

const baseProjects = [
  { id: "p-001", name: "Vaccinopole rougeole", baseline: 4_200_000, baselineDelai: 0, baseSante: 64 },
  { id: "p-005", name: "Vaccin fièvre jaune", baseline: 5_400_000, baselineDelai: 0, baseSante: 71 },
  { id: "p-007", name: "Plateforme ARNm", baseline: 8_900_000, baselineDelai: 0, baseSante: 35 },
  { id: "p-006", name: "Essai paludisme III", baseline: 4_950_000, baselineDelai: 0, baseSante: 44 },
];

export function ArbitrageSimulator() {
  const [allocations, setAllocations] = useState<Record<string, number>>({
    "p-001": 0,
    "p-005": 0,
    "p-007": 0,
    "p-006": 0,
  });

  const [delays, setDelays] = useState<Record<string, number>>({
    "p-001": 0,
    "p-005": 0,
    "p-007": 0,
    "p-006": 0,
  });

  const [running, setRunning] = useState(false);

  const projection = useMemo(() => {
    return baseProjects.map(p => {
      const allocDelta = allocations[p.id] || 0;
      const delayDelta = delays[p.id] || 0;
      // Mock model: +10% budget = +6 points santé ; +1 mois delai = -3 points santé
      const santeProjete = Math.max(10, Math.min(95,
        p.baseSante + allocDelta * 0.6 - delayDelta * 3
      ));
      const budgetProjete = p.baseline * (1 + allocDelta / 100);
      return {
        ...p,
        santeProjete: Math.round(santeProjete),
        budgetProjete,
        delta: santeProjete - p.baseSante,
      };
    });
  }, [allocations, delays]);

  const totalBaseline = baseProjects.reduce((s, p) => s + p.baseline, 0);
  const totalProjected = projection.reduce((s, p) => s + p.budgetProjete, 0);
  const totalDelta = totalProjected - totalBaseline;
  const portfolioSanteAvg = Math.round(projection.reduce((s, p) => s + p.santeProjete, 0) / projection.length);
  const portfolioSanteBase = Math.round(baseProjects.reduce((s, p) => s + p.baseSante, 0) / baseProjects.length);

  const reset = () => {
    setAllocations({ "p-001": 0, "p-005": 0, "p-007": 0, "p-006": 0 });
    setDelays({ "p-001": 0, "p-005": 0, "p-007": 0, "p-006": 0 });
  };

  return (
    <GlassPanel variant="strong" className="p-5">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h2 className="text-lg font-semibold flex items-center gap-2">
            <Sliders className="w-5 h-5 text-cyan" />
            Simulation d&apos;arbitrage — what if
          </h2>
          <p className="text-xs text-text-muted mt-0.5">
            Projeter l&apos;impact d&apos;une réallocation budgétaire ou d&apos;un report de jalon
          </p>
        </div>
        <button
          onClick={() => { setRunning(true); setTimeout(() => setRunning(false), 1200); }}
          className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-cyan text-bleu-ipd font-medium text-sm hover:bg-cyan-soft transition"
        >
          <Play className="w-4 h-4" />
          Simuler
        </button>
      </div>

      {/* Summary band */}
      <div className="grid grid-cols-3 gap-3 mb-4 p-3 rounded-xl bg-white/5 border border-cyan/10">
        <div>
          <p className="text-[10px] uppercase tracking-wider text-text-muted">Budget total</p>
          <p className="text-lg font-bold text-text-primary">{formatCurrency(totalProjected)}</p>
          {totalDelta !== 0 && (
            <p className={cn("text-xs font-medium", totalDelta > 0 ? "text-orange" : "text-vert")}>
              {totalDelta > 0 ? "+" : ""}{formatCurrency(totalDelta)}
            </p>
          )}
        </div>
        <div>
          <p className="text-[10px] uppercase tracking-wider text-text-muted">Santé moyenne</p>
          <p className={cn("text-lg font-bold", portfolioSanteAvg >= portfolioSanteBase ? "text-vert" : "text-orange")}>
            {portfolioSanteAvg} / 100
          </p>
          <p className="text-xs text-text-muted">base : {portfolioSanteBase}</p>
        </div>
        <div>
          <p className="text-[10px] uppercase tracking-wider text-text-muted">Statut simulation</p>
          {running ? (
            <p className="text-lg font-bold text-cyan flex items-center gap-2">
              <span className="shimmer inline-block w-3 h-3 rounded-full bg-cyan/40" />
              Calcul…
            </p>
          ) : (
            <p className="text-lg font-bold text-vert">Actualisé</p>
          )}
          <p className="text-xs text-text-muted">modèle IPD-arb v1.2</p>
        </div>
      </div>

      <div className="space-y-3">
        {projection.map(p => (
          <div key={p.id} className="p-3 rounded-xl bg-white/3 border border-white/5 hover:border-cyan/20 transition">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2 min-w-0">
                <span className="font-medium text-sm truncate">{p.name}</span>
                <Badge tone={p.delta > 5 ? "vert" : p.delta < -5 ? "rouge" : "neutre"}>
                  santé {p.santeProjete}{p.delta !== 0 && ` (${p.delta > 0 ? "+" : ""}${p.delta})`}
                </Badge>
              </div>
              <span className="text-xs text-text-muted whitespace-nowrap">
                {formatCurrency(p.budgetProjete)}
              </span>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <label className="block">
                <div className="flex justify-between text-[11px] text-text-muted mb-1">
                  <span>Réallocation budget</span>
                  <span className={cn(
                    allocations[p.id] > 0 ? "text-vert" : allocations[p.id] < 0 ? "text-orange" : "text-text-muted",
                  )}>
                    {allocations[p.id] > 0 ? "+" : ""}{allocations[p.id]} %
                  </span>
                </div>
                <input
                  type="range"
                  min={-30}
                  max={30}
                  step={5}
                  value={allocations[p.id]}
                  onChange={(e) => setAllocations({ ...allocations, [p.id]: Number(e.target.value) })}
                  className="w-full accent-cyan"
                />
              </label>
              <label className="block">
                <div className="flex justify-between text-[11px] text-text-muted mb-1">
                  <span>Report de jalon</span>
                  <span className={cn(delays[p.id] > 0 ? "text-orange" : "text-text-muted")}>
                    {delays[p.id] > 0 ? "+" : ""}{delays[p.id]} mois
                  </span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={6}
                  step={1}
                  value={delays[p.id]}
                  onChange={(e) => setDelays({ ...delays, [p.id]: Number(e.target.value) })}
                  className="w-full accent-orange"
                />
              </label>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-4 flex items-center justify-between">
        <p className="text-xs text-text-muted">
          ℹ Modèle d&apos;impact heuristique : +10 % budget → +6 santé · +1 mois retard → −3 santé.
        </p>
        <button onClick={reset} className="text-xs text-cyan hover:underline">Réinitialiser</button>
      </div>
    </GlassPanel>
  );
}
