import { cn } from "@/lib/utils";
import type { ReactNode } from "react";

const tones = {
  cyan: "bg-cyan/10 text-cyan border-cyan/30",
  vert: "bg-vert/10 text-vert border-vert/30",
  orange: "bg-orange/10 text-orange border-orange/30",
  rouge: "bg-rouge/10 text-rouge border-rouge/30",
  violet: "bg-violet/15 text-violet-pale border-violet/40",
  neutre: "bg-white/5 text-text-secondary border-white/10",
} as const;

interface BadgeProps {
  tone?: keyof typeof tones;
  children: ReactNode;
  className?: string;
}

export function Badge({ tone = "neutre", children, className }: BadgeProps) {
  return (
    <span className={cn(
      "inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-xs font-medium border",
      tones[tone],
      className,
    )}>
      {children}
    </span>
  );
}
