import { cn } from "@/lib/utils";
import type { ComponentProps, ReactNode } from "react";

interface GlassPanelProps extends ComponentProps<"div"> {
  variant?: "default" | "strong";
  children: ReactNode;
}

export function GlassPanel({ variant = "default", className, children, ...props }: GlassPanelProps) {
  return (
    <div
      className={cn(
        variant === "strong" ? "glass-strong" : "glass",
        "rounded-2xl",
        className,
      )}
      {...props}
    >
      {children}
    </div>
  );
}
