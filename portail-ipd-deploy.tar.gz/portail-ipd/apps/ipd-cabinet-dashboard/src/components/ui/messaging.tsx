"use client";

import { useState, FormEvent } from "react";
import { GlassPanel } from "./glass-panel";
import { MessageSquare, Send } from "lucide-react";
import { cn } from "@/lib/utils";

interface Message {
  id: string;
  author: string;
  authorTone: "primary" | "cabinet" | "engine" | "user";
  content: string;
  timeAgo: string;
}

interface MessagingProps {
  title?: string;
  initial: Message[];
}

const toneStyle: Record<Message["authorTone"], string> = {
  primary: "bg-white/3 border-white/5 text-cyan",
  cabinet: "bg-cyan/5 border-cyan/20 text-cyan",
  engine: "bg-vert/5 border-vert/20 text-vert",
  user: "bg-bleu-ipd/15 border-bleu-ipd/35 text-bleu-clair ml-8",
};

const authorColor: Record<Message["authorTone"], string> = {
  primary: "text-cyan",
  cabinet: "text-cyan",
  engine: "text-vert",
  user: "text-bleu-clair",
};

export function Messaging({ title = "Messagerie sécurisée — fil projet", initial }: MessagingProps) {
  const [messages, setMessages] = useState<Message[]>(initial);
  const [draft, setDraft] = useState("");

  const send = (e: FormEvent) => {
    e.preventDefault();
    const trimmed = draft.trim();
    if (!trimmed) return;
    setMessages(prev => [
      ...prev,
      {
        id: `m-${Date.now()}`,
        author: "Vous (Cabinet AG)",
        authorTone: "user",
        content: trimmed,
        timeAgo: "à l'instant",
      },
    ]);
    setDraft("");
  };

  return (
    <GlassPanel variant="strong" className="p-5">
      <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
        <MessageSquare className="w-4 h-4 text-cyan" />
        {title}
      </h3>
      <div className="space-y-3 text-sm max-h-[320px] overflow-y-auto pr-1 -mr-1">
        {messages.map(m => (
          <div key={m.id} className={cn("p-3 rounded-xl border", toneStyle[m.authorTone])}>
            <div className="flex items-center justify-between mb-1">
              <span className={cn("font-medium", authorColor[m.authorTone])}>{m.author}</span>
              <span className="text-xs text-text-muted">{m.timeAgo}</span>
            </div>
            <p className="text-text-secondary leading-relaxed">{m.content}</p>
          </div>
        ))}
      </div>
      <form onSubmit={send} className="flex items-center gap-2 pt-3 mt-3 border-t border-white/5">
        <input
          type="text"
          value={draft}
          onChange={e => setDraft(e.target.value)}
          placeholder="Écrire un message au fil…"
          className="flex-1 bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-sm outline-none focus:border-cyan/50 transition"
        />
        <button
          type="submit"
          disabled={!draft.trim()}
          className="px-4 py-2 rounded-xl bg-cyan text-bleu-ipd font-medium text-sm hover:bg-cyan-soft transition disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-1.5"
        >
          <Send className="w-3.5 h-3.5" />
          Envoyer
        </button>
      </form>
    </GlassPanel>
  );
}
