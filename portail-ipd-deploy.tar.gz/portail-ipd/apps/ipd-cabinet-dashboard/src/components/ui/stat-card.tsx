import { GlassPanel } from "./glass-panel";
import { TrendingUp, TrendingDown, Minus } from "lucide-react";
import { cn } from "@/lib/utils";

const colorMap = {
  cyan: { text: "text-cyan", bg: "from-cyan/20 to-cyan/0", glow: "shadow-cyan/20" },
  vert: { text: "text-vert", bg: "from-vert/20 to-vert/0", glow: "shadow-vert/20" },
  orange: { text: "text-orange", bg: "from-orange/20 to-orange/0", glow: "shadow-orange/20" },
  violet: { text: "text-violet-pale", bg: "from-violet/20 to-violet/0", glow: "shadow-violet/20" },
  rouge: { text: "text-rouge", bg: "from-rouge/20 to-rouge/0", glow: "shadow-rouge/20" },
} as const;

interface StatCardProps {
  label: string;
  value: string;
  delta: number;
  deltaLabel: string;
  trend: number[];
  hint: string;
  color: keyof typeof colorMap;
}

export function StatCard({ label, value, delta, deltaLabel, trend, hint, color }: StatCardProps) {
  const c = colorMap[color];
  const TrendIcon = delta > 0 ? TrendingUp : delta < 0 ? TrendingDown : Minus;
  const max = Math.max(...trend);
  const min = Math.min(...trend);
  const range = max - min || 1;
  const points = trend.map((v, i) => {
    const x = (i / (trend.length - 1)) * 100;
    const y = 100 - ((v - min) / range) * 100;
    return `${x},${y}`;
  }).join(" ");

  return (
    <GlassPanel variant="strong" className="relative overflow-hidden p-5 group hover:bg-glass-hover transition">
      <div className={cn("absolute inset-0 bg-gradient-to-br opacity-40 pointer-events-none", c.bg)} />
      <div className="relative flex flex-col gap-3">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-xs uppercase tracking-wider text-text-muted">{label}</p>
            <p className={cn("text-4xl font-bold mt-1", c.text)}>{value}</p>
          </div>
          <div className={cn("flex items-center gap-1 text-sm font-medium", c.text)}>
            <TrendIcon className="w-4 h-4" />
            <span>{delta > 0 ? "+" : ""}{delta}</span>
          </div>
        </div>
        <svg viewBox="0 0 100 100" preserveAspectRatio="none" className="h-10 w-full">
          <polyline
            points={points}
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className={c.text}
            vectorEffect="non-scaling-stroke"
          />
        </svg>
        <div className="flex items-center justify-between text-[11px] text-text-muted">
          <span>{deltaLabel}</span>
          <span title={hint} className="opacity-70">{hint.length > 30 ? hint.slice(0, 30) + "…" : hint}</span>
        </div>
      </div>
    </GlassPanel>
  );
}
