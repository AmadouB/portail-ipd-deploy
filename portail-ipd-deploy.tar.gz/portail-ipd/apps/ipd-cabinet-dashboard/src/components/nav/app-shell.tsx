"use client";

import { usePathname } from "next/navigation";
import { Sidebar } from "./sidebar";
import type { AuthUser } from "@/lib/auth";

interface AppShellProps {
  children: React.ReactNode;
  user: AuthUser | null;
}

export function AppShell({ children, user }: AppShellProps) {
  const pathname = usePathname();
  const isAuthRoute = pathname === "/login";

  if (isAuthRoute || !user) {
    return <>{children}</>;
  }

  return (
    <>
      <Sidebar user={user} />
      <main className="ml-72 min-h-screen">
        <div className="mx-auto max-w-[1600px] px-8 py-8">
          {children}
        </div>
      </main>
    </>
  );
}
