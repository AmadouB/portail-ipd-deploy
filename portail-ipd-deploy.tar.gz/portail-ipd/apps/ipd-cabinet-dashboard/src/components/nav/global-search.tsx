"use client";

import { useState, useEffect, FormEvent } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { Search, X } from "lucide-react";

export function GlobalSearch() {
  const router = useRouter();
  const params = useSearchParams();
  const [query, setQuery] = useState("");

  // Seed from URL on /dashboard
  useEffect(() => {
    setQuery(params?.get("q") ?? "");
  }, [params]);

  const submit = (e: FormEvent) => {
    e.preventDefault();
    const q = query.trim();
    if (q) {
      router.push(`/dashboard?q=${encodeURIComponent(q)}`);
    } else {
      router.push("/dashboard");
    }
  };

  // ⌘K / Ctrl+K to focus the input
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        const input = document.getElementById("global-search-input") as HTMLInputElement | null;
        input?.focus();
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, []);

  return (
    <form
      onSubmit={submit}
      className="hidden md:flex items-center gap-2 px-3 py-2 rounded-xl glass border border-white/10 w-72 focus-within:border-cyan/40 transition"
    >
      <Search className="w-4 h-4 text-text-muted" />
      <input
        id="global-search-input"
        type="text"
        value={query}
        onChange={e => setQuery(e.target.value)}
        placeholder="Rechercher projet, jalon, grant…"
        className="bg-transparent flex-1 text-sm outline-none placeholder:text-text-muted"
      />
      {query ? (
        <button
          type="button"
          onClick={() => { setQuery(""); router.push("/dashboard"); }}
          className="text-text-muted hover:text-text-primary transition"
          title="Effacer"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      ) : (
        <kbd className="text-[10px] text-text-muted px-1.5 py-0.5 rounded border border-white/10">⌘K</kbd>
      )}
    </form>
  );
}
