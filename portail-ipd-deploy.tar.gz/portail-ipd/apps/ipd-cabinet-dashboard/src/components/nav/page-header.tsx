import { ReactNode } from "react";
import { GlobalSearch } from "./global-search";

interface PageHeaderProps {
  title: string;
  subtitle?: string;
  badge?: string;
  actions?: ReactNode;
}

export function PageHeader({ title, subtitle, badge, actions }: PageHeaderProps) {
  const date = new Date().toLocaleDateString("fr-FR", { weekday: "long", day: "numeric", month: "long", year: "numeric" });
  return (
    <header className="flex flex-col gap-4 mb-6">
      <div className="flex items-start justify-between gap-6 flex-wrap">
        <div className="space-y-1">
          {badge && (
            <div className="flex items-center gap-2 text-xs">
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-bleu-ipd/15 border border-bleu-ipd/40 text-bleu-clair font-medium uppercase tracking-wider">
                <span className="w-1.5 h-1.5 rounded-full bg-bleu-ipd live-dot" />
                {badge}
              </span>
              <span className="text-text-muted capitalize">{date}</span>
            </div>
          )}
          <h1 className="text-3xl font-bold tracking-tight text-glow">{title}</h1>
          {subtitle && <p className="text-text-secondary max-w-2xl">{subtitle}</p>}
        </div>
        <div className="flex items-center gap-3">
          <GlobalSearch />
          {actions}
        </div>
      </div>
    </header>
  );
}
