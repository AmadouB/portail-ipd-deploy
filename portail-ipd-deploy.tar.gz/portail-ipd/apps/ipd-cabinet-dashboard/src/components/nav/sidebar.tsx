"use client";

import Link from "next/link";
import Image from "next/image";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";
import { LayoutDashboard, Sprout, Banknote, Factory, Activity, Bell, Settings, Shield, Newspaper, Network, LogOut } from "lucide-react";
import type { AuthUser } from "@/lib/auth";

const nav = [
  { href: "/dashboard", label: "Hub Stratégique", icon: LayoutDashboard, sub: "Cabinet AG" },
  { href: "/architecture", label: "Architecture", icon: Network, sub: "Système institutionnel" },
  { href: "/veille", label: "Veille IPD", icon: Newspaper, sub: "Brief 08:00 UTC" },
  { href: "/maturation", label: "Cellule de Maturation", icon: Sprout, sub: "Pipeline projets" },
  { href: "/grants", label: "Grant Office", icon: Banknote, sub: "Financements" },
  { href: "/madiba", label: "MADIBA", icon: Factory, sub: "Production & R&D" },
];

export function Sidebar({ user }: { user: AuthUser }) {
  const pathname = usePathname();

  return (
    <aside className="fixed inset-y-0 left-0 z-30 w-72 glass-strong border-r border-bleu-ipd/20 flex flex-col">
      {/* Logo IPD officiel */}
      <div className="px-5 pt-5 pb-4 border-b border-bleu-ipd/15">
        <Link href="/dashboard" className="block group" aria-label="Institut Pasteur de Dakar — Accueil">
          <div className="rounded-xl bg-white/95 px-3 py-2.5 shadow-lg group-hover:bg-white transition-colors">
            <Image
              src="/logo-ipd.png"
              alt="Institut Pasteur de Dakar"
              width={240}
              height={100}
              className="w-full h-auto object-contain"
              priority
            />
          </div>
          <div className="mt-3 flex items-center gap-2 px-1">
            <span className="text-[10px] uppercase tracking-[0.18em] text-bleu-clair font-semibold">Plateforme PMO</span>
            <span className="flex-1 h-px bg-gradient-to-r from-bleu-ipd/40 to-transparent" />
            <span className="text-[10px] text-text-muted">v1.0</span>
          </div>
        </Link>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
        <p className="px-3 py-2 text-[10px] uppercase tracking-widest text-text-muted">Modules</p>
        {nav.map(item => {
          const active = pathname.startsWith(item.href);
          const Icon = item.icon;
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "flex items-start gap-3 px-3 py-2.5 rounded-xl text-sm transition-all relative group",
                active
                  ? "bg-gradient-to-r from-bleu-ipd/20 via-cyan/10 to-transparent border-l-2 border-bleu-ipd text-text-primary"
                  : "hover:bg-white/5 text-text-secondary border-l-2 border-transparent",
              )}
            >
              <Icon className={cn("w-5 h-5 mt-0.5 shrink-0", active ? "text-bleu-ipd" : "text-text-muted group-hover:text-bleu-ipd/80")} />
              <div className="flex-1 min-w-0">
                <p className={cn("font-medium", active && "text-glow")}>{item.label}</p>
                <p className="text-[11px] text-text-muted">{item.sub}</p>
              </div>
              {active && <div className="absolute right-3 top-1/2 -translate-y-1/2 w-1.5 h-1.5 rounded-full bg-bleu-ipd live-dot" />}
            </Link>
          );
        })}

        <p className="px-3 pt-6 pb-2 text-[10px] uppercase tracking-widest text-text-muted">Système</p>
        {(() => {
          const sysItems = [
            { href: "/dashboard#alerts", label: "Alertes", icon: Bell, badge: "3" },
            { href: "/me", label: "M\u0026E temps réel", icon: Activity },
            { href: "/securite", label: "Sécurité", icon: Shield },
          ] as Array<{ href: string; label: string; icon: typeof Bell; badge?: string }>;
          return sysItems.map(item => {
            const sysActive = pathname === item.href.split("#")[0];
            const Icon = item.icon;
            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm transition",
                  sysActive
                    ? "bg-gradient-to-r from-bleu-ipd/15 to-transparent text-text-primary"
                    : "text-text-secondary hover:bg-white/5",
                )}
              >
                <Icon className={cn("w-5 h-5", sysActive ? "text-bleu-ipd" : "text-text-muted")} />
                <span>{item.label}</span>
                {item.badge && (
                  <span className="ml-auto text-xs px-2 py-0.5 rounded-full bg-rouge/15 text-rouge font-medium">{item.badge}</span>
                )}
              </Link>
            );
          });
        })()}
        <button
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm text-text-muted/60 cursor-not-allowed"
          disabled
          title="Disponible prochainement"
        >
          <Settings className="w-5 h-5 text-text-muted/60" />
          <span>Paramètres</span>
          <span className="ml-auto text-[10px] uppercase tracking-wider text-text-muted/60">à venir</span>
        </button>
      </nav>

      {/* User */}
      <div className="px-4 py-4 border-t border-bleu-ipd/15">
        <div className="flex items-center gap-3 px-2">
          <div className="w-9 h-9 rounded-full bg-gradient-to-br from-bleu-ipd to-cyan flex items-center justify-center text-white font-semibold text-sm shadow-md shrink-0">
            {user.initials}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium truncate">{user.name}</p>
            <p className="text-[11px] text-text-muted truncate">{user.role} · MFA actif</p>
          </div>
          <form action="/api/auth/logout" method="post" className="shrink-0">
            <button
              type="submit"
              title="Se déconnecter"
              className="p-1.5 rounded-lg text-text-muted hover:text-rouge hover:bg-rouge/10 transition"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>
    </aside>
  );
}
