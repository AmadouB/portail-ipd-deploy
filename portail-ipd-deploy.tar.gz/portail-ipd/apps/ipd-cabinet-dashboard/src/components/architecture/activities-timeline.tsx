"use client";

import { useState } from "react";
import { GlassPanel } from "@/components/ui/glass-panel";
import { Badge } from "@/components/ui/badge";
import { activities, entities, type ActivityType } from "@/lib/data/architecture";
import { CheckCircle2, Clock, Calendar, Presentation, ListChecks, ScrollText, Flag, GraduationCap } from "lucide-react";
import { cn } from "@/lib/utils";

const typeIcon: Record<ActivityType, typeof Presentation> = {
  presentation: Presentation,
  priorisation: ListChecks,
  decision: ScrollText,
  jalon: Flag,
  formation: GraduationCap,
};

const typeLabel: Record<ActivityType, string> = {
  presentation: "Présentation",
  priorisation: "Priorisation",
  decision: "Décision",
  jalon: "Jalon",
  formation: "Formation",
};

const typeColor: Record<ActivityType, string> = {
  presentation: "bleu-clair",
  priorisation: "orange",
  decision: "cyan",
  jalon: "vert",
  formation: "violet",
};

const statusIcon = {
  completed: CheckCircle2,
  "in-progress": Clock,
  planned: Calendar,
};

const statusTone = {
  completed: "vert",
  "in-progress": "cyan",
  planned: "violet",
} as const;

const statusLabel = {
  completed: "Réalisé",
  "in-progress": "En cours",
  planned: "Planifié",
};

type StatusFilter = "all" | "completed" | "in-progress" | "planned";

export function ActivitiesTimeline() {
  const [filter, setFilter] = useState<StatusFilter>("all");
  const [typeFilter, setTypeFilter] = useState<ActivityType | "all">("all");

  const filtered = activities
    .filter(a => filter === "all" || a.status === filter)
    .filter(a => typeFilter === "all" || a.type === typeFilter)
    .sort((a, b) => b.date.localeCompare(a.date));

  const counts = {
    all: activities.length,
    completed: activities.filter(a => a.status === "completed").length,
    "in-progress": activities.filter(a => a.status === "in-progress").length,
    planned: activities.filter(a => a.status === "planned").length,
  };

  return (
    <GlassPanel variant="strong" className="p-5">
      <div className="flex items-center justify-between mb-4 gap-3 flex-wrap">
        <div>
          <h2 className="text-lg font-semibold flex items-center gap-2">
            <ScrollText className="w-5 h-5 text-bleu-ipd" />
            Journal de la transformation
          </h2>
          <p className="text-xs text-text-muted mt-0.5">
            {filtered.length} activité{filtered.length > 1 ? "s" : ""} {filter !== "all" || typeFilter !== "all" ? "filtrée" + (filtered.length > 1 ? "s" : "") : "enregistrée" + (filtered.length > 1 ? "s" : "")}
          </p>
        </div>
        <div className="flex items-center gap-1 p-1 rounded-xl bg-white/5 border border-white/10">
          {(["all", "completed", "in-progress", "planned"] as const).map(s => (
            <button
              key={s}
              onClick={() => setFilter(s)}
              className={cn(
                "px-2.5 py-1 rounded-lg text-xs font-medium transition flex items-center gap-1.5",
                filter === s ? "bg-bleu-ipd/30 text-bleu-clair" : "text-text-muted hover:text-text-primary",
              )}
            >
              {s === "all" ? "Tous" : statusLabel[s]}
              <span className={cn("text-[10px] tabular-nums", filter === s ? "text-bleu-clair" : "text-text-muted")}>
                {counts[s]}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* Type filters */}
      <div className="flex items-center gap-1.5 flex-wrap mb-4">
        <button
          onClick={() => setTypeFilter("all")}
          className={cn(
            "px-2.5 py-1 rounded-full text-xs font-medium border transition",
            typeFilter === "all" ? "bg-cyan/15 text-cyan border-cyan/40" : "border-white/10 text-text-muted hover:text-text-secondary",
          )}
        >
          Tous types
        </button>
        {(Object.keys(typeLabel) as ActivityType[]).map(t => {
          const Icon = typeIcon[t];
          const active = typeFilter === t;
          return (
            <button
              key={t}
              onClick={() => setTypeFilter(t)}
              className={cn(
                "px-2.5 py-1 rounded-full text-xs font-medium border transition flex items-center gap-1.5",
                active ? "bg-cyan/15 text-cyan border-cyan/40" : "border-white/10 text-text-muted hover:text-text-secondary",
              )}
            >
              <Icon className="w-3 h-3" />
              {typeLabel[t]}
            </button>
          );
        })}
      </div>

      <div className="relative">
        <div className="absolute left-3 top-2 bottom-2 w-px bg-gradient-to-b from-bleu-ipd via-cyan/30 to-violet/20" />
        <div className="space-y-3">
          {filtered.map(a => {
            const TypeIcon = typeIcon[a.type];
            const StatusIcon = statusIcon[a.status];
            return (
              <div key={a.id} className="flex items-start gap-4 group">
                <div className={cn(
                  "relative w-7 h-7 rounded-full flex items-center justify-center border-2 z-10 shrink-0",
                  a.status === "completed" ? "bg-vert/20 border-vert" :
                  a.status === "in-progress" ? "bg-cyan/20 border-cyan" :
                  "bg-violet/20 border-violet",
                )}>
                  <StatusIcon className={cn("w-3.5 h-3.5",
                    a.status === "completed" ? "text-vert" :
                    a.status === "in-progress" ? "text-cyan" : "text-violet-pale",
                  )} />
                </div>
                <div className="flex-1 p-3 rounded-xl border bg-white/3 border-white/5 group-hover:border-cyan/20 group-hover:bg-glass-hover transition">
                  <div className="flex items-start justify-between gap-2 mb-1.5">
                    <p className="text-sm font-semibold text-text-primary leading-snug">{a.title}</p>
                    <Badge tone={statusTone[a.status]}>{statusLabel[a.status]}</Badge>
                  </div>
                  <p className="text-xs text-text-secondary leading-relaxed mb-2">{a.description}</p>
                  <div className="flex items-center gap-2 flex-wrap text-[11px] text-text-muted">
                    <span className="flex items-center gap-1">
                      <TypeIcon className={cn("w-3 h-3", `text-${typeColor[a.type]}`)} />
                      <span>{typeLabel[a.type]}</span>
                    </span>
                    <span>·</span>
                    <span className="font-medium text-text-secondary">
                      {new Date(a.date).toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" })}
                    </span>
                    <span>·</span>
                    <span>{a.presenter}</span>
                    <span>·</span>
                    <span className="italic">→ {a.audience}</span>
                  </div>
                  {a.outcome && (
                    <p className="text-[11px] text-vert mt-2 leading-relaxed border-l-2 border-vert/30 pl-2">
                      {a.outcome}
                    </p>
                  )}
                  {a.entityIds.length > 0 && (
                    <div className="flex items-center gap-1.5 flex-wrap mt-2 pt-2 border-t border-white/5">
                      {a.entityIds.map(eid => {
                        const ent = entities.find(e => e.id === eid);
                        return ent ? (
                          <span key={eid} className="text-[10px] px-1.5 py-0.5 rounded bg-white/5 text-text-muted">
                            {ent.shortLabel}
                          </span>
                        ) : null;
                      })}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </GlassPanel>
  );
}
