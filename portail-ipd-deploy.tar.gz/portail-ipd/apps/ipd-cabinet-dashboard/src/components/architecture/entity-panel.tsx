"use client";

import Link from "next/link";
import { Badge } from "@/components/ui/badge";
import { activities, layerLabels, type ArchEntity } from "@/lib/data/architecture";
import { meIndicators } from "@/lib/data/me";
import { getProjectById } from "@/lib/data/projects";
import { getGrantById } from "@/lib/data/grants";
import { X, Users, Activity, ArrowRight, FileText, Briefcase, Banknote } from "lucide-react";
import { cn } from "@/lib/utils";

const statusTone = {
  operational: "vert",
  transitioning: "cyan",
  planned: "violet",
} as const;

const statusLabel = {
  operational: "Opérationnel",
  transitioning: "En transition",
  planned: "À planifier",
};

interface EntityPanelProps {
  entity: ArchEntity;
  onClose: () => void;
}

export function EntityPanel({ entity, onClose }: EntityPanelProps) {
  const linkedActivities = activities
    .filter(a => a.entityIds.includes(entity.id))
    .sort((a, b) => b.date.localeCompare(a.date));

  const linkedIndicators = entity.meIndicators
    ?.map(id => meIndicators.find(i => i.id === id))
    .filter((i): i is NonNullable<typeof i> => Boolean(i));

  const linkedProjects = entity.relatedProjects?.map(id => getProjectById(id)).filter(Boolean);
  const linkedGrants = entity.relatedGrants?.map(id => getGrantById(id)).filter(Boolean);

  return (
    <div
      className="fixed inset-0 z-50 flex items-stretch justify-end bg-black/60 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="w-full max-w-xl glass-strong border-l border-bleu-ipd/40 overflow-y-auto p-6"
        onClick={e => e.stopPropagation()}
      >
        <div className="flex items-start justify-between mb-4 gap-3">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2 flex-wrap">
              <Badge tone={statusTone[entity.status]}>{statusLabel[entity.status]}</Badge>
              <Badge tone="neutre">{layerLabels[entity.layer]}</Badge>
            </div>
            <h3 className="text-2xl font-bold leading-tight">{entity.label}</h3>
            <p className="text-sm text-bleu-clair mt-1">{entity.role}</p>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl hover:bg-white/5 text-text-muted hover:text-text-primary transition shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <p className="text-sm text-text-secondary leading-relaxed mb-5">{entity.description}</p>

        {/* Responsables */}
        <section className="mb-5">
          <h4 className="text-xs uppercase tracking-widest text-text-muted mb-2 flex items-center gap-2">
            <Users className="w-3.5 h-3.5" /> Responsables
          </h4>
          <div className="space-y-1.5">
            {entity.responsables.map((r, i) => (
              <div key={i} className="flex items-center gap-3 px-3 py-2 rounded-xl bg-white/3 border border-white/5">
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-bleu-ipd to-cyan flex items-center justify-center text-white text-xs font-bold shrink-0">
                  {r.name.split(" ").map(n => n[0]).slice(0, 2).join("")}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{r.name}</p>
                  <p className="text-[11px] text-text-muted truncate">{r.title}</p>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* M&E indicators */}
        {linkedIndicators && linkedIndicators.length > 0 && (
          <section className="mb-5">
            <h4 className="text-xs uppercase tracking-widest text-text-muted mb-2 flex items-center gap-2">
              <Activity className="w-3.5 h-3.5" /> Indicateurs M&amp;E suivis
            </h4>
            <Link href="/me" className="block space-y-1.5 group">
              {linkedIndicators.map(ind => (
                <div key={ind.id} className="px-3 py-2 rounded-xl bg-white/3 border border-white/5 group-hover:border-cyan/30 transition flex items-center justify-between gap-2">
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{ind.label}</p>
                    <p className="text-[11px] text-text-muted font-mono">{ind.code}</p>
                  </div>
                  <span className="text-xs font-bold text-cyan tabular-nums whitespace-nowrap">
                    {typeof ind.value === "number" ? ind.value.toLocaleString("fr-FR") : ind.value} {ind.unit}
                  </span>
                </div>
              ))}
              <div className="text-[11px] text-cyan flex items-center gap-1 group-hover:underline pt-1">
                Voir le module M&amp;E temps réel <ArrowRight className="w-3 h-3" />
              </div>
            </Link>
          </section>
        )}

        {/* Linked projects */}
        {linkedProjects && linkedProjects.length > 0 && (
          <section className="mb-5">
            <h4 className="text-xs uppercase tracking-widest text-text-muted mb-2 flex items-center gap-2">
              <Briefcase className="w-3.5 h-3.5" /> Projets rattachés
            </h4>
            <div className="space-y-1.5">
              {linkedProjects.map(p => p && (
                <Link
                  key={p.id}
                  href={`/projects/${p.id}`}
                  className="flex items-center justify-between gap-2 px-3 py-2 rounded-xl bg-bleu-ipd/10 border border-bleu-ipd/30 hover:bg-bleu-ipd/20 transition group"
                >
                  <span className="text-sm text-bleu-clair font-medium truncate">{p.name}</span>
                  <ArrowRight className="w-3.5 h-3.5 text-bleu-clair shrink-0 group-hover:translate-x-0.5 transition" />
                </Link>
              ))}
            </div>
          </section>
        )}

        {/* Linked grants */}
        {linkedGrants && linkedGrants.length > 0 && (
          <section className="mb-5">
            <h4 className="text-xs uppercase tracking-widest text-text-muted mb-2 flex items-center gap-2">
              <Banknote className="w-3.5 h-3.5" /> Grants associés
            </h4>
            <div className="space-y-1.5">
              {linkedGrants.map(g => g && (
                <Link
                  key={g.id}
                  href={`/grants/${g.id}`}
                  className="flex items-center justify-between gap-2 px-3 py-2 rounded-xl bg-vert/10 border border-vert/30 hover:bg-vert/20 transition group"
                >
                  <span className="text-sm text-vert font-medium truncate">{g.title}</span>
                  <ArrowRight className="w-3.5 h-3.5 text-vert shrink-0 group-hover:translate-x-0.5 transition" />
                </Link>
              ))}
            </div>
          </section>
        )}

        {/* Activities */}
        <section>
          <h4 className="text-xs uppercase tracking-widest text-text-muted mb-2 flex items-center gap-2">
            <FileText className="w-3.5 h-3.5" /> Activités liées ({linkedActivities.length})
          </h4>
          {linkedActivities.length === 0 ? (
            <p className="text-xs text-text-muted italic">Aucune activité enregistrée pour cette entité.</p>
          ) : (
            <div className="space-y-2">
              {linkedActivities.map(a => (
                <div key={a.id} className={cn(
                  "rounded-xl border p-3",
                  a.status === "completed" ? "bg-vert/5 border-vert/20" :
                  a.status === "in-progress" ? "bg-cyan/5 border-cyan/25" :
                  "bg-violet/8 border-violet/25",
                )}>
                  <div className="flex items-start justify-between gap-2 mb-1">
                    <p className="text-sm font-semibold leading-snug">{a.title}</p>
                    <Badge tone={a.status === "completed" ? "vert" : a.status === "in-progress" ? "cyan" : "violet"}>
                      {a.status === "completed" ? "Réalisé" : a.status === "in-progress" ? "En cours" : "Planifié"}
                    </Badge>
                  </div>
                  <p className="text-xs text-text-secondary leading-relaxed mb-2">{a.description}</p>
                  <div className="text-[11px] text-text-muted flex items-center gap-2 flex-wrap">
                    <span>{new Date(a.date).toLocaleDateString("fr-FR", { day: "numeric", month: "short", year: "numeric" })}</span>
                    <span>·</span>
                    <span>{a.presenter}</span>
                    <span>·</span>
                    <span className="italic">{a.audience}</span>
                  </div>
                  {a.outcome && (
                    <p className="text-[11px] text-vert mt-1.5 leading-relaxed">→ {a.outcome}</p>
                  )}
                </div>
              ))}
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
