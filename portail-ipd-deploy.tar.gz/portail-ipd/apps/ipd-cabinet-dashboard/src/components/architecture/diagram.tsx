"use client";

import { useState, useId } from "react";
import { entities, type ArchEntity, type EntityStatus } from "@/lib/data/architecture";
import { EntityPanel } from "./entity-panel";
import { cn } from "@/lib/utils";

const ISO_ANGLE = (30 * Math.PI) / 180;
const COS = Math.cos(ISO_ANGLE);
const SIN = Math.sin(ISO_ANGLE);

const iso = (x: number, y: number, z: number = 0) => ({
  x: (x - y) * COS,
  y: (x + y) * SIN - z,
});

const statusBadge: Record<EntityStatus, { label: string; color: string }> = {
  operational: { label: "Opérationnel", color: "#5DBB63" },
  transitioning: { label: "En transition", color: "#00D4FF" },
  planned: { label: "À planifier", color: "#9B7FBF" },
};

type Color = { hue: string; tint: string; edge: string; glow: string; text: string };

const colorByLayer: Record<string, Color> = {
  intelligence:  { hue: "#5DBB63", tint: "#A8E6AE", edge: "#82D689", glow: "rgba(93,187,99,0.55)",  text: "#FFFFFF" },
  strategic:     { hue: "#00D4FF", tint: "#9FEEFF", edge: "#7FE8FF", glow: "rgba(0,212,255,0.65)",  text: "#FFFFFF" },
  operational:   { hue: "#0089D0", tint: "#6FBEEA", edge: "#4DB5E8", glow: "rgba(0,137,208,0.55)",  text: "#FFFFFF" },
  units:         { hue: "#9B7FBF", tint: "#D7C8EA", edge: "#C9B8E0", glow: "rgba(155,127,191,0.45)", text: "#FFFFFF" },
  maturity:      { hue: "#F39200", tint: "#FFC972", edge: "#FFB956", glow: "rgba(243,146,0,0.5)",   text: "#FFFFFF" },
};

interface BoxProps {
  entity: ArchEntity;
  x: number; y: number; z: number;
  dx: number; dy: number; dz: number;
  onClick: (e: ArchEntity) => void;
  hovered: string | null;
  setHovered: (id: string | null) => void;
  gradTop: string;
  gradFront: string;
  gradSide: string;
  delay?: number;
}

function IsoBox({ entity, x, y, z, dx, dy, dz, onClick, hovered, setHovered, gradTop, gradFront, gradSide, delay = 0 }: BoxProps) {
  const c = colorByLayer[entity.layer];
  const hover = hovered === entity.id;

  const p000 = iso(x, y, z);
  const p100 = iso(x + dx, y, z);
  const p010 = iso(x, y + dy, z);
  const p001 = iso(x, y, z + dz);
  const p101 = iso(x + dx, y, z + dz);
  const p011 = iso(x, y + dy, z + dz);
  const p111 = iso(x + dx, y + dy, z + dz);

  const front = `${p000.x},${p000.y} ${p100.x},${p100.y} ${p101.x},${p101.y} ${p001.x},${p001.y}`;
  const side  = `${p000.x},${p000.y} ${p010.x},${p010.y} ${p011.x},${p011.y} ${p001.x},${p001.y}`;
  const top   = `${p001.x},${p001.y} ${p101.x},${p101.y} ${p111.x},${p111.y} ${p011.x},${p011.y}`;

  // Label anchor: above top-back corner
  const labelX = (p001.x + p111.x) / 2;
  const labelY = (p001.y + p111.y) / 2;
  // Leader line tip just above top center
  const leaderTopY = labelY - 0.4;

  const status = statusBadge[entity.status];

  return (
    <g
      onClick={() => onClick(entity)}
      onMouseEnter={() => setHovered(entity.id)}
      onMouseLeave={() => setHovered(null)}
      className="cursor-pointer"
      style={{
        transformOrigin: `${labelX}px ${labelY}px`,
        animation: `floaty 6s ease-in-out infinite`,
        animationDelay: `${delay}s`,
      }}
    >
      {/* Soft halo behind box */}
      <ellipse
        cx={(p000.x + p111.x) / 2}
        cy={p000.y + 0.6}
        rx={dx * 0.8}
        ry={0.5}
        fill={c.glow}
        opacity={hover ? 0.5 : 0.25}
      />
      {/* Side face — most opaque (less light) */}
      <polygon
        points={side}
        fill={`url(#${gradSide})`}
        stroke={c.edge}
        strokeWidth={hover ? 0.18 : 0.08}
        strokeOpacity="0.85"
      />
      {/* Front face */}
      <polygon
        points={front}
        fill={`url(#${gradFront})`}
        stroke={c.edge}
        strokeWidth={hover ? 0.18 : 0.08}
        strokeOpacity="0.85"
      />
      {/* Top face — brightest */}
      <polygon
        points={top}
        fill={`url(#${gradTop})`}
        stroke={c.edge}
        strokeWidth={hover ? 0.28 : 0.14}
        strokeOpacity="1"
      />
      {/* Edge highlights (top edges only for shine) */}
      <line x1={p001.x} y1={p001.y} x2={p011.x} y2={p011.y} stroke={c.tint} strokeWidth="0.08" opacity="0.7" />
      <line x1={p001.x} y1={p001.y} x2={p101.x} y2={p101.y} stroke={c.tint} strokeWidth="0.08" opacity="0.7" />
      <line x1={p011.x} y1={p011.y} x2={p111.x} y2={p111.y} stroke={c.tint} strokeWidth="0.06" opacity="0.5" />
      <line x1={p101.x} y1={p101.y} x2={p111.x} y2={p111.y} stroke={c.tint} strokeWidth="0.06" opacity="0.5" />

      {/* Status indicator: pulsing dot at top-back corner */}
      <circle cx={p011.x + 0.35} cy={p011.y - 0.15} r="0.32" fill={status.color} opacity="0.95">
        {entity.status === "transitioning" && (
          <animate attributeName="r" values="0.32;0.55;0.32" dur="1.6s" repeatCount="indefinite" />
        )}
      </circle>
      <circle cx={p011.x + 0.35} cy={p011.y - 0.15} r="0.5" fill="none" stroke={status.color} strokeWidth="0.08" opacity="0.5">
        {entity.status === "transitioning" && (
          <animate attributeName="r" values="0.5;1.0;0.5" dur="1.6s" repeatCount="indefinite" />
        )}
      </circle>

      {/* Centered label on top face */}
      <text
        x={labelX}
        y={labelY}
        fontSize="0.85"
        fontWeight="700"
        fill={c.text}
        textAnchor="middle"
        dominantBaseline="middle"
        pointerEvents="none"
        style={{
          userSelect: "none",
          textShadow: "0 0 6px rgba(0,0,0,0.7), 0 0 2px rgba(0,0,0,0.9)",
          filter: hover ? "drop-shadow(0 0 4px rgba(255,255,255,0.5))" : "none",
        }}
      >
        {entity.shortLabel}
      </text>
    </g>
  );
}

interface ConnectionProps {
  from: { x: number; y: number; z: number };
  to: { x: number; y: number; z: number };
  variant?: "governance" | "data" | "maturity";
  animate?: boolean;
}

function Connection({ from, to, variant = "governance", animate = true }: ConnectionProps) {
  const a = iso(from.x, from.y, from.z);
  const b = iso(to.x, to.y, to.z);
  const stroke = variant === "data" ? "#5DBB63" : variant === "maturity" ? "#F39200" : "#00D4FF";
  const dasharray = variant === "data" ? "0" : variant === "maturity" ? "0.4 0.4" : "0";

  return (
    <g>
      <line
        x1={a.x} y1={a.y} x2={b.x} y2={b.y}
        stroke={stroke}
        strokeWidth="0.12"
        strokeOpacity="0.45"
        strokeDasharray={dasharray}
        strokeLinecap="round"
      />
      {/* Animated particle traveling along the line */}
      {animate && (
        <circle r="0.18" fill={stroke} opacity="0.9">
          <animate
            attributeName="cx"
            from={a.x}
            to={b.x}
            dur={`${2 + Math.abs(a.x - b.x) * 0.3}s`}
            repeatCount="indefinite"
          />
          <animate
            attributeName="cy"
            from={a.y}
            to={b.y}
            dur={`${2 + Math.abs(a.x - b.x) * 0.3}s`}
            repeatCount="indefinite"
          />
          <animate
            attributeName="opacity"
            values="0;1;1;0"
            dur={`${2 + Math.abs(a.x - b.x) * 0.3}s`}
            repeatCount="indefinite"
          />
        </circle>
      )}
    </g>
  );
}

const layout = {
  cellule:    { pos: { x: -9.5, y: -1.5, z: 0 }, size: { dx: 2, dy: 2, dz: 16 } },
  // MEL: smaller footprint and shifted back so Cabinet AG remains visible
  mel:        { pos: { x: -2, y: 0, z: 17 }, size: { dx: 5, dy: 5, dz: 1.2 } },
  // Cabinet AG shifted forward (negative y) so it sticks out from MEL
  cabinet:    { pos: { x: -1.5, y: -3, z: 12 }, size: { dx: 4, dy: 3.5, dz: 3 } },
  governance: { pos: { x: 5, y: -1, z: 12 }, size: { dx: 3, dy: 3, dz: 2.5 } },
  cvoCso:     { pos: { x: 5, y: -1, z: 8.5 }, size: { dx: 3, dy: 3, dz: 2.5 } },
  madiba:     { pos: { x: -3.5, y: -3.5, z: 8 }, size: { dx: 3.2, dy: 3.5, dz: 2.8 } },
  grant:      { pos: { x: 0.5, y: 1, z: 8 }, size: { dx: 3.2, dy: 3.5, dz: 2.8 } },
  // Units pulled forward (lower y) and lined up
  vrc:        { pos: { x: -4.4, y: -4.5, z: 4 }, size: { dx: 1.9, dy: 1.9, dz: 1.4 } },
  publicH:    { pos: { x: -2.2, y: -4.5, z: 4 }, size: { dx: 1.9, dy: 1.9, dz: 1.4 } },
  clinical:   { pos: { x: 0,    y: -4.5, z: 4 }, size: { dx: 1.9, dy: 1.9, dz: 1.4 } },
  diatropix:  { pos: { x: 2.2,  y: -4.5, z: 4 }, size: { dx: 1.9, dy: 1.9, dz: 1.4 } },
  care:       { pos: { x: 4.4,  y: -4.5, z: 4 }, size: { dx: 1.9, dy: 1.9, dz: 1.4 } },
};

const layerToGradKey = (layer: string) => layer.replace(/[^a-z]/gi, "");

export function ArchitectureDiagram() {
  const [selected, setSelected] = useState<ArchEntity | null>(null);
  const [hovered, setHovered] = useState<string | null>(null);
  const uid = useId().replace(/[:#]/g, "");

  const findEntity = (id: string) => entities.find(e => e.id === id)!;

  const boxes = [
    { entity: findEntity("e-cellule-pmo"), ...layout.cellule, delay: 0 },
    { entity: findEntity("e-mel"), ...layout.mel, delay: 0.6 },
    { entity: findEntity("e-cabinet"), ...layout.cabinet, delay: 1.2 },
    { entity: findEntity("e-governance"), ...layout.governance, delay: 1.5 },
    { entity: findEntity("e-cvo-cso"), ...layout.cvoCso, delay: 2.0 },
    { entity: findEntity("e-madiba"), ...layout.madiba, delay: 0.3 },
    { entity: findEntity("e-grant-office"), ...layout.grant, delay: 0.9 },
    { entity: findEntity("e-vrc"), ...layout.vrc, delay: 0.2 },
    { entity: findEntity("e-public-health"), ...layout.publicH, delay: 0.4 },
    { entity: findEntity("e-clinical-trials"), ...layout.clinical, delay: 0.6 },
    { entity: findEntity("e-diatropix"), ...layout.diatropix, delay: 0.8 },
    { entity: findEntity("e-care"), ...layout.care, delay: 1.0 },
  ];

  const sorted = [...boxes].sort((a, b) => {
    if (a.pos.z !== b.pos.z) return a.pos.z - b.pos.z;
    return (b.pos.x + b.pos.y) - (a.pos.x + a.pos.y);
  });

  const center = (k: keyof typeof layout) => ({
    x: layout[k].pos.x + layout[k].size.dx / 2,
    y: layout[k].pos.y + layout[k].size.dy / 2,
    z: layout[k].pos.z + layout[k].size.dz,
  });
  const baseCenter = (k: keyof typeof layout) => ({
    x: layout[k].pos.x + layout[k].size.dx / 2,
    y: layout[k].pos.y + layout[k].size.dy / 2,
    z: layout[k].pos.z,
  });

  // Layers we need gradients for
  const layers = ["intelligence", "strategic", "operational", "units", "maturity"] as const;

  return (
    <>
      <style>{`
        @keyframes floaty {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-0.18px); }
        }
        @keyframes drift {
          0% { transform: translate(0, 0); opacity: 0.3; }
          50% { opacity: 0.8; }
          100% { transform: translate(2px, -3px); opacity: 0; }
        }
        @keyframes grid-shimmer {
          0%, 100% { opacity: 0.04; }
          50% { opacity: 0.08; }
        }
      `}</style>
      <div className="relative">
        <svg viewBox="-13 -23 24 25" className="w-full max-h-[680px]" preserveAspectRatio="xMidYMid meet">
          <defs>
            {/* Gradient definitions for translucent glass faces */}
            {layers.map(l => {
              const c = colorByLayer[l];
              return (
                <g key={l}>
                  {/* Top — brightest, nearly transparent */}
                  <linearGradient id={`grad-top-${l}-${uid}`} x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor={c.tint} stopOpacity="0.55" />
                    <stop offset="60%" stopColor={c.hue} stopOpacity="0.40" />
                    <stop offset="100%" stopColor={c.hue} stopOpacity="0.30" />
                  </linearGradient>
                  {/* Front — medium light */}
                  <linearGradient id={`grad-front-${l}-${uid}`} x1="0%" y1="0%" x2="0%" y2="100%">
                    <stop offset="0%" stopColor={c.hue} stopOpacity="0.42" />
                    <stop offset="100%" stopColor={c.hue} stopOpacity="0.22" />
                  </linearGradient>
                  {/* Side — darkest */}
                  <linearGradient id={`grad-side-${l}-${uid}`} x1="100%" y1="0%" x2="0%" y2="100%">
                    <stop offset="0%" stopColor={c.hue} stopOpacity="0.55" />
                    <stop offset="100%" stopColor="#000000" stopOpacity="0.35" />
                  </linearGradient>
                </g>
              );
            })}

            {/* Background subtle grid pattern */}
            <pattern id={`cyber-grid-${uid}`} x="0" y="0" width="2" height="2" patternUnits="userSpaceOnUse">
              <path d="M 2 0 L 0 0 0 2" fill="none" stroke="#00D4FF" strokeWidth="0.04" strokeOpacity="0.18" />
            </pattern>

            {/* Floor radial gradient */}
            <radialGradient id={`floor-${uid}`} cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="rgba(0,212,255,0.20)" />
              <stop offset="100%" stopColor="rgba(0,212,255,0)" />
            </radialGradient>
          </defs>

          {/* Cyber grid background — subtle */}
          <rect x="-13" y="-23" width="24" height="25" fill={`url(#cyber-grid-${uid})`} opacity="0.5" />

          {/* Floor glow */}
          <ellipse cx="0" cy="-2" rx="11" ry="3" fill={`url(#floor-${uid})`} />

          {/* Connections — drawn under boxes with animated particles */}
          <g opacity="0.95">
            <Connection from={center("madiba")} to={baseCenter("cabinet")} variant="governance" />
            <Connection from={center("grant")} to={baseCenter("cabinet")} variant="governance" />
            <Connection from={center("vrc")} to={baseCenter("madiba")} variant="data" />
            <Connection from={center("publicH")} to={baseCenter("madiba")} variant="data" />
            <Connection from={center("clinical")} to={baseCenter("grant")} variant="data" />
            <Connection from={center("diatropix")} to={baseCenter("madiba")} variant="data" />
            <Connection from={center("care")} to={baseCenter("grant")} variant="data" />
            <Connection from={center("cabinet")} to={baseCenter("mel")} variant="data" />
            <Connection from={center("cabinet")} to={baseCenter("governance")} variant="governance" />
            <Connection from={center("cabinet")} to={baseCenter("cvoCso")} variant="governance" />
            <Connection from={baseCenter("cellule")} to={baseCenter("madiba")} variant="maturity" animate={false} />
            <Connection from={baseCenter("cellule")} to={baseCenter("grant")} variant="maturity" animate={false} />
            <Connection from={baseCenter("cellule")} to={baseCenter("cabinet")} variant="maturity" animate={false} />
          </g>

          {sorted.map(({ entity, pos, size, delay }) => (
            <IsoBox
              key={entity.id}
              entity={entity}
              x={pos.x} y={pos.y} z={pos.z}
              dx={size.dx} dy={size.dy} dz={size.dz}
              onClick={setSelected}
              hovered={hovered}
              setHovered={setHovered}
              gradTop={`grad-top-${layerToGradKey(entity.layer)}-${uid}`}
              gradFront={`grad-front-${layerToGradKey(entity.layer)}-${uid}`}
              gradSide={`grad-side-${layerToGradKey(entity.layer)}-${uid}`}
              delay={delay}
            />
          ))}

          {/* External layer labels — ultra-faint, far left */}
          <text x="-12.6" y="-19" fontSize="0.55" fill="#82D689" fontWeight="700" letterSpacing="0.06" opacity="0.7">INTELLIGENCE</text>
          <text x="-12.6" y="-13" fontSize="0.55" fill="#7FE8FF" fontWeight="700" letterSpacing="0.06" opacity="0.7">HUB STRATÉGIQUE</text>
          <text x="-12.6" y="-8.5" fontSize="0.55" fill="#4DB5E8" fontWeight="700" letterSpacing="0.06" opacity="0.7">PÔLES OPÉRATIONNELS</text>
          <text x="-12.6" y="-3.5" fontSize="0.55" fill="#C9B8E0" fontWeight="700" letterSpacing="0.06" opacity="0.7">UNITÉS</text>
          <text x="-12.6" y="2" fontSize="0.55" fill="#FFB956" fontWeight="700" letterSpacing="0.06" opacity="0.7">MATURITÉ</text>

          {/* Floating ambient particles for atmosphere */}
          {Array.from({ length: 12 }).map((_, i) => {
            const px = (Math.sin(i * 1.7) * 8);
            const py = (Math.cos(i * 2.3) * 6) - 9;
            return (
              <circle key={i} cx={px} cy={py} r="0.08" fill="#00D4FF" opacity="0.6">
                <animate
                  attributeName="opacity"
                  values="0;0.7;0"
                  dur={`${3 + (i % 4)}s`}
                  begin={`${i * 0.4}s`}
                  repeatCount="indefinite"
                />
                <animate
                  attributeName="cy"
                  values={`${py};${py - 1.5};${py}`}
                  dur={`${3 + (i % 4)}s`}
                  begin={`${i * 0.4}s`}
                  repeatCount="indefinite"
                />
              </circle>
            );
          })}
        </svg>

        {/* Legends */}
        <div className="absolute top-3 right-3 flex flex-col gap-1.5 text-[11px]">
          <Legend swatch="#5DBB63" label="Opérationnel" />
          <Legend swatch="#00D4FF" label="En transition" pulse />
          <Legend swatch="#9B7FBF" label="À planifier" />
        </div>
        <div className="absolute bottom-3 right-3 flex flex-col gap-1.5 text-[11px]">
          <Legend swatch="#00D4FF" label="Gouvernance" line />
          <Legend swatch="#5DBB63" label="Flux de données" line />
          <Legend swatch="#F39200" label="Maturité système" dashed line />
        </div>
      </div>

      {selected && (
        <EntityPanel entity={selected} onClose={() => setSelected(null)} />
      )}
    </>
  );
}

function Legend({ swatch, label, line, dashed, pulse }: { swatch: string; label: string; line?: boolean; dashed?: boolean; pulse?: boolean }) {
  return (
    <div className="flex items-center gap-2 px-2 py-1 rounded-lg glass border border-white/10 backdrop-blur-md">
      {line ? (
        <span
          className="block w-5 h-px"
          style={{ borderTop: `1.5px ${dashed ? "dashed" : "solid"} ${swatch}` }}
        />
      ) : (
        <span
          className={cn("block w-2.5 h-2.5 rounded-full", pulse && "live-dot")}
          style={{ background: swatch, boxShadow: `0 0 8px ${swatch}` }}
        />
      )}
      <span className="text-text-secondary">{label}</span>
    </div>
  );
}
