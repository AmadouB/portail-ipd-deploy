"use client";

import { useState, useEffect, FormEvent } from "react";
import { GlassPanel } from "@/components/ui/glass-panel";
import { Badge } from "@/components/ui/badge";
import { ScorecardRadar } from "./scorecard-radar";
import { maturationProjects as initialProjects, stageLabels, stageOrder, maturityScore } from "@/lib/data/maturation";
import type { MaturationProject, Pole } from "@/lib/types";
import { ChevronRight, X, Sprout, FlaskConical, Rocket, Factory, TrendingUp, CheckCircle2, Plus } from "lucide-react";
import { cn } from "@/lib/utils";

const stageIcons = {
  ideation: Sprout,
  validation: FlaskConical,
  pilote: Rocket,
  industrialisation: Factory,
};

const stageColors = {
  ideation: { bar: "from-violet to-violet-pale", text: "text-violet-pale", dot: "bg-violet" },
  validation: { bar: "from-violet to-bleu-clair", text: "text-violet-pale", dot: "bg-bleu-clair" },
  pilote: { bar: "from-bleu-clair to-cyan", text: "text-cyan-soft", dot: "bg-cyan-soft" },
  industrialisation: { bar: "from-cyan to-vert", text: "text-vert", dot: "bg-vert" },
} as const;

export function KanbanBoard() {
  const [projects, setProjects] = useState<MaturationProject[]>(initialProjects);
  const [selected, setSelected] = useState<MaturationProject | null>(null);
  const [showNewModal, setShowNewModal] = useState(false);
  const [toast, setToast] = useState<{ message: string; tone: "success" | "info" } | null>(null);

  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(null), 2800);
    return () => clearTimeout(t);
  }, [toast]);

  // Listen for external "open new project modal" trigger from PageHeader button
  useEffect(() => {
    const handler = () => setShowNewModal(true);
    window.addEventListener("open-new-maturation-project", handler);
    return () => window.removeEventListener("open-new-maturation-project", handler);
  }, []);

  const createProject = (data: { name: string; sponsor: string; pole: Pole; description: string }) => {
    const newProject: MaturationProject = {
      id: `m-${Date.now()}`,
      name: data.name,
      stage: "ideation",
      sponsor: data.sponsor,
      pole: data.pole,
      ideationDate: new Date().toISOString().slice(0, 10),
      description: data.description,
      scorecard: { vision: 0.4, technique: 0.2, financier: 0.2, risques: 0.3, equipe: 0.2, me: 0.1 },
    };
    setProjects(ps => [newProject, ...ps]);
    setShowNewModal(false);
    setToast({
      message: `« ${data.name} » ajouté en Idéation. Compléter la scorecard pour avancer.`,
      tone: "success",
    });
  };

  const promote = (project: MaturationProject) => {
    const currentIdx = stageOrder.indexOf(project.stage);
    if (currentIdx >= stageOrder.length - 1) {
      setToast({ message: `${project.name} est déjà au stade final.`, tone: "info" });
      return;
    }
    const nextStage = stageOrder[currentIdx + 1];
    setProjects(ps => ps.map(p => p.id === project.id ? { ...p, stage: nextStage } : p));
    setSelected({ ...project, stage: nextStage });
    setToast({
      message: `« ${project.name} » promu vers ${stageLabels[nextStage]}.`,
      tone: "success",
    });
  };

  const requestReview = (project: MaturationProject) => {
    setSelected(null);
    setToast({
      message: `Demande de revue envoyée pour « ${project.name} » au Cabinet AG.`,
      tone: "info",
    });
  };

  return (
    <>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {stageOrder.map((stage, stageIdx) => {
          const Icon = stageIcons[stage];
          const items = projects.filter(p => p.stage === stage);
          const colors = stageColors[stage];
          return (
            <GlassPanel key={stage} variant="strong" className="p-4 flex flex-col">
              <div className="flex items-center gap-2 mb-3 pb-3 border-b border-white/10">
                <div className={cn("p-2 rounded-lg bg-white/5", colors.text)}>
                  <Icon className="w-4 h-4" />
                </div>
                <div className="flex-1">
                  <p className="text-[10px] uppercase tracking-widest text-text-muted">Stade {stageIdx + 1}</p>
                  <p className="font-semibold text-sm">{stageLabels[stage]}</p>
                </div>
                <span className={cn("w-7 h-7 rounded-full text-xs font-bold flex items-center justify-center", colors.text, "bg-white/5")}>
                  {items.length}
                </span>
              </div>
              <div className="space-y-2 flex-1 min-h-[200px]">
                {items.map(p => {
                  const score = Math.round(maturityScore(p) * 100);
                  return (
                    <button
                      key={p.id}
                      onClick={() => setSelected(p)}
                      className="w-full text-left p-3 rounded-xl bg-white/3 border border-white/5 hover:border-cyan/30 hover:bg-glass-hover transition group"
                    >
                      <p className="text-sm font-medium text-text-primary group-hover:text-cyan transition leading-snug">
                        {p.name}
                      </p>
                      <p className="text-[11px] text-text-muted mt-1">{p.sponsor}</p>
                      <div className="flex items-center gap-2 mt-2.5">
                        <div className="flex-1 h-1 rounded-full bg-white/5 overflow-hidden">
                          <div
                            className={cn("h-full rounded-full bg-gradient-to-r", colors.bar)}
                            style={{ width: `${score}%` }}
                          />
                        </div>
                        <span className={cn("text-[10px] font-bold tabular-nums", colors.text)}>{score}</span>
                      </div>
                    </button>
                  );
                })}
                {items.length === 0 && (
                  <div className="text-center py-8 text-xs text-text-muted">
                    aucun projet
                  </div>
                )}
              </div>
            </GlassPanel>
          );
        })}
      </div>

      {/* Side panel detail */}
      {selected && (
        <div
          className="fixed inset-0 z-50 flex items-stretch justify-end bg-black/60 backdrop-blur-sm"
          onClick={() => setSelected(null)}
        >
          <div
            className="w-full max-w-xl glass-strong border-l border-cyan/30 overflow-y-auto p-6 animate-in"
            onClick={e => e.stopPropagation()}
          >
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <Badge tone="cyan">{stageLabels[selected.stage]}</Badge>
                <h3 className="text-2xl font-bold mt-2 leading-tight">{selected.name}</h3>
                <p className="text-sm text-text-secondary mt-1">{selected.sponsor} · {selected.pole}</p>
              </div>
              <button
                onClick={() => setSelected(null)}
                className="p-2 rounded-xl hover:bg-white/5 text-text-muted hover:text-text-primary transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-sm text-text-secondary leading-relaxed mb-6">{selected.description}</p>

            <div className="rounded-2xl bg-white/3 border border-white/5 p-4 mb-4">
              <div className="flex items-center gap-2 mb-2">
                <TrendingUp className="w-4 h-4 text-cyan" />
                <h4 className="text-sm font-semibold">Scorecard de maturité</h4>
                <span className="ml-auto text-xs px-2 py-0.5 rounded-full bg-cyan/15 text-cyan font-bold">
                  {Math.round(maturityScore(selected) * 100)} / 100
                </span>
              </div>
              <ScorecardRadar scorecard={selected.scorecard} size={260} />
            </div>

            <div className="grid grid-cols-2 gap-3 text-sm">
              <div className="p-3 rounded-xl bg-white/3 border border-white/5">
                <p className="text-xs text-text-muted">Date d&apos;idéation</p>
                <p className="font-medium mt-1">{new Date(selected.ideationDate).toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" })}</p>
              </div>
              <div className="p-3 rounded-xl bg-white/3 border border-white/5">
                <p className="text-xs text-text-muted">Pôle parrain</p>
                <p className="font-medium mt-1">{selected.pole}</p>
              </div>
            </div>

            <div className="mt-6 flex items-center gap-3">
              <button
                onClick={() => promote(selected)}
                disabled={stageOrder.indexOf(selected.stage) >= stageOrder.length - 1}
                className="flex-1 px-4 py-2.5 rounded-xl bg-cyan text-bleu-ipd font-semibold text-sm hover:bg-cyan-soft transition flex items-center justify-center gap-2 disabled:opacity-40 disabled:cursor-not-allowed"
              >
                Promouvoir au stade suivant
                <ChevronRight className="w-4 h-4" />
              </button>
              <button
                onClick={() => requestReview(selected)}
                className="px-4 py-2.5 rounded-xl border border-white/10 text-text-secondary hover:bg-white/5 text-sm"
              >
                Demander revue
              </button>
            </div>
          </div>
        </div>
      )}

      {toast && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-[60] glass-strong rounded-xl px-4 py-3 shadow-2xl flex items-center gap-3 animate-in min-w-[280px]">
          <div className={cn(
            "w-8 h-8 rounded-full flex items-center justify-center shrink-0",
            toast.tone === "success" ? "bg-vert/20 text-vert" : "bg-cyan/20 text-cyan",
          )}>
            <CheckCircle2 className="w-4 h-4" />
          </div>
          <p className="text-sm text-text-primary">{toast.message}</p>
        </div>
      )}

      {showNewModal && (
        <NewProjectModal
          onClose={() => setShowNewModal(false)}
          onCreate={createProject}
        />
      )}
    </>
  );
}

interface NewProjectModalProps {
  onClose: () => void;
  onCreate: (data: { name: string; sponsor: string; pole: Pole; description: string }) => void;
}

function NewProjectModal({ onClose, onCreate }: NewProjectModalProps) {
  const [name, setName] = useState("");
  const [sponsor, setSponsor] = useState("");
  const [pole, setPole] = useState<Pole>("MADIBA");
  const [description, setDescription] = useState("");

  const submit = (e: FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !sponsor.trim()) return;
    onCreate({ name: name.trim(), sponsor: sponsor.trim(), pole, description: description.trim() });
  };

  return (
    <div
      className="fixed inset-0 z-[70] flex items-center justify-center bg-black/65 backdrop-blur-sm p-4"
      onClick={onClose}
    >
      <div
        className="w-full max-w-lg glass-strong rounded-2xl p-6 border border-cyan/30"
        onClick={e => e.stopPropagation()}
      >
        <div className="flex items-start justify-between mb-5">
          <div>
            <div className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-violet/15 border border-violet/40 text-violet-pale text-[10px] uppercase tracking-wider font-semibold mb-2">
              <Plus className="w-3 h-3" /> Nouveau projet
            </div>
            <h3 className="text-xl font-bold leading-tight">Inscrire un projet en Idéation</h3>
            <p className="text-xs text-text-muted mt-1">Le projet entre dans la Cellule de Maturation. La scorecard sera enrichie ensuite.</p>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl hover:bg-white/5 text-text-muted hover:text-text-primary transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={submit} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-text-secondary mb-1.5 uppercase tracking-wider">
              Nom du projet *
            </label>
            <input
              required
              value={name}
              onChange={e => setName(e.target.value)}
              placeholder="ex. Plateforme d'analyse multi-omique"
              className="w-full px-3 py-2.5 rounded-xl bg-white/5 border border-white/10 text-sm outline-none focus:border-cyan/50 transition placeholder:text-text-muted"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-text-secondary mb-1.5 uppercase tracking-wider">
                Sponsor *
              </label>
              <input
                required
                value={sponsor}
                onChange={e => setSponsor(e.target.value)}
                placeholder="Dr. ..."
                className="w-full px-3 py-2.5 rounded-xl bg-white/5 border border-white/10 text-sm outline-none focus:border-cyan/50 transition placeholder:text-text-muted"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-text-secondary mb-1.5 uppercase tracking-wider">
                Pôle parrain
              </label>
              <select
                value={pole}
                onChange={e => setPole(e.target.value as Pole)}
                className="w-full px-3 py-2.5 rounded-xl bg-white/5 border border-white/10 text-sm outline-none focus:border-cyan/50 transition"
              >
                <option value="MADIBA">MADIBA</option>
                <option value="Grant Office">Grant Office</option>
                <option value="Cabinet AG">Cabinet AG</option>
                <option value="Maturation">Maturation</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-text-secondary mb-1.5 uppercase tracking-wider">
              Description
            </label>
            <textarea
              rows={3}
              value={description}
              onChange={e => setDescription(e.target.value)}
              placeholder="Vision, problème adressé, alignement stratégique…"
              className="w-full px-3 py-2.5 rounded-xl bg-white/5 border border-white/10 text-sm outline-none focus:border-cyan/50 transition placeholder:text-text-muted resize-none"
            />
          </div>

          <div className="flex items-center gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-2.5 rounded-xl border border-white/10 text-text-secondary hover:bg-white/5 text-sm font-medium"
            >
              Annuler
            </button>
            <button
              type="submit"
              className="flex-1 px-4 py-2.5 rounded-xl bg-gradient-to-r from-bleu-ipd to-cyan text-white font-semibold text-sm hover:shadow-lg hover:shadow-bleu-ipd/30 transition"
            >
              Créer le projet
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
