"use client";

import { Radar, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, ResponsiveContainer } from "recharts";

interface ScorecardRadarProps {
  scorecard: {
    vision: number;
    technique: number;
    financier: number;
    risques: number;
    equipe: number;
    me: number;
  };
  size?: number;
}

export function ScorecardRadar({ scorecard, size = 220 }: ScorecardRadarProps) {
  const data = [
    { dim: "Vision", value: scorecard.vision * 100 },
    { dim: "Technique", value: scorecard.technique * 100 },
    { dim: "Financier", value: scorecard.financier * 100 },
    { dim: "Risques", value: scorecard.risques * 100 },
    { dim: "Équipe", value: scorecard.equipe * 100 },
    { dim: "M&E", value: scorecard.me * 100 },
  ];

  return (
    <div style={{ height: size, width: "100%" }}>
      <ResponsiveContainer width="100%" height="100%">
        <RadarChart data={data} cx="50%" cy="50%" outerRadius="75%">
          <PolarGrid stroke="rgba(0,212,255,0.15)" />
          <PolarAngleAxis dataKey="dim" tick={{ fill: "#A8B8CC", fontSize: 10 }} />
          <PolarRadiusAxis domain={[0, 100]} tick={{ fill: "#6B7A90", fontSize: 9 }} stroke="rgba(255,255,255,0.05)" />
          <Radar dataKey="value" stroke="#00D4FF" fill="#00D4FF" fillOpacity={0.25} strokeWidth={2} />
        </RadarChart>
      </ResponsiveContainer>
    </div>
  );
}
