"use client";

import { Plus } from "lucide-react";

export function NewProjectButton() {
  return (
    <button
      onClick={() => window.dispatchEvent(new CustomEvent("open-new-maturation-project"))}
      className="flex items-center gap-2 px-4 py-2 rounded-xl bg-cyan text-bleu-ipd font-medium text-sm hover:bg-cyan-soft transition"
    >
      <Plus className="w-4 h-4" />
      Nouveau projet
    </button>
  );
}
