"use client";

import { useState, FormEvent } from "react";
import Link from "next/link";
import { Plus, X, Sprout, ExternalLink } from "lucide-react";
import { cn } from "@/lib/utils";

export function NewGrantButton() {
  const [open, setOpen] = useState(false);

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        className="flex items-center gap-2 px-4 py-2 rounded-xl bg-cyan text-bleu-ipd font-medium text-sm hover:bg-cyan-soft transition"
      >
        <Plus className="w-4 h-4" />
        Nouveau grant
      </button>

      {open && (
        <div
          className="fixed inset-0 z-[70] flex items-center justify-center bg-black/65 backdrop-blur-sm p-4"
          onClick={() => setOpen(false)}
        >
          <div
            className="w-full max-w-lg glass-strong rounded-2xl p-6 border border-cyan/30"
            onClick={e => e.stopPropagation()}
          >
            <div className="flex items-start justify-between mb-5">
              <div>
                <div className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-vert/15 border border-vert/40 text-vert text-[10px] uppercase tracking-wider font-semibold mb-2">
                  <Plus className="w-3 h-3" /> Inscrire un grant en pipeline
                </div>
                <h3 className="text-xl font-bold leading-tight">Référencer un nouvel appel à projets</h3>
                <p className="text-xs text-text-muted mt-1">
                  Le grant entre en veille avant qualification. Il sera promu via la Cellule de Maturation.
                </p>
              </div>
              <button
                onClick={() => setOpen(false)}
                className="p-2 rounded-xl hover:bg-white/5 text-text-muted hover:text-text-primary transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <NewGrantForm onClose={() => setOpen(false)} />
          </div>
        </div>
      )}
    </>
  );
}

function NewGrantForm({ onClose }: { onClose: () => void }) {
  const [title, setTitle] = useState("");
  const [bailleur, setBailleur] = useState("");
  const [amount, setAmount] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const submit = (e: FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !bailleur.trim()) return;
    setSubmitted(true);
    setTimeout(onClose, 2400);
  };

  if (submitted) {
    return (
      <div className="text-center py-6">
        <div className="w-12 h-12 mx-auto rounded-full bg-vert/20 text-vert flex items-center justify-center mb-3">
          <Plus className="w-6 h-6 rotate-45" />
        </div>
        <p className="text-sm font-medium mb-1">Grant inscrit en pipeline</p>
        <p className="text-xs text-text-muted leading-relaxed max-w-xs mx-auto">
          « {title} » est maintenant en veille. Routez-le vers la Cellule de Maturation pour qualification.
        </p>
        <Link
          href="/maturation"
          className="inline-flex items-center gap-1.5 mt-4 text-xs text-cyan hover:underline"
        >
          <Sprout className="w-3.5 h-3.5" />
          Aller à la Cellule de Maturation
          <ExternalLink className="w-3 h-3" />
        </Link>
      </div>
    );
  }

  return (
    <form onSubmit={submit} className="space-y-4">
      <div>
        <label className="block text-xs font-medium text-text-secondary mb-1.5 uppercase tracking-wider">
          Titre du grant *
        </label>
        <input
          required
          value={title}
          onChange={e => setTitle(e.target.value)}
          placeholder="ex. Renforcement plateforme génomique régionale"
          className="w-full px-3 py-2.5 rounded-xl bg-white/5 border border-white/10 text-sm outline-none focus:border-cyan/50 transition placeholder:text-text-muted"
        />
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="block text-xs font-medium text-text-secondary mb-1.5 uppercase tracking-wider">
            Bailleur *
          </label>
          <input
            required
            value={bailleur}
            onChange={e => setBailleur(e.target.value)}
            placeholder="ex. BMGF, AFD, EDCTP…"
            className="w-full px-3 py-2.5 rounded-xl bg-white/5 border border-white/10 text-sm outline-none focus:border-cyan/50 transition placeholder:text-text-muted"
          />
        </div>
        <div>
          <label className="block text-xs font-medium text-text-secondary mb-1.5 uppercase tracking-wider">
            Montant estimé
          </label>
          <input
            value={amount}
            onChange={e => setAmount(e.target.value)}
            placeholder="ex. 2 500 000 €"
            className="w-full px-3 py-2.5 rounded-xl bg-white/5 border border-white/10 text-sm outline-none focus:border-cyan/50 transition placeholder:text-text-muted"
          />
        </div>
      </div>

      <div className="flex items-center gap-3 pt-2">
        <button
          type="button"
          onClick={onClose}
          className={cn(
            "flex-1 px-4 py-2.5 rounded-xl border border-white/10 text-text-secondary hover:bg-white/5 text-sm font-medium",
          )}
        >
          Annuler
        </button>
        <button
          type="submit"
          className="flex-1 px-4 py-2.5 rounded-xl bg-gradient-to-r from-bleu-ipd to-cyan text-white font-semibold text-sm hover:shadow-lg hover:shadow-bleu-ipd/30 transition"
        >
          Inscrire en pipeline
        </button>
      </div>
    </form>
  );
}
