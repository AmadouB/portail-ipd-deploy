import Link from "next/link";
import { GlassPanel } from "@/components/ui/glass-panel";
import { Badge } from "@/components/ui/badge";
import { getProjectById } from "@/lib/data/projects";
import { getGrantById } from "@/lib/data/grants";
import type { VeilleBrief, VeilleCategory, VeilleItem } from "@/lib/types";
import { Microscope, Syringe, Banknote, Scale, Beaker, Radar, ExternalLink, ArrowRight } from "lucide-react";
import { cn } from "@/lib/utils";

const categoryConfig: Record<VeilleCategory, { label: string; icon: typeof Microscope; color: string; bg: string; border: string }> = {
  "épidémie":      { label: "Épidémies & alertes",     icon: Microscope, color: "text-rouge",       bg: "bg-rouge/8",    border: "border-rouge/30" },
  "vaccin":        { label: "Vaccins & production",    icon: Syringe,    color: "text-cyan",        bg: "bg-cyan/8",     border: "border-cyan/30" },
  "bailleur":      { label: "Bailleurs & financements", icon: Banknote,   color: "text-vert",        bg: "bg-vert/8",     border: "border-vert/30" },
  "réglementation":{ label: "Réglementation & normes", icon: Scale,      color: "text-bleu-clair",  bg: "bg-bleu-ipd/10", border: "border-bleu-ipd/40" },
  "recherche":     { label: "Recherche & publications", icon: Beaker,     color: "text-violet-pale", bg: "bg-violet/10",  border: "border-violet/30" },
  "signal-faible": { label: "Signaux faibles",         icon: Radar,      color: "text-orange",      bg: "bg-orange/8",   border: "border-orange/30" },
};

const relevanceTone = {
  high: "vert",
  medium: "cyan",
  low: "neutre",
} as const;

const relevanceLabel = {
  high: "Pertinence haute",
  medium: "Pertinence moyenne",
  low: "Pertinence basse",
};

const orderedCategories: VeilleCategory[] = [
  "épidémie",
  "bailleur",
  "vaccin",
  "réglementation",
  "recherche",
  "signal-faible",
];

interface BriefContentProps {
  brief: VeilleBrief;
}

export function BriefContent({ brief }: BriefContentProps) {
  const grouped = orderedCategories.map(cat => ({
    cat,
    items: brief.items.filter(i => i.category === cat),
  })).filter(g => g.items.length > 0);

  return (
    <div className="space-y-5">
      {/* Summary */}
      <GlassPanel variant="strong" className="p-5 border-l-2 border-l-bleu-ipd">
        <p className="text-[10px] uppercase tracking-widest text-bleu-clair font-semibold mb-1.5">
          En une phrase
        </p>
        <p className="text-base text-text-primary leading-relaxed">{brief.summary}</p>
        <p className="text-xs text-text-muted mt-3">
          Brief généré automatiquement le {new Date(brief.generatedAt).toLocaleString("fr-FR", {
            weekday: "long", day: "numeric", month: "long", year: "numeric", hour: "2-digit", minute: "2-digit"
          })} UTC
          · {brief.items.length} items
        </p>
      </GlassPanel>

      {/* Sections */}
      {grouped.map(({ cat, items }) => {
        const cfg = categoryConfig[cat];
        const Icon = cfg.icon;
        return (
          <section key={cat} className="space-y-3">
            <div className="flex items-center gap-3">
              <div className={cn("p-2 rounded-lg", cfg.bg, cfg.color)}>
                <Icon className="w-5 h-5" />
              </div>
              <div>
                <h2 className={cn("text-lg font-bold", cfg.color)}>{cfg.label}</h2>
                <p className="text-xs text-text-muted">{items.length} item{items.length > 1 ? "s" : ""}</p>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
              {items.map(item => (
                <BriefItemCard key={item.id} item={item} categoryColor={cfg.color} categoryBorder={cfg.border} />
              ))}
            </div>
          </section>
        );
      })}
    </div>
  );
}

function BriefItemCard({ item, categoryColor, categoryBorder }: { item: VeilleItem; categoryColor: string; categoryBorder: string }) {
  const linkedProject = item.linkedProjectId ? getProjectById(item.linkedProjectId) : undefined;
  const linkedGrant = item.linkedGrantId ? getGrantById(item.linkedGrantId) : undefined;

  return (
    <GlassPanel className={cn("p-4 transition hover:bg-glass-hover border-l-2", categoryBorder)}>
      <div className="flex items-start justify-between gap-3 mb-2">
        <h3 className="text-sm font-semibold text-text-primary leading-snug flex-1">{item.title}</h3>
        <Badge tone={relevanceTone[item.ipdRelevance]} className="shrink-0">{relevanceLabel[item.ipdRelevance]}</Badge>
      </div>

      <p className="text-sm text-text-secondary leading-relaxed mb-3">{item.summary}</p>

      <div className="flex items-center justify-between gap-2 flex-wrap pt-3 border-t border-white/5">
        <a
          href={item.sourceUrl}
          target="_blank"
          rel="noopener noreferrer"
          className={cn("flex items-center gap-1.5 text-xs font-medium hover:underline", categoryColor)}
        >
          {item.source}
          <ExternalLink className="w-3 h-3" />
        </a>
        <div className="flex items-center gap-1.5 flex-wrap">
          {item.tags.slice(0, 3).map(t => (
            <span key={t} className="text-[10px] px-1.5 py-0.5 rounded bg-white/5 text-text-muted">
              {t}
            </span>
          ))}
        </div>
      </div>

      {(linkedProject || linkedGrant) && (
        <div className="mt-3 pt-3 border-t border-white/5 space-y-1.5">
          {linkedProject && (
            <Link
              href={`/projects/${linkedProject.id}`}
              className="flex items-center justify-between gap-2 px-2.5 py-1.5 rounded-lg bg-bleu-ipd/10 hover:bg-bleu-ipd/20 border border-bleu-ipd/30 text-xs transition group"
            >
              <span className="flex items-center gap-2 text-bleu-clair font-medium truncate">
                <span className="text-[10px] uppercase tracking-wider opacity-75">Projet</span>
                <span className="truncate">{linkedProject.name}</span>
              </span>
              <ArrowRight className="w-3.5 h-3.5 text-bleu-clair shrink-0 group-hover:translate-x-0.5 transition" />
            </Link>
          )}
          {linkedGrant && (
            <Link
              href={`/grants/${linkedGrant.id}`}
              className="flex items-center justify-between gap-2 px-2.5 py-1.5 rounded-lg bg-vert/10 hover:bg-vert/20 border border-vert/30 text-xs transition group"
            >
              <span className="flex items-center gap-2 text-vert font-medium truncate">
                <span className="text-[10px] uppercase tracking-wider opacity-75">Grant</span>
                <span className="truncate">{linkedGrant.title}</span>
              </span>
              <ArrowRight className="w-3.5 h-3.5 text-vert shrink-0 group-hover:translate-x-0.5 transition" />
            </Link>
          )}
        </div>
      )}
    </GlassPanel>
  );
}
