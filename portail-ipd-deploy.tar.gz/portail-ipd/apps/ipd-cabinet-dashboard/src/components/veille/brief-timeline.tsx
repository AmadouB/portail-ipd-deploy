"use client";

import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { GlassPanel } from "@/components/ui/glass-panel";
import { Calendar, RefreshCcw } from "lucide-react";
import { cn } from "@/lib/utils";

interface BriefTimelineProps {
  dates: string[];
  selected: string;
  itemCounts: Record<string, number>;
}

const dayLabel = (iso: string) => {
  const d = new Date(iso);
  return d.toLocaleDateString("fr-FR", { weekday: "long", day: "numeric", month: "long" });
};

const isToday = (iso: string) => iso === new Date().toISOString().slice(0, 10);

export function BriefTimeline({ dates, selected, itemCounts }: BriefTimelineProps) {
  const searchParams = useSearchParams();

  return (
    <GlassPanel variant="strong" className="p-5 sticky top-6">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h2 className="text-lg font-semibold flex items-center gap-2">
            <Calendar className="w-5 h-5 text-bleu-ipd" />
            Briefs quotidiens
          </h2>
          <p className="text-xs text-text-muted mt-0.5">{dates.length} brief{dates.length > 1 ? "s" : ""} disponible{dates.length > 1 ? "s" : ""}</p>
        </div>
        <button
          onClick={() => window.location.reload()}
          className="p-2 rounded-lg hover:bg-white/5 text-text-muted hover:text-cyan transition"
          title="Recharger la liste"
        >
          <RefreshCcw className="w-4 h-4" />
        </button>
      </div>

      <div className="relative">
        <div className="absolute left-3 top-2 bottom-2 w-px bg-gradient-to-b from-bleu-ipd via-cyan/30 to-transparent" />
        <div className="space-y-2">
          {dates.map((d, idx) => {
            const active = d === selected;
            const today = isToday(d);
            const params = new URLSearchParams(searchParams);
            params.set("date", d);
            return (
              <Link
                key={d}
                href={`/veille?${params.toString()}`}
                className={cn(
                  "flex items-start gap-3 group relative",
                  active ? "" : "hover:opacity-100 opacity-80",
                )}
              >
                <div className={cn(
                  "relative w-7 h-7 rounded-full flex items-center justify-center border-2 z-10 shrink-0 transition",
                  active ? "bg-bleu-ipd border-cyan glow-ipd" : "bg-bg-surface border-white/20 group-hover:border-cyan/40",
                )}>
                  <span className={cn(
                    "text-[10px] font-bold tabular-nums",
                    active ? "text-white" : "text-text-secondary",
                  )}>
                    {idx === 0 ? "•" : `J-${idx}`}
                  </span>
                </div>
                <div className={cn(
                  "flex-1 min-w-0 px-3 py-2 rounded-xl border transition",
                  active
                    ? "bg-gradient-to-r from-bleu-ipd/15 to-transparent border-bleu-ipd/40"
                    : "bg-white/3 border-white/5 group-hover:bg-glass-hover group-hover:border-cyan/20",
                )}>
                  <div className="flex items-center justify-between gap-2">
                    <p className={cn(
                      "text-sm font-medium capitalize truncate",
                      active ? "text-text-primary" : "text-text-secondary",
                    )}>{dayLabel(d)}</p>
                    {today && (
                      <span className="text-[9px] uppercase tracking-wider px-1.5 py-0.5 rounded-full bg-cyan/15 border border-cyan/30 text-cyan font-bold whitespace-nowrap">
                        aujourd&apos;hui
                      </span>
                    )}
                  </div>
                  <p className="text-[11px] text-text-muted mt-0.5">{itemCounts[d]} items · 08:00 UTC</p>
                </div>
              </Link>
            );
          })}
        </div>
      </div>

      <div className="mt-5 pt-4 border-t border-white/5 text-[11px] text-text-muted leading-relaxed">
        Les briefs sont générés automatiquement chaque matin à <span className="text-bleu-clair font-semibold">08:00 UTC</span> par la routine
        <span className="text-cyan font-mono"> ipd-veille-quotidienne</span>.
      </div>
    </GlassPanel>
  );
}
