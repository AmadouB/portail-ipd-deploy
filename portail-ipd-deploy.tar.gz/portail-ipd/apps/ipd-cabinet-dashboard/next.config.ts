import type { NextConfig } from "next";
import path from "node:path";

// Allow basePath to be overridden via env (used in multi-app portail IPD).
// Default empty (no basePath) for local dev / Vercel; production SRV-SEID sets "/cabinet-ipd".
const basePath = process.env.NEXT_BASE_PATH ?? "";

const nextConfig: NextConfig = {
  output: "standalone",
  basePath: basePath || undefined,
  // Anchor the standalone trace on this project so the build doesn't try to
  // include the parent monorepo lockfile (we're not actually a monorepo).
  outputFileTracingRoot: path.resolve(),
  images: {
    unoptimized: true,
  },
};

export default nextConfig;
