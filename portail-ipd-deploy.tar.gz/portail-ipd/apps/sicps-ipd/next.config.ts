import type { NextConfig } from "next";

// Multi-app portal IPD : basePath injecte au build via NEXT_BASE_PATH (ex: /sicps).
// Si NEXT_BASE_PATH est defini, on build en mode export statique avec basePath.
const basePath = process.env.NEXT_BASE_PATH ?? "";
const isPortalBuild = basePath.length > 0;

const nextConfig: NextConfig = {
  trailingSlash: true,
  images: { unoptimized: true },
  ...(isPortalBuild && {
    output: "export",
    basePath,
    assetPrefix: basePath,
  }),
};

export default nextConfig;
