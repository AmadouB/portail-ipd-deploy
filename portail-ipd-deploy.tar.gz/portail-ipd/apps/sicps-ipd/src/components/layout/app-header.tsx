"use client";

import { useState, useRef, useEffect } from "react";
import { useRouter } from "next/navigation";
import { useThemeStore } from "@/stores/theme-store";
import { useLocaleStore } from "@/stores/locale-store";
import { useAuthStore } from "@/stores/auth-store";
import { useProspectStore } from "@/stores/prospect-store";
import { useTranslation } from "@/lib/i18n";
import {
  Search, Sun, Moon, Maximize, Minimize, Menu, Bell, Languages, LogOut, X,
  AlertTriangle, Target, Database, Clock,
} from "lucide-react";

interface AppHeaderProps {
  onMenuClick: () => void;
}

export function AppHeader({ onMenuClick }: AppHeaderProps) {
  const router = useRouter();
  const { theme, toggleTheme, isFullscreen, toggleFullscreen } = useThemeStore();
  const { locale, toggleLocale } = useLocaleStore();
  const session = useAuthStore((s) => s.session);
  const logout = useAuthStore((s) => s.logout);
  const prospects = useProspectStore((s) => s.prospects);
  const { t } = useTranslation();

  const [searchQuery, setSearchQuery] = useState("");
  const [showNotifications, setShowNotifications] = useState(false);
  const [searchFocused, setSearchFocused] = useState(false);
  const notifRef = useRef<HTMLDivElement>(null);
  const searchRef = useRef<HTMLDivElement>(null);

  const user = session?.user;
  const initials = user
    ? `${user.firstName.charAt(0)}${user.lastName.charAt(0)}`
    : "??";
  const displayName = user
    ? `${user.firstName.charAt(0)}. ${user.lastName}`
    : "";
  const roleLabels: Record<string, string> = { admin: "Administrateur", analyst: "Analyste", viewer: "Lecteur" };

  // Compute alerts
  const alerts = (() => {
    const items: { id: string; icon: React.ReactNode; title: string; count: number; color: string }[] = [];
    const unscored = prospects.filter((p) => p.scoringTier === "unscored").length;
    if (unscored > 0) items.push({ id: "unscored", icon: <Target className="w-3.5 h-3.5" />, title: locale === "fr" ? `${unscored} prospects à scorer` : `${unscored} prospects to score`, count: unscored, color: "#8b5cf6" });
    const stale = prospects.filter((p) => p.dataFreshness === "stale").length;
    if (stale > 0) items.push({ id: "stale", icon: <Database className="w-3.5 h-3.5" />, title: locale === "fr" ? `${stale} données obsolètes` : `${stale} stale data records`, count: stale, color: "#ef4444" });
    const noPipeline = prospects.filter((p) => !p.pipelinePhase).length;
    if (noPipeline > 0) items.push({ id: "nopipe", icon: <Clock className="w-3.5 h-3.5" />, title: locale === "fr" ? `${noPipeline} sans phase pipeline` : `${noPipeline} without pipeline phase`, count: noPipeline, color: "#3b82f6" });
    const knownIdle = prospects.filter((p) => p.knownToIPD === true && (!p.pipelinePhase || p.pipelinePhase === "insight")).length;
    if (knownIdle > 0) items.push({ id: "kidle", icon: <AlertTriangle className="w-3.5 h-3.5" />, title: locale === "fr" ? `${knownIdle} contacts IPD inactifs` : `${knownIdle} IPD contacts idle`, count: knownIdle, color: "#f59e0b" });
    return items;
  })();

  // Search results (live)
  const searchResults = searchQuery.length >= 2
    ? prospects
        .filter((p) => {
          const q = searchQuery.toLowerCase();
          return p.organisation.toLowerCase().includes(q) ||
            p.type.toLowerCase().includes(q) ||
            p.delegates.some((d) => d.name.toLowerCase().includes(q)) ||
            p.countriesServed.some((c) => c.toLowerCase().includes(q));
        })
        .slice(0, 8)
    : [];

  // Click outside handlers
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (notifRef.current && !notifRef.current.contains(e.target as Node)) setShowNotifications(false);
      if (searchRef.current && !searchRef.current.contains(e.target as Node)) setSearchFocused(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  // Cmd+K shortcut
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        const input = document.getElementById("global-search-input") as HTMLInputElement | null;
        input?.focus();
      }
    };
    document.addEventListener("keydown", handler);
    return () => document.removeEventListener("keydown", handler);
  }, []);

  const goToProspect = (route: string) => {
    setSearchFocused(false);
    setSearchQuery("");
    router.push(route);
  };

  return (
    <header
      className="sticky top-0 z-30 flex items-center justify-between h-16 px-4 lg:px-6 border-b border-white/5 backdrop-blur-xl"
      style={{ backgroundColor: "var(--surface-header)" }}
    >
      {/* Left: Mobile menu + Search */}
      <div className="flex items-center gap-3 flex-1">
        <button
          onClick={onMenuClick}
          className="p-2 rounded-lg text-muted-foreground hover:text-white hover:bg-white/5 transition-all lg:hidden"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div ref={searchRef} className="hidden sm:flex items-center gap-2 flex-1 max-w-md relative">
          <div className="relative w-full">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <input
              id="global-search-input"
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onFocus={() => setSearchFocused(true)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && searchQuery.length >= 2) {
                  router.push(`/saisie`);
                  setSearchFocused(false);
                }
                if (e.key === "Escape") {
                  setSearchQuery("");
                  setSearchFocused(false);
                  (e.target as HTMLInputElement).blur();
                }
              }}
              placeholder={t("common.search")}
              className="w-full h-9 pl-9 pr-12 rounded-lg text-sm bg-white/5 border border-white/8 text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-[#00D4FF]/50 transition-all"
            />
            {searchQuery ? (
              <button
                onClick={() => setSearchQuery("")}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-white"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            ) : (
              <kbd className="absolute right-3 top-1/2 -translate-y-1/2 hidden md:inline-flex items-center gap-0.5 px-1.5 py-0.5 text-[10px] font-mono text-muted-foreground bg-white/5 rounded border border-white/10">
                ⌘K
              </kbd>
            )}
          </div>

          {/* Live search dropdown */}
          {searchFocused && searchQuery.length >= 2 && (
            <div className="absolute top-full left-0 right-0 mt-2 max-h-96 overflow-y-auto rounded-xl border border-white/10 bg-[#0D1117]/95 backdrop-blur-xl shadow-2xl z-50">
              {searchResults.length === 0 ? (
                <div className="p-4 text-center text-xs text-muted-foreground">
                  {locale === "fr" ? "Aucun résultat" : "No results"}
                </div>
              ) : (
                <>
                  <div className="px-3 py-2 text-[10px] uppercase font-semibold text-muted-foreground border-b border-white/5">
                    {searchResults.length} {locale === "fr" ? "résultats" : "results"}
                  </div>
                  {searchResults.map((p) => (
                    <button
                      key={p.id}
                      onClick={() => goToProspect("/saisie")}
                      className="w-full text-left px-3 py-2 hover:bg-white/5 transition-all border-b border-white/3 last:border-0"
                    >
                      <p className="text-sm font-medium truncate">{p.organisation}</p>
                      <p className="text-[10px] text-muted-foreground truncate">{p.type}</p>
                    </button>
                  ))}
                </>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Right: Actions */}
      <div className="flex items-center gap-1">
        {/* Language toggle */}
        <button
          onClick={toggleLocale}
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium text-muted-foreground hover:text-white hover:bg-white/5 transition-all"
          title={locale === "fr" ? "Switch to English" : "Passer en Francais"}
        >
          <Languages className="w-4 h-4" />
          <span className="uppercase font-mono">{locale}</span>
        </button>

        {/* Theme toggle */}
        <button
          onClick={toggleTheme}
          className="p-2 rounded-lg text-muted-foreground hover:text-white hover:bg-white/5 transition-all"
          title={theme === "dark" ? "Mode clair" : "Mode sombre"}
        >
          {theme === "dark" ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
        </button>

        {/* Fullscreen */}
        <button
          onClick={toggleFullscreen}
          className="hidden md:flex p-2 rounded-lg text-muted-foreground hover:text-white hover:bg-white/5 transition-all"
          title={isFullscreen ? (locale === "fr" ? "Quitter plein écran" : "Exit fullscreen") : (locale === "fr" ? "Plein écran" : "Fullscreen")}
        >
          {isFullscreen ? <Minimize className="w-4 h-4" /> : <Maximize className="w-4 h-4" />}
        </button>

        {/* Notifications */}
        <div ref={notifRef} className="relative">
          <button
            onClick={() => setShowNotifications(!showNotifications)}
            className="relative p-2 rounded-lg text-muted-foreground hover:text-white hover:bg-white/5 transition-all"
            title={locale === "fr" ? "Notifications" : "Notifications"}
          >
            <Bell className="w-4 h-4" />
            {alerts.length > 0 && (
              <span className="absolute top-1 right-1 min-w-[16px] h-4 px-1 flex items-center justify-center rounded-full bg-[#ef4444] text-white text-[9px] font-bold pulse-dot">
                {alerts.length}
              </span>
            )}
          </button>

          {showNotifications && (
            <div className="absolute right-0 top-full mt-2 w-80 rounded-xl border border-white/10 bg-[#0D1117]/95 backdrop-blur-xl shadow-2xl z-50">
              <div className="flex items-center justify-between px-4 py-3 border-b border-white/5">
                <h4 className="text-sm font-semibold">{locale === "fr" ? "Alertes" : "Alerts"}</h4>
                <span className="text-[10px] text-muted-foreground">{alerts.length} {locale === "fr" ? "actives" : "active"}</span>
              </div>
              <div className="max-h-96 overflow-y-auto">
                {alerts.length === 0 ? (
                  <div className="p-6 text-center text-xs text-muted-foreground">
                    {locale === "fr" ? "Aucune alerte" : "No alerts"}
                  </div>
                ) : (
                  alerts.map((a) => (
                    <button
                      key={a.id}
                      onClick={() => { router.push("/dashboard"); setShowNotifications(false); }}
                      className="w-full text-left flex items-center gap-3 px-4 py-3 hover:bg-white/5 transition-all border-b border-white/3 last:border-0"
                    >
                      <div className="flex items-center justify-center w-8 h-8 rounded-lg shrink-0" style={{ backgroundColor: `${a.color}15`, color: a.color }}>
                        {a.icon}
                      </div>
                      <p className="text-xs flex-1">{a.title}</p>
                      <span className="text-[10px] font-mono font-bold" style={{ color: a.color }}>{a.count}</span>
                    </button>
                  ))
                )}
              </div>
              <button
                onClick={() => { router.push("/dashboard"); setShowNotifications(false); }}
                className="w-full px-4 py-2.5 text-xs text-[#00D4FF] hover:bg-white/5 transition-all border-t border-white/5"
              >
                {locale === "fr" ? "Voir toutes les alertes →" : "View all alerts →"}
              </button>
            </div>
          )}
        </div>

        {/* User + Logout */}
        <div className="flex items-center gap-2 ml-2 pl-2 border-l border-white/10">
          <div className="flex items-center justify-center w-8 h-8 rounded-full bg-[#00D4FF]/20 text-[#00D4FF] text-xs font-bold">
            {initials}
          </div>
          <div className="hidden md:block">
            <p className="text-xs font-medium text-foreground">{displayName}</p>
            <p className="text-[10px] text-muted-foreground">{user ? roleLabels[user.role] || user.role : ""}</p>
          </div>
          <button
            onClick={logout}
            className="p-1.5 rounded-lg text-muted-foreground hover:text-red-400 hover:bg-red-500/10 transition-all"
            title={locale === "fr" ? "Se déconnecter" : "Sign out"}
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
}
