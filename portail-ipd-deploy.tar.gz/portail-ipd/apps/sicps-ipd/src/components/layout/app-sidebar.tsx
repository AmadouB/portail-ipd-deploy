"use client";

import { useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";
import { useTranslation } from "@/lib/i18n";
import { useThemeStore } from "@/stores/theme-store";
import { motion, AnimatePresence } from "framer-motion";
import {
  LayoutDashboard,
  Target,
  Globe,
  GitBranch,
  Network,
  DollarSign,
  Brain,
  ClipboardEdit,
  ChevronLeft,
  ChevronRight,
  Crosshair,
  X,
} from "lucide-react";

const iconMap: Record<string, React.ElementType> = {
  LayoutDashboard,
  Target,
  Globe,
  GitBranch,
  Network,
  DollarSign,
  Brain,
  ClipboardEdit,
};

interface NavItem {
  id: string;
  label: string;
  icon: string;
  route: string;
  color: string;
}

const navItems: NavItem[] = [
  { id: "dashboard", label: "nav.dashboard", icon: "LayoutDashboard", route: "/dashboard", color: "#00D4FF" },
  { id: "radar",     label: "nav.radar",     icon: "Target",          route: "/radar",     color: "#8b5cf6" },
  { id: "map",       label: "nav.map",       icon: "Globe",           route: "/map",       color: "#10b981" },
  { id: "pipeline",  label: "nav.pipeline",  icon: "GitBranch",       route: "/pipeline",  color: "#3b82f6" },
  { id: "network",   label: "nav.network",   icon: "Network",         route: "/network",   color: "#f59e0b" },
  { id: "capsight",  label: "nav.capsight",  icon: "DollarSign",      route: "/capsight",  color: "#ec4899" },
  { id: "saisie",    label: "nav.saisie",    icon: "ClipboardEdit",   route: "/saisie",    color: "#10b981" },
  { id: "advisor",   label: "nav.advisor",   icon: "Brain",           route: "/advisor",   color: "#00D4FF" },
];

interface AppSidebarProps {
  mobileOpen: boolean;
  onMobileClose: () => void;
}

export function AppSidebar({ mobileOpen, onMobileClose }: AppSidebarProps) {
  const [collapsed, setCollapsed] = useState(false);
  const pathname = usePathname();
  const { t } = useTranslation();
  const theme = useThemeStore((s) => s.theme);

  const sidebarContent = (
    <div className="flex flex-col h-full">
      {/* Logo IPD */}
      <Link href="/dashboard" className="flex items-center justify-center px-4 py-4 border-b border-white/5 hover:bg-white/3 transition-all">
        <Image
          src={theme === "dark" ? "/images/logo-ipd-dark.png" : "/images/logo-ipd-light.png"}
          alt="Institut Pasteur de Dakar"
          width={collapsed ? 36 : 150}
          height={collapsed ? 36 : 45}
          className="object-contain"
          priority
        />
      </Link>

      {/* Nav Items */}
      <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
        {navItems.map((item) => {
          const Icon = iconMap[item.icon] || LayoutDashboard;
          const isActive = pathname?.startsWith(item.route);

          return (
            <Link
              key={item.id}
              href={item.route}
              onClick={onMobileClose}
              className={cn(
                "flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm transition-all duration-200 group relative",
                isActive
                  ? "text-white"
                  : "text-muted-foreground hover:text-white hover:bg-white/5"
              )}
            >
              {/* Active indicator bar */}
              {isActive && (
                <motion.div
                  layoutId="sidebar-active"
                  className="absolute left-0 top-1/2 -translate-y-1/2 w-[3px] h-6 rounded-r-full"
                  style={{ backgroundColor: item.color }}
                  transition={{ type: "spring", stiffness: 350, damping: 30 }}
                />
              )}

              <div
                className={cn(
                  "flex items-center justify-center w-8 h-8 rounded-lg transition-all",
                  isActive ? "bg-white/10" : "group-hover:bg-white/5"
                )}
                style={isActive ? { backgroundColor: `${item.color}20` } : undefined}
              >
                <Icon
                  className="w-4.5 h-4.5 transition-colors"
                  style={isActive ? { color: item.color } : undefined}
                />
              </div>

              <AnimatePresence>
                {!collapsed && (
                  <motion.span
                    initial={{ opacity: 0, width: 0 }}
                    animate={{ opacity: 1, width: "auto" }}
                    exit={{ opacity: 0, width: 0 }}
                    className="overflow-hidden whitespace-nowrap font-medium"
                  >
                    {t(item.label)}
                  </motion.span>
                )}
              </AnimatePresence>
            </Link>
          );
        })}
      </nav>

      {/* Collapse toggle */}
      <div className="hidden lg:flex px-3 py-3 border-t border-white/5">
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="flex items-center justify-center w-full py-2 rounded-lg text-muted-foreground hover:text-white hover:bg-white/5 transition-all"
        >
          {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
        </button>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Sidebar */}
      <motion.aside
        className="hidden lg:flex flex-col h-screen sticky top-0 border-r border-white/5"
        style={{ backgroundColor: "var(--sidebar)" }}
        animate={{ width: collapsed ? 72 : 240 }}
        transition={{ duration: 0.3, ease: "easeInOut" }}
      >
        {sidebarContent}
      </motion.aside>

      {/* Mobile Overlay */}
      <AnimatePresence>
        {mobileOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={onMobileClose}
              className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 lg:hidden"
            />
            <motion.aside
              initial={{ x: -280 }}
              animate={{ x: 0 }}
              exit={{ x: -280 }}
              transition={{ type: "spring", stiffness: 300, damping: 30 }}
              className="fixed inset-y-0 left-0 w-[280px] z-50 lg:hidden border-r border-white/5"
              style={{ backgroundColor: "var(--sidebar)" }}
            >
              <button
                onClick={onMobileClose}
                className="absolute top-4 right-4 p-1 rounded-lg text-muted-foreground hover:text-white z-10"
              >
                <X className="w-5 h-5" />
              </button>
              {sidebarContent}
            </motion.aside>
          </>
        )}
      </AnimatePresence>
    </>
  );
}
