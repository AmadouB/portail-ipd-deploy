"use client";

import { useMemo } from "react";
import type { Prospect } from "@/types";
import { ORG_TYPE_COLORS } from "@/types";
import { useTranslation } from "@/lib/i18n";
import { GlassPanel } from "@/components/shared/glass-panel";
import { formatCurrency } from "@/lib/utils";
import {
  RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar,
  ScatterChart, Scatter, XAxis, YAxis, ZAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, Legend,
} from "recharts";

interface RadarVisualizationProps {
  prospects: Prospect[];
}

export function RadarVisualization({ prospects }: RadarVisualizationProps) {
  const { t, locale } = useTranslation();

  const scored = useMemo(() => prospects.filter((p) => p.scoringTier !== "unscored"), [prospects]);

  // Radar chart: average scores by type
  const radarData = useMemo(() => {
    const types = [...new Set(scored.map((p) => p.type))];
    return types.map((type) => {
      const group = scored.filter((p) => p.type === type);
      return {
        type: type.split(" / ")[0].split(" ")[0], // Short label
        affinity: group.reduce((s, p) => s + p.affinity, 0) / group.length,
        ability: group.reduce((s, p) => s + p.ability, 0) / group.length,
        access: group.reduce((s, p) => s + p.access, 0) / group.length,
      };
    });
  }, [scored]);

  // Bubble chart data
  const bubbleData = useMemo(() => {
    return scored.map((p) => ({
      x: p.affinity,
      y: p.ability,
      z: Math.max(100, (p.annualGiving || 100000) / 1000000),
      name: p.organisation,
      access: p.access,
      giving: p.annualGiving,
      type: p.type,
      fill: ORG_TYPE_COLORS[p.type] || "#64748b",
    }));
  }, [scored]);

  // Heatmap data
  const heatmapData = useMemo(() => {
    const grid: number[][] = Array.from({ length: 5 }, () => Array(5).fill(0));
    scored.forEach((p) => {
      if (p.affinity > 0 && p.ability > 0) {
        grid[p.affinity - 1][p.ability - 1]++;
      }
    });
    return grid;
  }, [scored]);

  if (scored.length === 0) {
    return (
      <GlassPanel className="flex items-center justify-center h-96">
        <p className="text-muted-foreground">
          {locale === "fr" ? "Aucun prospect score. Commencez par l'onglet Scoring." : "No scored prospects. Start with the Scoring tab."}
        </p>
      </GlassPanel>
    );
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Radar Chart */}
      <GlassPanel delay={0}>
        <h3 className="text-sm font-semibold text-muted-foreground uppercase mb-4">
          {locale === "fr" ? "Profil 3A par Type" : "3A Profile by Type"}
        </h3>
        <ResponsiveContainer width="100%" height={300}>
          <RadarChart data={radarData}>
            <PolarGrid stroke="rgba(255,255,255,0.08)" />
            <PolarAngleAxis dataKey="type" tick={{ fill: "rgba(255,255,255,0.6)", fontSize: 11 }} />
            <PolarRadiusAxis domain={[0, 5]} tick={{ fill: "rgba(255,255,255,0.4)", fontSize: 10 }} />
            <Radar name={t("radar.affinity")} dataKey="affinity" stroke="#8b5cf6" fill="#8b5cf6" fillOpacity={0.2} />
            <Radar name={t("radar.ability")} dataKey="ability" stroke="#10b981" fill="#10b981" fillOpacity={0.2} />
            <Radar name={t("radar.access")} dataKey="access" stroke="#f59e0b" fill="#f59e0b" fillOpacity={0.2} />
            <Legend wrapperStyle={{ fontSize: 12, color: "rgba(255,255,255,0.7)" }} />
          </RadarChart>
        </ResponsiveContainer>
      </GlassPanel>

      {/* Bubble Chart */}
      <GlassPanel delay={0.05}>
        <h3 className="text-sm font-semibold text-muted-foreground uppercase mb-4">
          {locale === "fr" ? "Affinite x Capacite (taille = Annual Giving)" : "Affinity x Ability (size = Annual Giving)"}
        </h3>
        <ResponsiveContainer width="100%" height={300}>
          <ScatterChart>
            <CartesianGrid stroke="rgba(255,255,255,0.06)" />
            <XAxis
              type="number"
              dataKey="x"
              name={t("radar.affinity")}
              domain={[0, 6]}
              tick={{ fill: "rgba(255,255,255,0.5)", fontSize: 11 }}
              label={{ value: t("radar.affinity"), position: "bottom", fill: "rgba(255,255,255,0.5)", fontSize: 11 }}
            />
            <YAxis
              type="number"
              dataKey="y"
              name={t("radar.ability")}
              domain={[0, 6]}
              tick={{ fill: "rgba(255,255,255,0.5)", fontSize: 11 }}
              label={{ value: t("radar.ability"), angle: -90, position: "left", fill: "rgba(255,255,255,0.5)", fontSize: 11 }}
            />
            <ZAxis type="number" dataKey="z" range={[40, 400]} />
            <Tooltip
              contentStyle={{ backgroundColor: "#161b22", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 12 }}
              formatter={(value: any, name: any) => [value, name]}
              labelFormatter={() => ""}
              content={({ payload }) => {
                if (!payload || !payload[0]) return null;
                const d = payload[0].payload;
                return (
                  <div className="p-3 text-xs space-y-1">
                    <p className="font-semibold text-sm">{d.name}</p>
                    <p>Affinity: {d.x} | Ability: {d.y}</p>
                    <p>Giving: {formatCurrency(d.giving, true)}</p>
                  </div>
                );
              }}
            />
            <Scatter data={bubbleData} />
          </ScatterChart>
        </ResponsiveContainer>
      </GlassPanel>

      {/* Heatmap */}
      <GlassPanel delay={0.1} className="lg:col-span-2">
        <h3 className="text-sm font-semibold text-muted-foreground uppercase mb-4">
          {locale === "fr" ? "Matrice Affinite x Capacite" : "Affinity x Ability Matrix"}
        </h3>
        <div className="flex items-center gap-2 mb-2">
          <span className="text-[10px] text-muted-foreground">{t("radar.ability")} →</span>
        </div>
        <div className="grid grid-cols-5 gap-1.5">
          {heatmapData.map((row, aff) =>
            row.map((count, abi) => {
              const intensity = count > 0 ? Math.min(1, count / 5) : 0;
              return (
                <div
                  key={`${aff}-${abi}`}
                  className="aspect-square rounded-lg flex items-center justify-center text-xs font-mono border border-white/5"
                  style={{
                    backgroundColor: count > 0
                      ? `rgba(139, 92, 246, ${0.1 + intensity * 0.6})`
                      : "rgba(255,255,255,0.02)",
                  }}
                  title={`Affinity ${aff + 1}, Ability ${abi + 1}: ${count}`}
                >
                  {count > 0 ? count : ""}
                </div>
              );
            })
          )}
        </div>
        <div className="flex items-center gap-2 mt-2">
          <span className="text-[10px] text-muted-foreground">↑ {t("radar.affinity")}</span>
        </div>
      </GlassPanel>
    </div>
  );
}
