"use client";

import { useState, useMemo } from "react";
import type { Prospect } from "@/types";
import { useTranslation } from "@/lib/i18n";
import { GlassPanel } from "@/components/shared/glass-panel";
import { StatusBadge } from "@/components/shared/status-badge";
import { formatCurrency } from "@/lib/utils";
import { ArrowUpDown, Search, Download } from "lucide-react";

interface RankedTableProps {
  prospects: Prospect[];
}

type SortKey = "totalScore" | "affinity" | "ability" | "access" | "annualGiving" | "organisation";

export function RankedTable({ prospects }: RankedTableProps) {
  const { t, locale } = useTranslation();
  const [sortKey, setSortKey] = useState<SortKey>("totalScore");
  const [sortDir, setSortDir] = useState<"asc" | "desc">("desc");
  const [search, setSearch] = useState("");

  const sorted = useMemo(() => {
    return [...prospects]
      .filter((p) =>
        p.organisation.toLowerCase().includes(search.toLowerCase()) ||
        p.type.toLowerCase().includes(search.toLowerCase())
      )
      .sort((a, b) => {
        let aVal: number | string = 0;
        let bVal: number | string = 0;
        if (sortKey === "organisation") {
          aVal = a.organisation;
          bVal = b.organisation;
          return sortDir === "asc" ? String(aVal).localeCompare(String(bVal)) : String(bVal).localeCompare(String(aVal));
        }
        aVal = sortKey === "annualGiving" ? (a.annualGiving || 0) : (a[sortKey] as number);
        bVal = sortKey === "annualGiving" ? (b.annualGiving || 0) : (b[sortKey] as number);
        return sortDir === "asc" ? (aVal as number) - (bVal as number) : (bVal as number) - (aVal as number);
      });
  }, [prospects, sortKey, sortDir, search]);

  const toggleSort = (key: SortKey) => {
    if (sortKey === key) {
      setSortDir(sortDir === "asc" ? "desc" : "asc");
    } else {
      setSortKey(key);
      setSortDir("desc");
    }
  };

  const exportCSV = () => {
    const headers = ["Rank", "Organisation", "Type", "Affinity", "Ability", "Access", "Total Score", "Annual Giving", "Tier"];
    const rows = sorted.map((p, i) => [
      i + 1, p.organisation, p.type, p.affinity, p.ability, p.access, p.totalScore,
      p.annualGiving || "", p.scoringTier,
    ]);
    const csv = [headers.join(","), ...rows.map((r) => r.join(","))].join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "sicps_rankings.csv";
    a.click();
  };

  const SortHeader = ({ label, sortKey: key }: { label: string; sortKey: SortKey }) => (
    <th
      className="py-2 px-3 cursor-pointer hover:text-white transition-colors group"
      onClick={() => toggleSort(key)}
    >
      <div className="flex items-center gap-1">
        {label}
        <ArrowUpDown className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity" />
      </div>
    </th>
  );

  return (
    <GlassPanel animate={false}>
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="relative flex-1 max-w-xs">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={t("common.search")}
            className="w-full h-9 pl-9 pr-4 rounded-lg text-sm bg-white/5 border border-white/8 focus:outline-none focus:ring-1 focus:ring-[#8b5cf6]/50"
          />
        </div>
        <button
          onClick={exportCSV}
          className="flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-medium text-muted-foreground hover:text-white bg-white/5 hover:bg-white/8 transition-all"
        >
          <Download className="w-3.5 h-3.5" />
          CSV
        </button>
      </div>

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-xs text-muted-foreground border-b border-white/5 text-left">
              <th className="py-2 px-3 w-10">#</th>
              <SortHeader label={t("common.organisation")} sortKey="organisation" />
              <SortHeader label={t("radar.affinity")} sortKey="affinity" />
              <SortHeader label={t("radar.ability")} sortKey="ability" />
              <SortHeader label={t("radar.access")} sortKey="access" />
              <SortHeader label={t("common.score")} sortKey="totalScore" />
              <SortHeader label="Annual Giving" sortKey="annualGiving" />
              <th className="py-2 px-3">Tier</th>
            </tr>
          </thead>
          <tbody>
            {sorted.map((p, i) => (
              <tr
                key={p.id}
                className="border-b border-white/3 hover:bg-white/3 transition-colors"
              >
                <td className="py-2 px-3 text-muted-foreground font-mono text-xs">{i + 1}</td>
                <td className="py-2 px-3 font-medium truncate max-w-[200px]">{p.organisation}</td>
                <td className="py-2 px-3 font-mono text-center" style={{ color: p.affinity > 0 ? "#8b5cf6" : undefined }}>
                  {p.affinity || "—"}
                </td>
                <td className="py-2 px-3 font-mono text-center" style={{ color: p.ability > 0 ? "#10b981" : undefined }}>
                  {p.ability || "—"}
                </td>
                <td className="py-2 px-3 font-mono text-center" style={{ color: p.access > 0 ? "#f59e0b" : undefined }}>
                  {p.access || "—"}
                </td>
                <td className="py-2 px-3 font-mono font-bold text-center">{p.totalScore || "—"}</td>
                <td className="py-2 px-3 font-mono text-right">{formatCurrency(p.annualGiving, true)}</td>
                <td className="py-2 px-3">
                  <StatusBadge variant="scoring" value={p.scoringTier} locale={locale} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </GlassPanel>
  );
}
