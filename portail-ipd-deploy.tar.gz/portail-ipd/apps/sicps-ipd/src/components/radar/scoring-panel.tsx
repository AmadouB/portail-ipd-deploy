"use client";

import { useState } from "react";
import type { Prospect } from "@/types";
import { ORG_TYPE_COLORS } from "@/types";
import { useProspectStore } from "@/stores/prospect-store";
import { useTranslation } from "@/lib/i18n";
import { GlassPanel } from "@/components/shared/glass-panel";
import { StatusBadge } from "@/components/shared/status-badge";
import { formatCurrency } from "@/lib/utils";
import { cn } from "@/lib/utils";
import { generateHeuristicScore } from "@/lib/scoring/heuristic-score";
import { Search, Sparkles, Check, ChevronRight, Target } from "lucide-react";

interface ScoringPanelProps {
  prospects: Prospect[];
}

const SCORE_COLORS = {
  affinity: "#8b5cf6",
  ability: "#10b981",
  access: "#f59e0b",
};

export function ScoringPanel({ prospects }: ScoringPanelProps) {
  const { t, locale } = useTranslation();
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [showUnscored, setShowUnscored] = useState(true);
  const [aiLoading, setAiLoading] = useState(false);
  const [aiScores, setAiScores] = useState<{ affinity: number; ability: number; access: number; rationale: string } | null>(null);
  const [editScores, setEditScores] = useState({ affinity: 0, ability: 0, access: 0 });

  const scoreProspect = useProspectStore((s) => s.scoreProspect);

  const filtered = prospects
    .filter((p) =>
      showUnscored ? p.scoringTier === "unscored" : true
    )
    .filter((p) =>
      p.organisation.toLowerCase().includes(search.toLowerCase()) ||
      p.type.toLowerCase().includes(search.toLowerCase())
    )
    .sort((a, b) => {
      if (a.scoringTier === "unscored" && b.scoringTier !== "unscored") return -1;
      if (a.scoringTier !== "unscored" && b.scoringTier === "unscored") return 1;
      return (b.annualGiving || 0) - (a.annualGiving || 0);
    });

  const selected = selectedId ? prospects.find((p) => p.id === selectedId) : null;

  const handleAiPreScore = async () => {
    if (!selected) return;
    setAiLoading(true);

    const fallback = () => {
      const score = generateHeuristicScore(selected);
      setAiScores(score);
      setEditScores({ affinity: score.affinity, ability: score.ability, access: score.access });
    };

    try {
      // Try server API first; fall back to client-side heuristic if unavailable (static export)
      const res = await fetch("/api/ai/score", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          organisation: selected.organisation,
          summary: selected.organisationSummary,
          type: selected.type,
          whyAligned: selected.whyAligned,
          annualGiving: selected.annualGiving,
          avgGrantSize: selected.avgGrantSize,
          knownToIPD: selected.knownToIPD,
          countriesServed: selected.countriesServed,
          confidence: selected.confidence,
        }),
      });
      if (res.ok) {
        const data = await res.json();
        setAiScores(data);
        setEditScores({ affinity: data.affinity, ability: data.ability, access: data.access });
      } else {
        fallback();
      }
    } catch {
      fallback();
    } finally {
      setAiLoading(false);
    }
  };

  const handleConfirmScore = () => {
    if (!selectedId) return;
    scoreProspect(selectedId, editScores.affinity, editScores.ability, editScores.access);
    setAiScores(null);
    // Move to next unscored
    const nextUnscored = prospects.find((p) => p.id !== selectedId && p.scoringTier === "unscored");
    if (nextUnscored) setSelectedId(nextUnscored.id);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
      {/* Left: Prospect List */}
      <div className="lg:col-span-4">
        <GlassPanel animate={false} className="h-[calc(100vh-280px)] flex flex-col">
          {/* Search & Filter */}
          <div className="space-y-3 mb-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder={t("common.search")}
                className="w-full h-9 pl-9 pr-4 rounded-lg text-sm bg-white/5 border border-white/8 focus:outline-none focus:ring-1 focus:ring-[#8b5cf6]/50"
              />
            </div>
            <label className="flex items-center gap-2 text-xs text-muted-foreground cursor-pointer">
              <input
                type="checkbox"
                checked={showUnscored}
                onChange={(e) => setShowUnscored(e.target.checked)}
                className="rounded border-white/20"
              />
              {locale === "fr" ? "Non scores uniquement" : "Unscored only"}
              <span className="ml-auto font-mono text-[#8b5cf6]">
                {filtered.length}
              </span>
            </label>
          </div>

          {/* Prospect List */}
          <div className="flex-1 overflow-y-auto space-y-1">
            {filtered.map((p) => (
              <button
                key={p.id}
                onClick={() => { setSelectedId(p.id); setAiScores(null); setEditScores({ affinity: p.affinity, ability: p.ability, access: p.access }); }}
                className={cn(
                  "w-full text-left px-3 py-2.5 rounded-lg transition-all",
                  selectedId === p.id
                    ? "bg-[#8b5cf6]/10 border border-[#8b5cf6]/30"
                    : "hover:bg-white/5 border border-transparent"
                )}
              >
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium truncate max-w-[180px]">{p.organisation}</span>
                  <StatusBadge variant="scoring" value={p.scoringTier} locale={locale} />
                </div>
                <div className="flex items-center justify-between mt-1">
                  <span className="text-[11px] text-muted-foreground truncate max-w-[150px]">{p.type}</span>
                  <span className="text-[11px] font-mono text-muted-foreground">{formatCurrency(p.annualGiving, true)}</span>
                </div>
              </button>
            ))}
          </div>
        </GlassPanel>
      </div>

      {/* Right: Scoring Detail */}
      <div className="lg:col-span-8">
        {selected ? (
          <GlassPanel animate={false} className="h-[calc(100vh-280px)] overflow-y-auto">
            {/* Prospect Header */}
            <div className="mb-6">
              <div className="flex items-center gap-2 mb-1">
                <div
                  className="w-3 h-3 rounded-full"
                  style={{ backgroundColor: ORG_TYPE_COLORS[selected.type] || "#64748b" }}
                />
                <h2 className="text-xl font-bold">{selected.organisation}</h2>
              </div>
              <div className="flex items-center gap-2 flex-wrap">
                <StatusBadge variant="scoring" value={selected.scoringTier} locale={locale} />
                <StatusBadge variant="funding" value={selected.fundingTier} locale={locale} />
                <StatusBadge variant="confidence" value={selected.confidence} locale={locale} />
                {selected.knownToIPD && (
                  <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                    Known to IPD
                  </span>
                )}
              </div>
            </div>

            {/* Summary */}
            <div className="mb-6 p-4 rounded-xl bg-white/3 border border-white/5">
              <h4 className="text-xs font-semibold text-muted-foreground uppercase mb-2">
                {locale === "fr" ? "Resume" : "Summary"}
              </h4>
              <p className="text-sm text-foreground/80 leading-relaxed">
                {selected.organisationSummary || "—"}
              </p>
              {selected.whyAligned && (
                <>
                  <h4 className="text-xs font-semibold text-muted-foreground uppercase mt-4 mb-2">
                    {locale === "fr" ? "Alignement avec l'IPD" : "Alignment with IPD"}
                  </h4>
                  <p className="text-sm text-[#8b5cf6]">{selected.whyAligned}</p>
                </>
              )}
            </div>

            {/* Financial Data */}
            <div className="grid grid-cols-3 gap-3 mb-6">
              <div className="p-3 rounded-xl bg-white/3 border border-white/5 text-center">
                <p className="text-[10px] text-muted-foreground uppercase">Annual Giving</p>
                <p className="text-lg font-bold font-mono">{formatCurrency(selected.annualGiving, true)}</p>
              </div>
              <div className="p-3 rounded-xl bg-white/3 border border-white/5 text-center">
                <p className="text-[10px] text-muted-foreground uppercase">Avg Grant</p>
                <p className="text-lg font-bold font-mono">{formatCurrency(selected.avgGrantSize, true)}</p>
              </div>
              <div className="p-3 rounded-xl bg-white/3 border border-white/5 text-center">
                <p className="text-[10px] text-muted-foreground uppercase"># Grants</p>
                <p className="text-lg font-bold font-mono">{selected.grantCount?.toLocaleString() || "N/A"}</p>
              </div>
            </div>

            {/* AI Pre-Score */}
            <div className="mb-6">
              <button
                onClick={handleAiPreScore}
                disabled={aiLoading}
                className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#8b5cf6]/10 border border-[#8b5cf6]/30 text-[#8b5cf6] font-medium text-sm hover:bg-[#8b5cf6]/20 transition-all disabled:opacity-50"
              >
                <Sparkles className="w-4 h-4" />
                {aiLoading
                  ? (locale === "fr" ? "Analyse IA en cours..." : "AI analysis in progress...")
                  : t("radar.aiPreScore")}
              </button>

              {aiScores && (
                <div className="mt-3 p-4 rounded-xl bg-[#8b5cf6]/5 border border-[#8b5cf6]/20">
                  <p className="text-xs text-muted-foreground mb-2">{locale === "fr" ? "Justification IA :" : "AI Rationale:"}</p>
                  <p className="text-sm text-foreground/80 italic">{aiScores.rationale}</p>
                </div>
              )}
            </div>

            {/* Score Buttons */}
            <div className="space-y-4 mb-6">
              {(["affinity", "ability", "access"] as const).map((dim) => (
                <div key={dim} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium" style={{ color: SCORE_COLORS[dim] }}>
                      {t(`radar.${dim}`)}
                    </span>
                    {aiScores && (
                      <span className="text-xs text-muted-foreground">
                        IA: {aiScores[dim]}/5
                      </span>
                    )}
                  </div>
                  <div className="flex gap-2">
                    {[1, 2, 3, 4, 5].map((score) => (
                      <button
                        key={score}
                        onClick={() =>
                          setEditScores((prev) => ({ ...prev, [dim]: score }))
                        }
                        className={cn(
                          "flex-1 py-2.5 rounded-lg text-sm font-bold transition-all border",
                          editScores[dim] === score
                            ? "text-white"
                            : "text-muted-foreground hover:text-white bg-white/3 border-white/5 hover:bg-white/8"
                        )}
                        style={
                          editScores[dim] === score
                            ? {
                                backgroundColor: `${SCORE_COLORS[dim]}20`,
                                borderColor: `${SCORE_COLORS[dim]}60`,
                                color: SCORE_COLORS[dim],
                              }
                            : undefined
                        }
                      >
                        {score}
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </div>

            {/* Confirm */}
            {(editScores.affinity > 0 || editScores.ability > 0 || editScores.access > 0) && (
              <button
                onClick={handleConfirmScore}
                className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-[#8b5cf6] text-white font-semibold text-sm hover:bg-[#7c3aed] transition-all"
              >
                <Check className="w-4 h-4" />
                {t("radar.confirmScore")}
              </button>
            )}
          </GlassPanel>
        ) : (
          <GlassPanel animate={false} className="h-[calc(100vh-280px)] flex items-center justify-center">
            <div className="text-center">
              <Target className="w-16 h-16 mx-auto text-[#8b5cf6]/30 mb-4" />
              <p className="text-lg font-medium text-muted-foreground">
                {locale === "fr" ? "Selectionnez un prospect" : "Select a prospect"}
              </p>
              <p className="text-sm text-muted-foreground/50 mt-1">
                {locale === "fr" ? "pour commencer le scoring 3A" : "to start 3A scoring"}
              </p>
            </div>
          </GlassPanel>
        )}
      </div>
    </div>
  );
}
