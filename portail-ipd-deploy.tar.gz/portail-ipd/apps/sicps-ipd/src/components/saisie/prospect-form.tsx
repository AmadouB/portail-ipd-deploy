"use client";

import { useState } from "react";
import { useProspectStore } from "@/stores/prospect-store";
import { useTranslation } from "@/lib/i18n";
import { GlassPanel } from "@/components/shared/glass-panel";
import { ALL_ORGANISATION_TYPES, ALL_CONFIDENCE_LEVELS, type Prospect, type OrganisationType, type ConfidenceLevel } from "@/types";
import { classifyFundingTier, calculateDataFreshness } from "@/lib/scoring/tier-classifier";
import { slugify, generateId } from "@/lib/utils";
import { Save, X } from "lucide-react";

interface ProspectFormProps {
  /** If provided, edit mode; otherwise create mode */
  initialData?: Prospect;
  onSaved: () => void;
  onCancel: () => void;
}

interface FormData {
  organisation: string;
  organisationSummary: string;
  type: OrganisationType;
  knownToIPD: string;
  whyAligned: string;
  annualGiving: string;
  avgGrantSize: string;
  grantCount: string;
  dataYear: string;
  dataSource: string;
  confidence: ConfidenceLevel;
  countriesServed: string;
  delegatesRaw: string;
  contactPerson: string;
  nextActionDate: string;
  nextActionDescription: string;
}

function toFormData(p?: Prospect): FormData {
  if (!p) return {
    organisation: "",
    organisationSummary: "",
    type: "Major Grant-Making Foundation",
    knownToIPD: "",
    whyAligned: "",
    annualGiving: "",
    avgGrantSize: "",
    grantCount: "",
    dataYear: new Date().getFullYear().toString(),
    dataSource: "",
    confidence: "Medium",
    countriesServed: "",
    delegatesRaw: "",
    contactPerson: "",
    nextActionDate: "",
    nextActionDescription: "",
  };

  return {
    organisation: p.organisation,
    organisationSummary: p.organisationSummary,
    type: p.type,
    knownToIPD: p.knownToIPD === true ? "yes" : p.knownToIPD === false ? "no" : "",
    whyAligned: p.whyAligned,
    annualGiving: p.annualGiving?.toString() || "",
    avgGrantSize: p.avgGrantSize?.toString() || "",
    grantCount: p.grantCount?.toString() || "",
    dataYear: p.dataYear?.toString() || "",
    dataSource: p.dataSource,
    confidence: p.confidence,
    countriesServed: p.countriesServed.join(", "),
    delegatesRaw: p.delegatesRaw,
    contactPerson: p.contactPerson || "",
    nextActionDate: p.nextActionDate || "",
    nextActionDescription: p.nextActionDescription || "",
  };
}

export function ProspectForm({ initialData, onSaved, onCancel }: ProspectFormProps) {
  const { locale } = useTranslation();
  const addProspect = useProspectStore((s) => s.addProspect);
  const updateProspect = useProspectStore((s) => s.updateProspect);
  const [form, setForm] = useState<FormData>(toFormData(initialData));
  const [errors, setErrors] = useState<Record<string, string>>({});

  const isEdit = !!initialData;

  const set = (key: keyof FormData, value: string) => {
    setForm((prev) => ({ ...prev, [key]: value }));
    if (errors[key]) setErrors((prev) => { const { [key]: _, ...rest } = prev; return rest; });
  };

  const validate = (): boolean => {
    const errs: Record<string, string> = {};
    if (!form.organisation.trim()) errs.organisation = locale === "fr" ? "Obligatoire" : "Required";
    if (!form.type) errs.type = locale === "fr" ? "Obligatoire" : "Required";
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = () => {
    if (!validate()) return;

    const annualGiving = form.annualGiving ? Number(form.annualGiving.replace(/[^0-9.]/g, "")) : null;
    const avgGrantSize = form.avgGrantSize ? Number(form.avgGrantSize.replace(/[^0-9.]/g, "")) : null;
    const grantCount = form.grantCount ? parseInt(form.grantCount) : null;
    const dataYear = form.dataYear ? parseInt(form.dataYear) : null;
    const countriesServed = form.countriesServed.split(",").map((c) => c.trim()).filter(Boolean);
    const knownToIPD = form.knownToIPD === "yes" ? true : form.knownToIPD === "no" ? false : null;
    const now = new Date().toISOString();

    if (isEdit && initialData) {
      updateProspect(initialData.id, {
        organisation: form.organisation.trim(),
        organisationSummary: form.organisationSummary.trim(),
        type: form.type,
        knownToIPD,
        whyAligned: form.whyAligned.trim(),
        annualGiving,
        avgGrantSize,
        grantCount,
        dataYear,
        dataSource: form.dataSource.trim(),
        confidence: form.confidence,
        countriesServed,
        countriesServedRaw: form.countriesServed,
        delegatesRaw: form.delegatesRaw,
        contactPerson: form.contactPerson.trim() || undefined,
        nextActionDate: form.nextActionDate || undefined,
        nextActionDescription: form.nextActionDescription.trim() || undefined,
        fundingTier: classifyFundingTier(annualGiving),
        dataFreshness: calculateDataFreshness(dataYear),
      });
    } else {
      const id = slugify(form.organisation.trim()) || generateId();
      const prospect: Prospect = {
        id,
        organisation: form.organisation.trim(),
        organisationSummary: form.organisationSummary.trim(),
        type: form.type,
        knownToIPD,
        delegatesRaw: form.delegatesRaw,
        delegates: [],
        whyAligned: form.whyAligned.trim(),
        annualGiving,
        avgGrantSize,
        grantCount,
        dataYear,
        dataSource: form.dataSource.trim(),
        confidence: form.confidence,
        countriesServedRaw: form.countriesServed,
        countriesServed,
        affinity: 0,
        ability: 0,
        access: 0,
        totalScore: 0,
        fundingTier: classifyFundingTier(annualGiving),
        scoringTier: "unscored",
        dataFreshness: calculateDataFreshness(dataYear),
        contactPerson: form.contactPerson.trim() || undefined,
        nextActionDate: form.nextActionDate || undefined,
        nextActionDescription: form.nextActionDescription.trim() || undefined,
        prospectionNotes: [],
        createdAt: now,
        updatedAt: now,
      };
      addProspect(prospect);
    }

    onSaved();
  };

  const Field = ({ label, required, error, children }: { label: string; required?: boolean; error?: string; children: React.ReactNode }) => (
    <div>
      <label className="block text-xs font-medium text-muted-foreground mb-1.5">
        {label} {required && <span className="text-red-400">*</span>}
      </label>
      {children}
      {error && <p className="text-[11px] text-red-400 mt-1">{error}</p>}
    </div>
  );

  const inputClass = "w-full h-9 px-3 rounded-lg text-sm bg-white/5 border border-white/8 text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-1 focus:ring-[#10b981]/50 transition-all";
  const textareaClass = "w-full px-3 py-2 rounded-lg text-sm bg-white/5 border border-white/8 text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-1 focus:ring-[#10b981]/50 resize-none transition-all";

  return (
    <GlassPanel animate={false}>
      <h2 className="text-lg font-bold mb-6">
        {isEdit
          ? (locale === "fr" ? "Modifier le prospect" : "Edit prospect")
          : (locale === "fr" ? "Nouveau prospect" : "New prospect")
        }
      </h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-4">
        {/* === Identity Section === */}
        <div className="md:col-span-2">
          <p className="text-xs font-semibold text-[#10b981] uppercase tracking-wider mb-3">
            {locale === "fr" ? "Identite" : "Identity"}
          </p>
        </div>

        <Field label="Organisation" required error={errors.organisation}>
          <input type="text" value={form.organisation} onChange={(e) => set("organisation", e.target.value)} className={inputClass} placeholder="Ex: Gates Foundation" />
        </Field>

        <Field label={locale === "fr" ? "Type d'organisation" : "Organisation Type"} required error={errors.type}>
          <select value={form.type} onChange={(e) => set("type", e.target.value as OrganisationType)} className={inputClass}>
            {ALL_ORGANISATION_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
          </select>
        </Field>

        <Field label={locale === "fr" ? "Resume de l'organisation" : "Organisation Summary"}>
          <textarea value={form.organisationSummary} onChange={(e) => set("organisationSummary", e.target.value)} className={textareaClass} rows={3} placeholder={locale === "fr" ? "Description de l'organisation..." : "Organisation description..."} />
        </Field>

        <Field label={locale === "fr" ? "Pourquoi aligne avec l'IPD" : "Why Aligned with IPD"}>
          <textarea value={form.whyAligned} onChange={(e) => set("whyAligned", e.target.value)} className={textareaClass} rows={3} placeholder={locale === "fr" ? "Raisons d'alignement strategique..." : "Strategic alignment reasons..."} />
        </Field>

        {/* === Financial Section === */}
        <div className="md:col-span-2 mt-2">
          <p className="text-xs font-semibold text-[#ec4899] uppercase tracking-wider mb-3">
            {locale === "fr" ? "Donnees financieres" : "Financial Data"}
          </p>
        </div>

        <Field label="Annual Giving (USD)">
          <input type="text" value={form.annualGiving} onChange={(e) => set("annualGiving", e.target.value)} className={inputClass} placeholder="Ex: 7700000000" />
        </Field>

        <Field label="Avg Grant Size (USD)">
          <input type="text" value={form.avgGrantSize} onChange={(e) => set("avgGrantSize", e.target.value)} className={inputClass} placeholder="Ex: 500000" />
        </Field>

        <Field label={locale === "fr" ? "Nombre de grants" : "# Grants"}>
          <input type="text" value={form.grantCount} onChange={(e) => set("grantCount", e.target.value)} className={inputClass} placeholder="Ex: 150" />
        </Field>

        <Field label={locale === "fr" ? "Niveau de confiance" : "Confidence Level"}>
          <select value={form.confidence} onChange={(e) => set("confidence", e.target.value as ConfidenceLevel)} className={inputClass}>
            {ALL_CONFIDENCE_LEVELS.map((c) => <option key={c} value={c}>{c}</option>)}
          </select>
        </Field>

        {/* === Metadata Section === */}
        <div className="md:col-span-2 mt-2">
          <p className="text-xs font-semibold text-[#f59e0b] uppercase tracking-wider mb-3">
            {locale === "fr" ? "Metadonnees & Geographie" : "Metadata & Geography"}
          </p>
        </div>

        <Field label={locale === "fr" ? "Annee des donnees" : "Data Year"}>
          <input type="text" value={form.dataYear} onChange={(e) => set("dataYear", e.target.value)} className={inputClass} placeholder="Ex: 2024" />
        </Field>

        <Field label={locale === "fr" ? "Source des donnees" : "Data Source"}>
          <input type="text" value={form.dataSource} onChange={(e) => set("dataSource", e.target.value)} className={inputClass} placeholder="Ex: 990-PF, Annual Report" />
        </Field>

        <Field label={locale === "fr" ? "Connu de l'IPD ?" : "Known to IPD?"}>
          <select value={form.knownToIPD} onChange={(e) => set("knownToIPD", e.target.value)} className={inputClass}>
            <option value="">{locale === "fr" ? "Non renseigne" : "Not specified"}</option>
            <option value="yes">{locale === "fr" ? "Oui" : "Yes"}</option>
            <option value="no">{locale === "fr" ? "Non" : "No"}</option>
          </select>
        </Field>

        <Field label={locale === "fr" ? "Pays desservis (separes par virgule)" : "Countries Served (comma-separated)"}>
          <input type="text" value={form.countriesServed} onChange={(e) => set("countriesServed", e.target.value)} className={inputClass} placeholder="Ex: Senegal, Nigeria, Kenya" />
        </Field>

        {/* === Delegates & Contacts Section === */}
        <div className="md:col-span-2 mt-2">
          <p className="text-xs font-semibold text-[#3b82f6] uppercase tracking-wider mb-3">
            {locale === "fr" ? "Delegues & Contact" : "Delegates & Contact"}
          </p>
        </div>

        <Field label={locale === "fr" ? "Delegues (un par ligne)" : "Delegates (one per line)"}>
          <textarea value={form.delegatesRaw} onChange={(e) => set("delegatesRaw", e.target.value)} className={textareaClass} rows={3} placeholder={locale === "fr" ? "Nom (Titre) [Date ajout]\nEx: John Doe (Director) [2026-03-23]" : "Name (Title) [Added Date]\nEx: John Doe (Director) [2026-03-23]"} />
        </Field>

        <Field label={locale === "fr" ? "Personne de contact IPD" : "IPD Contact Person"}>
          <input type="text" value={form.contactPerson} onChange={(e) => set("contactPerson", e.target.value)} className={inputClass} placeholder={locale === "fr" ? "Responsable IPD pour ce prospect" : "IPD responsible for this prospect"} />
        </Field>

        {/* === Next Action Section === */}
        <div className="md:col-span-2 mt-2">
          <p className="text-xs font-semibold text-[#8b5cf6] uppercase tracking-wider mb-3">
            {locale === "fr" ? "Prochaine action" : "Next Action"}
          </p>
        </div>

        <Field label={locale === "fr" ? "Date prochaine action" : "Next Action Date"}>
          <input type="date" value={form.nextActionDate} onChange={(e) => set("nextActionDate", e.target.value)} className={inputClass} />
        </Field>

        <Field label={locale === "fr" ? "Description prochaine action" : "Next Action Description"}>
          <input type="text" value={form.nextActionDescription} onChange={(e) => set("nextActionDescription", e.target.value)} className={inputClass} placeholder={locale === "fr" ? "Ex: Envoyer proposition de partenariat" : "Ex: Send partnership proposal"} />
        </Field>
      </div>

      {/* Actions */}
      <div className="flex items-center justify-end gap-3 mt-8 pt-6 border-t border-white/5">
        <button
          onClick={onCancel}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium text-muted-foreground hover:text-white bg-white/5 hover:bg-white/8 transition-all"
        >
          <X className="w-4 h-4" />
          {locale === "fr" ? "Annuler" : "Cancel"}
        </button>
        <button
          onClick={handleSubmit}
          className="flex items-center gap-2 px-6 py-2.5 rounded-xl text-sm font-medium text-white bg-[#10b981] hover:bg-[#059669] transition-all"
        >
          <Save className="w-4 h-4" />
          {isEdit
            ? (locale === "fr" ? "Mettre a jour" : "Update")
            : (locale === "fr" ? "Creer le prospect" : "Create Prospect")
          }
        </button>
      </div>
    </GlassPanel>
  );
}
