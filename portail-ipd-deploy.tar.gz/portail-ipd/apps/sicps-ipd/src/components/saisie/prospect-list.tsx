"use client";

import { useState, useMemo } from "react";
import type { Prospect, OrganisationType, ConfidenceLevel, PipelinePhase, ScoringTier, FundingTier } from "@/types";
import { ALL_ORGANISATION_TYPES, ALL_CONFIDENCE_LEVELS, PIPELINE_PHASES, ORG_TYPE_COLORS } from "@/types";
import { TIER_LABELS } from "@/lib/scoring/composite-index";
import { FUNDING_TIER_LABELS } from "@/lib/scoring/tier-classifier";
import { useTranslation } from "@/lib/i18n";
import { GlassPanel } from "@/components/shared/glass-panel";
import { StatusBadge } from "@/components/shared/status-badge";
import { formatCurrency } from "@/lib/utils";
import {
  Search, ArrowUpDown, Edit3, MessageSquare, Filter, X, ChevronDown, ChevronUp,
  RotateCcw, Download,
} from "lucide-react";

interface ProspectListProps {
  prospects: Prospect[];
  onSelect: (id: string) => void;
}

type SortKey = "organisation" | "updatedAt" | "totalScore" | "annualGiving" | "pipelinePhase" | "confidence" | "dataYear";

export function ProspectList({ prospects, onSelect }: ProspectListProps) {
  const { locale } = useTranslation();
  const [search, setSearch] = useState("");
  const [sortKey, setSortKey] = useState<SortKey>("updatedAt");
  const [sortDir, setSortDir] = useState<"asc" | "desc">("desc");
  const [showFilters, setShowFilters] = useState(false);

  // Filters
  const [filterTypes, setFilterTypes] = useState<OrganisationType[]>([]);
  const [filterConfidences, setFilterConfidences] = useState<ConfidenceLevel[]>([]);
  const [filterPhases, setFilterPhases] = useState<string[]>([]);
  const [filterScoringTiers, setFilterScoringTiers] = useState<ScoringTier[]>([]);
  const [filterFundingTiers, setFilterFundingTiers] = useState<FundingTier[]>([]);
  const [filterKnownToIPD, setFilterKnownToIPD] = useState<string>("");
  const [filterDataFreshness, setFilterDataFreshness] = useState<string>("");
  const [filterHasNotes, setFilterHasNotes] = useState<string>("");
  const [filterHasNextAction, setFilterHasNextAction] = useState<string>("");
  const [filterCountry, setFilterCountry] = useState("");

  const activeFilterCount = useMemo(() => {
    let count = 0;
    if (filterTypes.length) count++;
    if (filterConfidences.length) count++;
    if (filterPhases.length) count++;
    if (filterScoringTiers.length) count++;
    if (filterFundingTiers.length) count++;
    if (filterKnownToIPD) count++;
    if (filterDataFreshness) count++;
    if (filterHasNotes) count++;
    if (filterHasNextAction) count++;
    if (filterCountry) count++;
    return count;
  }, [filterTypes, filterConfidences, filterPhases, filterScoringTiers, filterFundingTiers, filterKnownToIPD, filterDataFreshness, filterHasNotes, filterHasNextAction, filterCountry]);

  const resetFilters = () => {
    setFilterTypes([]);
    setFilterConfidences([]);
    setFilterPhases([]);
    setFilterScoringTiers([]);
    setFilterFundingTiers([]);
    setFilterKnownToIPD("");
    setFilterDataFreshness("");
    setFilterHasNotes("");
    setFilterHasNextAction("");
    setFilterCountry("");
  };

  // All unique countries for filter dropdown
  const allCountries = useMemo(() => {
    const set = new Set<string>();
    prospects.forEach((p) => p.countriesServed.forEach((c) => set.add(c)));
    return [...set].sort();
  }, [prospects]);

  const filtered = useMemo(() => {
    let list = [...prospects];

    // Search
    if (search) {
      const q = search.toLowerCase();
      list = list.filter((p) =>
        p.organisation.toLowerCase().includes(q) ||
        p.type.toLowerCase().includes(q) ||
        p.whyAligned.toLowerCase().includes(q) ||
        p.delegates.some((d) => d.name.toLowerCase().includes(q)) ||
        p.countriesServed.some((c) => c.toLowerCase().includes(q)) ||
        (p.contactPerson || "").toLowerCase().includes(q) ||
        (p.assignedTo || "").toLowerCase().includes(q)
      );
    }

    // Type
    if (filterTypes.length > 0) {
      list = list.filter((p) => filterTypes.includes(p.type));
    }

    // Confidence
    if (filterConfidences.length > 0) {
      list = list.filter((p) => filterConfidences.includes(p.confidence));
    }

    // Pipeline phase
    if (filterPhases.length > 0) {
      list = list.filter((p) => {
        if (filterPhases.includes("none")) {
          if (!p.pipelinePhase) return true;
        }
        return p.pipelinePhase && filterPhases.includes(p.pipelinePhase);
      });
    }

    // Scoring tier
    if (filterScoringTiers.length > 0) {
      list = list.filter((p) => filterScoringTiers.includes(p.scoringTier));
    }

    // Funding tier
    if (filterFundingTiers.length > 0) {
      list = list.filter((p) => filterFundingTiers.includes(p.fundingTier));
    }

    // Known to IPD
    if (filterKnownToIPD === "yes") list = list.filter((p) => p.knownToIPD === true);
    else if (filterKnownToIPD === "no") list = list.filter((p) => p.knownToIPD !== true);

    // Data freshness
    if (filterDataFreshness) {
      list = list.filter((p) => p.dataFreshness === filterDataFreshness);
    }

    // Has notes
    if (filterHasNotes === "yes") list = list.filter((p) => (p.prospectionNotes?.length || 0) > 0);
    else if (filterHasNotes === "no") list = list.filter((p) => (p.prospectionNotes?.length || 0) === 0);

    // Has next action
    if (filterHasNextAction === "yes") list = list.filter((p) => !!p.nextActionDescription);
    else if (filterHasNextAction === "no") list = list.filter((p) => !p.nextActionDescription);

    // Country
    if (filterCountry) {
      list = list.filter((p) => p.countriesServed.includes(filterCountry));
    }

    // Sort
    list.sort((a, b) => {
      let cmp = 0;
      switch (sortKey) {
        case "organisation": cmp = a.organisation.localeCompare(b.organisation); break;
        case "updatedAt": cmp = new Date(a.updatedAt).getTime() - new Date(b.updatedAt).getTime(); break;
        case "totalScore": cmp = a.totalScore - b.totalScore; break;
        case "annualGiving": cmp = (a.annualGiving || 0) - (b.annualGiving || 0); break;
        case "pipelinePhase": cmp = (a.pipelinePhase || "zzz").localeCompare(b.pipelinePhase || "zzz"); break;
        case "confidence": {
          const order = ["High", "Verified", "Reported", "Medium", "Estimated", "Low"];
          cmp = order.indexOf(a.confidence) - order.indexOf(b.confidence);
          break;
        }
        case "dataYear": cmp = (a.dataYear || 0) - (b.dataYear || 0); break;
      }
      return sortDir === "asc" ? cmp : -cmp;
    });

    return list;
  }, [prospects, search, filterTypes, filterConfidences, filterPhases, filterScoringTiers, filterFundingTiers, filterKnownToIPD, filterDataFreshness, filterHasNotes, filterHasNextAction, filterCountry, sortKey, sortDir]);

  const toggleSort = (key: SortKey) => {
    if (sortKey === key) setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    else { setSortKey(key); setSortDir("desc"); }
  };

  const toggleMulti = <T extends string>(arr: T[], val: T, setter: (v: T[]) => void) => {
    setter(arr.includes(val) ? arr.filter((v) => v !== val) : [...arr, val]);
  };

  const selectClass = "h-8 px-2 rounded-lg text-xs bg-white/5 border border-white/8 text-foreground focus:outline-none focus:ring-1 focus:ring-[#10b981]/50 appearance-none";
  const chipActive = "px-2 py-1 rounded-lg text-[11px] font-medium cursor-pointer transition-all border";

  // CSV export
  const exportCSV = () => {
    const headers = ["Organisation", "Type", "Phase Pipeline", "Score", "Annual Giving", "Confidence", "Known to IPD", "Pays", "Data Year", "Notes", "Prochaine Action", "Maj"];
    const rows = filtered.map((p) => [
      p.organisation, p.type, p.pipelinePhase || "", p.totalScore, p.annualGiving || "",
      p.confidence, p.knownToIPD ? "Oui" : "Non", p.countriesServed.join("; "),
      p.dataYear || "", p.prospectionNotes?.length || 0, p.nextActionDescription || "",
      new Date(p.updatedAt).toLocaleDateString(),
    ]);
    const csv = [headers.join(","), ...rows.map((r) => r.map((v) => `"${v}"`).join(","))].join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "sicps_prospects_export.csv";
    a.click();
  };

  return (
    <GlassPanel animate={false}>
      {/* Toolbar */}
      <div className="flex flex-col gap-3 mb-4">
        <div className="flex flex-col sm:flex-row gap-3">
          {/* Search */}
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder={locale === "fr" ? "Rechercher organisation, delegue, pays, alignement..." : "Search organisation, delegate, country, alignment..."}
              className="w-full h-9 pl-9 pr-4 rounded-lg text-sm bg-white/5 border border-white/8 focus:outline-none focus:ring-1 focus:ring-[#10b981]/50"
            />
          </div>

          {/* Filter toggle + Export */}
          <div className="flex gap-2">
            <button
              onClick={() => setShowFilters(!showFilters)}
              className={`flex items-center gap-1.5 h-9 px-3 rounded-lg text-xs font-medium transition-all border ${
                activeFilterCount > 0
                  ? "bg-[#10b981]/10 border-[#10b981]/30 text-[#10b981]"
                  : "bg-white/5 border-white/8 text-muted-foreground hover:text-white"
              }`}
            >
              <Filter className="w-3.5 h-3.5" />
              {locale === "fr" ? "Filtres" : "Filters"}
              {activeFilterCount > 0 && (
                <span className="ml-1 w-5 h-5 flex items-center justify-center rounded-full bg-[#10b981] text-white text-[10px] font-bold">
                  {activeFilterCount}
                </span>
              )}
              {showFilters ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
            </button>

            {activeFilterCount > 0 && (
              <button
                onClick={resetFilters}
                className="flex items-center gap-1 h-9 px-3 rounded-lg text-xs text-muted-foreground hover:text-white bg-white/5 border border-white/8 transition-all"
                title={locale === "fr" ? "Reinitialiser" : "Reset"}
              >
                <RotateCcw className="w-3 h-3" />
              </button>
            )}

            <button
              onClick={exportCSV}
              className="flex items-center gap-1.5 h-9 px-3 rounded-lg text-xs font-medium text-muted-foreground hover:text-white bg-white/5 border border-white/8 transition-all"
            >
              <Download className="w-3.5 h-3.5" />
              CSV
            </button>
          </div>
        </div>

        {/* =================== FILTER PANEL =================== */}
        {showFilters && (
          <div className="p-4 rounded-xl bg-white/2 border border-white/5 space-y-4">

            {/* Row 1: Type d'organisation */}
            <div>
              <label className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider mb-2 block">
                {locale === "fr" ? "Type d'organisation" : "Organisation Type"}
              </label>
              <div className="flex flex-wrap gap-1.5">
                {ALL_ORGANISATION_TYPES.map((type) => {
                  const active = filterTypes.includes(type);
                  const color = ORG_TYPE_COLORS[type];
                  const shortLabel = type.split(" / ")[0];
                  return (
                    <button
                      key={type}
                      onClick={() => toggleMulti(filterTypes, type, setFilterTypes)}
                      className={chipActive}
                      style={active
                        ? { backgroundColor: `${color}20`, borderColor: `${color}60`, color }
                        : { backgroundColor: "rgba(255,255,255,0.03)", borderColor: "rgba(255,255,255,0.08)", color: "rgba(255,255,255,0.5)" }
                      }
                    >
                      {shortLabel}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Row 2: Pipeline Phase + Scoring Tier */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider mb-2 block">
                  {locale === "fr" ? "Phase Pipeline" : "Pipeline Phase"}
                </label>
                <div className="flex flex-wrap gap-1.5">
                  <button
                    onClick={() => toggleMulti(filterPhases, "none", setFilterPhases)}
                    className={chipActive}
                    style={filterPhases.includes("none")
                      ? { backgroundColor: "rgba(100,116,139,0.2)", borderColor: "rgba(100,116,139,0.6)", color: "#94a3b8" }
                      : { backgroundColor: "rgba(255,255,255,0.03)", borderColor: "rgba(255,255,255,0.08)", color: "rgba(255,255,255,0.5)" }
                    }
                  >
                    {locale === "fr" ? "Non assigne" : "Unassigned"}
                  </button>
                  {PIPELINE_PHASES.map((phase) => {
                    const active = filterPhases.includes(phase.key);
                    return (
                      <button
                        key={phase.key}
                        onClick={() => toggleMulti(filterPhases, phase.key, setFilterPhases)}
                        className={chipActive}
                        style={active
                          ? { backgroundColor: `${phase.color}20`, borderColor: `${phase.color}60`, color: phase.color }
                          : { backgroundColor: "rgba(255,255,255,0.03)", borderColor: "rgba(255,255,255,0.08)", color: "rgba(255,255,255,0.5)" }
                        }
                      >
                        {locale === "fr" ? phase.label : phase.labelEn}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div>
                <label className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider mb-2 block">
                  {locale === "fr" ? "Tier de Scoring" : "Scoring Tier"}
                </label>
                <div className="flex flex-wrap gap-1.5">
                  {(["hot", "warm", "cool", "cold", "unscored"] as ScoringTier[]).map((tier) => {
                    const active = filterScoringTiers.includes(tier);
                    const colors: Record<ScoringTier, string> = { hot: "#ef4444", warm: "#f59e0b", cool: "#3b82f6", cold: "#64748b", unscored: "#374151" };
                    return (
                      <button
                        key={tier}
                        onClick={() => toggleMulti(filterScoringTiers, tier, setFilterScoringTiers)}
                        className={chipActive}
                        style={active
                          ? { backgroundColor: `${colors[tier]}20`, borderColor: `${colors[tier]}60`, color: colors[tier] }
                          : { backgroundColor: "rgba(255,255,255,0.03)", borderColor: "rgba(255,255,255,0.08)", color: "rgba(255,255,255,0.5)" }
                        }
                      >
                        {locale === "fr" ? TIER_LABELS[tier].fr : TIER_LABELS[tier].en}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Row 3: Confidence + Funding Tier */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider mb-2 block">
                  {locale === "fr" ? "Niveau de Confiance" : "Confidence Level"}
                </label>
                <div className="flex flex-wrap gap-1.5">
                  {ALL_CONFIDENCE_LEVELS.map((conf) => {
                    const active = filterConfidences.includes(conf);
                    const colors: Record<ConfidenceLevel, string> = { High: "#10b981", Verified: "#3b82f6", Reported: "#8b5cf6", Medium: "#f59e0b", Estimated: "#f97316", Low: "#ef4444" };
                    return (
                      <button
                        key={conf}
                        onClick={() => toggleMulti(filterConfidences, conf, setFilterConfidences)}
                        className={chipActive}
                        style={active
                          ? { backgroundColor: `${colors[conf]}20`, borderColor: `${colors[conf]}60`, color: colors[conf] }
                          : { backgroundColor: "rgba(255,255,255,0.03)", borderColor: "rgba(255,255,255,0.08)", color: "rgba(255,255,255,0.5)" }
                        }
                      >
                        {conf}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div>
                <label className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider mb-2 block">
                  {locale === "fr" ? "Tier Financier" : "Funding Tier"}
                </label>
                <div className="flex flex-wrap gap-1.5">
                  {(["mega", "major", "mid", "emerging", "unknown"] as FundingTier[]).map((tier) => {
                    const active = filterFundingTiers.includes(tier);
                    const colors: Record<FundingTier, string> = { mega: "#ef4444", major: "#f59e0b", mid: "#3b82f6", emerging: "#10b981", unknown: "#64748b" };
                    return (
                      <button
                        key={tier}
                        onClick={() => toggleMulti(filterFundingTiers, tier, setFilterFundingTiers)}
                        className={chipActive}
                        style={active
                          ? { backgroundColor: `${colors[tier]}20`, borderColor: `${colors[tier]}60`, color: colors[tier] }
                          : { backgroundColor: "rgba(255,255,255,0.03)", borderColor: "rgba(255,255,255,0.08)", color: "rgba(255,255,255,0.5)" }
                        }
                      >
                        {locale === "fr" ? FUNDING_TIER_LABELS[tier].fr : FUNDING_TIER_LABELS[tier].en}
                        <span className="ml-1 text-[9px] opacity-60">{FUNDING_TIER_LABELS[tier].range}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Row 4: Dropdowns — Known IPD, Data Freshness, Country, Notes, Next Action */}
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
              <div>
                <label className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider mb-1.5 block">
                  Known to IPD
                </label>
                <select value={filterKnownToIPD} onChange={(e) => setFilterKnownToIPD(e.target.value)} className={selectClass + " w-full"}>
                  <option value="">{locale === "fr" ? "Tous" : "All"}</option>
                  <option value="yes">{locale === "fr" ? "Oui" : "Yes"}</option>
                  <option value="no">{locale === "fr" ? "Non / N.R." : "No / N/A"}</option>
                </select>
              </div>

              <div>
                <label className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider mb-1.5 block">
                  {locale === "fr" ? "Fraicheur donnees" : "Data Freshness"}
                </label>
                <select value={filterDataFreshness} onChange={(e) => setFilterDataFreshness(e.target.value)} className={selectClass + " w-full"}>
                  <option value="">{locale === "fr" ? "Toutes" : "All"}</option>
                  <option value="fresh">{locale === "fr" ? "Frais (< 1 an)" : "Fresh (< 1y)"}</option>
                  <option value="aging">{locale === "fr" ? "Vieillissant (1-2 ans)" : "Aging (1-2y)"}</option>
                  <option value="stale">{locale === "fr" ? "Obsolete (> 2 ans)" : "Stale (> 2y)"}</option>
                  <option value="unknown">{locale === "fr" ? "Inconnu" : "Unknown"}</option>
                </select>
              </div>

              <div>
                <label className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider mb-1.5 block">
                  {locale === "fr" ? "Pays" : "Country"}
                </label>
                <select value={filterCountry} onChange={(e) => setFilterCountry(e.target.value)} className={selectClass + " w-full"}>
                  <option value="">{locale === "fr" ? "Tous" : "All"}</option>
                  {allCountries.map((c) => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>

              <div>
                <label className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider mb-1.5 block">
                  {locale === "fr" ? "Notes prospection" : "Prospection Notes"}
                </label>
                <select value={filterHasNotes} onChange={(e) => setFilterHasNotes(e.target.value)} className={selectClass + " w-full"}>
                  <option value="">{locale === "fr" ? "Tous" : "All"}</option>
                  <option value="yes">{locale === "fr" ? "Avec notes" : "Has notes"}</option>
                  <option value="no">{locale === "fr" ? "Sans notes" : "No notes"}</option>
                </select>
              </div>

              <div>
                <label className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider mb-1.5 block">
                  {locale === "fr" ? "Prochaine action" : "Next Action"}
                </label>
                <select value={filterHasNextAction} onChange={(e) => setFilterHasNextAction(e.target.value)} className={selectClass + " w-full"}>
                  <option value="">{locale === "fr" ? "Tous" : "All"}</option>
                  <option value="yes">{locale === "fr" ? "Avec action" : "Has action"}</option>
                  <option value="no">{locale === "fr" ? "Sans action" : "No action"}</option>
                </select>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Results count */}
      <div className="flex items-center justify-between text-xs text-muted-foreground mb-3">
        <span>
          {filtered.length}/{prospects.length} {locale === "fr" ? "prospects affiches" : "prospects shown"}
        </span>
        {activeFilterCount > 0 && (
          <button onClick={resetFilters} className="text-[#10b981] hover:underline flex items-center gap-1">
            <X className="w-3 h-3" />
            {locale === "fr" ? "Effacer les filtres" : "Clear filters"}
          </button>
        )}
      </div>

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-xs text-muted-foreground border-b border-white/5 text-left">
              <th className="py-2 px-3 cursor-pointer hover:text-white" onClick={() => toggleSort("organisation")}>
                <div className="flex items-center gap-1">Organisation <ArrowUpDown className="w-3 h-3" /></div>
              </th>
              <th className="py-2 px-3 hidden lg:table-cell">Type</th>
              <th className="py-2 px-3 cursor-pointer hover:text-white hidden md:table-cell" onClick={() => toggleSort("pipelinePhase")}>
                <div className="flex items-center gap-1">{locale === "fr" ? "Phase" : "Phase"} <ArrowUpDown className="w-3 h-3" /></div>
              </th>
              <th className="py-2 px-3 cursor-pointer hover:text-white text-right hidden md:table-cell" onClick={() => toggleSort("annualGiving")}>
                <div className="flex items-center justify-end gap-1">Annual Giving <ArrowUpDown className="w-3 h-3" /></div>
              </th>
              <th className="py-2 px-3 cursor-pointer hover:text-white text-center hidden sm:table-cell" onClick={() => toggleSort("totalScore")}>
                <div className="flex items-center justify-center gap-1">Score <ArrowUpDown className="w-3 h-3" /></div>
              </th>
              <th className="py-2 px-3 cursor-pointer hover:text-white text-center hidden lg:table-cell" onClick={() => toggleSort("confidence")}>
                <div className="flex items-center justify-center gap-1">Conf. <ArrowUpDown className="w-3 h-3" /></div>
              </th>
              <th className="py-2 px-3 text-center hidden lg:table-cell">
                <MessageSquare className="w-3.5 h-3.5 inline" />
              </th>
              <th className="py-2 px-3 cursor-pointer hover:text-white text-right" onClick={() => toggleSort("updatedAt")}>
                <div className="flex items-center justify-end gap-1">{locale === "fr" ? "Maj" : "Updated"} <ArrowUpDown className="w-3 h-3" /></div>
              </th>
              <th className="py-2 px-3 w-10"></th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((p) => (
              <tr
                key={p.id}
                className="border-b border-white/3 hover:bg-white/3 transition-colors group cursor-pointer"
                onClick={() => onSelect(p.id)}
              >
                <td className="py-3 px-3">
                  <div className="flex items-center gap-2">
                    {p.knownToIPD && (
                      <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0" title="Known to IPD" />
                    )}
                    <div className="min-w-0">
                      <p className="font-medium truncate max-w-[220px]">{p.organisation}</p>
                      {p.nextActionDescription && (
                        <p className="text-[10px] text-[#f59e0b] truncate max-w-[220px] mt-0.5">
                          ⚡ {p.nextActionDescription}
                        </p>
                      )}
                    </div>
                  </div>
                </td>
                <td className="py-3 px-3 hidden lg:table-cell">
                  <span className="text-xs text-muted-foreground">{p.type.split(" / ")[0]}</span>
                </td>
                <td className="py-3 px-3 hidden md:table-cell">
                  {p.pipelinePhase ? (
                    <StatusBadge variant="pipeline" value={p.pipelinePhase} locale={locale} />
                  ) : (
                    <span className="text-xs text-muted-foreground">—</span>
                  )}
                </td>
                <td className="py-3 px-3 text-right hidden md:table-cell">
                  <span className="text-xs font-mono">{formatCurrency(p.annualGiving, true)}</span>
                </td>
                <td className="py-3 px-3 text-center hidden sm:table-cell">
                  <StatusBadge variant="scoring" value={p.scoringTier} locale={locale} />
                </td>
                <td className="py-3 px-3 text-center hidden lg:table-cell">
                  <StatusBadge variant="confidence" value={p.confidence} locale={locale} size="sm" />
                </td>
                <td className="py-3 px-3 text-center hidden lg:table-cell">
                  <span className="text-xs font-mono text-muted-foreground">
                    {p.prospectionNotes?.length || 0}
                  </span>
                </td>
                <td className="py-3 px-3 text-right">
                  <span className="text-[11px] text-muted-foreground font-mono">
                    {new Date(p.updatedAt).toLocaleDateString(locale === "fr" ? "fr-FR" : "en-US", { day: "2-digit", month: "short" })}
                  </span>
                </td>
                <td className="py-3 px-3">
                  <button
                    onClick={(e) => { e.stopPropagation(); onSelect(p.id); }}
                    className="p-1.5 rounded-lg text-muted-foreground hover:text-white hover:bg-white/5 transition-all opacity-0 group-hover:opacity-100"
                    title={locale === "fr" ? "Ouvrir fiche" : "Open record"}
                  >
                    <Edit3 className="w-4 h-4" />
                  </button>
                </td>
              </tr>
            ))}
            {filtered.length === 0 && (
              <tr>
                <td colSpan={9} className="py-12 text-center text-sm text-muted-foreground">
                  {locale === "fr" ? "Aucun prospect ne correspond aux filtres." : "No prospects match the current filters."}
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </GlassPanel>
  );
}
