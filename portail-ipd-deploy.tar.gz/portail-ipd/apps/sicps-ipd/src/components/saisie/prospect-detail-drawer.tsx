"use client";

import { useState } from "react";
import type { Prospect, ProspectionNoteType, PipelinePhase } from "@/types";
import { PROSPECTION_NOTE_TYPES, PIPELINE_PHASES, ORG_TYPE_COLORS } from "@/types";
import { useProspectStore } from "@/stores/prospect-store";
import { useTranslation } from "@/lib/i18n";
import { ProspectForm } from "./prospect-form";
import { StatusBadge } from "@/components/shared/status-badge";
import { GlassPanel } from "@/components/shared/glass-panel";
import { formatCurrency, generateId } from "@/lib/utils";
import { motion, AnimatePresence } from "framer-motion";
import {
  X, Edit3, Clock, Plus, Trash2, UserPlus, Users, Mail, Phone,
  FileText, RefreshCw, StickyNote, Flag, ChevronDown, Save,
} from "lucide-react";

const NOTE_ICONS: Record<string, React.ElementType> = {
  contact: UserPlus, meeting: Users, email: Mail, call: Phone,
  proposal: FileText, update: RefreshCw, note: StickyNote, milestone: Flag,
};

interface ProspectDetailDrawerProps {
  prospect: Prospect;
  onClose: () => void;
}

type Tab = "overview" | "edit" | "notes" | "actions";

export function ProspectDetailDrawer({ prospect, onClose }: ProspectDetailDrawerProps) {
  const { locale } = useTranslation();
  const updateProspect = useProspectStore((s) => s.updateProspect);
  const addProspectionNote = useProspectStore((s) => s.addProspectionNote);
  const deleteProspectionNote = useProspectStore((s) => s.deleteProspectionNote);
  const [tab, setTab] = useState<Tab>("overview");
  const [showAddNote, setShowAddNote] = useState(false);

  // Note form state
  const [noteType, setNoteType] = useState<ProspectionNoteType>("note");
  const [noteDate, setNoteDate] = useState(new Date().toISOString().split("T")[0]);
  const [noteSummary, setNoteSummary] = useState("");
  const [noteDetails, setNoteDetails] = useState("");

  // Quick actions
  const [quickPhase, setQuickPhase] = useState(prospect.pipelinePhase || "");
  const [quickAssignee, setQuickAssignee] = useState(prospect.assignedTo || "");
  const [quickNextAction, setQuickNextAction] = useState(prospect.nextActionDescription || "");
  const [quickNextDate, setQuickNextDate] = useState(prospect.nextActionDate || "");

  const notes = (prospect.prospectionNotes || []).sort(
    (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
  );

  const handleAddNote = () => {
    if (!noteSummary.trim()) return;
    addProspectionNote(prospect.id, {
      id: generateId(),
      type: noteType,
      date: noteDate,
      author: "Analyst",
      summary: noteSummary.trim(),
      details: noteDetails.trim() || undefined,
      createdAt: new Date().toISOString(),
    });
    setNoteSummary("");
    setNoteDetails("");
    setShowAddNote(false);
  };

  const handleSaveActions = () => {
    updateProspect(prospect.id, {
      pipelinePhase: (quickPhase as PipelinePhase) || undefined,
      assignedTo: quickAssignee.trim() || undefined,
      nextActionDescription: quickNextAction.trim() || undefined,
      nextActionDate: quickNextDate || undefined,
    });
  };

  const tabs: { key: Tab; label: string }[] = [
    { key: "overview", label: locale === "fr" ? "Fiche" : "Overview" },
    { key: "notes", label: locale === "fr" ? `Journal (${notes.length})` : `Log (${notes.length})` },
    { key: "actions", label: locale === "fr" ? "Actions & Suivi" : "Actions & Follow-up" },
    { key: "edit", label: locale === "fr" ? "Modifier" : "Edit" },
  ];

  const inputClass = "w-full h-9 px-3 rounded-lg text-sm bg-white/5 border border-white/8 text-foreground focus:outline-none focus:ring-1 focus:ring-[#10b981]/50";
  const textareaClass = "w-full px-3 py-2 rounded-lg text-sm bg-white/5 border border-white/8 text-foreground focus:outline-none focus:ring-1 focus:ring-[#10b981]/50 resize-none";

  return (
    <>
      {/* Backdrop */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40"
      />

      {/* Drawer */}
      <motion.div
        initial={{ x: "100%" }}
        animate={{ x: 0 }}
        exit={{ x: "100%" }}
        transition={{ type: "spring", stiffness: 300, damping: 30 }}
        className="fixed inset-y-0 right-0 w-full max-w-2xl z-50 overflow-y-auto"
        style={{ backgroundColor: "var(--background)" }}
      >
        <div className="p-6">
          {/* Header */}
          <div className="flex items-start justify-between mb-6">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <div className="w-3 h-3 rounded-full" style={{ backgroundColor: ORG_TYPE_COLORS[prospect.type] || "#64748b" }} />
                <h2 className="text-xl font-bold">{prospect.organisation}</h2>
              </div>
              <div className="flex flex-wrap gap-1.5 mt-2">
                <StatusBadge variant="scoring" value={prospect.scoringTier} locale={locale} />
                <StatusBadge variant="funding" value={prospect.fundingTier} locale={locale} />
                {prospect.pipelinePhase && <StatusBadge variant="pipeline" value={prospect.pipelinePhase} locale={locale} />}
                {prospect.knownToIPD && (
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">Known to IPD</span>
                )}
              </div>
            </div>
            <button onClick={onClose} className="p-2 rounded-lg text-muted-foreground hover:text-white hover:bg-white/5">
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Tabs */}
          <div className="flex gap-1 p-1 rounded-xl bg-white/3 border border-white/5 mb-6">
            {tabs.map((t) => (
              <button
                key={t.key}
                onClick={() => setTab(t.key)}
                className={`flex-1 px-3 py-2 rounded-lg text-xs font-medium transition-all ${
                  tab === t.key ? "bg-[#10b981]/20 text-white border border-[#10b981]/30" : "text-muted-foreground hover:text-white"
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>

          {/* ========== OVERVIEW TAB ========== */}
          {tab === "overview" && (
            <div className="space-y-4">
              {/* Summary */}
              <GlassPanel animate={false} className="!p-4">
                <h4 className="text-xs font-semibold text-muted-foreground uppercase mb-2">{locale === "fr" ? "Resume" : "Summary"}</h4>
                <p className="text-sm text-foreground/80">{prospect.organisationSummary || "—"}</p>
              </GlassPanel>

              {prospect.whyAligned && (
                <GlassPanel animate={false} className="!p-4">
                  <h4 className="text-xs font-semibold text-muted-foreground uppercase mb-2">{locale === "fr" ? "Alignement IPD" : "IPD Alignment"}</h4>
                  <p className="text-sm text-[#8b5cf6]">{prospect.whyAligned}</p>
                </GlassPanel>
              )}

              {/* Financial grid */}
              <div className="grid grid-cols-3 gap-3">
                <div className="p-3 rounded-xl bg-white/3 border border-white/5 text-center">
                  <p className="text-[10px] text-muted-foreground uppercase">Annual Giving</p>
                  <p className="text-base font-bold font-mono mt-1">{formatCurrency(prospect.annualGiving, true)}</p>
                </div>
                <div className="p-3 rounded-xl bg-white/3 border border-white/5 text-center">
                  <p className="text-[10px] text-muted-foreground uppercase">Avg Grant</p>
                  <p className="text-base font-bold font-mono mt-1">{formatCurrency(prospect.avgGrantSize, true)}</p>
                </div>
                <div className="p-3 rounded-xl bg-white/3 border border-white/5 text-center">
                  <p className="text-[10px] text-muted-foreground uppercase">Score 3A</p>
                  <p className="text-base font-bold font-mono mt-1">{prospect.totalScore || "—"}</p>
                </div>
              </div>

              {/* Scores */}
              {prospect.totalScore > 0 && (
                <div className="grid grid-cols-3 gap-3">
                  {[
                    { label: locale === "fr" ? "Affinite" : "Affinity", value: prospect.affinity, color: "#8b5cf6" },
                    { label: locale === "fr" ? "Capacite" : "Ability", value: prospect.ability, color: "#10b981" },
                    { label: locale === "fr" ? "Acces" : "Access", value: prospect.access, color: "#f59e0b" },
                  ].map((s) => (
                    <div key={s.label} className="p-3 rounded-xl bg-white/3 border border-white/5 text-center">
                      <p className="text-[10px] text-muted-foreground uppercase">{s.label}</p>
                      <p className="text-lg font-bold font-mono mt-1" style={{ color: s.color }}>{s.value}/5</p>
                    </div>
                  ))}
                </div>
              )}

              {/* Delegates */}
              {prospect.delegates.length > 0 && (
                <GlassPanel animate={false} className="!p-4">
                  <h4 className="text-xs font-semibold text-muted-foreground uppercase mb-2">
                    {locale === "fr" ? "Delegues" : "Delegates"} ({prospect.delegates.length})
                  </h4>
                  <div className="space-y-1.5">
                    {prospect.delegates.map((d) => (
                      <div key={d.id} className="flex items-center justify-between text-sm">
                        <span className="font-medium">{d.name}</span>
                        <span className="text-xs text-muted-foreground">{d.title}</span>
                      </div>
                    ))}
                  </div>
                </GlassPanel>
              )}

              {/* Countries */}
              {prospect.countriesServed.length > 0 && (
                <GlassPanel animate={false} className="!p-4">
                  <h4 className="text-xs font-semibold text-muted-foreground uppercase mb-2">
                    {locale === "fr" ? "Pays desservis" : "Countries Served"} ({prospect.countriesServed.length})
                  </h4>
                  <div className="flex flex-wrap gap-1.5">
                    {prospect.countriesServed.map((c) => (
                      <span key={c} className="text-xs px-2 py-0.5 rounded-full bg-white/5 text-muted-foreground">{c}</span>
                    ))}
                  </div>
                </GlassPanel>
              )}

              {/* Metadata */}
              <div className="grid grid-cols-2 gap-3 text-xs text-muted-foreground">
                <div>Data Year: <span className="font-mono text-foreground">{prospect.dataYear || "—"}</span></div>
                <div>Source: <span className="text-foreground">{prospect.dataSource || "—"}</span></div>
                <div>Confidence: <StatusBadge variant="confidence" value={prospect.confidence} locale={locale} /></div>
                <div>{locale === "fr" ? "Cree le" : "Created"}: <span className="font-mono">{new Date(prospect.createdAt).toLocaleDateString()}</span></div>
              </div>
            </div>
          )}

          {/* ========== NOTES / JOURNAL TAB ========== */}
          {tab === "notes" && (
            <div className="space-y-4">
              {/* Add note button */}
              <button
                onClick={() => setShowAddNote(!showAddNote)}
                className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium text-white bg-[#10b981] hover:bg-[#059669] transition-all w-full justify-center"
              >
                <Plus className="w-4 h-4" />
                {locale === "fr" ? "Ajouter une note de prospection" : "Add prospection note"}
              </button>

              {/* Add note form */}
              <AnimatePresence>
                {showAddNote && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="overflow-hidden"
                  >
                    <GlassPanel animate={false} glow="emerald" className="!p-4 space-y-3">
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="text-xs text-muted-foreground mb-1 block">{locale === "fr" ? "Type" : "Type"}</label>
                          <select value={noteType} onChange={(e) => setNoteType(e.target.value as ProspectionNoteType)} className={inputClass}>
                            {PROSPECTION_NOTE_TYPES.map((t) => (
                              <option key={t.key} value={t.key}>{locale === "fr" ? t.label : t.labelEn}</option>
                            ))}
                          </select>
                        </div>
                        <div>
                          <label className="text-xs text-muted-foreground mb-1 block">Date</label>
                          <input type="date" value={noteDate} onChange={(e) => setNoteDate(e.target.value)} className={inputClass} />
                        </div>
                      </div>

                      <div>
                        <label className="text-xs text-muted-foreground mb-1 block">{locale === "fr" ? "Resume" : "Summary"} *</label>
                        <input type="text" value={noteSummary} onChange={(e) => setNoteSummary(e.target.value)} className={inputClass}
                          placeholder={locale === "fr" ? "Ex: Appel avec le directeur des partenariats" : "Ex: Call with partnerships director"} />
                      </div>

                      <div>
                        <label className="text-xs text-muted-foreground mb-1 block">{locale === "fr" ? "Details (optionnel)" : "Details (optional)"}</label>
                        <textarea value={noteDetails} onChange={(e) => setNoteDetails(e.target.value)} className={textareaClass} rows={3}
                          placeholder={locale === "fr" ? "Notes detaillees, points cles, suites a donner..." : "Detailed notes, key points, follow-ups..."} />
                      </div>

                      <div className="flex gap-2 justify-end">
                        <button onClick={() => setShowAddNote(false)} className="px-3 py-1.5 rounded-lg text-xs text-muted-foreground hover:text-white bg-white/5">
                          {locale === "fr" ? "Annuler" : "Cancel"}
                        </button>
                        <button onClick={handleAddNote} disabled={!noteSummary.trim()} className="px-4 py-1.5 rounded-lg text-xs font-medium text-white bg-[#10b981] hover:bg-[#059669] disabled:opacity-50">
                          {locale === "fr" ? "Enregistrer" : "Save"}
                        </button>
                      </div>
                    </GlassPanel>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Notes timeline */}
              {notes.length === 0 ? (
                <div className="text-center py-12">
                  <Clock className="w-12 h-12 mx-auto text-muted-foreground/20 mb-3" />
                  <p className="text-sm text-muted-foreground">{locale === "fr" ? "Aucune note de prospection" : "No prospection notes"}</p>
                </div>
              ) : (
                <div className="relative space-y-3 pl-6">
                  {/* Timeline line */}
                  <div className="absolute left-[11px] top-2 bottom-2 w-px bg-white/10" />

                  {notes.map((note) => {
                    const noteConfig = PROSPECTION_NOTE_TYPES.find((t) => t.key === note.type);
                    const IconComp = NOTE_ICONS[note.type] || StickyNote;
                    return (
                      <div key={note.id} className="relative group">
                        {/* Timeline dot */}
                        <div
                          className="absolute -left-6 top-3 w-[22px] h-[22px] rounded-full flex items-center justify-center border-2"
                          style={{ backgroundColor: `${noteConfig?.color || "#64748b"}20`, borderColor: noteConfig?.color || "#64748b" }}
                        >
                          <IconComp className="w-3 h-3" style={{ color: noteConfig?.color }} />
                        </div>

                        <div className="ml-3 p-3 rounded-xl bg-white/3 border border-white/5 hover:bg-white/5 transition-all">
                          <div className="flex items-start justify-between">
                            <div>
                              <div className="flex items-center gap-2 mb-1">
                                <span className="text-xs font-medium px-2 py-0.5 rounded-full" style={{ backgroundColor: `${noteConfig?.color}20`, color: noteConfig?.color }}>
                                  {locale === "fr" ? noteConfig?.label : noteConfig?.labelEn}
                                </span>
                                <span className="text-[11px] text-muted-foreground font-mono">{note.date}</span>
                              </div>
                              <p className="text-sm font-medium mt-1">{note.summary}</p>
                              {note.details && <p className="text-xs text-muted-foreground mt-1.5 whitespace-pre-wrap">{note.details}</p>}
                              <p className="text-[10px] text-muted-foreground/50 mt-2">par {note.author}</p>
                            </div>
                            <button
                              onClick={() => deleteProspectionNote(prospect.id, note.id)}
                              className="p-1 rounded text-muted-foreground/30 hover:text-red-400 opacity-0 group-hover:opacity-100 transition-all"
                              title={locale === "fr" ? "Supprimer" : "Delete"}
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* ========== ACTIONS & SUIVI TAB ========== */}
          {tab === "actions" && (
            <div className="space-y-6">
              <GlassPanel animate={false} className="!p-4 space-y-4">
                <h4 className="text-xs font-semibold text-[#8b5cf6] uppercase">{locale === "fr" ? "Statut de prospection" : "Prospection Status"}</h4>

                <div>
                  <label className="text-xs text-muted-foreground mb-1 block">{locale === "fr" ? "Phase pipeline" : "Pipeline Phase"}</label>
                  <select value={quickPhase} onChange={(e) => setQuickPhase(e.target.value)} className={inputClass}>
                    <option value="">{locale === "fr" ? "Non assignee" : "Not assigned"}</option>
                    {PIPELINE_PHASES.filter((p) => p.key !== "lost").map((p) => (
                      <option key={p.key} value={p.key}>{locale === "fr" ? p.label : p.labelEn}</option>
                    ))}
                    <option value="lost">{locale === "fr" ? "Perdu" : "Lost"}</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs text-muted-foreground mb-1 block">{locale === "fr" ? "Responsable IPD" : "IPD Assignee"}</label>
                  <input type="text" value={quickAssignee} onChange={(e) => setQuickAssignee(e.target.value)} className={inputClass}
                    placeholder={locale === "fr" ? "Nom du responsable" : "Assignee name"} />
                </div>

                <div>
                  <label className="text-xs text-muted-foreground mb-1 block">{locale === "fr" ? "Prochaine action" : "Next Action"}</label>
                  <input type="text" value={quickNextAction} onChange={(e) => setQuickNextAction(e.target.value)} className={inputClass}
                    placeholder={locale === "fr" ? "Ex: Envoyer proposition de partenariat" : "Ex: Send partnership proposal"} />
                </div>

                <div>
                  <label className="text-xs text-muted-foreground mb-1 block">{locale === "fr" ? "Date prochaine action" : "Next Action Date"}</label>
                  <input type="date" value={quickNextDate} onChange={(e) => setQuickNextDate(e.target.value)} className={inputClass} />
                </div>

                <button
                  onClick={handleSaveActions}
                  className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium text-white bg-[#8b5cf6] hover:bg-[#7c3aed] transition-all w-full justify-center"
                >
                  <Save className="w-4 h-4" />
                  {locale === "fr" ? "Enregistrer les modifications" : "Save Changes"}
                </button>
              </GlassPanel>

              {/* Quick stats */}
              <GlassPanel animate={false} className="!p-4">
                <h4 className="text-xs font-semibold text-muted-foreground uppercase mb-3">{locale === "fr" ? "Historique" : "History"}</h4>
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div className="p-2 rounded-lg bg-white/3 text-center">
                    <p className="text-lg font-bold font-mono">{notes.length}</p>
                    <p className="text-[10px] text-muted-foreground">{locale === "fr" ? "Notes" : "Notes"}</p>
                  </div>
                  <div className="p-2 rounded-lg bg-white/3 text-center">
                    <p className="text-lg font-bold font-mono">
                      {notes.filter((n) => ["contact", "meeting", "call", "email"].includes(n.type)).length}
                    </p>
                    <p className="text-[10px] text-muted-foreground">{locale === "fr" ? "Contacts" : "Contacts"}</p>
                  </div>
                  <div className="p-2 rounded-lg bg-white/3 text-center">
                    <p className="text-xs font-mono">
                      {prospect.lastContactDate ? new Date(prospect.lastContactDate).toLocaleDateString() : "—"}
                    </p>
                    <p className="text-[10px] text-muted-foreground">{locale === "fr" ? "Dernier contact" : "Last Contact"}</p>
                  </div>
                  <div className="p-2 rounded-lg bg-white/3 text-center">
                    <p className="text-xs font-mono">
                      {new Date(prospect.updatedAt).toLocaleDateString()}
                    </p>
                    <p className="text-[10px] text-muted-foreground">{locale === "fr" ? "Mise a jour" : "Updated"}</p>
                  </div>
                </div>
              </GlassPanel>
            </div>
          )}

          {/* ========== EDIT TAB ========== */}
          {tab === "edit" && (
            <ProspectForm
              initialData={prospect}
              onSaved={() => setTab("overview")}
              onCancel={() => setTab("overview")}
            />
          )}
        </div>
      </motion.div>
    </>
  );
}
