"use client";

import { useState } from "react";
import type { Prospect } from "@/types";
import { PIPELINE_PHASES, ORG_TYPE_COLORS } from "@/types";
import { TIER_LABELS } from "@/lib/scoring/composite-index";
import { FUNDING_TIER_LABELS } from "@/lib/scoring/tier-classifier";
import { useTranslation } from "@/lib/i18n";
import { GlassPanel } from "@/components/shared/glass-panel";
import { formatCurrency } from "@/lib/utils";
import { motion, AnimatePresence } from "framer-motion";
import {
  FileText, X, Download, Calendar, BarChart3, Users, DollarSign,
  Target, Globe, TrendingUp, Clock, CheckCircle2, AlertTriangle,
} from "lucide-react";

interface ReportGeneratorProps {
  prospects: Prospect[];
  open: boolean;
  onClose: () => void;
}

type ReportType = "executive" | "pipeline" | "scoring" | "financial" | "activity";
type ReportFormat = "pdf-view" | "csv";

export function ReportGenerator({ prospects, open, onClose }: ReportGeneratorProps) {
  const { locale } = useTranslation();
  const [reportType, setReportType] = useState<ReportType>("executive");
  const [generating, setGenerating] = useState(false);
  const [generatedHtml, setGeneratedHtml] = useState<string | null>(null);

  const reportTypes: { key: ReportType; label: string; labelEn: string; icon: React.ReactNode; color: string; description: string; descriptionEn: string }[] = [
    { key: "executive",  label: "Rapport Executif",           labelEn: "Executive Report",       icon: <FileText className="w-4 h-4" />,   color: "#00D4FF", description: "Vue d'ensemble strategique : KPIs, pipeline, top prospects, alertes",           descriptionEn: "Strategic overview: KPIs, pipeline, top prospects, alerts" },
    { key: "pipeline",   label: "Rapport Pipeline",           labelEn: "Pipeline Report",        icon: <BarChart3 className="w-4 h-4" />,  color: "#3b82f6", description: "Etat du tunnel de prospection par phase, taux de conversion, valeurs",         descriptionEn: "Prospection funnel status by phase, conversion rates, values" },
    { key: "scoring",    label: "Rapport Scoring 3A",         labelEn: "3A Scoring Report",      icon: <Target className="w-4 h-4" />,     color: "#8b5cf6", description: "Couverture scoring, distribution par tier, prospects prioritaires",            descriptionEn: "Scoring coverage, tier distribution, priority prospects" },
    { key: "financial",  label: "Rapport Financier",          labelEn: "Financial Report",       icon: <DollarSign className="w-4 h-4" />, color: "#10b981", description: "Analyse Annual Giving, segmentation tiers, potentiel de capture",             descriptionEn: "Annual Giving analysis, tier segmentation, capture potential" },
    { key: "activity",   label: "Rapport d'Activite",         labelEn: "Activity Report",        icon: <Clock className="w-4 h-4" />,      color: "#f59e0b", description: "Journal des interactions, notes de prospection, prochaines actions",          descriptionEn: "Interaction log, prospection notes, upcoming actions" },
  ];

  const generateReport = () => {
    setGenerating(true);
    setTimeout(() => {
      const html = buildReport(reportType, prospects, locale);
      setGeneratedHtml(html);
      setGenerating(false);
    }, 600);
  };

  const handlePrint = () => {
    if (!generatedHtml) return;
    const win = window.open("", "_blank");
    if (!win) return;
    win.document.write(generatedHtml);
    win.document.close();
    setTimeout(() => win.print(), 500);
  };

  const handleDownloadHtml = () => {
    if (!generatedHtml) return;
    const blob = new Blob([generatedHtml], { type: "text/html;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    const dateStr = new Date().toISOString().split("T")[0];
    a.download = `SICPS_IPD_Rapport_${reportType}_${dateStr}.html`;
    a.click();
    URL.revokeObjectURL(url);
  };

  if (!open) return null;

  return (
    <>
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={onClose} className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40" />
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        className="fixed inset-4 md:inset-x-[10%] md:inset-y-[5%] z-50 overflow-hidden rounded-2xl flex flex-col"
        style={{ backgroundColor: "var(--background)" }}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/5">
          <div className="flex items-center gap-3">
            <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-[#00D4FF]/10">
              <FileText className="w-5 h-5 text-[#00D4FF]" />
            </div>
            <div>
              <h2 className="text-lg font-bold">
                {locale === "fr" ? "Generateur de Rapports" : "Report Generator"}
              </h2>
              <p className="text-xs text-muted-foreground">
                {locale === "fr" ? "Rapports periodiques sur la situation de la prospection" : "Periodic reports on prospection status"}
              </p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 rounded-lg text-muted-foreground hover:text-white hover:bg-white/5">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6">
          {!generatedHtml ? (
            <div className="space-y-6">
              {/* Report type selection */}
              <div>
                <h3 className="text-sm font-semibold text-muted-foreground uppercase mb-3">
                  {locale === "fr" ? "Type de rapport" : "Report Type"}
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                  {reportTypes.map((rt) => (
                    <button
                      key={rt.key}
                      onClick={() => setReportType(rt.key)}
                      className={`text-left p-4 rounded-xl border transition-all ${
                        reportType === rt.key
                          ? "border-[var(--ring)] bg-white/5"
                          : "border-white/5 hover:border-white/10 hover:bg-white/3"
                      }`}
                    >
                      <div className="flex items-center gap-2 mb-2">
                        <div className="flex items-center justify-center w-8 h-8 rounded-lg" style={{ backgroundColor: `${rt.color}15`, color: rt.color }}>
                          {rt.icon}
                        </div>
                        <span className="text-sm font-semibold">{locale === "fr" ? rt.label : rt.labelEn}</span>
                      </div>
                      <p className="text-[11px] text-muted-foreground leading-relaxed">
                        {locale === "fr" ? rt.description : rt.descriptionEn}
                      </p>
                    </button>
                  ))}
                </div>
              </div>

              {/* Info */}
              <GlassPanel animate={false} className="!p-4">
                <div className="flex items-center gap-3 text-sm">
                  <Calendar className="w-5 h-5 text-muted-foreground shrink-0" />
                  <div>
                    <p className="font-medium">{locale === "fr" ? "Date du rapport" : "Report Date"}: <span className="font-mono text-[#00D4FF]">{new Date().toLocaleDateString(locale === "fr" ? "fr-FR" : "en-US", { weekday: "long", year: "numeric", month: "long", day: "numeric" })}</span></p>
                    <p className="text-xs text-muted-foreground mt-0.5">{prospects.length} prospects — {locale === "fr" ? "Donnees en temps reel" : "Real-time data"}</p>
                  </div>
                </div>
              </GlassPanel>

              {/* Generate button */}
              <button
                onClick={generateReport}
                disabled={generating}
                className="w-full flex items-center justify-center gap-2 py-3.5 rounded-xl text-sm font-semibold text-white bg-[#00D4FF] hover:bg-[#00bde0] transition-all disabled:opacity-50"
              >
                {generating ? (
                  <>
                    <div className="w-4 h-4 rounded-full border-2 border-white/30 border-t-white animate-spin" />
                    {locale === "fr" ? "Generation en cours..." : "Generating..."}
                  </>
                ) : (
                  <>
                    <FileText className="w-4 h-4" />
                    {locale === "fr" ? "Generer le rapport" : "Generate Report"}
                  </>
                )}
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {/* Actions bar */}
              <div className="flex items-center justify-between">
                <button onClick={() => setGeneratedHtml(null)} className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-white transition-all">
                  ← {locale === "fr" ? "Retour" : "Back"}
                </button>
                <div className="flex gap-2">
                  <button onClick={handleDownloadHtml} className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-medium text-white bg-[#10b981] hover:bg-[#059669] transition-all">
                    <Download className="w-3.5 h-3.5" />
                    {locale === "fr" ? "Telecharger HTML" : "Download HTML"}
                  </button>
                  <button onClick={handlePrint} className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-medium text-white bg-[#3b82f6] hover:bg-[#2563eb] transition-all">
                    <FileText className="w-3.5 h-3.5" />
                    {locale === "fr" ? "Imprimer / PDF" : "Print / PDF"}
                  </button>
                </div>
              </div>

              {/* Preview */}
              <div className="rounded-xl border border-white/10 overflow-hidden bg-white">
                <iframe
                  srcDoc={generatedHtml}
                  className="w-full border-0"
                  style={{ height: "calc(100vh - 300px)", minHeight: 500 }}
                  title="Report Preview"
                />
              </div>
            </div>
          )}
        </div>
      </motion.div>
    </>
  );
}

// ================================================================
// Report Builder Functions
// ================================================================

function buildReport(type: ReportType, prospects: Prospect[], locale: string): string {
  const date = new Date().toLocaleDateString(locale === "fr" ? "fr-FR" : "en-US", { weekday: "long", year: "numeric", month: "long", day: "numeric" });
  const isFr = locale === "fr";

  const css = `
    <style>
      @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap');
      * { margin: 0; padding: 0; box-sizing: border-box; }
      body { font-family: 'Inter', sans-serif; color: #1e293b; background: #fff; padding: 40px; max-width: 900px; margin: 0 auto; font-size: 13px; line-height: 1.6; }
      h1 { font-size: 22px; font-weight: 700; color: #0D1117; margin-bottom: 4px; }
      h2 { font-size: 16px; font-weight: 700; color: #1A73E8; margin: 28px 0 12px 0; padding-bottom: 6px; border-bottom: 2px solid #1A73E8; }
      h3 { font-size: 13px; font-weight: 600; color: #475569; margin: 16px 0 8px 0; text-transform: uppercase; letter-spacing: 0.5px; }
      .header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 30px; padding-bottom: 20px; border-bottom: 3px solid #0D1117; }
      .header-right { text-align: right; font-size: 11px; color: #64748b; }
      .subtitle { font-size: 13px; color: #64748b; margin-top: 2px; }
      .kpi-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(130px, 1fr)); gap: 12px; margin: 16px 0; }
      .kpi { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 10px; padding: 14px; text-align: center; }
      .kpi-value { font-size: 24px; font-weight: 700; font-family: 'JetBrains Mono', monospace; }
      .kpi-label { font-size: 10px; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px; margin-top: 4px; }
      table { width: 100%; border-collapse: collapse; margin: 12px 0; font-size: 12px; }
      th { background: #f1f5f9; font-weight: 600; text-align: left; padding: 8px 10px; border: 1px solid #e2e8f0; font-size: 11px; text-transform: uppercase; color: #475569; }
      td { padding: 7px 10px; border: 1px solid #e2e8f0; vertical-align: top; }
      tr:nth-child(even) { background: #f8fafc; }
      .badge { display: inline-block; padding: 2px 8px; border-radius: 10px; font-size: 10px; font-weight: 600; }
      .bar-container { background: #e2e8f0; border-radius: 4px; height: 8px; width: 100%; }
      .bar-fill { height: 8px; border-radius: 4px; }
      .mono { font-family: 'JetBrains Mono', monospace; }
      .text-right { text-align: right; }
      .text-center { text-align: center; }
      .footer { margin-top: 40px; padding-top: 16px; border-top: 1px solid #e2e8f0; font-size: 10px; color: #94a3b8; text-align: center; }
      .alert-box { background: #fef3c7; border: 1px solid #f59e0b; border-radius: 8px; padding: 10px 14px; margin: 8px 0; font-size: 12px; }
      .section { page-break-inside: avoid; }
      @media print { body { padding: 20px; } .no-print { display: none; } }
    </style>
  `;

  // Compute stats
  const total = prospects.length;
  const scored = prospects.filter(p => p.scoringTier !== "unscored").length;
  const scoredPct = Math.round((scored / total) * 100);
  const totalGiving = prospects.reduce((s, p) => s + (p.annualGiving || 0), 0);
  const hot = prospects.filter(p => p.scoringTier === "hot").length;
  const warm = prospects.filter(p => p.scoringTier === "warm").length;
  const known = prospects.filter(p => p.knownToIPD).length;
  const stale = prospects.filter(p => p.dataFreshness === "stale").length;
  const withNotes = prospects.filter(p => (p.prospectionNotes?.length || 0) > 0).length;
  const withAction = prospects.filter(p => !!p.nextActionDescription).length;
  const totalNotes = prospects.reduce((s, p) => s + (p.prospectionNotes?.length || 0), 0);

  const phaseCounts = PIPELINE_PHASES.filter(p => p.key !== "lost").map(phase => {
    const items = prospects.filter(p => phase.key === "insight" ? (!p.pipelinePhase || p.pipelinePhase === "insight") : p.pipelinePhase === phase.key);
    return { ...phase, count: items.length, value: items.reduce((s, p) => s + (p.annualGiving || 0), 0) };
  });

  const typeCounts = Object.entries(
    prospects.reduce<Record<string, number>>((acc, p) => { acc[p.type] = (acc[p.type] || 0) + 1; return acc; }, {})
  ).sort((a, b) => b[1] - a[1]);

  const top10 = [...prospects].sort((a, b) => b.totalScore - a.totalScore || (b.annualGiving || 0) - (a.annualGiving || 0)).slice(0, 10);

  const header = `
    <div class="header">
      <div>
        <h1>Institut Pasteur de Dakar</h1>
        <div class="subtitle">SICPS-IPD — ${isFr ? "Systeme Intelligent de Cartographie et de Suivi de la Prospection Strategique" : "Strategic Prospection Intelligence System"}</div>
      </div>
      <div class="header-right">
        <strong>${date}</strong><br/>
        ${isFr ? "Rapport genere automatiquement" : "Automatically generated report"}<br/>
        ${total} ${isFr ? "prospects analyses" : "prospects analyzed"}
      </div>
    </div>
  `;

  const footer = `<div class="footer">SICPS-IPD v2.0 — Institut Pasteur de Dakar — ${isFr ? "Rapport confidentiel" : "Confidential Report"} — ${date}</div>`;

  // Build specific report content
  let body = "";

  switch (type) {
    case "executive":
      body = buildExecutiveReport(isFr, total, scored, scoredPct, totalGiving, hot, warm, known, stale, withAction, phaseCounts, typeCounts, top10);
      break;
    case "pipeline":
      body = buildPipelineReport(isFr, prospects, phaseCounts, total);
      break;
    case "scoring":
      body = buildScoringReport(isFr, prospects, scored, scoredPct, hot, warm, total, top10);
      break;
    case "financial":
      body = buildFinancialReport(isFr, prospects, totalGiving, typeCounts);
      break;
    case "activity":
      body = buildActivityReport(isFr, prospects, totalNotes, withNotes, withAction);
      break;
  }

  const titles: Record<ReportType, string> = {
    executive: isFr ? "Rapport Executif — Situation de la Prospection" : "Executive Report — Prospection Status",
    pipeline: isFr ? "Rapport Pipeline de Prospection" : "Prospection Pipeline Report",
    scoring: isFr ? "Rapport Scoring 3A" : "3A Scoring Report",
    financial: isFr ? "Rapport d'Intelligence Financiere" : "Financial Intelligence Report",
    activity: isFr ? "Rapport d'Activite de Prospection" : "Prospection Activity Report",
  };

  return `<!DOCTYPE html><html lang="${locale}"><head><meta charset="utf-8"><title>${titles[type]}</title>${css}</head><body>${header}<h2 style="border-color:#0D1117;color:#0D1117;margin-top:0">${titles[type]}</h2>${body}${footer}</body></html>`;
}

function buildExecutiveReport(fr: boolean, total: number, scored: number, scoredPct: number, totalGiving: number, hot: number, warm: number, known: number, stale: number, withAction: number, phaseCounts: any[], typeCounts: [string, number][], top10: Prospect[]): string {
  return `
    <div class="section">
      <h2>${fr ? "Indicateurs Cles" : "Key Indicators"}</h2>
      <div class="kpi-grid">
        <div class="kpi"><div class="kpi-value" style="color:#00D4FF">${total}</div><div class="kpi-label">${fr ? "Total Prospects" : "Total Prospects"}</div></div>
        <div class="kpi"><div class="kpi-value" style="color:#8b5cf6">${scoredPct}%</div><div class="kpi-label">${fr ? "Scoring Complet" : "Scoring Complete"}</div></div>
        <div class="kpi"><div class="kpi-value" style="color:#10b981">${formatCurrency(totalGiving, true)}</div><div class="kpi-label">Annual Giving Total</div></div>
        <div class="kpi"><div class="kpi-value" style="color:#ef4444">${hot}</div><div class="kpi-label">${fr ? "Leads Chauds" : "Hot Leads"}</div></div>
        <div class="kpi"><div class="kpi-value" style="color:#f59e0b">${warm}</div><div class="kpi-label">${fr ? "Leads Tiedes" : "Warm Leads"}</div></div>
        <div class="kpi"><div class="kpi-value" style="color:#3b82f6">${known}</div><div class="kpi-label">Known to IPD</div></div>
      </div>
      ${stale > 0 ? `<div class="alert-box">⚠ ${stale} ${fr ? "prospects avec des donnees obsoletes (> 2 ans)" : "prospects with stale data (> 2 years)"}</div>` : ""}
    </div>

    <div class="section">
      <h2>${fr ? "Etat du Pipeline" : "Pipeline Status"}</h2>
      <table>
        <tr><th>${fr ? "Phase" : "Phase"}</th><th class="text-center">${fr ? "Nombre" : "Count"}</th><th class="text-right">${fr ? "Valeur Agregee" : "Aggregate Value"}</th><th>${fr ? "Repartition" : "Distribution"}</th></tr>
        ${phaseCounts.map(p => `
          <tr>
            <td><span class="badge" style="background:${p.color}20;color:${p.color}">${fr ? p.label : p.labelEn}</span></td>
            <td class="text-center mono">${p.count}</td>
            <td class="text-right mono">${formatCurrency(p.value, true)}</td>
            <td><div class="bar-container"><div class="bar-fill" style="width:${Math.max(5, (p.count / total) * 100)}%;background:${p.color}"></div></div></td>
          </tr>
        `).join("")}
      </table>
    </div>

    <div class="section">
      <h2>${fr ? "Repartition par Type" : "Distribution by Type"}</h2>
      <table>
        <tr><th>Type</th><th class="text-center">${fr ? "Nombre" : "Count"}</th><th class="text-right">%</th></tr>
        ${typeCounts.map(([type, count]) => `<tr><td>${type}</td><td class="text-center mono">${count}</td><td class="text-right mono">${Math.round((count / total) * 100)}%</td></tr>`).join("")}
      </table>
    </div>

    <div class="section">
      <h2>${fr ? "Top 10 Prospects" : "Top 10 Prospects"}</h2>
      <table>
        <tr><th>#</th><th>Organisation</th><th>Type</th><th class="text-center">Score</th><th class="text-right">Annual Giving</th></tr>
        ${top10.map((p, i) => `<tr><td class="mono">${i + 1}</td><td><strong>${p.organisation}</strong></td><td style="font-size:11px">${p.type}</td><td class="text-center mono" style="font-weight:700">${p.totalScore || "—"}</td><td class="text-right mono">${formatCurrency(p.annualGiving, true)}</td></tr>`).join("")}
      </table>
    </div>
  `;
}

function buildPipelineReport(fr: boolean, prospects: Prospect[], phaseCounts: any[], total: number): string {
  const phaseDetails = phaseCounts.map(phase => {
    const items = prospects.filter(p => phase.key === "insight" ? (!p.pipelinePhase || p.pipelinePhase === "insight") : p.pipelinePhase === phase.key);
    return { ...phase, items };
  });

  return `
    <div class="section">
      <h2>${fr ? "Vue d'ensemble Pipeline" : "Pipeline Overview"}</h2>
      <div class="kpi-grid">
        ${phaseCounts.map(p => `<div class="kpi"><div class="kpi-value" style="color:${p.color}">${p.count}</div><div class="kpi-label">${fr ? p.label : p.labelEn}</div></div>`).join("")}
      </div>
    </div>
    ${phaseDetails.filter(p => p.items.length > 0).map(phase => `
      <div class="section">
        <h2 style="border-color:${phase.color};color:${phase.color}">${fr ? phase.label : phase.labelEn} (${phase.items.length})</h2>
        <table>
          <tr><th>Organisation</th><th>Type</th><th class="text-center">Score</th><th class="text-right">Annual Giving</th><th>${fr ? "Prochaine Action" : "Next Action"}</th></tr>
          ${phase.items.sort((a: Prospect, b: Prospect) => b.totalScore - a.totalScore).map((p: Prospect) => `
            <tr><td><strong>${p.organisation}</strong></td><td style="font-size:11px">${p.type.split(" / ")[0]}</td><td class="text-center mono">${p.totalScore || "—"}</td><td class="text-right mono">${formatCurrency(p.annualGiving, true)}</td><td style="font-size:11px;color:#f59e0b">${p.nextActionDescription || "—"}</td></tr>
          `).join("")}
        </table>
      </div>
    `).join("")}
  `;
}

function buildScoringReport(fr: boolean, prospects: Prospect[], scored: number, scoredPct: number, hot: number, warm: number, total: number, top10: Prospect[]): string {
  const unscored = prospects.filter(p => p.scoringTier === "unscored").sort((a, b) => (b.annualGiving || 0) - (a.annualGiving || 0));
  const cool = prospects.filter(p => p.scoringTier === "cool").length;
  const cold = prospects.filter(p => p.scoringTier === "cold").length;

  return `
    <div class="section">
      <h2>${fr ? "Couverture du Scoring" : "Scoring Coverage"}</h2>
      <div class="kpi-grid">
        <div class="kpi"><div class="kpi-value" style="color:#8b5cf6">${scored}/${total}</div><div class="kpi-label">${fr ? "Scores" : "Scored"}</div></div>
        <div class="kpi"><div class="kpi-value" style="color:#8b5cf6">${scoredPct}%</div><div class="kpi-label">${fr ? "Couverture" : "Coverage"}</div></div>
        <div class="kpi"><div class="kpi-value" style="color:#ef4444">${hot}</div><div class="kpi-label">${fr ? "Chauds" : "Hot"}</div></div>
        <div class="kpi"><div class="kpi-value" style="color:#f59e0b">${warm}</div><div class="kpi-label">${fr ? "Tiedes" : "Warm"}</div></div>
        <div class="kpi"><div class="kpi-value" style="color:#3b82f6">${cool}</div><div class="kpi-label">${fr ? "Froids" : "Cool"}</div></div>
        <div class="kpi"><div class="kpi-value" style="color:#64748b">${cold}</div><div class="kpi-label">${fr ? "Tres froids" : "Cold"}</div></div>
      </div>
    </div>
    <div class="section">
      <h2>${fr ? "Top 10 par Score Composite" : "Top 10 by Composite Score"}</h2>
      <table>
        <tr><th>#</th><th>Organisation</th><th class="text-center">${fr ? "Affinite" : "Affinity"}</th><th class="text-center">${fr ? "Capacite" : "Ability"}</th><th class="text-center">${fr ? "Acces" : "Access"}</th><th class="text-center">Total</th><th class="text-right">Annual Giving</th></tr>
        ${top10.map((p, i) => `<tr><td class="mono">${i + 1}</td><td><strong>${p.organisation}</strong></td><td class="text-center mono" style="color:#8b5cf6">${p.affinity || "—"}</td><td class="text-center mono" style="color:#10b981">${p.ability || "—"}</td><td class="text-center mono" style="color:#f59e0b">${p.access || "—"}</td><td class="text-center mono" style="font-weight:700">${p.totalScore}</td><td class="text-right mono">${formatCurrency(p.annualGiving, true)}</td></tr>`).join("")}
      </table>
    </div>
    ${unscored.length > 0 ? `
      <div class="section">
        <h2>${fr ? "Prospects a Scorer (Prioritaires)" : "Prospects to Score (Priority)"}</h2>
        <table>
          <tr><th>Organisation</th><th>Type</th><th class="text-right">Annual Giving</th><th>Known to IPD</th></tr>
          ${unscored.slice(0, 15).map(p => `<tr><td><strong>${p.organisation}</strong></td><td style="font-size:11px">${p.type}</td><td class="text-right mono">${formatCurrency(p.annualGiving, true)}</td><td class="text-center">${p.knownToIPD ? "✅" : "—"}</td></tr>`).join("")}
        </table>
      </div>
    ` : ""}
  `;
}

function buildFinancialReport(fr: boolean, prospects: Prospect[], totalGiving: number, typeCounts: [string, number][]): string {
  const tiers = { mega: prospects.filter(p => p.fundingTier === "mega"), major: prospects.filter(p => p.fundingTier === "major"), mid: prospects.filter(p => p.fundingTier === "mid"), emerging: prospects.filter(p => p.fundingTier === "emerging") };
  const givingByType = typeCounts.map(([type]) => {
    const group = prospects.filter(p => p.type === type);
    return { type, total: group.reduce((s, p) => s + (p.annualGiving || 0), 0), count: group.length };
  }).sort((a, b) => b.total - a.total);

  return `
    <div class="section">
      <h2>${fr ? "Indicateurs Financiers" : "Financial Indicators"}</h2>
      <div class="kpi-grid">
        <div class="kpi"><div class="kpi-value" style="color:#10b981">${formatCurrency(totalGiving, true)}</div><div class="kpi-label">Annual Giving Total</div></div>
        <div class="kpi"><div class="kpi-value" style="color:#ef4444">${tiers.mega.length}</div><div class="kpi-label">${fr ? "Mega (> $1B)" : "Mega (> $1B)"}</div></div>
        <div class="kpi"><div class="kpi-value" style="color:#f59e0b">${tiers.major.length}</div><div class="kpi-label">${fr ? "Major ($50M-$1B)" : "Major ($50M-$1B)"}</div></div>
        <div class="kpi"><div class="kpi-value" style="color:#3b82f6">${tiers.mid.length}</div><div class="kpi-label">${fr ? "Mid ($1M-$50M)" : "Mid ($1M-$50M)"}</div></div>
        <div class="kpi"><div class="kpi-value" style="color:#10b981">${tiers.emerging.length}</div><div class="kpi-label">${fr ? "Emergent (< $1M)" : "Emerging (< $1M)"}</div></div>
      </div>
    </div>
    <div class="section">
      <h2>${fr ? "Annual Giving par Type d'Organisation" : "Annual Giving by Organisation Type"}</h2>
      <table>
        <tr><th>Type</th><th class="text-center">${fr ? "Nombre" : "Count"}</th><th class="text-right">Annual Giving</th><th class="text-right">${fr ? "Moyenne" : "Average"}</th></tr>
        ${givingByType.map(g => `<tr><td>${g.type}</td><td class="text-center mono">${g.count}</td><td class="text-right mono" style="font-weight:600">${formatCurrency(g.total, true)}</td><td class="text-right mono">${formatCurrency(g.count > 0 ? g.total / g.count : 0, true)}</td></tr>`).join("")}
      </table>
    </div>
    <div class="section">
      <h2>${fr ? "Detail Mega-Donateurs (> $1B)" : "Mega-Donors Detail (> $1B)"}</h2>
      <table>
        <tr><th>Organisation</th><th>Type</th><th class="text-right">Annual Giving</th><th class="text-right">Avg Grant</th><th class="text-center"># Grants</th></tr>
        ${tiers.mega.sort((a, b) => (b.annualGiving || 0) - (a.annualGiving || 0)).map(p => `<tr><td><strong>${p.organisation}</strong></td><td style="font-size:11px">${p.type}</td><td class="text-right mono">${formatCurrency(p.annualGiving, true)}</td><td class="text-right mono">${formatCurrency(p.avgGrantSize, true)}</td><td class="text-center mono">${p.grantCount?.toLocaleString() || "—"}</td></tr>`).join("")}
      </table>
    </div>
  `;
}

function buildActivityReport(fr: boolean, prospects: Prospect[], totalNotes: number, withNotes: number, withAction: number): string {
  const allNotes = prospects.flatMap(p => (p.prospectionNotes || []).map(n => ({ ...n, organisation: p.organisation }))).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  const upcomingActions = prospects.filter(p => p.nextActionDescription).sort((a, b) => (a.nextActionDate || "9999").localeCompare(b.nextActionDate || "9999"));

  return `
    <div class="section">
      <h2>${fr ? "Indicateurs d'Activite" : "Activity Indicators"}</h2>
      <div class="kpi-grid">
        <div class="kpi"><div class="kpi-value" style="color:#f59e0b">${totalNotes}</div><div class="kpi-label">${fr ? "Notes Total" : "Total Notes"}</div></div>
        <div class="kpi"><div class="kpi-value" style="color:#3b82f6">${withNotes}</div><div class="kpi-label">${fr ? "Prospects avec Notes" : "Prospects with Notes"}</div></div>
        <div class="kpi"><div class="kpi-value" style="color:#10b981">${withAction}</div><div class="kpi-label">${fr ? "Actions Planifiees" : "Planned Actions"}</div></div>
        <div class="kpi"><div class="kpi-value" style="color:#64748b">${prospects.length - withNotes}</div><div class="kpi-label">${fr ? "Sans Activite" : "No Activity"}</div></div>
      </div>
    </div>
    ${upcomingActions.length > 0 ? `
      <div class="section">
        <h2>${fr ? "Prochaines Actions Planifiees" : "Upcoming Planned Actions"}</h2>
        <table>
          <tr><th>${fr ? "Date" : "Date"}</th><th>Organisation</th><th>${fr ? "Action" : "Action"}</th><th>${fr ? "Responsable" : "Assignee"}</th></tr>
          ${upcomingActions.map(p => `<tr><td class="mono" style="white-space:nowrap">${p.nextActionDate || "—"}</td><td><strong>${p.organisation}</strong></td><td>${p.nextActionDescription}</td><td>${p.assignedTo || "—"}</td></tr>`).join("")}
        </table>
      </div>
    ` : ""}
    ${allNotes.length > 0 ? `
      <div class="section">
        <h2>${fr ? "Journal des Interactions Recentes" : "Recent Interactions Log"}</h2>
        <table>
          <tr><th>Date</th><th>Organisation</th><th>Type</th><th>${fr ? "Resume" : "Summary"}</th><th>${fr ? "Auteur" : "Author"}</th></tr>
          ${allNotes.slice(0, 30).map((n: any) => `<tr><td class="mono" style="white-space:nowrap">${n.date}</td><td><strong>${n.organisation}</strong></td><td>${n.type}</td><td>${n.summary}</td><td>${n.author}</td></tr>`).join("")}
        </table>
        ${allNotes.length > 30 ? `<p style="color:#94a3b8;font-size:11px;margin-top:8px">${fr ? `... et ${allNotes.length - 30} autres notes` : `... and ${allNotes.length - 30} more notes`}</p>` : ""}
      </div>
    ` : ""}
  `;
}
