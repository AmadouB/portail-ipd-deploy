"use client";

import { cn } from "@/lib/utils";
import type { ScoringTier, FundingTier, PipelinePhase, ConfidenceLevel } from "@/types";
import { TIER_COLORS, TIER_LABELS } from "@/lib/scoring/composite-index";
import { FUNDING_TIER_COLORS, FUNDING_TIER_LABELS } from "@/lib/scoring/tier-classifier";
import { PIPELINE_PHASES, CONFIDENCE_COLORS } from "@/types";

interface StatusBadgeProps {
  variant: "scoring" | "funding" | "pipeline" | "confidence" | "custom";
  value: string;
  size?: "sm" | "md";
  pulse?: boolean;
  locale?: "fr" | "en";
}

export function StatusBadge({ variant, value, size = "sm", pulse = false, locale = "fr" }: StatusBadgeProps) {
  let color = "#64748b";
  let label = value;

  if (variant === "scoring") {
    const tier = value as ScoringTier;
    color = TIER_COLORS[tier] || "#64748b";
    label = locale === "fr" ? TIER_LABELS[tier]?.fr : TIER_LABELS[tier]?.en || value;
  } else if (variant === "funding") {
    const tier = value as FundingTier;
    color = FUNDING_TIER_COLORS[tier] || "#64748b";
    label = locale === "fr" ? FUNDING_TIER_LABELS[tier]?.fr : FUNDING_TIER_LABELS[tier]?.en || value;
  } else if (variant === "pipeline") {
    const phase = PIPELINE_PHASES.find((p) => p.key === value);
    color = phase?.color || "#64748b";
    label = locale === "fr" ? phase?.label || value : phase?.labelEn || value;
  } else if (variant === "confidence") {
    color = CONFIDENCE_COLORS[value as ConfidenceLevel] || "#64748b";
    label = value;
  }

  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full font-medium",
        size === "sm" ? "px-2 py-0.5 text-xs" : "px-3 py-1 text-sm"
      )}
      style={{
        backgroundColor: `${color}20`,
        color: color,
        border: `1px solid ${color}40`,
      }}
    >
      {pulse && (
        <span
          className="w-1.5 h-1.5 rounded-full pulse-dot"
          style={{ backgroundColor: color }}
        />
      )}
      {label}
    </span>
  );
}
