"use client";

import { cn } from "@/lib/utils";
import { GlassPanel } from "./glass-panel";
import { AnimatedNumber } from "./animated-number";
import { TrendingUp, TrendingDown, Minus } from "lucide-react";

interface KpiCardProps {
  label: string;
  value: number;
  previousValue?: number;
  unit?: string;
  trend?: "up" | "down" | "stable";
  icon?: React.ReactNode;
  color?: string;
  glow?: "cyan" | "emerald" | "amber" | "red" | "purple" | "blue" | "none";
  delay?: number;
  format?: (n: number) => string;
  subtitle?: string;
}

export function KpiCard({
  label,
  value,
  previousValue,
  unit = "",
  trend,
  icon,
  color,
  glow = "none",
  delay = 0,
  format,
  subtitle,
}: KpiCardProps) {
  const trendIcon = trend === "up" ? (
    <TrendingUp className="h-4 w-4 text-emerald-400" />
  ) : trend === "down" ? (
    <TrendingDown className="h-4 w-4 text-red-400" />
  ) : trend ? (
    <Minus className="h-4 w-4 text-muted-foreground" />
  ) : null;

  const change = previousValue
    ? (((value - previousValue) / previousValue) * 100).toFixed(1)
    : null;

  return (
    <GlassPanel glow={glow} delay={delay} className="flex flex-col gap-3">
      <div className="flex items-center justify-between">
        <span className="text-sm text-muted-foreground">{label}</span>
        {icon && (
          <div className="p-2 rounded-lg" style={{ backgroundColor: color ? `${color}15` : undefined }}>
            <div style={{ color }}>{icon}</div>
          </div>
        )}
      </div>
      <div className="flex items-end gap-2">
        <span className="text-3xl font-bold tracking-tight font-[var(--font-mono)]">
          <AnimatedNumber value={value} format={format} />
        </span>
        {unit && <span className="text-sm text-muted-foreground mb-1">{unit}</span>}
      </div>
      {subtitle && (
        <span className="text-xs text-muted-foreground">{subtitle}</span>
      )}
      {(trendIcon || change) && (
        <div className="flex items-center gap-2 text-sm">
          {trendIcon}
          {change && (
            <span className={cn(
              Number(change) > 0 ? "text-emerald-400" : Number(change) < 0 ? "text-red-400" : "text-muted-foreground"
            )}>
              {Number(change) > 0 ? "+" : ""}{change}%
            </span>
          )}
        </div>
      )}
    </GlassPanel>
  );
}
