"use client";

import { cn } from "@/lib/utils";
import { motion, type Transition } from "framer-motion";

interface GlassPanelProps {
  children: React.ReactNode;
  className?: string;
  glow?: "cyan" | "emerald" | "amber" | "red" | "purple" | "blue" | "none";
  hover?: boolean;
  animate?: boolean;
  delay?: number;
}

const glowClasses: Record<string, string> = {
  cyan: "glow-cyan",
  emerald: "glow-emerald",
  amber: "glow-amber",
  red: "glow-red",
  purple: "glow-purple",
  blue: "glow-blue",
  none: "",
};

export function GlassPanel({
  children,
  className,
  glow = "none",
  hover = false,
  animate = true,
  delay = 0,
}: GlassPanelProps) {
  const classes = cn(
    "glass rounded-2xl p-6",
    glowClasses[glow],
    hover && "glass-hover transition-all duration-300 cursor-pointer",
    className
  );

  if (!animate) {
    return <div className={classes}>{children}</div>;
  }

  const transition: Transition = { duration: 0.5, delay, ease: "easeOut" as const };

  return (
    <motion.div
      className={classes}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={transition}
    >
      {children}
    </motion.div>
  );
}
