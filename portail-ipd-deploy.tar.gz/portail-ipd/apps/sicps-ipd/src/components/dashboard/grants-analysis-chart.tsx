"use client";

import { useMemo } from "react";
import type { Prospect } from "@/types";
import { ORG_TYPE_COLORS } from "@/types";
import { useTranslation } from "@/lib/i18n";
import { GlassPanel } from "@/components/shared/glass-panel";
import { formatCurrency } from "@/lib/utils";
import {
  PieChart, Pie, Cell, ResponsiveContainer, Tooltip,
  BarChart, Bar, XAxis, YAxis, CartesianGrid,
} from "recharts";
import { DollarSign } from "lucide-react";

interface GrantsAnalysisChartProps {
  prospects: Prospect[];
}

const SHORT_TYPE: Record<string, string> = {
  "Research / Academic": "Research",
  "Multilateral / Government": "Multilateral",
  "Major Grant-Making Foundation": "Major Found.",
  "Advisory / Intermediary": "Advisory",
  "Thematic / Regional Foundation": "Thematic",
  "Family Foundation / Family Office": "Family",
  "Impact Investor / Social Investment": "Impact",
};

export function GrantsAnalysisChart({ prospects }: GrantsAnalysisChartProps) {
  const { locale } = useTranslation();

  // Annual Giving distribution by type (for donut)
  const givingByType = useMemo(() => {
    const map = new Map<string, number>();
    prospects.forEach((p) => {
      if (p.annualGiving) {
        map.set(p.type, (map.get(p.type) || 0) + p.annualGiving);
      }
    });
    return Array.from(map.entries())
      .map(([type, value]) => ({
        name: SHORT_TYPE[type] || type,
        fullName: type,
        value,
        fill: ORG_TYPE_COLORS[type as keyof typeof ORG_TYPE_COLORS] || "#64748b",
      }))
      .sort((a, b) => b.value - a.value);
  }, [prospects]);

  // Avg Grant Size + # Grants by type (for bar chart)
  const grantMetrics = useMemo(() => {
    const map = new Map<string, { totalGrants: number; totalAvgGrant: number; count: number }>();
    prospects.forEach((p) => {
      const key = SHORT_TYPE[p.type] || p.type;
      const existing = map.get(key) || { totalGrants: 0, totalAvgGrant: 0, count: 0 };
      existing.totalGrants += p.grantCount || 0;
      if (p.avgGrantSize) {
        existing.totalAvgGrant += p.avgGrantSize;
        existing.count++;
      }
      map.set(key, existing);
    });
    return Array.from(map.entries())
      .map(([name, data]) => ({
        name,
        grants: data.totalGrants,
        avgGrant: data.count > 0 ? Math.round(data.totalAvgGrant / data.count) : 0,
      }))
      .filter((d) => d.grants > 0 || d.avgGrant > 0)
      .sort((a, b) => b.grants - a.grants);
  }, [prospects]);

  // Confidence distribution (small donut)
  const confidenceData = useMemo(() => {
    const counts = new Map<string, number>();
    prospects.forEach((p) => {
      counts.set(p.confidence, (counts.get(p.confidence) || 0) + 1);
    });
    const colors: Record<string, string> = {
      High: "#10b981", Verified: "#3b82f6", Reported: "#8b5cf6",
      Medium: "#f59e0b", Estimated: "#f97316", Low: "#ef4444",
    };
    return Array.from(counts.entries())
      .map(([name, value]) => ({ name, value, fill: colors[name] || "#64748b" }))
      .sort((a, b) => b.value - a.value);
  }, [prospects]);

  return (
    <GlassPanel delay={0.2} className="h-full">
      <div className="flex items-center gap-2 mb-4">
        <DollarSign className="w-5 h-5 text-[#10b981]" />
        <h3 className="text-lg font-semibold">
          {locale === "fr" ? "Analyse Grants & Financements" : "Grants & Funding Analysis"}
        </h3>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Annual Giving by Type - Donut */}
        <div>
          <h4 className="text-xs font-semibold text-muted-foreground uppercase mb-3">
            {locale === "fr" ? "Annual Giving par Type" : "Annual Giving by Type"}
          </h4>
          <div style={{ height: 200 }}>
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={givingByType}
                  cx="50%"
                  cy="50%"
                  innerRadius={45}
                  outerRadius={80}
                  paddingAngle={2}
                  dataKey="value"
                  stroke="none"
                >
                  {givingByType.map((entry, i) => (
                    <Cell key={i} fill={entry.fill} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    backgroundColor: "#161b22",
                    border: "1px solid rgba(255,255,255,0.1)",
                    borderRadius: 12,
                    fontSize: 12,
                  }}
                  formatter={(value: any) => [formatCurrency(Number(value), true), "Annual Giving"]}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
          {/* Top 3 values */}
          <div className="space-y-1 mt-2">
            {givingByType.slice(0, 4).map((item) => (
              <div key={item.fullName} className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full" style={{ backgroundColor: item.fill }} />
                <span className="text-[11px] text-muted-foreground flex-1 truncate">{item.name}</span>
                <span className="text-[11px] font-mono font-bold">{formatCurrency(item.value, true)}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Grants count by type - Bar chart */}
        <div>
          <h4 className="text-xs font-semibold text-muted-foreground uppercase mb-3">
            {locale === "fr" ? "Nombre de Grants par Type" : "Grant Count by Type"}
          </h4>
          {grantMetrics.length > 0 ? (
            <div style={{ height: 200 }}>
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={grantMetrics} layout="vertical">
                  <CartesianGrid stroke="rgba(255,255,255,0.04)" horizontal={false} />
                  <XAxis
                    type="number"
                    tick={{ fill: "rgba(255,255,255,0.4)", fontSize: 10 }}
                    tickFormatter={(v) => v >= 1000 ? `${(v / 1000).toFixed(0)}K` : v.toString()}
                  />
                  <YAxis
                    dataKey="name"
                    type="category"
                    width={75}
                    tick={{ fill: "rgba(255,255,255,0.6)", fontSize: 10 }}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "#161b22",
                      border: "1px solid rgba(255,255,255,0.1)",
                      borderRadius: 12,
                      fontSize: 12,
                    }}
                    formatter={(value: any) => [Number(value).toLocaleString(), "# Grants"]}
                  />
                  <Bar dataKey="grants" fill="#10b981" radius={[0, 4, 4, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          ) : (
            <div className="flex items-center justify-center h-[200px] text-sm text-muted-foreground">
              {locale === "fr" ? "Donnees non disponibles" : "Data not available"}
            </div>
          )}

          {/* Avg grant size highlights */}
          {grantMetrics.filter((m) => m.avgGrant > 0).length > 0 && (
            <div className="mt-3 space-y-1">
              <h4 className="text-[10px] font-semibold text-muted-foreground uppercase">
                {locale === "fr" ? "Taille moyenne grant" : "Avg Grant Size"}
              </h4>
              {grantMetrics.filter((m) => m.avgGrant > 0).slice(0, 3).map((item) => (
                <div key={item.name} className="flex items-center justify-between text-[11px]">
                  <span className="text-muted-foreground">{item.name}</span>
                  <span className="font-mono font-bold text-[#f59e0b]">{formatCurrency(item.avgGrant, true)}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Confidence Distribution - small donut - full width */}
        <div className="md:col-span-2">
          <h4 className="text-xs font-semibold text-muted-foreground uppercase mb-3">
            {locale === "fr" ? "Niveaux de Confiance des Donnees" : "Data Confidence Levels"}
          </h4>
          <div className="flex items-center gap-6">
            <div style={{ width: 120, height: 120 }}>
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={confidenceData}
                    cx="50%"
                    cy="50%"
                    innerRadius={30}
                    outerRadius={50}
                    paddingAngle={2}
                    dataKey="value"
                    stroke="none"
                  >
                    {confidenceData.map((entry, i) => (
                      <Cell key={i} fill={entry.fill} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "#161b22",
                      border: "1px solid rgba(255,255,255,0.1)",
                      borderRadius: 12,
                      fontSize: 11,
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="flex-1 grid grid-cols-3 gap-x-6 gap-y-1">
              {confidenceData.map((item) => (
                <div key={item.name} className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full shrink-0" style={{ backgroundColor: item.fill }} />
                  <span className="text-xs text-muted-foreground">{item.name}</span>
                  <span className="text-xs font-mono font-bold ml-auto" style={{ color: item.fill }}>
                    {item.value}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </GlassPanel>
  );
}
