"use client";

import type { Prospect } from "@/types";
import { useTranslation } from "@/lib/i18n";
import { GlassPanel } from "@/components/shared/glass-panel";
import { AlertTriangle, Clock, Target, Database } from "lucide-react";

interface AlertFeedProps {
  prospects: Prospect[];
}

interface Alert {
  id: string;
  type: "warning" | "info" | "danger";
  icon: React.ReactNode;
  message: string;
  count?: number;
}

export function AlertFeed({ prospects }: AlertFeedProps) {
  const { t, locale } = useTranslation();

  const alerts: Alert[] = [];

  // Unscored prospects
  const unscored = prospects.filter((p) => p.scoringTier === "unscored").length;
  if (unscored > 0) {
    alerts.push({
      id: "unscored",
      type: "warning",
      icon: <Target className="w-4 h-4" />,
      message: locale === "fr"
        ? `${unscored} prospects n'ont pas encore de score 3A`
        : `${unscored} prospects have no 3A score yet`,
      count: unscored,
    });
  }

  // Stale data
  const stale = prospects.filter((p) => p.dataFreshness === "stale").length;
  if (stale > 0) {
    alerts.push({
      id: "stale",
      type: "danger",
      icon: <Database className="w-4 h-4" />,
      message: locale === "fr"
        ? `${stale} prospects avec des donnees obsoletes (> 2 ans)`
        : `${stale} prospects with stale data (> 2 years old)`,
      count: stale,
    });
  }

  // No pipeline phase assigned
  const noPipeline = prospects.filter((p) => !p.pipelinePhase).length;
  if (noPipeline > 0) {
    alerts.push({
      id: "no-pipeline",
      type: "info",
      icon: <Clock className="w-4 h-4" />,
      message: locale === "fr"
        ? `${noPipeline} prospects sans phase pipeline assignee`
        : `${noPipeline} prospects without pipeline phase`,
      count: noPipeline,
    });
  }

  // Known to IPD but not engaged
  const knownNotEngaged = prospects.filter(
    (p) => p.knownToIPD === true && (!p.pipelinePhase || p.pipelinePhase === "insight")
  ).length;
  if (knownNotEngaged > 0) {
    alerts.push({
      id: "known-idle",
      type: "warning",
      icon: <AlertTriangle className="w-4 h-4" />,
      message: locale === "fr"
        ? `${knownNotEngaged} prospects connus de l'IPD mais non engages`
        : `${knownNotEngaged} prospects known to IPD but not engaged`,
      count: knownNotEngaged,
    });
  }

  const typeColors = {
    warning: "#f59e0b",
    danger: "#ef4444",
    info: "#3b82f6",
  };

  return (
    <GlassPanel delay={0.25} className="h-full">
      <div className="flex items-center gap-2 mb-4">
        <AlertTriangle className="w-5 h-5 text-[#f59e0b]" />
        <h3 className="text-lg font-semibold">{t("dashboard.alerts")}</h3>
      </div>

      <div className="space-y-3">
        {alerts.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-8">
            {locale === "fr" ? "Aucune alerte" : "No alerts"}
          </p>
        ) : (
          alerts.map((alert) => (
            <div
              key={alert.id}
              className="flex items-start gap-3 p-3 rounded-xl bg-white/3 border border-white/5"
            >
              <div
                className="flex items-center justify-center w-8 h-8 rounded-lg shrink-0 mt-0.5"
                style={{
                  backgroundColor: `${typeColors[alert.type]}15`,
                  color: typeColors[alert.type],
                }}
              >
                {alert.icon}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm text-foreground">{alert.message}</p>
              </div>
              {alert.count && (
                <span
                  className="text-xs font-mono font-bold px-2 py-0.5 rounded-full shrink-0"
                  style={{
                    backgroundColor: `${typeColors[alert.type]}20`,
                    color: typeColors[alert.type],
                  }}
                >
                  {alert.count}
                </span>
              )}
            </div>
          ))
        )}
      </div>
    </GlassPanel>
  );
}
