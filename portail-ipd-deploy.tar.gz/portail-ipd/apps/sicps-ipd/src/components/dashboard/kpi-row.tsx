"use client";

import type { Prospect } from "@/types";
import { useTranslation } from "@/lib/i18n";
import { KpiCard } from "@/components/shared/kpi-card";
import { formatCurrency } from "@/lib/utils";
import { Users, Target, DollarSign, Flame, TrendingUp, Database } from "lucide-react";

interface KpiRowProps {
  prospects: Prospect[];
}

export function KpiRow({ prospects }: KpiRowProps) {
  const { t } = useTranslation();

  const total = prospects.length;
  const scored = prospects.filter((p) => p.scoringTier !== "unscored").length;
  const scoredPct = total > 0 ? Math.round((scored / total) * 100) : 0;
  const hotLeads = prospects.filter((p) => p.scoringTier === "hot").length;

  const totalGiving = prospects.reduce((sum, p) => sum + (p.annualGiving || 0), 0);

  const engaged = prospects.filter((p) =>
    p.pipelinePhase && p.pipelinePhase !== "insight" && p.pipelinePhase !== "lost"
  ).length;
  const engagementRate = total > 0 ? Math.round((engaged / total) * 100) : 0;

  const fresh = prospects.filter((p) => p.dataFreshness === "fresh").length;
  const freshPct = total > 0 ? Math.round((fresh / total) * 100) : 0;

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
      <KpiCard
        label={t("dashboard.totalProspects")}
        value={total}
        icon={<Users className="w-4 h-4" />}
        color="#00D4FF"
        glow="cyan"
        delay={0}
      />
      <KpiCard
        label={t("dashboard.scoredProspects")}
        value={scoredPct}
        unit="%"
        icon={<Target className="w-4 h-4" />}
        color="#8b5cf6"
        glow="purple"
        delay={0.05}
        subtitle={`${scored}/${total}`}
      />
      <KpiCard
        label={t("dashboard.pipelineValue")}
        value={totalGiving}
        icon={<DollarSign className="w-4 h-4" />}
        color="#10b981"
        glow="emerald"
        delay={0.1}
        format={(n) => formatCurrency(n, true)}
      />
      <KpiCard
        label={t("dashboard.hotLeads")}
        value={hotLeads}
        icon={<Flame className="w-4 h-4" />}
        color="#ef4444"
        glow="red"
        delay={0.15}
      />
      <KpiCard
        label={t("dashboard.engagementRate")}
        value={engagementRate}
        unit="%"
        icon={<TrendingUp className="w-4 h-4" />}
        color="#3b82f6"
        glow="blue"
        delay={0.2}
      />
      <KpiCard
        label={t("dashboard.dataFreshness")}
        value={freshPct}
        unit="%"
        icon={<Database className="w-4 h-4" />}
        color="#f59e0b"
        glow="amber"
        delay={0.25}
      />
    </div>
  );
}
