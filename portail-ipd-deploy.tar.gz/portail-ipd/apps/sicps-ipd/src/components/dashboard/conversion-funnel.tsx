"use client";

import type { Prospect } from "@/types";
import { PIPELINE_PHASES } from "@/types";
import { useTranslation } from "@/lib/i18n";
import { GlassPanel } from "@/components/shared/glass-panel";
import { Filter } from "lucide-react";

interface ConversionFunnelProps {
  prospects: Prospect[];
}

export function ConversionFunnel({ prospects }: ConversionFunnelProps) {
  const { t, locale } = useTranslation();

  const activePhases = PIPELINE_PHASES.filter((p) => p.key !== "lost");

  const phaseCounts = activePhases.map((phase, i) => {
    let count: number;
    if (i === 0) {
      // Insight includes unassigned
      count = prospects.filter((p) => !p.pipelinePhase || p.pipelinePhase === phase.key).length;
    } else {
      count = prospects.filter((p) => p.pipelinePhase === phase.key).length;
    }
    return {
      ...phase,
      count,
      label: locale === "fr" ? phase.label : phase.labelEn,
    };
  });

  const maxCount = Math.max(...phaseCounts.map((p) => p.count), 1);

  return (
    <GlassPanel delay={0.15} className="h-full">
      <div className="flex items-center gap-2 mb-6">
        <Filter className="w-5 h-5 text-[#8b5cf6]" />
        <h3 className="text-lg font-semibold">{t("dashboard.conversionFunnel")}</h3>
      </div>

      <div className="flex flex-col items-center gap-2">
        {phaseCounts.map((phase, i) => {
          const widthPct = Math.max(20, (phase.count / maxCount) * 100);

          return (
            <div key={phase.key} className="w-full flex flex-col items-center">
              <div
                className="relative flex items-center justify-center rounded-lg py-3 transition-all duration-500"
                style={{
                  width: `${widthPct}%`,
                  backgroundColor: `${phase.color}20`,
                  border: `1px solid ${phase.color}40`,
                }}
              >
                <span className="text-xs font-medium" style={{ color: phase.color }}>
                  {phase.label}
                </span>
                <span className="absolute right-2 text-xs font-mono text-muted-foreground">
                  {phase.count}
                </span>
              </div>
              {i < phaseCounts.length - 1 && (
                <div className="w-px h-3 bg-white/10" />
              )}
            </div>
          );
        })}
      </div>
    </GlassPanel>
  );
}
