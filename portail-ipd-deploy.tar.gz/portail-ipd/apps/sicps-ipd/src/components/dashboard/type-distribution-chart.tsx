"use client";

import { useMemo } from "react";
import type { Prospect } from "@/types";
import { ORG_TYPE_COLORS } from "@/types";
import { useTranslation } from "@/lib/i18n";
import { GlassPanel } from "@/components/shared/glass-panel";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from "recharts";
import { PieChart as PieIcon } from "lucide-react";

interface TypeDistributionChartProps {
  prospects: Prospect[];
}

// Short labels for the chart legend
const SHORT_LABELS: Record<string, { fr: string; en: string }> = {
  "Research / Academic": { fr: "Recherche", en: "Research" },
  "Multilateral / Government": { fr: "Multilateral", en: "Multilateral" },
  "Major Grant-Making Foundation": { fr: "Fondation Majeure", en: "Major Foundation" },
  "Advisory / Intermediary": { fr: "Conseil", en: "Advisory" },
  "Thematic / Regional Foundation": { fr: "Fondation Thematique", en: "Thematic Found." },
  "Family Foundation / Family Office": { fr: "Family Office", en: "Family Office" },
  "Impact Investor / Social Investment": { fr: "Impact Investor", en: "Impact Investor" },
};

export function TypeDistributionChart({ prospects }: TypeDistributionChartProps) {
  const { locale } = useTranslation();

  const data = useMemo(() => {
    const counts = new Map<string, number>();
    prospects.forEach((p) => {
      counts.set(p.type, (counts.get(p.type) || 0) + 1);
    });
    return Array.from(counts.entries())
      .map(([type, count]) => ({
        name: locale === "fr" ? SHORT_LABELS[type]?.fr || type : SHORT_LABELS[type]?.en || type,
        fullName: type,
        value: count,
        fill: ORG_TYPE_COLORS[type as keyof typeof ORG_TYPE_COLORS] || "#64748b",
        pct: Math.round((count / prospects.length) * 100),
      }))
      .sort((a, b) => b.value - a.value);
  }, [prospects, locale]);

  return (
    <GlassPanel delay={0.15} className="h-full">
      <div className="flex items-center gap-2 mb-4">
        <PieIcon className="w-5 h-5 text-[#8b5cf6]" />
        <h3 className="text-lg font-semibold">
          {locale === "fr" ? "Repartition par Type" : "Distribution by Type"}
        </h3>
      </div>

      <div className="flex flex-col lg:flex-row items-center gap-4">
        {/* Donut chart */}
        <div className="w-full lg:w-1/2" style={{ height: 220 }}>
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={data}
                cx="50%"
                cy="50%"
                innerRadius={55}
                outerRadius={90}
                paddingAngle={2}
                dataKey="value"
                stroke="none"
              >
                {data.map((entry, i) => (
                  <Cell key={i} fill={entry.fill} />
                ))}
              </Pie>
              <Tooltip
                contentStyle={{
                  backgroundColor: "#161b22",
                  border: "1px solid rgba(255,255,255,0.1)",
                  borderRadius: 12,
                  fontSize: 12,
                }}
                formatter={(value: any, name: any) => [`${value} prospects`, name]}
              />
            </PieChart>
          </ResponsiveContainer>
        </div>

        {/* Legend list */}
        <div className="w-full lg:w-1/2 space-y-1.5">
          {data.map((item) => (
            <div key={item.fullName} className="flex items-center gap-2 group">
              <div className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: item.fill }} />
              <span className="text-xs text-muted-foreground group-hover:text-foreground transition-colors truncate flex-1">
                {item.name}
              </span>
              <span className="text-xs font-mono font-bold" style={{ color: item.fill }}>
                {item.value}
              </span>
              <span className="text-[10px] text-muted-foreground font-mono w-8 text-right">
                {item.pct}%
              </span>
            </div>
          ))}
        </div>
      </div>
    </GlassPanel>
  );
}
