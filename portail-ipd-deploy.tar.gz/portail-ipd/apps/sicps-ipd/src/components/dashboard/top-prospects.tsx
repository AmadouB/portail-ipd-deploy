"use client";

import type { Prospect } from "@/types";
import { useTranslation } from "@/lib/i18n";
import { GlassPanel } from "@/components/shared/glass-panel";
import { StatusBadge } from "@/components/shared/status-badge";
import { formatCurrency } from "@/lib/utils";
import { Trophy } from "lucide-react";
import Link from "next/link";

interface TopProspectsProps {
  prospects: Prospect[];
}

export function TopProspects({ prospects }: TopProspectsProps) {
  const { t, locale } = useTranslation();

  // Sort by totalScore, then by annualGiving
  const top10 = [...prospects]
    .sort((a, b) => {
      if (b.totalScore !== a.totalScore) return b.totalScore - a.totalScore;
      return (b.annualGiving || 0) - (a.annualGiving || 0);
    })
    .slice(0, 10);

  return (
    <GlassPanel delay={0.2} className="h-full">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Trophy className="w-5 h-5 text-[#f59e0b]" />
          <h3 className="text-lg font-semibold">{t("dashboard.topProspects")}</h3>
        </div>
        <Link
          href="/radar"
          className="text-xs text-[#00D4FF] hover:underline"
        >
          {locale === "fr" ? "Voir tout →" : "View all →"}
        </Link>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="text-xs text-muted-foreground border-b border-white/5">
              <th className="text-left py-2 pr-4">#</th>
              <th className="text-left py-2 pr-4">{t("common.organisation")}</th>
              <th className="text-left py-2 pr-4">{t("common.type")}</th>
              <th className="text-right py-2 pr-4">Annual Giving</th>
              <th className="text-center py-2 pr-4">{t("common.score")}</th>
              <th className="text-center py-2">Tier</th>
            </tr>
          </thead>
          <tbody>
            {top10.map((prospect, i) => (
              <tr
                key={prospect.id}
                className="border-b border-white/3 hover:bg-white/3 transition-colors cursor-pointer"
              >
                <td className="py-2.5 pr-4 text-sm text-muted-foreground font-mono">
                  {i + 1}
                </td>
                <td className="py-2.5 pr-4">
                  <div className="flex items-center gap-2">
                    {prospect.scoringTier === "hot" && (
                      <span className="w-2 h-2 rounded-full bg-red-500 pulse-dot" />
                    )}
                    <span className="text-sm font-medium truncate max-w-[200px]">
                      {prospect.organisation}
                    </span>
                  </div>
                </td>
                <td className="py-2.5 pr-4">
                  <span className="text-xs text-muted-foreground truncate max-w-[120px] block">
                    {prospect.type}
                  </span>
                </td>
                <td className="py-2.5 pr-4 text-right">
                  <span className="text-sm font-mono">
                    {formatCurrency(prospect.annualGiving, true)}
                  </span>
                </td>
                <td className="py-2.5 pr-4 text-center">
                  <span className="text-sm font-mono font-bold">
                    {prospect.totalScore || "—"}
                  </span>
                </td>
                <td className="py-2.5 text-center">
                  <StatusBadge
                    variant="scoring"
                    value={prospect.scoringTier}
                    locale={locale}
                  />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </GlassPanel>
  );
}
