"use client";

import type { Prospect } from "@/types";
import { PIPELINE_PHASES } from "@/types";
import { useTranslation } from "@/lib/i18n";
import { GlassPanel } from "@/components/shared/glass-panel";
import { formatCurrency } from "@/lib/utils";
import { BarChart3 } from "lucide-react";

interface PipelineMonitorProps {
  prospects: Prospect[];
}

export function PipelineMonitor({ prospects }: PipelineMonitorProps) {
  const { t, locale } = useTranslation();

  const phases = PIPELINE_PHASES.filter((p) => p.key !== "lost").map((phase) => {
    const inPhase = prospects.filter((p) => p.pipelinePhase === phase.key);
    const value = inPhase.reduce((sum, p) => sum + (p.annualGiving || 0), 0);
    return {
      ...phase,
      count: inPhase.length,
      value,
      label: locale === "fr" ? phase.label : phase.labelEn,
    };
  });

  // For unassigned prospects (no pipeline phase), put them in "Insight"
  const unassigned = prospects.filter((p) => !p.pipelinePhase);
  if (phases[0]) {
    phases[0].count += unassigned.length;
    phases[0].value += unassigned.reduce((sum, p) => sum + (p.annualGiving || 0), 0);
  }

  const maxCount = Math.max(...phases.map((p) => p.count), 1);

  return (
    <GlassPanel delay={0.1} className="h-full">
      <div className="flex items-center gap-2 mb-6">
        <BarChart3 className="w-5 h-5 text-[#00D4FF]" />
        <h3 className="text-lg font-semibold">{t("dashboard.pipelineMonitor")}</h3>
      </div>

      <div className="space-y-4">
        {phases.map((phase) => (
          <div key={phase.key} className="space-y-1.5">
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-2">
                <div
                  className="w-2.5 h-2.5 rounded-full"
                  style={{ backgroundColor: phase.color }}
                />
                <span className="font-medium">{phase.label}</span>
              </div>
              <div className="flex items-center gap-3 text-muted-foreground">
                <span className="font-mono text-xs">{phase.count} prospects</span>
                <span className="font-mono text-xs">{formatCurrency(phase.value, true)}</span>
              </div>
            </div>
            <div className="h-2 rounded-full bg-white/5 overflow-hidden">
              <div
                className="h-full rounded-full transition-all duration-700"
                style={{
                  width: `${(phase.count / maxCount) * 100}%`,
                  backgroundColor: phase.color,
                  boxShadow: `0 0 8px ${phase.color}40`,
                }}
              />
            </div>
          </div>
        ))}
      </div>
    </GlassPanel>
  );
}
