"use client";

import { MapContainer, TileLayer, CircleMarker, Tooltip, Popup } from "react-leaflet";
import type { CountryCluster, Prospect } from "@/types";
import { formatCurrency } from "@/lib/utils";
import "leaflet/dist/leaflet.css";

interface WorldMapProps {
  clusters: CountryCluster[];
  prospects: Prospect[];
}

function getRadius(count: number): number {
  return Math.max(6, Math.min(25, 4 + Math.sqrt(count) * 5));
}

function getColor(count: number): string {
  if (count >= 10) return "#ef4444";
  if (count >= 5) return "#f59e0b";
  if (count >= 2) return "#00D4FF";
  return "#10b981";
}

export default function WorldMap({ clusters, prospects }: WorldMapProps) {
  // Highlight Senegal
  const senegal = { lat: 14.50, lng: -14.45 };

  return (
    <MapContainer
      center={[15, 0]}
      zoom={3}
      minZoom={2}
      maxZoom={10}
      className="w-full h-full"
      style={{ background: "#0D1117" }}
      zoomControl={true}
    >
      <TileLayer
        url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OSM</a> &copy; <a href="https://carto.com/">CARTO</a>'
      />

      {/* Senegal highlight */}
      <CircleMarker
        center={[senegal.lat, senegal.lng]}
        radius={18}
        pathOptions={{
          color: "#00D4FF",
          fillColor: "#00D4FF",
          fillOpacity: 0.08,
          weight: 2,
          dashArray: "4 4",
        }}
      >
        <Tooltip permanent direction="top" offset={[0, -15]} className="!bg-transparent !border-0 !shadow-none">
          <span className="text-[10px] font-bold text-[#00D4FF] bg-black/80 px-2 py-0.5 rounded-full">
            IPD - Dakar
          </span>
        </Tooltip>
      </CircleMarker>

      {/* Country clusters */}
      {clusters.map((cluster) => {
        const color = getColor(cluster.prospectCount);
        const radius = getRadius(cluster.prospectCount);

        return (
          <CircleMarker
            key={cluster.country.code}
            center={[cluster.country.lat, cluster.country.lng]}
            radius={radius}
            pathOptions={{
              color: color,
              fillColor: color,
              fillOpacity: 0.3,
              weight: 1.5,
              opacity: 0.8,
            }}
          >
            <Tooltip direction="top" offset={[0, -radius]}>
              <div className="text-xs space-y-0.5">
                <p className="font-bold">{cluster.country.name}</p>
                <p>{cluster.prospectCount} prospect{cluster.prospectCount > 1 ? "s" : ""}</p>
                <p className="text-muted-foreground">{formatCurrency(cluster.totalGiving, true)} total</p>
              </div>
            </Tooltip>
            <Popup>
              <div className="text-xs space-y-1 max-h-40 overflow-y-auto">
                <p className="font-bold text-sm mb-2">{cluster.country.name}</p>
                {cluster.prospects.slice(0, 10).map((pid) => {
                  const p = prospects.find((pr) => pr.id === pid);
                  return p ? (
                    <div key={pid} className="flex justify-between gap-2">
                      <span className="truncate">{p.organisation}</span>
                      <span className="font-mono text-muted-foreground">{formatCurrency(p.annualGiving, true)}</span>
                    </div>
                  ) : null;
                })}
              </div>
            </Popup>
          </CircleMarker>
        );
      })}
    </MapContainer>
  );
}
