// ============================================================
// SICPS-IPD — Core Type Definitions
// ============================================================

// ---------- Organisation / Prospect ----------

export type OrganisationType =
  | "Research / Academic"
  | "Multilateral / Government"
  | "Major Grant-Making Foundation"
  | "Advisory / Intermediary"
  | "Thematic / Regional Foundation"
  | "Family Foundation / Family Office"
  | "Impact Investor / Social Investment";

export type ConfidenceLevel =
  | "High"
  | "Verified"
  | "Reported"
  | "Medium"
  | "Estimated"
  | "Low";

export type ScoringTier = "hot" | "warm" | "cool" | "cold" | "unscored";

export type FundingTier = "mega" | "major" | "mid" | "emerging" | "unknown";

export interface Delegate {
  id: string;
  name: string;
  title: string;
  addedDate: string | null;
  organisationId: string;
  linkedinUrl?: string;
  interactions?: Interaction[];
}

export interface Interaction {
  id: string;
  type: "email" | "meeting" | "call" | "event" | "note";
  date: string;
  summary: string;
  delegateId: string;
}

export interface Prospect {
  id: string;
  organisation: string;
  organisationSummary: string;
  knownToIPD: boolean | null;
  type: OrganisationType;
  delegatesRaw: string;
  delegates: Delegate[];
  whyAligned: string;
  annualGiving: number | null;
  avgGrantSize: number | null;
  grantCount: number | null;
  dataYear: number | null;
  dataSource: string;
  confidence: ConfidenceLevel;
  countriesServedRaw: string;
  countriesServed: string[];
  affinity: number;
  ability: number;
  access: number;
  totalScore: number;
  // AI-generated suggestions
  aiAffinity?: number;
  aiAbility?: number;
  aiAccess?: number;
  aiRationale?: string;
  // Pipeline
  pipelinePhase?: PipelinePhase;
  pipelineProbability?: number;
  assignedTo?: string;
  // Computed fields
  potentialCapture?: number;
  fundingTier: FundingTier;
  scoringTier: ScoringTier;
  dataFreshness: "fresh" | "aging" | "stale" | "unknown";
  // Prospection tracking
  prospectionNotes?: ProspectionNote[];
  lastContactDate?: string;
  nextActionDate?: string;
  nextActionDescription?: string;
  contactPerson?: string;
  // Metadata
  scoredAt?: string;
  scoredBy?: string;
  createdAt: string;
  updatedAt: string;
}

// ---------- Prospection Notes / Activity Log ----------

export type ProspectionNoteType = "contact" | "meeting" | "email" | "call" | "proposal" | "update" | "note" | "milestone";

export interface ProspectionNote {
  id: string;
  type: ProspectionNoteType;
  date: string;
  author: string;
  summary: string;
  details?: string;
  attachmentName?: string;
  createdAt: string;
}

export const PROSPECTION_NOTE_TYPES: { key: ProspectionNoteType; label: string; labelEn: string; icon: string; color: string }[] = [
  { key: "contact",   label: "Prise de contact",  labelEn: "Initial Contact", icon: "UserPlus",    color: "#3b82f6" },
  { key: "meeting",   label: "Reunion",            labelEn: "Meeting",         icon: "Users",       color: "#8b5cf6" },
  { key: "email",     label: "Email",              labelEn: "Email",           icon: "Mail",        color: "#06b6d4" },
  { key: "call",      label: "Appel",              labelEn: "Call",            icon: "Phone",       color: "#10b981" },
  { key: "proposal",  label: "Proposition envoyee", labelEn: "Proposal Sent",  icon: "FileText",    color: "#f59e0b" },
  { key: "update",    label: "Mise a jour donnees", labelEn: "Data Update",    icon: "RefreshCw",   color: "#ec4899" },
  { key: "note",      label: "Note interne",       labelEn: "Internal Note",   icon: "StickyNote",  color: "#64748b" },
  { key: "milestone", label: "Jalon atteint",      labelEn: "Milestone",       icon: "Flag",        color: "#ef4444" },
];

export const ALL_ORGANISATION_TYPES: OrganisationType[] = [
  "Research / Academic",
  "Multilateral / Government",
  "Major Grant-Making Foundation",
  "Advisory / Intermediary",
  "Thematic / Regional Foundation",
  "Family Foundation / Family Office",
  "Impact Investor / Social Investment",
];

export const ALL_CONFIDENCE_LEVELS: ConfidenceLevel[] = [
  "High", "Verified", "Reported", "Medium", "Estimated", "Low",
];

// ---------- Scoring ----------

export interface ScoringWeights {
  affinity: number; // default 0.35
  ability: number;  // default 0.40
  access: number;   // default 0.25
}

export interface AiScoreResponse {
  affinity: number;
  ability: number;
  access: number;
  rationale: string;
}

export const DEFAULT_WEIGHTS: ScoringWeights = {
  affinity: 0.35,
  ability: 0.40,
  access: 0.25,
};

export const WEIGHT_PRESETS: Record<string, { label: string; labelEn: string; weights: ScoringWeights }> = {
  balanced: { label: "Equilibre", labelEn: "Balanced", weights: { affinity: 0.35, ability: 0.40, access: 0.25 } },
  quickWins: { label: "Quick Wins", labelEn: "Quick Wins", weights: { affinity: 0.20, ability: 0.20, access: 0.60 } },
  bigTickets: { label: "Big Tickets", labelEn: "Big Tickets", weights: { affinity: 0.20, ability: 0.60, access: 0.20 } },
  missionFit: { label: "Mission Fit", labelEn: "Mission Fit", weights: { affinity: 0.60, ability: 0.20, access: 0.20 } },
};

// ---------- Pipeline ----------

export type PipelinePhase =
  | "insight"
  | "engagement"
  | "proposal"
  | "due_diligence"
  | "signature"
  | "lost";

export interface PipelineDeal {
  id: string;
  prospectId: string;
  phase: PipelinePhase;
  probability: number;
  estimatedValue: number;
  assignee: string;
  lostReason?: string;
  notes: string;
  milestones: Milestone[];
  createdAt: string;
  updatedAt: string;
}

export interface Milestone {
  id: string;
  label: string;
  date: string;
  completed: boolean;
}

export const PIPELINE_PHASES: { key: PipelinePhase; label: string; labelEn: string; color: string; order: number }[] = [
  { key: "insight",        label: "Insight",         labelEn: "Insight",        color: "#64748b", order: 1 },
  { key: "engagement",     label: "Engagement",      labelEn: "Engagement",     color: "#3b82f6", order: 2 },
  { key: "proposal",       label: "Proposition",     labelEn: "Proposal",       color: "#8b5cf6", order: 3 },
  { key: "due_diligence",  label: "Due Diligence",   labelEn: "Due Diligence",  color: "#f59e0b", order: 4 },
  { key: "signature",      label: "Signature",       labelEn: "Signature",      color: "#10b981", order: 5 },
  { key: "lost",           label: "Perdu",           labelEn: "Lost",           color: "#ef4444", order: 6 },
];

// ---------- Geography ----------

export interface CountryData {
  code: string;
  name: string;
  nameFr: string;
  lat: number;
  lng: number;
}

export interface CountryCluster {
  country: CountryData;
  prospectCount: number;
  totalGiving: number;
  prospects: string[]; // prospect IDs
  avgTier: ScoringTier;
}

// ---------- Network Graph ----------

export interface GraphNode {
  id: string;
  label: string;
  type: "organisation" | "delegate";
  group?: string;
  size: number;
  color: string;
  x?: number;
  y?: number;
  vx?: number;
  vy?: number;
  fx?: number | null;
  fy?: number | null;
}

export interface GraphEdge {
  source: string;
  target: string;
  weight: number;
}

// ---------- Auth ----------

export interface UserSession {
  user: {
    id: string;
    email: string;
    firstName: string;
    lastName: string;
    role: "admin" | "analyst" | "viewer";
    avatar?: string;
  };
  token: string;
  expiresAt: string;
}

// ---------- Notifications ----------

export interface AppNotification {
  id: string;
  type: "alert" | "info" | "success" | "warning";
  title: string;
  message: string;
  read: boolean;
  createdAt: string;
  module?: string;
  prospectId?: string;
}

// ---------- Module Navigation ----------

export interface NavModule {
  id: string;
  label: string;
  labelEn: string;
  icon: string;
  route: string;
  color: string;
  description: string;
  descriptionEn: string;
}

export const NAV_MODULES: NavModule[] = [
  { id: "dashboard", label: "Command Center", labelEn: "Command Center", icon: "LayoutDashboard", route: "/dashboard", color: "#06b6d4", description: "Vue d'ensemble strategique", descriptionEn: "Strategic overview" },
  { id: "radar",     label: "Radar 3A",       labelEn: "Radar 3A",       icon: "Target",          route: "/radar",     color: "#8b5cf6", description: "Scoring et priorisation", descriptionEn: "Scoring and prioritization" },
  { id: "map",       label: "Geospatial",     labelEn: "Geospatial",     icon: "Globe",           route: "/map",       color: "#10b981", description: "Intelligence geographique", descriptionEn: "Geographic intelligence" },
  { id: "pipeline",  label: "Pulse Pipeline", labelEn: "Pulse Pipeline", icon: "GitBranch",       route: "/pipeline",  color: "#3b82f6", description: "Tunnel de prospection", descriptionEn: "Prospection pipeline" },
  { id: "network",   label: "Delegates Net",  labelEn: "Delegates Net",  icon: "Network",         route: "/network",   color: "#f59e0b", description: "Graphe d'influence", descriptionEn: "Influence network" },
  { id: "capsight",  label: "CapSight",       labelEn: "CapSight",       icon: "DollarSign",      route: "/capsight",  color: "#ec4899", description: "Intelligence financiere", descriptionEn: "Financial intelligence" },
  { id: "advisor",   label: "IA Advisor",     labelEn: "AI Advisor",     icon: "Brain",           route: "/advisor",   color: "#06b6d4", description: "Assistant IA proactif", descriptionEn: "Proactive AI assistant" },
];

// ---------- Organisation Type Colors ----------

export const ORG_TYPE_COLORS: Record<OrganisationType, string> = {
  "Research / Academic": "#3b82f6",
  "Multilateral / Government": "#8b5cf6",
  "Major Grant-Making Foundation": "#10b981",
  "Advisory / Intermediary": "#f59e0b",
  "Thematic / Regional Foundation": "#ec4899",
  "Family Foundation / Family Office": "#06b6d4",
  "Impact Investor / Social Investment": "#ef4444",
};

export const CONFIDENCE_COLORS: Record<ConfidenceLevel, string> = {
  High: "#10b981",
  Verified: "#3b82f6",
  Reported: "#8b5cf6",
  Medium: "#f59e0b",
  Estimated: "#f97316",
  Low: "#ef4444",
};
