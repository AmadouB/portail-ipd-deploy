import type { ScoringWeights, ScoringTier } from "@/types";
import { DEFAULT_WEIGHTS } from "@/types";

/**
 * Calculate composite score (0-100) from 3A scores (each 1-5).
 * Formula: Total = (w1*Affinity + w2*Ability + w3*Access) / (w1+w2+w3) * 20
 * This normalizes to 0-100 scale.
 */
export function calculateCompositeScore(
  affinity: number,
  ability: number,
  access: number,
  weights: ScoringWeights = DEFAULT_WEIGHTS
): number {
  if (affinity === 0 && ability === 0 && access === 0) return 0;

  const totalWeight = weights.affinity + weights.ability + weights.access;
  if (totalWeight === 0) return 0;

  const weighted =
    weights.affinity * affinity +
    weights.ability * ability +
    weights.access * access;

  return Math.round((weighted / totalWeight) * 20);
}

/**
 * Classify a prospect into a scoring tier based on composite score.
 */
export function classifyScoringTier(
  affinity: number,
  ability: number,
  access: number
): ScoringTier {
  if (affinity === 0 && ability === 0 && access === 0) return "unscored";
  const avg = (affinity + ability + access) / 3;
  if (avg >= 3.5) return "hot";
  if (avg >= 2.5) return "warm";
  if (avg >= 1.5) return "cool";
  return "cold";
}

export const TIER_COLORS: Record<ScoringTier, string> = {
  hot: "#ef4444",
  warm: "#f59e0b",
  cool: "#3b82f6",
  cold: "#64748b",
  unscored: "#374151",
};

export const TIER_LABELS: Record<ScoringTier, { fr: string; en: string }> = {
  hot: { fr: "Chaud", en: "Hot" },
  warm: { fr: "Tiede", en: "Warm" },
  cool: { fr: "Froid", en: "Cool" },
  cold: { fr: "Tres froid", en: "Cold" },
  unscored: { fr: "Non score", en: "Unscored" },
};
