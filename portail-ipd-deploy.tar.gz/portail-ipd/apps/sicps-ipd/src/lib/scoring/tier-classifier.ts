import type { FundingTier, ConfidenceLevel } from "@/types";

/**
 * Classify into funding tier based on Annual Giving.
 */
export function classifyFundingTier(annualGiving: number | null): FundingTier {
  if (annualGiving == null) return "unknown";
  if (annualGiving >= 1_000_000_000) return "mega";
  if (annualGiving >= 50_000_000) return "major";
  if (annualGiving >= 1_000_000) return "mid";
  return "emerging";
}

/**
 * Calculate data freshness based on Data Year vs current year.
 */
export function calculateDataFreshness(
  dataYear: number | null
): "fresh" | "aging" | "stale" | "unknown" {
  if (dataYear == null) return "unknown";
  const currentYear = new Date().getFullYear();
  const age = currentYear - dataYear;
  if (age <= 1) return "fresh";
  if (age <= 2) return "aging";
  return "stale";
}

/**
 * Confidence factor for Potential Capture estimation.
 */
export function getConfidenceFactor(confidence: ConfidenceLevel): number {
  const factors: Record<ConfidenceLevel, number> = {
    High: 0.8,
    Verified: 0.8,
    Reported: 0.5,
    Medium: 0.5,
    Estimated: 0.2,
    Low: 0.2,
  };
  return factors[confidence] ?? 0.3;
}

/**
 * Calculate Potential Capture amount.
 * Formula: Avg Grant Size * Confidence Factor * Access Factor
 */
export function calculatePotentialCapture(
  avgGrantSize: number | null,
  confidence: ConfidenceLevel,
  access: number
): number | undefined {
  if (avgGrantSize == null || avgGrantSize === 0) return undefined;
  const confidenceFactor = getConfidenceFactor(confidence);
  const accessFactor = access > 0 ? access / 5 : 0.1;
  return Math.round(avgGrantSize * confidenceFactor * accessFactor);
}

export const FUNDING_TIER_COLORS: Record<FundingTier, string> = {
  mega: "#ef4444",
  major: "#f59e0b",
  mid: "#3b82f6",
  emerging: "#10b981",
  unknown: "#64748b",
};

export const FUNDING_TIER_LABELS: Record<FundingTier, { fr: string; en: string; range: string }> = {
  mega: { fr: "Mega-donateur", en: "Mega-donor", range: "> $1B" },
  major: { fr: "Majeur", en: "Major", range: "$50M - $1B" },
  mid: { fr: "Intermediaire", en: "Mid-range", range: "$1M - $50M" },
  emerging: { fr: "Emergent", en: "Emerging", range: "< $1M" },
  unknown: { fr: "Inconnu", en: "Unknown", range: "N/A" },
};
