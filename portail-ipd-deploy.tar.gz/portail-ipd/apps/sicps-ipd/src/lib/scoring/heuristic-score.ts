/**
 * Client-side heuristic scoring (fallback when API not available).
 * Used in static export deployments where /api/ai/score is unavailable.
 */
import type { Prospect } from "@/types";

export interface HeuristicScore {
  affinity: number;
  ability: number;
  access: number;
  rationale: string;
}

export function generateHeuristicScore(p: Pick<Prospect, "whyAligned" | "annualGiving" | "knownToIPD" | "countriesServed" | "delegates" | "type">): HeuristicScore {
  // Affinity: based on alignment text quality + type
  let affinity = 2;
  const aligned = (p.whyAligned || "").toLowerCase();
  if (aligned.includes("pandemic") || aligned.includes("vaccine") || aligned.includes("diagnostic")) affinity = 5;
  else if (aligned.includes("health") || aligned.includes("santé") || aligned.includes("medic")) affinity = 4;
  else if (aligned.length > 30) affinity = 3;
  else if (aligned.length > 10) affinity = 2;

  // Boost for relevant types
  if (p.type === "Major Grant-Making Foundation" || p.type === "Multilateral / Government") affinity = Math.min(5, affinity + 1);

  // Ability: based on Annual Giving
  let ability = 1;
  const giving = p.annualGiving || 0;
  if (giving >= 1_000_000_000) ability = 5;
  else if (giving >= 100_000_000) ability = 4;
  else if (giving >= 10_000_000) ability = 3;
  else if (giving >= 1_000_000) ability = 2;

  // Access: based on Known to IPD + delegates + Senegal presence
  let access = 1;
  if (p.knownToIPD === true) access = 4;
  else if ((p.delegates?.length || 0) >= 3) access = 3;
  else if ((p.delegates?.length || 0) >= 1) access = 2;

  if (p.countriesServed?.some((c) => c.toLowerCase().includes("senegal"))) {
    access = Math.min(5, access + 1);
  }

  return {
    affinity,
    ability,
    access,
    rationale: "Score heuristique calculé à partir de l'alignement, des données financières et du réseau relationnel disponible.",
  };
}
