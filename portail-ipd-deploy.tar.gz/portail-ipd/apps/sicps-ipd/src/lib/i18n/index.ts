"use client";

import { useLocaleStore } from "@/stores/locale-store";
import fr from "./fr.json";
import en from "./en.json";

const translations: Record<string, Record<string, unknown>> = { fr, en };

function getNestedValue(obj: unknown, path: string): string {
  const keys = path.split(".");
  let current: unknown = obj;
  for (const key of keys) {
    if (current == null || typeof current !== "object") return path;
    current = (current as Record<string, unknown>)[key];
  }
  return typeof current === "string" ? current : path;
}

export function useTranslation() {
  const locale = useLocaleStore((s) => s.locale);

  const t = (key: string): string => {
    return getNestedValue(translations[locale], key);
  };

  return { t, locale };
}
