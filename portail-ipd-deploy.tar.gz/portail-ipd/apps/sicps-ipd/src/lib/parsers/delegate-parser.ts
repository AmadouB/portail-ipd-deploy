import type { Delegate } from "@/types";
import { generateId } from "@/lib/utils";

/**
 * Parse the "Delegates at Skoll" field.
 * Formats encountered in real data:
 *   - "Francis Collins"
 *   - "Susan Brown\nLauren Bradford (Philanthropy Advisor) [Added 2026-03-23]"
 *   - "Erin Gregor, Mark Wensley\nAndrew Dunckleman (Deputy Director, Philanthropic Partnerships) [Added 2026-03-23]"
 */
export function parseDelegates(raw: string | null | undefined, organisationId: string): Delegate[] {
  if (!raw || raw.trim() === "") return [];

  const delegates: Delegate[] = [];
  // Split by newline first, then by comma for simple name lists
  const lines = raw.split(/\n/).map(l => l.trim()).filter(Boolean);

  for (const line of lines) {
    // Try to match: Name (Title) [Added Date]
    const fullMatch = line.match(/^(.+?)\s*\((.+?)\)\s*\[(?:Added\s*)?(\d{4}-\d{2}-\d{2})\]$/);
    if (fullMatch) {
      delegates.push({
        id: generateId(),
        name: fullMatch[1].trim(),
        title: fullMatch[2].trim(),
        addedDate: fullMatch[3],
        organisationId,
      });
      continue;
    }

    // Try to match: Name (Title) — without date
    const titleMatch = line.match(/^(.+?)\s*\((.+?)\)$/);
    if (titleMatch) {
      delegates.push({
        id: generateId(),
        name: titleMatch[1].trim(),
        title: titleMatch[2].trim(),
        addedDate: null,
        organisationId,
      });
      continue;
    }

    // Simple comma-separated names: "Erin Gregor, Mark Wensley"
    const names = line.split(",").map(n => n.trim()).filter(Boolean);
    for (const name of names) {
      if (name.length > 1) {
        delegates.push({
          id: generateId(),
          name,
          title: "",
          addedDate: null,
          organisationId,
        });
      }
    }
  }

  return delegates;
}
