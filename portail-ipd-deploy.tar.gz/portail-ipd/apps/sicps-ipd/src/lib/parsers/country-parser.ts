/**
 * Parse the "Countries Served" field into normalized country names.
 * Handles comma-separated lists like:
 *   "Brazil, Chile, Colombia, Senegal, South Africa"
 *   "United States of America (USA)"
 *   "I prefer not to say"  -> skip
 */

const COUNTRY_ALIASES: Record<string, string> = {
  "usa": "United States",
  "us": "United States",
  "united states of america": "United States",
  "united states of america (usa)": "United States",
  "uk": "United Kingdom",
  "great britain": "United Kingdom",
  "england": "United Kingdom",
  "democratic republic of the congo": "DR Congo",
  "drc": "DR Congo",
  "cote d'ivoire": "Ivory Coast",
  "ivory coast": "Ivory Coast",
  "republic of korea": "South Korea",
  "south korea": "South Korea",
  "korea": "South Korea",
  "uae": "United Arab Emirates",
  "tanzania": "Tanzania",
  "united republic of tanzania": "Tanzania",
};

const SKIP_TERMS = [
  "i prefer not to say",
  "n/a",
  "not specified",
  "global",
  "worldwide",
  "all",
  "various",
];

export function parseCountries(raw: string | null | undefined): string[] {
  if (!raw || raw.trim() === "") return [];

  const lower = raw.toLowerCase().trim();
  if (SKIP_TERMS.some(t => lower.includes(t))) return [];

  return raw
    .split(",")
    .map(c => c.trim())
    .filter(Boolean)
    .map(normalizeCountryName)
    .filter(Boolean) as string[];
}

function normalizeCountryName(name: string): string | null {
  const lower = name.toLowerCase().trim();
  if (SKIP_TERMS.includes(lower)) return null;
  if (COUNTRY_ALIASES[lower]) return COUNTRY_ALIASES[lower];
  // Capitalize each word
  return name
    .trim()
    .split(" ")
    .map(w => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase())
    .join(" ");
}
