"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { AppSidebar } from "@/components/layout/app-sidebar";
import { AppHeader } from "@/components/layout/app-header";
import { useThemeStore } from "@/stores/theme-store";
import { useLocaleStore } from "@/stores/locale-store";
import { useProspectStore } from "@/stores/prospect-store";
import { useAuthStore } from "@/stores/auth-store";

export default function AppLayout({ children }: { children: React.ReactNode }) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const router = useRouter();

  const loadTheme = useThemeStore((s) => s.loadTheme);
  const loadLocale = useLocaleStore((s) => s.loadLocale);
  const loadProspects = useProspectStore((s) => s.loadProspects);
  const session = useAuthStore((s) => s.session);
  const isLoading = useAuthStore((s) => s.isLoading);
  const loadSession = useAuthStore((s) => s.loadSession);

  useEffect(() => {
    loadTheme();
    loadLocale();
    loadSession();
    loadProspects();
  }, [loadTheme, loadLocale, loadSession, loadProspects]);

  useEffect(() => {
    if (!isLoading && !session) {
      router.push("/login");
    }
  }, [isLoading, session, router]);

  // Show nothing while checking auth
  if (isLoading || !session) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: "var(--body-gradient)" }}>
        <div className="w-12 h-12 rounded-full border-2 border-[#00D4FF]/30 border-t-[#00D4FF] animate-spin" />
      </div>
    );
  }

  return (
    <div className="flex min-h-screen">
      <AppSidebar
        mobileOpen={mobileOpen}
        onMobileClose={() => setMobileOpen(false)}
      />
      <div className="flex-1 flex flex-col min-w-0">
        <AppHeader onMenuClick={() => setMobileOpen(true)} />
        <main className="flex-1 p-4 lg:p-6 overflow-auto">
          {children}
        </main>
      </div>
    </div>
  );
}
