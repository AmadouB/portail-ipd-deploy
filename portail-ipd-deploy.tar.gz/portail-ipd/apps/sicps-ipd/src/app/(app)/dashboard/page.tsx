"use client";

import { useProspectStore } from "@/stores/prospect-store";
import { useTranslation } from "@/lib/i18n";
import { KpiRow } from "@/components/dashboard/kpi-row";
import { TopProspects } from "@/components/dashboard/top-prospects";
import { PipelineMonitor } from "@/components/dashboard/pipeline-monitor";
import { ConversionFunnel } from "@/components/dashboard/conversion-funnel";
import { AlertFeed } from "@/components/dashboard/alert-feed";
import { TypeDistributionChart } from "@/components/dashboard/type-distribution-chart";
import { GrantsAnalysisChart } from "@/components/dashboard/grants-analysis-chart";
import { GlassPanel } from "@/components/shared/glass-panel";
import { useThemeStore } from "@/stores/theme-store";
import Image from "next/image";
import { Crosshair } from "lucide-react";

export default function DashboardPage() {
  const { t } = useTranslation();
  const prospects = useProspectStore((s) => s.prospects);
  const isLoading = useProspectStore((s) => s.isLoading);
  const theme = useThemeStore((s) => s.theme);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-[60vh]">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 rounded-full border-2 border-[#00D4FF]/30 border-t-[#00D4FF] animate-spin" />
          <p className="text-sm text-muted-foreground">{t("common.loading")}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 bg-grid min-h-full">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Image
          src={theme === "dark" ? "/images/logo-ipd-dark.png" : "/images/logo-ipd-light.png"}
          alt="Institut Pasteur de Dakar"
          width={48}
          height={48}
          className="object-contain"
        />
        <div>
          <h1 className="text-2xl font-bold text-foreground font-[family-name:var(--font-display)]">
            {t("dashboard.title")}
          </h1>
          <p className="text-sm text-muted-foreground">
            Institut Pasteur de Dakar — SICPS NextGen v2.0
          </p>
        </div>
      </div>

      {/* KPI Row */}
      <KpiRow prospects={prospects} />

      {/* Visual Analytics Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <TypeDistributionChart prospects={prospects} />
        <GrantsAnalysisChart prospects={prospects} />
      </div>

      {/* Pipeline Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <PipelineMonitor prospects={prospects} />
        </div>
        <div>
          <ConversionFunnel prospects={prospects} />
        </div>
      </div>

      {/* Bottom Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <TopProspects prospects={prospects} />
        </div>
        <div>
          <AlertFeed prospects={prospects} />
        </div>
      </div>
    </div>
  );
}
