"use client";

import { useState } from "react";
import { useProspectStore } from "@/stores/prospect-store";
import { useTranslation } from "@/lib/i18n";
import { GlassPanel } from "@/components/shared/glass-panel";
import { ProspectList } from "@/components/saisie/prospect-list";
import { ProspectForm } from "@/components/saisie/prospect-form";
import { ProspectDetailDrawer } from "@/components/saisie/prospect-detail-drawer";
import { ReportGenerator } from "@/components/saisie/report-generator";
import type { Prospect } from "@/types";
import { ClipboardEdit, Plus, X, FileText } from "lucide-react";

type View = "list" | "create";

export default function SaisiePage() {
  const { t, locale } = useTranslation();
  const prospects = useProspectStore((s) => s.prospects);
  const isLoading = useProspectStore((s) => s.isLoading);
  const [view, setView] = useState<View>("list");
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [reportOpen, setReportOpen] = useState(false);

  const selectedProspect = selectedId ? prospects.find((p) => p.id === selectedId) : null;

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-[60vh]">
        <div className="w-12 h-12 rounded-full border-2 border-[#10b981]/30 border-t-[#10b981] animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6 bg-grid min-h-full">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-[#10b981]/10">
            <ClipboardEdit className="w-5 h-5 text-[#10b981]" />
          </div>
          <div>
            <h1 className="text-2xl font-bold font-[family-name:var(--font-display)]">
              {locale === "fr" ? "Saisie & Suivi Prospection" : "Data Entry & Prospection Tracking"}
            </h1>
            <p className="text-sm text-muted-foreground">
              {prospects.length} {locale === "fr" ? "partenaires potentiels" : "potential partners"}
            </p>
          </div>
        </div>

        {/* Action buttons */}
        <div className="flex gap-2">
          {/* Report button */}
          <button
            onClick={() => setReportOpen(true)}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium text-[#00D4FF] bg-[#00D4FF]/10 border border-[#00D4FF]/20 hover:bg-[#00D4FF]/20 transition-all"
          >
            <FileText className="w-4 h-4" />
            <span className="hidden sm:inline">{locale === "fr" ? "Generer Rapport" : "Generate Report"}</span>
          </button>

          {view === "create" ? (
            <button
              onClick={() => setView("list")}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium text-muted-foreground hover:text-white bg-white/5 hover:bg-white/8 transition-all"
            >
              <X className="w-4 h-4" />
              {locale === "fr" ? "Annuler" : "Cancel"}
            </button>
          ) : (
            <button
              onClick={() => setView("create")}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium text-white bg-[#10b981] hover:bg-[#059669] transition-all"
            >
              <Plus className="w-4 h-4" />
              {locale === "fr" ? "Nouveau Prospect" : "New Prospect"}
            </button>
          )}
        </div>
      </div>

      {/* Content */}
      {view === "create" ? (
        <ProspectForm
          onSaved={() => setView("list")}
          onCancel={() => setView("list")}
        />
      ) : (
        <ProspectList
          prospects={prospects}
          onSelect={(id) => setSelectedId(id)}
        />
      )}

      {/* Detail Drawer */}
      {selectedProspect && (
        <ProspectDetailDrawer
          prospect={selectedProspect}
          onClose={() => setSelectedId(null)}
        />
      )}

      {/* Report Generator Modal */}
      <ReportGenerator
        prospects={prospects}
        open={reportOpen}
        onClose={() => setReportOpen(false)}
      />
    </div>
  );
}
