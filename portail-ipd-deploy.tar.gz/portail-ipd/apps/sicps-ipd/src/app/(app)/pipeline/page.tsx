"use client";

import { useState, useMemo } from "react";
import { useProspectStore } from "@/stores/prospect-store";
import { useTranslation } from "@/lib/i18n";
import { GlassPanel } from "@/components/shared/glass-panel";
import { StatusBadge } from "@/components/shared/status-badge";
import { formatCurrency } from "@/lib/utils";
import { PIPELINE_PHASES, type PipelinePhase } from "@/types";
import { GitBranch, Plus, GripVertical } from "lucide-react";

export default function PipelinePage() {
  const { t, locale } = useTranslation();
  const prospects = useProspectStore((s) => s.prospects);
  const updateProspect = useProspectStore((s) => s.updateProspect);
  const isLoading = useProspectStore((s) => s.isLoading);
  const [draggedId, setDraggedId] = useState<string | null>(null);

  const activePhases = PIPELINE_PHASES.filter((p) => p.key !== "lost");

  const columns = useMemo(() => {
    return activePhases.map((phase) => {
      const items = prospects.filter((p) => {
        if (phase.key === "insight") return !p.pipelinePhase || p.pipelinePhase === "insight";
        return p.pipelinePhase === phase.key;
      });
      const value = items.reduce((sum, p) => sum + (p.annualGiving || 0), 0);
      return { ...phase, items, value, label: locale === "fr" ? phase.label : phase.labelEn };
    });
  }, [prospects, locale, activePhases]);

  const handleDragStart = (e: React.DragEvent, prospectId: string) => {
    setDraggedId(prospectId);
    e.dataTransfer.effectAllowed = "move";
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = "move";
  };

  const handleDrop = (e: React.DragEvent, phase: PipelinePhase) => {
    e.preventDefault();
    if (draggedId) {
      updateProspect(draggedId, { pipelinePhase: phase });
      setDraggedId(null);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-[60vh]">
        <div className="w-12 h-12 rounded-full border-2 border-[#3b82f6]/30 border-t-[#3b82f6] animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6 bg-grid min-h-full">
      {/* Header */}
      <div className="flex items-center gap-3">
        <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-[#3b82f6]/10">
          <GitBranch className="w-5 h-5 text-[#3b82f6]" />
        </div>
        <div>
          <h1 className="text-2xl font-bold font-[family-name:var(--font-display)]">{t("pipeline.title")}</h1>
          <p className="text-sm text-muted-foreground">
            {prospects.length} prospects — {locale === "fr" ? "Glisser-deposer pour changer de phase" : "Drag and drop to change phase"}
          </p>
        </div>
      </div>

      {/* Kanban Board */}
      <div className="flex gap-4 overflow-x-auto pb-4" style={{ minHeight: "calc(100vh - 240px)" }}>
        {columns.map((col) => (
          <div
            key={col.key}
            className="flex-shrink-0 w-[280px] flex flex-col"
            onDragOver={handleDragOver}
            onDrop={(e) => handleDrop(e, col.key)}
          >
            {/* Column Header */}
            <div
              className="flex items-center justify-between px-3 py-2.5 rounded-t-xl border border-b-0 border-white/5"
              style={{ backgroundColor: `${col.color}10` }}
            >
              <div className="flex items-center gap-2">
                <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: col.color }} />
                <span className="text-sm font-semibold">{col.label}</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono px-1.5 py-0.5 rounded-full bg-white/5">
                  {col.items.length}
                </span>
              </div>
            </div>

            {/* Column Value */}
            <div className="px-3 py-1.5 text-xs text-muted-foreground border-x border-white/5 bg-white/2">
              {formatCurrency(col.value, true)}
            </div>

            {/* Cards */}
            <div className="flex-1 space-y-2 p-2 rounded-b-xl border border-t-0 border-white/5 bg-white/2 overflow-y-auto">
              {col.items.map((prospect) => (
                <div
                  key={prospect.id}
                  draggable
                  onDragStart={(e) => handleDragStart(e, prospect.id)}
                  className="glass rounded-xl p-3 cursor-grab active:cursor-grabbing hover:bg-white/5 transition-all group"
                >
                  <div className="flex items-start gap-2">
                    <GripVertical className="w-3.5 h-3.5 text-muted-foreground/30 group-hover:text-muted-foreground mt-0.5 shrink-0" />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{prospect.organisation}</p>
                      <p className="text-[11px] text-muted-foreground truncate mt-0.5">{prospect.type}</p>
                      <div className="flex items-center justify-between mt-2">
                        <span className="text-xs font-mono">{formatCurrency(prospect.annualGiving, true)}</span>
                        <StatusBadge variant="scoring" value={prospect.scoringTier} locale={locale} />
                      </div>
                      {prospect.knownToIPD && (
                        <span className="inline-block mt-1.5 text-[10px] px-1.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400">
                          Known to IPD
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
