"use client";

import { useMemo } from "react";
import dynamic from "next/dynamic";
import { useProspectStore } from "@/stores/prospect-store";
import { useTranslation } from "@/lib/i18n";
import { GlassPanel } from "@/components/shared/glass-panel";
import { StatusBadge } from "@/components/shared/status-badge";
import { formatCurrency } from "@/lib/utils";
import { Globe, MapPin } from "lucide-react";
import type { CountryCluster } from "@/types";
import { COUNTRY_COORDS } from "@/lib/data/countries";

// Dynamic import for Leaflet (SSR incompatible)
const WorldMap = dynamic(() => import("@/components/map/world-map"), { ssr: false });

export default function MapPage() {
  const { t, locale } = useTranslation();
  const prospects = useProspectStore((s) => s.prospects);
  const isLoading = useProspectStore((s) => s.isLoading);

  const clusters = useMemo<CountryCluster[]>(() => {
    const countryMap = new Map<string, CountryCluster>();

    prospects.forEach((p) => {
      p.countriesServed.forEach((country) => {
        const coords = COUNTRY_COORDS[country];
        if (!coords) return;

        if (!countryMap.has(country)) {
          countryMap.set(country, {
            country: { code: coords.code, name: country, nameFr: country, lat: coords.lat, lng: coords.lng },
            prospectCount: 0,
            totalGiving: 0,
            prospects: [],
            avgTier: "unscored",
          });
        }

        const cluster = countryMap.get(country)!;
        cluster.prospectCount++;
        cluster.totalGiving += p.annualGiving || 0;
        cluster.prospects.push(p.id);
      });
    });

    return Array.from(countryMap.values());
  }, [prospects]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-[60vh]">
        <div className="w-12 h-12 rounded-full border-2 border-[#10b981]/30 border-t-[#10b981] animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-4 bg-grid min-h-full">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-[#10b981]/10">
            <Globe className="w-5 h-5 text-[#10b981]" />
          </div>
          <div>
            <h1 className="text-2xl font-bold font-[family-name:var(--font-display)]">{t("map.title")}</h1>
            <p className="text-sm text-muted-foreground">
              {clusters.length} {locale === "fr" ? "pays couverts" : "countries covered"} — {prospects.length} prospects
            </p>
          </div>
        </div>
      </div>

      {/* Map Container */}
      <div className="relative rounded-2xl overflow-hidden border border-white/5" style={{ height: "calc(100vh - 220px)" }}>
        <WorldMap clusters={clusters} prospects={prospects} />

        {/* Stats overlay */}
        <div className="absolute top-4 left-4 z-[1000]">
          <GlassPanel animate={false} className="!p-3 space-y-2">
            <div className="flex items-center gap-2 text-xs">
              <MapPin className="w-3.5 h-3.5 text-[#10b981]" />
              <span className="font-medium">{clusters.length} {locale === "fr" ? "pays" : "countries"}</span>
            </div>
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <span>{prospects.length} organisations</span>
            </div>
          </GlassPanel>
        </div>
      </div>
    </div>
  );
}
