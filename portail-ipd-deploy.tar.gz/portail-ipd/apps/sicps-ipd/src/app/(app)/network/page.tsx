"use client";

import { useMemo, useState } from "react";
import { useProspectStore } from "@/stores/prospect-store";
import { useTranslation } from "@/lib/i18n";
import { GlassPanel } from "@/components/shared/glass-panel";
import { ORG_TYPE_COLORS, type Delegate } from "@/types";
import { Network as NetworkIcon, Users, Link2, Search } from "lucide-react";

export default function NetworkPage() {
  const { t, locale } = useTranslation();
  const prospects = useProspectStore((s) => s.prospects);
  const [selectedDelegate, setSelectedDelegate] = useState<Delegate | null>(null);
  const [search, setSearch] = useState("");

  // Build delegate list with org connections
  const delegateMap = useMemo(() => {
    const map = new Map<string, { delegate: Delegate; organisations: string[] }>();

    prospects.forEach((p) => {
      p.delegates.forEach((d) => {
        const key = d.name.toLowerCase().trim();
        if (!map.has(key)) {
          map.set(key, { delegate: d, organisations: [p.organisation] });
        } else {
          const entry = map.get(key)!;
          if (!entry.organisations.includes(p.organisation)) {
            entry.organisations.push(p.organisation);
          }
        }
      });
    });

    return Array.from(map.values())
      .filter((entry) =>
        entry.delegate.name.toLowerCase().includes(search.toLowerCase()) ||
        entry.organisations.some((o) => o.toLowerCase().includes(search.toLowerCase()))
      )
      .sort((a, b) => b.organisations.length - a.organisations.length);
  }, [prospects, search]);

  const bridges = delegateMap.filter((d) => d.organisations.length >= 2);
  const totalDelegates = delegateMap.length;

  return (
    <div className="space-y-6 bg-grid min-h-full">
      {/* Header */}
      <div className="flex items-center gap-3">
        <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-[#f59e0b]/10">
          <NetworkIcon className="w-5 h-5 text-[#f59e0b]" />
        </div>
        <div>
          <h1 className="text-2xl font-bold font-[family-name:var(--font-display)]">{t("network.title")}</h1>
          <p className="text-sm text-muted-foreground">
            {totalDelegates} {locale === "fr" ? "delegues" : "delegates"} — {bridges.length} {t("network.bridges").toLowerCase()}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Delegate List */}
        <div className="lg:col-span-2">
          <GlassPanel animate={false}>
            {/* Search */}
            <div className="relative mb-4">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder={locale === "fr" ? "Rechercher delegues ou organisations..." : "Search delegates or organisations..."}
                className="w-full h-9 pl-9 pr-4 rounded-lg text-sm bg-white/5 border border-white/8 focus:outline-none focus:ring-1 focus:ring-[#f59e0b]/50"
              />
            </div>

            {/* Bridges Section */}
            {bridges.length > 0 && (
              <div className="mb-6">
                <h3 className="text-sm font-semibold text-[#f59e0b] mb-3 flex items-center gap-2">
                  <Link2 className="w-4 h-4" />
                  {t("network.bridges")} ({bridges.length})
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                  {bridges.map((entry) => (
                    <button
                      key={entry.delegate.id}
                      onClick={() => setSelectedDelegate(entry.delegate)}
                      className="text-left p-3 rounded-xl bg-[#f59e0b]/5 border border-[#f59e0b]/20 hover:bg-[#f59e0b]/10 transition-all"
                    >
                      <p className="text-sm font-medium">{entry.delegate.name}</p>
                      {entry.delegate.title && (
                        <p className="text-[11px] text-muted-foreground">{entry.delegate.title}</p>
                      )}
                      <div className="flex flex-wrap gap-1 mt-2">
                        {entry.organisations.map((org) => (
                          <span key={org} className="text-[10px] px-1.5 py-0.5 rounded-full bg-white/5 text-muted-foreground">
                            {org.length > 25 ? org.slice(0, 25) + "..." : org}
                          </span>
                        ))}
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* All Delegates */}
            <h3 className="text-sm font-semibold text-muted-foreground mb-3 flex items-center gap-2">
              <Users className="w-4 h-4" />
              {locale === "fr" ? "Tous les delegues" : "All Delegates"} ({delegateMap.length})
            </h3>
            <div className="space-y-1 max-h-[500px] overflow-y-auto">
              {delegateMap.map((entry) => (
                <button
                  key={entry.delegate.id}
                  onClick={() => setSelectedDelegate(entry.delegate)}
                  className="w-full text-left flex items-center justify-between px-3 py-2 rounded-lg hover:bg-white/5 transition-all"
                >
                  <div>
                    <p className="text-sm">{entry.delegate.name}</p>
                    <p className="text-[11px] text-muted-foreground">
                      {entry.delegate.title || entry.organisations[0]}
                    </p>
                  </div>
                  <span className="text-xs font-mono text-muted-foreground">
                    {entry.organisations.length} org{entry.organisations.length > 1 ? "s" : ""}
                  </span>
                </button>
              ))}
            </div>
          </GlassPanel>
        </div>

        {/* Detail Panel */}
        <div>
          {selectedDelegate ? (
            <GlassPanel animate={false} glow="amber">
              <h3 className="text-lg font-bold mb-1">{selectedDelegate.name}</h3>
              {selectedDelegate.title && (
                <p className="text-sm text-muted-foreground mb-4">{selectedDelegate.title}</p>
              )}
              {selectedDelegate.addedDate && (
                <p className="text-xs text-muted-foreground mb-4">
                  {locale === "fr" ? "Ajoute le" : "Added"}: {selectedDelegate.addedDate}
                </p>
              )}

              <h4 className="text-xs font-semibold text-muted-foreground uppercase mb-2">
                {locale === "fr" ? "Organisations liees" : "Linked Organisations"}
              </h4>
              <div className="space-y-2">
                {prospects
                  .filter((p) => p.delegates.some((d) => d.name.toLowerCase() === selectedDelegate.name.toLowerCase()))
                  .map((p) => (
                    <div key={p.id} className="p-2 rounded-lg bg-white/3 border border-white/5">
                      <p className="text-sm font-medium">{p.organisation}</p>
                      <p className="text-[11px] text-muted-foreground">{p.type}</p>
                    </div>
                  ))}
              </div>
            </GlassPanel>
          ) : (
            <GlassPanel animate={false} className="flex items-center justify-center h-64">
              <div className="text-center">
                <NetworkIcon className="w-12 h-12 mx-auto text-[#f59e0b]/30 mb-3" />
                <p className="text-sm text-muted-foreground">
                  {locale === "fr" ? "Selectionnez un delegue" : "Select a delegate"}
                </p>
              </div>
            </GlassPanel>
          )}
        </div>
      </div>
    </div>
  );
}
