"use client";

import { useState, useMemo } from "react";
import { useProspectStore } from "@/stores/prospect-store";
import { useTranslation } from "@/lib/i18n";
import { GlassPanel } from "@/components/shared/glass-panel";
import { Brain, Sparkles, FileText, AlertTriangle, Send } from "lucide-react";

export default function AdvisorPage() {
  const { t, locale } = useTranslation();
  const prospects = useProspectStore((s) => s.prospects);
  const [chatInput, setChatInput] = useState("");
  const [messages, setMessages] = useState<{ role: "user" | "assistant"; content: string }[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  // Generate proactive suggestions
  const suggestions = useMemo(() => {
    const items: { icon: React.ReactNode; title: string; description: string; color: string }[] = [];

    // Unscored prospects
    const unscored = prospects.filter((p) => p.scoringTier === "unscored").length;
    if (unscored > 0) {
      items.push({
        icon: <Sparkles className="w-4 h-4" />,
        title: locale === "fr" ? `${unscored} prospects a scorer` : `${unscored} prospects to score`,
        description: locale === "fr"
          ? "Utilisez le module Radar 3A pour scorer ces prospects avec l'assistance IA."
          : "Use the Radar 3A module to score these prospects with AI assistance.",
        color: "#8b5cf6",
      });
    }

    // Known to IPD but idle
    const knownIdle = prospects.filter((p) => p.knownToIPD && (!p.pipelinePhase || p.pipelinePhase === "insight"));
    if (knownIdle.length > 0) {
      items.push({
        icon: <AlertTriangle className="w-4 h-4" />,
        title: locale === "fr"
          ? `${knownIdle.length} contacts IPD non engages`
          : `${knownIdle.length} IPD contacts not engaged`,
        description: knownIdle.slice(0, 3).map((p) => p.organisation).join(", ") + (knownIdle.length > 3 ? "..." : ""),
        color: "#f59e0b",
      });
    }

    // High-value unscored
    const highValueUnscored = prospects
      .filter((p) => p.scoringTier === "unscored" && (p.annualGiving || 0) > 100_000_000)
      .sort((a, b) => (b.annualGiving || 0) - (a.annualGiving || 0));
    if (highValueUnscored.length > 0) {
      items.push({
        icon: <FileText className="w-4 h-4" />,
        title: locale === "fr" ? "Prospects prioritaires a scorer" : "Priority prospects to score",
        description: highValueUnscored.slice(0, 3).map((p) => p.organisation).join(", "),
        color: "#ef4444",
      });
    }

    // Stale data
    const stale = prospects.filter((p) => p.dataFreshness === "stale");
    if (stale.length > 0) {
      items.push({
        icon: <AlertTriangle className="w-4 h-4" />,
        title: locale === "fr" ? `${stale.length} donnees obsoletes` : `${stale.length} stale data records`,
        description: locale === "fr"
          ? "Ces prospects ont des donnees de plus de 2 ans. Envisagez une mise a jour."
          : "These prospects have data older than 2 years. Consider updating.",
        color: "#64748b",
      });
    }

    return items;
  }, [prospects, locale]);

  const handleSend = async () => {
    if (!chatInput.trim()) return;
    const userMessage = chatInput.trim();
    setChatInput("");
    setMessages((prev) => [...prev, { role: "user", content: userMessage }]);
    setIsLoading(true);

    // Simple local response (no API call needed for basic queries)
    setTimeout(() => {
      const response = generateLocalResponse(userMessage, prospects, locale);
      setMessages((prev) => [...prev, { role: "assistant", content: response }]);
      setIsLoading(false);
    }, 500);
  };

  return (
    <div className="space-y-6 bg-grid min-h-full">
      {/* Header */}
      <div className="flex items-center gap-3">
        <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-[#00D4FF]/10">
          <Brain className="w-5 h-5 text-[#00D4FF]" />
        </div>
        <div>
          <h1 className="text-2xl font-bold font-[family-name:var(--font-display)]">{t("advisor.title")}</h1>
          <p className="text-sm text-muted-foreground">
            {locale === "fr" ? "Recommandations proactives et assistance intelligente" : "Proactive recommendations and intelligent assistance"}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Suggestions */}
        <div className="lg:col-span-1">
          <GlassPanel animate={false}>
            <h3 className="text-sm font-semibold text-muted-foreground uppercase mb-4">
              {t("advisor.suggestions")}
            </h3>
            <div className="space-y-3">
              {suggestions.map((s, i) => (
                <div
                  key={i}
                  className="p-3 rounded-xl bg-white/3 border border-white/5 hover:bg-white/5 transition-all cursor-pointer"
                >
                  <div className="flex items-start gap-3">
                    <div
                      className="flex items-center justify-center w-8 h-8 rounded-lg shrink-0"
                      style={{ backgroundColor: `${s.color}15`, color: s.color }}
                    >
                      {s.icon}
                    </div>
                    <div>
                      <p className="text-sm font-medium">{s.title}</p>
                      <p className="text-[11px] text-muted-foreground mt-0.5">{s.description}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </GlassPanel>
        </div>

        {/* Chat */}
        <div className="lg:col-span-2">
          <GlassPanel animate={false} className="flex flex-col h-[calc(100vh-240px)]">
            <h3 className="text-sm font-semibold text-muted-foreground uppercase mb-4">
              {t("advisor.chat")}
            </h3>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto space-y-4 mb-4">
              {messages.length === 0 && (
                <div className="flex items-center justify-center h-full">
                  <div className="text-center">
                    <Brain className="w-12 h-12 mx-auto text-[#00D4FF]/20 mb-3" />
                    <p className="text-sm text-muted-foreground">
                      {locale === "fr"
                        ? "Posez une question sur vos prospects..."
                        : "Ask a question about your prospects..."}
                    </p>
                  </div>
                </div>
              )}
              {messages.map((msg, i) => (
                <div
                  key={i}
                  className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
                >
                  <div
                    className={`max-w-[80%] p-3 rounded-xl text-sm ${
                      msg.role === "user"
                        ? "bg-[#1A73E8]/20 border border-[#1A73E8]/30"
                        : "bg-white/5 border border-white/5"
                    }`}
                  >
                    {msg.content}
                  </div>
                </div>
              ))}
              {isLoading && (
                <div className="flex justify-start">
                  <div className="p-3 rounded-xl bg-white/5 border border-white/5">
                    <div className="flex gap-1">
                      <div className="w-2 h-2 rounded-full bg-[#00D4FF] animate-bounce" />
                      <div className="w-2 h-2 rounded-full bg-[#00D4FF] animate-bounce" style={{ animationDelay: "0.1s" }} />
                      <div className="w-2 h-2 rounded-full bg-[#00D4FF] animate-bounce" style={{ animationDelay: "0.2s" }} />
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Input */}
            <div className="flex gap-2">
              <input
                type="text"
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleSend()}
                placeholder={locale === "fr" ? "Posez votre question..." : "Ask your question..."}
                className="flex-1 h-10 px-4 rounded-xl text-sm bg-white/5 border border-white/8 focus:outline-none focus:ring-1 focus:ring-[#00D4FF]/50"
              />
              <button
                onClick={handleSend}
                disabled={!chatInput.trim()}
                className="px-4 h-10 rounded-xl bg-[#1A73E8] text-white text-sm font-medium hover:bg-[#1557b0] transition-all disabled:opacity-50"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </GlassPanel>
        </div>
      </div>
    </div>
  );
}

function generateLocalResponse(query: string, prospects: any[], locale: string): string {
  const q = query.toLowerCase();

  if (q.includes("combien") || q.includes("how many") || q.includes("total")) {
    const scored = prospects.filter((p: any) => p.scoringTier !== "unscored").length;
    return locale === "fr"
      ? `Vous avez ${prospects.length} prospects au total. ${scored} sont scores, ${prospects.length - scored} restent a scorer.`
      : `You have ${prospects.length} total prospects. ${scored} are scored, ${prospects.length - scored} remain to be scored.`;
  }

  if (q.includes("top") || q.includes("meilleur") || q.includes("best")) {
    const top = [...prospects].sort((a: any, b: any) => b.totalScore - a.totalScore).slice(0, 5);
    const list = top.map((p: any, i: number) => `${i + 1}. ${p.organisation} (score: ${p.totalScore})`).join("\n");
    return (locale === "fr" ? "Top 5 prospects par score:\n" : "Top 5 prospects by score:\n") + list;
  }

  if (q.includes("known") || q.includes("connu")) {
    const known = prospects.filter((p: any) => p.knownToIPD);
    return locale === "fr"
      ? `${known.length} prospects sont connus de l'IPD: ${known.map((p: any) => p.organisation).join(", ")}.`
      : `${known.length} prospects are known to IPD: ${known.map((p: any) => p.organisation).join(", ")}.`;
  }

  return locale === "fr"
    ? "Je peux vous aider avec des questions sur vos prospects, scores, pipeline et donnees financieres. Essayez: 'Combien de prospects?', 'Top prospects', 'Prospects connus de l'IPD'."
    : "I can help with questions about your prospects, scores, pipeline and financial data. Try: 'How many prospects?', 'Top prospects', 'Known to IPD'.";
}
