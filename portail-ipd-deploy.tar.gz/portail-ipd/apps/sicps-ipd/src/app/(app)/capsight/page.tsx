"use client";

import { useMemo } from "react";
import { useProspectStore } from "@/stores/prospect-store";
import { useTranslation } from "@/lib/i18n";
import { GlassPanel } from "@/components/shared/glass-panel";
import { KpiCard } from "@/components/shared/kpi-card";
import { formatCurrency } from "@/lib/utils";
import { FUNDING_TIER_COLORS, FUNDING_TIER_LABELS } from "@/lib/scoring/tier-classifier";
import { DollarSign, TrendingUp, PieChart, BarChart3, Database } from "lucide-react";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart as RPieChart, Pie, Cell, Legend,
} from "recharts";

export default function CapSightPage() {
  const { t, locale } = useTranslation();
  const prospects = useProspectStore((s) => s.prospects);

  // Tier distribution
  const tierData = useMemo(() => {
    const tiers = { mega: 0, major: 0, mid: 0, emerging: 0, unknown: 0 };
    prospects.forEach((p) => { tiers[p.fundingTier]++; });
    return Object.entries(tiers)
      .filter(([, v]) => v > 0)
      .map(([key, value]) => ({
        name: locale === "fr" ? FUNDING_TIER_LABELS[key as keyof typeof FUNDING_TIER_LABELS].fr : FUNDING_TIER_LABELS[key as keyof typeof FUNDING_TIER_LABELS].en,
        value,
        fill: FUNDING_TIER_COLORS[key as keyof typeof FUNDING_TIER_COLORS],
      }));
  }, [prospects, locale]);

  // Giving by type
  const givingByType = useMemo(() => {
    const map = new Map<string, number>();
    prospects.forEach((p) => {
      const short = p.type.split(" / ")[0];
      map.set(short, (map.get(short) || 0) + (p.annualGiving || 0));
    });
    return Array.from(map.entries())
      .map(([name, value]) => ({ name: name.length > 15 ? name.slice(0, 15) + "..." : name, value }))
      .sort((a, b) => b.value - a.value);
  }, [prospects]);

  // Data freshness
  const freshness = useMemo(() => {
    const counts = { fresh: 0, aging: 0, stale: 0, unknown: 0 };
    prospects.forEach((p) => { counts[p.dataFreshness]++; });
    return counts;
  }, [prospects]);

  const totalGiving = prospects.reduce((s, p) => s + (p.annualGiving || 0), 0);
  const avgGrant = prospects.reduce((s, p) => s + (p.avgGrantSize || 0), 0) / Math.max(1, prospects.filter((p) => p.avgGrantSize).length);

  return (
    <div className="space-y-6 bg-grid min-h-full">
      {/* Header */}
      <div className="flex items-center gap-3">
        <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-[#ec4899]/10">
          <DollarSign className="w-5 h-5 text-[#ec4899]" />
        </div>
        <div>
          <h1 className="text-2xl font-bold font-[family-name:var(--font-display)]">{t("capsight.title")}</h1>
          <p className="text-sm text-muted-foreground">
            {locale === "fr" ? "Analyse de la capacite financiere des prospects" : "Financial capacity analysis of prospects"}
          </p>
        </div>
      </div>

      {/* KPI Row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <KpiCard label="Total Annual Giving" value={totalGiving} format={(n) => formatCurrency(n, true)} icon={<DollarSign className="w-4 h-4" />} color="#ec4899" glow="purple" />
        <KpiCard label="Avg Grant Size" value={avgGrant} format={(n) => formatCurrency(n, true)} icon={<TrendingUp className="w-4 h-4" />} color="#10b981" delay={0.05} />
        <KpiCard label={locale === "fr" ? "Mega-donateurs" : "Mega-donors"} value={prospects.filter((p) => p.fundingTier === "mega").length} icon={<BarChart3 className="w-4 h-4" />} color="#ef4444" delay={0.1} />
        <KpiCard
          label={locale === "fr" ? "Donnees fraiches" : "Fresh Data"}
          value={Math.round((freshness.fresh / Math.max(1, prospects.length)) * 100)}
          unit="%"
          icon={<Database className="w-4 h-4" />}
          color="#f59e0b"
          delay={0.15}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Giving Distribution by Type */}
        <GlassPanel delay={0.1}>
          <h3 className="text-sm font-semibold text-muted-foreground uppercase mb-4">
            {locale === "fr" ? "Annual Giving par Type" : "Annual Giving by Type"}
          </h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={givingByType} layout="vertical">
              <CartesianGrid stroke="rgba(255,255,255,0.06)" horizontal={false} />
              <XAxis type="number" tick={{ fill: "rgba(255,255,255,0.5)", fontSize: 10 }} tickFormatter={(v) => formatCurrency(v, true)} />
              <YAxis dataKey="name" type="category" width={100} tick={{ fill: "rgba(255,255,255,0.6)", fontSize: 11 }} />
              <Tooltip
                contentStyle={{ backgroundColor: "#161b22", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 12 }}
                formatter={(value: any) => [formatCurrency(Number(value), true), "Annual Giving"]}
              />
              <Bar dataKey="value" fill="#ec4899" radius={[0, 4, 4, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </GlassPanel>

        {/* Tier Segmentation */}
        <GlassPanel delay={0.15}>
          <h3 className="text-sm font-semibold text-muted-foreground uppercase mb-4">
            {t("capsight.tiers")}
          </h3>
          <ResponsiveContainer width="100%" height={300}>
            <RPieChart>
              <Pie
                data={tierData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={100}
                paddingAngle={3}
                dataKey="value"
                label={({ name, value }) => `${name} (${value})`}
              >
                {tierData.map((entry, i) => (
                  <Cell key={i} fill={entry.fill} />
                ))}
              </Pie>
              <Legend wrapperStyle={{ fontSize: 12 }} />
              <Tooltip contentStyle={{ backgroundColor: "#161b22", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 12 }} />
            </RPieChart>
          </ResponsiveContainer>
        </GlassPanel>

        {/* Data Freshness */}
        <GlassPanel delay={0.2} className="lg:col-span-2">
          <h3 className="text-sm font-semibold text-muted-foreground uppercase mb-4">
            {t("capsight.freshness")}
          </h3>
          <div className="grid grid-cols-4 gap-4">
            {[
              { key: "fresh", label: locale === "fr" ? "Frais (< 1 an)" : "Fresh (< 1y)", color: "#10b981", count: freshness.fresh },
              { key: "aging", label: locale === "fr" ? "Vieillissant (1-2 ans)" : "Aging (1-2y)", color: "#f59e0b", count: freshness.aging },
              { key: "stale", label: locale === "fr" ? "Obsolete (> 2 ans)" : "Stale (> 2y)", color: "#ef4444", count: freshness.stale },
              { key: "unknown", label: locale === "fr" ? "Inconnu" : "Unknown", color: "#64748b", count: freshness.unknown },
            ].map((item) => (
              <div key={item.key} className="text-center p-4 rounded-xl bg-white/3 border border-white/5">
                <div className="w-3 h-3 rounded-full mx-auto mb-2" style={{ backgroundColor: item.color }} />
                <p className="text-2xl font-bold font-mono" style={{ color: item.color }}>{item.count}</p>
                <p className="text-[11px] text-muted-foreground mt-1">{item.label}</p>
              </div>
            ))}
          </div>
        </GlassPanel>
      </div>
    </div>
  );
}
