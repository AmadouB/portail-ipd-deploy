"use client";

import { useState } from "react";
import { useProspectStore } from "@/stores/prospect-store";
import { useTranslation } from "@/lib/i18n";
import { GlassPanel } from "@/components/shared/glass-panel";
import { StatusBadge } from "@/components/shared/status-badge";
import { ScoringPanel } from "@/components/radar/scoring-panel";
import { RadarVisualization } from "@/components/radar/radar-visualization";
import { RankedTable } from "@/components/radar/ranked-table";
import { Target } from "lucide-react";

type Tab = "scoring" | "visualizations" | "rankings";

export default function RadarPage() {
  const { t } = useTranslation();
  const [activeTab, setActiveTab] = useState<Tab>("scoring");
  const prospects = useProspectStore((s) => s.prospects);
  const isLoading = useProspectStore((s) => s.isLoading);
  const getScoringProgress = useProspectStore((s) => s.getScoringProgress);
  const progress = getScoringProgress();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-[60vh]">
        <div className="w-12 h-12 rounded-full border-2 border-[#8b5cf6]/30 border-t-[#8b5cf6] animate-spin" />
      </div>
    );
  }

  const tabs: { key: Tab; label: string }[] = [
    { key: "scoring", label: t("radar.scoring") },
    { key: "visualizations", label: t("radar.visualizations") },
    { key: "rankings", label: t("radar.rankings") },
  ];

  return (
    <div className="space-y-6 bg-grid min-h-full">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-[#8b5cf6]/10">
            <Target className="w-5 h-5 text-[#8b5cf6]" />
          </div>
          <div>
            <h1 className="text-2xl font-bold font-[family-name:var(--font-display)]">
              {t("radar.title")}
            </h1>
            <p className="text-sm text-muted-foreground">
              {progress.scored}/{progress.total} scores — {progress.percentage}% {t("radar.scoring").toLowerCase()}
            </p>
          </div>
        </div>

        {/* Progress bar */}
        <div className="hidden md:flex items-center gap-3">
          <div className="w-32 h-2 rounded-full bg-white/5">
            <div
              className="h-full rounded-full bg-[#8b5cf6] transition-all duration-700"
              style={{ width: `${progress.percentage}%` }}
            />
          </div>
          <span className="text-sm font-mono text-muted-foreground">{progress.percentage}%</span>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 p-1 rounded-xl bg-white/3 border border-white/5 w-fit">
        {tabs.map((tab) => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key)}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
              activeTab === tab.key
                ? "bg-[#8b5cf6]/20 text-white border border-[#8b5cf6]/30"
                : "text-muted-foreground hover:text-white hover:bg-white/5"
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      {activeTab === "scoring" && <ScoringPanel prospects={prospects} />}
      {activeTab === "visualizations" && <RadarVisualization prospects={prospects} />}
      {activeTab === "rankings" && <RankedTable prospects={prospects} />}
    </div>
  );
}
