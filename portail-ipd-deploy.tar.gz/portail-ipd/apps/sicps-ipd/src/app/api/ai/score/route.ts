import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { organisation, summary, type, whyAligned, annualGiving, avgGrantSize, knownToIPD, countriesServed, confidence } = body;

    const apiKey = process.env.ANTHROPIC_API_KEY;

    // If no API key, use heuristic scoring
    if (!apiKey || apiKey === "your_api_key_here") {
      return NextResponse.json(generateHeuristicScore(body));
    }

    const prompt = `You are a fundraising intelligence advisor for Institut Pasteur de Dakar (IPD), a leading biomedical research institution in Senegal focused on pandemic preparedness, vaccine development, diagnostics, and public health.

Score this prospect on three dimensions (1-5 each):

1. **Affinity (1-5)**: Mission alignment with IPD's priorities (pandemic preparedness, vaccine manufacturing, diagnostics, public health in Africa)
   - 5 = Direct funding of vaccine/diagnostics/pandemic prep in Africa
   - 4 = Strong health/global health focus with Africa presence
   - 3 = General health or development focus, some Africa work
   - 2 = Tangential alignment (education, agriculture, but relevant regions)
   - 1 = No clear alignment

2. **Ability (1-5)**: Financial capacity to fund IPD-scale projects
   - 5 = Annual Giving > $1B, large grant capacity
   - 4 = $100M-$1B, significant grant capacity
   - 3 = $10M-$100M, moderate grants
   - 2 = $1M-$10M, smaller grants
   - 1 = < $1M or unknown

3. **Access (1-5)**: How reachable is this prospect for IPD
   - 5 = Known to IPD, existing relationship, multiple delegates
   - 4 = Known to IPD or strong delegate connections
   - 3 = Some delegates identified, indirect connections possible
   - 2 = Few connections, cold outreach needed
   - 1 = No connections, very difficult to reach

PROSPECT DATA:
- Organisation: ${organisation}
- Type: ${type}
- Summary: ${summary || "N/A"}
- Why Aligned with IPD: ${whyAligned || "N/A"}
- Annual Giving: ${annualGiving ? `$${annualGiving.toLocaleString()}` : "Unknown"}
- Avg Grant Size: ${avgGrantSize ? `$${avgGrantSize.toLocaleString()}` : "Unknown"}
- Known to IPD: ${knownToIPD ? "Yes" : "No/Unknown"}
- Countries Served: ${countriesServed?.join(", ") || "Unknown"}
- Data Confidence: ${confidence || "Unknown"}

Respond in JSON format only:
{
  "affinity": <1-5>,
  "ability": <1-5>,
  "access": <1-5>,
  "rationale": "<2-3 sentence justification>"
}`;

    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 300,
        messages: [{ role: "user", content: prompt }],
      }),
    });

    if (!response.ok) {
      console.error("Claude API error:", response.status);
      return NextResponse.json(generateHeuristicScore(body));
    }

    const result = await response.json();
    const text = result.content?.[0]?.text || "";

    // Extract JSON from response
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      const parsed = JSON.parse(jsonMatch[0]);
      return NextResponse.json({
        affinity: Math.max(1, Math.min(5, parsed.affinity)),
        ability: Math.max(1, Math.min(5, parsed.ability)),
        access: Math.max(1, Math.min(5, parsed.access)),
        rationale: parsed.rationale || "",
      });
    }

    return NextResponse.json(generateHeuristicScore(body));
  } catch (error) {
    console.error("AI score error:", error);
    return NextResponse.json(generateHeuristicScore({}), { status: 200 });
  }
}

function generateHeuristicScore(data: any) {
  const { whyAligned, annualGiving, knownToIPD, countriesServed } = data;

  // Simple heuristic scoring
  let affinity = 2;
  if (whyAligned && whyAligned.toLowerCase().includes("pandemic")) affinity = 4;
  else if (whyAligned && whyAligned.length > 10) affinity = 3;

  let ability = 2;
  if (annualGiving > 1e9) ability = 5;
  else if (annualGiving > 1e8) ability = 4;
  else if (annualGiving > 1e7) ability = 3;
  else if (annualGiving > 1e6) ability = 2;

  let access = 2;
  if (knownToIPD) access = 4;
  else if (countriesServed?.some((c: string) => c.toLowerCase().includes("senegal"))) access = 3;

  return {
    affinity,
    ability,
    access,
    rationale: "Score heuristique automatique (configurez ANTHROPIC_API_KEY pour le scoring IA complet).",
  };
}
