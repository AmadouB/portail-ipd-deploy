"use client";

import { create } from "zustand";
import type { Prospect, ScoringWeights, ScoringTier, PipelinePhase, ProspectionNote } from "@/types";
import { DEFAULT_WEIGHTS } from "@/types";
import { calculateCompositeScore, classifyScoringTier } from "@/lib/scoring/composite-index";
import { classifyFundingTier, calculateDataFreshness } from "@/lib/scoring/tier-classifier";

interface ProspectStore {
  prospects: Prospect[];
  isLoading: boolean;
  weights: ScoringWeights;

  // Actions
  loadProspects: () => Promise<void>;
  addProspect: (prospect: Prospect) => void;
  deleteProspect: (id: string) => void;
  updateProspect: (id: string, updates: Partial<Prospect>) => void;
  addProspectionNote: (prospectId: string, note: ProspectionNote) => void;
  deleteProspectionNote: (prospectId: string, noteId: string) => void;
  scoreProspect: (id: string, affinity: number, ability: number, access: number, scoredBy?: string) => void;
  setWeights: (weights: ScoringWeights) => void;

  // Selectors
  getById: (id: string) => Prospect | undefined;
  getScored: () => Prospect[];
  getUnscored: () => Prospect[];
  getByTier: (tier: ScoringTier) => Prospect[];
  getByType: (type: string) => Prospect[];
  getByPhase: (phase: PipelinePhase) => Prospect[];
  getTopProspects: (n: number) => Prospect[];
  getScoringProgress: () => { scored: number; total: number; percentage: number };
}

const STORAGE_KEY = "sicps_prospects";

function persistProspects(prospects: Prospect[]) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(prospects));
  } catch { /* ignore quota errors */ }
}

function loadPersistedProspects(): Prospect[] | null {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) return JSON.parse(stored);
  } catch { /* ignore */ }
  return null;
}

export const useProspectStore = create<ProspectStore>((set, get) => ({
  prospects: [],
  isLoading: true,
  weights: DEFAULT_WEIGHTS,

  loadProspects: async () => {
    // Try localStorage first (contains user modifications)
    const persisted = loadPersistedProspects();
    if (persisted && persisted.length > 0) {
      set({ prospects: persisted, isLoading: false });
      return;
    }
    // Fallback: load from JSON seed
    try {
      const res = await fetch("/data/prospects.json");
      const data = await res.json();
      set({ prospects: data, isLoading: false });
    } catch (err) {
      console.error("[SICPS] Failed to load prospects:", err);
      set({ isLoading: false });
    }
  },

  addProspect: (prospect) => {
    set((state) => {
      const prospects = [...state.prospects, prospect];
      persistProspects(prospects);
      return { prospects };
    });
  },

  deleteProspect: (id) => {
    set((state) => {
      const prospects = state.prospects.filter((p) => p.id !== id);
      persistProspects(prospects);
      return { prospects };
    });
  },

  updateProspect: (id, updates) => {
    set((state) => {
      const prospects = state.prospects.map((p) =>
        p.id === id ? { ...p, ...updates, updatedAt: new Date().toISOString() } : p
      );
      persistProspects(prospects);
      return { prospects };
    });
  },

  addProspectionNote: (prospectId, note) => {
    set((state) => {
      const prospects = state.prospects.map((p) => {
        if (p.id !== prospectId) return p;
        const notes = [...(p.prospectionNotes || []), note];
        return {
          ...p,
          prospectionNotes: notes,
          lastContactDate: ["contact", "meeting", "email", "call"].includes(note.type) ? note.date : p.lastContactDate,
          updatedAt: new Date().toISOString(),
        };
      });
      persistProspects(prospects);
      return { prospects };
    });
  },

  deleteProspectionNote: (prospectId, noteId) => {
    set((state) => {
      const prospects = state.prospects.map((p) => {
        if (p.id !== prospectId) return p;
        return {
          ...p,
          prospectionNotes: (p.prospectionNotes || []).filter((n) => n.id !== noteId),
          updatedAt: new Date().toISOString(),
        };
      });
      persistProspects(prospects);
      return { prospects };
    });
  },

  scoreProspect: (id, affinity, ability, access, scoredBy) => {
    const { weights } = get();
    const totalScore = calculateCompositeScore(affinity, ability, access, weights);
    const scoringTier = classifyScoringTier(affinity, ability, access);

    set((state) => {
      const prospects = state.prospects.map((p) =>
        p.id === id
          ? {
              ...p,
              affinity,
              ability,
              access,
              totalScore,
              scoringTier,
              scoredAt: new Date().toISOString(),
              scoredBy: scoredBy || "analyst",
              updatedAt: new Date().toISOString(),
            }
          : p
      );
      persistProspects(prospects);
      return { prospects };
    });
  },

  setWeights: (weights) => {
    // Recalculate all composite scores
    set((state) => {
      const prospects = state.prospects.map((p) => {
        if (p.affinity === 0 && p.ability === 0 && p.access === 0) return p;
        const totalScore = calculateCompositeScore(p.affinity, p.ability, p.access, weights);
        return { ...p, totalScore };
      });
      persistProspects(prospects);
      return { prospects, weights };
    });
  },

  // Selectors
  getById: (id) => get().prospects.find((p) => p.id === id),
  getScored: () => get().prospects.filter((p) => p.scoringTier !== "unscored"),
  getUnscored: () => get().prospects.filter((p) => p.scoringTier === "unscored"),
  getByTier: (tier) => get().prospects.filter((p) => p.scoringTier === tier),
  getByType: (type) => get().prospects.filter((p) => p.type === type),
  getByPhase: (phase) => get().prospects.filter((p) => p.pipelinePhase === phase),
  getTopProspects: (n) =>
    [...get().prospects]
      .filter((p) => p.totalScore > 0)
      .sort((a, b) => b.totalScore - a.totalScore)
      .slice(0, n),
  getScoringProgress: () => {
    const { prospects } = get();
    const scored = prospects.filter((p) => p.scoringTier !== "unscored").length;
    return {
      scored,
      total: prospects.length,
      percentage: prospects.length > 0 ? Math.round((scored / prospects.length) * 100) : 0,
    };
  },
}));
