"use client";

import { create } from "zustand";

type Locale = "fr" | "en";

interface LocaleStore {
  locale: Locale;
  setLocale: (locale: Locale) => void;
  toggleLocale: () => void;
  loadLocale: () => void;
}

export const useLocaleStore = create<LocaleStore>((set) => ({
  locale: "fr",

  setLocale: (locale) => {
    if (typeof localStorage !== "undefined") {
      localStorage.setItem("sicps_locale", locale);
    }
    set({ locale });
  },

  toggleLocale: () =>
    set((state) => {
      const next = state.locale === "fr" ? "en" : "fr";
      if (typeof localStorage !== "undefined") {
        localStorage.setItem("sicps_locale", next);
      }
      return { locale: next };
    }),

  loadLocale: () => {
    if (typeof localStorage !== "undefined") {
      const saved = localStorage.getItem("sicps_locale");
      if (saved === "fr" || saved === "en") {
        set({ locale: saved });
      }
    }
  },
}));
