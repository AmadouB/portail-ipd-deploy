"use client";

import { create } from "zustand";
import type { UserSession } from "@/types";

const STORAGE_KEY = "sicps_session";

// Pre-configured users for IPD
const MOCK_USERS = [
  { id: "u1", email: "amadou.bao@pasteur.sn", password: "Sicps@2026", firstName: "Amadou", lastName: "BAO", role: "admin" as const },
  { id: "u2", email: "sophie.diallo@pasteur.sn", password: "Sicps@2026", firstName: "Sophie", lastName: "DIALLO", role: "admin" as const },
];

interface AuthStore {
  session: UserSession | null;
  isLoading: boolean;
  error: string | null;
  login: (email: string, password: string) => boolean;
  logout: () => void;
  loadSession: () => void;
}

export const useAuthStore = create<AuthStore>((set, get) => ({
  session: null,
  isLoading: true,
  error: null,

  login: (email, password) => {
    const user = MOCK_USERS.find(
      (u) => u.email.toLowerCase() === email.toLowerCase() && u.password === password
    );
    if (!user) {
      set({ error: "Email ou mot de passe incorrect" });
      return false;
    }
    const { password: _, ...safeUser } = user;
    const session: UserSession = {
      user: safeUser,
      token: `sicps_${user.id}_${Date.now()}`,
      expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
    };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(session));
    set({ session, error: null });
    return true;
  },

  logout: () => {
    localStorage.removeItem(STORAGE_KEY);
    set({ session: null, error: null });
  },

  loadSession: () => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const session: UserSession = JSON.parse(stored);
        if (new Date(session.expiresAt) > new Date()) {
          set({ session, isLoading: false });
          return;
        }
        localStorage.removeItem(STORAGE_KEY);
      }
    } catch { /* ignore */ }
    set({ session: null, isLoading: false });
  },
}));
