"use client";

import { create } from "zustand";

type Theme = "dark" | "light";

interface ThemeStore {
  theme: Theme;
  isFullscreen: boolean;
  toggleTheme: () => void;
  setTheme: (theme: Theme) => void;
  toggleFullscreen: () => void;
  loadTheme: () => void;
}

function applyTheme(theme: Theme) {
  if (typeof document === "undefined") return;
  document.documentElement.classList.toggle("dark", theme === "dark");
  document.documentElement.classList.toggle("light", theme === "light");
}

function saveTheme(theme: Theme) {
  if (typeof localStorage !== "undefined") {
    localStorage.setItem("sicps_theme", theme);
  }
}

function getSavedTheme(): Theme {
  if (typeof localStorage !== "undefined") {
    const saved = localStorage.getItem("sicps_theme");
    if (saved === "light" || saved === "dark") return saved;
  }
  return "dark";
}

export const useThemeStore = create<ThemeStore>((set) => ({
  theme: "dark",
  isFullscreen: false,

  toggleTheme: () =>
    set((state) => {
      const next = state.theme === "dark" ? "light" : "dark";
      applyTheme(next);
      saveTheme(next);
      return { theme: next };
    }),

  setTheme: (theme) => {
    applyTheme(theme);
    saveTheme(theme);
    set({ theme });
  },

  loadTheme: () => {
    const saved = getSavedTheme();
    applyTheme(saved);
    set({ theme: saved });
  },

  toggleFullscreen: () => {
    if (typeof document === "undefined") return;
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
      set({ isFullscreen: true });
    } else {
      document.exitFullscreen().catch(() => {});
      set({ isFullscreen: false });
    }
  },
}));
