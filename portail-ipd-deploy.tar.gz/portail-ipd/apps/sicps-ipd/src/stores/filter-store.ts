"use client";

import { create } from "zustand";
import type { OrganisationType, ConfidenceLevel, ScoringTier, FundingTier } from "@/types";

interface FilterStore {
  searchQuery: string;
  types: OrganisationType[];
  confidences: ConfidenceLevel[];
  scoringTiers: ScoringTier[];
  fundingTiers: FundingTier[];
  knownToIPD: boolean | null;
  givingRange: [number, number];

  setSearchQuery: (query: string) => void;
  toggleType: (type: OrganisationType) => void;
  toggleConfidence: (confidence: ConfidenceLevel) => void;
  toggleScoringTier: (tier: ScoringTier) => void;
  toggleFundingTier: (tier: FundingTier) => void;
  setKnownToIPD: (value: boolean | null) => void;
  setGivingRange: (range: [number, number]) => void;
  resetFilters: () => void;
  hasActiveFilters: () => boolean;
}

const initialState = {
  searchQuery: "",
  types: [] as OrganisationType[],
  confidences: [] as ConfidenceLevel[],
  scoringTiers: [] as ScoringTier[],
  fundingTiers: [] as FundingTier[],
  knownToIPD: null as boolean | null,
  givingRange: [0, 50_000_000_000] as [number, number],
};

export const useFilterStore = create<FilterStore>((set, get) => ({
  ...initialState,

  setSearchQuery: (query) => set({ searchQuery: query }),

  toggleType: (type) =>
    set((state) => ({
      types: state.types.includes(type)
        ? state.types.filter((t) => t !== type)
        : [...state.types, type],
    })),

  toggleConfidence: (confidence) =>
    set((state) => ({
      confidences: state.confidences.includes(confidence)
        ? state.confidences.filter((c) => c !== confidence)
        : [...state.confidences, confidence],
    })),

  toggleScoringTier: (tier) =>
    set((state) => ({
      scoringTiers: state.scoringTiers.includes(tier)
        ? state.scoringTiers.filter((t) => t !== tier)
        : [...state.scoringTiers, tier],
    })),

  toggleFundingTier: (tier) =>
    set((state) => ({
      fundingTiers: state.fundingTiers.includes(tier)
        ? state.fundingTiers.filter((t) => t !== tier)
        : [...state.fundingTiers, tier],
    })),

  setKnownToIPD: (value) => set({ knownToIPD: value }),
  setGivingRange: (range) => set({ givingRange: range }),
  resetFilters: () => set(initialState),

  hasActiveFilters: () => {
    const s = get();
    return (
      s.searchQuery !== "" ||
      s.types.length > 0 ||
      s.confidences.length > 0 ||
      s.scoringTiers.length > 0 ||
      s.fundingTiers.length > 0 ||
      s.knownToIPD !== null ||
      s.givingRange[0] > 0 ||
      s.givingRange[1] < 50_000_000_000
    );
  },
}));
