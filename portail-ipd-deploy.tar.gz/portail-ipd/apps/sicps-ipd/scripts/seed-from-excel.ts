/**
 * Seed script: reads Skoll Shortlist Excel and generates prospects.json
 * Usage: npx tsx scripts/seed-from-excel.ts
 */
import * as XLSX from "xlsx";
import * as fs from "fs";
import * as path from "path";

// Inline parsers to avoid @/ alias issues in scripts
function parseDelegates(raw: string | null | undefined, organisationId: string) {
  if (!raw || raw.trim() === "") return [];
  const delegates: any[] = [];
  const lines = raw.split(/\n/).map((l: string) => l.trim()).filter(Boolean);
  let counter = 0;

  for (const line of lines) {
    const fullMatch = line.match(/^(.+?)\s*\((.+?)\)\s*\[(?:Added\s*)?(\d{4}-\d{2}-\d{2})\]$/);
    if (fullMatch) {
      delegates.push({
        id: `del_${organisationId}_${counter++}`,
        name: fullMatch[1].trim(),
        title: fullMatch[2].trim(),
        addedDate: fullMatch[3],
        organisationId,
      });
      continue;
    }
    const titleMatch = line.match(/^(.+?)\s*\((.+?)\)$/);
    if (titleMatch) {
      delegates.push({
        id: `del_${organisationId}_${counter++}`,
        name: titleMatch[1].trim(),
        title: titleMatch[2].trim(),
        addedDate: null,
        organisationId,
      });
      continue;
    }
    const names = line.split(",").map((n: string) => n.trim()).filter(Boolean);
    for (const name of names) {
      if (name.length > 1) {
        delegates.push({
          id: `del_${organisationId}_${counter++}`,
          name,
          title: "",
          addedDate: null,
          organisationId,
        });
      }
    }
  }
  return delegates;
}

const SKIP_TERMS = ["i prefer not to say", "n/a", "not specified", "global", "worldwide"];
const COUNTRY_ALIASES: Record<string, string> = {
  "usa": "United States",
  "us": "United States",
  "united states of america": "United States",
  "united states of america (usa)": "United States",
  "uk": "United Kingdom",
  "great britain": "United Kingdom",
};

function parseCountries(raw: string | null | undefined): string[] {
  if (!raw || raw.trim() === "") return [];
  const lower = raw.toLowerCase().trim();
  if (SKIP_TERMS.some(t => lower.includes(t))) return [];
  return raw.split(",").map(c => c.trim()).filter(Boolean).map(name => {
    const l = name.toLowerCase().trim();
    if (COUNTRY_ALIASES[l]) return COUNTRY_ALIASES[l];
    return name.trim().split(" ").map(w => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase()).join(" ");
  });
}

function classifyFundingTier(annualGiving: number | null) {
  if (annualGiving == null) return "unknown";
  if (annualGiving >= 1_000_000_000) return "mega";
  if (annualGiving >= 50_000_000) return "major";
  if (annualGiving >= 1_000_000) return "mid";
  return "emerging";
}

function calculateDataFreshness(dataYear: number | null) {
  if (dataYear == null) return "unknown";
  const age = new Date().getFullYear() - dataYear;
  if (age <= 1) return "fresh";
  if (age <= 2) return "aging";
  return "stale";
}

function slugify(text: string) {
  return text.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "_").replace(/^_|_$/g, "").slice(0, 40);
}

// ——— Main ———
const EXCEL_PATH = path.resolve(process.env.HOME || "", "Downloads/Skoll Shortlist .xlsx");
const OUTPUT_PATH = path.resolve(__dirname, "../public/data/prospects.json");

console.log(`Reading Excel: ${EXCEL_PATH}`);
const workbook = XLSX.readFile(EXCEL_PATH);
const sheet = workbook.Sheets[workbook.SheetNames[0]];
const rows: any[] = XLSX.utils.sheet_to_json(sheet, { defval: null });

console.log(`Found ${rows.length} rows`);

const prospects = rows.map((row, index) => {
  const id = slugify(row["Organisation"] || `prospect_${index}`);
  const annualGiving = parseFinancialValue(row["Annual Giving (USD)"]);
  const avgGrantSize = parseFinancialValue(row["Avg Grant Size (USD)"]);
  const grantCount = parseIntSafe(row["# Grants"]);
  const dataYear = parseIntSafe(row["Data Year"]);
  const knownRaw = row["Known to IPD?"];
  const knownToIPD = knownRaw ? String(knownRaw).toLowerCase().includes("yes") : null;
  const confidence = normalizeConfidence(row["Confidence"]);

  return {
    id,
    organisation: String(row["Organisation"] || "").trim(),
    organisationSummary: String(row["Organisation Summary"] || "").trim(),
    knownToIPD,
    type: normalizeType(row["Type"]),
    delegatesRaw: String(row["Delegates at Skoll"] || ""),
    delegates: parseDelegates(row["Delegates at Skoll"], id),
    whyAligned: String(row["Why Aligned with IPD"] || "").trim(),
    annualGiving,
    avgGrantSize,
    grantCount,
    dataYear,
    dataSource: String(row["Data Source"] || "").trim(),
    confidence,
    countriesServedRaw: String(row["Countries Served"] || ""),
    countriesServed: parseCountries(row["Countries Served"]),
    affinity: 0,
    ability: 0,
    access: 0,
    totalScore: 0,
    fundingTier: classifyFundingTier(annualGiving),
    scoringTier: "unscored",
    dataFreshness: calculateDataFreshness(dataYear),
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
});

fs.mkdirSync(path.dirname(OUTPUT_PATH), { recursive: true });
fs.writeFileSync(OUTPUT_PATH, JSON.stringify(prospects, null, 2), "utf-8");
console.log(`Wrote ${prospects.length} prospects to ${OUTPUT_PATH}`);

// Stats
const typeCounts: Record<string, number> = {};
const tierCounts: Record<string, number> = {};
let totalDelegates = 0;
let totalCountries = 0;
for (const p of prospects) {
  typeCounts[p.type] = (typeCounts[p.type] || 0) + 1;
  tierCounts[p.fundingTier] = (tierCounts[p.fundingTier] || 0) + 1;
  totalDelegates += p.delegates.length;
  totalCountries += p.countriesServed.length;
}
console.log("\n--- Stats ---");
console.log("By Type:", typeCounts);
console.log("By Funding Tier:", tierCounts);
console.log(`Total delegates parsed: ${totalDelegates}`);
console.log(`Total country entries: ${totalCountries}`);

// ——— Helpers ———
function parseFinancialValue(val: any): number | null {
  if (val == null) return null;
  if (typeof val === "number") return val;
  const str = String(val).replace(/[$,\s]/g, "").trim();
  if (str === "" || str.toLowerCase() === "n/a") return null;
  const num = Number(str);
  return isNaN(num) ? null : num;
}

function parseIntSafe(val: any): number | null {
  if (val == null) return null;
  if (typeof val === "number") return Math.round(val);
  const str = String(val).replace(/[,\s]/g, "").trim();
  if (str === "" || str.toLowerCase() === "n/a") return null;
  const num = parseInt(str, 10);
  return isNaN(num) ? null : num;
}

function normalizeType(raw: any): string {
  if (!raw) return "Major Grant-Making Foundation";
  const str = String(raw).trim();
  // Map to our exact enum values
  const mapping: Record<string, string> = {
    "research / academic": "Research / Academic",
    "research/academic": "Research / Academic",
    "multilateral / government": "Multilateral / Government",
    "multilateral/government": "Multilateral / Government",
    "major grant-making foundation": "Major Grant-Making Foundation",
    "advisory / intermediary": "Advisory / Intermediary",
    "advisory/intermediary": "Advisory / Intermediary",
    "thematic / regional foundation": "Thematic / Regional Foundation",
    "thematic/regional foundation": "Thematic / Regional Foundation",
    "family foundation / family office": "Family Foundation / Family Office",
    "family foundation/family office": "Family Foundation / Family Office",
    "impact investor / social investment": "Impact Investor / Social Investment",
    "impact investor/social investment": "Impact Investor / Social Investment",
  };
  return mapping[str.toLowerCase()] || str;
}

function normalizeConfidence(raw: any): string {
  if (!raw) return "Medium";
  const str = String(raw).trim();
  const valid = ["High", "Verified", "Reported", "Medium", "Estimated", "Low"];
  const found = valid.find(v => v.toLowerCase() === str.toLowerCase());
  return found || "Medium";
}
