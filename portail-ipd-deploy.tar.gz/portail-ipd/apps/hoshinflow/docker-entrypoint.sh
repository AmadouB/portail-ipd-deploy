#!/bin/sh
set -e

echo "=== HoshinFlow — Démarrage ==="
echo "Environnement: ${NODE_ENV:-production}"
echo "BasePath: ${NEXT_BASE_PATH:-/hoshinflow}"
echo "Port: ${PORT:-3000}"

# Appel direct via `node ...prisma/build/index.js` plutôt que via .bin/prisma :
# le launcher prisma cherche ses fichiers .wasm voisins (prisma_schema_build_bg.wasm)
# dans son __dirname. Si on l'invoque via le symlink .bin/, et que le symlink
# a été déréférencé (Docker COPY), les fichiers wasm sont introuvables.
PRISMA="node /app/node_modules/prisma/build/index.js"

if [ -n "$DATABASE_URL" ]; then
  echo "Application des migrations Prisma..."
  i=0
  until $PRISMA migrate deploy --schema=./prisma/schema.prisma 2>&1; do
    i=$((i+1))
    if [ $i -gt 15 ]; then
      echo "[WARN] Migration impossible après 15 tentatives — démarrage quand même"
      break
    fi
    echo "Attente PostgreSQL... ($i/15)"
    sleep 2
  done
fi

echo "=== Démarrage du serveur ==="
exec "$@"
