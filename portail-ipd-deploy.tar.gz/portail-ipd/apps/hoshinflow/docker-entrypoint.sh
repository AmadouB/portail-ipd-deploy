#!/bin/sh
set -e

echo "=== HoshinFlow — Démarrage ==="
echo "Environnement: ${NODE_ENV:-production}"
echo "BasePath: ${NEXT_BASE_PATH:-/hoshinflow}"
echo "Port: ${PORT:-3000}"

if [ -n "$DATABASE_URL" ]; then
  echo "Application des migrations Prisma..."
  i=0
  until ./node_modules/.bin/prisma migrate deploy --schema=./prisma/schema.prisma 2>&1; do
    i=$((i+1))
    if [ $i -gt 15 ]; then
      echo "[WARN] Migration impossible après 15 tentatives — démarrage quand même"
      break
    fi
    echo "Attente PostgreSQL... ($i/15)"
    sleep 2
  done
fi

echo "=== Démarrage du serveur ==="
exec "$@"
