#!/bin/bash
set -e

# ─── HoshinFlow — Script de déploiement JumpServer ───
#
# Usage:
#   ./deploy.sh              Déploiement avec Docker Compose
#   ./deploy.sh --build      Rebuild l'image avant déploiement
#   ./deploy.sh --seed       Initialise la base avec les données IPD
#   ./deploy.sh --stop       Arrête le service
#   ./deploy.sh --logs       Affiche les logs
#   ./deploy.sh --status     Vérifie l'état du service
#   ./deploy.sh --bare       Déploiement sans Docker (Node.js direct)

APP_NAME="hoshinflow"
PORT="${PORT:-3000}"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
CYAN='\033[0;36m'
NC='\033[0m'

info() { echo -e "${CYAN}[INFO]${NC} $1"; }
ok() { echo -e "${GREEN}[OK]${NC} $1"; }
err() { echo -e "${RED}[ERREUR]${NC} $1"; }

# ─── Vérifications ─────────────────────────────

check_env() {
  if [ ! -f .env ]; then
    info "Création du fichier .env depuis .env.example..."
    cp .env.example .env
    echo ""
    err "Modifiez .env avant de relancer le déploiement !"
    err "  - JWT_SECRET : remplacez par un secret sécurisé"
    exit 1
  fi

  source .env

  if [ "$JWT_SECRET" = "votre-secret-jwt-securise-min-32-caracteres" ] || [ -z "$JWT_SECRET" ]; then
    err "JWT_SECRET n'est pas configuré dans .env"
    exit 1
  fi
}

# ─── Docker Compose ────────────────────────────

deploy_docker() {
  info "Vérification de Docker..."
  if ! command -v docker &> /dev/null; then
    err "Docker n'est pas installé"
    exit 1
  fi

  if ! command -v docker-compose &> /dev/null && ! docker compose version &> /dev/null; then
    err "Docker Compose n'est pas installé"
    exit 1
  fi

  check_env

  if [ "$1" = "--build" ]; then
    info "Build de l'image Docker..."
    docker compose build --no-cache
  fi

  info "Démarrage de HoshinFlow..."
  docker compose up -d

  sleep 5

  if docker compose ps | grep -q "running"; then
    ok "HoshinFlow démarré sur http://localhost:${PORT}"
    ok "Login: admin@hoshinflow.local"
  else
    err "Le démarrage a échoué. Consultez les logs:"
    docker compose logs --tail=20
    exit 1
  fi
}

# ─── Bare Metal (sans Docker) ──────────────────

deploy_bare() {
  info "Déploiement sans Docker..."

  # Check Node.js
  if ! command -v node &> /dev/null; then
    err "Node.js n'est pas installé (requis: v18+)"
    exit 1
  fi

  NODE_VERSION=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
  if [ "$NODE_VERSION" -lt 18 ]; then
    err "Node.js v18+ requis (actuel: $(node -v))"
    exit 1
  fi

  check_env

  info "Installation des dépendances..."
  npm ci --legacy-peer-deps

  info "Génération du client Prisma..."
  npx prisma generate --schema=prisma/schema.prisma

  info "Application des migrations PostgreSQL..."
  npx prisma migrate deploy

  info "Build de l'application..."
  npm run build

  info "Démarrage du serveur avec PM2..."
  if command -v pm2 &> /dev/null; then
    pm2 delete hoshinflow 2>/dev/null || true
    PORT=$PORT pm2 start npm --name hoshinflow -- start
    pm2 save
    ok "HoshinFlow démarré avec PM2"
  else
    info "PM2 non disponible, démarrage direct..."
    PORT=$PORT npm start
  fi
}

# ─── Seed ──────────────────────────────────────

seed() {
  info "Chargement des données IPD..."

  if [ ! -f /tmp/hoshin-data.json ]; then
    err "/tmp/hoshin-data.json introuvable"
    err "Exécutez d'abord le script d'extraction Excel"
    exit 1
  fi

  npx tsx prisma/seed.ts
  ok "Données chargées avec succès"
}

# ─── Commandes ─────────────────────────────────

case "${1:-}" in
  --build)
    deploy_docker --build
    ;;
  --seed)
    seed
    ;;
  --stop)
    info "Arrêt de HoshinFlow..."
    docker compose down
    ok "Service arrêté"
    ;;
  --logs)
    docker compose logs -f --tail=50
    ;;
  --status)
    docker compose ps
    echo ""
    info "Santé de l'API:"
    curl -s http://localhost:${PORT}/api/auth/session | head -c 200
    echo ""
    ;;
  --bare)
    deploy_bare
    ;;
  *)
    deploy_docker
    ;;
esac
