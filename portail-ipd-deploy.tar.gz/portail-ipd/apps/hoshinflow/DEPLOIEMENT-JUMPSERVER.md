# Déploiement HoshinFlow — JumpServer IPD

## Prérequis
- VPN IPD connecté
- Accès au JumpServer http://10.99.1.10 (user: `bao`, MFA activé)
- Serveur cible (ex. SRV-Delivery_unit / 10.1.7.249) accessible depuis le JumpServer

## Étape 1 — Uploader l'archive via File Manager

1. Connectez-vous sur **http://10.99.1.10**
2. Ouvrez **File Manager** (menu du haut)
3. Naviguez vers le serveur cible (SRV-Delivery_unit)
4. Uploadez le fichier **`hoshinflow-deploy.tar.gz`** dans `/tmp/` ou `/home/bao/`

## Étape 2 — Se connecter au serveur cible

Dans le menu **My assets** de JumpServer :
1. Double-cliquez sur **SRV-Delivery_unit** (ou l'asset cible)
2. Une session Luna (terminal web) s'ouvre

## Étape 3 — Installation (une seule commande)

```bash
# Extraction
cd /tmp   # ou là où vous avez uploadé
tar -xzf hoshinflow-deploy.tar.gz
cd hoshinflow

# Lancement — installe Docker + déploie tout
sudo ./scripts/install-on-server.sh
```

Durée : **3-5 minutes** (pull des images + build + démarrage).

## Étape 4 — Vérification

```bash
# État des services
sudo ./scripts/install-on-server.sh --status

# Logs temps réel
sudo ./scripts/install-on-server.sh --logs
```

Une fois déployé, l'application est accessible depuis le réseau IPD :
```
http://<IP_DU_SERVEUR>
```

## Commandes utiles

| Commande | Usage |
|----------|-------|
| `sudo ./scripts/install-on-server.sh --seed` | Charge les données IPD |
| `sudo ./scripts/install-on-server.sh --update` | Rebuild + redémarre |
| `sudo ./scripts/install-on-server.sh --stop` | Arrête les services |
| `sudo ./scripts/install-on-server.sh --status` | État des conteneurs |
| `docker compose logs -f` | Logs en direct |
| `docker compose exec postgres psql -U hoshinflow` | Accès DB |

## Architecture déployée

```
┌─────────────────────────────────────────────┐
│  Serveur cible (10.1.7.249 ou autre)       │
│                                             │
│  ┌─────────┐  ┌──────────┐  ┌────────────┐  │
│  │  Nginx  │→ │   App    │→ │ PostgreSQL │  │
│  │  :80    │  │  :3000   │  │   :5432    │  │
│  └─────────┘  └──────────┘  └────────────┘  │
│       ↑                                     │
│       │ Docker Compose (3 conteneurs)       │
└───────┼─────────────────────────────────────┘
        │
   Utilisateurs IPD (via VPN)
```

## Accès & sécurité

- **Authentification locale** : admin@hoshinflow.local (créé au seed)
- **SSO depuis le portail IPD** : le portail envoie un token HMAC-SHA256
  via `/api/auth/sso?token=...` qui crée automatiquement la session.
- **Variables sensibles** dans `.env` (JWT_SECRET, SSO_SECRET, POSTGRES_PASSWORD)
- **Iframe autorisée** depuis seid-pasteur.org et 10.99.1.10 (CSP configuré)

## Dépannage

### Le conteneur app redémarre en boucle
```bash
docker compose logs app --tail=50
```
Souvent une migration Prisma qui échoue → vérifier `DATABASE_URL` dans `.env`.

### PostgreSQL inaccessible
```bash
docker compose exec postgres pg_isready -U hoshinflow
docker compose logs postgres
```

### Réinitialiser complètement
```bash
docker compose down -v   # ⚠ supprime aussi la DB
docker compose up -d --build
```

### Mise à jour du code
Uploadez la nouvelle archive, puis :
```bash
tar -xzf hoshinflow-deploy.tar.gz --strip-components=0
cd hoshinflow
sudo ./scripts/install-on-server.sh --update
```
