import { PrismaClient } from "@prisma/client";
import { readFileSync } from "fs";
import { join } from "path";

// ─────────────────────────────────────────────
// Prisma client — PostgreSQL via DATABASE_URL
// ─────────────────────────────────────────────
if (!process.env.DATABASE_URL) {
  console.error("Set DATABASE_URL env var (e.g. postgresql://user:pass@host:5432/db)");
  process.exit(1);
}
console.log("Connecting to:", process.env.DATABASE_URL.replace(/:[^:@]+@/, ':***@'));
const prisma = new PrismaClient();

// ─────────────────────────────────────────────
// Static data (mirrors data.ts)
// ─────────────────────────────────────────────

const ORG = {
  id: "org-ipd-001",
  nom: "Institut Pasteur de Dakar",
  vision:
    "Devenir un pôle d'excellence en recherche biomédicale, vaccination et santé publique en Afrique d'ici 2030",
  anneeDepart: 2024,
  anneeCible: 2030,
};

const BTGS = [
  {
    id: "btg-001",
    code: "BTG1",
    nom: "Pipeline vaccinal",
    description:
      "Developper un pipeline de vaccins innovants adaptes aux besoins de sante publique africains",
  },
  {
    id: "btg-002",
    code: "BTG2",
    nom: "Autosuffisance financiere",
    description:
      "Atteindre 60% de revenus propres d'ici 2028 pour reduire la dependance aux financements exterieurs",
  },
  {
    id: "btg-003",
    code: "BTG3",
    nom: "Centre formation reference",
    description:
      "Devenir le centre de reference en Afrique de l'Ouest pour la formation en vaccinologie et biologie moleculaire",
  },
  {
    id: "btg-004",
    code: "BTG4",
    nom: "Hub regional sante",
    description:
      "Etablir un hub regional de surveillance epidemiologique et de reponse aux epidemies",
  },
  {
    id: "btg-005",
    code: "BTG5",
    nom: "Transformation digitale",
    description:
      "Digitaliser l'ensemble des processus de recherche, production et gestion d'ici 2027",
  },
];

const AXES = [
  {
    id: "axe-001",
    code: "AXE-R",
    slug: "recherche",
    nom: "Recherche",
    description:
      "Renforcer la recherche biomedicale et developper des solutions innovantes pour la sante publique africaine",
    couleur: "#06b6d4",
    ordre: 1,
  },
  {
    id: "axe-002",
    code: "AXE-V",
    slug: "revenue",
    nom: "Revenue",
    description:
      "Diversifier et accroitre les sources de revenus pour assurer la perennite financiere de l'institut",
    couleur: "#10b981",
    ordre: 2,
  },
  {
    id: "axe-003",
    code: "AXE-E",
    slug: "education-expertise",
    nom: "Education & Expertise",
    description:
      "Developper le capital humain et les competences pour maintenir l'excellence scientifique",
    couleur: "#f59e0b",
    ordre: 3,
  },
  {
    id: "axe-004",
    code: "AXE-X",
    slug: "expansion",
    nom: "Expansion",
    description:
      "Etendre le rayonnement regional et international de l'institut",
    couleur: "#ef4444",
    ordre: 4,
  },
  {
    id: "axe-005",
    code: "AXE-D",
    slug: "digital-gouvernance",
    nom: "Digital & Gouvernance",
    description:
      "Moderniser la gouvernance et accelerer la transformation digitale",
    couleur: "#8b5cf6",
    ordre: 5,
  },
];

const OBJECTIFS = [
  { id: "os-001", axeId: "axe-001", code: "OS-1", libelle: "Renforcer les capacites de recherche fondamentale et appliquee", description: "Accroitre le nombre de publications et brevets en biologie moleculaire, virologie et immunologie", poids: 15, ordre: 1 },
  { id: "os-002", axeId: "axe-001", code: "OS-2", libelle: "Developper le pipeline de vaccins et produits biomedicaux", description: "Accelerer le developpement de vaccins candidats et d'outils de diagnostic", poids: 15, ordre: 2 },
  { id: "os-003", axeId: "axe-002", code: "OS-3", libelle: "Diversifier les sources de financement", description: "Augmenter les revenus propres via la production vaccinale, les prestations et les partenariats", poids: 10, ordre: 1 },
  { id: "os-004", axeId: "axe-002", code: "OS-4", libelle: "Optimiser la performance financiere et operationnelle", description: "Ameliorer l'efficience des depenses et la gestion budgetaire", poids: 10, ordre: 2 },
  { id: "os-005", axeId: "axe-003", code: "OS-5", libelle: "Renforcer les programmes de formation et d'enseignement", description: "Developper les masters, doctorats et formations continues en sciences biomedicales", poids: 10, ordre: 1 },
  { id: "os-006", axeId: "axe-003", code: "OS-6", libelle: "Attirer et retenir les talents scientifiques", description: "Creer un environnement de travail attractif pour les chercheurs africains et internationaux", poids: 10, ordre: 2 },
  { id: "os-007", axeId: "axe-004", code: "OS-7", libelle: "Etendre les partenariats regionaux et internationaux", description: "Developper un reseau de collaborations avec les instituts de recherche africains et mondiaux", poids: 10, ordre: 1 },
  { id: "os-008", axeId: "axe-004", code: "OS-8", libelle: "Renforcer le role de sentinelle epidemiologique", description: "Etablir un centre regional de surveillance et de reponse rapide aux epidemies", poids: 10, ordre: 2 },
  { id: "os-009", axeId: "axe-005", code: "OS-9", libelle: "Digitaliser les processus cles de l'institut", description: "Mettre en place un systeme d'information integre pour la recherche, production et gestion", poids: 5, ordre: 1 },
  { id: "os-010", axeId: "axe-005", code: "OS-10", libelle: "Ameliorer la gouvernance et la gestion des risques", description: "Renforcer les mecanismes de gouvernance, conformite reglementaire et gestion qualite", poids: 5, ordre: 2 },
];

const DEPARTEMENTS = [
  { id: "dep-001", code: "CODIR", nom: "Comite de Direction", nomCourt: "CODIR", couleur: "#1e293b" },
  { id: "dep-002", code: "BMF", nom: "Biologie Moleculaire et Fonctionnelle", nomCourt: "BMF", couleur: "#0891b2" },
  { id: "dep-003", code: "DDSI", nom: "Direction des Systemes d'Information", nomCourt: "DDSI", couleur: "#7c3aed" },
  { id: "dep-004", code: "DAL", nom: "Direction des Achats et Logistique", nomCourt: "DAL", couleur: "#ea580c" },
  { id: "dep-005", code: "DCH", nom: "Direction du Capital Humain", nomCourt: "DCH", couleur: "#db2777" },
  { id: "dep-006", code: "DFC", nom: "Direction Financiere et Comptable", nomCourt: "DFC", couleur: "#059669" },
  { id: "dep-007", code: "DRO", nom: "Direction de la Recherche Operationnelle", nomCourt: "DRO", couleur: "#2563eb" },
  { id: "dep-008", code: "DPC", nom: "Direction des Partenariats et de la Communication", nomCourt: "DPC", couleur: "#16a34a" },
  { id: "dep-009", code: "DCO", nom: "Direction Commerciale", nomCourt: "DCO", couleur: "#d97706" },
  { id: "dep-010", code: "DREI", nom: "Direction des Relations Exterieures et Institutionnelles", nomCourt: "DREI", couleur: "#9333ea" },
  { id: "dep-011", code: "DSP", nom: "Direction de la Sante Publique", nomCourt: "DSP", couleur: "#0d9488" },
  { id: "dep-012", code: "DVX", nom: "Direction de la Vaccinologie Experimentale", nomCourt: "DVX", couleur: "#dc2626" },
  { id: "dep-013", code: "VRC", nom: "Centre de Recherche Vaccinale", nomCourt: "VRC", couleur: "#4f46e5" },
  { id: "dep-014", code: "DTX", nom: "Direction de la Transformation", nomCourt: "DTX", couleur: "#c026d3" },
];

// ─────────────────────────────────────────────
// Real data from Excel (kpiPct, owner, budget, statut by project ref)
// Mirrors the realDataByRef object in data.ts
// ─────────────────────────────────────────────
const realDataByRef: Record<string, { kpiPct?: number; owner?: string; budget?: string; statut?: string }> = {
  "DDSI-1. -1.01.1": { kpiPct: 1 },
  "DDSI-1. -1.02.1": { kpiPct: 1 },
  "DDSI-1. -1.03.1": { kpiPct: 0.7 },
  "DDSI-1. -1.04.1": { kpiPct: 0.8 },
  "DDSI-1. -1.05.1": { kpiPct: 0.3 },
  "DDSI-1. -1.06.1": { kpiPct: 1 },
  "DDSI-1. -1.07.1": { kpiPct: 0.6 },
  "DDSI-1. -1.08.1": { kpiPct: 0.9 },
  "DDSI-1. -1.09.1": { kpiPct: 0.5 },
  "DDSI-1. -1.10.1": { kpiPct: 1 },
  "DDSI-1. -1.11.1": { kpiPct: 1 },
  "DDSI-1. -1.12.1": { kpiPct: 0.3 },
  "DDSI-1. -1.13.1": { kpiPct: 1 },
  "DDSI-1. -1.14.1": { kpiPct: 1 },
  "DDSI-1. -1.15.1": { kpiPct: 0.9 },
  "DDSI-2. -2.01.1": { kpiPct: 1 },
  "DDSI-2. -2.02.1": { kpiPct: 0.9 },
  "DDSI-2. -2.03.1": { kpiPct: 0.9 },
  "DDSI-2. -2.04.1": { kpiPct: 0.9 },
  "DDSI-2. -2.05.1": { kpiPct: 0 },
  "DDSI-2. -2.06.1": { kpiPct: 0 },
  "DDSI-2. -2.07.1": { kpiPct: 0.5 },
  "DDSI-2. -2.08.1": { kpiPct: 0 },
  "DDSI-3. -3.01.1": { kpiPct: 0.1 },
  "DDSI-3. -3.02.1": { kpiPct: 0.3 },
  "DDSI-3. -3.03.1": { kpiPct: 0 },
  "DRO-1. -1.01.1": { kpiPct: 1, owner: "Mame Fatou NDIAYE" },
  "DRO-1. -1.02.1": { kpiPct: 1, owner: "Michel M FAYE" },
  "DRO-1. -1.03.1": { kpiPct: 1, owner: "Mame Fatou NDIAYE" },
  "DRO-1. -1.04.1": { kpiPct: 1, owner: "Mamadou DIAKITE" },
  "DRO-2. -2.01.1": { kpiPct: 0.7, owner: "Mor SY" },
  "DRO-2. -2.02.1": { kpiPct: 0.5, owner: "Mame Fatou NDIAYE" },
  "DRO-2. -2.03.1": { kpiPct: 1 },
  "DRO-2. -2.04.1": { kpiPct: 1 },
  "DRO-2. -2.05.1": { kpiPct: 0.5 },
  "DRO-2. -2.06.1": { kpiPct: 0.5 },
  "DRO-3. -3.01.1": { kpiPct: 0 },
  "DRO-3. -3.02.1": { kpiPct: 0.4 },
  "DRO-3. -3.03.1": { kpiPct: 0.3 },
  "DRO-3. -3.04.1": { kpiPct: 0.1 },
  "DRO-3. -3.05.1": { kpiPct: 0.6 },
  "DRO-3. -3.06.1": { kpiPct: 0.8 },
  "DRO-3. -3.07.1": { kpiPct: 0.7 },
  "DRO-4. -4.01.1": { kpiPct: 0.6 },
  "DRO-4. -4.02.1": { kpiPct: 0.5 },
  "DRO-4. -4.03.1": { kpiPct: 0.1 },
  "DPC-1. -1.01.1": { kpiPct: 0.2, owner: "Sokhna", statut: "Annulé", budget: "IPD" },
  "DPC-1. -1.02.1": { kpiPct: 0.4, owner: "Myriam", statut: "A reconduire" },
  "DPC-1. -1.03.1": { kpiPct: 0.4, owner: "Myriam", statut: "A reconduire", budget: "IPD" },
  "DPC-1. -1.04.1": { kpiPct: 0, owner: "Sophie", statut: "A reconduire", budget: "FCDO" },
  "DPC-1. -1.05.1": { kpiPct: 0, owner: "Sophie", statut: "A reconduire" },
  "DPC-1. -1.06.1": { kpiPct: 0, owner: "Sophie", statut: "En attente" },
  "DPC-10.-10.1.1": { owner: "Sophie", statut: "En cours", budget: "FCDO / IPD" },
  "DPC-10.-10.2.1": { statut: "A reconduire" },
  "DPC-10.-10.3.1": { kpiPct: 0.7, owner: "Sophie" },
  "DPC-11.-11.1.1": { kpiPct: 1, owner: "Sophie", statut: "Complet" },
  "DPC-11.-11.2.1": { kpiPct: 1, owner: "Sophie", statut: "Complet" },
  "DPC-11.-11.3.1": { kpiPct: 1, owner: "Sophie", statut: "Complet" },
  "DPC-11.-11.4.1": { kpiPct: 0.9, owner: "Sophie", statut: "En cours" },
  "DPC-11.-11.5.1": { kpiPct: 0.3, owner: "Sophie" },
  "DPC-2. -2.01.1": { kpiPct: 0.2, statut: "A reconduire" },
  "DPC-2. -2.02.1": { statut: "A reconduire", budget: "FCDO" },
  "DPC-2. -2.03.1": { kpiPct: 0, statut: "A reconduire" },
  "DPC-2. -2.04.1": { statut: "A reconduire", budget: "IPD" },
  "DPC-2. -2.05.1": { owner: "Sophie", statut: "A reconduire", budget: "IPD" },
  "DPC-3. -3.01.1": { statut: "A reconduire", budget: "IPD" },
  "DPC-3. -3.02.1": { statut: "A reconduire" },
  "DPC-3. -3.03.1": { statut: "A reconduire" },
  "DPC-4. -4.01.1": { owner: "Sophie", statut: "A reconduire", budget: "IPD" },
  "DPC-4. -4.02.1": { statut: "A reconduire" },
  "DPC-5. -5.01.1": { kpiPct: 0.4, owner: "Mame Bousso", statut: "En cours", budget: "IPD" },
  "DPC-5. -5.02.1": { kpiPct: 0.2, owner: "Mame Bousso", statut: "En cours", budget: "IPD" },
  "DPC-5. -5.03.1": { kpiPct: 1, owner: "Bamba Khadim", statut: "Complet", budget: "UTI-Diag" },
  "DPC-5. -5.04.1": { kpiPct: 1, owner: "Marie Vianey", statut: "Complet", budget: "IPD" },
  "DPC-5. -5.05.1": { kpiPct: 1, statut: "Complet", budget: "IPD" },
  "DPC-5. -5.06.1": { kpiPct: 1, owner: "Marie Vianey", statut: "Complet", budget: "Buffett" },
  "DPC-5. -5.07.1": { kpiPct: 1, owner: "Marie Vianey", statut: "Complet" },
  "DPC-5. -5.08.1": { kpiPct: 1, owner: "Mame Bousso", statut: "Complet" },
  "DPC-6. -6.01.1": { kpiPct: 0.8, owner: "Marie Vianey", statut: "En cours" },
  "DPC-6. -6.02.1": { kpiPct: 1, owner: "Marie Vianey", statut: "Complet", budget: "FCDO" },
  "DPC-7. -7.01.1": { kpiPct: 0.6, owner: "Marie Vianey", statut: "En cours" },
  "DPC-7. -7.02.1": { kpiPct: 0, owner: "Marie Vianey" },
  "DPC-7. -7.03.1": { kpiPct: 0.6, owner: "Myriam", statut: "A reconduire" },
  "DPC-7. -7.04.1": { kpiPct: 0.7, owner: "Marie Vianey", statut: "En cours" },
  "DPC-8. -8.01.1": { owner: "Sophie", statut: "En cours" },
  "DPC-8. -8.02.1": { owner: "Mame Bousso", statut: "En cours" },
  "DPC-8. -8.03.1": { owner: "Marie Vianey", statut: "En cours" },
  "DVX-1 E-1.01.1": { kpiPct: 1 },
  "DVX-1 E-1.02.1": { kpiPct: 0.5 },
  "DVX-1 E-1.03.1": { kpiPct: 0 },
  "DVX-1 E-1.04.1": { kpiPct: 0 },
  "DVX-1 E-1.05.1": { kpiPct: 0 },
  "DVX-1 E-1.06.1": { kpiPct: 1 },
  "DVX-1 E-1.07.1": { kpiPct: 0.1 },
  "DVX-1 E-1.08.1": { kpiPct: 0.5 },
  "DVX-2. -2.01.1": { kpiPct: 1 },
  "DVX-2. -2.02.1": { kpiPct: 0.1 },
  "DVX-2. -2.03.1": { kpiPct: 0.9 },
  "DVX-2. -2.04.1": { kpiPct: 0.5 },
  "DVX-2. -2.05.1": { kpiPct: 0 },
  "DVX-2. -2.06.1": { kpiPct: 0 },
  "DVX-3. -3.01.1": { kpiPct: 0.3 },
  "DVX-3. -3.02.1": { kpiPct: 0.1 },
  "DVX-3. -3.03.1": { kpiPct: 1 },
  "DVX-3. -3.04.1": { kpiPct: 1 },
};

// ─────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────

function mapStatut(statut: string): string {
  if (statut === "Non démarré" || statut === "Non demarre") return "NON_DEMARRE";
  if (statut === "En cours") return "EN_COURS";
  if (statut === "En retard") return "EN_RETARD";
  if (statut === "En attente") return "EN_ATTENTE";
  if (statut === "Complet" || statut === "Terminé") return "COMPLET";
  if (statut === "Annulé") return "ANNULE";
  if (statut === "A reconduire") return "A_RECONDUIRE";
  return "NON_DEMARRE";
}

function pad(n: number, width: number): string {
  return String(n).padStart(width, "0");
}

// ─────────────────────────────────────────────
// Load JSON data extracted from Excel
// ─────────────────────────────────────────────

interface ProjetDef {
  ref: string;
  libelle: string;
  owner: string;
  statut: string;
  kpis: string[];
  btgs: number[];
  financeur: string;
  contributors: string[];
}

interface StrategyDef {
  ref: string;
  projets: ProjetDef[];
}

interface DeptDef {
  code: string;
  strategies: StrategyDef[];
}

interface HoshinData {
  departments: DeptDef[];
}

// ─────────────────────────────────────────────
// Main seed function
// ─────────────────────────────────────────────

async function main() {
  console.log("Loading hoshin data from /tmp/hoshin-data.json ...");
  const hoshinRaw = readFileSync("/tmp/hoshin-data.json", "utf-8");
  const hoshinData: HoshinData = JSON.parse(hoshinRaw);

  // Build a map from department code to its definition list
  const deptDataMap = new Map<string, StrategyDef[]>();
  for (const dept of hoshinData.departments) {
    deptDataMap.set(dept.code, dept.strategies);
  }

  // Build a map from department code to its ID
  const depCodeToId = new Map<string, string>();
  for (const d of DEPARTEMENTS) {
    depCodeToId.set(d.code, d.id);
  }

  // ─── Delete all existing data (reverse dependency order) ───
  console.log("Clearing existing data ...");
  await prisma.auditLog.deleteMany();
  await prisma.mesureKPI.deleteMany();
  await prisma.projetBTG.deleteMany();
  await prisma.projetContributeur.deleteMany();
  await prisma.kPI.deleteMany();
  await prisma.projet.deleteMany();
  await prisma.strategieDepartementale.deleteMany();
  await prisma.matriceContributeurs.deleteMany();
  await prisma.objectifStrategique.deleteMany();
  await prisma.axeStrategique.deleteMany();
  await prisma.breakthroughGoal.deleteMany();
  await prisma.user.deleteMany();
  await prisma.departement.deleteMany();
  await prisma.organisation.deleteMany();

  // ─── 1. Organisation ───
  console.log("Creating Organisation ...");
  await prisma.organisation.create({
    data: {
      id: ORG.id,
      nom: ORG.nom,
      vision: ORG.vision,
      anneeDepart: ORG.anneeDepart,
      anneeCible: ORG.anneeCible,
    },
  });

  // ─── 2. Breakthrough Goals ───
  console.log("Creating BTGs ...");
  for (const btg of BTGS) {
    await prisma.breakthroughGoal.create({
      data: {
        id: btg.id,
        organisationId: ORG.id,
        code: btg.code,
        nom: btg.nom,
        description: btg.description,
      },
    });
  }

  // ─── 3. Axes Strategiques ───
  console.log("Creating Axes ...");
  for (const axe of AXES) {
    await prisma.axeStrategique.create({
      data: {
        id: axe.id,
        organisationId: ORG.id,
        code: axe.code,
        slug: axe.slug,
        nom: axe.nom,
        description: axe.description,
        couleur: axe.couleur,
        ordre: axe.ordre,
      },
    });
  }

  // ─── 4. Objectifs Strategiques ───
  console.log("Creating Objectifs ...");
  for (const os of OBJECTIFS) {
    await prisma.objectifStrategique.create({
      data: {
        id: os.id,
        axeId: os.axeId,
        code: os.code,
        libelle: os.libelle,
        description: os.description,
        poids: os.poids,
        ordre: os.ordre,
      },
    });
  }

  // ─── 5. Departements ───
  console.log("Creating Departements ...");
  for (const dep of DEPARTEMENTS) {
    await prisma.departement.create({
      data: {
        id: dep.id,
        organisationId: ORG.id,
        code: dep.code,
        nom: dep.nom,
        nomCourt: dep.nomCourt,
        couleur: dep.couleur,
      },
    });
  }

  // ─── 6. Default admin user ───
  console.log("Creating admin user ...");
  await prisma.user.create({
    data: {
      id: "user-admin-001",
      email: "admin@hoshinflow.local",
      nom: "Administrateur",
      role: "ADMIN",
      actif: true,
    },
  });

  // ─── 7. Strategies, Projects, KPIs, Mesures, BTG links, Contributors ───
  console.log("Creating strategies, projects, KPIs ...");

  let globalStrategieCounter = 0;
  let globalProjetCounter = 0;
  let globalKpiCounter = 0;
  let globalMesureCounter = 0;
  let globalContributeurCounter = 0;
  let globalProjetBtgCounter = 0;

  // Global strategy counter drives OS round-robin assignment
  let globalOsIndex = 0;

  // Process departments in the same order as data.ts (DEPARTEMENTS array order)
  for (const dep of DEPARTEMENTS) {
    const strategies = deptDataMap.get(dep.code);
    if (!strategies || strategies.length === 0) continue;

    for (const stratDef of strategies) {
      globalStrategieCounter++;
      const strategieId = `str-${pad(globalStrategieCounter, 3)}`;

      // Round-robin OS assignment (global counter)
      const osId = OBJECTIFS[globalOsIndex % 10].id;
      globalOsIndex++;

      // Create the strategy
      await prisma.strategieDepartementale.create({
        data: {
          id: strategieId,
          objectifStrategiqueId: osId,
          departementId: dep.id,
          code: `S-${dep.code}-${pad(globalStrategieCounter, 2)}`,
          libelle: stratDef.ref, // strategy ref from Excel is the libelle
          responsable: null,
          statut: "NON_DEMARRE",
        },
      });

      // Create projects for this strategy
      for (const pDef of stratDef.projets) {
        globalProjetCounter++;
        const projetId = `prj-${pad(globalProjetCounter, 4)}`;

        // Look up real data by ref
        const realData = pDef.ref ? realDataByRef[pDef.ref] : undefined;

        // Map statut
        const statut: string = pDef.statut
          ? mapStatut(pDef.statut)
          : realData?.statut
            ? mapStatut(realData.statut)
            : "NON_DEMARRE";

        // Owner: prefer realData owner, then hoshin-data owner
        const responsable = realData?.owner || pDef.owner || null;

        // Financeur: realData budget field, then hoshin-data financeur
        const financeur = realData?.budget || pDef.financeur || null;

        await prisma.projet.create({
          data: {
            id: projetId,
            strategieId,
            code: `P-${pad(globalProjetCounter, 3)}`,
            libelle: pDef.libelle,
            responsable,
            statut,
            financeur,
            budgetAlloue: null,
            budgetDepense: null,
            devise: "FCFA",
            commentaire: null,
          },
        });

        // KPIs for this project
        for (let ki = 0; ki < pDef.kpis.length; ki++) {
          globalKpiCounter++;
          const kpiId = `kpi-${pad(globalKpiCounter, 4)}`;
          const kpiLabel = pDef.kpis[ki];

          const isPercent =
            kpiLabel.toLowerCase().includes("%") ||
            kpiLabel.toLowerCase().includes("taux") ||
            kpiLabel.toLowerCase().includes("pourcentage");
          const isBool =
            kpiLabel.toUpperCase() === "Y/N" ||
            kpiLabel.toLowerCase().includes("y/n");

          await prisma.kPI.create({
            data: {
              id: kpiId,
              projetId,
              code: `KPI-${pad(globalKpiCounter, 3)}`,
              libelle: kpiLabel,
              modeCalcul: isPercent ? "POURCENTAGE" : isBool ? "BOOLEEN" : "SOMME",
              unite: isPercent ? "%" : isBool ? "O/N" : "unite",
              valeurReference: null,
              ordre: ki + 1,
            },
          });

          // MesureKPI: T1-T4 for each KPI
          const kpiPct = realData?.kpiPct;
          const hasValidKpiPct =
            kpiPct !== undefined && kpiPct !== null && kpiPct >= 0 && kpiPct <= 1;

          const trimestres = ["T1", "T2", "T3", "T4"] as const;
          for (const tri of trimestres) {
            globalMesureCounter++;
            const isT1 = tri === "T1";
            await prisma.mesureKPI.create({
              data: {
                id: `mes-${pad(globalMesureCounter, 4)}`,
                kpiId,
                annee: 2025,
                trimestre: tri,
                cible: isT1 && hasValidKpiPct ? 100 : null,
                realise: isT1 && hasValidKpiPct ? Math.round(kpiPct! * 100) : null,
                tauxCompletion: isT1 && hasValidKpiPct ? Math.round(kpiPct! * 100) : null,
                commentaire: null,
              },
            });
          }
        }

        // ProjetBTG linkages
        for (const btgNum of pDef.btgs) {
          globalProjetBtgCounter++;
          await prisma.projetBTG.create({
            data: {
              id: `pbtg-${pad(globalProjetBtgCounter, 4)}`,
              projetId,
              btgId: `btg-${pad(btgNum, 3)}`,
              indicateurBinaire: false,
            },
          });
        }

        // ProjetContributeur
        for (let ci = 0; ci < pDef.contributors.length; ci++) {
          globalContributeurCounter++;
          const contribName = pDef.contributors[ci];
          // Check if contributor name matches a department code
          const contribDep = DEPARTEMENTS.find((d) => d.code === contribName);
          await prisma.projetContributeur.create({
            data: {
              id: `contrib-${pad(globalContributeurCounter, 4)}`,
              projetId,
              departementId: contribDep ? contribDep.id : dep.id,
              nom: contribName,
              rang: ci + 1,
            },
          });
        }
      }
    }
  }

  // ─── Summary ───
  const counts = {
    organisations: await prisma.organisation.count(),
    btgs: await prisma.breakthroughGoal.count(),
    axes: await prisma.axeStrategique.count(),
    objectifs: await prisma.objectifStrategique.count(),
    departements: await prisma.departement.count(),
    users: await prisma.user.count(),
    strategies: await prisma.strategieDepartementale.count(),
    projets: await prisma.projet.count(),
    kpis: await prisma.kPI.count(),
    mesures: await prisma.mesureKPI.count(),
    projetBtgs: await prisma.projetBTG.count(),
    contributeurs: await prisma.projetContributeur.count(),
  };

  console.log("\nSeed completed successfully!");
  console.log("Record counts:", JSON.stringify(counts, null, 2));
}

main()
  .catch((e) => {
    console.error("Seed failed:", e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
