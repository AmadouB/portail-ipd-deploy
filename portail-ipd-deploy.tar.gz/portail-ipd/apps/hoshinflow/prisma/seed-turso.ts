import { createClient } from "@libsql/client";
import Database from "better-sqlite3";

const TURSO_DATABASE_URL = process.env.TURSO_DATABASE_URL;
const TURSO_AUTH_TOKEN = process.env.TURSO_AUTH_TOKEN;

if (!TURSO_DATABASE_URL || !TURSO_AUTH_TOKEN) {
  console.error("Missing TURSO_DATABASE_URL or TURSO_AUTH_TOKEN environment variables");
  process.exit(1);
}

const turso = createClient({
  url: TURSO_DATABASE_URL,
  authToken: TURSO_AUTH_TOKEN,
});

const localDb = new Database("prisma/dev.db");

// Tables in reverse dependency order for deletion
const tablesReverse = [
  "MatriceContributeurs",
  "ProjetBTG",
  "ProjetContributeur",
  "MesureKPI",
  "KPI",
  "Projet",
  "StrategieDepartementale",
  "ObjectifStrategique",
  "User",
  "Departement",
  "BreakthroughGoal",
  "AxeStrategique",
  "Organisation",
];

// Tables in dependency order for insertion
const tables = [...tablesReverse].reverse();

// Column definitions for each table
const tableColumns: Record<string, string[]> = {
  Organisation: ["id", "nom", "vision", "anneeDepart", "anneeCible", "createdAt", "updatedAt"],
  AxeStrategique: ["id", "organisationId", "code", "slug", "nom", "description", "couleur", "ordre"],
  BreakthroughGoal: ["id", "organisationId", "code", "nom", "description"],
  Departement: ["id", "organisationId", "code", "nom", "nomCourt", "couleur", "directeur"],
  User: ["id", "email", "nom", "prenom", "role", "departementId", "actif", "createdAt", "updatedAt"],
  ObjectifStrategique: ["id", "axeId", "code", "libelle", "description", "poids", "ordre"],
  StrategieDepartementale: ["id", "objectifStrategiqueId", "departementId", "code", "libelle", "responsable", "statut", "createdAt", "updatedAt"],
  Projet: ["id", "strategieId", "code", "libelle", "responsable", "statut", "financeur", "budgetAlloue", "budgetDepense", "devise", "commentaire", "createdAt", "updatedAt"],
  KPI: ["id", "projetId", "code", "libelle", "modeCalcul", "unite", "valeurReference", "ordre", "createdAt", "updatedAt"],
  MesureKPI: ["id", "kpiId", "annee", "trimestre", "cible", "realise", "tauxCompletion", "commentaire", "createdAt", "updatedAt"],
  ProjetContributeur: ["id", "projetId", "departementId", "nom", "rang"],
  ProjetBTG: ["id", "projetId", "btgId", "indicateurBinaire"],
  MatriceContributeurs: ["id", "objectifStrategiqueId", "departementId", "roleContribution"],
};

async function main() {
  console.log("=== Turso Seed Script ===\n");

  // Step 1: Clear existing data in reverse dependency order
  console.log("--- Clearing existing data ---");
  for (const table of tablesReverse) {
    try {
      await turso.execute(`DELETE FROM ${table}`);
      console.log(`  Cleared: ${table}`);
    } catch (err: any) {
      console.warn(`  Warning clearing ${table}: ${err.message}`);
    }
  }
  console.log("");

  // Step 2: Insert data in dependency order
  console.log("--- Inserting data ---");
  for (const table of tables) {
    const columns = tableColumns[table];
    const rows = localDb.prepare(`SELECT * FROM ${table}`).all() as Record<string, any>[];

    if (rows.length === 0) {
      console.log(`  ${table}: 0 rows (skipped)`);
      continue;
    }

    const placeholders = columns.map(() => "?").join(", ");
    const columnList = columns.join(", ");
    const sql = `INSERT INTO ${table} (${columnList}) VALUES (${placeholders})`;

    // Build batch of statements
    const statements = rows.map((row) => ({
      sql,
      args: columns.map((col) => {
        const val = row[col];
        // Convert booleans (stored as 0/1 in SQLite) - keep as-is since Turso also uses SQLite
        if (val === undefined) return null;
        return val;
      }),
    }));

    try {
      // Batch in chunks of 100 to avoid overly large batches
      const chunkSize = 100;
      for (let i = 0; i < statements.length; i += chunkSize) {
        const chunk = statements.slice(i, i + chunkSize);
        await turso.batch(chunk, "write");
      }
      console.log(`  ${table}: ${rows.length} rows inserted`);
    } catch (err: any) {
      console.error(`  ERROR inserting into ${table}: ${err.message}`);
      // Log the first failing row for debugging
      if (rows.length > 0) {
        console.error(`    Sample row keys: ${Object.keys(rows[0]).join(", ")}`);
      }
    }
  }

  console.log("\n=== Seed complete ===");
  localDb.close();
  turso.close();
}

main().catch((err) => {
  console.error("Fatal error:", err);
  localDb.close();
  turso.close();
  process.exit(1);
});
