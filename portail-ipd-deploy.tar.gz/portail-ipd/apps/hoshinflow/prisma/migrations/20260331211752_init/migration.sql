-- CreateTable
CREATE TABLE "User" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "email" TEXT NOT NULL,
    "nom" TEXT NOT NULL,
    "prenom" TEXT,
    "role" TEXT NOT NULL DEFAULT 'LECTEUR',
    "departementId" TEXT,
    "actif" BOOLEAN NOT NULL DEFAULT true,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "User_departementId_fkey" FOREIGN KEY ("departementId") REFERENCES "Departement" ("id") ON DELETE SET NULL ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "AuditLog" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "userId" TEXT,
    "action" TEXT NOT NULL,
    "entityType" TEXT NOT NULL,
    "entityId" TEXT NOT NULL,
    "oldValue" TEXT,
    "newValue" TEXT,
    "description" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "AuditLog_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User" ("id") ON DELETE SET NULL ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "Organisation" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "nom" TEXT NOT NULL,
    "vision" TEXT,
    "anneeDepart" INTEGER NOT NULL DEFAULT 2025,
    "anneeCible" INTEGER NOT NULL DEFAULT 2026,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL
);

-- CreateTable
CREATE TABLE "AxeStrategique" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "organisationId" TEXT NOT NULL,
    "code" TEXT NOT NULL,
    "slug" TEXT NOT NULL,
    "nom" TEXT NOT NULL,
    "description" TEXT,
    "couleur" TEXT NOT NULL DEFAULT '#06b6d4',
    "ordre" INTEGER NOT NULL DEFAULT 0,
    CONSTRAINT "AxeStrategique_organisationId_fkey" FOREIGN KEY ("organisationId") REFERENCES "Organisation" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "BreakthroughGoal" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "organisationId" TEXT NOT NULL,
    "code" TEXT NOT NULL,
    "nom" TEXT NOT NULL,
    "description" TEXT,
    CONSTRAINT "BreakthroughGoal_organisationId_fkey" FOREIGN KEY ("organisationId") REFERENCES "Organisation" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "Departement" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "organisationId" TEXT NOT NULL,
    "code" TEXT NOT NULL,
    "nom" TEXT NOT NULL,
    "nomCourt" TEXT,
    "couleur" TEXT NOT NULL DEFAULT '#06b6d4',
    "directeur" TEXT,
    CONSTRAINT "Departement_organisationId_fkey" FOREIGN KEY ("organisationId") REFERENCES "Organisation" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "ObjectifStrategique" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "axeId" TEXT NOT NULL,
    "code" TEXT NOT NULL,
    "libelle" TEXT NOT NULL,
    "description" TEXT,
    "poids" REAL NOT NULL DEFAULT 1.0,
    "ordre" INTEGER NOT NULL DEFAULT 0,
    CONSTRAINT "ObjectifStrategique_axeId_fkey" FOREIGN KEY ("axeId") REFERENCES "AxeStrategique" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "StrategieDepartementale" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "objectifStrategiqueId" TEXT NOT NULL,
    "departementId" TEXT NOT NULL,
    "code" TEXT NOT NULL,
    "libelle" TEXT NOT NULL,
    "responsable" TEXT,
    "statut" TEXT NOT NULL DEFAULT 'NON_DEMARRE',
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "StrategieDepartementale_objectifStrategiqueId_fkey" FOREIGN KEY ("objectifStrategiqueId") REFERENCES "ObjectifStrategique" ("id") ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT "StrategieDepartementale_departementId_fkey" FOREIGN KEY ("departementId") REFERENCES "Departement" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "Projet" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "strategieId" TEXT NOT NULL,
    "code" TEXT NOT NULL,
    "libelle" TEXT NOT NULL,
    "responsable" TEXT,
    "statut" TEXT NOT NULL DEFAULT 'NON_DEMARRE',
    "financeur" TEXT,
    "budgetAlloue" REAL,
    "budgetDepense" REAL,
    "devise" TEXT NOT NULL DEFAULT 'FCFA',
    "commentaire" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "Projet_strategieId_fkey" FOREIGN KEY ("strategieId") REFERENCES "StrategieDepartementale" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "KPI" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "projetId" TEXT NOT NULL,
    "code" TEXT NOT NULL,
    "libelle" TEXT NOT NULL,
    "modeCalcul" TEXT NOT NULL DEFAULT 'SOMME',
    "unite" TEXT,
    "valeurReference" TEXT,
    "ordre" INTEGER NOT NULL DEFAULT 1,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "KPI_projetId_fkey" FOREIGN KEY ("projetId") REFERENCES "Projet" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "MesureKPI" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "kpiId" TEXT NOT NULL,
    "annee" INTEGER NOT NULL DEFAULT 2025,
    "trimestre" TEXT NOT NULL,
    "cible" REAL,
    "realise" REAL,
    "tauxCompletion" REAL,
    "commentaire" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "MesureKPI_kpiId_fkey" FOREIGN KEY ("kpiId") REFERENCES "KPI" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "ProjetContributeur" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "projetId" TEXT NOT NULL,
    "departementId" TEXT NOT NULL,
    "nom" TEXT NOT NULL,
    "rang" INTEGER NOT NULL DEFAULT 1,
    CONSTRAINT "ProjetContributeur_projetId_fkey" FOREIGN KEY ("projetId") REFERENCES "Projet" ("id") ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT "ProjetContributeur_departementId_fkey" FOREIGN KEY ("departementId") REFERENCES "Departement" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "ProjetBTG" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "projetId" TEXT NOT NULL,
    "btgId" TEXT NOT NULL,
    "indicateurBinaire" BOOLEAN NOT NULL DEFAULT false,
    CONSTRAINT "ProjetBTG_projetId_fkey" FOREIGN KEY ("projetId") REFERENCES "Projet" ("id") ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT "ProjetBTG_btgId_fkey" FOREIGN KEY ("btgId") REFERENCES "BreakthroughGoal" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "MatriceContributeurs" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "objectifStrategiqueId" TEXT NOT NULL,
    "departementId" TEXT NOT NULL,
    "roleContribution" TEXT NOT NULL DEFAULT 'CONTRIBUTEUR',
    CONSTRAINT "MatriceContributeurs_objectifStrategiqueId_fkey" FOREIGN KEY ("objectifStrategiqueId") REFERENCES "ObjectifStrategique" ("id") ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT "MatriceContributeurs_departementId_fkey" FOREIGN KEY ("departementId") REFERENCES "Departement" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);

-- CreateIndex
CREATE UNIQUE INDEX "User_email_key" ON "User"("email");

-- CreateIndex
CREATE UNIQUE INDEX "Departement_code_key" ON "Departement"("code");
