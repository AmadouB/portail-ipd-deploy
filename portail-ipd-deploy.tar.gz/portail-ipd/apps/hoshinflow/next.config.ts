import type { NextConfig } from "next";

// Allow basePath to be overridden via env (used in multi-app portail).
// Default to "/hoshinflow" so the app behaves the same locally and in prod.
const basePath = process.env.NEXT_BASE_PATH ?? "/hoshinflow";

const nextConfig: NextConfig = {
  output: "standalone",
  basePath: basePath || undefined,
  images: {
    unoptimized: true,
  },
  async headers() {
    return [
      {
        source: "/:path*",
        headers: [
          { key: "X-Frame-Options", value: "SAMEORIGIN" },
        ],
      },
    ];
  },
};

export default nextConfig;
