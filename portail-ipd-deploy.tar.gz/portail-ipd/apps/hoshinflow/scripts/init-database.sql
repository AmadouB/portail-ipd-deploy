-- ══════════════════════════════════════════════════════════
-- HoshinFlow — Initialisation PostgreSQL
-- Serveur: 10.99.1.10
--
-- Étape 1 — En tant que superuser postgres:
--   sudo -u postgres psql < scripts/init-database.sql
--
-- Étape 2 — Appliquer le schéma Prisma:
--   npx prisma migrate deploy
--   OU
--   npx prisma db push
--
-- Étape 3 — Charger les données:
--   npx tsx prisma/seed.ts
-- ══════════════════════════════════════════════════════════

-- Créer l'utilisateur applicatif
DO $$
BEGIN
  IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = 'hoshinflow') THEN
    CREATE ROLE hoshinflow WITH LOGIN PASSWORD 'hoshinflow_pwd_2026';
  END IF;
END
$$;

-- Créer la base de données
SELECT 'CREATE DATABASE hoshinflow OWNER hoshinflow'
WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = 'hoshinflow');
\gexec

-- Accorder les droits
GRANT ALL PRIVILEGES ON DATABASE hoshinflow TO hoshinflow;

-- Se connecter à la base hoshinflow
\c hoshinflow

-- Droits sur le schéma public
GRANT ALL ON SCHEMA public TO hoshinflow;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO hoshinflow;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON SEQUENCES TO hoshinflow;

-- Extensions utiles
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ══════════════════════════════════════════════════════════
-- Les tables seront créées par Prisma (npx prisma db push)
-- Ceci crée uniquement la base et l'utilisateur
-- ══════════════════════════════════════════════════════════
