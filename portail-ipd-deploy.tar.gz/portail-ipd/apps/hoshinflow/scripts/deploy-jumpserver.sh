#!/bin/bash
set -e

# ══════════════════════════════════════════════════════════
# HoshinFlow — Déploiement sur JumpServer IPD
# Serveur: 10.99.1.10 (accès VPN requis)
# User: amadou.bao
# Stack: Next.js 16 + PostgreSQL 16 + Nginx (Docker Compose)
#
# Usage (depuis votre Mac, connecté au VPN):
#   ./scripts/deploy-jumpserver.sh                 Déploiement complet
#   ./scripts/deploy-jumpserver.sh --init          1er déploiement (installe Docker)
#   ./scripts/deploy-jumpserver.sh --update        Mise à jour rapide
#   ./scripts/deploy-jumpserver.sh --seed          Charge les données IPD
#   ./scripts/deploy-jumpserver.sh --status        Vérifie l'état
#   ./scripts/deploy-jumpserver.sh --logs          Affiche les logs
#   ./scripts/deploy-jumpserver.sh --ssh           Session SSH directe
# ══════════════════════════════════════════════════════════

# ─── Configuration ─────────────────────────────
JUMP_HOST="10.99.1.10"
JUMP_USER="bao"
JUMP_DIR="/home/bao/hoshinflow"
PROJECT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
SSH_OPTS="-o ConnectTimeout=10 -o StrictHostKeyChecking=no"
SSH_CMD="ssh ${SSH_OPTS} ${JUMP_USER}@${JUMP_HOST}"
SCP_CMD="scp ${SSH_OPTS}"

# Colors
RED='\033[0;31m'; GREEN='\033[0;32m'; CYAN='\033[0;36m'; YELLOW='\033[1;33m'; NC='\033[0m'

info()  { echo -e "${CYAN}[INFO]${NC} $1"; }
ok()    { echo -e "${GREEN}  ✓${NC} $1"; }
warn()  { echo -e "${YELLOW}[WARN]${NC} $1"; }
err()   { echo -e "${RED}[ERREUR]${NC} $1"; exit 1; }

# ─── Vérification VPN ──────────────────────────
check_vpn() {
  info "Vérification de la connectivité VPN..."
  if ! ping -c 1 -W 3 ${JUMP_HOST} &>/dev/null; then
    err "Impossible de joindre ${JUMP_HOST}. Vérifiez votre connexion VPN."
  fi
  ok "JumpServer accessible via VPN"
}

# ─── Upload du projet ──────────────────────────
upload_project() {
  info "Synchronisation des fichiers vers ${JUMP_HOST}:${JUMP_DIR}..."

  ${SSH_CMD} "mkdir -p ${JUMP_DIR}"

  rsync -avz --progress \
    --exclude 'node_modules' \
    --exclude '.next' \
    --exclude '.git' \
    --exclude 'dev.db' \
    --exclude 'prisma/dev.db' \
    --exclude '.env' \
    --exclude '.vercel' \
    -e "ssh ${SSH_OPTS}" \
    "${PROJECT_DIR}/" \
    "${JUMP_USER}@${JUMP_HOST}:${JUMP_DIR}/"

  # Upload .env.production comme .env sur le serveur
  ${SCP_CMD} "${PROJECT_DIR}/.env.production" "${JUMP_USER}@${JUMP_HOST}:${JUMP_DIR}/.env"

  ok "Fichiers synchronisés"
}

# ─── Premier déploiement ───────────────────────
init_server() {
  info "═══ Initialisation du JumpServer ═══"
  check_vpn

  ${SSH_CMD} bash -s << 'INIT_EOF'
set -e

echo "=== Installation des pré-requis ==="

# Docker
if ! command -v docker &>/dev/null; then
  echo "[INFO] Installation de Docker..."
  curl -fsSL https://get.docker.com | sudo sh
  sudo usermod -aG docker $USER
  sudo systemctl enable docker
  sudo systemctl start docker
  echo "[OK] Docker installé"
else
  echo "[OK] Docker déjà installé: $(docker --version)"
fi

# Docker Compose plugin
if ! docker compose version &>/dev/null; then
  echo "[INFO] Installation de Docker Compose plugin..."
  sudo apt-get update -qq
  sudo apt-get install -y -qq docker-compose-plugin 2>/dev/null || {
    # Fallback: install manually
    COMPOSE_VERSION=$(curl -sL https://api.github.com/repos/docker/compose/releases/latest | grep tag_name | cut -d'"' -f4)
    sudo curl -L "https://github.com/docker/compose/releases/download/${COMPOSE_VERSION}/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
    sudo chmod +x /usr/local/bin/docker-compose
  }
  echo "[OK] Docker Compose installé"
else
  echo "[OK] Docker Compose: $(docker compose version)"
fi

# Firewall
if command -v ufw &>/dev/null; then
  sudo ufw allow 80/tcp 2>/dev/null || true
  echo "[OK] Port 80 ouvert"
fi

echo ""
echo "═══════════════════════════════════════"
echo "  Serveur prêt pour le déploiement"
echo "  Relancez sans --init"
echo "═══════════════════════════════════════"
INIT_EOF

  ok "Serveur initialisé"
  warn "Si Docker vient d'être installé, vous devrez peut-être vous reconnecter pour que le groupe docker soit actif."
}

# ─── Déploiement Docker Compose ────────────────
deploy() {
  info "═══ Déploiement HoshinFlow sur ${JUMP_HOST} ═══"

  check_vpn
  upload_project

  info "Build et démarrage des conteneurs..."
  ${SSH_CMD} bash -s << DEPLOY_EOF
set -e
cd ${JUMP_DIR}

echo ""
echo "=== Build de l'image Docker ==="
docker compose build --no-cache

echo ""
echo "=== Démarrage des services ==="
docker compose down 2>/dev/null || true
docker compose up -d

echo ""
echo "=== Attente du démarrage (30s)... ==="
sleep 30

echo ""
echo "=== État des services ==="
docker compose ps

echo ""
echo "=== Application des migrations ==="
docker compose exec -T app sh -c "npx prisma migrate deploy" 2>&1 || echo "[INFO] Migrations en attente"

echo ""
if curl -sf http://localhost/login > /dev/null 2>&1; then
  echo ""
  echo "═══════════════════════════════════════════"
  echo "  ✓ HoshinFlow déployé avec succès !"
  echo ""
  echo "  URL interne (VPN) : http://10.99.1.10"
  echo "═══════════════════════════════════════════"
else
  echo "[WARN] Le serveur n'est pas encore prêt."
  echo "Vérifiez: docker compose logs -f"
fi
DEPLOY_EOF

  echo ""
  ok "Déploiement terminé !"
  echo ""
  echo -e "  ${CYAN}URL (VPN):${NC} http://${JUMP_HOST}"
  echo -e "  ${CYAN}Login:${NC}    admin@hoshinflow.local"
  echo ""
}

# ─── Mise à jour rapide ───────────────────────
update() {
  info "═══ Mise à jour de HoshinFlow ═══"
  check_vpn
  upload_project

  info "Rebuild et redéploiement..."
  ${SSH_CMD} bash -s << UPDATE_EOF
set -e
cd ${JUMP_DIR}
docker compose build
docker compose up -d
sleep 15
docker compose exec -T app sh -c "npx prisma migrate deploy" 2>/dev/null || true
docker compose ps
echo ""
if curl -sf http://localhost/login > /dev/null 2>&1; then
  echo "✓ Mise à jour réussie — http://10.99.1.10"
else
  echo "[WARN] Vérifiez: docker compose logs -f"
fi
UPDATE_EOF

  ok "Mise à jour terminée"
}

# ─── Seed des données ─────────────────────────
seed_data() {
  info "Chargement des données IPD..."
  check_vpn

  if [ -f /tmp/hoshin-data.json ]; then
    ${SCP_CMD} /tmp/hoshin-data.json "${JUMP_USER}@${JUMP_HOST}:/tmp/hoshin-data.json"
    ok "hoshin-data.json uploadé"
  fi

  ${SSH_CMD} bash -s << SEED_EOF
set -e
cd ${JUMP_DIR}
docker compose exec -T app sh -c "npx tsx prisma/seed.ts"
echo "✓ Données chargées avec succès"
SEED_EOF

  ok "Seed terminé"
}

# ─── Status ───────────────────────────────────
status() {
  check_vpn
  info "État des services sur ${JUMP_HOST}..."
  ${SSH_CMD} bash -s << 'STATUS_EOF'
cd /home/bao/hoshinflow 2>/dev/null || cd ~/hoshinflow 2>/dev/null || true

echo "=== Docker ==="
docker compose ps 2>/dev/null || echo "Non démarré"

echo ""
echo "=== Espace disque ==="
df -h / | tail -1

echo ""
echo "=== Mémoire ==="
free -h 2>/dev/null || echo "N/A"

echo ""
echo "=== Base de données ==="
docker compose exec -T postgres psql -U hoshinflow -c "SELECT count(*) AS users FROM \"User\";" 2>/dev/null || echo "DB non accessible"

echo ""
echo "=== Test HTTP ==="
if curl -sf http://localhost/login > /dev/null 2>&1; then
  echo "✓ Application accessible sur http://10.99.1.10"
else
  echo "✗ Application non accessible"
fi
STATUS_EOF
}

# ─── Logs ─────────────────────────────────────
show_logs() {
  check_vpn
  ${SSH_CMD} "cd ${JUMP_DIR} && docker compose logs -f --tail=100"
}

# ─── SSH direct ───────────────────────────────
open_ssh() {
  check_vpn
  info "Connexion SSH à ${JUMP_HOST}..."
  exec ${SSH_CMD}
}

# ─── Main ─────────────────────────────────────
echo ""
echo -e "${CYAN}╔══════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║  HoshinFlow — Déploiement JumpServer    ║${NC}"
echo -e "${CYAN}║  Serveur: ${JUMP_HOST} (VPN)             ║${NC}"
echo -e "${CYAN}║  User: ${JUMP_USER}                 ║${NC}"
echo -e "${CYAN}╚══════════════════════════════════════════╝${NC}"
echo ""

case "${1:-}" in
  --init)     init_server ;;
  --update)   update ;;
  --seed)     seed_data ;;
  --status)   status ;;
  --logs)     show_logs ;;
  --ssh)      open_ssh ;;
  --help|-h)
    echo "Usage: $0 [option]"
    echo ""
    echo "Options:"
    echo "  (sans option)  Déploiement complet (Docker Compose)"
    echo "  --init         1er déploiement (installe Docker)"
    echo "  --update       Mise à jour rapide (rebuild + restart)"
    echo "  --seed         Charge les données IPD"
    echo "  --status       État des services"
    echo "  --logs         Logs en temps réel"
    echo "  --ssh          Session SSH directe"
    echo ""
    ;;
  *)          deploy ;;
esac
