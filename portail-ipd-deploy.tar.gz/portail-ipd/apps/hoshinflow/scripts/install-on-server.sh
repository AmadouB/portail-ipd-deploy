#!/bin/bash
set -e

# ══════════════════════════════════════════════════════════
# HoshinFlow — Installation sur serveur cible (SRV-Delivery_unit)
# ══════════════════════════════════════════════════════════
# À exécuter DIRECTEMENT sur le serveur cible (10.1.7.249 ou autre),
# après extraction de l'archive hoshinflow-deploy.tar.gz
#
# Usage :
#   tar -xzf hoshinflow-deploy.tar.gz
#   cd hoshinflow
#   sudo ./scripts/install-on-server.sh           # Installation complète
#   sudo ./scripts/install-on-server.sh --update  # Mise à jour (rebuild)
#   sudo ./scripts/install-on-server.sh --seed    # Charger les données IPD
#   sudo ./scripts/install-on-server.sh --status  # État des services
#   sudo ./scripts/install-on-server.sh --logs    # Logs temps réel
#   sudo ./scripts/install-on-server.sh --stop    # Arrêt des services
# ══════════════════════════════════════════════════════════

RED='\033[0;31m'; GREEN='\033[0;32m'; CYAN='\033[0;36m'; YELLOW='\033[1;33m'; NC='\033[0m'
info()  { echo -e "${CYAN}[INFO]${NC} $1"; }
ok()    { echo -e "${GREEN}  ✓${NC} $1"; }
warn()  { echo -e "${YELLOW}[WARN]${NC} $1"; }
err()   { echo -e "${RED}[ERREUR]${NC} $1"; exit 1; }

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PROJECT_DIR="$( cd "$SCRIPT_DIR/.." && pwd )"
cd "$PROJECT_DIR"

# ─── Détection OS ─────────────────────────────
detect_os() {
  if [ -f /etc/os-release ]; then
    . /etc/os-release
    OS_ID="$ID"
    OS_VERSION="$VERSION_ID"
  else
    err "Impossible de détecter l'OS"
  fi
  info "OS détecté : $OS_ID $OS_VERSION"
}

# ─── Installation Docker ──────────────────────
install_docker() {
  if command -v docker &>/dev/null && docker compose version &>/dev/null; then
    ok "Docker déjà installé : $(docker --version)"
    return
  fi

  info "Installation de Docker..."
  case "$OS_ID" in
    ubuntu|debian)
      apt-get update -qq
      apt-get install -y -qq ca-certificates curl gnupg
      install -m 0755 -d /etc/apt/keyrings
      curl -fsSL https://download.docker.com/linux/$OS_ID/gpg -o /etc/apt/keyrings/docker.asc
      chmod a+r /etc/apt/keyrings/docker.asc
      echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.asc] https://download.docker.com/linux/$OS_ID $(. /etc/os-release && echo "$VERSION_CODENAME") stable" \
        > /etc/apt/sources.list.d/docker.list
      apt-get update -qq
      apt-get install -y -qq docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
      ;;
    rhel|centos|rocky|almalinux)
      yum install -y -q yum-utils
      yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo
      yum install -y -q docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
      ;;
    *)
      warn "OS non reconnu, installation générique via get.docker.com..."
      curl -fsSL https://get.docker.com | sh
      ;;
  esac

  systemctl enable docker
  systemctl start docker
  ok "Docker installé"
}

# ─── Firewall ─────────────────────────────────
open_port_80() {
  if command -v ufw &>/dev/null && ufw status | grep -q "Status: active"; then
    ufw allow 80/tcp 2>/dev/null || true
    ok "UFW : port 80 ouvert"
  elif command -v firewall-cmd &>/dev/null; then
    firewall-cmd --permanent --add-port=80/tcp 2>/dev/null || true
    firewall-cmd --reload 2>/dev/null || true
    ok "firewalld : port 80 ouvert"
  fi
}

# ─── .env ─────────────────────────────────────
setup_env() {
  if [ -f .env ]; then
    ok "Fichier .env déjà présent"
    return
  fi
  if [ -f .env.production ]; then
    cp .env.production .env
    ok "Fichier .env créé depuis .env.production"
  else
    err "Aucun fichier .env.production trouvé"
  fi
}

# ─── Déploiement ──────────────────────────────
deploy_stack() {
  setup_env

  info "Build de l'image Docker (peut prendre 3-5 min)..."
  docker compose build --no-cache

  info "Démarrage des services..."
  docker compose down 2>/dev/null || true
  docker compose up -d

  info "Attente du démarrage (30s)..."
  sleep 30

  info "Application des migrations Prisma..."
  docker compose exec -T app sh -c "npx prisma migrate deploy" 2>&1 || warn "Migrations en attente"

  info "État des conteneurs :"
  docker compose ps

  echo ""
  if curl -sf http://localhost/login > /dev/null 2>&1 || curl -sf http://localhost:3000/login > /dev/null 2>&1; then
    echo ""
    echo "═══════════════════════════════════════════════════════"
    echo "  ✓ HoshinFlow DÉPLOYÉ AVEC SUCCÈS !"
    echo ""
    echo "  URL (depuis le réseau IPD) : http://$(hostname -I | awk '{print $1}')"
    echo "  Admin : admin@hoshinflow.local"
    echo ""
    echo "  Prochaine étape : charger les données"
    echo "  sudo ./scripts/install-on-server.sh --seed"
    echo "═══════════════════════════════════════════════════════"
  else
    warn "Le service n'est pas encore prêt. Consultez les logs :"
    echo "  docker compose logs -f"
  fi
}

# ─── Seed ─────────────────────────────────────
seed_data() {
  info "Chargement des données IPD..."
  if [ -f /tmp/hoshin-data.json ] || [ -f ./prisma/hoshin-data.json ]; then
    docker compose exec -T app sh -c "npx tsx prisma/seed.ts"
    ok "Données chargées"
  else
    warn "hoshin-data.json introuvable — seed minimal uniquement"
    docker compose exec -T app sh -c "npx tsx prisma/seed.ts" || true
  fi
}

# ─── Status ───────────────────────────────────
show_status() {
  info "État des services..."
  docker compose ps
  echo ""
  info "Ressources :"
  df -h / | tail -1
  free -h 2>/dev/null | head -2
  echo ""
  info "Test HTTP :"
  if curl -sf http://localhost/login > /dev/null 2>&1; then
    ok "Application accessible sur http://localhost"
  else
    warn "Application non accessible — vérifier les logs"
  fi
}

# ─── Main ─────────────────────────────────────
if [ "$EUID" -ne 0 ]; then
  err "Ce script doit être exécuté en root (sudo ./scripts/install-on-server.sh)"
fi

echo ""
echo -e "${CYAN}╔══════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║  HoshinFlow — Installation serveur IPD          ║${NC}"
echo -e "${CYAN}║  $(date +"%Y-%m-%d %H:%M:%S")                         ║${NC}"
echo -e "${CYAN}╚══════════════════════════════════════════════════╝${NC}"
echo ""

case "${1:-}" in
  --update)
    info "Mise à jour de HoshinFlow..."
    docker compose build
    docker compose up -d
    sleep 10
    docker compose exec -T app sh -c "npx prisma migrate deploy" 2>/dev/null || true
    show_status
    ;;
  --seed)
    seed_data
    ;;
  --status)
    show_status
    ;;
  --logs)
    docker compose logs -f --tail=100
    ;;
  --stop)
    info "Arrêt des services..."
    docker compose down
    ok "Services arrêtés"
    ;;
  --help|-h)
    echo "Usage: sudo $0 [option]"
    echo ""
    echo "Options :"
    echo "  (aucune)    Installation complète (Docker + build + démarrage)"
    echo "  --update    Rebuild + redémarrage"
    echo "  --seed      Charge les données IPD (si hoshin-data.json présent)"
    echo "  --status    État des services"
    echo "  --logs      Logs temps réel"
    echo "  --stop      Arrête les services"
    ;;
  *)
    detect_os
    install_docker
    open_port_80
    deploy_stack
    ;;
esac
