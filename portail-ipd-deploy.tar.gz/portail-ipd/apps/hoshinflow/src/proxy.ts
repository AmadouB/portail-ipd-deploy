import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";
import { jwtVerify } from "jose";

const SECRET = new TextEncoder().encode(
  process.env.JWT_SECRET || "hoshinflow-dev-secret-change-in-production"
);

const BASE_PATH = process.env.NEXT_BASE_PATH ?? "/hoshinflow";

const PUBLIC_PATHS = [
  "/login",
  "/api/auth/login",
  "/api/auth/logout",
  "/api/auth/sso",
];

function isPublicPath(pathname: string): boolean {
  return PUBLIC_PATHS.some((p) => pathname.startsWith(p));
}

function loginRedirect(request: NextRequest): NextResponse {
  // Construct absolute URL with basePath included so the browser navigates
  // to /hoshinflow/login through the upstream Nginx.
  const url = request.nextUrl.clone();
  url.pathname = `${BASE_PATH}/login`;
  url.search = "";
  return NextResponse.redirect(url);
}

export async function proxy(request: NextRequest) {
  // pathname is already stripped of basePath by Next.js
  const { pathname } = request.nextUrl;

  if (isPublicPath(pathname)) {
    return NextResponse.next();
  }

  const token = request.cookies.get("hoshinflow-session")?.value;

  if (!token) {
    return loginRedirect(request);
  }

  try {
    await jwtVerify(token, SECRET);
    return NextResponse.next();
  } catch {
    return loginRedirect(request);
  }
}

export const config = {
  matcher: [
    /*
     * Match all paths except static assets. With basePath set, the
     * matcher patterns are evaluated against the basePath-stripped path.
     */
    "/((?!_next/static|_next/image|favicon\\.ico|.*\\.svg$).*)",
  ],
};
