import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";
import { jwtVerify } from "jose";

const SECRET = new TextEncoder().encode(
  process.env.JWT_SECRET || "hoshinflow-dev-secret-change-in-production"
);

const PUBLIC_PATHS = [
  "/login",
  "/api/auth/login",
  "/api/auth/logout",
  "/api/auth/sso",
];

function isPublicPath(pathname: string): boolean {
  return PUBLIC_PATHS.some((p) => pathname.startsWith(p));
}

function loginRedirect(request: NextRequest): NextResponse {
  // Important : ne PAS prefixer avec basePath ici.
  // Next.js avec basePath ajoute automatiquement /hoshinflow aux redirects
  // depuis le middleware/proxy. Sinon on aurait /hoshinflow/hoshinflow/login.
  const url = request.nextUrl.clone();
  url.pathname = "/login";
  url.search = "";
  return NextResponse.redirect(url);
}

export async function proxy(request: NextRequest) {
  // pathname is already stripped of basePath by Next.js
  const { pathname } = request.nextUrl;

  if (isPublicPath(pathname)) {
    return NextResponse.next();
  }

  const token = request.cookies.get("hoshinflow-session")?.value;

  if (!token) {
    return loginRedirect(request);
  }

  try {
    await jwtVerify(token, SECRET);
    return NextResponse.next();
  } catch {
    return loginRedirect(request);
  }
}

export const config = {
  matcher: [
    /*
     * Match all paths except static assets. With basePath set, the
     * matcher patterns are evaluated against the basePath-stripped path.
     */
    "/((?!_next/static|_next/image|favicon\\.ico|.*\\.svg$).*)",
  ],
};
