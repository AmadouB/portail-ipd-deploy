import { NextRequest, NextResponse } from "next/server";
import { verifySessionToken } from "./auth";
import { checkPermission, canAccessDepartement } from "./rbac";
import type { Resource, Action } from "./rbac";

interface AuthorizedResult {
  authorized: true;
  user: {
    id: string;
    email: string;
    nom: string;
    role: string;
    departementId: string | null;
  };
}

interface UnauthorizedResult {
  authorized: false;
  response: NextResponse;
}

export type GuardResult = AuthorizedResult | UnauthorizedResult;

/**
 * API route guard that:
 * 1. Reads the JWT token from the session cookie
 * 2. Verifies the JWT
 * 3. Checks role-based permission for the resource/action
 * 4. Optionally checks department-level access
 * 5. Returns the authenticated user or an error response (401/403)
 */
export async function apiGuard(
  request: NextRequest,
  resource: string,
  action: string,
  departementId?: string
): Promise<GuardResult> {
  // 1. Read token from cookie
  const token = request.cookies.get("hoshinflow-session")?.value;
  if (!token) {
    return {
      authorized: false,
      response: NextResponse.json(
        { error: "Non authentifie" },
        { status: 401 }
      ),
    };
  }

  // 2. Verify JWT
  const user = await verifySessionToken(token);
  if (!user) {
    return {
      authorized: false,
      response: NextResponse.json(
        { error: "Session invalide" },
        { status: 401 }
      ),
    };
  }

  // 3. Check permission
  const hasPermission = checkPermission(
    user,
    resource as Resource,
    action as Action
  );
  if (!hasPermission) {
    return {
      authorized: false,
      response: NextResponse.json(
        { error: "Acces refuse" },
        { status: 403 }
      ),
    };
  }

  // 4. If departementId provided, check department access
  if (departementId && !canAccessDepartement(user, departementId)) {
    return {
      authorized: false,
      response: NextResponse.json(
        { error: "Acces au departement refuse" },
        { status: 403 }
      ),
    };
  }

  // 5. Return authorized user
  return {
    authorized: true,
    user,
  };
}

/**
 * Type guard to check if a GuardResult is an error (unauthorized).
 */
export function isGuardError(
  result: GuardResult
): result is UnauthorizedResult {
  return !result.authorized;
}
