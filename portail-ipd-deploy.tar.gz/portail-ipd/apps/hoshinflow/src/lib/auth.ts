import { SignJWT, jwtVerify } from "jose";
import { cookies } from "next/headers";

export interface SessionUser {
  id: string;
  email: string;
  nom: string;
  role: string;
  departementId: string | null;
}

/** @deprecated Use SessionUser instead */
export type SessionPayload = SessionUser;

const COOKIE_NAME = "hoshinflow-session";
const SECRET = new TextEncoder().encode(
  process.env.JWT_SECRET || "fallback-dev-secret"
);

/**
 * Signs a JWT with HS256 and a 7-day expiry. Returns the token string.
 */
export async function createSession(user: SessionUser): Promise<string> {
  const token = await new SignJWT({
    id: user.id,
    email: user.email,
    nom: user.nom,
    role: user.role,
    departementId: user.departementId,
  })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime("7d")
    .sign(SECRET);

  return token;
}

/**
 * Verifies and decodes a JWT token, returning the SessionUser payload or null.
 */
export async function verifySessionToken(
  token: string
): Promise<SessionUser | null> {
  try {
    const { payload } = await jwtVerify(token, SECRET);
    return {
      id: payload.id as string,
      email: payload.email as string,
      nom: payload.nom as string,
      role: payload.role as string,
      departementId: (payload.departementId as string) ?? null,
    };
  } catch {
    return null;
  }
}

/**
 * Reads the session cookie via next/headers, verifies the JWT,
 * and returns the SessionUser or null.
 */
export async function getServerSessionUser(): Promise<SessionUser | null> {
  const cookieStore = await cookies();
  const cookie = cookieStore.get(COOKIE_NAME);
  if (!cookie?.value) return null;
  return verifySessionToken(cookie.value);
}

/**
 * Backward-compatible alias: reads cookie and verifies session.
 * @deprecated Use getServerSessionUser() instead.
 */
export const verifySession = getServerSessionUser;

/**
 * Sets an httpOnly session cookie on the given Response.
 */
export function setSessionCookie(response: Response, token: string): void {
  const isProduction = process.env.NODE_ENV === "production";
  const sameSite = isProduction ? "None" : "Lax";
  const secure = isProduction ? "; Secure" : "";
  response.headers.append(
    "Set-Cookie",
    `${COOKIE_NAME}=${token}; HttpOnly; Path=/; SameSite=${sameSite}${secure}; Max-Age=${60 * 60 * 24 * 7}`
  );
}

/**
 * Clears the session cookie on the given Response.
 */
export function clearSessionCookie(response: Response): void {
  response.headers.append(
    "Set-Cookie",
    `${COOKIE_NAME}=; HttpOnly; Path=/; SameSite=Lax; Max-Age=0`
  );
}
