export type Statut = 'NON_DEMARRE' | 'EN_COURS' | 'EN_RETARD' | 'EN_ATTENTE' | 'COMPLET' | 'ANNULE' | 'A_RECONDUIRE';

export type Trimestre = 'T1' | 'T2' | 'T3' | 'T4';

export type RoleContribution = 'PILOTE' | 'CONTRIBUTEUR' | 'SUPPORT' | 'INFORME';

export interface Organisation {
  id: string;
  nom: string;
  vision: string | null;
  anneeDepart: number;
  anneeCible: number;
}

export interface AxeStrategique {
  id: string;
  code: string;
  slug: string;
  nom: string;
  description: string | null;
  couleur: string;
  ordre: number;
  objectifs: ObjectifStrategique[];
  tauxCompletion?: number;
}

export interface BreakthroughGoal {
  id: string;
  code: string;
  nom: string;
  description: string | null;
}

export interface Departement {
  id: string;
  code: string;
  nom: string;
  nomCourt: string | null;
  couleur: string;
  directeur: string | null;
  strategies: StrategieDepartementale[];
  tauxCompletion?: number;
  totalProjets?: number;
}

export interface ObjectifStrategique {
  id: string;
  axeId: string;
  code: string;
  libelle: string;
  description: string | null;
  poids: number;
  ordre: number;
  strategies: StrategieDepartementale[];
  tauxCompletion?: number;
}

export interface StrategieDepartementale {
  id: string;
  objectifStrategiqueId: string;
  departementId: string;
  code: string;
  libelle: string;
  responsable: string | null;
  statut: Statut;
  projets: Projet[];
  tauxCompletion?: number;
  departement?: Departement;
  objectifStrategique?: ObjectifStrategique;
}

export interface Projet {
  id: string;
  strategieId: string;
  code: string;
  libelle: string;
  responsable: string | null;
  statut: Statut;
  financeur: string | null;
  budgetAlloue: number | null;
  budgetDepense: number | null;
  devise: string;
  commentaire: string | null;
  kpis: KPI[];
  projetBtgs: ProjetBTG[];
  contributeurs: ProjetContributeur[];
  strategie?: StrategieDepartementale;
  scorePerformance?: number;
}

export interface KPI {
  id: string;
  projetId: string;
  code: string;
  libelle: string;
  modeCalcul: string;
  unite: string | null;
  valeurReference: string | null;
  ordre: number;
  mesures: MesureKPI[];
  tauxRealisation?: number;
  statutKpi?: string;
}

export interface MesureKPI {
  id: string;
  kpiId: string;
  annee: number;
  trimestre: Trimestre;
  cible: number | null;
  realise: number | null;
  tauxCompletion: number | null;
  commentaire: string | null;
}

export interface ProjetContributeur {
  id: string;
  projetId: string;
  departementId: string;
  nom: string;
  rang: number;
}

export interface ProjetBTG {
  id: string;
  projetId: string;
  btgId: string;
  indicateurBinaire: boolean;
}

export interface MatriceContributeurs {
  id: string;
  objectifStrategiqueId: string;
  departementId: string;
  roleContribution: RoleContribution;
}
