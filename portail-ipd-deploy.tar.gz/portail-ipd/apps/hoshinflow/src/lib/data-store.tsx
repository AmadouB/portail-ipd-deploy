"use client";

import {
  createContext,
  useContext,
  useState,
  useCallback,
  type ReactNode,
} from "react";
import {
  getDepartements,
  getAxes,
  getProjets,
  getObjectifs,
  getStrategies,
  getBtgs,
} from "./data";
import type {
  Departement,
  AxeStrategique,
  ObjectifStrategique,
  StrategieDepartementale,
  Projet,
  KPI,
  MesureKPI,
  Statut,
  Trimestre,
} from "./types";

// ─── Flat row for the global matrix ───

export interface MatrixRow {
  deptCode: string;
  deptNom: string;
  deptCouleur: string;
  directeur: string | null;
  axeCode: string;
  axeNom: string;
  axeCouleur: string;
  objectifCode: string;
  objectifLibelle: string;
  strategieId: string;
  strategieCode: string;
  strategieLibelle: string;
  strategieStatut: Statut;
  strategieResponsable: string | null;
  projetId: string;
  projetCode: string;
  projetLibelle: string;
  projetResponsable: string | null;
  projetStatut: Statut;
  projetFinanceur: string | null;
  projetBudgetAlloue: number | null;
  projetBudgetDepense: number | null;
  kpiCount: number;
  kpiFilledCount: number;
  scoreT1: number | null;
  scoreT2: number | null;
  scoreT3: number | null;
  scoreT4: number | null;
  latestScore: number;
  // References for edit
  projet: Projet;
  strategie: StrategieDepartementale;
}

// ─── Context ───

interface DataStoreContextValue {
  rows: MatrixRow[];
  departements: Departement[];
  axes: AxeStrategique[];
  objectifs: ObjectifStrategique[];
  allStrategies: StrategieDepartementale[];

  // CRUD
  updateProjet: (id: string, patch: Partial<Projet>) => void;
  updateStrategie: (id: string, patch: Partial<StrategieDepartementale>) => void;
  updateKpi: (projetId: string, kpiId: string, patch: Partial<KPI>) => void;
  updateMesure: (
    projetId: string,
    kpiId: string,
    trimestre: Trimestre,
    patch: Partial<MesureKPI>
  ) => void;
  addProjet: (strategieId: string) => Projet;
  addKpi: (projetId: string) => KPI;
  deleteProjet: (id: string) => void;
  deleteKpi: (projetId: string, kpiId: string) => void;

  // Refresh
  version: number;
}

const DataStoreContext = createContext<DataStoreContextValue | null>(null);

// ─── Helper to compute score for a trimestre ───

function getTriScore(kpis: KPI[], tri: Trimestre): number | null {
  const scores: number[] = [];
  for (const kpi of kpis) {
    const m = kpi.mesures.find(
      (mes) =>
        mes.trimestre === tri && mes.realise !== null && mes.cible !== null && mes.cible > 0
    );
    if (m) {
      scores.push(
        Math.min(
          Math.round(((m.realise as number) / (m.cible as number)) * 1000) / 10,
          100
        )
      );
    }
  }
  return scores.length > 0
    ? Math.round((scores.reduce((a, b) => a + b, 0) / scores.length) * 10) / 10
    : null;
}

function buildRows(departements: Departement[], axes: AxeStrategique[]): MatrixRow[] {
  const rows: MatrixRow[] = [];

  // Build objectif->axe index
  const objAxeMap = new Map<string, AxeStrategique>();
  for (const axe of axes) {
    for (const obj of axe.objectifs) {
      objAxeMap.set(obj.id, axe);
    }
  }

  // Build objectif map
  const objMap = new Map<string, ObjectifStrategique>();
  for (const axe of axes) {
    for (const obj of axe.objectifs) {
      objMap.set(obj.id, obj);
    }
  }

  for (const dept of departements) {
    for (const str of dept.strategies) {
      const axe = objAxeMap.get(str.objectifStrategiqueId);
      const obj = objMap.get(str.objectifStrategiqueId);

      if (str.projets.length === 0) {
        // Strategy with no projects — still show
        rows.push({
          deptCode: dept.code,
          deptNom: dept.nom,
          deptCouleur: dept.couleur,
          directeur: dept.directeur,
          axeCode: axe?.code ?? "",
          axeNom: axe?.nom ?? "",
          axeCouleur: axe?.couleur ?? "#6b7280",
          objectifCode: obj?.code ?? "",
          objectifLibelle: obj?.libelle ?? "",
          strategieId: str.id,
          strategieCode: str.code,
          strategieLibelle: str.libelle,
          strategieStatut: str.statut,
          strategieResponsable: str.responsable,
          projetId: "",
          projetCode: "—",
          projetLibelle: "Aucun projet",
          projetResponsable: null,
          projetStatut: "NON_DEMARRE",
          projetFinanceur: null,
          projetBudgetAlloue: null,
          projetBudgetDepense: null,
          kpiCount: 0,
          kpiFilledCount: 0,
          scoreT1: null,
          scoreT2: null,
          scoreT3: null,
          scoreT4: null,
          latestScore: 0,
          projet: {} as Projet,
          strategie: str,
        });
      } else {
        for (const p of str.projets) {
          const kpiFilledCount = p.kpis.filter((k) =>
            k.mesures.some((m) => m.realise !== null)
          ).length;

          const t1 = getTriScore(p.kpis, "T1");
          const t2 = getTriScore(p.kpis, "T2");
          const t3 = getTriScore(p.kpis, "T3");
          const t4 = getTriScore(p.kpis, "T4");
          const latest = t4 ?? t3 ?? t2 ?? t1 ?? 0;

          rows.push({
            deptCode: dept.code,
            deptNom: dept.nom,
            deptCouleur: dept.couleur,
            directeur: dept.directeur,
            axeCode: axe?.code ?? "",
            axeNom: axe?.nom ?? "",
            axeCouleur: axe?.couleur ?? "#6b7280",
            objectifCode: obj?.code ?? "",
            objectifLibelle: obj?.libelle ?? "",
            strategieId: str.id,
            strategieCode: str.code,
            strategieLibelle: str.libelle,
            strategieStatut: str.statut,
            strategieResponsable: str.responsable,
            projetId: p.id,
            projetCode: p.code,
            projetLibelle: p.libelle,
            projetResponsable: p.responsable,
            projetStatut: p.statut,
            projetFinanceur: p.financeur,
            projetBudgetAlloue: p.budgetAlloue,
            projetBudgetDepense: p.budgetDepense,
            kpiCount: p.kpis.length,
            kpiFilledCount,
            scoreT1: t1,
            scoreT2: t2,
            scoreT3: t3,
            scoreT4: t4,
            latestScore: latest,
            projet: p,
            strategie: str,
          });
        }
      }
    }
  }

  return rows;
}

// ─── Provider ───

let idCounter = 10000;
function nextId(prefix: string) {
  return `${prefix}-${++idCounter}`;
}

export function DataStoreProvider({ children }: { children: ReactNode }) {
  const [departements, setDepartements] = useState(() => getDepartements());
  const [axes] = useState(() => getAxes());
  const [version, setVersion] = useState(0);

  const bump = useCallback(() => setVersion((v) => v + 1), []);

  const objectifs = axes.flatMap((a) => a.objectifs);
  const allStrategies = departements.flatMap((d) => d.strategies);

  const rows = buildRows(departements, axes);

  // ── CRUD ──

  const updateProjet = useCallback(
    (id: string, patch: Partial<Projet>) => {
      setDepartements((prev) =>
        prev.map((d) => ({
          ...d,
          strategies: d.strategies.map((s) => ({
            ...s,
            projets: s.projets.map((p) =>
              p.id === id ? { ...p, ...patch } : p
            ),
          })),
        }))
      );
      bump();
    },
    [bump]
  );

  const updateStrategie = useCallback(
    (id: string, patch: Partial<StrategieDepartementale>) => {
      setDepartements((prev) =>
        prev.map((d) => ({
          ...d,
          strategies: d.strategies.map((s) =>
            s.id === id ? { ...s, ...patch } : s
          ),
        }))
      );
      bump();
    },
    [bump]
  );

  const updateKpi = useCallback(
    (projetId: string, kpiId: string, patch: Partial<KPI>) => {
      setDepartements((prev) =>
        prev.map((d) => ({
          ...d,
          strategies: d.strategies.map((s) => ({
            ...s,
            projets: s.projets.map((p) =>
              p.id === projetId
                ? {
                    ...p,
                    kpis: p.kpis.map((k) =>
                      k.id === kpiId ? { ...k, ...patch } : k
                    ),
                  }
                : p
            ),
          })),
        }))
      );
      bump();
    },
    [bump]
  );

  const updateMesure = useCallback(
    (
      projetId: string,
      kpiId: string,
      trimestre: Trimestre,
      patch: Partial<MesureKPI>
    ) => {
      setDepartements((prev) =>
        prev.map((d) => ({
          ...d,
          strategies: d.strategies.map((s) => ({
            ...s,
            projets: s.projets.map((p) =>
              p.id === projetId
                ? {
                    ...p,
                    kpis: p.kpis.map((k) =>
                      k.id === kpiId
                        ? {
                            ...k,
                            mesures: k.mesures.map((m) =>
                              m.trimestre === trimestre ? { ...m, ...patch } : m
                            ),
                          }
                        : k
                    ),
                  }
                : p
            ),
          })),
        }))
      );
      bump();
    },
    [bump]
  );

  const addProjet = useCallback(
    (strategieId: string): Projet => {
      const newProjet: Projet = {
        id: nextId("proj"),
        strategieId,
        code: `P-NEW-${idCounter}`,
        libelle: "Nouveau projet",
        responsable: null,
        statut: "NON_DEMARRE",
        financeur: null,
        budgetAlloue: null,
        budgetDepense: null,
        devise: "FCFA",
        commentaire: null,
        kpis: [],
        projetBtgs: [],
        contributeurs: [],
      };
      setDepartements((prev) =>
        prev.map((d) => ({
          ...d,
          strategies: d.strategies.map((s) =>
            s.id === strategieId
              ? { ...s, projets: [...s.projets, newProjet] }
              : s
          ),
        }))
      );
      bump();
      return newProjet;
    },
    [bump]
  );

  const addKpi = useCallback(
    (projetId: string): KPI => {
      const newKpi: KPI = {
        id: nextId("kpi"),
        projetId,
        code: `KPI-NEW-${idCounter}`,
        libelle: "Nouvel indicateur",
        modeCalcul: "SOMME",
        unite: null,
        valeurReference: null,
        ordre: 0,
        mesures: (["T1", "T2", "T3", "T4"] as Trimestre[]).map((tri) => ({
          id: nextId("mes"),
          kpiId: `kpi-${idCounter}`,
          annee: 2025,
          trimestre: tri,
          cible: null,
          realise: null,
          tauxCompletion: null,
          commentaire: null,
        })),
      };
      setDepartements((prev) =>
        prev.map((d) => ({
          ...d,
          strategies: d.strategies.map((s) => ({
            ...s,
            projets: s.projets.map((p) =>
              p.id === projetId ? { ...p, kpis: [...p.kpis, newKpi] } : p
            ),
          })),
        }))
      );
      bump();
      return newKpi;
    },
    [bump]
  );

  const deleteProjet = useCallback(
    (id: string) => {
      setDepartements((prev) =>
        prev.map((d) => ({
          ...d,
          strategies: d.strategies.map((s) => ({
            ...s,
            projets: s.projets.filter((p) => p.id !== id),
          })),
        }))
      );
      bump();
    },
    [bump]
  );

  const deleteKpi = useCallback(
    (projetId: string, kpiId: string) => {
      setDepartements((prev) =>
        prev.map((d) => ({
          ...d,
          strategies: d.strategies.map((s) => ({
            ...s,
            projets: s.projets.map((p) =>
              p.id === projetId
                ? { ...p, kpis: p.kpis.filter((k) => k.id !== kpiId) }
                : p
            ),
          })),
        }))
      );
      bump();
    },
    [bump]
  );

  return (
    <DataStoreContext.Provider
      value={{
        rows,
        departements,
        axes,
        objectifs,
        allStrategies,
        updateProjet,
        updateStrategie,
        updateKpi,
        updateMesure,
        addProjet,
        addKpi,
        deleteProjet,
        deleteKpi,
        version,
      }}
    >
      {children}
    </DataStoreContext.Provider>
  );
}

export function useDataStore(): DataStoreContextValue {
  const ctx = useContext(DataStoreContext);
  if (!ctx) throw new Error("useDataStore must be within DataStoreProvider");
  return ctx;
}
