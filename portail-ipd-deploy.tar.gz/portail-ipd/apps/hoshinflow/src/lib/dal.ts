import { prisma } from "./prisma";
import { calculateProjetScore, calculateStrategieCompletion } from "./utils";
import type {
  Organisation,
  AxeStrategique,
  BreakthroughGoal,
  Departement,
  ObjectifStrategique,
  StrategieDepartementale,
  Projet,
  Statut,
  Trimestre,
  KPI,
  MesureKPI,
  ProjetBTG,
  ProjetContributeur,
} from "./types";

// ─── Nested include constants ────────────────────────

const mesureInclude = true; // MesureKPI has no nested relations

const kpiInclude = {
  mesures: true,
} as const;

const projetInclude = {
  kpis: { include: { mesures: true } },
  projetBtgs: true,
  contributeurs: true,
} as const;

const strategieInclude = {
  projets: { include: projetInclude },
  departement: true,
  objectifStrategique: true,
} as const;

const objectifInclude = {
  strategies: { include: { projets: { include: projetInclude }, departement: true } },
} as const;

const axeInclude = {
  objectifs: { include: objectifInclude },
} as const;

const departementInclude = {
  strategies: { include: { projets: { include: projetInclude } } },
} as const;

// ─── Mapping helpers ─────────────────────────────────

function mapMesure(m: Record<string, unknown>): MesureKPI {
  return {
    id: m.id as string,
    kpiId: m.kpiId as string,
    annee: m.annee as number,
    trimestre: m.trimestre as Trimestre,
    cible: m.cible as number | null,
    realise: m.realise as number | null,
    tauxCompletion: m.tauxCompletion as number | null,
    commentaire: m.commentaire as string | null,
  };
}

function mapKpi(k: Record<string, unknown>): KPI {
  const mesures = ((k.mesures as Record<string, unknown>[]) || []).map(mapMesure);
  return {
    id: k.id as string,
    projetId: k.projetId as string,
    code: k.code as string,
    libelle: k.libelle as string,
    modeCalcul: k.modeCalcul as string,
    unite: k.unite as string | null,
    valeurReference: k.valeurReference as string | null,
    ordre: k.ordre as number,
    mesures,
  };
}

function mapProjet(p: Record<string, unknown>): Projet {
  const kpis = ((p.kpis as Record<string, unknown>[]) || []).map(mapKpi);
  const projetBtgs = ((p.projetBtgs as Record<string, unknown>[]) || []).map((b) => ({
    id: b.id as string,
    projetId: b.projetId as string,
    btgId: b.btgId as string,
    indicateurBinaire: b.indicateurBinaire as boolean,
  })) as ProjetBTG[];
  const contributeurs = ((p.contributeurs as Record<string, unknown>[]) || []).map((c) => ({
    id: c.id as string,
    projetId: c.projetId as string,
    departementId: c.departementId as string,
    nom: c.nom as string,
    rang: c.rang as number,
  })) as ProjetContributeur[];

  const projet: Projet = {
    id: p.id as string,
    strategieId: p.strategieId as string,
    code: p.code as string,
    libelle: p.libelle as string,
    responsable: p.responsable as string | null,
    statut: p.statut as Statut,
    financeur: p.financeur as string | null,
    budgetAlloue: p.budgetAlloue as number | null,
    budgetDepense: p.budgetDepense as number | null,
    devise: p.devise as string,
    commentaire: p.commentaire as string | null,
    kpis,
    projetBtgs,
    contributeurs,
    scorePerformance: calculateProjetScore(kpis),
  };

  if (p.strategie) {
    const s = p.strategie as Record<string, unknown>;
    projet.strategie = {
      id: s.id as string,
      objectifStrategiqueId: s.objectifStrategiqueId as string,
      departementId: s.departementId as string,
      code: s.code as string,
      libelle: s.libelle as string,
      responsable: s.responsable as string | null,
      statut: s.statut as Statut,
      projets: [],
    };
  }

  return projet;
}

function mapStrategie(s: Record<string, unknown>): StrategieDepartementale {
  const projets = ((s.projets as Record<string, unknown>[]) || []).map(mapProjet);
  const strat: StrategieDepartementale = {
    id: s.id as string,
    objectifStrategiqueId: s.objectifStrategiqueId as string,
    departementId: s.departementId as string,
    code: s.code as string,
    libelle: s.libelle as string,
    responsable: s.responsable as string | null,
    statut: s.statut as Statut,
    projets,
    tauxCompletion: calculateStrategieCompletion(projets),
  };

  if (s.departement) {
    const d = s.departement as Record<string, unknown>;
    strat.departement = {
      id: d.id as string,
      code: d.code as string,
      nom: d.nom as string,
      nomCourt: d.nomCourt as string | null,
      couleur: d.couleur as string,
      directeur: d.directeur as string | null,
      strategies: [],
    };
  }

  if (s.objectifStrategique) {
    const o = s.objectifStrategique as Record<string, unknown>;
    strat.objectifStrategique = {
      id: o.id as string,
      axeId: o.axeId as string,
      code: o.code as string,
      libelle: o.libelle as string,
      description: o.description as string | null,
      poids: o.poids as number,
      ordre: o.ordre as number,
      strategies: [],
    };
  }

  return strat;
}

function mapObjectif(o: Record<string, unknown>): ObjectifStrategique {
  const strategies = ((o.strategies as Record<string, unknown>[]) || []).map(mapStrategie);
  const completions = strategies.map((s) => s.tauxCompletion ?? 0);
  const tauxCompletion =
    completions.length > 0
      ? Math.round((completions.reduce((a, b) => a + b, 0) / completions.length) * 10) / 10
      : 0;
  return {
    id: o.id as string,
    axeId: o.axeId as string,
    code: o.code as string,
    libelle: o.libelle as string,
    description: o.description as string | null,
    poids: o.poids as number,
    ordre: o.ordre as number,
    strategies,
    tauxCompletion,
  };
}

// ─── Public API ──────────────────────────────────────

export async function getOrganisation(): Promise<Organisation> {
  const org = await prisma.organisation.findFirstOrThrow();
  return {
    id: org.id,
    nom: org.nom,
    vision: org.vision,
    anneeDepart: org.anneeDepart,
    anneeCible: org.anneeCible,
  };
}

export async function getAxes(): Promise<AxeStrategique[]> {
  const rows = await prisma.axeStrategique.findMany({
    orderBy: { ordre: "asc" },
    include: axeInclude,
  });

  return rows.map((row: any) => {
    const r = row as Record<string, unknown>;
    const objectifs = ((r.objectifs as Record<string, unknown>[]) || []).map(mapObjectif);
    const completions = objectifs.map((o) => o.tauxCompletion ?? 0);
    const tauxCompletion =
      completions.length > 0
        ? Math.round((completions.reduce((a, b) => a + b, 0) / completions.length) * 10) / 10
        : 0;
    return {
      id: row.id,
      code: row.code,
      slug: row.slug,
      nom: row.nom,
      description: row.description,
      couleur: row.couleur,
      ordre: row.ordre,
      objectifs,
      tauxCompletion,
    };
  });
}

export async function getDepartements(): Promise<Departement[]> {
  const rows = await prisma.departement.findMany({
    orderBy: { nom: "asc" },
    include: departementInclude,
  });

  return rows.map((row: any) => {
    const r = row as Record<string, unknown>;
    const strategies = ((r.strategies as Record<string, unknown>[]) || []).map(mapStrategie);
    const allProjets = strategies.flatMap((s) => s.projets);
    const completions = strategies.map((s) => s.tauxCompletion ?? 0);
    const tauxCompletion =
      completions.length > 0
        ? Math.round((completions.reduce((a, b) => a + b, 0) / completions.length) * 10) / 10
        : 0;
    return {
      id: row.id,
      code: row.code,
      nom: row.nom,
      nomCourt: row.nomCourt,
      couleur: row.couleur,
      directeur: row.directeur,
      strategies,
      tauxCompletion,
      totalProjets: allProjets.length,
    };
  });
}

export async function getBtgs(): Promise<BreakthroughGoal[]> {
  const rows = await prisma.breakthroughGoal.findMany();
  return rows.map((row: any) => ({
    id: row.id,
    code: row.code,
    nom: row.nom,
    description: row.description,
  }));
}

export async function getObjectifs(): Promise<ObjectifStrategique[]> {
  const rows = await prisma.objectifStrategique.findMany({
    orderBy: { ordre: "asc" },
    include: objectifInclude,
  });
  return rows.map((r: any) => mapObjectif(r as Record<string, unknown>));
}

export async function getStrategies(): Promise<StrategieDepartementale[]> {
  const rows = await prisma.strategieDepartementale.findMany({
    include: strategieInclude,
  });
  return rows.map((r: any) => mapStrategie(r as Record<string, unknown>));
}

export async function getProjets(): Promise<Projet[]> {
  const rows = await prisma.projet.findMany({
    include: { ...projetInclude, strategie: { include: { departement: true } } },
  });
  return rows.map((r: any) => mapProjet(r as Record<string, unknown>));
}

export async function getProjetById(id: string): Promise<Projet | null> {
  const row = await prisma.projet.findUnique({
    where: { id },
    include: { ...projetInclude, strategie: { include: { departement: true, objectifStrategique: true } } },
  });
  if (!row) return null;
  return mapProjet(row as unknown as Record<string, unknown>);
}

export async function getAxeBySlug(slug: string): Promise<AxeStrategique | null> {
  const row = await prisma.axeStrategique.findFirst({
    where: { slug },
    include: axeInclude,
  });
  if (!row) return null;
  const r = row as unknown as Record<string, unknown>;
  const objectifs = ((r.objectifs as Record<string, unknown>[]) || []).map(mapObjectif);
  const completions = objectifs.map((o) => o.tauxCompletion ?? 0);
  const tauxCompletion =
    completions.length > 0
      ? Math.round((completions.reduce((a, b) => a + b, 0) / completions.length) * 10) / 10
      : 0;
  return {
    id: row.id,
    code: row.code,
    slug: row.slug,
    nom: row.nom,
    description: row.description,
    couleur: row.couleur,
    ordre: row.ordre,
    objectifs,
    tauxCompletion,
  };
}

export async function getDepartementByCode(code: string): Promise<Departement | null> {
  const row = await prisma.departement.findUnique({
    where: { code },
    include: departementInclude,
  });
  if (!row) return null;
  const r = row as unknown as Record<string, unknown>;
  const strategies = ((r.strategies as Record<string, unknown>[]) || []).map(mapStrategie);
  const allProjets = strategies.flatMap((s) => s.projets);
  const completions = strategies.map((s) => s.tauxCompletion ?? 0);
  const tauxCompletion =
    completions.length > 0
      ? Math.round((completions.reduce((a, b) => a + b, 0) / completions.length) * 10) / 10
      : 0;
  return {
    id: row.id,
    code: row.code,
    nom: row.nom,
    nomCourt: row.nomCourt,
    couleur: row.couleur,
    directeur: row.directeur,
    strategies,
    tauxCompletion,
    totalProjets: allProjets.length,
  };
}

export async function getObjectifById(id: string): Promise<ObjectifStrategique | null> {
  const row = await prisma.objectifStrategique.findUnique({
    where: { id },
    include: objectifInclude,
  });
  if (!row) return null;
  return mapObjectif(row as unknown as Record<string, unknown>);
}

export async function getStrategieById(id: string): Promise<StrategieDepartementale | null> {
  const row = await prisma.strategieDepartementale.findUnique({
    where: { id },
    include: strategieInclude,
  });
  if (!row) return null;
  return mapStrategie(row as unknown as Record<string, unknown>);
}

export async function getProjetsByDepartement(code: string): Promise<Projet[]> {
  const dept = await prisma.departement.findUnique({ where: { code } });
  if (!dept) return [];

  const rows = await prisma.projet.findMany({
    where: {
      strategie: { departementId: dept.id },
    },
    include: { ...projetInclude, strategie: { include: { departement: true } } },
  });
  return rows.map((r: any) => mapProjet(r as Record<string, unknown>));
}

// ─── OGSM / Cartographie ─────────────────────────────────

export interface OGSMMesure {
  id: string;
  libelle: string;
  cible: string | null;
  realise: string | null;
  unite: string | null;
  tauxCompletion: number | null;
  ordre: number;
}

export interface OGSMAction {
  id: string;
  refCode: string | null;
  quoi: string;
  comment: string | null;
  direction: string | null;
  responsable: string | null;
  contributeurs: string | null;
  priorite: number | null;
  statut: string;
  avancementPct: number | null;
  deadline: Date | null;
  bailleurBudget: string | null;
  ordre: number;
  mesures: OGSMMesure[];
}

export interface OGSMAxe {
  id: string;
  libelle: string;
  description: string | null;
  groupe: string | null;
  investmentCase: string | null;
  couleur: string;
  ordre: number;
  actions: OGSMAction[];
}

export interface OGSMPlan {
  id: string;
  code: string;
  nom: string;
  objectif: string;
  description: string | null;
  anneeDepart: number;
  anneeCible: number;
  couleur: string;
  source: string | null;
  createdAt: Date;
  updatedAt: Date;
  axes: OGSMAxe[];
}

export async function getStrategicPlans(): Promise<OGSMPlan[]> {
  const rows = await prisma.planStrategique.findMany({
    include: {
      axes: {
        orderBy: { ordre: "asc" },
        include: {
          actions: {
            orderBy: { ordre: "asc" },
            include: {
              mesures: { orderBy: { ordre: "asc" } },
            },
          },
        },
      },
    },
    orderBy: { createdAt: "asc" },
  });
  return rows as unknown as OGSMPlan[];
}

export async function getStrategicPlanByCode(
  code: string
): Promise<OGSMPlan | null> {
  const row = await prisma.planStrategique.findUnique({
    where: { code },
    include: {
      axes: {
        orderBy: { ordre: "asc" },
        include: {
          actions: {
            orderBy: { ordre: "asc" },
            include: {
              mesures: { orderBy: { ordre: "asc" } },
            },
          },
        },
      },
    },
  });
  return row as unknown as OGSMPlan | null;
}

export async function getStrategicPlanList(): Promise<
  Array<{
    id: string;
    code: string;
    nom: string;
    objectif: string;
    couleur: string;
    axesCount: number;
    actionsCount: number;
    updatedAt: Date;
  }>
> {
  const rows = await prisma.planStrategique.findMany({
    include: {
      _count: { select: { axes: true } },
      axes: { include: { _count: { select: { actions: true } } } },
    },
    orderBy: { updatedAt: "desc" },
  });
  return rows.map((r: any) => ({
    id: r.id,
    code: r.code,
    nom: r.nom,
    objectif: r.objectif,
    couleur: r.couleur,
    axesCount: r._count.axes,
    actionsCount: r.axes.reduce(
      (s: number, a: any) => s + (a._count?.actions ?? 0),
      0
    ),
    updatedAt: r.updatedAt,
  }));
}
