"use client";

import { useAuth } from "@/lib/auth-context";
import { checkPermission, getUserPermissions } from "@/lib/rbac";
import type { Resource, Action } from "@/lib/rbac";

export function useCanEdit(resource: string): boolean {
  const { user } = useAuth();
  if (!user) return false;
  return checkPermission(
    { id: user.id, role: user.role, departementId: user.departementId ?? null },
    resource as Resource,
    "update" as Action
  );
}

export function useCanCreate(resource: string): boolean {
  const { user } = useAuth();
  if (!user) return false;
  return checkPermission(
    { id: user.id, role: user.role, departementId: user.departementId ?? null },
    resource as Resource,
    "create" as Action
  );
}

export function useCanDelete(resource: string): boolean {
  const { user } = useAuth();
  if (!user) return false;
  return checkPermission(
    { id: user.id, role: user.role, departementId: user.departementId ?? null },
    resource as Resource,
    "delete" as Action
  );
}

export function usePermissions(): Record<string, string[]> {
  const { user } = useAuth();
  if (!user) return {};
  return getUserPermissions(user.role);
}
