type Role = "ADMIN" | "DIRECTEUR" | "CHEF_PROJET" | "CONTRIBUTEUR" | "LECTEUR";

type Resource =
  | "organisation"
  | "axe"
  | "departement"
  | "objectif"
  | "strategie"
  | "projet"
  | "kpi"
  | "mesure"
  | "rapport"
  | "user"
  | "audit"
  | "import";

type Action = "create" | "read" | "update" | "delete";

export interface UserContext {
  id: string;
  role: string;
  departementId: string | null;
}

// ─── Permission matrix ──────────────────────────────

const PERMISSIONS: Record<Role, Record<Resource, Action[]>> = {
  ADMIN: {
    organisation: ["create", "read", "update", "delete"],
    axe: ["create", "read", "update", "delete"],
    departement: ["create", "read", "update", "delete"],
    objectif: ["create", "read", "update", "delete"],
    strategie: ["create", "read", "update", "delete"],
    projet: ["create", "read", "update", "delete"],
    kpi: ["create", "read", "update", "delete"],
    mesure: ["create", "read", "update", "delete"],
    rapport: ["create", "read", "update", "delete"],
    user: ["create", "read", "update", "delete"],
    audit: ["create", "read", "update", "delete"],
    import: ["create", "read", "update", "delete"],
  },
  DIRECTEUR: {
    organisation: ["read"],
    axe: ["read"],
    departement: ["read", "update"],
    objectif: ["read"],
    strategie: ["create", "read", "update", "delete"],
    projet: ["create", "read", "update", "delete"],
    kpi: ["create", "read", "update", "delete"],
    mesure: ["create", "read", "update", "delete"],
    rapport: ["create", "read", "update", "delete"],
    user: ["read"],
    audit: ["read"],
    import: [],
  },
  CHEF_PROJET: {
    organisation: ["read"],
    axe: ["read"],
    departement: ["read"],
    objectif: ["read"],
    strategie: ["read", "update"],
    projet: ["create", "read", "update"],
    kpi: ["create", "read", "update", "delete"],
    mesure: ["create", "read", "update"],
    rapport: ["read", "update"],
    user: ["read"],
    audit: ["read"],
    import: [],
  },
  CONTRIBUTEUR: {
    organisation: ["read"],
    axe: ["read"],
    departement: ["read"],
    objectif: ["read"],
    strategie: ["read"],
    projet: ["read"],
    kpi: ["read"],
    mesure: ["read", "update"],
    rapport: ["read"],
    user: ["read"],
    audit: ["read"],
    import: [],
  },
  LECTEUR: {
    organisation: ["read"],
    axe: ["read"],
    departement: ["read"],
    objectif: ["read"],
    strategie: ["read"],
    projet: ["read"],
    kpi: ["read"],
    mesure: ["read"],
    rapport: ["read"],
    user: [],
    audit: [],
    import: [],
  },
};

/**
 * Checks whether the user has permission to perform the given action on the resource.
 */
export function checkPermission(
  user: UserContext,
  resource: Resource,
  action: Action
): boolean {
  const rolePerms = PERMISSIONS[user.role as Role];
  if (!rolePerms) return false;
  return rolePerms[resource]?.includes(action) ?? false;
}

/**
 * ADMIN can access all departments; others can only access their own.
 */
export function canAccessDepartement(
  user: UserContext,
  departementId: string
): boolean {
  if (user.role === "ADMIN") return true;
  return user.departementId === departementId;
}

/**
 * Returns the full permission map for a given role (useful for client-side UI).
 */
export function getUserPermissions(
  role: string
): Record<Resource, Action[]> {
  const rolePerms = PERMISSIONS[role as Role];
  if (!rolePerms) {
    const empty: Record<Resource, Action[]> = {
      organisation: [],
      axe: [],
      departement: [],
      objectif: [],
      strategie: [],
      projet: [],
      kpi: [],
      mesure: [],
      rapport: [],
      user: [],
      audit: [],
      import: [],
    };
    return empty;
  }
  // Return a copy to prevent mutation
  const result = {} as Record<Resource, Action[]>;
  for (const [key, actions] of Object.entries(rolePerms)) {
    result[key as Resource] = [...actions];
  }
  return result;
}

export type { Role, Resource, Action };
