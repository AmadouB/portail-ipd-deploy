"use client";

import { createContext, useContext, useState, useCallback, type ReactNode } from "react";
import type { Trimestre } from "./types";

interface TrimestreContextValue {
  /** Currently selected trimestre — null means "all / latest" */
  selectedTrimestre: Trimestre | null;
  /** Set a specific trimestre, or null to show all */
  setSelectedTrimestre: (t: Trimestre | null) => void;
  /** Convenience: is a specific trimestre actively filtered? */
  isFiltered: boolean;
}

const TrimestreContext = createContext<TrimestreContextValue | null>(null);

export function TrimestreProvider({ children }: { children: ReactNode }) {
  const [selectedTrimestre, setSelectedTrimestreRaw] = useState<Trimestre | null>(null);

  const setSelectedTrimestre = useCallback((t: Trimestre | null) => {
    setSelectedTrimestreRaw((prev) => (prev === t ? null : t));
  }, []);

  return (
    <TrimestreContext.Provider
      value={{
        selectedTrimestre,
        setSelectedTrimestre,
        isFiltered: selectedTrimestre !== null,
      }}
    >
      {children}
    </TrimestreContext.Provider>
  );
}

export function useTrimestre(): TrimestreContextValue {
  const ctx = useContext(TrimestreContext);
  if (!ctx) {
    throw new Error("useTrimestre must be used within a TrimestreProvider");
  }
  return ctx;
}
