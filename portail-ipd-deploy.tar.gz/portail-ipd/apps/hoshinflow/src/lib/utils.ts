import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";
import type { KPI, Projet, Trimestre } from "./types";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function getStatutColor(statut: string): string {
  switch (statut) {
    case "COMPLET":
      return "#10b981";
    case "EN_COURS":
      return "#06b6d4";
    case "EN_RETARD":
      return "#ef4444";
    case "EN_ATTENTE":
      return "#f59e0b";
    case "NON_DEMARRE":
      return "#6b7280";
    case "ANNULE":
      return "#71717a";
    case "A_RECONDUIRE":
      return "#8b5cf6";
    default:
      return "#6b7280";
  }
}

export function getStatutLabel(statut: string): string {
  switch (statut) {
    case "COMPLET":
      return "Complet";
    case "EN_COURS":
      return "En cours";
    case "EN_RETARD":
      return "En retard";
    case "EN_ATTENTE":
      return "En attente";
    case "NON_DEMARRE":
      return "Non démarré";
    case "ANNULE":
      return "Annulé";
    case "A_RECONDUIRE":
      return "À reconduire";
    default:
      return statut;
  }
}

export function getTauxColor(taux: number): string {
  if (taux >= 80) return "#10b981";
  if (taux >= 50) return "#06b6d4";
  if (taux >= 20) return "#f59e0b";
  return "#ef4444";
}

export function formatBudget(amount: number | null, devise: string = "FCFA"): string {
  if (amount === null || amount === undefined) return "N/A";
  const formatted = amount.toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ");
  return `${formatted} ${devise}`;
}

export function calculateKpiTaux(realise: number | null, cible: number | null): number {
  if (cible === null || cible === undefined || cible === 0) return 0;
  if (realise === null || realise === undefined) return 0;
  const taux = (realise / cible) * 100;
  return Math.min(Math.round(taux * 10) / 10, 100);
}

/**
 * Calculate projet score. If `forTrimestre` is provided, uses only that
 * trimestre's mesures. Otherwise, uses the latest available mesure per KPI.
 */
export function calculateProjetScore(kpis: KPI[], forTrimestre?: Trimestre | null): number {
  if (!kpis || kpis.length === 0) return 0;

  const kpiScores = kpis.map((kpi) => {
    if (forTrimestre) {
      const mesure = kpi.mesures.find(
        (m) => m.trimestre === forTrimestre && m.realise !== null && m.cible !== null
      );
      return mesure ? calculateKpiTaux(mesure.realise, mesure.cible) : 0;
    }
    // Fallback: latest available
    const trimestresOrder: Trimestre[] = ["T4", "T3", "T2", "T1"];
    for (const tri of trimestresOrder) {
      const mesure = kpi.mesures.find(
        (m) => m.trimestre === tri && m.realise !== null && m.cible !== null
      );
      if (mesure) {
        return calculateKpiTaux(mesure.realise, mesure.cible);
      }
    }
    return 0;
  });

  const total = kpiScores.reduce((sum, score) => sum + score, 0);
  return Math.round((total / kpiScores.length) * 10) / 10;
}

export function calculateStrategieCompletion(projets: Projet[]): number {
  if (!projets || projets.length === 0) return 0;

  const scores = projets.map((projet) => {
    if (projet.scorePerformance !== undefined) return projet.scorePerformance;
    return calculateProjetScore(projet.kpis);
  });

  const total = scores.reduce((sum, score) => sum + score, 0);
  return Math.round((total / scores.length) * 10) / 10;
}

export function getTrimestreLabel(trimestre: Trimestre): string {
  switch (trimestre) {
    case "T1":
      return "Trimestre 1";
    case "T2":
      return "Trimestre 2";
    case "T3":
      return "Trimestre 3";
    case "T4":
      return "Trimestre 4";
  }
}

export function getProgressBarColor(taux: number): string {
  if (taux >= 80) return "bg-emerald-500";
  if (taux >= 50) return "bg-cyan-500";
  if (taux >= 20) return "bg-amber-500";
  return "bg-red-500";
}

export function getStatutBadgeClasses(statut: string): string {
  switch (statut) {
    case "COMPLET":
      return "bg-emerald-500/20 text-emerald-400 border-emerald-500/30";
    case "EN_COURS":
      return "bg-cyan-500/20 text-cyan-400 border-cyan-500/30";
    case "EN_RETARD":
      return "bg-red-500/20 text-red-400 border-red-500/30";
    case "EN_ATTENTE":
      return "bg-amber-500/20 text-amber-400 border-amber-500/30";
    case "NON_DEMARRE":
      return "bg-gray-500/20 text-gray-400 border-gray-500/30";
    case "ANNULE":
      return "bg-zinc-500/20 text-zinc-400 border-zinc-500/30";
    case "A_RECONDUIRE":
      return "bg-violet-500/20 text-violet-400 border-violet-500/30";
    default:
      return "bg-gray-500/20 text-gray-400 border-gray-500/30";
  }
}
