/**
 * ══════════════════════════════════════════════════════════
 * Hoshin import service
 * ══════════════════════════════════════════════════════════
 * Takes a parsed HoshinData JSON and upserts it into the
 * PostgreSQL database. Departments / Axes / Objectifs / BTGs
 * are assumed to exist (created by the initial seed).
 *
 * Strategy: per-department reset
 *   For each department in the import data:
 *     1. Delete all its existing strategies + projets + KPIs + mesures
 *        + projetBtgs + projetContributeurs.
 *     2. Re-create everything from the new data.
 *
 * This avoids stale records but preserves audit history (kept).
 */

import { prisma } from "@/lib/prisma";
import type { HoshinData } from "./excel-parser";

function pad(n: number, w: number): string {
  return String(n).padStart(w, "0");
}

function mapStatut(s: string): string {
  const t = (s || "").trim().toLowerCase();
  if (!t) return "NON_DEMARRE";
  if (t.includes("annul")) return "ANNULE";
  if (t.includes("reconduire") || t.includes("reconduit")) return "A_RECONDUIRE";
  if (t.includes("complet") || t.includes("termin")) return "COMPLET";
  if (t.includes("retard")) return "EN_RETARD";
  if (t.includes("attente")) return "EN_ATTENTE";
  if (t.includes("cours")) return "EN_COURS";
  return "NON_DEMARRE";
}

export interface ImportResult {
  success: boolean;
  affectedDepartements: string[];
  unknownDepartements: string[];
  counts: {
    strategies: number;
    projets: number;
    kpis: number;
    mesures: number;
    projetBtgs: number;
    contributeurs: number;
  };
  durationMs: number;
}

export async function importHoshinData(
  data: HoshinData,
  userId: string | null
): Promise<ImportResult> {
  const start = Date.now();

  // Lookups
  const departements = await prisma.departement.findMany();
  const depByCode = new Map(departements.map((d) => [d.code, d]));

  const objectifs = await prisma.objectifStrategique.findMany({
    orderBy: { ordre: "asc" },
  });
  const objectifIds = objectifs.map((o) => o.id);

  const affectedDepartements: string[] = [];
  const unknownDepartements: string[] = [];

  // ─── Per-department reset ──────────────────────────────
  for (const dept of data.departments) {
    const dep = depByCode.get(dept.code);
    if (!dep) {
      unknownDepartements.push(dept.code);
      continue;
    }
    affectedDepartements.push(dept.code);

    // Find all existing strategies for this department to cascade-delete their dependencies
    const existingStrategies = await prisma.strategieDepartementale.findMany({
      where: { departementId: dep.id },
      select: { id: true },
    });
    const stratIds = existingStrategies.map((s) => s.id);

    if (stratIds.length > 0) {
      const projetsForDept = await prisma.projet.findMany({
        where: { strategieId: { in: stratIds } },
        select: { id: true },
      });
      const projetIds = projetsForDept.map((p) => p.id);

      if (projetIds.length > 0) {
        const kpisForDept = await prisma.kPI.findMany({
          where: { projetId: { in: projetIds } },
          select: { id: true },
        });
        const kpiIds = kpisForDept.map((k) => k.id);

        if (kpiIds.length > 0) {
          await prisma.mesureKPI.deleteMany({ where: { kpiId: { in: kpiIds } } });
        }
        await prisma.kPI.deleteMany({ where: { projetId: { in: projetIds } } });
        await prisma.projetBTG.deleteMany({ where: { projetId: { in: projetIds } } });
        await prisma.projetContributeur.deleteMany({
          where: { projetId: { in: projetIds } },
        });
        // LigneRapport may reference projets — null them out so deletion succeeds
        await prisma.ligneRapport
          .updateMany({
            where: { projetId: { in: projetIds } },
            data: { projetId: null },
          })
          .catch(() => {
            // Older DB may not have this table — safe to ignore
          });
      }
      await prisma.projet.deleteMany({ where: { strategieId: { in: stratIds } } });
      await prisma.strategieDepartementale.deleteMany({
        where: { id: { in: stratIds } },
      });
    }
  }

  // ─── Re-create from fresh data ──────────────────────────
  let stratCount = 0;
  let projetCount = 0;
  let kpiCount = 0;
  let mesureCount = 0;
  let pbtgCount = 0;
  let contribCount = 0;

  // Use timestamp-prefixed IDs to avoid collisions with seed-generated IDs
  const ts = Date.now().toString(36);

  // Round-robin OS assignment across the import
  let osIdx = 0;

  for (const dept of data.departments) {
    const dep = depByCode.get(dept.code);
    if (!dep) continue;

    for (const stratDef of dept.strategies) {
      stratCount++;
      const strategieId = `imp-${ts}-str-${pad(stratCount, 4)}`;
      const osId = objectifIds.length > 0 ? objectifIds[osIdx % objectifIds.length] : null;
      osIdx++;

      if (!osId) continue; // safety

      await prisma.strategieDepartementale.create({
        data: {
          id: strategieId,
          objectifStrategiqueId: osId,
          departementId: dep.id,
          code: `S-${dep.code}-${pad(stratCount, 2)}`,
          libelle: stratDef.ref,
          responsable: null,
          statut: "NON_DEMARRE",
        },
      });

      for (const pDef of stratDef.projets) {
        projetCount++;
        const projetId = `imp-${ts}-prj-${pad(projetCount, 4)}`;

        await prisma.projet.create({
          data: {
            id: projetId,
            strategieId,
            code: `P-${pad(projetCount, 4)}`,
            libelle: pDef.libelle,
            responsable: pDef.owner,
            statut: mapStatut(pDef.statut),
            financeur: pDef.financeur || null,
            budgetAlloue: null,
            budgetDepense: null,
            devise: "FCFA",
            commentaire: null,
          },
        });

        // KPIs
        for (let ki = 0; ki < pDef.kpis.length; ki++) {
          kpiCount++;
          const kpiId = `imp-${ts}-kpi-${pad(kpiCount, 4)}`;
          const label = pDef.kpis[ki];
          const isPercent =
            label.toLowerCase().includes("%") ||
            label.toLowerCase().includes("taux") ||
            label.toLowerCase().includes("pourcentage");
          const isBool =
            label.toUpperCase() === "Y/N" || label.toLowerCase().includes("y/n");

          await prisma.kPI.create({
            data: {
              id: kpiId,
              projetId,
              code: `KPI-${pad(kpiCount, 4)}`,
              libelle: label,
              modeCalcul: isPercent ? "POURCENTAGE" : isBool ? "BOOLEEN" : "SOMME",
              unite: isPercent ? "%" : isBool ? "O/N" : "unite",
              valeurReference: null,
              ordre: ki + 1,
            },
          });

          // Mesures T1..T4 — empty by default for fresh imports
          const trimestres: ("T1" | "T2" | "T3" | "T4")[] = ["T1", "T2", "T3", "T4"];
          for (const tri of trimestres) {
            mesureCount++;
            await prisma.mesureKPI.create({
              data: {
                id: `imp-${ts}-mes-${pad(mesureCount, 5)}`,
                kpiId,
                annee: 2025,
                trimestre: tri,
                cible: null,
                realise: null,
                tauxCompletion: null,
                commentaire: null,
              },
            });
          }
        }

        // BTGs
        for (const btgNum of pDef.btgs) {
          pbtgCount++;
          await prisma.projetBTG.create({
            data: {
              id: `imp-${ts}-pbtg-${pad(pbtgCount, 4)}`,
              projetId,
              btgId: `btg-${pad(btgNum, 3)}`,
              indicateurBinaire: false,
            },
          });
        }

        // Contributors
        for (let ci = 0; ci < pDef.contributors.length; ci++) {
          contribCount++;
          const contribName = pDef.contributors[ci];
          const contribDep = departements.find((d) => d.code === contribName);
          await prisma.projetContributeur.create({
            data: {
              id: `imp-${ts}-contrib-${pad(contribCount, 4)}`,
              projetId,
              departementId: contribDep ? contribDep.id : dep.id,
              nom: contribName,
              rang: ci + 1,
            },
          });
        }
      }
    }
  }

  const result: ImportResult = {
    success: true,
    affectedDepartements,
    unknownDepartements,
    counts: {
      strategies: stratCount,
      projets: projetCount,
      kpis: kpiCount,
      mesures: mesureCount,
      projetBtgs: pbtgCount,
      contributeurs: contribCount,
    },
    durationMs: Date.now() - start,
  };

  // Audit log
  await prisma.auditLog.create({
    data: {
      userId,
      action: "IMPORT",
      entityType: "Hoshin",
      entityId: "excel",
      newValue: JSON.stringify(result),
      description: `Import Excel — ${affectedDepartements.length} departements`,
    },
  });

  return result;
}
