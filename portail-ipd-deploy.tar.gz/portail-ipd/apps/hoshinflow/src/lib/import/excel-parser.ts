/**
 * ══════════════════════════════════════════════════════════
 * Excel parser for the IPD Hoshin file
 * ══════════════════════════════════════════════════════════
 * Reads the same structure used by `prisma/seed.ts` (HoshinData)
 * from a buffer (uploaded .xlsx) and returns a typed JSON.
 *
 * Two sheets are read:
 *   1. "HOSHIN - Fev2025"  — main sheet (departments × strategies × projects × KPIs × BTGs × owner)
 *   2. "V. OUTPUT Template" (optional) — adds reference codes + statut + budget
 */

import * as XLSX from "xlsx";

export interface ProjetDef {
  ref: string;
  libelle: string;
  owner: string | null;
  statut: string;
  kpis: string[];
  btgs: number[];
  financeur: string;
  contributors: string[];
}

export interface StrategyDef {
  ref: string;
  projets: ProjetDef[];
}

export interface DeptDef {
  code: string;
  strategies: StrategyDef[];
}

export interface HoshinData {
  departments: DeptDef[];
}

const HOSHIN_SHEET = "HOSHIN - Fev2025";
const OUTPUT_SHEET = "V. OUTPUT Template";

// ─── Helpers ──────────────────────────────────────────────

function normalizeDeptCode(raw: string): string {
  const t = String(raw || "").trim();
  // Merge DSP Surv / DSP SS / DSP RC under "DSP"
  if (t.startsWith("DSP")) return "DSP";
  if (t === "CODIR") return "CODIR";
  return t;
}

function cleanText(v: unknown): string {
  if (v === null || v === undefined) return "";
  return String(v).replace(/\r/g, "").trim();
}

function parseBtgs(row: unknown[]): number[] {
  // Columns 2..6 = BTG1..BTG5 (x means linked)
  const btgs: number[] = [];
  for (let i = 0; i < 5; i++) {
    const cell = cleanText(row[2 + i]).toLowerCase();
    if (cell === "x" || cell === "1") btgs.push(i + 1);
  }
  return btgs;
}

function parseContributors(row: unknown[]): string[] {
  // Columns 14..16 = Secondary, Secondary2, Secondary3
  const contrib: string[] = [];
  for (let i = 14; i <= 16; i++) {
    const v = cleanText(row[i]);
    if (v) contrib.push(v);
  }
  return contrib;
}

function parseKpis(row: unknown[]): string[] {
  // Columns 8..12 = KPI1..KPI5
  const kpis: string[] = [];
  for (let i = 8; i <= 12; i++) {
    const v = cleanText(row[i]);
    if (v) kpis.push(v);
  }
  return kpis;
}

// ─── Main parser ──────────────────────────────────────────

export function parseHoshinExcel(buffer: Buffer | ArrayBuffer): HoshinData {
  const wb = XLSX.read(buffer, { type: "buffer" });

  if (!wb.SheetNames.includes(HOSHIN_SHEET)) {
    throw new Error(
      `Feuille manquante: "${HOSHIN_SHEET}". Feuilles trouvees: ${wb.SheetNames.join(", ")}`
    );
  }

  const main = wb.Sheets[HOSHIN_SHEET];
  const rows: unknown[][] = XLSX.utils.sheet_to_json(main, {
    header: 1,
    defval: "",
  });

  // First two rows = title + header. Data starts at row 2.
  const deptMap = new Map<string, Map<string, ProjetDef[]>>();

  let currentDept = "";
  let currentStrat = "";

  for (let i = 2; i < rows.length; i++) {
    const row = rows[i];
    if (!row || row.length === 0) continue;

    const deptRaw = cleanText(row[0]);
    if (deptRaw) currentDept = normalizeDeptCode(deptRaw);

    const stratRaw = cleanText(row[1]);
    if (stratRaw) currentStrat = stratRaw;

    const delivrable = cleanText(row[7]);
    if (!currentDept || !currentStrat || !delivrable) continue;

    if (!deptMap.has(currentDept)) deptMap.set(currentDept, new Map());
    const stratMap = deptMap.get(currentDept)!;
    if (!stratMap.has(currentStrat)) stratMap.set(currentStrat, []);

    const owner = cleanText(row[13]);
    const projet: ProjetDef = {
      ref: "", // filled below from OUTPUT sheet
      libelle: delivrable,
      owner: owner || null,
      statut: "",
      kpis: parseKpis(row),
      btgs: parseBtgs(row),
      financeur: "",
      contributors: parseContributors(row),
    };

    stratMap.get(currentStrat)!.push(projet);
  }

  // ─── Optional: read V. OUTPUT Template for refs + statut + budget ──
  if (wb.SheetNames.includes(OUTPUT_SHEET)) {
    const out = wb.Sheets[OUTPUT_SHEET];
    const outRows: unknown[][] = XLSX.utils.sheet_to_json(out, {
      header: 1,
      defval: "",
    });

    // Find header row (contains "Reference Projet-KPI")
    let headerIdx = -1;
    let refCol = -1;
    let statutCol = -1;
    let budgetCol = -1;
    let projetCol = -1;
    for (let i = 0; i < Math.min(10, outRows.length); i++) {
      const cells = outRows[i].map((c) => cleanText(c));
      const ri = cells.findIndex((c) => c.includes("Reference Projet-KPI"));
      if (ri >= 0) {
        headerIdx = i;
        refCol = ri;
        statutCol = cells.findIndex((c) => c.includes("Statut Objectif"));
        budgetCol = cells.findIndex(
          (c) => c.includes("Bailleur") || c.includes("Budget")
        );
        projetCol = cells.findIndex((c) => c.includes("OBJECTIFS/PROJETS"));
        break;
      }
    }

    if (headerIdx >= 0 && refCol >= 0 && projetCol >= 0) {
      // Build a lookup: projet libelle prefix → { ref, statut, budget }
      const refByLibelle = new Map<
        string,
        { ref: string; statut: string; budget: string }
      >();
      for (let i = headerIdx + 1; i < outRows.length; i++) {
        const r = outRows[i];
        const ref = cleanText(r[refCol]);
        const projetLib = cleanText(r[projetCol]);
        if (!ref || !projetLib) continue;
        const key = projetLib.substring(0, 30).toLowerCase();
        refByLibelle.set(key, {
          ref,
          statut: statutCol >= 0 ? cleanText(r[statutCol]) : "",
          budget: budgetCol >= 0 ? cleanText(r[budgetCol]) : "",
        });
      }

      // Apply to deptMap entries
      for (const stratMap of deptMap.values()) {
        for (const projets of stratMap.values()) {
          for (const p of projets) {
            const key = p.libelle.substring(0, 30).toLowerCase();
            const meta = refByLibelle.get(key);
            if (meta) {
              p.ref = meta.ref;
              p.statut = meta.statut;
              p.financeur = meta.budget;
            }
          }
        }
      }
    }
  }

  // ─── Convert maps to arrays ──
  const departments: DeptDef[] = [];
  for (const [code, stratMap] of deptMap.entries()) {
    const strategies: StrategyDef[] = [];
    for (const [stratRef, projets] of stratMap.entries()) {
      strategies.push({ ref: stratRef, projets });
    }
    departments.push({ code, strategies });
  }

  return { departments };
}

export function summarize(data: HoshinData): {
  departments: number;
  strategies: number;
  projets: number;
  kpis: number;
} {
  let strategies = 0;
  let projets = 0;
  let kpis = 0;
  for (const d of data.departments) {
    strategies += d.strategies.length;
    for (const s of d.strategies) {
      projets += s.projets.length;
      for (const p of s.projets) kpis += p.kpis.length;
    }
  }
  return { departments: data.departments.length, strategies, projets, kpis };
}
