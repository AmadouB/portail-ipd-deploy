/**
 * ══════════════════════════════════════════════════════════
 * Strategic Plan parser — IPD HOSHIN v2026 — Stratégie CoDirection
 * ══════════════════════════════════════════════════════════
 *
 * Le fichier Excel contient plusieurs feuilles "Strategié *" qui
 * définissent chacune un plan stratégique de niveau direction
 * (Scientifique, COO, CHC, CoDir, Investiment Case).
 *
 * Structure de chaque feuille (12 colonnes) :
 *   Col 0:  BTG 2026–32        (✅ BTG1 — ..., fill-down)
 *   Col 1:  Direction / Department
 *   Col 2:  Investiment Case 2026-32 (fill-down)
 *   Col 3:  Strategy [Scientifique|CHC|...]
 *   Col 4:  Ref Code            (ex: SCI-1, DSP-1, CRIP-1)
 *   Col 5:  Objectives / Projects
 *   Col 6:  Priorité
 *   Col 7:  KPI
 *   Col 8:  Owner Rôle/Position
 *   Col 9:  Contributeurs
 *   Col 10: Date limite
 *   Col 11: Bailleur / Budget
 *
 * La feuille "Strategié Codir - 2025-26" intervertit Direction et
 * Investment Case, et ajoute une colonne "Année".
 *
 * Le parser :
 *   1. Détecte la ligne d'en-tête (contient "BTG 2026" ou "Investiment Case")
 *   2. Mappe les colonnes par leur libellé
 *   3. Applique le fill-down sur BTG, Investment Case, Strategy
 *   4. Groupe les lignes par (BTG, Investment Case, Strategy) en Axes
 *      contenant chacun N actions.
 */

import * as XLSX from "xlsx";

export interface MesureSP {
  libelle: string;
  cible?: string;
  unite?: string;
}

export interface ActionSP {
  refCode?: string;
  quoi: string;
  direction?: string;
  responsable?: string;
  contributeurs?: string;
  priorite?: number;
  deadline?: string;
  bailleurBudget?: string;
  mesures: MesureSP[];
}

export interface AxeSP {
  libelle: string;
  groupe?: string;          // BTG label
  investmentCase?: string;
  ordre: number;
  actions: ActionSP[];
}

export interface PlanSP {
  code: string;
  nom: string;
  objectif: string;
  description?: string;
  source?: string;
  axes: AxeSP[];
}

export interface ParseResult {
  plans: PlanSP[];
  /** Feuilles ignorées (non reconnues comme plans) */
  skippedSheets: string[];
}

// ─── Helpers ──────────────────────────────────────────────

function clean(v: unknown): string {
  if (v === null || v === undefined) return "";
  return String(v).replace(/\r/g, "").trim();
}

function asNumber(v: unknown): number | undefined {
  if (v === null || v === undefined || v === "") return undefined;
  if (typeof v === "number" && !Number.isNaN(v)) return v;
  const n = Number(String(v).replace(",", "."));
  return Number.isFinite(n) ? n : undefined;
}

function isStrategySheet(name: string): boolean {
  const t = name.toLowerCase();
  return (
    /^strateg/i.test(t) ||
    /^investiment\s*case/i.test(t) ||
    /^investment\s*case/i.test(t) ||
    t === "all data"
  );
}

function slugify(s: string): string {
  return s
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .replace(/[^A-Za-z0-9]+/g, "-")
    .replace(/^-|-$/g, "")
    .toUpperCase()
    .slice(0, 60);
}

// ─── Column mapping ──────────────────────────────────────

interface ColMap {
  btg: number;
  direction: number;
  investmentCase: number;
  strategy: number;
  refCode: number;
  project: number;
  priorite: number;
  kpi: number;
  owner: number;
  contributeurs: number;
  deadline: number;
  budget: number;
}

function detectColumns(rows: string[][]): { headerIdx: number; cols: ColMap } | null {
  for (let i = 0; i < Math.min(8, rows.length); i++) {
    const r = rows[i].map((c) => clean(c).toLowerCase());
    const btg = r.findIndex((c) => /^btg\b/.test(c) || c.startsWith("btg "));
    const investment = r.findIndex(
      (c) => c.includes("investiment case") || c.includes("investment case")
    );
    const strategy = r.findIndex((c) => /^strategy\b|^strat[eé]gie\b/.test(c));
    if (btg < 0 || investment < 0) continue;

    const direction = r.findIndex(
      (c) =>
        c.includes("direction / department") ||
        c.startsWith("direction") ||
        c.startsWith("departement")
    );
    const refCode = r.findIndex((c) => c === "ref code" || c.includes("ref code"));
    const project = r.findIndex(
      (c) => c.includes("objectives / projects") || c.includes("objective")
    );
    const priorite = r.findIndex((c) => c.startsWith("priorit"));
    const kpi = r.findIndex((c) => c === "kpi" || c.startsWith("kpi"));
    const owner = r.findIndex(
      (c) => c.startsWith("owner") || c.includes("rôle") || c.includes("role")
    );
    const contributeurs = r.findIndex((c) => c.startsWith("contribut"));
    const deadline = r.findIndex(
      (c) => c.startsWith("date") || c.includes("limite") || c.includes("échéance")
    );
    const budget = r.findIndex(
      (c) => c.startsWith("bailleur") || c.startsWith("budget")
    );

    return {
      headerIdx: i,
      cols: {
        btg,
        direction: direction >= 0 ? direction : 1,
        investmentCase: investment,
        strategy: strategy >= 0 ? strategy : 3,
        refCode: refCode >= 0 ? refCode : 4,
        project: project >= 0 ? project : 5,
        priorite: priorite >= 0 ? priorite : 6,
        kpi: kpi >= 0 ? kpi : 7,
        owner: owner >= 0 ? owner : 8,
        contributeurs: contributeurs >= 0 ? contributeurs : 9,
        deadline: deadline >= 0 ? deadline : 10,
        budget: budget >= 0 ? budget : 11,
      },
    };
  }
  return null;
}

// ─── Parse one sheet into a Plan ─────────────────────────

function parseSheet(
  rawRows: unknown[][],
  sheetName: string,
  fileName?: string
): PlanSP | null {
  const rows: string[][] = rawRows.map((r) => r.map((c) => clean(c)));

  const det = detectColumns(rows);
  if (!det) return null;

  const { headerIdx, cols } = det;

  let curBtg = "";
  let curInvest = "";
  let curStrategy = "";

  // Group key → axe
  const axesByKey = new Map<string, AxeSP>();
  let order = 0;

  for (let i = headerIdx + 1; i < rows.length; i++) {
    const r = rows[i];
    if (!r || r.every((c) => !c.trim())) continue;

    const btg = r[cols.btg];
    const invest = r[cols.investmentCase];
    const strategy = r[cols.strategy];

    if (btg) curBtg = btg;
    if (invest) curInvest = invest;
    if (strategy) curStrategy = strategy;

    const refCode = cols.refCode >= 0 ? r[cols.refCode] : "";
    const project = cols.project >= 0 ? r[cols.project] : "";
    const kpi = cols.kpi >= 0 ? r[cols.kpi] : "";

    // We need at least a project or a refCode to consider this a real action
    if (!project && !refCode) continue;
    if (!curStrategy) continue;

    const groupKey = `${curBtg}||${curInvest}||${curStrategy}`;
    if (!axesByKey.has(groupKey)) {
      axesByKey.set(groupKey, {
        libelle: curStrategy,
        groupe: curBtg || undefined,
        investmentCase: curInvest || undefined,
        ordre: order++,
        actions: [],
      });
    }
    const axe = axesByKey.get(groupKey)!;

    const action: ActionSP = {
      refCode: refCode || undefined,
      quoi: project || refCode || "(non renseigné)",
      direction: cols.direction >= 0 ? r[cols.direction] || undefined : undefined,
      responsable: cols.owner >= 0 ? r[cols.owner] || undefined : undefined,
      contributeurs:
        cols.contributeurs >= 0 ? r[cols.contributeurs] || undefined : undefined,
      priorite: cols.priorite >= 0 ? asNumber(r[cols.priorite]) : undefined,
      deadline: cols.deadline >= 0 ? r[cols.deadline] || undefined : undefined,
      bailleurBudget: cols.budget >= 0 ? r[cols.budget] || undefined : undefined,
      mesures: kpi ? [{ libelle: kpi }] : [],
    };

    axe.actions.push(action);
  }

  if (axesByKey.size === 0) return null;

  // Build the plan
  const cleanSheetName = sheetName.replace(/^Strateg[ié]é?\s*/i, "").trim();
  const code = slugify(`PLAN-${cleanSheetName || sheetName}`);
  const nom = sheetName;
  // Use first BTG line or sheet title as objectif
  const objectif =
    Array.from(axesByKey.values())[0]?.groupe ||
    `Plan stratégique — ${sheetName}`;

  return {
    code,
    nom,
    objectif,
    source: fileName,
    axes: Array.from(axesByKey.values()),
  };
}

// ─── Public API ──────────────────────────────────────────

export function parseStrategyExcel(
  buffer: Buffer | ArrayBuffer,
  opts: { fileName?: string; sheetNames?: string[] } = {}
): ParseResult {
  const wb = XLSX.read(buffer, { type: "buffer" });

  const targetSheets = opts.sheetNames
    ? wb.SheetNames.filter((n) => opts.sheetNames!.includes(n))
    : wb.SheetNames.filter((n) => isStrategySheet(n));

  const plans: PlanSP[] = [];
  const skipped: string[] = [];

  for (const sheetName of wb.SheetNames) {
    if (!targetSheets.includes(sheetName)) {
      skipped.push(sheetName);
      continue;
    }
    const ws = wb.Sheets[sheetName];
    const rows: unknown[][] = XLSX.utils.sheet_to_json(ws, {
      header: 1,
      defval: "",
    });
    const plan = parseSheet(rows, sheetName, opts.fileName);
    if (plan) {
      plans.push(plan);
    } else {
      skipped.push(sheetName);
    }
  }

  return { plans, skippedSheets: skipped };
}

export function summarize(plans: PlanSP[]) {
  let axes = 0;
  let actions = 0;
  let mesures = 0;
  for (const p of plans) {
    axes += p.axes.length;
    for (const a of p.axes) {
      actions += a.actions.length;
      for (const ac of a.actions) mesures += ac.mesures.length;
    }
  }
  return {
    plans: plans.length,
    axes,
    actions,
    mesures,
  };
}
