/**
 * ══════════════════════════════════════════════════════════
 * OGSM Excel parser
 * ══════════════════════════════════════════════════════════
 * Parse une feuille OGSM (Objectives, Goals, Strategies, Measures)
 * tirée du Drive IPD (data-and-analytics-teams-Strategie).
 *
 * Structure attendue (cf. "OGSM AFM" sheet) :
 *   Col 0: OBJECTIF        (rempli sur la première ligne de données)
 *   Col 1: BUTS            (rempli sur la première ligne de données)
 *   Col 2: AXES STRATEGIQUES (fill-down — défini une fois par axe)
 *   Col 3: PLAN D'ACTION (QUOI)
 *   Col 4: COMMENT (détails)
 *   Col 5: MESURE (KPI avec ✅)
 *
 * Le parser :
 *   1. Localise la 1ère ligne de données (après les en-têtes)
 *   2. Applique le fill-down sur AXES
 *   3. Émet une structure { plan, buts, axes[{ actions[{ mesures[] }] }] }
 */

import * as XLSX from "xlsx";

export interface MesureOGSM {
  libelle: string;
  cible?: string;
  unite?: string;
}

export interface ActionOGSM {
  quoi: string;
  comment?: string;
  ressource?: string;
  mesures: MesureOGSM[];
}

export interface AxeOGSM {
  libelle: string;
  ordre: number;
  actions: ActionOGSM[];
}

export interface ButOGSM {
  libelle: string;
  cible?: string;
}

export interface PlanOGSM {
  code: string;
  nom: string;
  objectif: string;
  description?: string;
  anneeDepart?: number;
  anneeCible?: number;
  source?: string;
  buts: ButOGSM[];
  axes: AxeOGSM[];
}

// ─── Helpers ──────────────────────────────────────────────

function clean(v: unknown): string {
  if (v === null || v === undefined) return "";
  return String(v).replace(/\r/g, "").trim();
}

function isHeaderText(v: string): boolean {
  const t = v.toUpperCase();
  return (
    t === "OBJECTIF" ||
    t === "BUTS" ||
    t === "STRATEGIE" ||
    t === "STRATÉGIE" ||
    t === "AXES STRATEGIQUES" ||
    t === "AXES STRATÉGIQUES" ||
    t === "PLAN D'ACTION" ||
    t === "MESURE" ||
    t === "MESURES" ||
    t === "QUOI" ||
    t === "COMMENT"
  );
}

function detectColumns(rows: string[][]): {
  objectif: number;
  buts: number;
  axe: number;
  quoi: number;
  comment: number;
  mesure: number;
  headerEnd: number;
} | null {
  // Look for the row containing "AXES STRATEGIQUES" or "OBJECTIF" + "BUTS"
  for (let i = 0; i < Math.min(8, rows.length); i++) {
    const r = rows[i].map((c) => clean(c).toUpperCase());
    const objIdx = r.findIndex((c) => c === "OBJECTIF");
    const butsIdx = r.findIndex((c) => c === "BUTS");
    const axeIdx = r.findIndex(
      (c) => c === "AXES STRATEGIQUES" || c === "AXES STRATÉGIQUES"
    );
    if (objIdx >= 0 && butsIdx >= 0) {
      // Look at next row for sub-headers (QUOI / COMMENT)
      const next = (rows[i + 1] || []).map((c) => clean(c).toUpperCase());
      const quoiIdx = next.findIndex((c) => c === "QUOI");
      const commentIdx = next.findIndex((c) => c === "COMMENT");
      // Mesure may share header row
      const mesIdx = r.findIndex((c) => c === "MESURE" || c === "MESURES");
      // Fallback: assume column = axeIdx + 1 (QUOI) and axeIdx + 2 (COMMENT)
      const quoi = quoiIdx >= 0 ? quoiIdx : axeIdx >= 0 ? axeIdx + 1 : 3;
      const comment = commentIdx >= 0 ? commentIdx : quoi + 1;
      const mesure = mesIdx >= 0 ? mesIdx : comment + 1;
      // Header ends at the row after sub-headers (if present)
      const headerEnd =
        quoiIdx >= 0 || commentIdx >= 0 ? i + 2 : i + 1;
      return {
        objectif: objIdx,
        buts: butsIdx,
        axe: axeIdx >= 0 ? axeIdx : 2,
        quoi,
        comment,
        mesure,
        headerEnd,
      };
    }
  }
  return null;
}

function pickPlanMeta(
  rows: string[][],
  fileName: string
): { code: string; nom: string; description?: string } {
  // Try first 3 rows for a plan name
  let nom = "";
  let description = "";
  for (let i = 0; i < Math.min(3, rows.length); i++) {
    const cells = rows[i].map(clean).filter((c) => c && !isHeaderText(c));
    if (!cells.length) continue;
    if (!nom) nom = cells[0];
    else if (!description) description = cells[0];
  }
  // Build code from filename or nom
  const base = fileName.replace(/\.[^.]+$/, "").replace(/[^A-Za-z0-9]+/g, "-");
  const code = base.toUpperCase().slice(0, 60) || "PLAN-OGSM";
  return {
    code,
    nom: nom || fileName.replace(/\.[^.]+$/, ""),
    description: description || undefined,
  };
}

// ─── Main entry ───────────────────────────────────────────

export interface ParseOptions {
  fileName?: string;
  sheetName?: string;
  /** Override le code et le nom du plan */
  planCode?: string;
  planNom?: string;
}

export function parseOGSMExcel(
  buffer: Buffer | ArrayBuffer,
  opts: ParseOptions = {}
): PlanOGSM {
  const wb = XLSX.read(buffer, { type: "buffer" });

  // Choose the most likely sheet
  let sheetName = opts.sheetName;
  if (!sheetName) {
    // Prefer "OGSM AFM" / "OGSM <NAME>" — concise version
    const candidates = [
      ...wb.SheetNames.filter((n) => /^OGSM\s+\w+/i.test(n) && !/DETAIL/i.test(n)),
      ...wb.SheetNames.filter((n) => /^OGSM/i.test(n)),
      wb.SheetNames[0],
    ];
    sheetName = candidates[0];
  }

  const ws = wb.Sheets[sheetName];
  if (!ws) {
    throw new Error(
      `Feuille "${sheetName}" introuvable. Feuilles disponibles : ${wb.SheetNames.join(", ")}`
    );
  }

  const raw: unknown[][] = XLSX.utils.sheet_to_json(ws, {
    header: 1,
    defval: "",
  });
  const rows: string[][] = raw.map((r) => r.map((c) => clean(c)));

  const cols = detectColumns(rows);
  if (!cols) {
    throw new Error(
      "Structure OGSM non détectée — colonnes attendues : OBJECTIF, BUTS, AXES STRATEGIQUES, PLAN D'ACTION, MESURE."
    );
  }

  const meta = pickPlanMeta(rows, opts.fileName || sheetName);

  // ─── Iterate data rows ───
  const buts: ButOGSM[] = [];
  const axesByLib = new Map<string, AxeOGSM>();
  const axesOrder: string[] = []; // preserves first-seen order

  let currentObjectif = "";
  let currentAxe = "";

  for (let i = cols.headerEnd; i < rows.length; i++) {
    const r = rows[i];
    if (!r || r.every((c) => !c.trim())) continue;

    const objCell = r[cols.objectif];
    const butCell = r[cols.buts];
    const axeCell = r[cols.axe];
    const quoiCell = r[cols.quoi];
    const commentCell = r[cols.comment];
    const mesureCell = r[cols.mesure];

    if (objCell) currentObjectif = objCell;

    if (butCell) {
      buts.push({ libelle: butCell });
    }

    if (axeCell) currentAxe = axeCell;

    if (!quoiCell && !commentCell && !mesureCell) continue;
    if (!currentAxe) continue;

    if (!axesByLib.has(currentAxe)) {
      axesByLib.set(currentAxe, {
        libelle: currentAxe,
        ordre: axesOrder.length,
        actions: [],
      });
      axesOrder.push(currentAxe);
    }
    const axe = axesByLib.get(currentAxe)!;

    // Skip rows that have only mesure (orphan measure attaches to last action)
    if (quoiCell || commentCell) {
      const action: ActionOGSM = {
        quoi: quoiCell || "(non renseigné)",
        comment: commentCell || undefined,
        mesures: [],
      };
      if (mesureCell) action.mesures.push({ libelle: mesureCell });
      axe.actions.push(action);
    } else if (mesureCell) {
      const last = axe.actions[axe.actions.length - 1];
      if (last) last.mesures.push({ libelle: mesureCell });
    }
  }

  const plan: PlanOGSM = {
    code: opts.planCode || meta.code,
    nom: opts.planNom || meta.nom,
    objectif: currentObjectif || meta.description || meta.nom,
    description: meta.description,
    source: opts.fileName,
    buts,
    axes: Array.from(axesByLib.values()),
  };

  return plan;
}

export function summarizeOGSM(plan: PlanOGSM) {
  let actions = 0;
  let mesures = 0;
  for (const a of plan.axes) {
    actions += a.actions.length;
    for (const ac of a.actions) mesures += ac.mesures.length;
  }
  return {
    buts: plan.buts.length,
    axes: plan.axes.length,
    actions,
    mesures,
  };
}
