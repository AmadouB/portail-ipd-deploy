/**
 * ══════════════════════════════════════════════════════════
 * Strategic Plan import — service
 * ══════════════════════════════════════════════════════════
 *
 * Pour chaque plan détecté dans l'Excel :
 *   1. Si un PlanStrategique avec ce code existe déjà → suppression
 *      en cascade (axes, actions, mesures, buts).
 *   2. Création d'un nouveau plan + axes + actions + mesures.
 *
 * Le code du plan = slug du nom de feuille (PlanStrategique.code unique).
 */

import { prisma } from "@/lib/prisma";
import type { PlanSP } from "./strategy-parser";

export interface ImportResult {
  success: boolean;
  plansImported: { code: string; nom: string }[];
  counts: {
    plans: number;
    axes: number;
    actions: number;
    mesures: number;
  };
  durationMs: number;
}

function pad(n: number, w: number): string {
  return String(n).padStart(w, "0");
}

export async function importStrategyPlans(
  plans: PlanSP[],
  userId: string | null
): Promise<ImportResult> {
  const start = Date.now();
  const plansImported: { code: string; nom: string }[] = [];
  let axeCount = 0;
  let actionCount = 0;
  let mesureCount = 0;

  const ts = Date.now().toString(36);

  for (let pi = 0; pi < plans.length; pi++) {
    const p = plans[pi];

    // Replace existing plan with same code
    const existing = await prisma.planStrategique.findUnique({
      where: { code: p.code },
      select: { id: true },
    });
    if (existing) {
      await prisma.planStrategique.delete({ where: { id: existing.id } });
    }

    const planId = `plan-${ts}-${pad(pi, 2)}`;

    await prisma.planStrategique.create({
      data: {
        id: planId,
        code: p.code,
        nom: p.nom,
        objectif: p.objectif,
        description: p.description ?? null,
        source: p.source ?? null,
      },
    });

    for (let ai = 0; ai < p.axes.length; ai++) {
      const a = p.axes[ai];
      axeCount++;
      const axeId = `axeo-${ts}-${pad(axeCount, 4)}`;

      await prisma.axeOGSM.create({
        data: {
          id: axeId,
          planId,
          libelle: a.libelle,
          groupe: a.groupe ?? null,
          investmentCase: a.investmentCase ?? null,
          ordre: a.ordre,
        },
      });

      for (let aci = 0; aci < a.actions.length; aci++) {
        const ac = a.actions[aci];
        actionCount++;
        const actionId = `act-${ts}-${pad(actionCount, 4)}`;

        let deadline: Date | null = null;
        if (ac.deadline) {
          const d = new Date(ac.deadline);
          if (!isNaN(d.getTime())) deadline = d;
        }

        await prisma.actionOGSM.create({
          data: {
            id: actionId,
            axeId,
            refCode: ac.refCode ?? null,
            quoi: ac.quoi,
            direction: ac.direction ?? null,
            responsable: ac.responsable ?? null,
            contributeurs: ac.contributeurs ?? null,
            priorite: ac.priorite ?? null,
            deadline,
            bailleurBudget: ac.bailleurBudget ?? null,
            ordre: aci,
          },
        });

        for (let mi = 0; mi < ac.mesures.length; mi++) {
          const m = ac.mesures[mi];
          mesureCount++;
          await prisma.mesureOGSM.create({
            data: {
              id: `mesog-${ts}-${pad(mesureCount, 5)}`,
              actionId,
              libelle: m.libelle,
              cible: m.cible ?? null,
              unite: m.unite ?? null,
              ordre: mi,
            },
          });
        }
      }
    }

    plansImported.push({ code: p.code, nom: p.nom });
  }

  const result: ImportResult = {
    success: true,
    plansImported,
    counts: {
      plans: plans.length,
      axes: axeCount,
      actions: actionCount,
      mesures: mesureCount,
    },
    durationMs: Date.now() - start,
  };

  // Audit
  await prisma.auditLog.create({
    data: {
      userId,
      action: "IMPORT",
      entityType: "PlanStrategique",
      entityId: plansImported.map((p) => p.code).join(","),
      newValue: JSON.stringify(result),
      description: `Import Plans Stratégiques — ${plansImported.length} plan(s)`,
    },
  });

  return result;
}
