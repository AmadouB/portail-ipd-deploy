/**
 * SSO Token Verification for Portal Integration
 *
 * Verifies HMAC-SHA256 signed tokens from the Portail IPD
 * and creates local sessions for authenticated users.
 */

const SSO_SECRET = process.env.SSO_SECRET || "ipd-sso-shared-secret-2026-k8Xm2v";

export interface SsoPayload {
  email: string;
  name: string;
  role: string;
  iat: number;
  exp: number;
}

function base64UrlDecode(str: string): string {
  const padded = str.replace(/-/g, "+").replace(/_/g, "/");
  return Buffer.from(padded, "base64url").toString();
}

async function getKey(): Promise<CryptoKey> {
  const encoder = new TextEncoder();
  return crypto.subtle.importKey(
    "raw",
    encoder.encode(SSO_SECRET),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["verify"]
  );
}

/**
 * Verify an SSO token from the portal.
 * Returns the decoded payload if valid, null otherwise.
 */
export async function verifySsoToken(token: string): Promise<SsoPayload | null> {
  try {
    const [payloadStr, sig] = token.split(".");
    if (!payloadStr || !sig) return null;

    const key = await getKey();
    const encoder = new TextEncoder();
    const sigBytes = Uint8Array.from(
      base64UrlDecode(sig),
      (c) => c.charCodeAt(0)
    );

    const valid = await crypto.subtle.verify(
      "HMAC",
      key,
      sigBytes,
      encoder.encode(payloadStr)
    );
    if (!valid) return null;

    const payload: SsoPayload = JSON.parse(base64UrlDecode(payloadStr));

    // Check expiration (5-minute window)
    const now = Math.floor(Date.now() / 1000);
    if (payload.exp < now) return null;

    return payload;
  } catch {
    return null;
  }
}
