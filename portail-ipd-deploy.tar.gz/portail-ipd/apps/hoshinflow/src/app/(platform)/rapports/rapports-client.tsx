"use client";

import { useState, useEffect, useMemo, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  CalendarCheck,
  ChevronLeft,
  ChevronRight,
  FileText,
  BarChart3,
  History,
  AlertTriangle,
  CheckCircle2,
  Clock,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { GlassPanel } from "@/components/ui/glass-panel";
import { AnimatedNumber } from "@/components/ui/animated-number";
import { Modal } from "@/components/ui/modal";
import { useAuth } from "@/lib/auth-context";
import { RapportForm } from "@/components/rapports/rapport-form";
import { RapportTimeline } from "@/components/rapports/rapport-timeline";
import { RapportDetail } from "@/components/rapports/rapport-detail";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

// ─── ISO Week helpers ───

function getCurrentISOWeek(): string {
  const now = new Date();
  const yearStart = new Date(now.getFullYear(), 0, 1);
  const weekNo = Math.ceil(
    ((now.getTime() - yearStart.getTime()) / 86400000 + yearStart.getDay() + 1) / 7
  );
  return `${now.getFullYear()}-W${String(weekNo).padStart(2, "0")}`;
}

function getWeekDates(isoWeek: string): { start: Date; end: Date } {
  const [year, week] = isoWeek.split("-W").map(Number);
  const jan1 = new Date(year, 0, 1);
  const dayOfWeek = jan1.getDay() || 7;
  const start = new Date(jan1);
  start.setDate(jan1.getDate() + (week - 1) * 7 - dayOfWeek + 1);
  const end = new Date(start);
  end.setDate(start.getDate() + 6);
  return { start, end };
}

function offsetWeek(isoWeek: string, offset: number): string {
  const { start } = getWeekDates(isoWeek);
  const newDate = new Date(start);
  newDate.setDate(newDate.getDate() + offset * 7);
  const yearStart = new Date(newDate.getFullYear(), 0, 1);
  const weekNo = Math.ceil(
    ((newDate.getTime() - yearStart.getTime()) / 86400000 + yearStart.getDay() + 1) / 7
  );
  return `${newDate.getFullYear()}-W${String(weekNo).padStart(2, "0")}`;
}

function formatWeekLabel(isoWeek: string): string {
  const { start, end } = getWeekDates(isoWeek);
  const fmt = (d: Date) =>
    d.toLocaleDateString("fr-FR", { day: "numeric", month: "short" });
  return `${fmt(start)} — ${fmt(end)}`;
}

function getLastNWeeks(n: number): string[] {
  const weeks: string[] = [];
  const current = getCurrentISOWeek();
  for (let i = 0; i < n; i++) {
    weeks.push(offsetWeek(current, -i));
  }
  return weeks;
}

// ─── Types ───

export interface RapportLigne {
  id: string;
  projetId: string;
  projetLibelle: string;
  avancement: number;
  statut: string;
  commentaire: string;
  isNewProjet?: boolean;
}

export interface Rapport {
  id: string;
  departementId: string;
  departementCode?: string;
  departementNom?: string;
  semaine: string;
  statut: "BROUILLON" | "SOUMIS" | "VALIDE";
  faitsMarquants: string;
  difficultes: string;
  prochainesEtapes: string;
  soumisParNom?: string;
  soumisLe?: string;
  lignes: RapportLigne[];
}

interface DepartementOption {
  id: string;
  code: string;
  nom: string;
  couleur: string;
}

type ViewMode = "saisie" | "consolide" | "historique";

const VIEW_TABS: { key: ViewMode; label: string; icon: typeof FileText }[] = [
  { key: "saisie", label: "Saisie", icon: FileText },
  { key: "consolide", label: "Vue Consolidée", icon: BarChart3 },
  { key: "historique", label: "Historique", icon: History },
];

// ─── Component ───

export function RapportsClient() {
  const { user } = useAuth();
  const isAdmin = user?.role === "ADMIN" || user?.role === "DIRECTION";

  // State
  const [viewMode, setViewMode] = useState<ViewMode>("saisie");
  const [selectedSemaine, setSelectedSemaine] = useState(getCurrentISOWeek());
  const [selectedDept, setSelectedDept] = useState(user?.departementId ?? "");
  const [rapports, setRapports] = useState<Rapport[]>([]);
  const [departements, setDepartements] = useState<DepartementOption[]>([]);
  const [loading, setLoading] = useState(true);

  // Detail modal
  const [detailRapportId, setDetailRapportId] = useState<string | null>(null);
  const detailRapport = rapports.find((r) => r.id === detailRapportId) ?? null;

  // Historique
  const [historiqueProjetId, setHistoriqueProjetId] = useState("");
  const [historiqueProjets, setHistoriqueProjets] = useState<
    { id: string; libelle: string }[]
  >([]);

  // Fetch departements
  useEffect(() => {
    fetch("/api/departements")
      .then((r) => r.json())
      .then((data) => {
        const depts: DepartementOption[] = (data ?? []).map((d: DepartementOption) => ({
          id: d.id,
          code: d.code,
          nom: d.nom,
          couleur: d.couleur,
        }));
        setDepartements(depts);
        if (!selectedDept && depts.length > 0) {
          setSelectedDept(user?.departementId ?? depts[0].id);
        }
      })
      .catch(() => {});
  }, []);

  // Fetch rapports
  const fetchRapports = useCallback(() => {
    setLoading(true);
    fetch("/api/rapports")
      .then((r) => r.json())
      .then((data) => {
        setRapports(data ?? []);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  useEffect(() => {
    fetchRapports();
  }, [fetchRapports]);

  // Fetch projets for historique
  useEffect(() => {
    if (viewMode === "historique" && selectedDept) {
      fetch(`/api/projets?departementId=${selectedDept}`)
        .then((r) => r.json())
        .then((data) => {
          setHistoriqueProjets(
            (data ?? []).map((p: { id: string; libelle: string }) => ({
              id: p.id,
              libelle: p.libelle,
            }))
          );
        })
        .catch(() => {});
    }
  }, [viewMode, selectedDept]);

  // Current rapport for saisie
  const currentRapport = useMemo(
    () =>
      rapports.find(
        (r) => r.semaine === selectedSemaine && r.departementId === selectedDept
      ) ?? null,
    [rapports, selectedSemaine, selectedDept]
  );

  const [isEditing, setIsEditing] = useState(false);

  // Consolidated stats
  const consolidatedStats = useMemo(() => {
    const weeks = getLastNWeeks(12);
    const latestWeek = weeks[0];
    const latestRapports = rapports.filter((r) => r.semaine === latestWeek);
    const soumis = latestRapports.filter(
      (r) => r.statut === "SOUMIS" || r.statut === "VALIDE"
    ).length;
    const brouillons = latestRapports.filter(
      (r) => r.statut === "BROUILLON"
    ).length;
    const sansRapport = departements.length - latestRapports.length;

    return { soumis, brouillons, sansRapport };
  }, [rapports, departements]);

  // Historique chart data
  const historiqueData = useMemo(() => {
    if (!historiqueProjetId) return [];
    const weeks = getLastNWeeks(12).reverse();
    return weeks.map((w) => {
      const rapport = rapports.find(
        (r) => r.semaine === w && r.departementId === selectedDept
      );
      const ligne = rapport?.lignes.find(
        (l) => l.projetId === historiqueProjetId
      );
      return {
        semaine: w.split("-W")[1] ? `S${w.split("-W")[1]}` : w,
        avancement: ligne?.avancement ?? null,
      };
    });
  }, [historiqueProjetId, rapports, selectedDept]);

  const selectedDeptObj = departements.find((d) => d.id === selectedDept);

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
            <CalendarCheck size={24} className="text-cyan-400" />
            Suivi Hebdomadaire
          </h1>
          <p className="text-sm text-foreground-secondary mt-1">
            Rapports de suivi par département et par semaine
          </p>
        </div>
      </div>

      {/* View toggle */}
      <div className="flex items-center gap-1 p-1 rounded-xl bg-white/[0.03] border border-white/[0.08] w-fit">
        {VIEW_TABS.map((tab) => {
          const Icon = tab.icon;
          const active = viewMode === tab.key;
          return (
            <button
              key={tab.key}
              onClick={() => setViewMode(tab.key)}
              className={cn(
                "flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200",
                active
                  ? "bg-cyan-500/15 text-cyan-400 border border-cyan-500/30"
                  : "text-white/50 hover:text-white/70 hover:bg-white/[0.04] border border-transparent"
              )}
            >
              <Icon size={16} />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* ─── VUE SAISIE ─── */}
      <AnimatePresence mode="wait">
        {viewMode === "saisie" && (
          <motion.div
            key="saisie"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
            className="space-y-4"
          >
            {/* Week + Dept selector */}
            <div className="flex flex-wrap items-center gap-4">
              {/* Week navigation */}
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setSelectedSemaine(offsetWeek(selectedSemaine, -1))}
                  className="p-2 rounded-lg bg-white/[0.04] border border-white/[0.08] text-white/50 hover:text-white/80 hover:bg-white/[0.08] transition-all"
                >
                  <ChevronLeft size={16} />
                </button>
                <div className="px-4 py-2 rounded-lg bg-white/[0.04] border border-white/[0.08] min-w-[240px] text-center">
                  <span className="text-sm font-medium text-cyan-400">
                    {selectedSemaine}
                  </span>
                  <span className="text-xs text-white/40 ml-2">
                    {formatWeekLabel(selectedSemaine)}
                  </span>
                </div>
                <button
                  onClick={() => setSelectedSemaine(offsetWeek(selectedSemaine, 1))}
                  className="p-2 rounded-lg bg-white/[0.04] border border-white/[0.08] text-white/50 hover:text-white/80 hover:bg-white/[0.08] transition-all"
                >
                  <ChevronRight size={16} />
                </button>
              </div>

              {/* Department selector */}
              {isAdmin ? (
                <select
                  value={selectedDept}
                  onChange={(e) => setSelectedDept(e.target.value)}
                  className="h-10 px-3 rounded-lg text-sm appearance-none bg-white/[0.03] border border-white/[0.08] text-white/70 focus:outline-none focus:border-cyan-500/40 transition-all min-w-[180px]"
                >
                  <option value="">Département</option>
                  {departements.map((d) => (
                    <option key={d.id} value={d.id}>
                      {d.code} — {d.nom}
                    </option>
                  ))}
                </select>
              ) : (
                selectedDeptObj && (
                  <span
                    className="inline-flex items-center px-3 py-2 rounded-lg text-sm font-medium border"
                    style={{
                      backgroundColor: `${selectedDeptObj.couleur}15`,
                      borderColor: `${selectedDeptObj.couleur}30`,
                      color: selectedDeptObj.couleur,
                    }}
                  >
                    {selectedDeptObj.code} — {selectedDeptObj.nom}
                  </span>
                )
              )}
            </div>

            {/* Rapport form or create button */}
            {selectedDept ? (
              currentRapport || isEditing ? (
                <RapportForm
                  rapport={currentRapport}
                  departementId={selectedDept}
                  semaine={selectedSemaine}
                  onSaved={() => {
                    fetchRapports();
                    setIsEditing(false);
                  }}
                />
              ) : (
                <GlassPanel className="p-8 text-center">
                  <Clock size={40} className="mx-auto text-white/20 mb-3" />
                  <p className="text-sm text-white/50 mb-4">
                    Aucun rapport pour{" "}
                    <span className="text-cyan-400">{selectedSemaine}</span>{" "}
                    {selectedDeptObj && (
                      <>
                        —{" "}
                        <span style={{ color: selectedDeptObj.couleur }}>
                          {selectedDeptObj.code}
                        </span>
                      </>
                    )}
                  </p>
                  <button
                    onClick={() => setIsEditing(true)}
                    className="px-5 py-2.5 rounded-lg text-sm font-medium bg-cyan-500/15 text-cyan-400 border border-cyan-500/30 hover:bg-cyan-500/25 transition-all"
                  >
                    Créer le rapport
                  </button>
                </GlassPanel>
              )
            ) : (
              <GlassPanel className="p-8 text-center">
                <p className="text-sm text-white/40">
                  Sélectionnez un département pour commencer.
                </p>
              </GlassPanel>
            )}
          </motion.div>
        )}

        {/* ─── VUE CONSOLIDÉE ─── */}
        {viewMode === "consolide" && (
          <motion.div
            key="consolide"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
            className="space-y-5"
          >
            {/* Summary cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {[
                {
                  label: "Soumis / Validés",
                  value: consolidatedStats.soumis,
                  accent: "emerald" as const,
                  icon: CheckCircle2,
                },
                {
                  label: "Brouillons",
                  value: consolidatedStats.brouillons,
                  accent: "amber" as const,
                  icon: Clock,
                },
                {
                  label: "Depts sans rapport",
                  value: consolidatedStats.sansRapport,
                  accent: "red" as const,
                  icon: AlertTriangle,
                },
              ].map((card, i) => {
                const Icon = card.icon;
                return (
                  <motion.div
                    key={card.label}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.06 }}
                  >
                    <GlassPanel
                      variant="glow"
                      accentColor={card.accent}
                      accentPosition="top"
                      className="p-4"
                    >
                      <div className="flex items-center gap-3">
                        <Icon size={20} className="text-white/30" />
                        <div>
                          <p className="text-[10px] font-medium text-white/40 uppercase tracking-wider">
                            {card.label}
                          </p>
                          <AnimatedNumber
                            value={card.value}
                            format="number"
                            className="text-2xl font-bold text-white/90"
                          />
                        </div>
                      </div>
                    </GlassPanel>
                  </motion.div>
                );
              })}
            </div>

            {/* Timeline heatmap */}
            <RapportTimeline
              rapports={rapports}
              departements={departements}
              onCellClick={(rapportId) => setDetailRapportId(rapportId)}
            />
          </motion.div>
        )}

        {/* ─── VUE HISTORIQUE ─── */}
        {viewMode === "historique" && (
          <motion.div
            key="historique"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
            className="space-y-4"
          >
            {/* Dept + project selector */}
            <div className="flex flex-wrap items-center gap-4">
              <select
                value={selectedDept}
                onChange={(e) => {
                  setSelectedDept(e.target.value);
                  setHistoriqueProjetId("");
                }}
                className="h-10 px-3 rounded-lg text-sm appearance-none bg-white/[0.03] border border-white/[0.08] text-white/70 focus:outline-none focus:border-cyan-500/40 transition-all min-w-[180px]"
              >
                <option value="">Département</option>
                {departements.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.code} — {d.nom}
                  </option>
                ))}
              </select>

              <select
                value={historiqueProjetId}
                onChange={(e) => setHistoriqueProjetId(e.target.value)}
                className="h-10 px-3 rounded-lg text-sm appearance-none bg-white/[0.03] border border-white/[0.08] text-white/70 focus:outline-none focus:border-cyan-500/40 transition-all min-w-[250px]"
              >
                <option value="">Sélectionner un projet</option>
                {historiqueProjets.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.libelle}
                  </option>
                ))}
              </select>
            </div>

            {/* Chart */}
            {historiqueProjetId ? (
              <GlassPanel className="p-6">
                <h3 className="text-sm font-semibold text-white/80 mb-4">
                  Avancement au fil des semaines
                </h3>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={historiqueData}>
                      <CartesianGrid
                        strokeDasharray="3 3"
                        stroke="rgba(255,255,255,0.06)"
                      />
                      <XAxis
                        dataKey="semaine"
                        tick={{ fill: "rgba(255,255,255,0.4)", fontSize: 11 }}
                        axisLine={{ stroke: "rgba(255,255,255,0.08)" }}
                      />
                      <YAxis
                        domain={[0, 100]}
                        tick={{ fill: "rgba(255,255,255,0.4)", fontSize: 11 }}
                        axisLine={{ stroke: "rgba(255,255,255,0.08)" }}
                        tickFormatter={(v: number) => `${v}%`}
                      />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "rgba(13,17,23,0.95)",
                          border: "1px solid rgba(255,255,255,0.1)",
                          borderRadius: "8px",
                          color: "rgba(255,255,255,0.8)",
                          fontSize: "12px",
                        }}
                        formatter={(value) =>
                          value != null ? [`${value}%`, "Avancement"] : ["—", "Avancement"]
                        }
                      />
                      <Line
                        type="monotone"
                        dataKey="avancement"
                        stroke="#06b6d4"
                        strokeWidth={2}
                        dot={{ fill: "#06b6d4", r: 4, strokeWidth: 0 }}
                        activeDot={{ r: 6, fill: "#06b6d4" }}
                        connectNulls={false}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </GlassPanel>
            ) : (
              <GlassPanel className="p-8 text-center">
                <History size={40} className="mx-auto text-white/20 mb-3" />
                <p className="text-sm text-white/40">
                  Sélectionnez un projet pour voir son évolution.
                </p>
              </GlassPanel>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Detail modal */}
      {detailRapport && (
        <Modal
          open={!!detailRapportId}
          onClose={() => setDetailRapportId(null)}
          title={`Rapport — ${detailRapport.departementCode ?? ""}`}
          subtitle={`Semaine ${detailRapport.semaine}`}
          size="lg"
          accentColor="#06b6d4"
        >
          <RapportDetail
            rapport={detailRapport}
            isAdmin={isAdmin}
            onValidate={() => {
              fetch(`/api/rapports/${detailRapport.id}/valider`, {
                method: "POST",
              }).then(() => {
                fetchRapports();
                setDetailRapportId(null);
              });
            }}
          />
        </Modal>
      )}
    </div>
  );
}
