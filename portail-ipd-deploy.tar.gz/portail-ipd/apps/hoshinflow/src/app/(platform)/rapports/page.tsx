import { RapportsClient } from "./rapports-client";

export default async function RapportsPage() {
  return <RapportsClient />;
}
