import { RapportsClient } from "./rapports-client";

export const dynamic = 'force-dynamic';


export default async function RapportsPage() {
  return <RapportsClient />;
}
