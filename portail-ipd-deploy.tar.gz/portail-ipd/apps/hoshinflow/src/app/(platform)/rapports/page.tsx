import { RapportsClient } from "./rapports-client";

// Rendu dynamique : evite les appels DB pendant le build Docker
export const dynamic = 'force-dynamic';



export default async function RapportsPage() {
  return <RapportsClient />;
}
