import { notFound } from "next/navigation";
import Link from "next/link";
import { getAxes, getAxeBySlug } from "@/lib/dal";
import { Breadcrumb } from "@/components/ui/breadcrumb";
import { ProgressRing } from "@/components/ui/progress-ring";
import { Target, Layers, ArrowRight } from "lucide-react";

export async function generateStaticParams() {
  const axes = await getAxes();
  return axes.map((a) => ({ slug: a.slug }));
}

interface PageProps {
  params: Promise<{ slug: string }>;
}

export default async function AxeDetailPage({ params }: PageProps) {
  const { slug } = await params;
  const axe = await getAxeBySlug(slug);

  if (!axe) {
    notFound();
  }

  const totalStrategies = axe.objectifs.reduce(
    (sum, obj) => sum + obj.strategies.length,
    0
  );
  const totalProjets = axe.objectifs.reduce(
    (sum, obj) =>
      sum + obj.strategies.reduce((s, st) => s + st.projets.length, 0),
    0
  );

  return (
    <div className="space-y-8">
      {/* Breadcrumb */}
      <Breadcrumb
        items={[
          { label: "Dashboard", href: "/" },
          { label: "Axes", href: "/axes" },
          { label: axe.nom },
        ]}
      />

      {/* Axe Header */}
      <div className="flex flex-col md:flex-row md:items-center gap-6">
        <ProgressRing value={axe.tauxCompletion ?? 0} size="lg" />

        <div className="flex-1">
          <div className="flex items-center gap-3 mb-2">
            <span
              className="inline-block text-xs font-mono font-bold tracking-wider uppercase px-2.5 py-1 rounded"
              style={{
                color: axe.couleur,
                backgroundColor: `${axe.couleur}15`,
                border: `1px solid ${axe.couleur}30`,
              }}
            >
              {axe.code}
            </span>
          </div>
          <h1 className="text-2xl font-bold text-white/95 tracking-tight mb-2">
            {axe.nom}
          </h1>
          {axe.description && (
            <p className="text-sm text-white/45 max-w-2xl leading-relaxed">
              {axe.description}
            </p>
          )}

          {/* Summary stats */}
          <div className="flex items-center gap-6 mt-4 text-sm text-white/40">
            <span className="flex items-center gap-1.5">
              <Target className="h-4 w-4" style={{ color: axe.couleur }} />
              {axe.objectifs.length} objectif{axe.objectifs.length > 1 ? "s" : ""}
            </span>
            <span className="flex items-center gap-1.5">
              <Layers className="h-4 w-4" style={{ color: axe.couleur }} />
              {totalStrategies} stratégie{totalStrategies > 1 ? "s" : ""}
            </span>
            <span className="text-white/30">
              {totalProjets} projet{totalProjets > 1 ? "s" : ""}
            </span>
          </div>
        </div>
      </div>

      {/* Separator */}
      <div className="h-px bg-white/[0.06]" />

      {/* Objectifs list */}
      <div className="space-y-6">
        <h2 className="text-lg font-semibold text-white/80">
          Objectifs Stratégiques
        </h2>

        <div className="grid grid-cols-1 gap-4">
          {axe.objectifs.map((objectif) => {
            const objCompletion = objectif.tauxCompletion ?? 0;
            const objStrategiesCount = objectif.strategies.length;
            const objProjetsCount = objectif.strategies.reduce(
              (s, st) => s + st.projets.length,
              0
            );

            return (
              <Link
                key={objectif.id}
                href={`/axes/${slug}/objectifs/${objectif.id}`}
                className="block group"
              >
                <div className="rounded-xl border border-white/[0.08] bg-white/[0.03] backdrop-blur-xl p-5 hover:bg-white/[0.06] hover:border-white/[0.12] transition-all duration-300">
                  <div className="flex items-center gap-5">
                    <ProgressRing value={objCompletion} size="md" />

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-[10px] font-mono font-bold text-white/30 tracking-wider">
                          {objectif.code}
                        </span>
                        <span className="text-[10px] text-white/20">
                          Poids: {objectif.poids}%
                        </span>
                      </div>
                      <h3 className="text-white/85 font-medium text-sm leading-snug group-hover:text-white transition-colors">
                        {objectif.libelle}
                      </h3>
                      {objectif.description && (
                        <p className="text-xs text-white/35 mt-1 line-clamp-2">
                          {objectif.description}
                        </p>
                      )}

                      <div className="flex items-center gap-4 mt-3 text-xs text-white/30">
                        <span className="flex items-center gap-1">
                          <Layers className="h-3 w-3" />
                          {objStrategiesCount} stratégie{objStrategiesCount > 1 ? "s" : ""}
                        </span>
                        <span>
                          {objProjetsCount} projet{objProjetsCount > 1 ? "s" : ""}
                        </span>
                      </div>
                    </div>

                    <ArrowRight className="h-4 w-4 text-white/20 group-hover:text-white/50 group-hover:translate-x-1 transition-all shrink-0" />
                  </div>
                </div>
              </Link>
            );
          })}
        </div>
      </div>
    </div>
  );
}
