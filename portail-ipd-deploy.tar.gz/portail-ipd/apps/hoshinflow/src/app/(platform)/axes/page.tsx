import { getAxes } from "@/lib/dal";
import { AxeCard } from "@/components/axes/axe-card";

// Rendu dynamique : evite les appels DB pendant le build Docker
export const dynamic = 'force-dynamic';

export default async function AxesPage() {
  const axes = await getAxes();

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-white/95 tracking-tight">
          Axes Stratégiques
        </h1>
        <p className="text-sm text-white/40 mt-1">
          Les 5 axes directeurs de la stratégie organisationnelle
        </p>
      </div>

      {/* Grid of Axe cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
        {axes.map((axe, index) => {
          const strategiesCount = axe.objectifs.reduce(
            (sum, obj) => sum + obj.strategies.length,
            0
          );

          return (
            <AxeCard
              key={axe.id}
              slug={axe.slug}
              code={axe.code}
              nom={axe.nom}
              couleur={axe.couleur}
              tauxCompletion={axe.tauxCompletion ?? 0}
              objectifsCount={axe.objectifs.length}
              strategiesCount={strategiesCount}
              index={index}
            />
          );
        })}
      </div>
    </div>
  );
}
