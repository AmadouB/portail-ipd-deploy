import { notFound } from "next/navigation";
import { getAxes, getAxeBySlug, getDepartements } from "@/lib/dal";
import { Breadcrumb } from "@/components/ui/breadcrumb";
import { ProgressRing } from "@/components/ui/progress-ring";
import { StatusBadge } from "@/components/ui/status-badge";
import { User, Layers, FolderKanban, Building2, BarChart3 } from "lucide-react";
import type { Statut } from "@/lib/types";
import { getProgressBarColor as getBarColor } from "@/lib/utils";

// Rendu dynamique : evite les appels DB pendant le build Docker
export const dynamic = 'force-dynamic';
interface PageProps {
  params: Promise<{ slug: string; id: string }>;
}

export default async function ObjectifDetailPage({ params }: PageProps) {
  const { slug, id } = await params;
  const axe = await getAxeBySlug(slug);
  if (!axe) notFound();

  const objectif = axe.objectifs.find((o) => o.id === id);
  if (!objectif) notFound();

  const departements = await getDepartements();
  const deptMap = new Map(departements.map((d) => [d.id, d]));

  const completion = objectif.tauxCompletion ?? 0;
  const totalStrategies = objectif.strategies.length;
  const totalProjets = objectif.strategies.reduce(
    (s, st) => s + st.projets.length,
    0
  );

  return (
    <div className="space-y-8">
      {/* Breadcrumb */}
      <Breadcrumb
        items={[
          { label: "Dashboard", href: "/" },
          { label: "Axes", href: "/axes" },
          { label: axe.nom, href: `/axes/${slug}` },
          { label: objectif.code },
        ]}
      />

      {/* Objectif Header */}
      <div className="flex flex-col md:flex-row md:items-start gap-6">
        <ProgressRing value={completion} size="lg" />

        <div className="flex-1">
          <div className="flex items-center gap-2 mb-2">
            <span
              className="inline-block text-xs font-mono font-bold tracking-wider uppercase px-2.5 py-1 rounded"
              style={{
                color: axe.couleur,
                backgroundColor: `${axe.couleur}15`,
                border: `1px solid ${axe.couleur}30`,
              }}
            >
              {objectif.code}
            </span>
            <span className="text-xs text-white/25">
              Poids: {objectif.poids}%
            </span>
          </div>

          <h1 className="text-xl font-bold text-white/95 tracking-tight mb-2">
            {objectif.libelle}
          </h1>
          {objectif.description && (
            <p className="text-sm text-white/40 max-w-2xl leading-relaxed">
              {objectif.description}
            </p>
          )}

          <div className="flex items-center gap-5 mt-4 text-sm text-white/35">
            <span className="flex items-center gap-1.5">
              <Layers className="h-4 w-4" />
              {totalStrategies} stratégie{totalStrategies > 1 ? "s" : ""}
            </span>
            <span className="flex items-center gap-1.5">
              <FolderKanban className="h-4 w-4" />
              {totalProjets} projet{totalProjets > 1 ? "s" : ""}
            </span>
          </div>
        </div>
      </div>

      {/* Separator */}
      <div className="h-px bg-white/[0.06]" />

      {/* Strategies List */}
      <div className="space-y-6">
        <h2 className="text-lg font-semibold text-white/80">
          Stratégies Départementales
        </h2>

        <div className="space-y-4">
          {objectif.strategies.map((strat) => {
            const dept = deptMap.get(strat.departementId);
            const stratCompletion = strat.tauxCompletion ?? 0;

            return (
              <div
                key={strat.id}
                className="rounded-xl border border-white/[0.08] bg-white/[0.03] backdrop-blur-xl overflow-hidden"
              >
                {/* Strategy header */}
                <div className="p-5">
                  <div className="flex items-start gap-4">
                    <ProgressRing value={stratCompletion} size="sm" />

                    <div className="flex-1 min-w-0">
                      <div className="flex flex-wrap items-center gap-2 mb-1.5">
                        <span className="text-[10px] font-mono font-bold text-white/30 tracking-wider">
                          {strat.code}
                        </span>
                        <StatusBadge status={strat.statut as Statut} />
                      </div>

                      <h3 className="text-sm font-medium text-white/85 mb-2">
                        {strat.libelle}
                      </h3>

                      <div className="flex flex-wrap items-center gap-4 text-xs text-white/35">
                        {dept && (
                          <span className="flex items-center gap-1">
                            <Building2 className="h-3 w-3" />
                            <span style={{ color: dept.couleur }}>{dept.code}</span>
                            {" "}{dept.nomCourt ?? dept.nom}
                          </span>
                        )}
                        {strat.responsable && (
                          <span className="flex items-center gap-1">
                            <User className="h-3 w-3" />
                            {strat.responsable}
                          </span>
                        )}
                        <span className="flex items-center gap-1">
                          <FolderKanban className="h-3 w-3" />
                          {strat.projets.length} projet{strat.projets.length > 1 ? "s" : ""}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Completion bar */}
                  <div className="mt-4 h-1 rounded-full bg-white/[0.06]">
                    <div
                      className={`h-full rounded-full transition-all duration-700 ${getBarColor(stratCompletion)}`}
                      style={{ width: `${Math.min(stratCompletion, 100)}%` }}
                    />
                  </div>
                </div>

                {/* Projets under this strategy */}
                {strat.projets.length > 0 && (
                  <div className="border-t border-white/[0.05] bg-white/[0.01]">
                    <div className="divide-y divide-white/[0.04]">
                      {strat.projets.map((projet) => {
                        const score = projet.scorePerformance ?? 0;
                        return (
                          <div
                            key={projet.id}
                            className="flex items-center gap-3 px-5 py-3 hover:bg-white/[0.02] transition-colors"
                          >
                            <div
                              className="h-2 w-2 rounded-full shrink-0"
                              style={{
                                backgroundColor:
                                  score >= 80
                                    ? "#10b981"
                                    : score >= 50
                                    ? "#06b6d4"
                                    : score >= 20
                                    ? "#f59e0b"
                                    : "#ef4444",
                              }}
                            />

                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2 mb-0.5">
                                <span className="text-[10px] font-mono text-white/25">
                                  {projet.code}
                                </span>
                                <StatusBadge status={projet.statut as Statut} />
                              </div>
                              <p className="text-xs text-white/70 truncate">
                                {projet.libelle}
                              </p>
                            </div>

                            <div className="shrink-0 text-right space-y-0.5">
                              {projet.responsable && (
                                <p className="text-[10px] text-white/30 truncate max-w-[140px]">
                                  {projet.responsable}
                                </p>
                              )}
                              <p className="text-[10px] text-white/20 flex items-center justify-end gap-1">
                                <BarChart3 className="h-2.5 w-2.5" />
                                {projet.kpis.length} KPI{projet.kpis.length > 1 ? "s" : ""}
                              </p>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
