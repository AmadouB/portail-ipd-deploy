import { notFound } from "next/navigation";
import { getDepartements, getDepartementByCode } from "@/lib/dal";
import { Breadcrumb } from "@/components/ui/breadcrumb";
import { ProgressRing } from "@/components/ui/progress-ring";
import { AnimatedNumber } from "@/components/ui/animated-number";
import { StrategieAccordion } from "@/components/departements/strategie-accordion";
import { User, Layers, FolderKanban, Wallet } from "lucide-react";
import { formatBudget } from "@/lib/utils";

export async function generateStaticParams() {
  const departements = await getDepartements();
  return departements.map((d) => ({ code: d.code }));
}

interface PageProps {
  params: Promise<{ code: string }>;
}

export default async function DepartementDetailPage({ params }: PageProps) {
  const { code } = await params;
  const dept = await getDepartementByCode(code);

  if (!dept) {
    notFound();
  }

  const totalStrategies = dept.strategies.length;
  const totalProjets = dept.strategies.reduce(
    (sum, s) => sum + s.projets.length,
    0
  );
  const totalBudgetAlloue = dept.strategies.reduce(
    (sum, s) =>
      sum +
      s.projets.reduce((ps, p) => ps + (p.budgetAlloue ?? 0), 0),
    0
  );
  const totalBudgetDepense = dept.strategies.reduce(
    (sum, s) =>
      sum +
      s.projets.reduce((ps, p) => ps + (p.budgetDepense ?? 0), 0),
    0
  );
  const completion = dept.tauxCompletion ?? 0;

  return (
    <div className="space-y-8">
      {/* Breadcrumb */}
      <Breadcrumb
        items={[
          { label: "Dashboard", href: "/" },
          { label: "Départements", href: "/departements" },
          { label: dept.nom },
        ]}
      />

      {/* Department Header */}
      <div className="flex flex-col md:flex-row md:items-center gap-6">
        <ProgressRing value={completion} size="lg" />

        <div className="flex-1">
          <div className="flex items-center gap-3 mb-2">
            <span
              className="text-3xl font-black font-mono tracking-tight"
              style={{
                color: dept.couleur,
                textShadow: `0 0 25px ${dept.couleur}50`,
              }}
            >
              {dept.code}
            </span>
          </div>
          <h1 className="text-xl font-bold text-white/95 tracking-tight mb-1">
            {dept.nom}
          </h1>
          {dept.directeur && (
            <p className="flex items-center gap-1.5 text-sm text-white/40">
              <User className="h-4 w-4" />
              {dept.directeur}
            </p>
          )}
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <SummaryCard
          icon={<Layers className="h-5 w-5 text-cyan-400" />}
          label="Stratégies"
          value={totalStrategies}
          color={dept.couleur}
        />
        <SummaryCard
          icon={<FolderKanban className="h-5 w-5 text-emerald-400" />}
          label="Projets"
          value={totalProjets}
          color={dept.couleur}
        />
        <SummaryCard
          icon={<Wallet className="h-5 w-5 text-amber-400" />}
          label="Budget alloué"
          value={totalBudgetAlloue}
          isBudget
          color={dept.couleur}
        />
        <SummaryCard
          icon={<Wallet className="h-5 w-5 text-red-400" />}
          label="Budget dépensé"
          value={totalBudgetDepense}
          isBudget
          color={dept.couleur}
        />
      </div>

      {/* Separator */}
      <div className="h-px bg-white/[0.06]" />

      {/* Strategies with accordion */}
      <div className="space-y-6">
        <h2 className="text-lg font-semibold text-white/80">
          Stratégies &amp; Projets
        </h2>

        {dept.strategies.length === 0 ? (
          <div className="rounded-xl border border-white/[0.08] bg-white/[0.03] p-8 text-center">
            <p className="text-sm text-white/30">
              Aucune stratégie rattachée à ce département
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {dept.strategies.map((strat, index) => (
              <StrategieAccordion
                key={strat.id}
                strategie={strat}
                index={index}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// ── Summary Card (inline server sub-component) ──
function SummaryCard({
  icon,
  label,
  value,
  isBudget = false,
  color,
}: {
  icon: React.ReactNode;
  label: string;
  value: number;
  isBudget?: boolean;
  color: string;
}) {
  return (
    <div className="rounded-xl border border-white/[0.08] bg-white/[0.03] backdrop-blur-xl p-4">
      <div className="flex items-center gap-2 mb-2">
        {icon}
        <span className="text-xs text-white/40">{label}</span>
      </div>
      <p className="text-lg font-bold text-white/90 tabular-nums">
        {isBudget ? formatBudget(value) : value}
      </p>
    </div>
  );
}
