import { getDepartements } from "@/lib/dal";
import { DeptCard } from "@/components/departements/dept-card";
import { DepartementSearch } from "@/components/departements/dept-search";

// Rendu dynamique : evite les appels DB pendant le build Docker
export const dynamic = 'force-dynamic';

export default async function DepartementsPage() {
  const departements = await getDepartements();

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-white/95 tracking-tight">
          Départements
        </h1>
        <p className="text-sm text-white/40 mt-1">
          {departements.length} départements &mdash; suivi de la performance par direction
        </p>
      </div>

      {/* Search + Grid - client component wrapper for filtering */}
      <DepartementSearch departements={departements} />
    </div>
  );
}
