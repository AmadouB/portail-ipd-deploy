"use client";

import { useState, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Search,
  X,
  Plus,
  Edit3,
  ChevronDown,
  ChevronUp,
  Eye,
  BarChart3,
  Filter,
  Layers,
} from "lucide-react";
import { cn, getStatutColor, getStatutLabel, getTauxColor, formatBudget } from "@/lib/utils";
import { GlassPanel } from "@/components/ui/glass-panel";
import { AnimatedNumber } from "@/components/ui/animated-number";
import { ProgressRing } from "@/components/ui/progress-ring";
import { useTrimestre } from "@/lib/trimestre-context";
import { useDataStore, type MatrixRow } from "@/lib/data-store";
import { StrategieModal } from "@/components/modals/strategie-modal";
import { ProjetModal } from "@/components/modals/projet-modal";
import { KpiModal } from "@/components/modals/kpi-modal";
import type { Statut, Trimestre, Projet, StrategieDepartementale, KPI, MesureKPI } from "@/lib/types";

const STATUTS: { value: Statut; label: string }[] = [
  { value: "NON_DEMARRE", label: "Non démarré" },
  { value: "EN_COURS", label: "En cours" },
  { value: "EN_RETARD", label: "En retard" },
  { value: "EN_ATTENTE", label: "En attente" },
  { value: "COMPLET", label: "Complet" },
  { value: "ANNULE", label: "Annulé" },
  { value: "A_RECONDUIRE", label: "À reconduire" },
];

const TRIMESTRES: Trimestre[] = ["T1", "T2", "T3", "T4"];

type SortKey = "dept" | "axe" | "projet" | "statut" | "score" | "budget";
type SortDir = "asc" | "desc";

export function MatriceClient() {
  const { selectedTrimestre } = useTrimestre();
  const store = useDataStore();

  // Filters
  const [search, setSearch] = useState("");
  const [deptFilter, setDeptFilter] = useState("");
  const [axeFilter, setAxeFilter] = useState("");
  const [statutFilter, setStatutFilter] = useState("");
  const [financeurFilter, setFinanceurFilter] = useState("");
  const [scoreFilter, setScoreFilter] = useState(""); // "low", "mid", "high"
  const [sortKey, setSortKey] = useState<SortKey>("dept");
  const [sortDir, setSortDir] = useState<SortDir>("asc");

  // Expanded rows
  const [expandedRow, setExpandedRow] = useState<string | null>(null);

  // Modals
  const [strategieModal, setStrategieModal] = useState<{
    open: boolean;
    strategie: StrategieDepartementale | null;
  }>({ open: false, strategie: null });

  const [projetModal, setProjetModal] = useState<{
    open: boolean;
    projet: Projet | null;
    isNew: boolean;
    strategieId: string;
  }>({ open: false, projet: null, isNew: false, strategieId: "" });

  const [kpiModal, setKpiModal] = useState<{
    open: boolean;
    kpi: KPI | null;
    isNew: boolean;
    projetId: string;
  }>({ open: false, kpi: null, isNew: false, projetId: "" });

  // Unique financeurs
  const financeurs = useMemo(() => {
    const set = new Set<string>();
    store.rows.forEach((r) => {
      if (r.projetFinanceur) set.add(r.projetFinanceur);
    });
    return Array.from(set).sort();
  }, [store.rows]);

  // Current score for row based on trimestre
  function getRowScore(row: MatrixRow): number | null {
    if (selectedTrimestre) {
      const key = `score${selectedTrimestre}` as keyof MatrixRow;
      return row[key] as number | null;
    }
    return row.latestScore || null;
  }

  // Filter
  const filtered = useMemo(() => {
    let result = store.rows;

    if (search) {
      const q = search.toLowerCase();
      result = result.filter(
        (r) =>
          r.deptCode.toLowerCase().includes(q) ||
          r.projetCode.toLowerCase().includes(q) ||
          r.projetLibelle.toLowerCase().includes(q) ||
          r.strategieCode.toLowerCase().includes(q) ||
          r.strategieLibelle.toLowerCase().includes(q) ||
          (r.projetResponsable && r.projetResponsable.toLowerCase().includes(q)) ||
          r.objectifCode.toLowerCase().includes(q)
      );
    }
    if (deptFilter) result = result.filter((r) => r.deptCode === deptFilter);
    if (axeFilter) result = result.filter((r) => r.axeCode === axeFilter);
    if (statutFilter) result = result.filter((r) => r.projetStatut === statutFilter);
    if (financeurFilter)
      result = result.filter((r) => r.projetFinanceur === financeurFilter);
    if (scoreFilter) {
      result = result.filter((r) => {
        const score = getRowScore(r);
        if (score === null) return scoreFilter === "none";
        if (scoreFilter === "low") return score < 50;
        if (scoreFilter === "mid") return score >= 50 && score < 80;
        if (scoreFilter === "high") return score >= 80;
        return true;
      });
    }

    return result;
  }, [store.rows, search, deptFilter, axeFilter, statutFilter, financeurFilter, scoreFilter, selectedTrimestre]);

  // Sort
  const sorted = useMemo(() => {
    return [...filtered].sort((a, b) => {
      let va: string | number = 0;
      let vb: string | number = 0;

      switch (sortKey) {
        case "dept":
          va = a.deptCode;
          vb = b.deptCode;
          break;
        case "axe":
          va = a.axeCode;
          vb = b.axeCode;
          break;
        case "projet":
          va = a.projetCode;
          vb = b.projetCode;
          break;
        case "statut":
          va = a.projetStatut;
          vb = b.projetStatut;
          break;
        case "score":
          va = getRowScore(a) ?? -1;
          vb = getRowScore(b) ?? -1;
          break;
        case "budget":
          va = a.projetBudgetAlloue ?? 0;
          vb = b.projetBudgetAlloue ?? 0;
          break;
      }

      if (typeof va === "string" && typeof vb === "string") {
        return sortDir === "asc" ? va.localeCompare(vb) : vb.localeCompare(va);
      }
      return sortDir === "asc"
        ? (va as number) - (vb as number)
        : (vb as number) - (va as number);
    });
  }, [filtered, sortKey, sortDir, selectedTrimestre]);

  function toggleSort(key: SortKey) {
    if (sortKey === key) setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    else {
      setSortKey(key);
      setSortDir("asc");
    }
  }

  const activeFilters = [search, deptFilter, axeFilter, statutFilter, financeurFilter, scoreFilter].filter(Boolean).length;

  // Stats
  const totalProjets = sorted.filter((r) => r.projetId).length;
  const avgScore = useMemo(() => {
    const scores = sorted.map((r) => getRowScore(r)).filter((s): s is number => s !== null);
    return scores.length > 0 ? Math.round(scores.reduce((a, b) => a + b, 0) / scores.length) : 0;
  }, [sorted, selectedTrimestre]);

  function SortIcon({ col }: { col: SortKey }) {
    if (sortKey !== col) return null;
    return <span className="text-cyan-400 ml-0.5">{sortDir === "asc" ? "↑" : "↓"}</span>;
  }

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
            <Layers size={24} className="text-cyan-400" />
            Matrice Globale
          </h1>
          <p className="text-sm text-foreground-secondary mt-1">
            Vue consolidée de toutes les activités par structure
          </p>
        </div>
      </div>

      {/* Trimestre */}
      {selectedTrimestre && (
        <div className="flex items-center gap-2 px-1">
          <span className="text-xs text-white/40">Filtré sur</span>
          <span className="px-2 py-0.5 text-xs font-medium rounded-md bg-cyan-500/15 text-cyan-400 border border-cyan-500/30">
            {selectedTrimestre}
          </span>
        </div>
      )}

      {/* Summary */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: "Lignes affichées", value: sorted.length, color: "#06b6d4", accent: "cyan" as const },
          { label: "Projets", value: totalProjets, color: "#8b5cf6", accent: "violet" as const },
          { label: "Score moyen", value: avgScore, color: "#10b981", accent: "emerald" as const, suffix: "%" },
          { label: "Structures", value: new Set(sorted.map((r) => r.deptCode)).size, color: "#f59e0b", accent: "amber" as const },
        ].map((card, i) => (
          <motion.div
            key={card.label}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.06 }}
          >
            <GlassPanel variant="glow" accentColor={card.accent} accentPosition="top" className="p-4">
              <p className="text-[10px] font-medium text-white/40 uppercase tracking-wider">{card.label}</p>
              <div className="flex items-baseline gap-0.5 mt-1">
                <AnimatedNumber value={card.value} format="number" className="text-2xl font-bold text-white/90" />
                {card.suffix && <span className="text-sm text-white/40">{card.suffix}</span>}
              </div>
            </GlassPanel>
          </motion.div>
        ))}
      </div>

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-3 p-4 rounded-xl bg-white/[0.03] border border-white/[0.08] backdrop-blur-xl">
        <div className="relative flex-1 min-w-[180px]">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-white/30" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Rechercher..."
            className="w-full h-10 pl-9 pr-3 rounded-lg text-sm bg-white/[0.03] border border-white/[0.08] text-white/90 placeholder:text-white/30 focus:outline-none focus:border-cyan-500/40 focus:ring-1 focus:ring-cyan-500/20 transition-all"
          />
        </div>

        <select value={deptFilter} onChange={(e) => setDeptFilter(e.target.value)}
          className="h-10 px-3 rounded-lg text-sm appearance-none bg-white/[0.03] border border-white/[0.08] text-white/70 focus:outline-none focus:border-cyan-500/40 transition-all min-w-[120px]">
          <option value="">Structure</option>
          {store.departements.map((d) => (
            <option key={d.code} value={d.code}>{d.code}</option>
          ))}
        </select>

        <select value={axeFilter} onChange={(e) => setAxeFilter(e.target.value)}
          className="h-10 px-3 rounded-lg text-sm appearance-none bg-white/[0.03] border border-white/[0.08] text-white/70 focus:outline-none focus:border-cyan-500/40 transition-all min-w-[120px]">
          <option value="">Axe</option>
          {store.axes.map((a) => (
            <option key={a.code} value={a.code}>{a.code} - {a.nom}</option>
          ))}
        </select>

        <select value={statutFilter} onChange={(e) => setStatutFilter(e.target.value)}
          className="h-10 px-3 rounded-lg text-sm appearance-none bg-white/[0.03] border border-white/[0.08] text-white/70 focus:outline-none focus:border-cyan-500/40 transition-all min-w-[120px]">
          <option value="">Statut</option>
          {STATUTS.map((s) => (
            <option key={s.value} value={s.value}>{s.label}</option>
          ))}
        </select>

        <select value={financeurFilter} onChange={(e) => setFinanceurFilter(e.target.value)}
          className="h-10 px-3 rounded-lg text-sm appearance-none bg-white/[0.03] border border-white/[0.08] text-white/70 focus:outline-none focus:border-cyan-500/40 transition-all min-w-[120px]">
          <option value="">Financeur</option>
          {financeurs.map((f) => (
            <option key={f} value={f}>{f}</option>
          ))}
        </select>

        <select value={scoreFilter} onChange={(e) => setScoreFilter(e.target.value)}
          className="h-10 px-3 rounded-lg text-sm appearance-none bg-white/[0.03] border border-white/[0.08] text-white/70 focus:outline-none focus:border-cyan-500/40 transition-all min-w-[120px]">
          <option value="">Performance</option>
          <option value="high">≥ 80%</option>
          <option value="mid">50-79%</option>
          <option value="low">&lt; 50%</option>
          <option value="none">Non mesuré</option>
        </select>

        <AnimatePresence>
          {activeFilters > 0 && (
            <motion.button
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              onClick={() => {
                setSearch(""); setDeptFilter(""); setAxeFilter("");
                setStatutFilter(""); setFinanceurFilter(""); setScoreFilter("");
              }}
              className="flex items-center gap-1 text-xs text-white/40 hover:text-red-400 transition-colors"
            >
              <X size={12} /> Effacer ({activeFilters})
            </motion.button>
          )}
        </AnimatePresence>
      </div>

      <p className="text-sm text-white/40 px-1">
        <span className="text-white/70 font-medium">{sorted.length}</span> ligne{sorted.length !== 1 ? "s" : ""}
      </p>

      {/* Table */}
      <div className="rounded-xl border border-white/[0.08] overflow-hidden bg-white/[0.02] backdrop-blur-xl">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-white/[0.08] bg-white/[0.03]">
                <th className="px-3 py-3 text-left text-[10px] font-medium text-white/50 uppercase tracking-wider w-[70px] cursor-pointer hover:text-white/70" onClick={() => toggleSort("dept")}>
                  Dept <SortIcon col="dept" />
                </th>
                <th className="px-3 py-3 text-left text-[10px] font-medium text-white/50 uppercase tracking-wider w-[60px] cursor-pointer hover:text-white/70" onClick={() => toggleSort("axe")}>
                  Axe <SortIcon col="axe" />
                </th>
                <th className="px-3 py-3 text-left text-[10px] font-medium text-white/50 uppercase tracking-wider w-[80px]">
                  Objectif
                </th>
                <th className="px-3 py-3 text-left text-[10px] font-medium text-white/50 uppercase tracking-wider w-[90px]">
                  Stratégie
                </th>
                <th className="px-3 py-3 text-left text-[10px] font-medium text-white/50 uppercase tracking-wider cursor-pointer hover:text-white/70" onClick={() => toggleSort("projet")}>
                  Projet <SortIcon col="projet" />
                </th>
                <th className="px-3 py-3 text-left text-[10px] font-medium text-white/50 uppercase tracking-wider w-[100px]">
                  Responsable
                </th>
                <th className="px-3 py-3 text-center text-[10px] font-medium text-white/50 uppercase tracking-wider w-[80px] cursor-pointer hover:text-white/70" onClick={() => toggleSort("statut")}>
                  Statut <SortIcon col="statut" />
                </th>
                {TRIMESTRES.map((t) => (
                  <th key={t} className={cn(
                    "px-2 py-3 text-center text-[10px] font-medium uppercase tracking-wider w-[50px]",
                    selectedTrimestre === t ? "text-cyan-400 bg-cyan-500/[0.06]" : "text-white/50"
                  )}>
                    {t}
                  </th>
                ))}
                <th className="px-3 py-3 text-center text-[10px] font-medium text-white/50 uppercase tracking-wider w-[50px]">
                  KPI
                </th>
                <th className="px-3 py-3 text-center text-[10px] font-medium text-white/50 uppercase tracking-wider w-[90px] cursor-pointer hover:text-white/70" onClick={() => toggleSort("budget")}>
                  Budget <SortIcon col="budget" />
                </th>
                <th className="px-3 py-3 text-center text-[10px] font-medium text-white/50 uppercase tracking-wider w-[60px]">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody>
              {sorted.map((row, i) => {
                const score = getRowScore(row);
                const statutColor = getStatutColor(row.projetStatut);
                const isExpanded = expandedRow === `${row.strategieId}-${row.projetId}`;
                const rowKey = `${row.strategieId}-${row.projetId}-${i}`;

                return (
                  <motion.tr
                    key={rowKey}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ duration: 0.1, delay: Math.min(i * 0.01, 0.5) }}
                    className={cn(
                      "border-b border-white/[0.04] hover:bg-white/[0.03] transition-colors text-xs",
                      isExpanded && "bg-white/[0.02]"
                    )}
                  >
                    {/* Dept */}
                    <td className="px-3 py-2.5">
                      <span
                        className="inline-flex px-1.5 py-0.5 rounded text-[10px] font-bold border"
                        style={{ backgroundColor: `${row.deptCouleur}15`, borderColor: `${row.deptCouleur}30`, color: row.deptCouleur }}
                      >
                        {row.deptCode}
                      </span>
                    </td>

                    {/* Axe */}
                    <td className="px-3 py-2.5">
                      <span className="text-[10px] font-medium" style={{ color: row.axeCouleur }}>
                        {row.axeCode}
                      </span>
                    </td>

                    {/* Objectif */}
                    <td className="px-3 py-2.5">
                      <span className="text-[10px] text-white/40" title={row.objectifLibelle}>
                        {row.objectifCode}
                      </span>
                    </td>

                    {/* Strategie */}
                    <td className="px-3 py-2.5">
                      <button
                        onClick={() => setStrategieModal({ open: true, strategie: row.strategie })}
                        className="text-[10px] text-white/50 hover:text-cyan-400 transition-colors truncate max-w-[80px] block text-left"
                        title={row.strategieLibelle}
                      >
                        {row.strategieCode}
                      </button>
                    </td>

                    {/* Projet */}
                    <td className="px-3 py-2.5">
                      {row.projetId ? (
                        <button
                          onClick={() =>
                            setProjetModal({ open: true, projet: row.projet, isNew: false, strategieId: row.strategieId })
                          }
                          className="text-xs text-white/70 hover:text-cyan-400 transition-colors truncate max-w-[180px] block text-left"
                          title={row.projetLibelle}
                        >
                          <span className="font-mono text-cyan-400/50 mr-1">{row.projetCode}</span>
                          {row.projetLibelle}
                        </button>
                      ) : (
                        <span className="text-white/20 italic">—</span>
                      )}
                    </td>

                    {/* Responsable */}
                    <td className="px-3 py-2.5">
                      <span className="text-[10px] text-white/40 truncate max-w-[90px] block">
                        {row.projetResponsable || "—"}
                      </span>
                    </td>

                    {/* Statut */}
                    <td className="px-3 py-2.5 text-center">
                      {row.projetId && (
                        <span
                          className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full text-[9px] font-medium"
                          style={{ backgroundColor: `${statutColor}15`, color: statutColor }}
                        >
                          <span className="w-1 h-1 rounded-full" style={{ backgroundColor: statutColor }} />
                          {getStatutLabel(row.projetStatut).slice(0, 8)}
                        </span>
                      )}
                    </td>

                    {/* T1-T4 scores */}
                    {TRIMESTRES.map((t) => {
                      const key = `score${t}` as keyof MatrixRow;
                      const val = row[key] as number | null;
                      const isSelected = selectedTrimestre === t;
                      return (
                        <td key={t} className={cn("px-2 py-2.5 text-center", isSelected && "bg-cyan-500/[0.04]")}>
                          {val !== null ? (
                            <span className={cn("text-[10px] font-medium tabular-nums", isSelected && "font-bold")} style={{ color: getTauxColor(val) }}>
                              {val}%
                            </span>
                          ) : (
                            <span className="text-[10px] text-white/10">—</span>
                          )}
                        </td>
                      );
                    })}

                    {/* KPI count */}
                    <td className="px-3 py-2.5 text-center">
                      {row.kpiCount > 0 ? (
                        <span className="text-[10px] text-white/50">
                          <span className="text-emerald-400">{row.kpiFilledCount}</span>
                          /{row.kpiCount}
                        </span>
                      ) : (
                        <span className="text-[10px] text-white/10">—</span>
                      )}
                    </td>

                    {/* Budget */}
                    <td className="px-3 py-2.5 text-center">
                      {row.projetBudgetAlloue ? (
                        <span className="text-[10px] text-white/50 tabular-nums">
                          {(row.projetBudgetAlloue / 1_000_000).toFixed(0)}M
                        </span>
                      ) : (
                        <span className="text-[10px] text-white/10">—</span>
                      )}
                    </td>

                    {/* Actions */}
                    <td className="px-3 py-2.5 text-center">
                      <div className="flex items-center justify-center gap-1">
                        {row.projetId ? (
                          <>
                            <button
                              onClick={() => setProjetModal({ open: true, projet: row.projet, isNew: false, strategieId: row.strategieId })}
                              className="p-1 rounded text-white/30 hover:text-cyan-400 hover:bg-cyan-500/10 transition-all"
                              title="Modifier le projet"
                            >
                              <Edit3 size={12} />
                            </button>
                            <button
                              onClick={() => setExpandedRow(isExpanded ? null : `${row.strategieId}-${row.projetId}`)}
                              className="p-1 rounded text-white/30 hover:text-emerald-400 hover:bg-emerald-500/10 transition-all"
                              title="Voir les KPIs"
                            >
                              <Eye size={12} />
                            </button>
                          </>
                        ) : (
                          <button
                            onClick={() => {
                              const p = store.addProjet(row.strategieId);
                              setProjetModal({ open: true, projet: p, isNew: true, strategieId: row.strategieId });
                            }}
                            className="p-1 rounded text-white/30 hover:text-cyan-400 hover:bg-cyan-500/10 transition-all"
                            title="Ajouter un projet"
                          >
                            <Plus size={12} />
                          </button>
                        )}
                      </div>
                    </td>
                  </motion.tr>
                );
              })}

              {sorted.length === 0 && (
                <tr>
                  <td colSpan={14} className="px-4 py-12 text-center text-white/30 text-sm">
                    Aucun résultat ne correspond aux filtres.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Expanded KPI panel — shown below table when a row is expanded */}
      <AnimatePresence>
        {expandedRow && (() => {
          const row = sorted.find(
            (r) => `${r.strategieId}-${r.projetId}` === expandedRow
          );
          if (!row || !row.projetId) return null;

          return (
            <motion.div
              key={expandedRow}
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
            >
              <GlassPanel className="p-5">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="text-sm font-semibold text-white/80">
                      KPIs — {row.projetCode} {row.projetLibelle}
                    </h3>
                    <p className="text-xs text-white/40">
                      {row.deptCode} · {row.strategieCode}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => {
                        const kpi = store.addKpi(row.projetId);
                        setKpiModal({ open: true, kpi, isNew: true, projetId: row.projetId });
                      }}
                      className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-medium bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 hover:bg-emerald-500/25 transition-all"
                    >
                      <Plus size={12} /> Ajouter KPI
                    </button>
                    <button
                      onClick={() => setExpandedRow(null)}
                      className="p-1.5 rounded-lg text-white/30 hover:text-white/60 hover:bg-white/[0.06] transition-all"
                    >
                      <X size={14} />
                    </button>
                  </div>
                </div>

                {row.projet.kpis.length === 0 ? (
                  <p className="text-sm text-white/30 text-center py-8">
                    Aucun KPI défini pour ce projet.
                  </p>
                ) : (
                  <div className="rounded-lg border border-white/[0.06] overflow-hidden">
                    <table className="w-full">
                      <thead>
                        <tr className="bg-white/[0.02] border-b border-white/[0.06]">
                          <th className="px-3 py-2 text-left text-[10px] text-white/40 uppercase w-[80px]">Code</th>
                          <th className="px-3 py-2 text-left text-[10px] text-white/40 uppercase">Libellé</th>
                          <th className="px-3 py-2 text-center text-[10px] text-white/40 uppercase w-[60px]">Mode</th>
                          {TRIMESTRES.map((t) => (
                            <th key={t} className={cn(
                              "px-2 py-2 text-center text-[10px] uppercase w-[80px]",
                              selectedTrimestre === t ? "text-cyan-400" : "text-white/40"
                            )}>
                              {t}
                            </th>
                          ))}
                          <th className="px-3 py-2 text-center text-[10px] text-white/40 uppercase w-[50px]">Edit</th>
                        </tr>
                      </thead>
                      <tbody>
                        {row.projet.kpis.map((kpi) => (
                          <tr key={kpi.id} className="border-b border-white/[0.04] hover:bg-white/[0.02]">
                            <td className="px-3 py-2">
                              <span className="font-mono text-[10px] text-cyan-400/60">{kpi.code}</span>
                            </td>
                            <td className="px-3 py-2">
                              <span className="text-xs text-white/60 line-clamp-1">{kpi.libelle}</span>
                            </td>
                            <td className="px-3 py-2 text-center">
                              <span className="text-[9px] text-white/30 uppercase">{kpi.modeCalcul}</span>
                            </td>
                            {TRIMESTRES.map((t) => {
                              const m = kpi.mesures.find((mes) => mes.trimestre === t);
                              const hasCible = m?.cible !== null && m?.cible !== undefined;
                              const hasReal = m?.realise !== null && m?.realise !== undefined;
                              const taux = hasCible && hasReal
                                ? Math.min(Math.round(((m!.realise as number) / (m!.cible as number)) * 1000) / 10, 100)
                                : null;
                              const isSelected = selectedTrimestre === t;

                              return (
                                <td key={t} className={cn("px-2 py-2 text-center", isSelected && "bg-cyan-500/[0.04]")}>
                                  {taux !== null ? (
                                    <div className="space-y-0.5">
                                      <span className={cn("text-[10px] font-medium tabular-nums block", isSelected && "font-bold")} style={{ color: getTauxColor(taux) }}>
                                        {taux}%
                                      </span>
                                      <span className="text-[8px] text-white/25 block">
                                        {m!.realise}/{m!.cible}
                                      </span>
                                    </div>
                                  ) : hasCible ? (
                                    <div className="space-y-0.5">
                                      <span className="text-[10px] text-white/20">—</span>
                                      <span className="text-[8px] text-white/15 block">/{m!.cible}</span>
                                    </div>
                                  ) : (
                                    <span className="text-[10px] text-white/10">—</span>
                                  )}
                                </td>
                              );
                            })}
                            <td className="px-3 py-2 text-center">
                              <button
                                onClick={() => setKpiModal({ open: true, kpi, isNew: false, projetId: row.projetId })}
                                className="p-1 rounded text-white/30 hover:text-emerald-400 hover:bg-emerald-500/10 transition-all"
                              >
                                <Edit3 size={11} />
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </GlassPanel>
            </motion.div>
          );
        })()}
      </AnimatePresence>

      {/* ─── MODALS ─── */}

      {strategieModal.strategie && (
        <StrategieModal
          open={strategieModal.open}
          onClose={() => setStrategieModal({ open: false, strategie: null })}
          strategie={strategieModal.strategie}
          onSave={(patch) => {
            store.updateStrategie(strategieModal.strategie!.id, patch);
          }}
        />
      )}

      <ProjetModal
        open={projetModal.open}
        onClose={() => setProjetModal({ open: false, projet: null, isNew: false, strategieId: "" })}
        projet={projetModal.projet}
        isNew={projetModal.isNew}
        onSave={(patch) => {
          if (projetModal.projet) {
            store.updateProjet(projetModal.projet.id, patch);
          }
        }}
        onDelete={
          projetModal.projet && !projetModal.isNew
            ? () => {
                store.deleteProjet(projetModal.projet!.id);
                setProjetModal({ open: false, projet: null, isNew: false, strategieId: "" });
                setExpandedRow(null);
              }
            : undefined
        }
      />

      {kpiModal.kpi && (
        <KpiModal
          open={kpiModal.open}
          onClose={() => setKpiModal({ open: false, kpi: null, isNew: false, projetId: "" })}
          kpi={kpiModal.kpi}
          isNew={kpiModal.isNew}
          onSave={(patch) => {
            store.updateKpi(kpiModal.projetId, kpiModal.kpi!.id, patch);
          }}
          onSaveMesure={(tri, patch) => {
            store.updateMesure(kpiModal.projetId, kpiModal.kpi!.id, tri, patch);
          }}
          onDelete={
            !kpiModal.isNew
              ? () => {
                  store.deleteKpi(kpiModal.projetId, kpiModal.kpi!.id);
                  setKpiModal({ open: false, kpi: null, isNew: false, projetId: "" });
                }
              : undefined
          }
        />
      )}
    </div>
  );
}
