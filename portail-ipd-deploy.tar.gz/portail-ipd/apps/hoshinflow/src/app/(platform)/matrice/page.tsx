import { MatriceClient } from "./matrice-client";

export default function MatricePage() {
  return <MatriceClient />;
}
