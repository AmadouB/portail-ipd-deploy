import { MatriceClient } from "./matrice-client";

// Rendu dynamique : evite les appels DB pendant le build Docker
export const dynamic = 'force-dynamic';



export default function MatricePage() {
  return <MatriceClient />;
}
