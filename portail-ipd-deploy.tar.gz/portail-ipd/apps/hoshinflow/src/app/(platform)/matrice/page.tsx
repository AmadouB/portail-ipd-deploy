import { MatriceClient } from "./matrice-client";

export const dynamic = 'force-dynamic';


export default function MatricePage() {
  return <MatriceClient />;
}
