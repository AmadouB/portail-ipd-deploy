"use client";

import { useState, useMemo, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Grid3x3, Filter, Info, ChevronDown } from "lucide-react";
import { GlassPanel } from "@/components/ui/glass-panel";
import type {
  AxeStrategique,
  BreakthroughGoal,
  Departement,
  ObjectifStrategique,
  StrategieDepartementale,
} from "@/lib/types";
import { cn, getStatutLabel } from "@/lib/utils";

interface XMatrixClientProps {
  axes: AxeStrategique[];
  btgs: BreakthroughGoal[];
  departements: Departement[];
  objectifs: ObjectifStrategique[];
  allStrategies: StrategieDepartementale[];
}

/* ── Precompute which BTG IDs are linked to each strategy ── */
function btgIdsForStrategy(strat: StrategieDepartementale): Set<string> {
  const ids = new Set<string>();
  strat.projets.forEach((p) => {
    p.projetBtgs.forEach((pb) => ids.add(pb.btgId));
  });
  return ids;
}

/* ── Tooltip component ── */
function Tooltip({
  x,
  y,
  children,
}: {
  x: number;
  y: number;
  children: React.ReactNode;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      transition={{ duration: 0.15 }}
      className="fixed z-[100] pointer-events-none"
      style={{ left: x + 12, top: y - 8 }}
    >
      <div className="bg-[#0f1629]/95 backdrop-blur-xl border border-white/10 rounded-lg px-3 py-2 shadow-xl max-w-xs">
        {children}
      </div>
    </motion.div>
  );
}

export function XMatrixClient({ axes, btgs, departements, objectifs, allStrategies }: XMatrixClientProps) {
  const [selectedDept, setSelectedDept] = useState<string>("all");
  const [selectedStratId, setSelectedStratId] = useState<string | null>(null);
  const [tooltip, setTooltip] = useState<{
    x: number;
    y: number;
    content: React.ReactNode;
  } | null>(null);
  const [dropdownOpen, setDropdownOpen] = useState(false);

  /* ── Filtered strategies ── */
  const filteredStrategies = useMemo(() => {
    const strats =
      selectedDept === "all"
        ? allStrategies
        : allStrategies.filter((s) => s.departementId === selectedDept);
    return strats.slice(0, 30);
  }, [selectedDept, allStrategies]);

  /* ── Dept map for display ── */
  const deptMap = useMemo(() => {
    const map = new Map<string, Departement>();
    departements.forEach((d) => map.set(d.id, d));
    return map;
  }, [departements]);

  /* ── Objectif map ── */
  const objMap = useMemo(() => {
    const map = new Map<string, ObjectifStrategique>();
    objectifs.forEach((o) => map.set(o.id, o));
    return map;
  }, [objectifs]);

  /* ── BTG linkage map ── */
  const stratBtgMap = useMemo(() => {
    const map = new Map<string, Set<string>>();
    allStrategies.forEach((s) => {
      map.set(s.id, btgIdsForStrategy(s));
    });
    return map;
  }, [allStrategies]);

  /* ── Group strategies by department for display ── */
  const groupedStrategies = useMemo(() => {
    const groups: { dept: Departement; strategies: StrategieDepartementale[] }[] =
      [];
    const deptGroups = new Map<string, StrategieDepartementale[]>();

    filteredStrategies.forEach((s) => {
      const existing = deptGroups.get(s.departementId);
      if (existing) {
        existing.push(s);
      } else {
        deptGroups.set(s.departementId, [s]);
      }
    });

    deptGroups.forEach((strats, deptId) => {
      const dept = deptMap.get(deptId);
      if (dept) {
        groups.push({ dept, strategies: strats });
      }
    });

    groups.sort((a, b) => a.dept.code.localeCompare(b.dept.code));
    return groups;
  }, [filteredStrategies, deptMap]);

  const handleCellHover = useCallback(
    (
      e: React.MouseEvent,
      strategie: StrategieDepartementale,
      target: BreakthroughGoal | ObjectifStrategique,
      linked: boolean,
      type: "btg" | "obj"
    ) => {
      const dept = deptMap.get(strategie.departementId);
      setTooltip({
        x: e.clientX,
        y: e.clientY,
        content: (
          <div className="space-y-1">
            <p className="text-xs text-white/50">
              {type === "btg" ? "BTG" : "Objectif"}
            </p>
            <p className="text-sm font-medium text-white/90">
              {"code" in target ? target.code : ""} -{" "}
              {"nom" in target
                ? (target as BreakthroughGoal).nom
                : (target as ObjectifStrategique).libelle}
            </p>
            <div className="border-t border-white/10 pt-1 mt-1">
              <p className="text-xs text-white/50">Strategie</p>
              <p className="text-sm text-white/80">
                {strategie.code} - {strategie.libelle}
              </p>
            </div>
            {dept && (
              <p className="text-xs text-white/40">Dept: {dept.nomCourt}</p>
            )}
            <p
              className={cn(
                "text-xs font-semibold",
                linked ? "text-emerald-400" : "text-white/30"
              )}
            >
              {linked ? "Lie" : "Non lie"}
            </p>
          </div>
        ),
      });
    },
    [deptMap]
  );

  const handleCellLeave = useCallback(() => {
    setTooltip(null);
  }, []);

  const handleStrategyClick = useCallback(
    (stratId: string) => {
      setSelectedStratId((prev) => (prev === stratId ? null : stratId));
    },
    []
  );

  const deptOptions = useMemo(
    () => [
      { id: "all", label: "Tous les departements" },
      ...departements.map((d) => ({ id: d.id, label: `${d.code} - ${d.nom}` })),
    ],
    [departements]
  );

  const selectedDeptLabel =
    deptOptions.find((o) => o.id === selectedDept)?.label ??
    "Tous les departements";

  return (
    <div className="space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4"
      >
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-neon-cyan/10 flex items-center justify-center">
            <Grid3x3 className="w-5 h-5 text-neon-cyan" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-foreground">X-Matrix</h1>
            <p className="text-sm text-foreground-secondary">
              Matrice de correlation Hoshin Kanri
            </p>
          </div>
        </div>

        {/* Department filter */}
        <div className="relative">
          <button
            onClick={() => setDropdownOpen(!dropdownOpen)}
            className="flex items-center gap-2 px-4 py-2 rounded-lg bg-white/[0.03] border border-white/[0.08] text-sm text-foreground hover:bg-white/[0.06] transition-colors min-w-[240px] justify-between"
          >
            <div className="flex items-center gap-2">
              <Filter size={14} className="text-foreground-secondary" />
              <span className="truncate">{selectedDeptLabel}</span>
            </div>
            <ChevronDown
              size={14}
              className={cn(
                "text-foreground-secondary transition-transform",
                dropdownOpen && "rotate-180"
              )}
            />
          </button>
          <AnimatePresence>
            {dropdownOpen && (
              <motion.div
                initial={{ opacity: 0, y: -4 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -4 }}
                className="absolute right-0 mt-1 w-full z-50 bg-[#0f1629]/95 backdrop-blur-xl border border-white/10 rounded-lg shadow-2xl max-h-64 overflow-y-auto"
              >
                {deptOptions.map((opt) => (
                  <button
                    key={opt.id}
                    onClick={() => {
                      setSelectedDept(opt.id);
                      setDropdownOpen(false);
                    }}
                    className={cn(
                      "w-full text-left px-3 py-2 text-sm transition-colors hover:bg-white/[0.06]",
                      selectedDept === opt.id
                        ? "text-neon-cyan bg-neon-cyan/5"
                        : "text-foreground-secondary"
                    )}
                  >
                    {opt.label}
                  </button>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </motion.div>

      {/* Legend */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.2 }}
      >
        <GlassPanel className="p-4">
          <div className="flex flex-wrap items-center gap-6 text-xs">
            <div className="flex items-center gap-2">
              <Info size={14} className="text-foreground-secondary" />
              <span className="text-foreground-secondary font-medium">
                Legende :
              </span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-5 h-5 rounded bg-emerald-500/40 border border-emerald-500/60" />
              <span className="text-foreground-secondary">Lie (via projets)</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-5 h-5 rounded bg-white/[0.04] border border-white/[0.08]" />
              <span className="text-foreground-secondary">Non lie</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-5 h-5 rounded bg-cyan-500/30 border border-cyan-500/60 ring-1 ring-cyan-400/50" />
              <span className="text-foreground-secondary">
                Selection active
              </span>
            </div>
          </div>
        </GlassPanel>
      </motion.div>

      {/* BTGs vs Strategies Matrix */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3, duration: 0.5 }}
      >
        <GlassPanel className="p-0 overflow-hidden">
          <div className="px-5 py-4 border-b border-white/[0.08]">
            <h2 className="text-lg font-semibold text-foreground">
              BTGs vs Strategies
            </h2>
            <p className="text-xs text-foreground-secondary mt-0.5">
              Correlation entre les Breakthrough Goals et les strategies
              departementales
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full border-collapse min-w-[700px]">
              <thead>
                <tr className="border-b border-white/[0.08]">
                  <th className="sticky left-0 z-20 bg-[#0a0e1a]/90 backdrop-blur-sm px-4 py-3 text-left text-xs font-medium text-foreground-secondary uppercase tracking-wider min-w-[200px]">
                    Strategie
                  </th>
                  <th className="sticky left-0 z-20 bg-[#0a0e1a]/90 backdrop-blur-sm px-2 py-3 text-left text-xs font-medium text-foreground-secondary uppercase tracking-wider w-16">
                    Dept
                  </th>
                  {btgs.map((btg) => (
                    <th
                      key={btg.id}
                      className="px-2 py-3 text-center text-xs font-medium text-foreground-secondary min-w-[80px]"
                    >
                      <div className="flex flex-col items-center gap-1">
                        <span className="font-bold text-amber-400/80">
                          {btg.code}
                        </span>
                        <span className="text-[10px] text-foreground-secondary/60 max-w-[100px] truncate">
                          {btg.nom}
                        </span>
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {groupedStrategies.map(({ dept, strategies }) =>
                  strategies.map((strat, si) => {
                    const isSelected = selectedStratId === strat.id;
                    const linkedBtgs = stratBtgMap.get(strat.id) ?? new Set();

                    return (
                      <motion.tr
                        key={strat.id}
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: si * 0.02 }}
                        onClick={() => handleStrategyClick(strat.id)}
                        className={cn(
                          "border-b border-white/[0.04] cursor-pointer transition-colors",
                          isSelected
                            ? "bg-cyan-500/[0.08]"
                            : "hover:bg-white/[0.03]"
                        )}
                      >
                        <td className="sticky left-0 z-10 bg-[#0a0e1a]/80 backdrop-blur-sm px-4 py-2.5">
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-mono text-foreground-secondary/70">
                              {strat.code}
                            </span>
                            <span
                              className={cn(
                                "text-sm truncate max-w-[250px]",
                                isSelected
                                  ? "text-cyan-300 font-medium"
                                  : "text-foreground/80"
                              )}
                            >
                              {strat.libelle}
                            </span>
                          </div>
                        </td>
                        <td className="sticky left-0 z-10 bg-[#0a0e1a]/80 backdrop-blur-sm px-2 py-2.5">
                          <span
                            className="inline-flex items-center justify-center px-1.5 py-0.5 rounded text-[10px] font-bold"
                            style={{
                              backgroundColor: `${dept.couleur}20`,
                              color: dept.couleur,
                            }}
                          >
                            {dept.nomCourt ?? dept.code}
                          </span>
                        </td>
                        {btgs.map((btg) => {
                          const linked = linkedBtgs.has(btg.id);
                          return (
                            <td
                              key={btg.id}
                              className="px-2 py-2.5 text-center"
                              onMouseEnter={(e) =>
                                handleCellHover(e, strat, btg, linked, "btg")
                              }
                              onMouseMove={(e) =>
                                setTooltip((prev) =>
                                  prev
                                    ? {
                                        ...prev,
                                        x: e.clientX,
                                        y: e.clientY,
                                      }
                                    : null
                                )
                              }
                              onMouseLeave={handleCellLeave}
                            >
                              <div
                                className={cn(
                                  "w-8 h-8 mx-auto rounded-md transition-all duration-200",
                                  linked
                                    ? "bg-emerald-500/30 border border-emerald-500/50 shadow-[0_0_8px_rgba(16,185,129,0.2)]"
                                    : "bg-white/[0.03] border border-white/[0.06]",
                                  isSelected &&
                                    linked &&
                                    "ring-1 ring-cyan-400/50 bg-emerald-500/40"
                                )}
                              >
                                {linked && (
                                  <div className="w-full h-full flex items-center justify-center">
                                    <div className="w-2 h-2 rounded-full bg-emerald-400" />
                                  </div>
                                )}
                              </div>
                            </td>
                          );
                        })}
                      </motion.tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </GlassPanel>
      </motion.div>

      {/* Objectifs vs Strategies Matrix */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5, duration: 0.5 }}
      >
        <GlassPanel className="p-0 overflow-hidden">
          <div className="px-5 py-4 border-b border-white/[0.08]">
            <h2 className="text-lg font-semibold text-foreground">
              Objectifs Strategiques vs Strategies
            </h2>
            <p className="text-xs text-foreground-secondary mt-0.5">
              Correlation entre les 10 objectifs strategiques et les strategies
              departementales
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full border-collapse min-w-[900px]">
              <thead>
                <tr className="border-b border-white/[0.08]">
                  <th className="sticky left-0 z-20 bg-[#0a0e1a]/90 backdrop-blur-sm px-4 py-3 text-left text-xs font-medium text-foreground-secondary uppercase tracking-wider min-w-[200px]">
                    Strategie
                  </th>
                  <th className="sticky left-0 z-20 bg-[#0a0e1a]/90 backdrop-blur-sm px-2 py-3 text-left text-xs font-medium text-foreground-secondary uppercase tracking-wider w-16">
                    Dept
                  </th>
                  {objectifs.map((obj) => {
                    const axe = axes.find((a) => a.id === obj.axeId);
                    return (
                      <th
                        key={obj.id}
                        className="px-1 py-3 text-center text-xs font-medium min-w-[70px]"
                      >
                        <div className="flex flex-col items-center gap-1">
                          <span
                            className="font-bold text-[10px]"
                            style={{ color: axe?.couleur ?? "#06b6d4" }}
                          >
                            {obj.code}
                          </span>
                          <span className="text-[9px] text-foreground-secondary/50 max-w-[80px] line-clamp-2 leading-tight">
                            {obj.libelle}
                          </span>
                        </div>
                      </th>
                    );
                  })}
                </tr>
              </thead>
              <tbody>
                {groupedStrategies.map(({ dept, strategies }) =>
                  strategies.map((strat, si) => {
                    const isSelected = selectedStratId === strat.id;

                    return (
                      <motion.tr
                        key={strat.id}
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: si * 0.02 }}
                        onClick={() => handleStrategyClick(strat.id)}
                        className={cn(
                          "border-b border-white/[0.04] cursor-pointer transition-colors",
                          isSelected
                            ? "bg-cyan-500/[0.08]"
                            : "hover:bg-white/[0.03]"
                        )}
                      >
                        <td className="sticky left-0 z-10 bg-[#0a0e1a]/80 backdrop-blur-sm px-4 py-2.5">
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-mono text-foreground-secondary/70">
                              {strat.code}
                            </span>
                            <span
                              className={cn(
                                "text-sm truncate max-w-[250px]",
                                isSelected
                                  ? "text-cyan-300 font-medium"
                                  : "text-foreground/80"
                              )}
                            >
                              {strat.libelle}
                            </span>
                          </div>
                        </td>
                        <td className="sticky left-0 z-10 bg-[#0a0e1a]/80 backdrop-blur-sm px-2 py-2.5">
                          <span
                            className="inline-flex items-center justify-center px-1.5 py-0.5 rounded text-[10px] font-bold"
                            style={{
                              backgroundColor: `${dept.couleur}20`,
                              color: dept.couleur,
                            }}
                          >
                            {dept.nomCourt ?? dept.code}
                          </span>
                        </td>
                        {objectifs.map((obj) => {
                          const linked =
                            strat.objectifStrategiqueId === obj.id;
                          return (
                            <td
                              key={obj.id}
                              className="px-1 py-2.5 text-center"
                              onMouseEnter={(e) =>
                                handleCellHover(e, strat, obj, linked, "obj")
                              }
                              onMouseMove={(e) =>
                                setTooltip((prev) =>
                                  prev
                                    ? {
                                        ...prev,
                                        x: e.clientX,
                                        y: e.clientY,
                                      }
                                    : null
                                )
                              }
                              onMouseLeave={handleCellLeave}
                            >
                              <div
                                className={cn(
                                  "w-7 h-7 mx-auto rounded-md transition-all duration-200",
                                  linked
                                    ? "bg-emerald-500/30 border border-emerald-500/50 shadow-[0_0_8px_rgba(16,185,129,0.2)]"
                                    : "bg-white/[0.03] border border-white/[0.06]",
                                  isSelected &&
                                    linked &&
                                    "ring-1 ring-cyan-400/50 bg-emerald-500/40"
                                )}
                              >
                                {linked && (
                                  <div className="w-full h-full flex items-center justify-center">
                                    <div className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                                  </div>
                                )}
                              </div>
                            </td>
                          );
                        })}
                      </motion.tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </GlassPanel>
      </motion.div>

      {/* Summary stats */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6, duration: 0.5 }}
        className="grid grid-cols-2 md:grid-cols-4 gap-4"
      >
        <GlassPanel className="p-4 text-center">
          <p className="text-2xl font-bold text-neon-cyan">
            {allStrategies.length}
          </p>
          <p className="text-xs text-foreground-secondary mt-1">
            Strategies totales
          </p>
        </GlassPanel>
        <GlassPanel className="p-4 text-center">
          <p className="text-2xl font-bold text-neon-emerald">{btgs.length}</p>
          <p className="text-xs text-foreground-secondary mt-1">
            Breakthrough Goals
          </p>
        </GlassPanel>
        <GlassPanel className="p-4 text-center">
          <p className="text-2xl font-bold text-neon-amber">
            {objectifs.length}
          </p>
          <p className="text-xs text-foreground-secondary mt-1">
            Objectifs Strategiques
          </p>
        </GlassPanel>
        <GlassPanel className="p-4 text-center">
          <p className="text-2xl font-bold text-neon-violet">
            {departements.length}
          </p>
          <p className="text-xs text-foreground-secondary mt-1">
            Departements
          </p>
        </GlassPanel>
      </motion.div>

      {/* Tooltip portal */}
      <AnimatePresence>
        {tooltip && (
          <Tooltip x={tooltip.x} y={tooltip.y}>
            {tooltip.content}
          </Tooltip>
        )}
      </AnimatePresence>
    </div>
  );
}
