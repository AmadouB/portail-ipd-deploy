import {
  getAxes,
  getBtgs,
  getDepartements,
  getObjectifs,
  getStrategies,
} from "@/lib/dal";
import { XMatrixClient } from "./x-matrix-client";

// Rendu dynamique : evite les appels DB pendant le build Docker
export const dynamic = 'force-dynamic';

export default async function XMatrixPage() {
  const axes = await getAxes();
  const btgs = await getBtgs();
  const departements = await getDepartements();
  const objectifs = await getObjectifs();
  const allStrategies = await getStrategies();

  return (
    <XMatrixClient
      axes={axes}
      btgs={btgs}
      departements={departements}
      objectifs={objectifs}
      allStrategies={allStrategies}
    />
  );
}
