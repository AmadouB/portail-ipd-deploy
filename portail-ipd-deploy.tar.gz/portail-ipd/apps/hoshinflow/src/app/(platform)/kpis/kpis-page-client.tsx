"use client";

import { useState, useMemo } from "react";
import { useRouter } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import {
  BarChart3,
  TrendingUp,
  AlertTriangle,
  CheckCircle,
  Search,
  X,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";
import { cn, getTauxColor, calculateKpiTaux } from "@/lib/utils";
import { GlassPanel } from "@/components/ui/glass-panel";
import { AnimatedNumber } from "@/components/ui/animated-number";
import { useTrimestre } from "@/lib/trimestre-context";
import type { Projet, Departement, KPI, Trimestre } from "@/lib/types";

interface Props {
  projets: Projet[];
  departements: Departement[];
}

interface EnrichedKpi extends KPI {
  projetId: string;
  projetCode: string;
  projetLibelle: string;
  deptId: string;
  deptCode: string;
  deptCouleur: string;
  computedTaux: number;
  computedStatut: string;
}

const TRIMESTRES: Trimestre[] = ["T1", "T2", "T3", "T4"];
const PAGE_SIZE = 25;

const KPI_STATUTS = [
  { value: "EN_BONNE_VOIE", label: "En bonne voie", color: "#10b981" },
  { value: "A_RISQUE", label: "A risque", color: "#f59e0b" },
  { value: "EN_RETARD", label: "En retard", color: "#ef4444" },
  { value: "NON_MESURE", label: "Non mesure", color: "#6b7280" },
];

function computeKpiStatut(taux: number): string {
  if (taux >= 80) return "EN_BONNE_VOIE";
  if (taux >= 50) return "A_RISQUE";
  if (taux > 0) return "EN_RETARD";
  return "NON_MESURE";
}

function getStatutKpiLabel(statut: string): string {
  return KPI_STATUTS.find((s) => s.value === statut)?.label ?? statut;
}

function getStatutKpiColor(statut: string): string {
  return KPI_STATUTS.find((s) => s.value === statut)?.color ?? "#6b7280";
}

export function KpisPageClient({ projets, departements }: Props) {
  const router = useRouter();
  const { selectedTrimestre } = useTrimestre();
  const [deptFilter, setDeptFilter] = useState("");
  const [statutFilter, setStatutFilter] = useState("");
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(0);

  const allKpis: EnrichedKpi[] = useMemo(() => {
    const result: EnrichedKpi[] = [];
    for (const projet of projets) {
      const dept = departements.find((d) =>
        d.strategies.some((s) => s.projets.some((p) => p.id === projet.id))
      );
      for (const kpi of projet.kpis) {
        let taux = 0;

        if (selectedTrimestre) {
          // Use the selected trimestre
          const mesure = kpi.mesures.find(
            (m) => m.trimestre === selectedTrimestre && m.realise !== null && m.cible !== null
          );
          taux = mesure ? calculateKpiTaux(mesure.realise, mesure.cible) : 0;
        } else {
          // Latest available
          const latestMesure = [...kpi.mesures]
            .reverse()
            .find((m) => m.realise !== null && m.cible !== null);
          taux = latestMesure
            ? calculateKpiTaux(latestMesure.realise, latestMesure.cible)
            : 0;
        }

        result.push({
          ...kpi,
          projetId: projet.id,
          projetCode: projet.code,
          projetLibelle: projet.libelle,
          deptId: dept?.id ?? "",
          deptCode: dept?.code ?? "",
          deptCouleur: dept?.couleur ?? "#6b7280",
          computedTaux: taux,
          computedStatut: computeKpiStatut(taux),
        });
      }
    }
    return result;
  }, [projets, departements, selectedTrimestre]);

  const filtered = useMemo(() => {
    return allKpis.filter((k) => {
      if (deptFilter && k.deptId !== deptFilter) return false;
      if (statutFilter && k.computedStatut !== statutFilter) return false;
      if (search) {
        const q = search.toLowerCase();
        if (
          !k.code.toLowerCase().includes(q) &&
          !k.libelle.toLowerCase().includes(q) &&
          !k.projetCode.toLowerCase().includes(q)
        )
          return false;
      }
      return true;
    });
  }, [allKpis, deptFilter, statutFilter, search]);

  const totalKpis = filtered.length;
  const enBonneVoie = filtered.filter((k) => k.computedStatut === "EN_BONNE_VOIE").length;
  const aRisque = filtered.filter((k) => k.computedStatut === "A_RISQUE").length;
  const enRetard = filtered.filter((k) => k.computedStatut === "EN_RETARD").length;
  const enBonneVoiePct = totalKpis > 0 ? Math.round((enBonneVoie / totalKpis) * 100) : 0;
  const aRisquePct = totalKpis > 0 ? Math.round((aRisque / totalKpis) * 100) : 0;
  const enRetardPct = totalKpis > 0 ? Math.round((enRetard / totalKpis) * 100) : 0;

  const totalPages = Math.ceil(filtered.length / PAGE_SIZE);
  const paged = filtered.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE);
  const activeFilters = [deptFilter, statutFilter, search].filter(Boolean).length;

  const clearFilters = () => {
    setDeptFilter("");
    setStatutFilter("");
    setSearch("");
    setPage(0);
  };

  const summaryCards = [
    { label: "Total KPIs", value: totalKpis, icon: BarChart3, color: "#06b6d4", accent: "cyan" as const, suffix: "" },
    { label: "En bonne voie", value: enBonneVoiePct, icon: CheckCircle, color: "#10b981", accent: "emerald" as const, suffix: "%" },
    { label: "A risque", value: aRisquePct, icon: TrendingUp, color: "#f59e0b", accent: "amber" as const, suffix: "%" },
    { label: "En retard", value: enRetardPct, icon: AlertTriangle, color: "#ef4444", accent: "red" as const, suffix: "%" },
  ];

  return (
    <div className="space-y-6">
      {/* Trimestre indicator */}
      {selectedTrimestre && (
        <div className="flex items-center gap-2 px-1">
          <span className="text-xs text-white/40">Filtré sur</span>
          <span className="px-2 py-0.5 text-xs font-medium rounded-md bg-cyan-500/15 text-cyan-400 border border-cyan-500/30">
            {selectedTrimestre}
          </span>
        </div>
      )}

      {/* Summary cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {summaryCards.map((card, i) => (
          <motion.div
            key={card.label}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: i * 0.08 }}
          >
            <GlassPanel
              variant="glow"
              accentColor={card.accent}
              accentPosition="top"
              className="p-4"
            >
              <div className="flex items-center gap-3">
                <div
                  className="flex items-center justify-center w-10 h-10 rounded-lg"
                  style={{ backgroundColor: `${card.color}15` }}
                >
                  <card.icon size={20} style={{ color: card.color }} />
                </div>
                <div>
                  <div className="flex items-baseline gap-0.5">
                    <AnimatedNumber
                      value={card.value}
                      format="number"
                      className="text-2xl font-bold text-white/90"
                    />
                    {card.suffix && (
                      <span className="text-sm text-white/40 font-medium">{card.suffix}</span>
                    )}
                  </div>
                  <p className="text-xs text-white/40">{card.label}</p>
                </div>
              </div>
            </GlassPanel>
          </motion.div>
        ))}
      </div>

      {/* Filter bar */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.3 }}
        className="flex flex-wrap items-center gap-3 p-4 rounded-xl bg-white/[0.03] border border-white/[0.08] backdrop-blur-xl"
      >
        <div className="relative flex-1 min-w-[200px]">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-white/30" />
          <input
            type="text"
            value={search}
            onChange={(e) => { setSearch(e.target.value); setPage(0); }}
            placeholder="Rechercher un KPI..."
            className="w-full h-10 pl-9 pr-3 rounded-lg text-sm bg-white/[0.03] border border-white/[0.08] text-white/90 placeholder:text-white/30 focus:outline-none focus:border-cyan-500/40 focus:ring-1 focus:ring-cyan-500/20 transition-all duration-200"
          />
        </div>

        <select
          value={deptFilter}
          onChange={(e) => { setDeptFilter(e.target.value); setPage(0); }}
          className="h-10 px-3 rounded-lg text-sm appearance-none bg-white/[0.03] border border-white/[0.08] text-white/70 focus:outline-none focus:border-cyan-500/40 transition-all duration-200 min-w-[160px]"
        >
          <option value="">Departement</option>
          {departements.map((d) => (
            <option key={d.id} value={d.id}>{d.nomCourt || d.code} - {d.nom}</option>
          ))}
        </select>

        <select
          value={statutFilter}
          onChange={(e) => { setStatutFilter(e.target.value); setPage(0); }}
          className="h-10 px-3 rounded-lg text-sm appearance-none bg-white/[0.03] border border-white/[0.08] text-white/70 focus:outline-none focus:border-cyan-500/40 transition-all duration-200 min-w-[140px]"
        >
          <option value="">Statut KPI</option>
          {KPI_STATUTS.map((s) => (
            <option key={s.value} value={s.value}>{s.label}</option>
          ))}
        </select>

        <AnimatePresence>
          {activeFilters > 0 && (
            <motion.button
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              onClick={clearFilters}
              className="flex items-center gap-1 text-xs text-white/40 hover:text-red-400 transition-colors"
            >
              <X size={12} />
              Effacer ({activeFilters})
            </motion.button>
          )}
        </AnimatePresence>
      </motion.div>

      <p className="text-sm text-white/40 px-1">
        <span className="text-white/70 font-medium">{filtered.length}</span>{" "}
        indicateur{filtered.length !== 1 ? "s" : ""}
      </p>

      {/* KPIs Table */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.3, delay: 0.4 }}
      >
        <div className="rounded-xl border border-white/[0.08] overflow-hidden bg-white/[0.02] backdrop-blur-xl">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-white/[0.08] bg-white/[0.03]">
                  <th className="px-4 py-3 text-left text-xs font-medium text-white/50 uppercase tracking-wider w-[90px]">Code</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-white/50 uppercase tracking-wider">Libelle</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-white/50 uppercase tracking-wider w-[100px]">Projet</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-white/50 uppercase tracking-wider w-[80px]">Dept</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-white/50 uppercase tracking-wider w-[80px]">Mode</th>
                  {TRIMESTRES.map((tri) => (
                    <th
                      key={tri}
                      className={cn(
                        "px-3 py-3 text-center text-xs font-medium uppercase tracking-wider w-[70px] transition-colors duration-200",
                        selectedTrimestre === tri
                          ? "text-cyan-400 bg-cyan-500/[0.08]"
                          : "text-white/50"
                      )}
                    >
                      {tri}
                    </th>
                  ))}
                  <th className="px-4 py-3 text-left text-xs font-medium text-white/50 uppercase tracking-wider w-[120px]">Statut</th>
                </tr>
              </thead>
              <tbody>
                <AnimatePresence mode="wait">
                  {paged.map((kpi, i) => {
                    const statutColor = getStatutKpiColor(kpi.computedStatut);
                    const statutLabel = getStatutKpiLabel(kpi.computedStatut);

                    return (
                      <motion.tr
                        key={kpi.id}
                        initial={{ opacity: 0, y: 5 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -5 }}
                        transition={{ duration: 0.15, delay: i * 0.015 }}
                        onClick={() => router.push(`/projets/${kpi.projetId}`)}
                        className="border-b border-white/[0.04] cursor-pointer hover:bg-white/[0.04] transition-colors duration-150"
                      >
                        <td className="px-4 py-2.5">
                          <span className="font-mono text-xs text-cyan-400/70">{kpi.code}</span>
                        </td>
                        <td className="px-4 py-2.5">
                          <span className="text-sm text-white/70 line-clamp-1">{kpi.libelle}</span>
                        </td>
                        <td className="px-4 py-2.5">
                          <span className="font-mono text-xs text-white/50">{kpi.projetCode}</span>
                        </td>
                        <td className="px-4 py-2.5">
                          <span
                            className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-medium border"
                            style={{
                              backgroundColor: `${kpi.deptCouleur}15`,
                              borderColor: `${kpi.deptCouleur}30`,
                              color: kpi.deptCouleur,
                            }}
                          >
                            {kpi.deptCode}
                          </span>
                        </td>
                        <td className="px-4 py-2.5">
                          <span className="text-[10px] text-white/30 uppercase tracking-wider">{kpi.modeCalcul}</span>
                        </td>
                        {TRIMESTRES.map((tri) => {
                          const mesure = kpi.mesures.find((m) => m.trimestre === tri);
                          const taux =
                            mesure && mesure.cible !== null && mesure.realise !== null
                              ? calculateKpiTaux(mesure.realise, mesure.cible)
                              : null;
                          const isSelected = selectedTrimestre === tri;
                          return (
                            <td
                              key={tri}
                              className={cn(
                                "px-3 py-2.5 text-center transition-colors duration-200",
                                isSelected && "bg-cyan-500/[0.06]"
                              )}
                            >
                              {taux !== null ? (
                                <span
                                  className={cn(
                                    "text-xs font-medium tabular-nums",
                                    isSelected && "font-bold"
                                  )}
                                  style={{ color: getTauxColor(taux) }}
                                >
                                  {taux}%
                                </span>
                              ) : (
                                <span className="text-xs text-white/15">{"\u2014"}</span>
                              )}
                            </td>
                          );
                        })}
                        <td className="px-4 py-2.5">
                          <span
                            className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-xs font-medium"
                            style={{ backgroundColor: `${statutColor}15`, color: statutColor }}
                          >
                            <span className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ backgroundColor: statutColor }} />
                            {statutLabel}
                          </span>
                        </td>
                      </motion.tr>
                    );
                  })}
                </AnimatePresence>

                {paged.length === 0 && (
                  <tr>
                    <td colSpan={10} className="px-4 py-12 text-center text-white/30 text-sm">
                      Aucun indicateur ne correspond aux filtres selectionnes.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </motion.div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between">
          <p className="text-xs text-white/40">Page {page + 1} sur {totalPages}</p>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setPage(Math.max(0, page - 1))}
              disabled={page === 0}
              className={cn(
                "flex items-center justify-center w-8 h-8 rounded-lg bg-white/[0.03] border border-white/[0.08] backdrop-blur-xl transition-all duration-200",
                page === 0 ? "opacity-30 cursor-not-allowed" : "hover:bg-white/[0.06] hover:border-white/[0.12]"
              )}
            >
              <ChevronLeft size={14} className="text-white/60" />
            </button>

            {Array.from({ length: Math.min(totalPages, 7) }, (_, i) => {
              let pageNum = i;
              if (totalPages > 7) {
                if (page < 4) pageNum = i;
                else if (page > totalPages - 4) pageNum = totalPages - 7 + i;
                else pageNum = page - 3 + i;
              }
              return (
                <button
                  key={pageNum}
                  onClick={() => setPage(pageNum)}
                  className={cn(
                    "flex items-center justify-center w-8 h-8 rounded-lg text-xs font-medium transition-all duration-200",
                    page === pageNum
                      ? "bg-cyan-500/15 text-cyan-400 border border-cyan-500/30"
                      : "bg-white/[0.03] border border-white/[0.08] text-white/50 hover:bg-white/[0.06]"
                  )}
                >
                  {pageNum + 1}
                </button>
              );
            })}

            <button
              onClick={() => setPage(Math.min(totalPages - 1, page + 1))}
              disabled={page === totalPages - 1}
              className={cn(
                "flex items-center justify-center w-8 h-8 rounded-lg bg-white/[0.03] border border-white/[0.08] backdrop-blur-xl transition-all duration-200",
                page === totalPages - 1 ? "opacity-30 cursor-not-allowed" : "hover:bg-white/[0.06] hover:border-white/[0.12]"
              )}
            >
              <ChevronRight size={14} className="text-white/60" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
