import { getProjets, getDepartements } from "@/lib/dal";

// Rendu dynamique : evite les appels DB pendant le build Docker
export const dynamic = 'force-dynamic';

import { KpisPageClient } from "./kpis-page-client";

export default async function KpisPage() {
  const projets = await getProjets();
  const departements = await getDepartements();

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-white/95 tracking-tight">
          Indicateurs de Performance (KPIs)
        </h1>
        <p className="text-sm text-white/40 mt-1">
          Vue d&apos;ensemble de tous les indicateurs de performance des projets
          strategiques
        </p>
      </div>

      <KpisPageClient projets={projets} departements={departements} />
    </div>
  );
}
