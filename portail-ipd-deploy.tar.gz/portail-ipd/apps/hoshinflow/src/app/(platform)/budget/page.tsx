import { getAxes, getDepartements, getProjets } from "@/lib/dal";

// Rendu dynamique : evite les appels DB pendant le build Docker
export const dynamic = 'force-dynamic';

import { BudgetClient } from "./budget-client";

export default async function BudgetPage() {
  const axes = await getAxes();
  const departements = await getDepartements();
  const projets = await getProjets();

  return (
    <BudgetClient
      axes={axes}
      departements={departements}
      projets={projets}
    />
  );
}
