import { getAxes, getDepartements, getProjets } from "@/lib/dal";
import { BudgetClient } from "./budget-client";

export default async function BudgetPage() {
  const axes = await getAxes();
  const departements = await getDepartements();
  const projets = await getProjets();

  return (
    <BudgetClient
      axes={axes}
      departements={departements}
      projets={projets}
    />
  );
}
