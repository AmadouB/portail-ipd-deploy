"use client";

import { useMemo } from "react";
import { motion } from "framer-motion";
import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Tooltip,
} from "recharts";
import { Wallet, TrendingUp, TrendingDown, Target } from "lucide-react";
import { GlassPanel } from "@/components/ui/glass-panel";
import { AnimatedNumber } from "@/components/ui/animated-number";
import { BudgetChart } from "@/components/budget/budget-chart";
import { BudgetTable } from "@/components/budget/budget-table";
import { formatBudget } from "@/lib/utils";
import type { AxeStrategique, Departement, Projet } from "@/lib/types";

interface BudgetClientProps {
  axes: AxeStrategique[];
  departements: Departement[];
  projets: Projet[];
}

/* ── Pie tooltip ── */
function PieTooltipContent({
  active,
  payload,
}: {
  active?: boolean;
  payload?: Array<{ name: string; value: number; payload: { couleur: string } }>;
}) {
  if (!active || !payload || payload.length === 0) return null;
  const entry = payload[0];
  return (
    <div className="bg-[#0f1629]/95 backdrop-blur-xl border border-white/10 rounded-lg px-3 py-2 shadow-2xl">
      <p className="text-sm font-medium text-white/90">{entry.name}</p>
      <p className="text-xs text-white/60 mt-1">
        Budget : <span className="text-white/90 font-medium">{formatBudget(entry.value)}</span>
      </p>
    </div>
  );
}

export function BudgetClient({ axes, departements, projets }: BudgetClientProps) {
  /* ── Compute budget totals ── */
  const totals = useMemo(() => {
    let alloue = 0;
    let depense = 0;
    projets.forEach((p) => {
      alloue += p.budgetAlloue ?? 0;
      depense += p.budgetDepense ?? 0;
    });
    const restant = alloue - depense;
    const taux = alloue > 0 ? Math.round((depense / alloue) * 1000) / 10 : 0;
    return { alloue, depense, restant, taux };
  }, [projets]);

  /* ── Budget by department ── */
  const deptBudgets = useMemo(() => {
    return departements
      .map((dept) => {
        let alloue = 0;
        let depense = 0;
        dept.strategies.forEach((s) => {
          s.projets.forEach((p) => {
            alloue += p.budgetAlloue ?? 0;
            depense += p.budgetDepense ?? 0;
          });
        });
        const restant = alloue - depense;
        const taux =
          alloue > 0 ? Math.round((depense / alloue) * 1000) / 10 : 0;
        return {
          code: dept.code,
          nom: dept.nom,
          couleur: dept.couleur,
          alloue,
          depense,
          restant,
          taux,
        };
      })
      .filter((d) => d.alloue > 0);
  }, [departements]);

  /* ── Budget by axe for pie chart ── */
  const axeBudgets = useMemo(() => {
    return axes.map((axe) => {
      let alloue = 0;
      axe.objectifs.forEach((obj) => {
        obj.strategies.forEach((s) => {
          s.projets.forEach((p) => {
            alloue += p.budgetAlloue ?? 0;
          });
        });
      });
      return {
        name: axe.nom,
        value: alloue,
        couleur: axe.couleur,
      };
    });
  }, [axes]);

  const summaryCards = [
    {
      label: "Budget Total Alloue",
      value: totals.alloue,
      icon: Wallet,
      color: "cyan" as const,
      format: "currency" as const,
    },
    {
      label: "Budget Depense",
      value: totals.depense,
      icon: TrendingDown,
      color: "emerald" as const,
      format: "currency" as const,
    },
    {
      label: "Budget Restant",
      value: totals.restant,
      icon: TrendingUp,
      color: "amber" as const,
      format: "currency" as const,
    },
    {
      label: "Taux d'Execution",
      value: totals.taux,
      icon: Target,
      color: "violet" as const,
      format: "percent" as const,
    },
  ];

  const iconColorMap = {
    cyan: "text-neon-cyan bg-neon-cyan/10",
    emerald: "text-neon-emerald bg-neon-emerald/10",
    amber: "text-neon-amber bg-neon-amber/10",
    violet: "text-neon-violet bg-neon-violet/10",
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="flex items-center gap-3"
      >
        <div className="w-10 h-10 rounded-lg bg-neon-amber/10 flex items-center justify-center">
          <Wallet className="w-5 h-5 text-neon-amber" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-foreground">
            Suivi Budgetaire
          </h1>
          <p className="text-sm text-foreground-secondary">
            Vue d'ensemble des budgets alloues et depenses
          </p>
        </div>
      </motion.div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {summaryCards.map((card, i) => {
          const Icon = card.icon;
          return (
            <motion.div
              key={card.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 + i * 0.1, duration: 0.5 }}
            >
              <GlassPanel
                variant="glow"
                accentColor={card.color}
                className="p-5"
              >
                <div className="flex items-start justify-between mb-3">
                  <span className="text-sm text-white/50 font-medium">
                    {card.label}
                  </span>
                  <div
                    className={`w-8 h-8 rounded-lg flex items-center justify-center ${iconColorMap[card.color]}`}
                  >
                    <Icon size={16} />
                  </div>
                </div>
                <div>
                  {card.format === "percent" ? (
                    <AnimatedNumber
                      value={card.value}
                      format="percent"
                      decimals={1}
                      colorByValue
                      className="text-2xl font-bold"
                    />
                  ) : (
                    <p className="text-2xl font-bold text-foreground tabular-nums">
                      {formatBudget(card.value)}
                    </p>
                  )}
                </div>
              </GlassPanel>
            </motion.div>
          );
        })}
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Bar Chart */}
        <motion.div
          className="lg:col-span-2"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.5 }}
        >
          <GlassPanel className="p-5">
            <h2 className="text-lg font-semibold text-foreground mb-1">
              Alloue vs Depense par Departement
            </h2>
            <p className="text-xs text-foreground-secondary mb-4">
              Comparaison des budgets alloues et depenses
            </p>
            <BudgetChart data={deptBudgets} />
          </GlassPanel>
        </motion.div>

        {/* Pie Chart */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, duration: 0.5 }}
        >
          <GlassPanel className="p-5 h-full">
            <h2 className="text-lg font-semibold text-foreground mb-1">
              Repartition par Axe
            </h2>
            <p className="text-xs text-foreground-secondary mb-4">
              Distribution du budget alloue par axe strategique
            </p>
            <div className="h-[280px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={axeBudgets}
                    dataKey="value"
                    nameKey="name"
                    cx="50%"
                    cy="50%"
                    innerRadius={55}
                    outerRadius={95}
                    paddingAngle={3}
                    animationDuration={1200}
                    animationBegin={600}
                    stroke="none"
                  >
                    {axeBudgets.map((entry, index) => (
                      <Cell
                        key={`cell-${index}`}
                        fill={entry.couleur}
                        opacity={0.8}
                      />
                    ))}
                  </Pie>
                  <Tooltip content={<PieTooltipContent />} />
                </PieChart>
              </ResponsiveContainer>
            </div>
            {/* Legend */}
            <div className="space-y-2 mt-2">
              {axeBudgets.map((entry) => (
                <div
                  key={entry.name}
                  className="flex items-center justify-between text-xs"
                >
                  <div className="flex items-center gap-2">
                    <div
                      className="w-2.5 h-2.5 rounded-full"
                      style={{ backgroundColor: entry.couleur }}
                    />
                    <span className="text-foreground-secondary truncate max-w-[140px]">
                      {entry.name}
                    </span>
                  </div>
                  <span className="text-foreground/60 font-mono">
                    {formatBudget(entry.value)}
                  </span>
                </div>
              ))}
            </div>
          </GlassPanel>
        </motion.div>
      </div>

      {/* Budget Table */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6, duration: 0.5 }}
      >
        <GlassPanel className="p-0 overflow-hidden">
          <div className="px-5 py-4 border-b border-white/[0.08]">
            <h2 className="text-lg font-semibold text-foreground">
              Detail par Departement
            </h2>
            <p className="text-xs text-foreground-secondary mt-0.5">
              Ventilation budgetaire detaillee avec taux d'execution
            </p>
          </div>
          <BudgetTable data={deptBudgets} />
        </GlassPanel>
      </motion.div>
    </div>
  );
}
