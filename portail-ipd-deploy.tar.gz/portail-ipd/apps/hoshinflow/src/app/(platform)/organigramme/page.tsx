'use client';

import { motion } from 'framer-motion';
import { Network } from 'lucide-react';
import { GlassPanel } from '@/components/ui/glass-panel';
import { ProgressRing } from '@/components/ui/progress-ring';
import { getDepartements, getOrganisation } from '@/lib/data';
import Link from 'next/link';

export default function OrganigrammePage() {
  const org = getOrganisation();
  const departements = getDepartements();
  const dg = departements.find(d => d.code === 'DG') || departements[0];
  const otherDepts = departements.filter(d => d.code !== 'DG' && d.code !== dg?.code);

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold text-white/95 flex items-center gap-2">
          <Network className="w-6 h-6 text-cyan-400" /> Organigramme
        </h1>
        <p className="text-white/50 mt-1">{org.nom} — Structure organisationnelle</p>
      </div>

      {/* DG at top */}
      <div className="flex justify-center">
        <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }}>
          <GlassPanel variant="glow" accentColor="cyan" className="p-6 text-center w-72">
            <div className="text-lg font-bold text-cyan-400 mb-1">{dg?.code ?? 'DG'}</div>
            <div className="text-sm text-white/80 mb-1">{dg?.nom ?? 'Direction Générale'}</div>
            <div className="text-xs text-white/40 mb-3">{dg?.directeur}</div>
            <ProgressRing value={dg?.tauxCompletion ?? 0} size="sm" />
          </GlassPanel>
        </motion.div>
      </div>

      {/* Connector line */}
      <div className="flex justify-center">
        <div className="w-px h-8 bg-white/10" />
      </div>
      <div className="flex justify-center">
        <div className="w-3/4 h-px bg-white/10" />
      </div>

      {/* Departments grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
        {otherDepts.map((dept, i) => (
          <motion.div
            key={dept.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.05 }}
          >
            <Link href={`/departements/${dept.code}`}>
              <GlassPanel hover className="p-4 text-center h-full">
                <div className="text-base font-bold mb-1" style={{ color: dept.couleur }}>{dept.code}</div>
                <div className="text-xs text-white/60 mb-2 line-clamp-2">{dept.nom}</div>
                <div className="text-[10px] text-white/30 mb-3">{dept.directeur}</div>
                <div className="flex justify-center">
                  <ProgressRing value={dept.tauxCompletion ?? 0} size="sm" />
                </div>
                <div className="mt-2 text-[10px] text-white/30">
                  {dept.totalProjets ?? 0} projets
                </div>
              </GlassPanel>
            </Link>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
