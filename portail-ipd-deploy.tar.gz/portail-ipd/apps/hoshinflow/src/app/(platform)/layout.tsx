import { getServerSessionUser } from "@/lib/auth";
import { AuthProvider } from "@/lib/auth-context";
import PlatformLayout from "@/components/layout/platform-layout";

export default async function PlatformRouteLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const user = await getServerSessionUser();

  return (
    <AuthProvider initialUser={user}>
      <PlatformLayout>{children}</PlatformLayout>
    </AuthProvider>
  );
}
