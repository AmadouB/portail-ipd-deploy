"use client";

import { ProjetsFilterBar } from "@/components/projets/projets-filter-bar";
import { ProjetsTable } from "@/components/projets/projets-table";
import { ProjetsKanban } from "@/components/projets/projets-kanban";
import type { Projet, Departement, AxeStrategique } from "@/lib/types";

interface ProjetsPageClientProps {
  projets: Projet[];
  departements: Departement[];
  axes: AxeStrategique[];
}

export function ProjetsPageClient({
  projets,
  departements,
  axes,
}: ProjetsPageClientProps) {
  return (
    <ProjetsFilterBar projets={projets} departements={departements} axes={axes}>
      {(filteredProjets, viewMode) =>
        viewMode === "table" ? (
          <ProjetsTable
            projets={filteredProjets}
            departements={departements}
          />
        ) : (
          <ProjetsKanban
            projets={filteredProjets}
            departements={departements}
          />
        )
      }
    </ProjetsFilterBar>
  );
}
