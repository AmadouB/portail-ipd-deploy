import { getProjets, getDepartements, getAxes } from "@/lib/dal";
import { ProjetsPageClient } from "./projets-page-client";

export default async function ProjetsPage() {
  const projets = await getProjets();
  const departements = await getDepartements();
  const axes = await getAxes();

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-white/95 tracking-tight">
          Projets & Livrables
        </h1>
        <p className="text-sm text-white/40 mt-1">
          Suivi de l&apos;ensemble des projets strategiques et de leurs
          indicateurs de performance
        </p>
      </div>

      {/* Client-side filter + views */}
      <ProjetsPageClient
        projets={projets}
        departements={departements}
        axes={axes}
      />
    </div>
  );
}
