import { notFound } from "next/navigation";

// Rendu dynamique : evite les appels DB pendant le build Docker
export const dynamic = 'force-dynamic';

import { getProjets, getProjetById, getDepartements, getBtgs } from "@/lib/dal";
import { ProjetDetailClient } from "./projet-detail-client";

export async function generateStaticParams() {
  const projets = await getProjets();
  return projets.map((p) => ({ id: p.id }));
}

interface Props {
  params: Promise<{ id: string }>;
}

export default async function ProjetDetailPage({ params }: Props) {
  const { id } = await params;
  const projet = await getProjetById(id);

  if (!projet) {
    notFound();
  }

  const departements = await getDepartements();
  const btgs = await getBtgs();

  return (
    <ProjetDetailClient
      projet={projet}
      departements={departements}
      btgs={btgs}
    />
  );
}
