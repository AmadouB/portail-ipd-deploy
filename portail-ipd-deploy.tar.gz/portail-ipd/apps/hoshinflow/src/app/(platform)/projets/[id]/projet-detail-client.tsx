"use client";

import { motion } from "framer-motion";
import {
  User,
  Wallet,
  Target,
  Users,
  Info,
  Zap,
  Building2,
  MessageSquare,
  DollarSign,
} from "lucide-react";
import { cn, formatBudget, getTauxColor, calculateProjetScore } from "@/lib/utils";
import { GlassPanel } from "@/components/ui/glass-panel";
import { StatusBadge } from "@/components/ui/status-badge";
import { ProgressRing } from "@/components/ui/progress-ring";
import { Breadcrumb } from "@/components/ui/breadcrumb";
import { KpiDetailCard } from "@/components/projets/kpi-detail-card";
import type { Projet, Departement, BreakthroughGoal } from "@/lib/types";

interface Props {
  projet: Projet;
  departements: Departement[];
  btgs: BreakthroughGoal[];
}

const stagger = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: { staggerChildren: 0.08 },
  },
};

const fadeUp = {
  hidden: { opacity: 0, y: 15 },
  show: { opacity: 1, y: 0, transition: { duration: 0.3 } },
};

export function ProjetDetailClient({ projet, departements, btgs }: Props) {
  const dept = departements.find((d) =>
    d.strategies.some((s) => s.projets.some((p) => p.id === projet.id))
  );
  const score = calculateProjetScore(projet.kpis);

  const budgetAlloue = projet.budgetAlloue ?? 0;
  const budgetDepense = projet.budgetDepense ?? 0;
  const budgetRestant = budgetAlloue - budgetDepense;
  const budgetTaux =
    budgetAlloue > 0 ? Math.round((budgetDepense / budgetAlloue) * 100) : 0;
  const budgetOver = budgetDepense > budgetAlloue;

  return (
    <motion.div
      variants={stagger}
      initial="hidden"
      animate="show"
      className="space-y-6"
    >
      {/* Breadcrumb */}
      <motion.div variants={fadeUp}>
        <Breadcrumb
          items={[
            { label: "Dashboard", href: "/dashboard" },
            { label: "Projets", href: "/projets" },
            { label: projet.code },
          ]}
        />
      </motion.div>

      {/* Project Header */}
      <motion.div variants={fadeUp}>
        <GlassPanel className="p-6">
          <div className="flex items-start justify-between gap-6 flex-wrap">
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-3 mb-2">
                <span className="font-mono text-xl font-bold text-cyan-400">
                  {projet.code}
                </span>
                <StatusBadge status={projet.statut} />
              </div>
              <h1 className="text-xl font-bold text-white/95 mb-3">
                {projet.libelle}
              </h1>
              <div className="flex flex-wrap gap-4 text-sm text-white/50">
                {projet.responsable && (
                  <span className="flex items-center gap-1.5">
                    <User size={14} className="text-white/30" />
                    {projet.responsable}
                  </span>
                )}
                {dept && (
                  <span className="flex items-center gap-1.5">
                    <Building2 size={14} className="text-white/30" />
                    <span
                      className="inline-flex items-center px-1.5 py-0.5 rounded text-xs font-medium border"
                      style={{
                        backgroundColor: `${dept.couleur}15`,
                        borderColor: `${dept.couleur}30`,
                        color: dept.couleur,
                      }}
                    >
                      {dept.nomCourt || dept.code}
                    </span>
                  </span>
                )}
              </div>
            </div>
            <ProgressRing value={score} size="lg" />
          </div>
        </GlassPanel>
      </motion.div>

      {/* Section 1: Informations Generales */}
      <motion.div variants={fadeUp}>
        <h2 className="text-lg font-semibold text-white/90 mb-3 flex items-center gap-2">
          <Info size={18} className="text-cyan-400" />
          Informations Generales
        </h2>
        <GlassPanel className="p-5">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div>
              <p className="text-xs text-white/30 uppercase tracking-wider mb-1">
                Departement
              </p>
              <p className="text-sm text-white/80">
                {dept ? `${dept.code} - ${dept.nom}` : "\u2014"}
              </p>
            </div>
            <div>
              <p className="text-xs text-white/30 uppercase tracking-wider mb-1">
                Strategie
              </p>
              <p className="text-sm text-white/80">
                {projet.strategie
                  ? `${projet.strategie.code} - ${projet.strategie.libelle}`
                  : "\u2014"}
              </p>
            </div>
            <div>
              <p className="text-xs text-white/30 uppercase tracking-wider mb-1">
                Financeur
              </p>
              <p className="text-sm text-white/80">
                {projet.financeur || "\u2014"}
              </p>
            </div>
            <div>
              <p className="text-xs text-white/30 uppercase tracking-wider mb-1">
                Responsable
              </p>
              <p className="text-sm text-white/80">
                {projet.responsable || "\u2014"}
              </p>
            </div>
            <div>
              <p className="text-xs text-white/30 uppercase tracking-wider mb-1">
                Devise
              </p>
              <p className="text-sm text-white/80">{projet.devise}</p>
            </div>
            <div>
              <p className="text-xs text-white/30 uppercase tracking-wider mb-1">
                Statut
              </p>
              <StatusBadge status={projet.statut} />
            </div>
          </div>

          {projet.commentaire && (
            <div className="mt-4 pt-4 border-t border-white/[0.06]">
              <p className="text-xs text-white/30 uppercase tracking-wider mb-1 flex items-center gap-1">
                <MessageSquare size={12} />
                Commentaire
              </p>
              <p className="text-sm text-white/60 leading-relaxed">
                {projet.commentaire}
              </p>
            </div>
          )}
        </GlassPanel>
      </motion.div>

      {/* Section 2: KPIs */}
      <motion.div variants={fadeUp}>
        <h2 className="text-lg font-semibold text-white/90 mb-3 flex items-center gap-2">
          <Target size={18} className="text-cyan-400" />
          Indicateurs de Performance (KPIs)
          {projet.kpis.length > 0 && (
            <span className="text-xs text-white/30 font-normal ml-1">
              ({projet.kpis.length})
            </span>
          )}
        </h2>
        {projet.kpis.length > 0 ? (
          <div className="space-y-4">
            {projet.kpis.map((kpi, index) => (
              <KpiDetailCard key={kpi.id} kpi={kpi} index={index} />
            ))}
          </div>
        ) : (
          <GlassPanel className="p-6">
            <p className="text-center text-white/30 text-sm">
              Aucun KPI defini pour ce projet
            </p>
          </GlassPanel>
        )}
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Section 3: Budget */}
        <motion.div variants={fadeUp}>
          <h2 className="text-lg font-semibold text-white/90 mb-3 flex items-center gap-2">
            <Wallet size={18} className="text-emerald-400" />
            Budget
          </h2>
          <GlassPanel
            variant="glow"
            accentColor={budgetOver ? "red" : "emerald"}
            accentPosition="top"
            className="p-5"
          >
            {budgetAlloue > 0 ? (
              <div className="space-y-4">
                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <p className="text-xs text-white/30 uppercase tracking-wider mb-1">
                      Alloue
                    </p>
                    <p className="text-sm font-semibold text-white/80 tabular-nums">
                      {formatBudget(projet.budgetAlloue, projet.devise)}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs text-white/30 uppercase tracking-wider mb-1">
                      Depense
                    </p>
                    <p
                      className={cn(
                        "text-sm font-semibold tabular-nums",
                        budgetOver ? "text-red-400" : "text-amber-400"
                      )}
                    >
                      {formatBudget(projet.budgetDepense, projet.devise)}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs text-white/30 uppercase tracking-wider mb-1">
                      Restant
                    </p>
                    <p
                      className={cn(
                        "text-sm font-semibold tabular-nums",
                        budgetRestant < 0 ? "text-red-400" : "text-emerald-400"
                      )}
                    >
                      {formatBudget(budgetRestant, projet.devise)}
                    </p>
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between text-xs text-white/40 mb-1.5">
                    <span>Execution budgetaire</span>
                    <span
                      className={cn(
                        "font-medium tabular-nums",
                        budgetOver ? "text-red-400" : "text-white/60"
                      )}
                    >
                      {budgetTaux}%
                    </span>
                  </div>
                  <div className="w-full h-2 rounded-full bg-white/[0.06] overflow-hidden">
                    <motion.div
                      className={cn(
                        "h-full rounded-full",
                        budgetOver
                          ? "bg-gradient-to-r from-red-500 to-red-400"
                          : "bg-gradient-to-r from-cyan-500 to-emerald-500"
                      )}
                      initial={{ width: 0 }}
                      animate={{ width: `${Math.min(budgetTaux, 100)}%` }}
                      transition={{ duration: 1, ease: "easeOut", delay: 0.3 }}
                    />
                  </div>
                </div>

                <div className="flex items-center gap-1.5 text-xs text-white/30">
                  <DollarSign size={12} />
                  Devise: {projet.devise}
                </div>
              </div>
            ) : (
              <p className="text-center text-white/30 text-sm py-4">
                Aucun budget defini
              </p>
            )}
          </GlassPanel>
        </motion.div>

        {/* Section 4: Contributeurs */}
        <motion.div variants={fadeUp}>
          <h2 className="text-lg font-semibold text-white/90 mb-3 flex items-center gap-2">
            <Users size={18} className="text-violet-400" />
            Contributeurs
            {projet.contributeurs.length > 0 && (
              <span className="text-xs text-white/30 font-normal ml-1">
                ({projet.contributeurs.length})
              </span>
            )}
          </h2>
          <GlassPanel className="p-5">
            {projet.contributeurs.length > 0 ? (
              <div className="space-y-1">
                {projet.contributeurs
                  .sort((a, b) => a.rang - b.rang)
                  .map((contrib) => {
                    const contribDept = departements.find(
                      (d) => d.id === contrib.departementId
                    );
                    return (
                      <div
                        key={contrib.id}
                        className={cn(
                          "flex items-center justify-between py-2.5 px-3 rounded-lg",
                          "hover:bg-white/[0.03] transition-colors"
                        )}
                      >
                        <div className="flex items-center gap-3">
                          <div className="flex items-center justify-center w-7 h-7 rounded-full bg-violet-500/10 border border-violet-500/20">
                            <span className="text-xs font-bold text-violet-400">
                              {contrib.rang}
                            </span>
                          </div>
                          <span className="text-sm text-white/80">
                            {contrib.nom}
                          </span>
                        </div>
                        {contribDept && (
                          <span
                            className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium border"
                            style={{
                              backgroundColor: `${contribDept.couleur}15`,
                              borderColor: `${contribDept.couleur}30`,
                              color: contribDept.couleur,
                            }}
                          >
                            {contribDept.nomCourt || contribDept.code}
                          </span>
                        )}
                      </div>
                    );
                  })}
              </div>
            ) : (
              <p className="text-center text-white/30 text-sm py-4">
                Aucun contributeur
              </p>
            )}
          </GlassPanel>
        </motion.div>
      </div>

      {/* Section 5: BTGs */}
      <motion.div variants={fadeUp}>
        <h2 className="text-lg font-semibold text-white/90 mb-3 flex items-center gap-2">
          <Zap size={18} className="text-amber-400" />
          Objectifs de Percee (BTGs)
        </h2>
        <GlassPanel className="p-5">
          {btgs.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {btgs.map((btg) => {
                const projetBtg = projet.projetBtgs.find(
                  (pb) => pb.btgId === btg.id
                );
                const isLinked = !!projetBtg;
                const isActive = projetBtg?.indicateurBinaire ?? false;

                return (
                  <div
                    key={btg.id}
                    className={cn(
                      "flex items-start gap-3 p-3 rounded-lg border transition-all duration-200",
                      isLinked
                        ? isActive
                          ? "bg-emerald-500/5 border-emerald-500/20"
                          : "bg-amber-500/5 border-amber-500/20"
                        : "bg-white/[0.01] border-white/[0.06] opacity-40"
                    )}
                  >
                    <div
                      className={cn(
                        "flex-shrink-0 w-4 h-4 rounded-full mt-0.5 border-2",
                        isLinked
                          ? isActive
                            ? "bg-emerald-400 border-emerald-400 shadow-[0_0_8px_rgba(16,185,129,0.4)]"
                            : "bg-amber-400 border-amber-400 shadow-[0_0_8px_rgba(245,158,11,0.3)]"
                          : "bg-transparent border-white/20"
                      )}
                    />
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-mono text-white/40 mb-0.5">
                        {btg.code}
                      </p>
                      <p
                        className={cn(
                          "text-sm font-medium",
                          isLinked ? "text-white/80" : "text-white/30"
                        )}
                      >
                        {btg.nom}
                      </p>
                      {isLinked && (
                        <p className="text-[10px] mt-1 uppercase tracking-wider font-medium">
                          {isActive ? (
                            <span className="text-emerald-400">
                              Contributeur actif
                            </span>
                          ) : (
                            <span className="text-amber-400">
                              Contribution partielle
                            </span>
                          )}
                        </p>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <p className="text-center text-white/30 text-sm">
              Aucun BTG defini
            </p>
          )}
        </GlassPanel>
      </motion.div>
    </motion.div>
  );
}
