"use client";

import { useState, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Search,
  X,
  ChevronDown,
  ChevronUp,
  CheckCircle2,
  AlertCircle,
  XCircle,
  Info,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { GlassPanel } from "@/components/ui/glass-panel";
import { AnimatedNumber } from "@/components/ui/animated-number";
import { ProgressRing } from "@/components/ui/progress-ring";
import { useTrimestre } from "@/lib/trimestre-context";
import type {
  AxeStrategique,
  Departement,
  Projet,
  KPI,
  Trimestre,
} from "@/lib/types";

// ─── Niveau de renseignement ─────────────────────

type NiveauRenseignement = "complet" | "partiel" | "non_renseigne";

const CHAMPS_REQUIS = [
  { key: "responsable", label: "Responsable", icon: "👤" },
  { key: "statut_reel", label: "Statut réel", icon: "🔖" },
  { key: "kpi_defini", label: "KPI défini", icon: "📊" },
  { key: "kpi_mesure", label: "KPI mesuré", icon: "✅" },
  { key: "financeur", label: "Financeur", icon: "🏦" },
  { key: "budget", label: "Budget", icon: "💰" },
  { key: "commentaire", label: "Commentaire", icon: "💬" },
  { key: "contributeurs", label: "Contributeurs", icon: "👥" },
];

interface ProjetRenseignement {
  projet: Projet;
  deptCode: string;
  deptCouleur: string;
  strategieCode: string;
  champs: Record<string, boolean>;
  champsRemplis: number;
  champsTotal: number;
  niveau: NiveauRenseignement;
  pct: number;
}

interface DeptSynthese {
  dept: Departement;
  total: number;
  complets: number;
  partiels: number;
  nonRenseignes: number;
  pctGlobal: number;
  champsDetail: { key: string; label: string; icon: string; filled: number; total: number; pct: number }[];
}

function evaluerProjet(
  projet: Projet,
  deptCode: string,
  deptCouleur: string,
  strategieCode: string,
  selectedTrimestre: Trimestre | null
): ProjetRenseignement {
  const champs: Record<string, boolean> = {};

  champs.responsable = !!(projet.responsable && projet.responsable.trim());
  champs.statut_reel = projet.statut !== "NON_DEMARRE";
  champs.kpi_defini = projet.kpis.length > 0;

  // KPI mesuré: au moins un KPI a une mesure avec réalisé renseigné
  if (selectedTrimestre) {
    champs.kpi_mesure = projet.kpis.some((k) =>
      k.mesures.some((m) => m.trimestre === selectedTrimestre && m.realise !== null)
    );
  } else {
    champs.kpi_mesure = projet.kpis.some((k) =>
      k.mesures.some((m) => m.realise !== null)
    );
  }

  champs.financeur = !!(projet.financeur && projet.financeur.trim());
  champs.budget = projet.budgetAlloue !== null && projet.budgetAlloue > 0;
  champs.commentaire = !!(projet.commentaire && projet.commentaire.trim());
  champs.contributeurs = projet.contributeurs && projet.contributeurs.length > 0;

  const champsTotal = CHAMPS_REQUIS.length;
  const champsRemplis = CHAMPS_REQUIS.filter((c) => champs[c.key]).length;
  const pct = Math.round((champsRemplis / champsTotal) * 100);

  let niveau: NiveauRenseignement;
  if (champsRemplis === champsTotal) niveau = "complet";
  else if (champsRemplis > 0) niveau = "partiel";
  else niveau = "non_renseigne";

  return {
    projet,
    deptCode,
    deptCouleur,
    strategieCode,
    champs,
    champsRemplis,
    champsTotal,
    niveau,
    pct,
  };
}

const NIVEAU_CONFIG = {
  complet: {
    label: "Complet",
    color: "#10b981",
    bg: "bg-emerald-500/10",
    border: "border-emerald-500/20",
    text: "text-emerald-400",
    icon: CheckCircle2,
  },
  partiel: {
    label: "Partiel",
    color: "#f59e0b",
    bg: "bg-amber-500/10",
    border: "border-amber-500/20",
    text: "text-amber-400",
    icon: AlertCircle,
  },
  non_renseigne: {
    label: "Non renseigné",
    color: "#ef4444",
    bg: "bg-red-500/10",
    border: "border-red-500/20",
    text: "text-red-400",
    icon: XCircle,
  },
};

// ─── Component ────────────────────────────────────

interface Props {
  departements: Departement[];
  axes: AxeStrategique[];
}

export function MappingClient({ departements, axes }: Props) {
  const { selectedTrimestre } = useTrimestre();
  const [search, setSearch] = useState("");
  const [deptFilter, setDeptFilter] = useState("");
  const [axeFilter, setAxeFilter] = useState("");
  const [niveauFilter, setNiveauFilter] = useState<NiveauRenseignement | "">("");
  const [champFilter, setChampFilter] = useState("");
  const [viewMode, setViewMode] = useState<"synthese" | "detail">("synthese");
  const [expandedDept, setExpandedDept] = useState<string | null>(null);

  // Build dept -> axe mapping
  const deptAxeMap = useMemo(() => {
    const map = new Map<string, Set<string>>();
    for (const axe of axes) {
      for (const obj of axe.objectifs) {
        for (const str of obj.strategies) {
          if (!map.has(str.departementId)) map.set(str.departementId, new Set());
          map.get(str.departementId)!.add(axe.id);
        }
      }
    }
    return map;
  }, [axes]);

  // Evaluate all projects
  const allProjets: ProjetRenseignement[] = useMemo(() => {
    const result: ProjetRenseignement[] = [];
    for (const dept of departements) {
      for (const str of dept.strategies) {
        for (const p of str.projets) {
          result.push(evaluerProjet(p, dept.code, dept.couleur, str.code, selectedTrimestre));
        }
      }
    }
    return result;
  }, [departements, selectedTrimestre]);

  // Dept syntheses
  const deptSyntheses: DeptSynthese[] = useMemo(() => {
    return departements.map((dept) => {
      const projets = allProjets.filter((p) => p.deptCode === dept.code);
      const total = projets.length;
      const complets = projets.filter((p) => p.niveau === "complet").length;
      const partiels = projets.filter((p) => p.niveau === "partiel").length;
      const nonRenseignes = projets.filter((p) => p.niveau === "non_renseigne").length;
      const pctGlobal = total > 0
        ? Math.round(projets.reduce((s, p) => s + p.pct, 0) / total)
        : 0;

      const champsDetail = CHAMPS_REQUIS.map((c) => {
        const filled = projets.filter((p) => p.champs[c.key]).length;
        return { ...c, filled, total, pct: total > 0 ? Math.round((filled / total) * 100) : 0 };
      });

      return { dept, total, complets, partiels, nonRenseignes, pctGlobal, champsDetail };
    });
  }, [departements, allProjets]);

  // Filter syntheses
  const filteredSyntheses = useMemo(() => {
    let result = deptSyntheses;
    if (deptFilter) result = result.filter((d) => d.dept.code === deptFilter);
    if (axeFilter) {
      result = result.filter((d) => {
        const axeIds = deptAxeMap.get(d.dept.id);
        return axeIds?.has(axeFilter);
      });
    }
    if (niveauFilter) {
      result = result.filter((d) => {
        if (niveauFilter === "complet") return d.complets > 0;
        if (niveauFilter === "partiel") return d.partiels > 0;
        if (niveauFilter === "non_renseigne") return d.nonRenseignes > 0;
        return true;
      });
    }
    if (champFilter) {
      result = result.filter((d) => {
        const c = d.champsDetail.find((cd) => cd.key === champFilter);
        return c && c.pct < 100;
      });
    }
    if (search) {
      const q = search.toLowerCase();
      result = result.filter(
        (d) => d.dept.code.toLowerCase().includes(q) || d.dept.nom.toLowerCase().includes(q)
      );
    }
    return result;
  }, [deptSyntheses, deptFilter, axeFilter, niveauFilter, champFilter, search, deptAxeMap]);

  // Filter detail projets
  const filteredProjets = useMemo(() => {
    let result = allProjets;
    if (deptFilter) result = result.filter((p) => p.deptCode === deptFilter);
    if (niveauFilter) result = result.filter((p) => p.niveau === niveauFilter);
    if (champFilter) result = result.filter((p) => !p.champs[champFilter]);
    if (search) {
      const q = search.toLowerCase();
      result = result.filter(
        (p) =>
          p.deptCode.toLowerCase().includes(q) ||
          p.projet.code.toLowerCase().includes(q) ||
          p.projet.libelle.toLowerCase().includes(q) ||
          (p.projet.responsable && p.projet.responsable.toLowerCase().includes(q))
      );
    }
    return result;
  }, [allProjets, deptFilter, niveauFilter, champFilter, search]);

  // Global stats
  const totalProjets = allProjets.length;
  const totalComplets = allProjets.filter((p) => p.niveau === "complet").length;
  const totalPartiels = allProjets.filter((p) => p.niveau === "partiel").length;
  const totalNonRenseignes = allProjets.filter((p) => p.niveau === "non_renseigne").length;
  const avgPct = totalProjets > 0
    ? Math.round(allProjets.reduce((s, p) => s + p.pct, 0) / totalProjets)
    : 0;

  const activeFilters = [search, deptFilter, axeFilter, niveauFilter, champFilter].filter(Boolean).length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-foreground">
          Niveau de Renseignement
        </h1>
        <p className="text-sm text-foreground-secondary mt-1">
          Suivi de la complétude des données par structure et par projet
        </p>
      </div>

      {selectedTrimestre && (
        <div className="flex items-center gap-2 px-1">
          <span className="text-xs text-white/40">Filtré sur</span>
          <span className="px-2 py-0.5 text-xs font-medium rounded-md bg-cyan-500/15 text-cyan-400 border border-cyan-500/30">
            {selectedTrimestre}
          </span>
        </div>
      )}

      {/* Summary cards — 4 niveaux */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }}>
          <GlassPanel variant="glow" accentColor="cyan" accentPosition="top" className="p-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs font-medium text-white/40 uppercase tracking-wider mb-1">Taux Global</p>
                <AnimatedNumber value={avgPct} format="percent" colorByValue className="text-3xl font-bold" />
                <p className="text-xs text-white/30 mt-1">{totalProjets} projets évalués</p>
              </div>
              <ProgressRing value={avgPct} size="md" />
            </div>
          </GlassPanel>
        </motion.div>

        {([
          { niveau: "complet" as const, count: totalComplets },
          { niveau: "partiel" as const, count: totalPartiels },
          { niveau: "non_renseigne" as const, count: totalNonRenseignes },
        ]).map((item, i) => {
          const cfg = NIVEAU_CONFIG[item.niveau];
          const Icon = cfg.icon;
          const pct = totalProjets > 0 ? Math.round((item.count / totalProjets) * 100) : 0;
          return (
            <motion.div
              key={item.niveau}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: (i + 1) * 0.08 }}
            >
              <GlassPanel
                className={cn("p-5 cursor-pointer transition-all duration-200", niveauFilter === item.niveau && "ring-1 ring-offset-0", niveauFilter === item.niveau ? `ring-[${cfg.color}]` : "")}
                onClick={() => setNiveauFilter((prev) => (prev === item.niveau ? "" : item.niveau))}
              >
                <div className="flex items-center gap-2 mb-2">
                  <Icon size={16} style={{ color: cfg.color }} />
                  <p className="text-xs font-medium text-white/40 uppercase tracking-wider">{cfg.label}</p>
                </div>
                <div className="flex items-baseline gap-2">
                  <AnimatedNumber value={item.count} format="number" className="text-3xl font-bold text-white/90" />
                  <span className="text-sm text-white/30">({pct}%)</span>
                </div>
                <div className="mt-2 h-1.5 rounded-full bg-white/[0.06] overflow-hidden">
                  <motion.div
                    className="h-full rounded-full"
                    style={{ backgroundColor: cfg.color }}
                    initial={{ width: 0 }}
                    animate={{ width: `${pct}%` }}
                    transition={{ duration: 0.8, ease: "easeOut", delay: 0.3 }}
                  />
                </div>
              </GlassPanel>
            </motion.div>
          );
        })}
      </div>

      {/* Champs overview */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.3 }}
      >
        <GlassPanel className="p-5">
          <h3 className="text-sm font-semibold text-white/70 mb-4">Taux de renseignement par champ requis</h3>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {CHAMPS_REQUIS.map((c) => {
              const filled = allProjets.filter((p) => p.champs[c.key]).length;
              const pct = totalProjets > 0 ? Math.round((filled / totalProjets) * 100) : 0;
              const isSelected = champFilter === c.key;
              const barColor = pct >= 80 ? "#10b981" : pct >= 50 ? "#f59e0b" : pct > 0 ? "#ef4444" : "#6b7280";
              return (
                <button
                  key={c.key}
                  onClick={() => setChampFilter((prev) => (prev === c.key ? "" : c.key))}
                  className={cn(
                    "flex flex-col items-center gap-1.5 p-3 rounded-lg border transition-all duration-200",
                    isSelected
                      ? "border-cyan-500/40 bg-cyan-500/[0.08] ring-1 ring-cyan-500/20"
                      : "border-white/[0.08] bg-white/[0.02] hover:border-white/[0.15]"
                  )}
                >
                  <span className="text-base">{c.icon}</span>
                  <span className="text-[10px] text-white/50 text-center leading-tight">{c.label}</span>
                  <span className="text-lg font-bold tabular-nums" style={{ color: barColor }}>{pct}%</span>
                  <div className="w-full h-1 rounded-full bg-white/[0.06] overflow-hidden">
                    <div className="h-full rounded-full transition-all duration-500" style={{ width: `${pct}%`, backgroundColor: barColor }} />
                  </div>
                  <span className="text-[9px] text-white/25">{filled}/{totalProjets}</span>
                </button>
              );
            })}
          </div>
        </GlassPanel>
      </motion.div>

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-3 p-4 rounded-xl bg-white/[0.03] border border-white/[0.08] backdrop-blur-xl">
        <div className="relative flex-1 min-w-[180px]">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-white/30" />
          <input
            type="text" value={search} onChange={(e) => setSearch(e.target.value)}
            placeholder="Rechercher..."
            className="w-full h-10 pl-9 pr-3 rounded-lg text-sm bg-white/[0.03] border border-white/[0.08] text-white/90 placeholder:text-white/30 focus:outline-none focus:border-cyan-500/40 focus:ring-1 focus:ring-cyan-500/20 transition-all"
          />
        </div>
        <select value={deptFilter} onChange={(e) => setDeptFilter(e.target.value)} className="h-10 px-3 rounded-lg text-sm appearance-none bg-white/[0.03] border border-white/[0.08] text-white/70 focus:outline-none focus:border-cyan-500/40 transition-all min-w-[130px]">
          <option value="">Structure</option>
          {departements.map((d) => (<option key={d.code} value={d.code}>{d.code} - {d.nom}</option>))}
        </select>
        <select value={axeFilter} onChange={(e) => setAxeFilter(e.target.value)} className="h-10 px-3 rounded-lg text-sm appearance-none bg-white/[0.03] border border-white/[0.08] text-white/70 focus:outline-none focus:border-cyan-500/40 transition-all min-w-[130px]">
          <option value="">Axe</option>
          {axes.map((a) => (<option key={a.id} value={a.id}>{a.code} - {a.nom}</option>))}
        </select>
        <select value={niveauFilter} onChange={(e) => setNiveauFilter(e.target.value as NiveauRenseignement | "")} className="h-10 px-3 rounded-lg text-sm appearance-none bg-white/[0.03] border border-white/[0.08] text-white/70 focus:outline-none focus:border-cyan-500/40 transition-all min-w-[130px]">
          <option value="">Niveau</option>
          <option value="complet">Complet</option>
          <option value="partiel">Partiel</option>
          <option value="non_renseigne">Non renseigné</option>
        </select>
        <select value={champFilter} onChange={(e) => setChampFilter(e.target.value)} className="h-10 px-3 rounded-lg text-sm appearance-none bg-white/[0.03] border border-white/[0.08] text-white/70 focus:outline-none focus:border-cyan-500/40 transition-all min-w-[140px]">
          <option value="">Champ manquant</option>
          {CHAMPS_REQUIS.map((c) => (<option key={c.key} value={c.key}>{c.icon} {c.label}</option>))}
        </select>

        <div className="flex items-center gap-1 p-1 rounded-lg bg-white/[0.03] border border-white/[0.08]">
          <button onClick={() => setViewMode("synthese")} className={cn("px-3 py-1.5 rounded-md text-xs font-medium transition-all", viewMode === "synthese" ? "bg-cyan-500/15 text-cyan-400" : "text-white/40 hover:text-white/60")}>Synthèse</button>
          <button onClick={() => setViewMode("detail")} className={cn("px-3 py-1.5 rounded-md text-xs font-medium transition-all", viewMode === "detail" ? "bg-cyan-500/15 text-cyan-400" : "text-white/40 hover:text-white/60")}>Détail</button>
        </div>

        <AnimatePresence>
          {activeFilters > 0 && (
            <motion.button initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.9 }}
              onClick={() => { setSearch(""); setDeptFilter(""); setAxeFilter(""); setNiveauFilter(""); setChampFilter(""); }}
              className="flex items-center gap-1 text-xs text-white/40 hover:text-red-400 transition-colors"
            >
              <X size={12} /> Effacer ({activeFilters})
            </motion.button>
          )}
        </AnimatePresence>
      </div>

      {/* ─── SYNTHESE VIEW ─── */}
      {viewMode === "synthese" && (
        <div className="space-y-3">
          {filteredSyntheses.map((ds, i) => {
            const isExpanded = expandedDept === ds.dept.id;
            return (
              <motion.div key={ds.dept.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.2, delay: i * 0.03 }}>
                <GlassPanel className="overflow-hidden">
                  <button
                    onClick={() => setExpandedDept((prev) => (prev === ds.dept.id ? null : ds.dept.id))}
                    className="w-full flex items-center gap-4 p-4 hover:bg-white/[0.02] transition-colors"
                  >
                    <ProgressRing value={ds.pctGlobal} size="sm" />

                    <div className="flex-1 min-w-0 text-left">
                      <div className="flex items-center gap-2">
                        <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-bold border" style={{ backgroundColor: `${ds.dept.couleur}15`, borderColor: `${ds.dept.couleur}30`, color: ds.dept.couleur }}>
                          {ds.dept.code}
                        </span>
                        <span className="text-sm font-medium text-white/80 truncate">{ds.dept.nom}</span>
                      </div>
                      <p className="text-xs text-white/40 mt-0.5">{ds.total} projets</p>
                    </div>

                    {/* 3 badges */}
                    <div className="hidden md:flex items-center gap-2">
                      {([
                        { n: "complet" as const, count: ds.complets },
                        { n: "partiel" as const, count: ds.partiels },
                        { n: "non_renseigne" as const, count: ds.nonRenseignes },
                      ]).map((b) => {
                        const cfg = NIVEAU_CONFIG[b.n];
                        return (
                          <span key={b.n} className={cn("inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-medium border", cfg.bg, cfg.border, cfg.text)}>
                            {b.count}
                          </span>
                        );
                      })}
                    </div>

                    <span className={cn("px-2 py-0.5 rounded-full text-xs font-bold tabular-nums", ds.pctGlobal >= 80 ? "text-emerald-400" : ds.pctGlobal >= 50 ? "text-amber-400" : "text-red-400")}>
                      {ds.pctGlobal}%
                    </span>

                    {isExpanded ? <ChevronUp size={16} className="text-white/30" /> : <ChevronDown size={16} className="text-white/30" />}
                  </button>

                  <AnimatePresence>
                    {isExpanded && (
                      <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.2 }} className="overflow-hidden">
                        <div className="border-t border-white/[0.06] p-4 space-y-4">
                          {/* Champs detail */}
                          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                            {ds.champsDetail.map((c) => {
                              const barColor = c.pct >= 80 ? "#10b981" : c.pct >= 50 ? "#f59e0b" : c.pct > 0 ? "#ef4444" : "#6b7280";
                              return (
                                <div key={c.key} className="rounded-lg p-3 border border-white/[0.06] bg-white/[0.02]">
                                  <div className="flex items-center justify-between mb-1.5">
                                    <span className="text-[10px] text-white/50">{c.icon} {c.label}</span>
                                    <span className="text-sm font-bold tabular-nums" style={{ color: barColor }}>{c.pct}%</span>
                                  </div>
                                  <div className="h-1 rounded-full bg-white/[0.06] overflow-hidden">
                                    <div className="h-full rounded-full transition-all duration-500" style={{ width: `${c.pct}%`, backgroundColor: barColor }} />
                                  </div>
                                  <span className="text-[9px] text-white/25 mt-1 block">{c.filled}/{c.total}</span>
                                </div>
                              );
                            })}
                          </div>

                          {/* Projet list inside dept */}
                          <div className="rounded-lg border border-white/[0.06] overflow-hidden">
                            <table className="w-full">
                              <thead>
                                <tr className="bg-white/[0.02] border-b border-white/[0.06]">
                                  <th className="px-3 py-2 text-left text-[10px] text-white/40 uppercase">Projet</th>
                                  {CHAMPS_REQUIS.map((c) => (
                                    <th key={c.key} className="px-2 py-2 text-center text-[10px] text-white/40" title={c.label}>{c.icon}</th>
                                  ))}
                                  <th className="px-3 py-2 text-center text-[10px] text-white/40 uppercase">Niveau</th>
                                </tr>
                              </thead>
                              <tbody>
                                {allProjets
                                  .filter((p) => p.deptCode === ds.dept.code)
                                  .map((p) => {
                                    const cfg = NIVEAU_CONFIG[p.niveau];
                                    return (
                                      <tr key={p.projet.id} className="border-b border-white/[0.03] hover:bg-white/[0.02]">
                                        <td className="px-3 py-2">
                                          <span className="text-xs text-white/60 line-clamp-1">{p.projet.code} {p.projet.libelle}</span>
                                        </td>
                                        {CHAMPS_REQUIS.map((c) => (
                                          <td key={c.key} className="px-2 py-2 text-center">
                                            {p.champs[c.key] ? (
                                              <span className="inline-block w-3 h-3 rounded-full bg-emerald-500/30 border border-emerald-500/40" />
                                            ) : (
                                              <span className="inline-block w-3 h-3 rounded-full bg-red-500/20 border border-red-500/30" />
                                            )}
                                          </td>
                                        ))}
                                        <td className="px-3 py-2 text-center">
                                          <span className={cn("inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full text-[9px] font-medium border", cfg.bg, cfg.border, cfg.text)}>
                                            {cfg.label}
                                          </span>
                                        </td>
                                      </tr>
                                    );
                                  })}
                              </tbody>
                            </table>
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </GlassPanel>
              </motion.div>
            );
          })}
        </div>
      )}

      {/* ─── DETAIL VIEW ─── */}
      {viewMode === "detail" && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.3 }}>
          <p className="text-sm text-white/40 px-1 mb-3">
            <span className="text-white/70 font-medium">{filteredProjets.length}</span> projet{filteredProjets.length !== 1 ? "s" : ""}
          </p>
          <div className="rounded-xl border border-white/[0.08] overflow-hidden bg-white/[0.02] backdrop-blur-xl">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-white/[0.08] bg-white/[0.03]">
                    <th className="px-3 py-3 text-left text-[10px] font-medium text-white/50 uppercase w-[60px]">Dept</th>
                    <th className="px-3 py-3 text-left text-[10px] font-medium text-white/50 uppercase w-[80px]">Code</th>
                    <th className="px-3 py-3 text-left text-[10px] font-medium text-white/50 uppercase">Projet</th>
                    {CHAMPS_REQUIS.map((c) => (
                      <th key={c.key} className={cn("px-2 py-3 text-center text-[10px] font-medium uppercase w-[40px]", champFilter === c.key ? "text-cyan-400 bg-cyan-500/[0.06]" : "text-white/50")} title={c.label}>
                        {c.icon}
                      </th>
                    ))}
                    <th className="px-3 py-3 text-center text-[10px] font-medium text-white/50 uppercase w-[50px]">%</th>
                    <th className="px-3 py-3 text-center text-[10px] font-medium text-white/50 uppercase w-[90px]">Niveau</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredProjets.slice(0, 100).map((p, i) => {
                    const cfg = NIVEAU_CONFIG[p.niveau];
                    return (
                      <motion.tr
                        key={p.projet.id}
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ duration: 0.1, delay: Math.min(i * 0.01, 0.5) }}
                        className="border-b border-white/[0.04] hover:bg-white/[0.03] transition-colors"
                      >
                        <td className="px-3 py-2.5">
                          <span className="inline-flex px-1.5 py-0.5 rounded text-[10px] font-bold border" style={{ backgroundColor: `${p.deptCouleur}15`, borderColor: `${p.deptCouleur}30`, color: p.deptCouleur }}>
                            {p.deptCode}
                          </span>
                        </td>
                        <td className="px-3 py-2.5">
                          <span className="font-mono text-[10px] text-cyan-400/60">{p.projet.code}</span>
                        </td>
                        <td className="px-3 py-2.5">
                          <span className="text-xs text-white/60 line-clamp-1">{p.projet.libelle}</span>
                        </td>
                        {CHAMPS_REQUIS.map((c) => (
                          <td key={c.key} className={cn("px-2 py-2.5 text-center", champFilter === c.key && "bg-cyan-500/[0.04]")}>
                            {p.champs[c.key] ? (
                              <span className="inline-block w-3 h-3 rounded-full bg-emerald-500/30 border border-emerald-500/40" />
                            ) : (
                              <span className="inline-block w-3 h-3 rounded-full bg-red-500/20 border border-red-500/30" />
                            )}
                          </td>
                        ))}
                        <td className="px-3 py-2.5 text-center">
                          <span className="text-xs font-bold tabular-nums" style={{ color: p.pct >= 80 ? "#10b981" : p.pct >= 50 ? "#f59e0b" : "#ef4444" }}>
                            {p.pct}%
                          </span>
                        </td>
                        <td className="px-3 py-2.5 text-center">
                          <span className={cn("inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full text-[9px] font-medium border", cfg.bg, cfg.border, cfg.text)}>
                            {cfg.label}
                          </span>
                        </td>
                      </motion.tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
          {filteredProjets.length > 100 && (
            <p className="text-xs text-white/30 text-center mt-3">
              Affichage limité à 100 projets. Utilisez les filtres pour affiner.
            </p>
          )}
        </motion.div>
      )}

      {filteredSyntheses.length === 0 && viewMode === "synthese" && (
        <div className="text-center py-16">
          <Info size={40} className="mx-auto text-white/15 mb-3" />
          <p className="text-sm text-white/30">Aucune structure ne correspond aux filtres.</p>
        </div>
      )}

      {/* Legend */}
      <div className="flex items-center justify-center gap-6 pt-2">
        {(["complet", "partiel", "non_renseigne"] as const).map((n) => {
          const cfg = NIVEAU_CONFIG[n];
          return (
            <div key={n} className="flex items-center gap-1.5">
              <div className="w-3 h-3 rounded-full" style={{ backgroundColor: cfg.color }} />
              <span className="text-xs text-white/40">{cfg.label}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
}
