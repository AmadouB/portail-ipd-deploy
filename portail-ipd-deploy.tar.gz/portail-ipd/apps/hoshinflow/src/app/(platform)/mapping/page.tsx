import { getDepartements, getAxes } from "@/lib/dal";

// Rendu dynamique : evite les appels DB pendant le build Docker
export const dynamic = 'force-dynamic';

import { MappingClient } from "./mapping-client";

export default async function MappingPage() {
  const departements = await getDepartements();
  const axes = await getAxes();
  return <MappingClient departements={departements} axes={axes} />;
}
