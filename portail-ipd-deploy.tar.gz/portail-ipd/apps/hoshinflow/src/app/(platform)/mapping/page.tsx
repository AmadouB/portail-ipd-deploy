import { getDepartements, getAxes } from "@/lib/dal";
import { MappingClient } from "./mapping-client";

// Rendu dynamique : evite les appels DB pendant le build Docker
export const dynamic = 'force-dynamic';

export default async function MappingPage() {
  const departements = await getDepartements();
  const axes = await getAxes();
  return <MappingClient departements={departements} axes={axes} />;
}
