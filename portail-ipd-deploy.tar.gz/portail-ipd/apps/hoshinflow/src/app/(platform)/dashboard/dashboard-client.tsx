"use client";

import { useMemo } from "react";
import { VisionBanner } from "@/components/dashboard/vision-banner";
import { KpiSummaryCards } from "@/components/dashboard/kpi-summary-cards";
import { AxesRadar } from "@/components/dashboard/axes-radar";
import { DepartementsGrid } from "@/components/dashboard/departements-grid";
import { TrimestreTimeline } from "@/components/dashboard/trimestre-timeline";
import { AlertsPanel } from "@/components/dashboard/alerts-panel";
import { useTrimestre } from "@/lib/trimestre-context";
import { calculateKpiTaux, calculateProjetScore } from "@/lib/utils";
import type {
  Organisation,
  AxeStrategique,
  Departement,
  Projet,
  KPI,
  Trimestre,
} from "@/lib/types";

interface DashboardClientProps {
  organisation: Organisation;
  axes: AxeStrategique[];
  departements: Departement[];
  projets: Projet[];
}

function computeProjetScore(projet: Projet, tri: Trimestre | null): number {
  if (projet.kpis && projet.kpis.length > 0) {
    return calculateProjetScore(projet.kpis, tri);
  }
  switch (projet.statut) {
    case "COMPLET":
      return 100;
    case "EN_COURS":
      return 50;
    case "EN_RETARD":
      return 25;
    case "EN_ATTENTE":
      return 30;
    default:
      return 0;
  }
}

function computeAxesRadar(
  axes: AxeStrategique[],
  tri: Trimestre | null
): { nom: string; completion: number; couleur: string }[] {
  return axes.map((axe) => {
    const objCompletions = axe.objectifs.map((obj) => {
      const strCompletions = obj.strategies.map((str) => {
        if (str.projets.length === 0) return 0;
        const scores = str.projets.map((p) => computeProjetScore(p, tri));
        return scores.reduce((a, b) => a + b, 0) / scores.length;
      });
      if (strCompletions.length === 0) return 0;
      return strCompletions.reduce((a, b) => a + b, 0) / strCompletions.length;
    });
    if (objCompletions.length === 0)
      return { nom: axe.nom, completion: 0, couleur: axe.couleur };
    const completion =
      Math.round(
        (objCompletions.reduce((a, b) => a + b, 0) / objCompletions.length) * 10
      ) / 10;
    return { nom: axe.nom, completion, couleur: axe.couleur };
  });
}

export function DashboardClient({
  organisation,
  axes,
  departements,
  projets,
}: DashboardClientProps) {
  const { selectedTrimestre } = useTrimestre();

  const metrics = useMemo(() => {
    const tri = selectedTrimestre;

    // Axes radar data
    const axesRadarData = computeAxesRadar(axes, tri);

    // Global completion
    const completionGlobale =
      axesRadarData.length > 0
        ? Math.round(
            (axesRadarData.reduce((s, a) => s + a.completion, 0) /
              axesRadarData.length) *
              10
          ) / 10
        : 0;

    // Total & completed activities
    const totalActivites = projets.length;
    const activitesTerminees = projets.filter(
      (p) => p.statut === "COMPLET"
    ).length;

    // Budget
    const budgetTotal = projets.reduce(
      (sum, p) => sum + (p.budgetAlloue ?? 0),
      0
    );

    // Projets en retard
    const projetsEnRetard = projets.filter((p) => p.statut === "EN_RETARD");

    // KPIs critiques — use selected trimestre or latest
    const kpisCritiques: {
      kpi: KPI;
      projetLibelle: string;
      responsable: string | null;
    }[] = [];

    for (const projet of projets) {
      for (const kpi of projet.kpis) {
        let taux = 0;

        if (tri) {
          // Use only the selected trimestre
          const mesure = kpi.mesures.find(
            (m) =>
              m.trimestre === tri &&
              m.cible !== null &&
              m.cible > 0 &&
              m.realise !== null
          );
          if (mesure) {
            taux = Math.round(
              ((mesure.realise as number) / (mesure.cible as number)) * 100
            );
          }
        } else {
          // Latest available
          const order: Trimestre[] = ["T4", "T3", "T2", "T1"];
          for (const t of order) {
            const mesure = kpi.mesures.find(
              (m) =>
                m.trimestre === t &&
                m.cible !== null &&
                m.cible > 0 &&
                m.realise !== null
            );
            if (mesure) {
              taux = Math.round(
                ((mesure.realise as number) / (mesure.cible as number)) * 100
              );
              break;
            }
          }
        }

        if (taux > 0 && taux < 50) {
          kpisCritiques.push({
            kpi,
            projetLibelle: projet.libelle,
            responsable: projet.responsable,
          });
        }
      }
    }

    return {
      axesRadarData,
      completionGlobale,
      totalActivites,
      budgetTotal,
      activitesTerminees,
      projetsEnRetard,
      kpisCritiques,
    };
  }, [axes, projets, selectedTrimestre]);

  return (
    <div className="space-y-6">
      {/* Vision Banner */}
      <VisionBanner
        nom={organisation.nom}
        vision={organisation.vision}
        anneeDepart={organisation.anneeDepart}
        anneeCible={organisation.anneeCible}
      />

      {/* Trimestre filter indicator */}
      {selectedTrimestre && (
        <div className="flex items-center gap-2 px-1">
          <span className="text-xs text-white/40">
            Filtré sur
          </span>
          <span className="px-2 py-0.5 text-xs font-medium rounded-md bg-cyan-500/15 text-cyan-400 border border-cyan-500/30">
            {selectedTrimestre}
          </span>
        </div>
      )}

      {/* KPI Summary Cards */}
      <KpiSummaryCards
        completionGlobale={metrics.completionGlobale}
        totalActivites={metrics.totalActivites}
        budgetTotal={metrics.budgetTotal}
        activitesTerminees={metrics.activitesTerminees}
      />

      {/* Radar + Departments Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        <div className="lg:col-span-2">
          <AxesRadar axes={metrics.axesRadarData} />
        </div>
        <div className="lg:col-span-3">
          <DepartementsGrid departements={departements} />
        </div>
      </div>

      {/* Timeline */}
      <TrimestreTimeline />

      {/* Alerts */}
      <AlertsPanel
        projetsEnRetard={metrics.projetsEnRetard}
        kpisCritiques={metrics.kpisCritiques}
      />
    </div>
  );
}
