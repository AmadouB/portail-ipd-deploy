import {
  getAxes,
  getDepartements,
  getOrganisation,
  getProjets,
} from "@/lib/dal";
import { DashboardClient } from "./dashboard-client";

export default async function DashboardPage() {
  const organisation = await getOrganisation();
  const axes = await getAxes();
  const departements = await getDepartements();
  const projets = await getProjets();

  return (
    <DashboardClient
      organisation={organisation}
      axes={axes}
      departements={departements}
      projets={projets}
    />
  );
}
