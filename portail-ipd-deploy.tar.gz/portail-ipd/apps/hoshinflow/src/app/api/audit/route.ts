import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { apiGuard, isGuardError } from "@/lib/api-guard";

export async function GET(request: NextRequest) {
  const guard = await apiGuard(request, "audit", "read");
  if (isGuardError(guard)) return guard.response;

  const { searchParams } = new URL(request.url);
  const entityType = searchParams.get("entityType");
  const entityId = searchParams.get("entityId");
  const limit = parseInt(searchParams.get("limit") || "50", 10);

  const where: Record<string, string> = {};
  if (entityType) where.entityType = entityType;
  if (entityId) where.entityId = entityId;

  const logs = await prisma.auditLog.findMany({
    where,
    include: {
      user: {
        select: { id: true, nom: true, email: true },
      },
    },
    orderBy: { createdAt: "desc" },
    take: limit,
  });

  return NextResponse.json(logs);
}
