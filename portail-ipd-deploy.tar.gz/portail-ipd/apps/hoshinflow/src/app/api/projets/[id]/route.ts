import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { apiGuard, isGuardError } from "@/lib/api-guard";

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const guard = await apiGuard(request, "projet", "read");
  if (isGuardError(guard)) return guard.response;

  const { id } = await params;

  const projet = await prisma.projet.findUnique({
    where: { id },
    include: {
      strategie: {
        include: {
          departement: true,
          objectifStrategique: true,
        },
      },
      kpis: {
        include: { mesures: true },
        orderBy: { ordre: "asc" },
      },
      contributeurs: {
        orderBy: { rang: "asc" },
      },
      projetBtgs: {
        include: { btg: true },
      },
    },
  });

  if (!projet) {
    return NextResponse.json(
      { error: "Projet non trouvé" },
      { status: 404 }
    );
  }

  return NextResponse.json(projet);
}

export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const guard = await apiGuard(request, "projet", "update");
  if (isGuardError(guard)) return guard.response;

  const { id } = await params;

  try {
    const oldProjet = await prisma.projet.findUnique({ where: { id } });
    if (!oldProjet) {
      return NextResponse.json(
        { error: "Projet non trouvé" },
        { status: 404 }
      );
    }

    const body = await request.json();
    const projet = await prisma.projet.update({
      where: { id },
      data: body,
      include: {
        kpis: { include: { mesures: true } },
        contributeurs: true,
        projetBtgs: true,
      },
    });

    await prisma.auditLog.create({
      data: {
        userId: guard.user.id,
        action: "UPDATE",
        entityType: "Projet",
        entityId: id,
        oldValue: JSON.stringify(oldProjet),
        newValue: JSON.stringify(projet),
        description: `Mise à jour du projet ${projet.code}`,
      },
    });

    return NextResponse.json(projet);
  } catch {
    return NextResponse.json(
      { error: "Erreur lors de la mise à jour du projet" },
      { status: 500 }
    );
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const guard = await apiGuard(request, "projet", "delete");
  if (isGuardError(guard)) return guard.response;

  const { id } = await params;

  try {
    const projet = await prisma.projet.findUnique({
      where: { id },
      include: { kpis: true },
    });

    if (!projet) {
      return NextResponse.json(
        { error: "Projet non trouvé" },
        { status: 404 }
      );
    }

    // Delete in dependency order
    const kpiIds = projet.kpis.map((k: { id: string }) => k.id);
    if (kpiIds.length > 0) {
      await prisma.mesureKPI.deleteMany({ where: { kpiId: { in: kpiIds } } });
    }
    await prisma.projetBTG.deleteMany({ where: { projetId: id } });
    await prisma.projetContributeur.deleteMany({ where: { projetId: id } });
    await prisma.kPI.deleteMany({ where: { projetId: id } });
    await prisma.projet.delete({ where: { id } });

    await prisma.auditLog.create({
      data: {
        userId: guard.user.id,
        action: "DELETE",
        entityType: "Projet",
        entityId: id,
        oldValue: JSON.stringify(projet),
        description: `Suppression du projet ${projet.code}`,
      },
    });

    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json(
      { error: "Erreur lors de la suppression du projet" },
      { status: 500 }
    );
  }
}
