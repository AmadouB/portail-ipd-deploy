import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { apiGuard, isGuardError } from "@/lib/api-guard";

export async function GET(request: NextRequest) {
  const guard = await apiGuard(request, "projet", "read");
  if (isGuardError(guard)) return guard.response;

  const projets = await prisma.projet.findMany({
    include: {
      kpis: {
        include: { mesures: true },
      },
      contributeurs: true,
      projetBtgs: true,
    },
    orderBy: { createdAt: "desc" },
  });

  return NextResponse.json(projets);
}

export async function POST(request: NextRequest) {
  const guard = await apiGuard(request, "projet", "create");
  if (isGuardError(guard)) return guard.response;

  try {
    const body = await request.json();
    const { strategieId, ...data } = body;

    if (!strategieId) {
      return NextResponse.json(
        { error: "strategieId requis" },
        { status: 400 }
      );
    }

    const projet = await prisma.projet.create({
      data: {
        strategieId,
        ...data,
      },
      include: {
        kpis: { include: { mesures: true } },
        contributeurs: true,
        projetBtgs: true,
      },
    });

    await prisma.auditLog.create({
      data: {
        userId: guard.user.id,
        action: "CREATE",
        entityType: "Projet",
        entityId: projet.id,
        newValue: JSON.stringify(projet),
        description: `Création du projet ${projet.code}`,
      },
    });

    return NextResponse.json(projet, { status: 201 });
  } catch {
    return NextResponse.json(
      { error: "Erreur lors de la création du projet" },
      { status: 500 }
    );
  }
}
