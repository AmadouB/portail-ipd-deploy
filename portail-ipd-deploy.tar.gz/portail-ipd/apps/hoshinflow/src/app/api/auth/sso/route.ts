import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { createSession } from "@/lib/auth";
import { verifySsoToken } from "@/lib/sso";

/**
 * SSO endpoint — called by the Portail IPD iframe.
 * Verifies the SSO token, finds/creates the user, sets a session cookie,
 * and redirects to the dashboard.
 *
 * GET /api/auth/sso?token=xxx&redirect=/dashboard
 */
export async function GET(request: NextRequest) {
  const { searchParams } = request.nextUrl;
  const token = searchParams.get("token");
  const redirect = searchParams.get("redirect") || "/dashboard";

  if (!token) {
    return NextResponse.redirect(new URL("/login", request.url));
  }

  // Verify the SSO token signature and expiration
  const payload = await verifySsoToken(token);
  if (!payload) {
    return NextResponse.redirect(new URL("/login?error=sso_invalid", request.url));
  }

  // Find user by email (case-insensitive)
  let user = await prisma.user.findFirst({
    where: { email: { equals: payload.email.toLowerCase() } },
  });

  // Auto-provision user if not found
  if (!user) {
    const nameParts = payload.name.split(" ");
    const prenom = nameParts[0] || "";
    const nom = nameParts.slice(1).join(" ") || payload.name;

    user = await prisma.user.create({
      data: {
        email: payload.email.toLowerCase(),
        nom,
        prenom,
        role: mapPortalRole(payload.role),
        actif: true,
      },
    });
  }

  if (!user.actif) {
    return NextResponse.redirect(new URL("/login?error=disabled", request.url));
  }

  // Create a local session
  const sessionToken = await createSession({
    id: user.id,
    email: user.email,
    nom: user.nom,
    role: user.role,
    departementId: user.departementId,
  });

  // Redirect to dashboard with session cookie set
  const response = NextResponse.redirect(new URL(redirect, request.url));
  response.cookies.set("hoshinflow-session", sessionToken, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "none", // Required for cross-origin iframe
    maxAge: 7 * 24 * 60 * 60,
    path: "/",
  });

  return response;
}

/**
 * Map portal roles to HoshinFlow roles
 */
function mapPortalRole(portalRole: string): string {
  switch (portalRole) {
    case "admin_general":
      return "ADMIN";
    case "cas":
    case "dsi":
      return "DIRECTEUR";
    case "seid":
      return "CHEF_PROJET";
    case "utilisateur":
    default:
      return "CONTRIBUTEUR";
  }
}
