import { NextResponse } from "next/server";
import { verifySession } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function GET() {
  const session = await verifySession();

  if (!session) {
    return NextResponse.json({ error: "Non authentifié" }, { status: 401 });
  }

  const user = await prisma.user.findUnique({
    where: { id: session.id },
    select: {
      id: true,
      email: true,
      nom: true,
      prenom: true,
      role: true,
      departementId: true,
      actif: true,
    },
  });

  if (!user || !user.actif) {
    return NextResponse.json({ error: "Session invalide" }, { status: 401 });
  }

  return NextResponse.json({ user });
}
