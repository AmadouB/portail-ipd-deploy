import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { apiGuard, isGuardError } from "@/lib/api-guard";

export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const guard = await apiGuard(request, "mesure", "update");
  if (isGuardError(guard)) return guard.response;

  const { id } = await params;

  try {
    const oldMesure = await prisma.mesureKPI.findUnique({ where: { id } });
    if (!oldMesure) {
      return NextResponse.json(
        { error: "Mesure non trouvée" },
        { status: 404 }
      );
    }

    const body = await request.json();
    const { cible, realise, tauxCompletion, commentaire } = body;

    const mesure = await prisma.mesureKPI.update({
      where: { id },
      data: {
        ...(cible !== undefined && { cible }),
        ...(realise !== undefined && { realise }),
        ...(tauxCompletion !== undefined && { tauxCompletion }),
        ...(commentaire !== undefined && { commentaire }),
      },
    });

    await prisma.auditLog.create({
      data: {
        userId: guard.user.id,
        action: "UPDATE",
        entityType: "MesureKPI",
        entityId: id,
        oldValue: JSON.stringify(oldMesure),
        newValue: JSON.stringify(mesure),
        description: `Mise à jour de la mesure ${mesure.trimestre} ${mesure.annee}`,
      },
    });

    return NextResponse.json(mesure);
  } catch {
    return NextResponse.json(
      { error: "Erreur lors de la mise à jour de la mesure" },
      { status: 500 }
    );
  }
}
