import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { apiGuard, isGuardError } from "@/lib/api-guard";

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const guard = await apiGuard(request, "kpi", "read");
  if (isGuardError(guard)) return guard.response;

  const { id } = await params;

  const kpi = await prisma.kPI.findUnique({
    where: { id },
    include: {
      mesures: {
        orderBy: [{ annee: "asc" }, { trimestre: "asc" }],
      },
    },
  });

  if (!kpi) {
    return NextResponse.json({ error: "KPI non trouvé" }, { status: 404 });
  }

  return NextResponse.json(kpi);
}

export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const guard = await apiGuard(request, "kpi", "update");
  if (isGuardError(guard)) return guard.response;

  const { id } = await params;

  try {
    const oldKpi = await prisma.kPI.findUnique({ where: { id } });
    if (!oldKpi) {
      return NextResponse.json({ error: "KPI non trouvé" }, { status: 404 });
    }

    const body = await request.json();
    const kpi = await prisma.kPI.update({
      where: { id },
      data: body,
      include: { mesures: true },
    });

    await prisma.auditLog.create({
      data: {
        userId: guard.user.id,
        action: "UPDATE",
        entityType: "KPI",
        entityId: id,
        oldValue: JSON.stringify(oldKpi),
        newValue: JSON.stringify(kpi),
        description: `Mise à jour du KPI ${kpi.code}`,
      },
    });

    return NextResponse.json(kpi);
  } catch {
    return NextResponse.json(
      { error: "Erreur lors de la mise à jour du KPI" },
      { status: 500 }
    );
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const guard = await apiGuard(request, "kpi", "delete");
  if (isGuardError(guard)) return guard.response;

  const { id } = await params;

  try {
    const kpi = await prisma.kPI.findUnique({ where: { id } });
    if (!kpi) {
      return NextResponse.json({ error: "KPI non trouvé" }, { status: 404 });
    }

    await prisma.mesureKPI.deleteMany({ where: { kpiId: id } });
    await prisma.kPI.delete({ where: { id } });

    await prisma.auditLog.create({
      data: {
        userId: guard.user.id,
        action: "DELETE",
        entityType: "KPI",
        entityId: id,
        oldValue: JSON.stringify(kpi),
        description: `Suppression du KPI ${kpi.code}`,
      },
    });

    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json(
      { error: "Erreur lors de la suppression du KPI" },
      { status: 500 }
    );
  }
}
