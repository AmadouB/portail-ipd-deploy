import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { apiGuard, isGuardError } from "@/lib/api-guard";

export async function POST(request: NextRequest) {
  const guard = await apiGuard(request, "kpi", "create");
  if (isGuardError(guard)) return guard.response;

  try {
    const body = await request.json();
    const { projetId, ...data } = body;

    if (!projetId) {
      return NextResponse.json(
        { error: "projetId requis" },
        { status: 400 }
      );
    }

    const projet = await prisma.projet.findUnique({ where: { id: projetId } });
    if (!projet) {
      return NextResponse.json(
        { error: "Projet non trouvé" },
        { status: 404 }
      );
    }

    const currentYear = new Date().getFullYear();

    const kpi = await prisma.kPI.create({
      data: {
        projetId,
        ...data,
        mesures: {
          create: (["T1", "T2", "T3", "T4"] as const).map((trimestre) => ({
            annee: currentYear,
            trimestre,
          })),
        },
      },
      include: { mesures: true },
    });

    await prisma.auditLog.create({
      data: {
        userId: guard.user.id,
        action: "CREATE",
        entityType: "KPI",
        entityId: kpi.id,
        newValue: JSON.stringify(kpi),
        description: `Création du KPI ${kpi.code}`,
      },
    });

    return NextResponse.json(kpi, { status: 201 });
  } catch {
    return NextResponse.json(
      { error: "Erreur lors de la création du KPI" },
      { status: 500 }
    );
  }
}
