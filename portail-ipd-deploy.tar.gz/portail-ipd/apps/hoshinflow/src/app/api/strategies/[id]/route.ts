import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { apiGuard, isGuardError } from "@/lib/api-guard";

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const guard = await apiGuard(request, "strategie", "read");
  if (isGuardError(guard)) return guard.response;

  const { id } = await params;

  const strategie = await prisma.strategieDepartementale.findUnique({
    where: { id },
    include: {
      departement: true,
      objectifStrategique: {
        include: { axe: true },
      },
      projets: {
        include: {
          kpis: { include: { mesures: true } },
          contributeurs: true,
          projetBtgs: true,
        },
      },
    },
  });

  if (!strategie) {
    return NextResponse.json(
      { error: "Stratégie non trouvée" },
      { status: 404 }
    );
  }

  return NextResponse.json(strategie);
}

export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const guard = await apiGuard(request, "strategie", "update");
  if (isGuardError(guard)) return guard.response;

  const { id } = await params;

  try {
    const oldStrategie = await prisma.strategieDepartementale.findUnique({
      where: { id },
    });
    if (!oldStrategie) {
      return NextResponse.json(
        { error: "Stratégie non trouvée" },
        { status: 404 }
      );
    }

    const body = await request.json();
    const strategie = await prisma.strategieDepartementale.update({
      where: { id },
      data: body,
      include: {
        departement: true,
        objectifStrategique: true,
        projets: true,
      },
    });

    await prisma.auditLog.create({
      data: {
        userId: guard.user.id,
        action: "UPDATE",
        entityType: "Strategie",
        entityId: id,
        oldValue: JSON.stringify(oldStrategie),
        newValue: JSON.stringify(strategie),
        description: `Mise à jour de la stratégie ${strategie.code}`,
      },
    });

    return NextResponse.json(strategie);
  } catch {
    return NextResponse.json(
      { error: "Erreur lors de la mise à jour de la stratégie" },
      { status: 500 }
    );
  }
}
