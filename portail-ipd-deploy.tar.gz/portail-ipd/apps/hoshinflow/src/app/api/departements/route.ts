import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { apiGuard, isGuardError } from "@/lib/api-guard";

export async function GET(request: NextRequest) {
  const guard = await apiGuard(request, "departement", "read");
  if (isGuardError(guard)) return guard.response;

  const departements = await prisma.departement.findMany({
    include: {
      _count: {
        select: { strategies: true },
      },
    },
    orderBy: { nom: "asc" },
  });

  return NextResponse.json(departements);
}
