import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { apiGuard, isGuardError } from "@/lib/api-guard";

export async function GET(request: NextRequest) {
  const guard = await apiGuard(request, "axe", "read");
  if (isGuardError(guard)) return guard.response;

  const axes = await prisma.axeStrategique.findMany({
    include: {
      objectifs: {
        orderBy: { ordre: "asc" },
      },
    },
    orderBy: { ordre: "asc" },
  });

  return NextResponse.json(axes);
}
