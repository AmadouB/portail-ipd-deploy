import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { apiGuard, isGuardError } from "@/lib/api-guard";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  // ADMIN-only: we rely on RBAC — only ADMIN has "delete" on "projet"
  // which we use here as a proxy for "validate rapport" privilege
  const guard = await apiGuard(request, "projet", "delete");
  if (isGuardError(guard)) return guard.response;

  const { id } = await params;

  try {
    const rapport = await prisma.rapportHebdo.findUnique({
      where: { id },
    });

    if (!rapport) {
      return NextResponse.json(
        { error: "Rapport non trouve" },
        { status: 404 }
      );
    }

    if (rapport.statut !== "SOUMIS") {
      return NextResponse.json(
        { error: "Seuls les rapports SOUMIS peuvent etre valides" },
        { status: 400 }
      );
    }

    const updated = await prisma.rapportHebdo.update({
      where: { id },
      data: {
        statut: "VALIDE",
      },
      include: {
        lignes: { orderBy: { ordre: "asc" } },
        departement: true,
        soumisPar: true,
      },
    });

    await prisma.auditLog.create({
      data: {
        userId: guard.user.id,
        action: "UPDATE",
        entityType: "RapportHebdo",
        entityId: id,
        oldValue: JSON.stringify(rapport),
        newValue: JSON.stringify(updated),
        description: `Validation du rapport ${updated.semaine}`,
      },
    });

    return NextResponse.json(updated);
  } catch {
    return NextResponse.json(
      { error: "Erreur lors de la validation du rapport" },
      { status: 500 }
    );
  }
}
