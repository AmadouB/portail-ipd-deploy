import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { apiGuard, isGuardError } from "@/lib/api-guard";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const guard = await apiGuard(request, "projet", "update");
  if (isGuardError(guard)) return guard.response;

  const { id } = await params;

  try {
    const rapport = await prisma.rapportHebdo.findUnique({
      where: { id },
    });

    if (!rapport) {
      return NextResponse.json(
        { error: "Rapport non trouve" },
        { status: 404 }
      );
    }

    if (rapport.statut !== "BROUILLON") {
      return NextResponse.json(
        { error: "Seuls les rapports en BROUILLON peuvent etre soumis" },
        { status: 400 }
      );
    }

    const updated = await prisma.rapportHebdo.update({
      where: { id },
      data: {
        statut: "SOUMIS",
        soumisParId: guard.user.id,
      },
      include: {
        lignes: { orderBy: { ordre: "asc" } },
        departement: true,
        soumisPar: true,
      },
    });

    await prisma.auditLog.create({
      data: {
        userId: guard.user.id,
        action: "UPDATE",
        entityType: "RapportHebdo",
        entityId: id,
        oldValue: JSON.stringify(rapport),
        newValue: JSON.stringify(updated),
        description: `Soumission du rapport ${updated.semaine}`,
      },
    });

    return NextResponse.json(updated);
  } catch {
    return NextResponse.json(
      { error: "Erreur lors de la soumission du rapport" },
      { status: 500 }
    );
  }
}
