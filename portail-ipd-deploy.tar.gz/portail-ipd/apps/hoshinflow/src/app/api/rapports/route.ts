import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { apiGuard, isGuardError } from "@/lib/api-guard";

export async function GET(request: NextRequest) {
  const guard = await apiGuard(request, "projet", "read");
  if (isGuardError(guard)) return guard.response;

  const { searchParams } = new URL(request.url);
  const departementId = searchParams.get("departementId");
  const semaine = searchParams.get("semaine");
  const statut = searchParams.get("statut");

  const where: Record<string, unknown> = {};
  if (departementId) where.departementId = departementId;
  if (semaine) where.semaine = semaine;
  if (statut) where.statut = statut;

  const rapports = await prisma.rapportHebdo.findMany({
    where,
    include: {
      lignes: { orderBy: { ordre: "asc" } },
      departement: true,
    },
    orderBy: { createdAt: "desc" },
  });

  return NextResponse.json(rapports);
}

export async function POST(request: NextRequest) {
  const guard = await apiGuard(request, "projet", "create");
  if (isGuardError(guard)) return guard.response;

  try {
    const body = await request.json();
    const { departementId, semaine, dateDebut, dateFin, lignes, ...rest } = body;

    if (!departementId || !semaine || !dateDebut || !dateFin) {
      return NextResponse.json(
        { error: "departementId, semaine, dateDebut et dateFin requis" },
        { status: 400 }
      );
    }

    const rapport = await prisma.rapportHebdo.create({
      data: {
        departementId,
        semaine,
        dateDebut: new Date(dateDebut),
        dateFin: new Date(dateFin),
        ...rest,
        lignes: lignes?.length
          ? {
              create: lignes.map(
                (
                  l: {
                    projetId?: string;
                    libelle: string;
                    avancementPct?: number;
                    statut?: string;
                    commentaire?: string;
                    isNewProjet?: boolean;
                    ordre?: number;
                  },
                  index: number
                ) => ({
                  projetId: l.projetId ?? null,
                  libelle: l.libelle,
                  avancementPct: l.avancementPct ?? null,
                  statut: l.statut ?? "EN_COURS",
                  commentaire: l.commentaire ?? null,
                  isNewProjet: l.isNewProjet ?? false,
                  ordre: l.ordre ?? index,
                })
              ),
            }
          : undefined,
      },
      include: {
        lignes: { orderBy: { ordre: "asc" } },
        departement: true,
      },
    });

    await prisma.auditLog.create({
      data: {
        userId: guard.user.id,
        action: "CREATE",
        entityType: "RapportHebdo",
        entityId: rapport.id,
        newValue: JSON.stringify(rapport),
        description: `Creation du rapport ${rapport.semaine} - ${rapport.departement.nom}`,
      },
    });

    return NextResponse.json(rapport, { status: 201 });
  } catch {
    return NextResponse.json(
      { error: "Erreur lors de la creation du rapport" },
      { status: 500 }
    );
  }
}
