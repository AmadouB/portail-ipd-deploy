import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { apiGuard, isGuardError } from "@/lib/api-guard";

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const guard = await apiGuard(request, "projet", "read");
  if (isGuardError(guard)) return guard.response;

  const { id } = await params;

  const rapport = await prisma.rapportHebdo.findUnique({
    where: { id },
    include: {
      lignes: { orderBy: { ordre: "asc" } },
      departement: true,
      soumisPar: true,
    },
  });

  if (!rapport) {
    return NextResponse.json(
      { error: "Rapport non trouve" },
      { status: 404 }
    );
  }

  return NextResponse.json(rapport);
}

export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const guard = await apiGuard(request, "projet", "update");
  if (isGuardError(guard)) return guard.response;

  const { id } = await params;

  try {
    const oldRapport = await prisma.rapportHebdo.findUnique({
      where: { id },
      include: { lignes: true },
    });
    if (!oldRapport) {
      return NextResponse.json(
        { error: "Rapport non trouve" },
        { status: 404 }
      );
    }

    const body = await request.json();
    const { lignes, ...fields } = body;

    // Update rapport fields + replace lignes in a transaction
    const rapport = await prisma.$transaction(async (tx) => {
      // Update rapport scalar fields
      const updated = await tx.rapportHebdo.update({
        where: { id },
        data: fields,
      });

      // If lignes provided, delete all existing and recreate
      if (lignes !== undefined) {
        await tx.ligneRapport.deleteMany({ where: { rapportId: id } });

        if (Array.isArray(lignes) && lignes.length > 0) {
          await tx.ligneRapport.createMany({
            data: lignes.map(
              (
                l: {
                  projetId?: string;
                  libelle: string;
                  avancementPct?: number;
                  statut?: string;
                  commentaire?: string;
                  isNewProjet?: boolean;
                  ordre?: number;
                },
                index: number
              ) => ({
                rapportId: id,
                projetId: l.projetId ?? null,
                libelle: l.libelle,
                avancementPct: l.avancementPct ?? null,
                statut: l.statut ?? "EN_COURS",
                commentaire: l.commentaire ?? null,
                isNewProjet: l.isNewProjet ?? false,
                ordre: l.ordre ?? index,
              })
            ),
          });
        }
      }

      return updated;
    });

    // Re-fetch with includes for response
    const full = await prisma.rapportHebdo.findUnique({
      where: { id },
      include: {
        lignes: { orderBy: { ordre: "asc" } },
        departement: true,
        soumisPar: true,
      },
    });

    await prisma.auditLog.create({
      data: {
        userId: guard.user.id,
        action: "UPDATE",
        entityType: "RapportHebdo",
        entityId: id,
        oldValue: JSON.stringify(oldRapport),
        newValue: JSON.stringify(full),
        description: `Mise a jour du rapport ${rapport.semaine}`,
      },
    });

    return NextResponse.json(full);
  } catch {
    return NextResponse.json(
      { error: "Erreur lors de la mise a jour du rapport" },
      { status: 500 }
    );
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const guard = await apiGuard(request, "projet", "delete");
  if (isGuardError(guard)) return guard.response;

  const { id } = await params;

  try {
    const rapport = await prisma.rapportHebdo.findUnique({
      where: { id },
      include: { lignes: true, departement: true },
    });

    if (!rapport) {
      return NextResponse.json(
        { error: "Rapport non trouve" },
        { status: 404 }
      );
    }

    if (rapport.statut !== "BROUILLON") {
      return NextResponse.json(
        { error: "Seuls les rapports en BROUILLON peuvent etre supprimes" },
        { status: 400 }
      );
    }

    await prisma.ligneRapport.deleteMany({ where: { rapportId: id } });
    await prisma.rapportHebdo.delete({ where: { id } });

    await prisma.auditLog.create({
      data: {
        userId: guard.user.id,
        action: "DELETE",
        entityType: "RapportHebdo",
        entityId: id,
        oldValue: JSON.stringify(rapport),
        description: `Suppression du rapport ${rapport.semaine} - ${rapport.departement.nom}`,
      },
    });

    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json(
      { error: "Erreur lors de la suppression du rapport" },
      { status: 500 }
    );
  }
}
