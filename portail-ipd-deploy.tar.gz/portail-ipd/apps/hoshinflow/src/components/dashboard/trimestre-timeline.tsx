"use client";

import { motion } from "framer-motion";

type Trimestre = "T1" | "T2" | "T3" | "T4";

interface TrimestreTimelineProps {
  currentTrimestre?: Trimestre;
}

const trimestres: {
  id: Trimestre;
  label: string;
  months: string;
}[] = [
  { id: "T1", label: "T1", months: "Jan - Mar" },
  { id: "T2", label: "T2", months: "Avr - Jun" },
  { id: "T3", label: "T3", months: "Jul - Sep" },
  { id: "T4", label: "T4", months: "Oct - Dec" },
];

function getCurrentTrimestre(): Trimestre {
  const month = new Date().getMonth();
  if (month < 3) return "T1";
  if (month < 6) return "T2";
  if (month < 9) return "T3";
  return "T4";
}

function getTrimestreProgress(): number {
  const now = new Date();
  const month = now.getMonth();
  const day = now.getDate();
  const quarterStartMonth = Math.floor(month / 3) * 3;
  const daysInQuarter = [
    31 + 28 + 31, // Q1
    30 + 31 + 30, // Q2
    31 + 31 + 30, // Q3
    31 + 30 + 31, // Q4
  ];
  const quarterIndex = Math.floor(month / 3);

  // Days elapsed in the current quarter
  let elapsed = day;
  for (let m = quarterStartMonth; m < month; m++) {
    const d = new Date(now.getFullYear(), m + 1, 0).getDate();
    elapsed += d;
  }

  return Math.min(100, Math.round((elapsed / daysInQuarter[quarterIndex]) * 100));
}

export function TrimestreTimeline({
  currentTrimestre,
}: TrimestreTimelineProps) {
  const activeTri = currentTrimestre ?? getCurrentTrimestre();
  const progress = getTrimestreProgress();

  const activeIndex = trimestres.findIndex((t) => t.id === activeTri);

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.5 }}
      className="rounded-xl border border-white/[0.08] bg-white/[0.03] backdrop-blur-xl p-5"
    >
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-sm font-semibold text-foreground">
          Progression Annuelle
        </h3>
        <span className="text-xs text-foreground-secondary">
          {activeTri} en cours — {progress}% ecoul\u00e9
        </span>
      </div>

      <div className="flex items-center gap-2">
        {trimestres.map((tri, idx) => {
          const isPast = idx < activeIndex;
          const isCurrent = idx === activeIndex;
          const isFuture = idx > activeIndex;

          return (
            <div key={tri.id} className="flex-1 flex flex-col gap-1.5">
              {/* Label */}
              <div className="flex items-center justify-between px-1">
                <span
                  className={`text-xs font-semibold ${
                    isCurrent
                      ? "text-cyan-400"
                      : isPast
                      ? "text-emerald-400/70"
                      : "text-foreground-secondary"
                  }`}
                >
                  {tri.label}
                </span>
                <span className="text-[10px] text-foreground-secondary">
                  {tri.months}
                </span>
              </div>

              {/* Bar */}
              <div className="h-2.5 rounded-full bg-white/[0.04] overflow-hidden relative">
                {isPast && (
                  <motion.div
                    className="absolute inset-0 rounded-full bg-emerald-500/60"
                    initial={{ width: 0 }}
                    animate={{ width: "100%" }}
                    transition={{
                      duration: 0.6,
                      delay: 0.6 + idx * 0.1,
                      ease: "easeOut",
                    }}
                  />
                )}
                {isCurrent && (
                  <motion.div
                    className="absolute inset-y-0 left-0 rounded-full bg-gradient-to-r from-cyan-500 to-cyan-400"
                    initial={{ width: 0 }}
                    animate={{ width: `${progress}%` }}
                    transition={{
                      duration: 0.8,
                      delay: 0.6 + idx * 0.1,
                      ease: "easeOut",
                    }}
                  >
                    {/* Glow pulse on the leading edge */}
                    <div className="absolute right-0 top-1/2 -translate-y-1/2 w-2 h-2 rounded-full bg-cyan-400 shadow-[0_0_8px_rgba(6,182,212,0.6)]" />
                  </motion.div>
                )}
                {isFuture && (
                  <div className="absolute inset-0 rounded-full bg-white/[0.02]" />
                )}
              </div>
            </div>
          );
        })}
      </div>
    </motion.div>
  );
}
