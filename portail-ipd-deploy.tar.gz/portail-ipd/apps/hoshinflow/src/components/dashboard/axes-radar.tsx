"use client";

import { motion } from "framer-motion";
import {
  ResponsiveContainer,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  Tooltip,
} from "recharts";
import type { AxeStrategique } from "@/lib/types";

interface AxesRadarProps {
  axes: {
    nom: string;
    completion: number;
    couleur: string;
  }[];
}

function CustomTooltip({
  active,
  payload,
}: {
  active?: boolean;
  payload?: Array<{ payload: { nom: string; completion: number } }>;
}) {
  if (!active || !payload || payload.length === 0) return null;
  const data = payload[0].payload;
  return (
    <div className="rounded-lg border border-white/[0.08] bg-[#0f1629]/95 backdrop-blur-xl px-3 py-2 shadow-xl">
      <p className="text-xs font-medium text-foreground mb-1">{data.nom}</p>
      <p className="text-sm font-bold text-cyan-400">{data.completion.toFixed(1)}%</p>
    </div>
  );
}

export function AxesRadar({ axes }: AxesRadarProps) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.6, delay: 0.3 }}
      className="rounded-xl border border-white/[0.08] bg-white/[0.03] backdrop-blur-xl p-6"
    >
      <h3 className="text-sm font-semibold text-foreground mb-4">
        Performance par Axe Strategique
      </h3>
      <div className="h-[320px]">
        <ResponsiveContainer width="100%" height="100%">
          <RadarChart data={axes} cx="50%" cy="50%" outerRadius="75%">
            <PolarGrid
              stroke="rgba(255,255,255,0.05)"
              strokeDasharray="3 3"
            />
            <PolarAngleAxis
              dataKey="nom"
              tick={{
                fill: "rgba(255,255,255,0.5)",
                fontSize: 11,
              }}
              tickLine={false}
            />
            <PolarRadiusAxis
              angle={90}
              domain={[0, 100]}
              tick={{
                fill: "rgba(255,255,255,0.3)",
                fontSize: 10,
              }}
              axisLine={false}
              tickCount={5}
            />
            <Radar
              name="Completion"
              dataKey="completion"
              stroke="#06b6d4"
              strokeWidth={2}
              fill="rgba(6,182,212,0.15)"
              fillOpacity={1}
              dot={{
                r: 4,
                fill: "#06b6d4",
                stroke: "#06b6d4",
                strokeWidth: 1,
              }}
              activeDot={{
                r: 6,
                fill: "#06b6d4",
                stroke: "rgba(6,182,212,0.4)",
                strokeWidth: 3,
              }}
            />
            <Tooltip content={<CustomTooltip />} />
          </RadarChart>
        </ResponsiveContainer>
      </div>
    </motion.div>
  );
}
