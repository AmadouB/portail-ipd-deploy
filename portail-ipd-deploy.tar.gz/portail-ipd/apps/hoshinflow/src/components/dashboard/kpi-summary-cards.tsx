"use client";

import { motion } from "framer-motion";
import { Activity, FolderKanban, Wallet, CheckCircle2 } from "lucide-react";
import { GlassPanel } from "@/components/ui/glass-panel";
import { AnimatedNumber } from "@/components/ui/animated-number";
import { ProgressRing } from "@/components/ui/progress-ring";
import { formatBudget } from "@/lib/utils";

interface KpiSummaryCardsProps {
  completionGlobale: number;
  totalActivites: number;
  budgetTotal: number;
  activitesTerminees: number;
}

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const item = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0, transition: { duration: 0.5, ease: "easeOut" as const } },
};

export function KpiSummaryCards({
  completionGlobale,
  totalActivites,
  budgetTotal,
  activitesTerminees,
}: KpiSummaryCardsProps) {
  return (
    <motion.div
      variants={container}
      initial="hidden"
      animate="show"
      className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4"
    >
      {/* Card 1: Completion Globale */}
      <motion.div variants={item}>
        <GlassPanel
          accentColor="cyan"
          variant="glow"
          className="p-5"
        >
          <div className="flex items-center justify-between">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-3">
                <div className="p-2 rounded-lg bg-cyan-500/10">
                  <Activity size={18} className="text-cyan-400" />
                </div>
                <span className="text-xs font-medium text-foreground-secondary uppercase tracking-wider">
                  Completion Globale
                </span>
              </div>
              <AnimatedNumber
                value={completionGlobale}
                format="percent"
                decimals={1}
                colorByValue
                className="text-3xl"
              />
              <div className="mt-2 flex items-center gap-1.5">
                <span className="text-xs text-foreground-secondary">
                  Moyenne des 5 axes
                </span>
              </div>
            </div>
            <ProgressRing value={completionGlobale} size="md" />
          </div>
        </GlassPanel>
      </motion.div>

      {/* Card 2: Total Activites */}
      <motion.div variants={item}>
        <GlassPanel
          accentColor="violet"
          variant="glow"
          className="p-5"
        >
          <div className="flex items-center gap-2 mb-3">
            <div className="p-2 rounded-lg bg-violet-500/10">
              <FolderKanban size={18} className="text-violet-400" />
            </div>
            <span className="text-xs font-medium text-foreground-secondary uppercase tracking-wider">
              Total Activites
            </span>
          </div>
          <AnimatedNumber
            value={totalActivites}
            format="number"
            className="text-3xl text-foreground"
          />
          <div className="mt-2 flex items-center gap-1.5">
            <span className="text-xs text-foreground-secondary">
              Projets et actions en cours
            </span>
          </div>
        </GlassPanel>
      </motion.div>

      {/* Card 3: Budget Total */}
      <motion.div variants={item}>
        <GlassPanel
          accentColor="amber"
          variant="glow"
          className="p-5"
        >
          <div className="flex items-center gap-2 mb-3">
            <div className="p-2 rounded-lg bg-amber-500/10">
              <Wallet size={18} className="text-amber-400" />
            </div>
            <span className="text-xs font-medium text-foreground-secondary uppercase tracking-wider">
              Budget Total
            </span>
          </div>
          <div className="text-3xl font-semibold text-foreground">
            {formatBudget(budgetTotal)}
          </div>
          <div className="mt-2 flex items-center gap-1.5">
            <span className="text-xs text-foreground-secondary">
              Budget alloue global
            </span>
          </div>
        </GlassPanel>
      </motion.div>

      {/* Card 4: Activites Terminees */}
      <motion.div variants={item}>
        <GlassPanel
          accentColor="emerald"
          variant="glow"
          className="p-5"
        >
          <div className="flex items-center gap-2 mb-3">
            <div className="p-2 rounded-lg bg-emerald-500/10">
              <CheckCircle2 size={18} className="text-emerald-400" />
            </div>
            <span className="text-xs font-medium text-foreground-secondary uppercase tracking-wider">
              Activites Terminees
            </span>
          </div>
          <div className="flex items-baseline gap-2">
            <AnimatedNumber
              value={activitesTerminees}
              format="number"
              className="text-3xl text-emerald-400"
            />
            <span className="text-lg text-foreground-secondary">
              / {totalActivites}
            </span>
          </div>
          <div className="mt-2 flex items-center gap-1.5">
            <div className="flex-1 h-1.5 rounded-full bg-white/[0.06] overflow-hidden">
              <motion.div
                className="h-full rounded-full bg-emerald-500"
                initial={{ width: 0 }}
                animate={{
                  width: `${totalActivites > 0 ? (activitesTerminees / totalActivites) * 100 : 0}%`,
                }}
                transition={{ duration: 1, delay: 0.5, ease: "easeOut" }}
              />
            </div>
          </div>
        </GlassPanel>
      </motion.div>
    </motion.div>
  );
}
