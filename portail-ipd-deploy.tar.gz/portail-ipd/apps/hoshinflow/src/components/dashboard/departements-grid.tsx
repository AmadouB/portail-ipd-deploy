"use client";

import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import { GlassPanel } from "@/components/ui/glass-panel";
import { ProgressRing } from "@/components/ui/progress-ring";
import { FolderKanban } from "lucide-react";
import type { Departement } from "@/lib/types";

interface DepartementsGridProps {
  departements: Departement[];
}

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.04,
      delayChildren: 0.3,
    },
  },
};

const item = {
  hidden: { opacity: 0, y: 16, scale: 0.97 },
  show: {
    opacity: 1,
    y: 0,
    scale: 1,
    transition: { duration: 0.4, ease: "easeOut" as const },
  },
};

function getBorderColor(taux: number): string {
  if (taux >= 80) return "border-l-emerald-500";
  if (taux >= 50) return "border-l-cyan-500";
  if (taux >= 20) return "border-l-amber-500";
  return "border-l-red-500";
}

export function DepartementsGrid({ departements }: DepartementsGridProps) {
  const router = useRouter();

  // Sort by completion rate (worst first for attention)
  const sorted = [...departements].sort(
    (a, b) => (a.tauxCompletion ?? 0) - (b.tauxCompletion ?? 0)
  );

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.4 }}
      className="rounded-xl border border-white/[0.08] bg-white/[0.03] backdrop-blur-xl p-6"
    >
      <h3 className="text-sm font-semibold text-foreground mb-4">
        Departements
      </h3>

      <motion.div
        variants={container}
        initial="hidden"
        animate="show"
        className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3"
      >
        {sorted.map((dept) => {
          const completion = dept.tauxCompletion ?? 0;
          const projetCount = dept.totalProjets ?? 0;

          return (
            <motion.div key={dept.id} variants={item}>
              <GlassPanel
                hover
                className={`p-4 border-l-2 ${getBorderColor(completion)} cursor-pointer`}
                onClick={() => router.push(`/departements/${dept.code}`)}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0 flex-1">
                    <div
                      className="text-lg font-bold font-mono"
                      style={{ color: dept.couleur }}
                    >
                      {dept.code}
                    </div>
                    <p className="text-xs text-foreground truncate mt-0.5">
                      {dept.nomCourt || dept.nom}
                    </p>
                    {dept.directeur && (
                      <p className="text-[10px] text-foreground-secondary truncate mt-0.5">
                        {dept.directeur}
                      </p>
                    )}
                  </div>
                  <ProgressRing value={completion} size="sm" />
                </div>

                <div className="mt-3 flex items-center gap-1.5 text-foreground-secondary">
                  <FolderKanban size={12} />
                  <span className="text-[10px]">
                    {projetCount} projet{projetCount !== 1 ? "s" : ""}
                  </span>
                </div>
              </GlassPanel>
            </motion.div>
          );
        })}
      </motion.div>
    </motion.div>
  );
}
