"use client";

import { motion } from "framer-motion";
import { AlertTriangle, TrendingDown, ChevronRight } from "lucide-react";
import Link from "next/link";
import type { Projet, KPI } from "@/lib/types";
import { getStatutLabel } from "@/lib/utils";

interface AlertItem {
  type: "retard" | "kpi_critique";
  label: string;
  detail: string;
  responsable: string | null;
  value?: number;
  projetCode?: string;
}

interface AlertsPanelProps {
  projetsEnRetard: Projet[];
  kpisCritiques: { kpi: KPI; projetLibelle: string; responsable: string | null }[];
}

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: { staggerChildren: 0.06, delayChildren: 0.1 },
  },
};

const item = {
  hidden: { opacity: 0, x: -12 },
  show: { opacity: 1, x: 0, transition: { duration: 0.3, ease: "easeOut" as const } },
};

const MAX_ALERTS = 8;

export function AlertsPanel({
  projetsEnRetard,
  kpisCritiques,
}: AlertsPanelProps) {
  const alerts: AlertItem[] = [];

  // Add retard alerts
  for (const projet of projetsEnRetard) {
    alerts.push({
      type: "retard",
      label: projet.libelle,
      detail: getStatutLabel(projet.statut),
      responsable: projet.responsable,
      projetCode: projet.code,
    });
  }

  // Add KPI critical alerts
  for (const { kpi, projetLibelle, responsable } of kpisCritiques) {
    // Calculate latest taux
    let latestTaux = 0;
    const trimestresOrder = ["T4", "T3", "T2", "T1"] as const;
    for (const tri of trimestresOrder) {
      const mesure = kpi.mesures.find(
        (m) =>
          m.trimestre === tri &&
          m.cible !== null &&
          m.cible > 0 &&
          m.realise !== null
      );
      if (mesure) {
        latestTaux = Math.round(
          ((mesure.realise as number) / (mesure.cible as number)) * 100
        );
        break;
      }
    }

    alerts.push({
      type: "kpi_critique",
      label: kpi.libelle,
      detail: projetLibelle,
      responsable,
      value: latestTaux,
    });
  }

  const displayedAlerts = alerts.slice(0, MAX_ALERTS);
  const hasMore = alerts.length > MAX_ALERTS;

  if (alerts.length === 0) {
    return null;
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.6 }}
      className="rounded-xl border border-white/[0.08] bg-white/[0.03] backdrop-blur-xl p-6"
    >
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <AlertTriangle size={16} className="text-amber-400" />
          <h3 className="text-sm font-semibold text-foreground">
            Alertes ({alerts.length})
          </h3>
        </div>
      </div>

      <motion.div
        variants={container}
        initial="hidden"
        animate="show"
        className="space-y-2 max-h-[320px] overflow-y-auto pr-1"
      >
        {displayedAlerts.map((alert, idx) => (
          <motion.div
            key={`${alert.type}-${idx}`}
            variants={item}
            className={`flex items-center gap-3 p-3 rounded-lg border transition-colors duration-200 hover:bg-white/[0.03] ${
              alert.type === "retard"
                ? "border-red-500/20 bg-red-500/[0.03]"
                : "border-amber-500/20 bg-amber-500/[0.03]"
            }`}
          >
            {/* Icon */}
            <div
              className={`flex-shrink-0 p-1.5 rounded-md ${
                alert.type === "retard"
                  ? "bg-red-500/10"
                  : "bg-amber-500/10"
              }`}
            >
              {alert.type === "retard" ? (
                <AlertTriangle size={14} className="text-red-400" />
              ) : (
                <TrendingDown size={14} className="text-amber-400" />
              )}
            </div>

            {/* Content */}
            <div className="flex-1 min-w-0">
              <p className="text-xs font-medium text-foreground truncate">
                {alert.label}
              </p>
              <p className="text-[10px] text-foreground-secondary truncate">
                {alert.detail}
                {alert.responsable && ` — ${alert.responsable}`}
              </p>
            </div>

            {/* Value badge */}
            {alert.type === "kpi_critique" && alert.value !== undefined && (
              <span className="flex-shrink-0 text-xs font-bold font-mono text-amber-400">
                {alert.value}%
              </span>
            )}
            {alert.type === "retard" && (
              <span className="flex-shrink-0 px-2 py-0.5 text-[10px] font-medium rounded-full bg-red-500/10 text-red-400 border border-red-500/20">
                En retard
              </span>
            )}
          </motion.div>
        ))}
      </motion.div>

      {hasMore && (
        <div className="mt-3 pt-3 border-t border-white/[0.06]">
          <Link
            href="/projets"
            className="inline-flex items-center gap-1 text-xs text-cyan-400 hover:text-cyan-300 transition-colors"
          >
            Voir plus ({alerts.length - MAX_ALERTS} alertes restantes)
            <ChevronRight size={12} />
          </Link>
        </div>
      )}
    </motion.div>
  );
}
