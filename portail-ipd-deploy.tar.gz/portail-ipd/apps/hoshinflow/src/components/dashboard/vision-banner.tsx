"use client";

import { motion } from "framer-motion";

interface VisionBannerProps {
  nom: string;
  vision: string | null;
  anneeDepart: number;
  anneeCible: number;
}

export function VisionBanner({
  nom,
  vision,
  anneeDepart,
  anneeCible,
}: VisionBannerProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, ease: "easeOut" }}
      className="relative overflow-hidden rounded-2xl border border-white/[0.08] bg-white/[0.03] backdrop-blur-xl"
    >
      {/* Animated gradient border glow */}
      <div className="absolute inset-0 rounded-2xl p-[1px]">
        <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-cyan-500/20 via-violet-500/20 to-cyan-500/20 animate-shimmer" />
      </div>

      {/* Decorative dot grid pattern */}
      <div className="absolute inset-0 opacity-[0.03]">
        <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern
              id="dot-grid"
              x="0"
              y="0"
              width="20"
              height="20"
              patternUnits="userSpaceOnUse"
            >
              <circle cx="1" cy="1" r="1" fill="white" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#dot-grid)" />
        </svg>
      </div>

      {/* Decorative radial gradients */}
      <div className="absolute -top-24 -right-24 w-64 h-64 rounded-full bg-cyan-500/[0.07] blur-3xl" />
      <div className="absolute -bottom-24 -left-24 w-64 h-64 rounded-full bg-violet-500/[0.07] blur-3xl" />

      {/* Content */}
      <div className="relative px-8 py-6 flex items-center justify-between gap-6">
        <div className="flex-1 min-w-0">
          <motion.h1
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="text-2xl font-bold bg-gradient-to-r from-cyan-400 via-blue-400 to-violet-400 bg-clip-text text-transparent"
          >
            {nom}
          </motion.h1>
          {vision && (
            <motion.p
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.35 }}
              className="mt-2 text-sm text-foreground-secondary leading-relaxed max-w-3xl"
            >
              {vision}
            </motion.p>
          )}
        </div>

        {/* Year badge */}
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.4, delay: 0.4 }}
          className="flex-shrink-0 px-4 py-2 rounded-xl border border-cyan-500/20 bg-cyan-500/[0.08] backdrop-blur-sm"
        >
          <span className="text-sm font-mono font-semibold text-cyan-400">
            {anneeDepart} — {anneeCible}
          </span>
        </motion.div>
      </div>
    </motion.div>
  );
}
