"use client";

import { useMemo } from "react";
import { motion } from "framer-motion";
import { TrendingUp, TrendingDown, Minus } from "lucide-react";
import { cn, calculateKpiTaux, getTauxColor } from "@/lib/utils";
import { GlassPanel } from "@/components/ui/glass-panel";
import { AnimatedNumber } from "@/components/ui/animated-number";
import { useTrimestre } from "@/lib/trimestre-context";
import type { KPI, Trimestre } from "@/lib/types";

interface KpiDetailCardProps {
  kpi: KPI;
  index?: number;
}

const TRIMESTRES: Trimestre[] = ["T1", "T2", "T3", "T4"];

function getAccentFromTaux(
  taux: number
): "emerald" | "cyan" | "amber" | "red" {
  if (taux >= 80) return "emerald";
  if (taux >= 50) return "cyan";
  if (taux >= 20) return "amber";
  return "red";
}

type Trend = "up" | "down" | "stable";

function computeTrend(kpi: KPI): { trend: Trend; label: string } {
  const mesuresWithData = kpi.mesures
    .filter((m) => m.realise !== null && m.cible !== null)
    .sort((a, b) => {
      const order = { T1: 1, T2: 2, T3: 3, T4: 4 };
      return order[a.trimestre] - order[b.trimestre];
    });

  if (mesuresWithData.length < 2) {
    return { trend: "stable", label: "Stable" };
  }

  const lastTwo = mesuresWithData.slice(-2);
  const prevTaux = calculateKpiTaux(lastTwo[0].realise, lastTwo[0].cible);
  const currTaux = calculateKpiTaux(lastTwo[1].realise, lastTwo[1].cible);
  const diff = currTaux - prevTaux;

  if (diff > 5) return { trend: "up", label: `+${diff.toFixed(1)}%` };
  if (diff < -5) return { trend: "down", label: `${diff.toFixed(1)}%` };
  return { trend: "stable", label: "Stable" };
}

const trendConfig: Record<
  Trend,
  { icon: typeof TrendingUp; color: string; bg: string }
> = {
  up: {
    icon: TrendingUp,
    color: "text-emerald-400",
    bg: "bg-emerald-500/10",
  },
  down: { icon: TrendingDown, color: "text-red-400", bg: "bg-red-500/10" },
  stable: { icon: Minus, color: "text-amber-400", bg: "bg-amber-500/10" },
};

export function KpiDetailCard({ kpi, index = 0 }: KpiDetailCardProps) {
  const { selectedTrimestre } = useTrimestre();
  const { trend, label: trendLabel } = useMemo(() => computeTrend(kpi), [kpi]);

  const currentTaux = useMemo(() => {
    if (selectedTrimestre) {
      const mesure = kpi.mesures.find(
        (m) => m.trimestre === selectedTrimestre && m.realise !== null && m.cible !== null
      );
      return mesure ? calculateKpiTaux(mesure.realise, mesure.cible) : 0;
    }
    const latest = [...kpi.mesures]
      .reverse()
      .find((m) => m.realise !== null && m.cible !== null);
    if (!latest) return 0;
    return calculateKpiTaux(latest.realise, latest.cible);
  }, [kpi, selectedTrimestre]);

  const accentColor = getAccentFromTaux(currentTaux);
  const TrendIcon = trendConfig[trend].icon;

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay: index * 0.08 }}
    >
      <GlassPanel
        variant="glow"
        accentColor={accentColor}
        accentPosition="left"
        className="p-5"
      >
        {/* Header */}
        <div className="flex items-start justify-between mb-4">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <span className="font-mono text-xs text-cyan-400/60">
                {kpi.code}
              </span>
              <span className="text-[10px] text-white/30 uppercase tracking-wider px-1.5 py-0.5 rounded bg-white/[0.03] border border-white/[0.06]">
                {kpi.modeCalcul}
              </span>
              {selectedTrimestre && (
                <span className="text-[10px] text-cyan-400/60 uppercase tracking-wider px-1.5 py-0.5 rounded bg-cyan-500/[0.08] border border-cyan-500/20">
                  {selectedTrimestre}
                </span>
              )}
            </div>
            <h4 className="text-sm font-medium text-white/90 line-clamp-2">
              {kpi.libelle}
            </h4>
          </div>

          <div className="flex items-center gap-3 ml-3">
            {/* Trend */}
            <div
              className={cn(
                "flex items-center gap-1 px-2 py-1 rounded-md",
                trendConfig[trend].bg
              )}
            >
              <TrendIcon size={14} className={trendConfig[trend].color} />
              <span
                className={cn("text-xs font-medium", trendConfig[trend].color)}
              >
                {trendLabel}
              </span>
            </div>

            {/* Current taux */}
            <AnimatedNumber
              value={currentTaux}
              format="percent"
              decimals={1}
              colorByValue
              className="text-xl font-bold"
            />
          </div>
        </div>

        {/* Quarterly breakdown */}
        <div className="grid grid-cols-4 gap-3">
          {TRIMESTRES.map((tri) => {
            const mesure = kpi.mesures.find((m) => m.trimestre === tri);
            const cible = mesure?.cible ?? null;
            const realise = mesure?.realise ?? null;
            const taux = calculateKpiTaux(realise, cible);
            const barColor = getTauxColor(taux);
            const hasData = realise !== null || cible !== null;
            const isSelected = selectedTrimestre === tri;

            return (
              <div
                key={tri}
                className={cn(
                  "rounded-lg p-3 transition-all duration-200",
                  isSelected
                    ? "bg-cyan-500/[0.08] border-2 border-cyan-500/30 ring-1 ring-cyan-500/10"
                    : "bg-white/[0.02] border border-white/[0.06]",
                  isSelected && "scale-[1.02]"
                )}
              >
                {/* Trimestre label */}
                <p
                  className={cn(
                    "text-xs font-medium mb-2",
                    isSelected ? "text-cyan-400" : "text-white/50"
                  )}
                >
                  {tri}
                  {isSelected && (
                    <span className="ml-1 text-[9px] text-cyan-400/60">●</span>
                  )}
                </p>

                {hasData ? (
                  <>
                    {/* Cible vs Realise */}
                    <div className="space-y-1 mb-2">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] text-white/30">
                          Cible
                        </span>
                        <span className="text-xs text-white/60 tabular-nums">
                          {cible !== null ? cible : "—"}
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] text-white/30">
                          Realise
                        </span>
                        <span
                          className={cn(
                            "text-xs font-medium tabular-nums",
                            realise !== null ? "text-white/80" : "text-white/30"
                          )}
                        >
                          {realise !== null ? realise : "—"}
                        </span>
                      </div>
                    </div>

                    {/* Progress bar */}
                    <div className="w-full h-1.5 rounded-full bg-white/[0.06] overflow-hidden">
                      <motion.div
                        className="h-full rounded-full"
                        style={{ backgroundColor: barColor }}
                        initial={{ width: 0 }}
                        animate={{ width: `${taux}%` }}
                        transition={{
                          duration: 0.8,
                          ease: "easeOut",
                          delay: 0.3,
                        }}
                      />
                    </div>

                    {/* Taux */}
                    <p
                      className={cn(
                        "text-right text-[10px] font-medium mt-1 tabular-nums",
                        isSelected && "font-bold"
                      )}
                      style={{ color: barColor }}
                    >
                      {taux}%
                    </p>
                  </>
                ) : (
                  <div className="flex items-center justify-center py-4 text-white/20 text-xs">
                    —
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </GlassPanel>
    </motion.div>
  );
}
