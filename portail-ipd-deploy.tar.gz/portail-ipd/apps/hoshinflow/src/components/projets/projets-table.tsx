"use client";

import { useState, useMemo } from "react";
import { useRouter } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import {
  ArrowUpDown,
  ArrowUp,
  ArrowDown,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";
import { cn, formatBudget, calculateProjetScore } from "@/lib/utils";
import { StatusBadge } from "@/components/ui/status-badge";
import { ProgressRing } from "@/components/ui/progress-ring";
import type { Projet, Departement, Statut } from "@/lib/types";

interface ProjetsTableProps {
  projets: Projet[];
  departements: Departement[];
}

type SortKey =
  | "code"
  | "libelle"
  | "departement"
  | "responsable"
  | "statut"
  | "kpis"
  | "budget";
type SortDir = "asc" | "desc";

const PAGE_SIZE = 20;

function getDepartementForProjet(
  projet: Projet,
  departements: Departement[]
): Departement | undefined {
  const deptId = projet.strategie?.departementId;
  if (!deptId) return undefined;
  return departements.find((d) => d.id === deptId);
}

export function ProjetsTable({ projets, departements }: ProjetsTableProps) {
  const router = useRouter();
  const [sortKey, setSortKey] = useState<SortKey>("code");
  const [sortDir, setSortDir] = useState<SortDir>("asc");
  const [page, setPage] = useState(0);

  const handleSort = (key: SortKey) => {
    if (sortKey === key) {
      setSortDir(sortDir === "asc" ? "desc" : "asc");
    } else {
      setSortKey(key);
      setSortDir("asc");
    }
    setPage(0);
  };

  const sorted = useMemo(() => {
    const list = [...projets];
    const dir = sortDir === "asc" ? 1 : -1;

    list.sort((a, b) => {
      switch (sortKey) {
        case "code":
          return a.code.localeCompare(b.code) * dir;
        case "libelle":
          return a.libelle.localeCompare(b.libelle) * dir;
        case "departement": {
          const da = getDepartementForProjet(a, departements);
          const db = getDepartementForProjet(b, departements);
          return (
            (da?.nomCourt || da?.nom || "").localeCompare(
              db?.nomCourt || db?.nom || ""
            ) * dir
          );
        }
        case "responsable":
          return (a.responsable || "").localeCompare(b.responsable || "") * dir;
        case "statut": {
          const order: Record<Statut, number> = {
            EN_RETARD: 0,
            EN_COURS: 1,
            EN_ATTENTE: 2,
            NON_DEMARRE: 3,
            COMPLET: 4,
            ANNULE: 5,
            A_RECONDUIRE: 6,
          };
          return (order[a.statut] - order[b.statut]) * dir;
        }
        case "kpis":
          return (
            (calculateProjetScore(a.kpis) - calculateProjetScore(b.kpis)) * dir
          );
        case "budget":
          return ((a.budgetAlloue ?? 0) - (b.budgetAlloue ?? 0)) * dir;
        default:
          return 0;
      }
    });
    return list;
  }, [projets, sortKey, sortDir, departements]);

  const totalPages = Math.ceil(sorted.length / PAGE_SIZE);
  const paged = sorted.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE);

  const columns: { key: SortKey; label: string; className?: string }[] = [
    { key: "code", label: "Code", className: "w-[100px]" },
    { key: "libelle", label: "Libelle" },
    { key: "departement", label: "Departement", className: "w-[130px]" },
    { key: "responsable", label: "Responsable", className: "w-[160px]" },
    { key: "statut", label: "Statut", className: "w-[130px]" },
    { key: "kpis", label: "KPIs", className: "w-[100px]" },
    { key: "budget", label: "Budget", className: "w-[150px]" },
  ];

  function SortIcon({ col }: { col: SortKey }) {
    if (sortKey !== col) {
      return <ArrowUpDown size={12} className="text-white/20" />;
    }
    return sortDir === "asc" ? (
      <ArrowUp size={12} className="text-cyan-400" />
    ) : (
      <ArrowDown size={12} className="text-cyan-400" />
    );
  }

  return (
    <div className="space-y-4">
      {/* Table container */}
      <div
        className={cn(
          "rounded-xl border border-white/[0.08] overflow-hidden",
          "bg-white/[0.02] backdrop-blur-xl"
        )}
      >
        <div className="overflow-x-auto">
          <table className="w-full">
            {/* Header */}
            <thead>
              <tr className="border-b border-white/[0.08] bg-white/[0.03]">
                {columns.map((col) => (
                  <th
                    key={col.key}
                    className={cn(
                      "px-4 py-3 text-left text-xs font-medium text-white/50 uppercase tracking-wider",
                      "cursor-pointer select-none hover:text-white/70 transition-colors",
                      col.className
                    )}
                    onClick={() => handleSort(col.key)}
                  >
                    <div className="flex items-center gap-1.5">
                      {col.label}
                      <SortIcon col={col.key} />
                    </div>
                  </th>
                ))}
              </tr>
            </thead>

            {/* Body */}
            <tbody>
              <AnimatePresence mode="wait">
                {paged.map((projet, index) => {
                  const dept = getDepartementForProjet(projet, departements);
                  const score = calculateProjetScore(projet.kpis);

                  return (
                    <motion.tr
                      key={projet.id}
                      initial={{ opacity: 0, y: 8 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -8 }}
                      transition={{
                        duration: 0.2,
                        delay: index * 0.02,
                      }}
                      onClick={() => router.push(`/projets/${projet.id}`)}
                      className={cn(
                        "border-b border-white/[0.04] cursor-pointer",
                        "hover:bg-white/[0.04] transition-colors duration-150",
                        "group"
                      )}
                    >
                      {/* Code */}
                      <td className="px-4 py-3">
                        <span className="font-mono text-sm text-cyan-400/80 group-hover:text-cyan-400 transition-colors">
                          {projet.code}
                        </span>
                      </td>

                      {/* Libelle */}
                      <td className="px-4 py-3">
                        <span className="text-sm text-white/80 group-hover:text-white/95 transition-colors line-clamp-1">
                          {projet.libelle}
                        </span>
                      </td>

                      {/* Departement */}
                      <td className="px-4 py-3">
                        {dept && (
                          <span
                            className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium border"
                            style={{
                              backgroundColor: `${dept.couleur}15`,
                              borderColor: `${dept.couleur}30`,
                              color: dept.couleur,
                            }}
                          >
                            {dept.nomCourt || dept.code}
                          </span>
                        )}
                      </td>

                      {/* Responsable */}
                      <td className="px-4 py-3">
                        <span className="text-sm text-white/60">
                          {projet.responsable || "—"}
                        </span>
                      </td>

                      {/* Statut */}
                      <td className="px-4 py-3">
                        <StatusBadge status={projet.statut} />
                      </td>

                      {/* KPIs */}
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          {projet.kpis.length > 0 ? (
                            <>
                              <ProgressRing
                                value={score}
                                size="sm"
                                showLabel={false}
                              />
                              <span className="text-xs text-white/50">
                                {projet.kpis.length} KPI
                                {projet.kpis.length > 1 ? "s" : ""}
                              </span>
                            </>
                          ) : (
                            <span className="text-xs text-white/30">—</span>
                          )}
                        </div>
                      </td>

                      {/* Budget */}
                      <td className="px-4 py-3">
                        <span className="text-sm text-white/60 tabular-nums">
                          {projet.budgetAlloue
                            ? formatBudget(projet.budgetAlloue, projet.devise)
                            : "—"}
                        </span>
                      </td>
                    </motion.tr>
                  );
                })}
              </AnimatePresence>

              {paged.length === 0 && (
                <tr>
                  <td
                    colSpan={columns.length}
                    className="px-4 py-12 text-center text-white/30 text-sm"
                  >
                    Aucun projet ne correspond aux filtres selectionnes.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between">
          <p className="text-xs text-white/40">
            Page {page + 1} sur {totalPages}
          </p>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setPage(Math.max(0, page - 1))}
              disabled={page === 0}
              className={cn(
                "flex items-center justify-center w-8 h-8 rounded-lg",
                "bg-white/[0.03] border border-white/[0.08] backdrop-blur-xl",
                "transition-all duration-200",
                page === 0
                  ? "opacity-30 cursor-not-allowed"
                  : "hover:bg-white/[0.06] hover:border-white/[0.12]"
              )}
            >
              <ChevronLeft size={14} className="text-white/60" />
            </button>

            {Array.from({ length: totalPages }, (_, i) => (
              <button
                key={i}
                onClick={() => setPage(i)}
                className={cn(
                  "flex items-center justify-center w-8 h-8 rounded-lg text-xs font-medium",
                  "transition-all duration-200",
                  page === i
                    ? "bg-cyan-500/15 text-cyan-400 border border-cyan-500/30"
                    : "bg-white/[0.03] border border-white/[0.08] text-white/50 hover:bg-white/[0.06]"
                )}
              >
                {i + 1}
              </button>
            ))}

            <button
              onClick={() => setPage(Math.min(totalPages - 1, page + 1))}
              disabled={page === totalPages - 1}
              className={cn(
                "flex items-center justify-center w-8 h-8 rounded-lg",
                "bg-white/[0.03] border border-white/[0.08] backdrop-blur-xl",
                "transition-all duration-200",
                page === totalPages - 1
                  ? "opacity-30 cursor-not-allowed"
                  : "hover:bg-white/[0.06] hover:border-white/[0.12]"
              )}
            >
              <ChevronRight size={14} className="text-white/60" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
