"use client";

import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import { cn, getStatutLabel, getStatutColor, calculateProjetScore } from "@/lib/utils";
import { ProgressRing } from "@/components/ui/progress-ring";
import type { Projet, Departement, Statut } from "@/lib/types";

interface ProjetsKanbanProps {
  projets: Projet[];
  departements: Departement[];
}

const KANBAN_COLUMNS: { statut: Statut; glowClass: string }[] = [
  { statut: "NON_DEMARRE", glowClass: "shadow-[0_0_15px_rgba(107,114,128,0.15)]" },
  { statut: "EN_COURS", glowClass: "shadow-[0_0_15px_rgba(6,182,212,0.15)]" },
  { statut: "EN_RETARD", glowClass: "shadow-[0_0_15px_rgba(239,68,68,0.15)]" },
  { statut: "EN_ATTENTE", glowClass: "shadow-[0_0_15px_rgba(245,158,11,0.15)]" },
  { statut: "COMPLET", glowClass: "shadow-[0_0_15px_rgba(16,185,129,0.15)]" },
];

function getDepartementForProjet(
  projet: Projet,
  departements: Departement[]
): Departement | undefined {
  const deptId = projet.strategie?.departementId;
  if (!deptId) return undefined;
  return departements.find((d) => d.id === deptId);
}

function KanbanCard({
  projet,
  departements,
  index,
}: {
  projet: Projet;
  departements: Departement[];
  index: number;
}) {
  const router = useRouter();
  const dept = getDepartementForProjet(projet, departements);
  const score = calculateProjetScore(projet.kpis);

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.2, delay: index * 0.03 }}
      onClick={() => router.push(`/projets/${projet.id}`)}
      className={cn(
        "p-3 rounded-lg cursor-grab active:cursor-grabbing",
        "bg-white/[0.03] border border-white/[0.08] backdrop-blur-xl",
        "hover:bg-white/[0.06] hover:border-white/[0.12]",
        "transition-all duration-200 group"
      )}
    >
      {/* Code */}
      <p className="font-mono text-xs text-cyan-400/60 group-hover:text-cyan-400 mb-1 transition-colors">
        {projet.code}
      </p>

      {/* Libelle */}
      <p className="text-sm text-white/80 group-hover:text-white/95 font-medium line-clamp-2 mb-2 transition-colors">
        {projet.libelle}
      </p>

      {/* Bottom row */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          {/* Responsable */}
          <span className="text-xs text-white/40 truncate max-w-[100px]">
            {projet.responsable || "—"}
          </span>
        </div>

        <div className="flex items-center gap-2">
          {/* Department badge */}
          {dept && (
            <span
              className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-medium border"
              style={{
                backgroundColor: `${dept.couleur}10`,
                borderColor: `${dept.couleur}25`,
                color: dept.couleur,
              }}
            >
              {dept.nomCourt || dept.code}
            </span>
          )}

          {/* Mini progress */}
          {projet.kpis.length > 0 && (
            <ProgressRing value={score} size="sm" showLabel={false} />
          )}
        </div>
      </div>
    </motion.div>
  );
}

export function ProjetsKanban({ projets, departements }: ProjetsKanbanProps) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.3 }}
      className="flex gap-4 overflow-x-auto pb-4 min-h-[400px]"
    >
      {KANBAN_COLUMNS.map((col) => {
        const columnProjets = projets.filter((p) => p.statut === col.statut);
        const color = getStatutColor(col.statut);
        const label = getStatutLabel(col.statut);

        return (
          <div
            key={col.statut}
            className="flex-shrink-0 w-[280px] flex flex-col"
          >
            {/* Column header */}
            <div
              className={cn(
                "flex items-center gap-2 px-3 py-2.5 rounded-t-xl mb-2",
                "bg-white/[0.03] border border-white/[0.08] backdrop-blur-xl",
                col.glowClass
              )}
            >
              <div
                className="w-2.5 h-2.5 rounded-full flex-shrink-0"
                style={{
                  backgroundColor: color,
                  boxShadow: `0 0 8px ${color}60`,
                }}
              />
              <span className="text-sm font-medium text-white/80 flex-1">
                {label}
              </span>
              <span
                className="flex items-center justify-center min-w-[22px] h-[22px] px-1.5 rounded-full text-[11px] font-bold"
                style={{
                  backgroundColor: `${color}20`,
                  color: color,
                }}
              >
                {columnProjets.length}
              </span>
            </div>

            {/* Column body */}
            <div className="flex-1 space-y-2">
              {columnProjets.map((projet, index) => (
                <KanbanCard
                  key={projet.id}
                  projet={projet}
                  departements={departements}
                  index={index}
                />
              ))}
              {columnProjets.length === 0 && (
                <div className="flex items-center justify-center py-8 text-white/20 text-xs">
                  Aucun projet
                </div>
              )}
            </div>
          </div>
        );
      })}
    </motion.div>
  );
}
