"use client";

import { useState, useMemo, useCallback, type ReactNode } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Search, X, LayoutList, Kanban, ChevronDown } from "lucide-react";
import { cn } from "@/lib/utils";
import { getStatutLabel } from "@/lib/utils";
import type { Projet, Departement, AxeStrategique, Statut } from "@/lib/types";

export type ViewMode = "table" | "kanban";

interface ProjetsFilterBarProps {
  projets: Projet[];
  departements: Departement[];
  axes: AxeStrategique[];
  children: (filteredProjets: Projet[], viewMode: ViewMode) => ReactNode;
}

const STATUTS: Statut[] = [
  "NON_DEMARRE",
  "EN_COURS",
  "EN_RETARD",
  "EN_ATTENTE",
  "COMPLET",
  "ANNULE",
  "A_RECONDUIRE",
];

function GlassSelect({
  value,
  onChange,
  options,
  placeholder,
}: {
  value: string;
  onChange: (v: string) => void;
  options: { value: string; label: string }[];
  placeholder: string;
}) {
  const [open, setOpen] = useState(false);
  const selected = options.find((o) => o.value === value);

  return (
    <div className="relative">
      <button
        type="button"
        onClick={() => setOpen(!open)}
        className={cn(
          "flex items-center gap-2 h-10 px-3 rounded-lg text-sm",
          "bg-white/[0.03] border border-white/[0.08] backdrop-blur-xl",
          "hover:bg-white/[0.06] hover:border-white/[0.12] transition-all duration-200",
          "min-w-[160px] text-left",
          value ? "text-white/90" : "text-white/40"
        )}
      >
        <span className="flex-1 truncate">
          {selected ? selected.label : placeholder}
        </span>
        <ChevronDown
          size={14}
          className={cn(
            "text-white/30 transition-transform duration-200",
            open && "rotate-180"
          )}
        />
      </button>
      <AnimatePresence>
        {open && (
          <>
            <div
              className="fixed inset-0 z-40"
              onClick={() => setOpen(false)}
            />
            <motion.div
              initial={{ opacity: 0, y: -4, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -4, scale: 0.98 }}
              transition={{ duration: 0.15 }}
              className={cn(
                "absolute top-full mt-1 left-0 z-50 w-full min-w-[200px]",
                "bg-[#0f1629]/95 border border-white/[0.08] backdrop-blur-xl rounded-lg",
                "shadow-xl shadow-black/30 max-h-[280px] overflow-y-auto py-1"
              )}
            >
              <button
                type="button"
                onClick={() => {
                  onChange("");
                  setOpen(false);
                }}
                className={cn(
                  "w-full px-3 py-2 text-sm text-left hover:bg-white/[0.06] transition-colors",
                  !value ? "text-cyan-400" : "text-white/50"
                )}
              >
                {placeholder}
              </button>
              {options.map((opt) => (
                <button
                  key={opt.value}
                  type="button"
                  onClick={() => {
                    onChange(opt.value);
                    setOpen(false);
                  }}
                  className={cn(
                    "w-full px-3 py-2 text-sm text-left hover:bg-white/[0.06] transition-colors",
                    value === opt.value
                      ? "text-cyan-400 bg-cyan-500/5"
                      : "text-white/70"
                  )}
                >
                  {opt.label}
                </button>
              ))}
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}

export function ProjetsFilterBar({
  projets,
  departements,
  axes,
  children,
}: ProjetsFilterBarProps) {
  const [search, setSearch] = useState("");
  const [departementFilter, setDepartementFilter] = useState("");
  const [statutFilter, setStatutFilter] = useState("");
  const [axeFilter, setAxeFilter] = useState("");
  const [viewMode, setViewMode] = useState<ViewMode>("table");

  const activeFilterCount = useMemo(() => {
    let count = 0;
    if (search) count++;
    if (departementFilter) count++;
    if (statutFilter) count++;
    if (axeFilter) count++;
    return count;
  }, [search, departementFilter, statutFilter, axeFilter]);

  const clearFilters = useCallback(() => {
    setSearch("");
    setDepartementFilter("");
    setStatutFilter("");
    setAxeFilter("");
  }, []);

  const filteredProjets = useMemo(() => {
    return projets.filter((p) => {
      // Search
      if (search) {
        const q = search.toLowerCase();
        const matchSearch =
          p.code.toLowerCase().includes(q) ||
          p.libelle.toLowerCase().includes(q) ||
          (p.responsable && p.responsable.toLowerCase().includes(q));
        if (!matchSearch) return false;
      }

      // Departement filter
      if (departementFilter) {
        const stratDeptId = p.strategie?.departementId;
        if (stratDeptId !== departementFilter) return false;
      }

      // Statut filter
      if (statutFilter) {
        if (p.statut !== statutFilter) return false;
      }

      // Axe filter
      if (axeFilter) {
        const axeId =
          p.strategie?.objectifStrategique?.axeId ??
          p.strategie?.objectifStrategiqueId;
        // find the objectif in the axe
        const matchAxe = axes.some(
          (a) =>
            a.id === axeFilter &&
            a.objectifs.some(
              (o) =>
                o.id === p.strategie?.objectifStrategiqueId
            )
        );
        if (!matchAxe) return false;
      }

      return true;
    });
  }, [projets, search, departementFilter, statutFilter, axeFilter, axes]);

  const departementOptions = departements.map((d) => ({
    value: d.id,
    label: d.nomCourt || d.nom,
  }));

  const statutOptions = STATUTS.map((s) => ({
    value: s,
    label: getStatutLabel(s),
  }));

  const axeOptions = axes.map((a) => ({
    value: a.id,
    label: a.nom,
  }));

  return (
    <div className="space-y-4">
      {/* Filter bar */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.1 }}
        className={cn(
          "flex flex-wrap items-center gap-3 p-4 rounded-xl",
          "bg-white/[0.03] border border-white/[0.08] backdrop-blur-xl"
        )}
      >
        {/* Search */}
        <div className="relative flex-1 min-w-[220px]">
          <Search
            size={16}
            className="absolute left-3 top-1/2 -translate-y-1/2 text-white/30"
          />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Rechercher un projet..."
            className={cn(
              "w-full h-10 pl-9 pr-3 rounded-lg text-sm",
              "bg-white/[0.03] border border-white/[0.08]",
              "text-white/90 placeholder:text-white/30",
              "focus:outline-none focus:border-cyan-500/40 focus:ring-1 focus:ring-cyan-500/20",
              "transition-all duration-200"
            )}
          />
          {search && (
            <button
              onClick={() => setSearch("")}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-white/30 hover:text-white/60 transition-colors"
            >
              <X size={14} />
            </button>
          )}
        </div>

        {/* Dropdown filters */}
        <GlassSelect
          value={departementFilter}
          onChange={setDepartementFilter}
          options={departementOptions}
          placeholder="Departement"
        />
        <GlassSelect
          value={statutFilter}
          onChange={setStatutFilter}
          options={statutOptions}
          placeholder="Statut"
        />
        <GlassSelect
          value={axeFilter}
          onChange={setAxeFilter}
          options={axeOptions}
          placeholder="Axe strategique"
        />

        {/* Active filter badge + clear */}
        <AnimatePresence>
          {activeFilterCount > 0 && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="flex items-center gap-2"
            >
              <span className="flex items-center justify-center w-6 h-6 rounded-full bg-cyan-500/20 text-cyan-400 text-xs font-bold">
                {activeFilterCount}
              </span>
              <button
                onClick={clearFilters}
                className="text-xs text-white/40 hover:text-red-400 transition-colors flex items-center gap-1"
              >
                <X size={12} />
                Effacer
              </button>
            </motion.div>
          )}
        </AnimatePresence>

        {/* View toggle */}
        <div className="flex items-center gap-1 ml-auto bg-white/[0.03] border border-white/[0.08] rounded-lg p-0.5">
          <button
            onClick={() => setViewMode("table")}
            className={cn(
              "flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-all duration-200",
              viewMode === "table"
                ? "bg-cyan-500/15 text-cyan-400 shadow-[0_0_10px_rgba(6,182,212,0.1)]"
                : "text-white/40 hover:text-white/60"
            )}
          >
            <LayoutList size={14} />
            Table
          </button>
          <button
            onClick={() => setViewMode("kanban")}
            className={cn(
              "flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-all duration-200",
              viewMode === "kanban"
                ? "bg-cyan-500/15 text-cyan-400 shadow-[0_0_10px_rgba(6,182,212,0.1)]"
                : "text-white/40 hover:text-white/60"
            )}
          >
            <Kanban size={14} />
            Kanban
          </button>
        </div>
      </motion.div>

      {/* Results count */}
      <div className="flex items-center justify-between px-1">
        <motion.p
          key={filteredProjets.length}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-sm text-white/40"
        >
          <span className="text-white/70 font-medium">
            {filteredProjets.length}
          </span>{" "}
          projet{filteredProjets.length !== 1 ? "s" : ""}{" "}
          {activeFilterCount > 0 ? "filtre(s)" : "au total"}
        </motion.p>
      </div>

      {/* Children with filtered data */}
      {children(filteredProjets, viewMode)}
    </div>
  );
}
