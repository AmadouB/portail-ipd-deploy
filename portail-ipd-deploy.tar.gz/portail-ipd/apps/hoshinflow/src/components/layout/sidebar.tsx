"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  LayoutDashboard,
  Target,
  Building2,
  FolderKanban,
  BarChart3,
  Grid3x3,
  Wallet,
  Network,
  ClipboardCheck,
  CalendarCheck,
  Layers,
  Map,
  FileSpreadsheet,
  Settings,
  ChevronLeft,
  ChevronRight,
  User,
} from "lucide-react";
import { useAuth } from "@/lib/auth-context";

interface NavItem {
  label: string;
  href: string;
  icon: typeof LayoutDashboard;
  adminOnly?: boolean;
}

const navItems: NavItem[] = [
  { label: "Dashboard", href: "/dashboard", icon: LayoutDashboard },
  { label: "Matrice", href: "/matrice", icon: Layers },
  { label: "Axes Strategiques", href: "/axes", icon: Target },
  { label: "Departements", href: "/departements", icon: Building2 },
  { label: "Projets", href: "/projets", icon: FolderKanban },
  { label: "KPIs", href: "/kpis", icon: BarChart3 },
  { label: "X-Matrix", href: "/x-matrix", icon: Grid3x3 },
  { label: "Budget", href: "/budget", icon: Wallet },
  { label: "Organigramme", href: "/organigramme", icon: Network },
  { label: "Renseignement", href: "/mapping", icon: ClipboardCheck },
  { label: "Suivi Hebdo", href: "/rapports", icon: CalendarCheck },
  { label: "Cartographie", href: "/cartographie", icon: Map },
  { label: "Import Excel", href: "/admin/import", icon: FileSpreadsheet, adminOnly: true },
  { label: "Import Stratégie", href: "/admin/import-strategy", icon: FileSpreadsheet, adminOnly: true },
];

interface SidebarProps {
  collapsed: boolean;
  onToggle: () => void;
}

export default function Sidebar({ collapsed, onToggle }: SidebarProps) {
  const pathname = usePathname();
  const { user } = useAuth();
  const isAdmin = user?.role === "ADMIN";
  const visibleNavItems = navItems.filter((item) => !item.adminOnly || isAdmin);

  return (
    <motion.aside
      initial={false}
      animate={{ width: collapsed ? 72 : 260 }}
      transition={{ duration: 0.3, ease: [0.4, 0, 0.2, 1] }}
      className="fixed left-0 top-0 bottom-0 z-40 flex flex-col glass-panel"
    >
      {/* Logo */}
      <div className="flex items-center h-16 px-4 border-b border-border">
        <div className="flex items-center gap-3 overflow-hidden">
          <div className="flex-shrink-0 w-9 h-9 rounded-lg bg-neon-cyan/10 flex items-center justify-center animate-pulse-glow">
            <span className="text-neon-cyan font-bold text-lg">H</span>
          </div>
          <AnimatePresence>
            {!collapsed && (
              <motion.span
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -10 }}
                transition={{ duration: 0.2 }}
                className="text-lg font-bold text-foreground whitespace-nowrap text-glow-cyan"
              >
                HoshinFlow
              </motion.span>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 py-4 px-2 space-y-1 overflow-y-auto">
        {visibleNavItems.map((item) => {
          const isActive =
            pathname === item.href || pathname?.startsWith(item.href + "/");
          const Icon = item.icon;

          return (
            <Link
              key={item.href}
              href={item.href}
              className={`
                relative flex items-center gap-3 px-3 py-2.5 rounded-lg
                transition-all duration-200 group
                ${
                  isActive
                    ? "bg-neon-cyan/10 text-neon-cyan"
                    : "text-foreground-secondary hover:bg-surface-hover hover:text-foreground"
                }
              `}
            >
              {isActive && <div className="nav-active-indicator" />}
              <Icon
                size={20}
                className={`flex-shrink-0 transition-colors duration-200 ${
                  isActive
                    ? "text-neon-cyan drop-shadow-[0_0_8px_rgba(6,182,212,0.5)]"
                    : "text-foreground-secondary group-hover:text-foreground"
                }`}
              />
              <AnimatePresence>
                {!collapsed && (
                  <motion.span
                    initial={{ opacity: 0, x: -8 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -8 }}
                    transition={{ duration: 0.15 }}
                    className="text-sm font-medium whitespace-nowrap"
                  >
                    {item.label}
                  </motion.span>
                )}
              </AnimatePresence>
            </Link>
          );
        })}
      </nav>

      {/* Bottom section */}
      <div className="border-t border-border p-2 space-y-1">
        <Link
          href="/settings"
          className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-foreground-secondary hover:bg-surface-hover hover:text-foreground transition-all duration-200"
        >
          <Settings size={20} className="flex-shrink-0" />
          <AnimatePresence>
            {!collapsed && (
              <motion.span
                initial={{ opacity: 0, x: -8 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -8 }}
                transition={{ duration: 0.15 }}
                className="text-sm font-medium whitespace-nowrap"
              >
                Parametres
              </motion.span>
            )}
          </AnimatePresence>
        </Link>

        <div className="flex items-center gap-3 px-3 py-2.5 rounded-lg">
          <div className="flex-shrink-0 w-8 h-8 rounded-full bg-neon-violet/20 flex items-center justify-center border border-neon-violet/30">
            <User size={16} className="text-neon-violet" />
          </div>
          <AnimatePresence>
            {!collapsed && (
              <motion.div
                initial={{ opacity: 0, x: -8 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -8 }}
                transition={{ duration: 0.15 }}
                className="overflow-hidden"
              >
                <p className="text-sm font-medium text-foreground truncate">
                  Utilisateur
                </p>
                <p className="text-xs text-foreground-secondary truncate">
                  admin@hoshinflow.com
                </p>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* Collapse toggle */}
      <button
        onClick={onToggle}
        className="absolute -right-3 top-20 w-6 h-6 rounded-full bg-background border border-border flex items-center justify-center hover:border-border-hover hover:bg-surface-hover transition-all duration-200 z-50"
      >
        {collapsed ? (
          <ChevronRight size={14} className="text-foreground-secondary" />
        ) : (
          <ChevronLeft size={14} className="text-foreground-secondary" />
        )}
      </button>
    </motion.aside>
  );
}
