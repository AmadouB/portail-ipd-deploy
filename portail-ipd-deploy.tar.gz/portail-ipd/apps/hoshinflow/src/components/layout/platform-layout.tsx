"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import Sidebar from "./sidebar";
import Header from "./header";
import { TrimestreProvider } from "@/lib/trimestre-context";
import { DataStoreProvider } from "@/lib/data-store";

interface PlatformLayoutProps {
  children: React.ReactNode;
}

export default function PlatformLayout({ children }: PlatformLayoutProps) {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  const sidebarWidth = sidebarCollapsed ? 72 : 260;

  return (
    <TrimestreProvider>
      <DataStoreProvider>
        <div className="min-h-screen bg-background">
          <Sidebar
            collapsed={sidebarCollapsed}
            onToggle={() => setSidebarCollapsed((prev) => !prev)}
          />

          <motion.div
            initial={false}
            animate={{ marginLeft: sidebarWidth }}
            transition={{ duration: 0.3, ease: [0.4, 0, 0.2, 1] }}
            className="flex flex-col min-h-screen"
          >
            <Header />

            <main className="flex-1 p-6 overflow-auto">{children}</main>
          </motion.div>
        </div>
      </DataStoreProvider>
    </TrimestreProvider>
  );
}
