"use client";

import { motion } from "framer-motion";
import { Bell, Search, User, ChevronRight } from "lucide-react";
import { useTrimestre } from "@/lib/trimestre-context";
import type { Trimestre } from "@/lib/types";

const trimestres: Trimestre[] = ["T1", "T2", "T3", "T4"];

interface BreadcrumbItem {
  label: string;
  href?: string;
}

interface HeaderProps {
  breadcrumbs?: BreadcrumbItem[];
}

export default function Header({ breadcrumbs = [] }: HeaderProps) {
  const { selectedTrimestre, setSelectedTrimestre } = useTrimestre();
  const notificationCount = 3;

  return (
    <header className="h-16 flex items-center justify-between px-6 border-b border-border bg-background/80 backdrop-blur-xl sticky top-0 z-30">
      {/* Left: Breadcrumbs */}
      <div className="flex items-center gap-2 text-sm min-w-0">
        {breadcrumbs.length > 0 ? (
          breadcrumbs.map((crumb, index) => (
            <div key={index} className="flex items-center gap-2">
              {index > 0 && (
                <ChevronRight
                  size={14}
                  className="text-foreground-secondary flex-shrink-0"
                />
              )}
              <span
                className={
                  index === breadcrumbs.length - 1
                    ? "text-foreground font-medium truncate"
                    : "text-foreground-secondary truncate"
                }
              >
                {crumb.label}
              </span>
            </div>
          ))
        ) : (
          <span className="text-foreground-secondary">HoshinFlow</span>
        )}
      </div>

      {/* Center: Trimestre selector */}
      <div className="flex items-center gap-1 p-1 rounded-lg bg-surface border border-border">
        {trimestres.map((t) => {
          const isActive = selectedTrimestre === t;
          return (
            <button
              key={t}
              onClick={() => setSelectedTrimestre(t)}
              className="relative px-4 py-1.5 text-sm font-medium rounded-md transition-colors duration-200"
            >
              {isActive && (
                <motion.div
                  layoutId="trimestre-indicator"
                  className="absolute inset-0 rounded-md bg-neon-cyan/15 border border-neon-cyan/30"
                  transition={{ type: "spring", stiffness: 400, damping: 30 }}
                />
              )}
              <span
                className={`relative z-10 ${
                  isActive
                    ? "text-neon-cyan"
                    : "text-foreground-secondary hover:text-foreground"
                }`}
              >
                {t}
              </span>
            </button>
          );
        })}

        {/* "All" indicator — show a subtle label when no trimestre selected */}
        {selectedTrimestre === null && (
          <span className="ml-1 px-2 py-1 text-[10px] text-white/30 uppercase tracking-wider">
            Tous
          </span>
        )}
      </div>

      {/* Right: Actions */}
      <div className="flex items-center gap-2">
        <button className="p-2 rounded-lg text-foreground-secondary hover:text-foreground hover:bg-surface-hover transition-all duration-200">
          <Search size={18} />
        </button>

        <button className="relative p-2 rounded-lg text-foreground-secondary hover:text-foreground hover:bg-surface-hover transition-all duration-200">
          <Bell size={18} />
          {notificationCount > 0 && (
            <span className="absolute top-1 right-1 w-4 h-4 rounded-full bg-neon-red text-[10px] font-bold text-white flex items-center justify-center">
              {notificationCount}
            </span>
          )}
        </button>

        <div className="ml-2 w-8 h-8 rounded-full bg-neon-cyan/20 border border-neon-cyan/30 flex items-center justify-center cursor-pointer hover:border-neon-cyan/50 transition-colors duration-200">
          <User size={16} className="text-neon-cyan" />
        </div>
      </div>
    </header>
  );
}
