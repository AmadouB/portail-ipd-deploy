"use client";

import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { AnimatedNumber } from "./animated-number";
import { GlassPanel } from "./glass-panel";

type TrendDirection = "up" | "down" | "flat";
type NumberFormat = "percent" | "number" | "currency";

interface NeonKpiCardProps {
  label: string;
  value: number;
  target?: number;
  format?: NumberFormat;
  trend?: TrendDirection;
  trendValue?: string;
  className?: string;
}

function getPerformanceColor(value: number, target: number): string {
  const ratio = (value / target) * 100;
  if (ratio >= 80) return "emerald";
  if (ratio >= 50) return "cyan";
  if (ratio >= 20) return "amber";
  return "red";
}

function getProgressPercent(value: number, target: number): number {
  if (target === 0) return 0;
  return Math.min(100, Math.max(0, (value / target) * 100));
}

const trendIcons: Record<TrendDirection, { path: string; color: string }> = {
  up: {
    path: "M5 15l7-7 7 7",
    color: "text-emerald-400",
  },
  down: {
    path: "M19 9l-7 7-7-7",
    color: "text-red-400",
  },
  flat: {
    path: "M5 12h14",
    color: "text-amber-400",
  },
};

const progressBarColorMap: Record<string, string> = {
  emerald: "bg-emerald-500",
  cyan: "bg-cyan-500",
  amber: "bg-amber-500",
  red: "bg-red-500",
};

const progressBarGlowMap: Record<string, string> = {
  emerald: "shadow-[0_0_8px_rgba(16,185,129,0.4)]",
  cyan: "shadow-[0_0_8px_rgba(6,182,212,0.4)]",
  amber: "shadow-[0_0_8px_rgba(245,158,11,0.4)]",
  red: "shadow-[0_0_8px_rgba(239,68,68,0.4)]",
};

export function NeonKpiCard({
  label,
  value,
  target,
  format = "number",
  trend,
  trendValue,
  className,
}: NeonKpiCardProps) {
  const perfColor = target
    ? getPerformanceColor(value, target)
    : value >= 80
      ? "emerald"
      : value >= 50
        ? "cyan"
        : value >= 20
          ? "amber"
          : "red";

  const accentColor = perfColor as "cyan" | "emerald" | "amber" | "red";
  const progressPercent = target ? getProgressPercent(value, target) : null;

  return (
    <GlassPanel
      variant="glow"
      accentColor={accentColor}
      accentPosition="top"
      hover
      className={cn("p-5", className)}
    >
      {/* Header: label + trend */}
      <div className="flex items-center justify-between mb-3">
        <span className="text-sm text-white/50 font-medium">{label}</span>
        {trend && (
          <div className={cn("flex items-center gap-1", trendIcons[trend].color)}>
            <svg
              width="14"
              height="14"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d={trendIcons[trend].path} />
            </svg>
            {trendValue && (
              <span className="text-xs font-medium">{trendValue}</span>
            )}
          </div>
        )}
      </div>

      {/* Value */}
      <div className="mb-1">
        <AnimatedNumber
          value={value}
          format={format}
          colorByValue
          className="text-2xl font-bold"
        />
      </div>

      {/* Target */}
      {target !== undefined && (
        <p className="text-xs text-white/40 mb-3">
          Objectif :{" "}
          <span className="text-white/60">
            {format === "percent"
              ? `${target}%`
              : format === "currency"
                ? new Intl.NumberFormat("fr-FR", {
                    style: "currency",
                    currency: "EUR",
                  }).format(target)
                : new Intl.NumberFormat("fr-FR").format(target)}
          </span>
        </p>
      )}

      {/* Mini progress bar */}
      {progressPercent !== null && (
        <div className="w-full h-1.5 rounded-full bg-white/[0.06] overflow-hidden">
          <motion.div
            className={cn(
              "h-full rounded-full",
              progressBarColorMap[perfColor],
              progressBarGlowMap[perfColor]
            )}
            initial={{ width: 0 }}
            animate={{ width: `${progressPercent}%` }}
            transition={{ duration: 1, ease: "easeOut", delay: 0.3 }}
          />
        </div>
      )}
    </GlassPanel>
  );
}
