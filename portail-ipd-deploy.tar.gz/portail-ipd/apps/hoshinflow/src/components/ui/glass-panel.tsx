"use client";

import { type ReactNode, type MouseEvent } from "react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

type AccentColor = "cyan" | "emerald" | "amber" | "red" | "violet" | "rose";
type Variant = "default" | "glow" | "solid";
type AccentPosition = "top" | "left";

interface GlassPanelProps {
  children: ReactNode;
  className?: string;
  variant?: Variant;
  accentColor?: AccentColor;
  accentPosition?: AccentPosition;
  hover?: boolean;
  onClick?: (e: MouseEvent<HTMLDivElement>) => void;
}

const accentColorMap: Record<AccentColor, string> = {
  cyan: "#06b6d4",
  emerald: "#10b981",
  amber: "#f59e0b",
  red: "#ef4444",
  violet: "#8b5cf6",
  rose: "#ec4899",
};

const glowShadowMap: Record<AccentColor, string> = {
  cyan: "0 0 20px rgba(6,182,212,0.15), 0 0 40px rgba(6,182,212,0.05)",
  emerald: "0 0 20px rgba(16,185,129,0.15), 0 0 40px rgba(16,185,129,0.05)",
  amber: "0 0 20px rgba(245,158,11,0.15), 0 0 40px rgba(245,158,11,0.05)",
  red: "0 0 20px rgba(239,68,68,0.15), 0 0 40px rgba(239,68,68,0.05)",
  violet: "0 0 20px rgba(139,92,246,0.15), 0 0 40px rgba(139,92,246,0.05)",
  rose: "0 0 20px rgba(236,72,153,0.15), 0 0 40px rgba(236,72,153,0.05)",
};

const accentBorderClass: Record<AccentPosition, Record<AccentColor, string>> = {
  top: {
    cyan: "border-t-2 border-t-cyan-500",
    emerald: "border-t-2 border-t-emerald-500",
    amber: "border-t-2 border-t-amber-500",
    red: "border-t-2 border-t-red-500",
    violet: "border-t-2 border-t-violet-500",
    rose: "border-t-2 border-t-rose-500",
  },
  left: {
    cyan: "border-l-2 border-l-cyan-500",
    emerald: "border-l-2 border-l-emerald-500",
    amber: "border-l-2 border-l-amber-500",
    red: "border-l-2 border-l-red-500",
    violet: "border-l-2 border-l-violet-500",
    rose: "border-l-2 border-l-rose-500",
  },
};

export function GlassPanel({
  children,
  className,
  variant = "default",
  accentColor,
  accentPosition = "top",
  hover = false,
  onClick,
}: GlassPanelProps) {
  const baseClasses =
    "rounded-xl border border-white/[0.08] transition-all duration-300";

  const variantClasses: Record<Variant, string> = {
    default: "bg-white/[0.03] backdrop-blur-xl",
    glow: "bg-white/[0.03] backdrop-blur-xl",
    solid: "bg-[#0f1629] backdrop-blur-xl",
  };

  const hoverClasses = hover
    ? "hover:bg-white/[0.06] hover:border-white/[0.12] cursor-pointer"
    : "";

  const accentClasses =
    accentColor && accentPosition
      ? accentBorderClass[accentPosition][accentColor]
      : "";

  const glowStyle =
    variant === "glow" && accentColor
      ? { boxShadow: glowShadowMap[accentColor] }
      : {};

  const hoverGlowStyle =
    variant === "glow" && accentColor
      ? {
          boxShadow: glowShadowMap[accentColor].replace(
            /0\.(15|05)/g,
            (_, m) => (m === "15" ? "0.3" : "0.1")
          ),
        }
      : {};

  return (
    <motion.div
      className={cn(
        baseClasses,
        variantClasses[variant],
        hoverClasses,
        accentClasses,
        onClick && "cursor-pointer",
        className
      )}
      style={glowStyle}
      whileHover={
        hover
          ? {
              y: -2,
              ...(variant === "glow" && accentColor ? { style: hoverGlowStyle } : {}),
            }
          : undefined
      }
      transition={{ duration: 0.2, ease: "easeOut" }}
      onClick={onClick}
    >
      {children}
    </motion.div>
  );
}
