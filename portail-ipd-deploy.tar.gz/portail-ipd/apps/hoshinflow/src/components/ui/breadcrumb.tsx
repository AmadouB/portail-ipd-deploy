"use client";

import { type ReactNode } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

interface BreadcrumbItem {
  label: string;
  href?: string;
  icon?: ReactNode;
}

interface BreadcrumbProps {
  items: BreadcrumbItem[];
  className?: string;
}

function ChevronSeparator() {
  return (
    <svg
      width="16"
      height="16"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className="text-white/20 flex-shrink-0"
    >
      <path d="M9 18l6-6-6-6" />
    </svg>
  );
}

export function Breadcrumb({ items, className }: BreadcrumbProps) {
  return (
    <nav
      aria-label="Breadcrumb"
      className={cn(
        "inline-flex items-center gap-1 rounded-lg bg-white/[0.03] backdrop-blur-xl border border-white/[0.08] px-3 py-1.5",
        className
      )}
    >
      {items.map((item, index) => {
        const isLast = index === items.length - 1;

        return (
          <motion.div
            key={`${item.label}-${index}`}
            className="flex items-center gap-1"
            initial={{ opacity: 0, x: -4 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.2, delay: index * 0.05 }}
          >
            {index > 0 && <ChevronSeparator />}

            {isLast || !item.href ? (
              <span
                className={cn(
                  "flex items-center gap-1.5 text-sm px-1.5 py-0.5 rounded",
                  isLast
                    ? "text-cyan-400 font-medium"
                    : "text-white/50"
                )}
              >
                {item.icon && (
                  <span className="flex-shrink-0 w-4 h-4">{item.icon}</span>
                )}
                {item.label}
              </span>
            ) : (
              <Link
                href={item.href}
                className={cn(
                  "group flex items-center gap-1.5 text-sm text-white/50 px-1.5 py-0.5 rounded",
                  "transition-all duration-200",
                  "hover:text-white/90 hover:bg-white/[0.05]",
                  "hover:shadow-[0_0_10px_rgba(6,182,212,0.1)]"
                )}
              >
                {item.icon && (
                  <span className="flex-shrink-0 w-4 h-4">{item.icon}</span>
                )}
                {item.label}
              </Link>
            )}
          </motion.div>
        );
      })}
    </nav>
  );
}
