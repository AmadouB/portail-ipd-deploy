"use client";

import { motion, useSpring, useMotionValue, useTransform } from "framer-motion";
import { useEffect, useRef } from "react";
import { useInView } from "framer-motion";
import { cn } from "@/lib/utils";

type RingSize = "sm" | "md" | "lg";

interface ProgressRingProps {
  value: number;
  size?: RingSize;
  showLabel?: boolean;
  className?: string;
}

const sizeConfig: Record<
  RingSize,
  { dimension: number; strokeWidth: number; fontSize: string }
> = {
  sm: { dimension: 48, strokeWidth: 4, fontSize: "text-xs" },
  md: { dimension: 80, strokeWidth: 5, fontSize: "text-lg" },
  lg: { dimension: 120, strokeWidth: 6, fontSize: "text-2xl" },
};

function getStrokeColor(value: number): string {
  if (value >= 80) return "#10b981";
  if (value >= 50) return "#06b6d4";
  if (value >= 20) return "#f59e0b";
  return "#ef4444";
}

function getTextColorClass(value: number): string {
  if (value >= 80) return "text-emerald-400";
  if (value >= 50) return "text-cyan-400";
  if (value >= 20) return "text-amber-400";
  return "text-red-400";
}

export function ProgressRing({
  value,
  size = "md",
  showLabel = true,
  className,
}: ProgressRingProps) {
  const ref = useRef<SVGSVGElement>(null);
  const inView = useInView(ref, { once: true, margin: "-20px" });

  const config = sizeConfig[size];
  const radius = (config.dimension - config.strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const clampedValue = Math.min(100, Math.max(0, value));

  const motionValue = useMotionValue(0);
  const springValue = useSpring(motionValue, {
    duration: 1200,
    bounce: 0,
  });

  const strokeDashoffset = useTransform(
    springValue,
    [0, 100],
    [circumference, 0]
  );

  const displayValue = useRef<HTMLSpanElement>(null);

  useEffect(() => {
    if (inView) {
      motionValue.set(clampedValue);
    }
  }, [inView, clampedValue, motionValue]);

  useEffect(() => {
    const unsubscribe = springValue.on("change", (latest) => {
      if (displayValue.current) {
        displayValue.current.textContent = `${Math.round(latest)}%`;
      }
    });
    return unsubscribe;
  }, [springValue]);

  const strokeColor = getStrokeColor(clampedValue);
  const textColorClass = getTextColorClass(clampedValue);
  const center = config.dimension / 2;

  return (
    <div
      className={cn("relative inline-flex items-center justify-center", className)}
      style={{ width: config.dimension, height: config.dimension }}
    >
      <svg
        ref={ref}
        width={config.dimension}
        height={config.dimension}
        viewBox={`0 0 ${config.dimension} ${config.dimension}`}
        className="-rotate-90"
      >
        {/* Background track */}
        <circle
          cx={center}
          cy={center}
          r={radius}
          fill="none"
          stroke="rgba(255,255,255,0.06)"
          strokeWidth={config.strokeWidth}
        />
        {/* Animated progress arc */}
        <motion.circle
          cx={center}
          cy={center}
          r={radius}
          fill="none"
          stroke={strokeColor}
          strokeWidth={config.strokeWidth}
          strokeLinecap="round"
          strokeDasharray={circumference}
          style={{ strokeDashoffset }}
          initial={{ opacity: 0 }}
          animate={inView ? { opacity: 1 } : {}}
          transition={{ duration: 0.3 }}
        />
        {/* Glow effect */}
        <motion.circle
          cx={center}
          cy={center}
          r={radius}
          fill="none"
          stroke={strokeColor}
          strokeWidth={config.strokeWidth + 2}
          strokeLinecap="round"
          strokeDasharray={circumference}
          style={{ strokeDashoffset, filter: "blur(4px)", opacity: 0.3 }}
        />
      </svg>

      {/* Center label */}
      {showLabel && (
        <span
          ref={displayValue}
          className={cn(
            "absolute font-bold tabular-nums",
            config.fontSize,
            textColorClass
          )}
        >
          0%
        </span>
      )}
    </div>
  );
}
