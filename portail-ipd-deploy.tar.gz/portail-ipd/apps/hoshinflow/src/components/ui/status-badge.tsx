"use client";

import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

type Status =
  | "COMPLET"
  | "EN_COURS"
  | "EN_RETARD"
  | "EN_ATTENTE"
  | "NON_DEMARRE"
  | "ANNULE"
  | "A_RECONDUIRE";

interface StatusBadgeProps {
  status: Status;
  className?: string;
}

const statusConfig: Record<
  Status,
  { label: string; bg: string; text: string; dot: string; pulse: boolean }
> = {
  COMPLET: {
    label: "Complet",
    bg: "bg-emerald-500/10",
    text: "text-emerald-400",
    dot: "bg-emerald-400",
    pulse: false,
  },
  EN_COURS: {
    label: "En cours",
    bg: "bg-cyan-500/10",
    text: "text-cyan-400",
    dot: "bg-cyan-400",
    pulse: false,
  },
  EN_RETARD: {
    label: "En retard",
    bg: "bg-red-500/10",
    text: "text-red-400",
    dot: "bg-red-400",
    pulse: true,
  },
  EN_ATTENTE: {
    label: "En attente",
    bg: "bg-amber-500/10",
    text: "text-amber-400",
    dot: "bg-amber-400",
    pulse: false,
  },
  NON_DEMARRE: {
    label: "Non demarr\u00e9",
    bg: "bg-gray-500/10",
    text: "text-gray-400",
    dot: "bg-gray-400",
    pulse: false,
  },
  ANNULE: {
    label: "Annul\u00e9",
    bg: "bg-gray-500/10",
    text: "text-gray-500",
    dot: "bg-gray-500",
    pulse: false,
  },
  A_RECONDUIRE: {
    label: "\u00c0 reconduire",
    bg: "bg-violet-500/10",
    text: "text-violet-400",
    dot: "bg-violet-400",
    pulse: false,
  },
};

export function StatusBadge({ status, className }: StatusBadgeProps) {
  const config = statusConfig[status];

  return (
    <motion.span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-xs font-medium",
        config.bg,
        config.text,
        className
      )}
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.2 }}
    >
      <span className="relative flex h-1.5 w-1.5">
        {config.pulse && (
          <span
            className={cn(
              "absolute inline-flex h-full w-full animate-ping rounded-full opacity-75",
              config.dot
            )}
          />
        )}
        <span
          className={cn("relative inline-flex h-1.5 w-1.5 rounded-full", config.dot)}
        />
      </span>
      {config.label}
    </motion.span>
  );
}
