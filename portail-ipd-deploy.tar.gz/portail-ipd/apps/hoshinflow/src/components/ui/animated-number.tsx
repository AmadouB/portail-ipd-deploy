"use client";

import { useEffect, useRef } from "react";
import { useInView, useMotionValue, useSpring, motion } from "framer-motion";
import { cn } from "@/lib/utils";

type NumberFormat = "percent" | "number" | "currency";

interface AnimatedNumberProps {
  value: number;
  format?: NumberFormat;
  prefix?: string;
  suffix?: string;
  decimals?: number;
  duration?: number;
  colorByValue?: boolean;
  className?: string;
}

function getColorClass(value: number): string {
  if (value >= 80) return "text-emerald-400";
  if (value >= 50) return "text-cyan-400";
  if (value >= 20) return "text-amber-400";
  return "text-red-400";
}

function formatValue(
  raw: number,
  format: NumberFormat,
  decimals: number
): string {
  const fixed = raw.toFixed(decimals);
  switch (format) {
    case "percent":
      return `${fixed}%`;
    case "currency":
      return new Intl.NumberFormat("fr-FR", {
        style: "currency",
        currency: "EUR",
        minimumFractionDigits: decimals,
        maximumFractionDigits: decimals,
      }).format(raw);
    case "number":
    default:
      return new Intl.NumberFormat("fr-FR", {
        minimumFractionDigits: decimals,
        maximumFractionDigits: decimals,
      }).format(raw);
  }
}

export function AnimatedNumber({
  value,
  format = "number",
  prefix = "",
  suffix = "",
  decimals = 0,
  duration = 1.2,
  colorByValue = false,
  className,
}: AnimatedNumberProps) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true, margin: "-40px" });

  const motionValue = useMotionValue(0);
  const springValue = useSpring(motionValue, {
    duration: duration * 1000,
    bounce: 0,
  });

  useEffect(() => {
    if (inView) {
      motionValue.set(value);
    }
  }, [inView, value, motionValue]);

  useEffect(() => {
    const unsubscribe = springValue.on("change", (latest) => {
      if (ref.current) {
        ref.current.textContent = `${prefix}${formatValue(latest, format, decimals)}${suffix}`;
      }
    });
    return unsubscribe;
  }, [springValue, format, decimals, prefix, suffix]);

  return (
    <motion.span
      ref={ref}
      className={cn(
        "tabular-nums font-semibold",
        colorByValue && getColorClass(value),
        className
      )}
      initial={{ opacity: 0, y: 8 }}
      animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.4, ease: "easeOut" }}
    >
      {`${prefix}${formatValue(0, format, decimals)}${suffix}`}
    </motion.span>
  );
}
