"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { Target, Layers } from "lucide-react";
import { GlassPanel } from "@/components/ui/glass-panel";
import { ProgressRing } from "@/components/ui/progress-ring";
import { cn } from "@/lib/utils";

interface AxeCardProps {
  slug: string;
  code: string;
  nom: string;
  couleur: string;
  tauxCompletion: number;
  objectifsCount: number;
  strategiesCount: number;
  index?: number;
}

const colorToAccent: Record<string, "cyan" | "emerald" | "amber" | "red" | "violet"> = {
  "#06b6d4": "cyan",
  "#10b981": "emerald",
  "#f59e0b": "amber",
  "#ef4444": "red",
  "#8b5cf6": "violet",
};

export function AxeCard({
  slug,
  code,
  nom,
  couleur,
  tauxCompletion,
  objectifsCount,
  strategiesCount,
  index = 0,
}: AxeCardProps) {
  const accent = colorToAccent[couleur] ?? "cyan";

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: index * 0.08, ease: "easeOut" }}
    >
      <Link href={`/axes/${slug}`} className="block group">
        <GlassPanel
          variant="glow"
          accentColor={accent}
          accentPosition="left"
          hover
          className="p-5 h-full"
        >
          {/* Colored glow dot */}
          <div
            className="absolute top-4 right-4 h-2 w-2 rounded-full opacity-60 group-hover:opacity-100 transition-opacity"
            style={{ backgroundColor: couleur, boxShadow: `0 0 8px ${couleur}` }}
          />

          <div className="flex items-start gap-4">
            {/* Progress Ring */}
            <ProgressRing value={tauxCompletion} size="md" />

            {/* Content */}
            <div className="flex-1 min-w-0">
              {/* Code badge */}
              <span
                className="inline-block text-[10px] font-mono font-bold tracking-wider uppercase px-2 py-0.5 rounded mb-2"
                style={{
                  color: couleur,
                  backgroundColor: `${couleur}15`,
                  border: `1px solid ${couleur}30`,
                }}
              >
                {code}
              </span>

              {/* Name */}
              <h3 className="text-white/90 font-semibold text-base leading-tight mb-3 group-hover:text-white transition-colors">
                {nom}
              </h3>

              {/* Stats */}
              <div className="flex items-center gap-4 text-xs text-white/40">
                <span className="flex items-center gap-1.5">
                  <Target className="h-3.5 w-3.5" style={{ color: couleur }} />
                  {objectifsCount} objectif{objectifsCount > 1 ? "s" : ""}
                </span>
                <span className="flex items-center gap-1.5">
                  <Layers className="h-3.5 w-3.5" style={{ color: couleur }} />
                  {strategiesCount} stratégie{strategiesCount > 1 ? "s" : ""}
                </span>
              </div>
            </div>
          </div>
        </GlassPanel>
      </Link>
    </motion.div>
  );
}
