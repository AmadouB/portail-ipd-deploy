"use client";

import { useMemo } from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from "recharts";
import { motion } from "framer-motion";

interface DeptBudget {
  code: string;
  nom: string;
  alloue: number;
  depense: number;
}

interface BudgetChartProps {
  data: DeptBudget[];
}

function formatMontant(value: number): string {
  if (value >= 1_000_000) {
    return `${(value / 1_000_000).toFixed(1)}M`;
  }
  if (value >= 1_000) {
    return `${(value / 1_000).toFixed(0)}K`;
  }
  return value.toString();
}

function CustomTooltip({
  active,
  payload,
  label,
}: {
  active?: boolean;
  payload?: Array<{ value: number; name: string; color: string }>;
  label?: string;
}) {
  if (!active || !payload || payload.length === 0) return null;

  return (
    <div className="bg-[#0f1629]/95 backdrop-blur-xl border border-white/10 rounded-lg px-4 py-3 shadow-2xl">
      <p className="text-sm font-semibold text-white/90 mb-2">{label}</p>
      {payload.map((entry, index) => (
        <div key={index} className="flex items-center gap-2 text-xs mb-1">
          <div
            className="w-2.5 h-2.5 rounded-full"
            style={{ backgroundColor: entry.color }}
          />
          <span className="text-white/60">{entry.name} :</span>
          <span className="text-white/90 font-medium">
            {entry.value.toLocaleString("fr-FR")} FCFA
          </span>
        </div>
      ))}
      {payload.length >= 2 && (
        <div className="border-t border-white/10 mt-2 pt-2">
          <div className="flex items-center gap-2 text-xs">
            <span className="text-white/50">Taux :</span>
            <span className="font-semibold text-cyan-400">
              {payload[0].value > 0
                ? Math.round((payload[1].value / payload[0].value) * 100)
                : 0}
              %
            </span>
          </div>
        </div>
      )}
    </div>
  );
}

export function BudgetChart({ data }: BudgetChartProps) {
  const chartData = useMemo(
    () =>
      data.map((d) => ({
        name: d.code,
        fullName: `${d.code} - ${d.nom}`,
        Alloue: d.alloue,
        Depense: d.depense,
      })),
    [data]
  );

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.2 }}
      className="w-full h-[400px]"
    >
      <ResponsiveContainer width="100%" height="100%">
        <BarChart
          data={chartData}
          layout="vertical"
          margin={{ top: 10, right: 30, left: 60, bottom: 10 }}
          barGap={2}
          barCategoryGap="20%"
        >
          <CartesianGrid
            strokeDasharray="3 3"
            stroke="rgba(255,255,255,0.04)"
            horizontal={false}
          />
          <XAxis
            type="number"
            tick={{ fill: "rgba(255,255,255,0.3)", fontSize: 11 }}
            axisLine={{ stroke: "rgba(255,255,255,0.08)" }}
            tickLine={false}
            tickFormatter={formatMontant}
          />
          <YAxis
            type="category"
            dataKey="name"
            tick={{ fill: "rgba(255,255,255,0.5)", fontSize: 11 }}
            axisLine={{ stroke: "rgba(255,255,255,0.08)" }}
            tickLine={false}
            width={50}
          />
          <Tooltip
            content={<CustomTooltip />}
            cursor={{ fill: "rgba(255,255,255,0.03)" }}
          />
          <Bar
            dataKey="Alloue"
            name="Alloue"
            fill="#06b6d4"
            radius={[0, 4, 4, 0]}
            animationDuration={1200}
            animationBegin={300}
          />
          <Bar
            dataKey="Depense"
            name="Depense"
            fill="#10b981"
            radius={[0, 4, 4, 0]}
            animationDuration={1200}
            animationBegin={500}
          />
        </BarChart>
      </ResponsiveContainer>
    </motion.div>
  );
}
