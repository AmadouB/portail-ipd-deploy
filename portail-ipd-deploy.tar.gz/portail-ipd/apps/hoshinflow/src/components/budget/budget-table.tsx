"use client";

import { useState, useMemo } from "react";
import { motion } from "framer-motion";
import { ArrowUpDown, ArrowUp, ArrowDown } from "lucide-react";
import { cn, formatBudget, getProgressBarColor } from "@/lib/utils";

interface DeptBudgetRow {
  code: string;
  nom: string;
  couleur: string;
  alloue: number;
  depense: number;
  restant: number;
  taux: number;
}

interface BudgetTableProps {
  data: DeptBudgetRow[];
}

type SortKey = "code" | "nom" | "alloue" | "depense" | "restant" | "taux";
type SortDir = "asc" | "desc";

export function BudgetTable({ data }: BudgetTableProps) {
  const [sortKey, setSortKey] = useState<SortKey>("code");
  const [sortDir, setSortDir] = useState<SortDir>("asc");

  const handleSort = (key: SortKey) => {
    if (sortKey === key) {
      setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    } else {
      setSortKey(key);
      setSortDir("asc");
    }
  };

  const sortedData = useMemo(() => {
    const sorted = [...data].sort((a, b) => {
      const aVal = a[sortKey];
      const bVal = b[sortKey];
      if (typeof aVal === "string" && typeof bVal === "string") {
        return sortDir === "asc"
          ? aVal.localeCompare(bVal)
          : bVal.localeCompare(aVal);
      }
      if (typeof aVal === "number" && typeof bVal === "number") {
        return sortDir === "asc" ? aVal - bVal : bVal - aVal;
      }
      return 0;
    });
    return sorted;
  }, [data, sortKey, sortDir]);

  const totals = useMemo(() => {
    const alloue = data.reduce((s, d) => s + d.alloue, 0);
    const depense = data.reduce((s, d) => s + d.depense, 0);
    return {
      alloue,
      depense,
      restant: alloue - depense,
      taux: alloue > 0 ? Math.round((depense / alloue) * 100 * 10) / 10 : 0,
    };
  }, [data]);

  const SortIcon = ({ column }: { column: SortKey }) => {
    if (sortKey !== column) {
      return <ArrowUpDown size={12} className="text-white/20" />;
    }
    return sortDir === "asc" ? (
      <ArrowUp size={12} className="text-cyan-400" />
    ) : (
      <ArrowDown size={12} className="text-cyan-400" />
    );
  };

  const columns: { key: SortKey; label: string; align: string }[] = [
    { key: "code", label: "Code", align: "text-left" },
    { key: "nom", label: "Departement", align: "text-left" },
    { key: "alloue", label: "Alloue", align: "text-right" },
    { key: "depense", label: "Depense", align: "text-right" },
    { key: "restant", label: "Restant", align: "text-right" },
    { key: "taux", label: "Taux (%)", align: "text-center" },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.3 }}
      className="overflow-x-auto"
    >
      <table className="w-full border-collapse min-w-[700px]">
        <thead>
          <tr className="border-b border-white/[0.08]">
            {columns.map((col) => (
              <th
                key={col.key}
                onClick={() => handleSort(col.key)}
                className={cn(
                  "px-4 py-3 text-xs font-medium text-foreground-secondary uppercase tracking-wider cursor-pointer hover:text-foreground transition-colors select-none",
                  col.align
                )}
              >
                <div
                  className={cn(
                    "flex items-center gap-1",
                    col.align === "text-right" && "justify-end",
                    col.align === "text-center" && "justify-center"
                  )}
                >
                  {col.label}
                  <SortIcon column={col.key} />
                </div>
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {sortedData.map((row, index) => {
            const tauxColor =
              row.taux >= 80
                ? "text-emerald-400"
                : row.taux >= 50
                  ? "text-cyan-400"
                  : row.taux >= 20
                    ? "text-amber-400"
                    : "text-red-400";

            return (
              <motion.tr
                key={row.code}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.03 }}
                className="border-b border-white/[0.04] hover:bg-white/[0.03] transition-colors"
              >
                <td className="px-4 py-3">
                  <span
                    className="inline-flex items-center justify-center px-2 py-0.5 rounded text-xs font-bold"
                    style={{
                      backgroundColor: `${row.couleur}20`,
                      color: row.couleur,
                    }}
                  >
                    {row.code}
                  </span>
                </td>
                <td className="px-4 py-3 text-sm text-foreground/80">
                  {row.nom}
                </td>
                <td className="px-4 py-3 text-sm text-right font-mono text-cyan-400/80">
                  {formatBudget(row.alloue)}
                </td>
                <td className="px-4 py-3 text-sm text-right font-mono text-emerald-400/80">
                  {formatBudget(row.depense)}
                </td>
                <td className="px-4 py-3 text-sm text-right font-mono text-foreground-secondary">
                  {formatBudget(row.restant)}
                </td>
                <td className="px-4 py-3">
                  <div className="flex flex-col items-center gap-1">
                    <span className={cn("text-sm font-semibold", tauxColor)}>
                      {row.taux}%
                    </span>
                    <div className="w-full h-1.5 rounded-full bg-white/[0.06] overflow-hidden max-w-[80px]">
                      <motion.div
                        className={cn(
                          "h-full rounded-full",
                          getProgressBarColor(row.taux)
                        )}
                        initial={{ width: 0 }}
                        animate={{ width: `${Math.min(row.taux, 100)}%` }}
                        transition={{
                          duration: 1,
                          delay: 0.5 + index * 0.05,
                          ease: "easeOut",
                        }}
                      />
                    </div>
                  </div>
                </td>
              </motion.tr>
            );
          })}
        </tbody>
        <tfoot>
          <tr className="border-t-2 border-white/[0.12] bg-white/[0.02]">
            <td className="px-4 py-3 text-sm font-bold text-foreground" colSpan={2}>
              Total
            </td>
            <td className="px-4 py-3 text-sm text-right font-mono font-bold text-cyan-400">
              {formatBudget(totals.alloue)}
            </td>
            <td className="px-4 py-3 text-sm text-right font-mono font-bold text-emerald-400">
              {formatBudget(totals.depense)}
            </td>
            <td className="px-4 py-3 text-sm text-right font-mono font-bold text-foreground-secondary">
              {formatBudget(totals.restant)}
            </td>
            <td className="px-4 py-3">
              <div className="flex flex-col items-center gap-1">
                <span
                  className={cn(
                    "text-sm font-bold",
                    totals.taux >= 80
                      ? "text-emerald-400"
                      : totals.taux >= 50
                        ? "text-cyan-400"
                        : totals.taux >= 20
                          ? "text-amber-400"
                          : "text-red-400"
                  )}
                >
                  {totals.taux}%
                </span>
                <div className="w-full h-1.5 rounded-full bg-white/[0.06] overflow-hidden max-w-[80px]">
                  <motion.div
                    className={cn(
                      "h-full rounded-full",
                      getProgressBarColor(totals.taux)
                    )}
                    initial={{ width: 0 }}
                    animate={{
                      width: `${Math.min(totals.taux, 100)}%`,
                    }}
                    transition={{ duration: 1.2, delay: 0.8, ease: "easeOut" }}
                  />
                </div>
              </div>
            </td>
          </tr>
        </tfoot>
      </table>
    </motion.div>
  );
}
