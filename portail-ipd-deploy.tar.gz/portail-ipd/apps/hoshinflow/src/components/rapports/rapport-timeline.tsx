"use client";

import { useMemo } from "react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { GlassPanel } from "@/components/ui/glass-panel";
import type { Rapport } from "@/app/(platform)/rapports/rapports-client";

interface DepartementOption {
  id: string;
  code: string;
  nom: string;
  couleur: string;
}

interface RapportTimelineProps {
  rapports: Rapport[];
  departements: DepartementOption[];
  onCellClick: (rapportId: string) => void;
}

function getCurrentISOWeek(): string {
  const now = new Date();
  const yearStart = new Date(now.getFullYear(), 0, 1);
  const weekNo = Math.ceil(
    ((now.getTime() - yearStart.getTime()) / 86400000 + yearStart.getDay() + 1) / 7
  );
  return `${now.getFullYear()}-W${String(weekNo).padStart(2, "0")}`;
}

function offsetWeek(isoWeek: string, offset: number): string {
  const [year, week] = isoWeek.split("-W").map(Number);
  const jan1 = new Date(year, 0, 1);
  const dayOfWeek = jan1.getDay() || 7;
  const start = new Date(jan1);
  start.setDate(jan1.getDate() + (week - 1) * 7 - dayOfWeek + 1);
  start.setDate(start.getDate() + offset * 7);
  const newYearStart = new Date(start.getFullYear(), 0, 1);
  const weekNo = Math.ceil(
    ((start.getTime() - newYearStart.getTime()) / 86400000 + newYearStart.getDay() + 1) / 7
  );
  return `${start.getFullYear()}-W${String(weekNo).padStart(2, "0")}`;
}

function getWeekLabel(isoWeek: string): string {
  const parts = isoWeek.split("-W");
  return `S${parts[1]}`;
}

export function RapportTimeline({
  rapports,
  departements,
  onCellClick,
}: RapportTimelineProps) {
  // Generate last 12 weeks (current week first visually on the right)
  const weeks = useMemo(() => {
    const current = getCurrentISOWeek();
    const result: string[] = [];
    for (let i = 11; i >= 0; i--) {
      result.push(offsetWeek(current, -i));
    }
    return result;
  }, []);

  // Sort departments by code
  const sortedDepts = useMemo(
    () => [...departements].sort((a, b) => a.code.localeCompare(b.code)),
    [departements]
  );

  // Build lookup map: `${deptId}-${semaine}` -> rapport
  const rapportMap = useMemo(() => {
    const map = new Map<string, Rapport>();
    for (const r of rapports) {
      map.set(`${r.departementId}-${r.semaine}`, r);
    }
    return map;
  }, [rapports]);

  function getCellColor(rapport: Rapport | undefined): string {
    if (!rapport) return "rgba(239,68,68,0.2)";
    if (rapport.statut === "VALIDE" || rapport.statut === "SOUMIS")
      return "rgba(16,185,129,0.5)";
    if (rapport.statut === "BROUILLON") return "rgba(245,158,11,0.4)";
    return "rgba(239,68,68,0.2)";
  }

  function getCellBorder(rapport: Rapport | undefined): string {
    if (!rapport) return "rgba(239,68,68,0.15)";
    if (rapport.statut === "VALIDE" || rapport.statut === "SOUMIS")
      return "rgba(16,185,129,0.3)";
    if (rapport.statut === "BROUILLON") return "rgba(245,158,11,0.25)";
    return "rgba(239,68,68,0.15)";
  }

  return (
    <GlassPanel className="p-5">
      <h3 className="text-sm font-semibold text-white/80 mb-4">
        Heatmap — Rapports par département
      </h3>

      <div className="overflow-x-auto">
        <table className="w-full border-collapse">
          <thead>
            <tr>
              <th className="px-3 py-2 text-left text-[10px] font-medium text-white/40 uppercase tracking-wider w-[100px] sticky left-0 bg-[#0d1117]/80 backdrop-blur-sm z-10">
                Dept
              </th>
              {weeks.map((w) => (
                <th
                  key={w}
                  className="px-1 py-2 text-center text-[10px] font-medium text-white/40 uppercase tracking-wider min-w-[50px]"
                >
                  {getWeekLabel(w)}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {sortedDepts.map((dept, deptIdx) => (
              <motion.tr
                key={dept.id}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: deptIdx * 0.02 }}
                className="border-b border-white/[0.04]"
              >
                <td className="px-3 py-1.5 sticky left-0 bg-[#0d1117]/80 backdrop-blur-sm z-10">
                  <span
                    className="inline-flex px-1.5 py-0.5 rounded text-[10px] font-bold border"
                    style={{
                      backgroundColor: `${dept.couleur}15`,
                      borderColor: `${dept.couleur}30`,
                      color: dept.couleur,
                    }}
                  >
                    {dept.code}
                  </span>
                </td>
                {weeks.map((w) => {
                  const rapport = rapportMap.get(`${dept.id}-${w}`);
                  return (
                    <td key={w} className="px-1 py-1.5 text-center">
                      <button
                        onClick={() => rapport && onCellClick(rapport.id)}
                        disabled={!rapport}
                        className={cn(
                          "w-8 h-8 rounded-md mx-auto transition-all duration-200",
                          rapport
                            ? "cursor-pointer hover:scale-110 hover:shadow-lg"
                            : "cursor-default"
                        )}
                        style={{
                          backgroundColor: getCellColor(rapport),
                          border: `1px solid ${getCellBorder(rapport)}`,
                        }}
                        title={
                          rapport
                            ? `${dept.code} — ${w} — ${rapport.statut}`
                            : `${dept.code} — ${w} — Manquant`
                        }
                      />
                    </td>
                  );
                })}
              </motion.tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Legend */}
      <div className="flex items-center gap-4 mt-4 pt-3 border-t border-white/[0.06]">
        <span className="text-[10px] text-white/30 uppercase tracking-wider">
          Légende
        </span>
        {[
          { color: "rgba(16,185,129,0.5)", border: "rgba(16,185,129,0.3)", label: "Soumis / Validé" },
          { color: "rgba(245,158,11,0.4)", border: "rgba(245,158,11,0.25)", label: "Brouillon" },
          { color: "rgba(239,68,68,0.2)", border: "rgba(239,68,68,0.15)", label: "Manquant" },
        ].map((item) => (
          <div key={item.label} className="flex items-center gap-1.5">
            <div
              className="w-3 h-3 rounded-sm"
              style={{
                backgroundColor: item.color,
                border: `1px solid ${item.border}`,
              }}
            />
            <span className="text-[10px] text-white/50">{item.label}</span>
          </div>
        ))}
      </div>
    </GlassPanel>
  );
}
