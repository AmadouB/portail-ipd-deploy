"use client";

import { motion } from "framer-motion";
import { CheckCircle2, Clock, User, Calendar } from "lucide-react";
import { cn, getStatutColor, getStatutLabel } from "@/lib/utils";
import { GlassPanel } from "@/components/ui/glass-panel";
import { ModalButton } from "@/components/ui/modal";
import type { Rapport } from "@/app/(platform)/rapports/rapports-client";

interface RapportDetailProps {
  rapport: Rapport;
  isAdmin: boolean;
  onValidate: () => void;
}

function getStatutBadge(statut: string) {
  const styles: Record<string, string> = {
    BROUILLON: "bg-amber-500/15 text-amber-400 border-amber-500/30",
    SOUMIS: "bg-cyan-500/15 text-cyan-400 border-cyan-500/30",
    VALIDE: "bg-emerald-500/15 text-emerald-400 border-emerald-500/30",
  };
  return (
    <span
      className={cn(
        "inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium border",
        styles[statut] ?? "bg-white/[0.06] text-white/40 border-white/[0.1]"
      )}
    >
      {statut === "VALIDE" && <CheckCircle2 size={12} className="mr-1" />}
      {statut === "BROUILLON" && <Clock size={12} className="mr-1" />}
      {statut}
    </span>
  );
}

export function RapportDetail({
  rapport,
  isAdmin,
  onValidate,
}: RapportDetailProps) {
  return (
    <div className="space-y-5">
      {/* Header info */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          {rapport.departementNom && (
            <span className="text-sm font-medium text-white/70">
              {rapport.departementCode} — {rapport.departementNom}
            </span>
          )}
          {getStatutBadge(rapport.statut)}
        </div>
      </div>

      {/* Meta */}
      {(rapport.soumisParNom || rapport.soumisLe) && (
        <div className="flex items-center gap-4 text-xs text-white/40">
          {rapport.soumisParNom && (
            <div className="flex items-center gap-1.5">
              <User size={12} />
              <span>{rapport.soumisParNom}</span>
            </div>
          )}
          {rapport.soumisLe && (
            <div className="flex items-center gap-1.5">
              <Calendar size={12} />
              <span>
                {new Date(rapport.soumisLe).toLocaleDateString("fr-FR", {
                  day: "numeric",
                  month: "short",
                  year: "numeric",
                })}
              </span>
            </div>
          )}
        </div>
      )}

      {/* Lignes */}
      {rapport.lignes.length > 0 && (
        <div className="space-y-2">
          <h4 className="text-xs font-medium text-white/50 uppercase tracking-wider">
            Projets
          </h4>
          {rapport.lignes.map((ligne, i) => (
            <motion.div
              key={ligne.id}
              initial={{ opacity: 0, x: -8 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.04 }}
              className="p-3 rounded-lg bg-white/[0.02] border border-white/[0.06]"
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-white/70 font-medium">
                  {ligne.projetLibelle}
                </span>
                <div className="flex items-center gap-2">
                  <span
                    className={cn(
                      "inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full text-[9px] font-medium"
                    )}
                    style={{
                      backgroundColor: `${getStatutColor(ligne.statut)}15`,
                      color: getStatutColor(ligne.statut),
                    }}
                  >
                    <span
                      className="w-1 h-1 rounded-full"
                      style={{ backgroundColor: getStatutColor(ligne.statut) }}
                    />
                    {getStatutLabel(ligne.statut)}
                  </span>
                </div>
              </div>

              {/* Avancement bar */}
              <div className="flex items-center gap-3">
                <div className="flex-1 h-1.5 rounded-full bg-white/[0.06] overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${ligne.avancement}%` }}
                    transition={{ duration: 0.6, ease: "easeOut" }}
                    className="h-full rounded-full"
                    style={{
                      backgroundColor:
                        ligne.avancement >= 80
                          ? "#10b981"
                          : ligne.avancement >= 50
                            ? "#06b6d4"
                            : ligne.avancement >= 20
                              ? "#f59e0b"
                              : "#ef4444",
                    }}
                  />
                </div>
                <span className="text-xs text-white/60 tabular-nums w-10 text-right">
                  {ligne.avancement}%
                </span>
              </div>

              {ligne.commentaire && (
                <p className="text-xs text-white/40 mt-2 italic">
                  {ligne.commentaire}
                </p>
              )}
            </motion.div>
          ))}
        </div>
      )}

      {/* Synthèse sections */}
      {rapport.faitsMarquants && (
        <div>
          <h4 className="text-xs font-medium text-white/50 uppercase tracking-wider mb-1.5">
            Faits marquants
          </h4>
          <p className="text-sm text-white/70 whitespace-pre-line leading-relaxed">
            {rapport.faitsMarquants}
          </p>
        </div>
      )}

      {rapport.difficultes && (
        <div>
          <h4 className="text-xs font-medium text-white/50 uppercase tracking-wider mb-1.5">
            Difficultés / Blocages
          </h4>
          <p className="text-sm text-white/70 whitespace-pre-line leading-relaxed">
            {rapport.difficultes}
          </p>
        </div>
      )}

      {rapport.prochainesEtapes && (
        <div>
          <h4 className="text-xs font-medium text-white/50 uppercase tracking-wider mb-1.5">
            Prochaines étapes
          </h4>
          <p className="text-sm text-white/70 whitespace-pre-line leading-relaxed">
            {rapport.prochainesEtapes}
          </p>
        </div>
      )}

      {/* Validate button (ADMIN only) */}
      {isAdmin && rapport.statut === "SOUMIS" && (
        <div className="flex justify-end pt-2 border-t border-white/[0.06]">
          <button
            onClick={onValidate}
            className="flex items-center gap-2 px-5 py-2.5 rounded-lg text-sm font-medium bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 hover:bg-emerald-500/25 transition-all"
          >
            <CheckCircle2 size={16} />
            Valider le rapport
          </button>
        </div>
      )}
    </div>
  );
}
