"use client";

import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Plus, Save, Send, Trash2 } from "lucide-react";
import { cn, getStatutBadgeClasses, getStatutLabel } from "@/lib/utils";
import { GlassPanel } from "@/components/ui/glass-panel";
import {
  FormField,
  FormInput,
  FormTextarea,
  FormSelect,
  ModalButton,
} from "@/components/ui/modal";
import type { Rapport, RapportLigne } from "@/app/(platform)/rapports/rapports-client";

interface ProjetOption {
  id: string;
  libelle: string;
  code: string;
}

interface LigneFormData {
  projetId: string;
  projetLibelle: string;
  avancement: number;
  statut: string;
  commentaire: string;
  isNewProjet: boolean;
}

interface RapportFormProps {
  rapport: Rapport | null;
  departementId: string;
  semaine: string;
  onSaved: () => void;
}

const STATUTS_PROJET = [
  { value: "EN_COURS", label: "En cours" },
  { value: "EN_RETARD", label: "En retard" },
  { value: "COMPLET", label: "Complet" },
  { value: "EN_ATTENTE", label: "En attente" },
  { value: "NON_DEMARRE", label: "Non démarré" },
];

export function RapportForm({
  rapport,
  departementId,
  semaine,
  onSaved,
}: RapportFormProps) {
  const [projets, setProjets] = useState<ProjetOption[]>([]);
  const [lignes, setLignes] = useState<LigneFormData[]>([]);
  const [faitsMarquants, setFaitsMarquants] = useState(
    rapport?.faitsMarquants ?? ""
  );
  const [difficultes, setDifficultes] = useState(rapport?.difficultes ?? "");
  const [prochainesEtapes, setProchainesEtapes] = useState(
    rapport?.prochainesEtapes ?? ""
  );
  const [saving, setSaving] = useState(false);

  // Fetch projets for the department
  useEffect(() => {
    fetch(`/api/projets?departementId=${departementId}`)
      .then((r) => r.json())
      .then((data) => {
        const opts: ProjetOption[] = (data ?? []).map(
          (p: { id: string; libelle: string; code: string }) => ({
            id: p.id,
            libelle: p.libelle,
            code: p.code,
          })
        );
        setProjets(opts);

        // If editing, pre-fill from existing lignes
        if (rapport?.lignes?.length) {
          setLignes(
            rapport.lignes.map((l) => ({
              projetId: l.projetId,
              projetLibelle: l.projetLibelle,
              avancement: l.avancement,
              statut: l.statut,
              commentaire: l.commentaire,
              isNewProjet: l.isNewProjet ?? false,
            }))
          );
        } else {
          // Initialize with all department projects
          setLignes(
            opts.map((p) => ({
              projetId: p.id,
              projetLibelle: p.libelle,
              avancement: 0,
              statut: "EN_COURS",
              commentaire: "",
              isNewProjet: false,
            }))
          );
        }
      })
      .catch(() => {});
  }, [departementId, rapport]);

  function updateLigne(index: number, patch: Partial<LigneFormData>) {
    setLignes((prev) =>
      prev.map((l, i) => (i === index ? { ...l, ...patch } : l))
    );
  }

  function addNewProjet() {
    setLignes((prev) => [
      ...prev,
      {
        projetId: "",
        projetLibelle: "",
        avancement: 0,
        statut: "NON_DEMARRE",
        commentaire: "",
        isNewProjet: true,
      },
    ]);
  }

  function removeLigne(index: number) {
    setLignes((prev) => prev.filter((_, i) => i !== index));
  }

  async function handleSave(submit: boolean) {
    setSaving(true);
    try {
      const body = {
        departementId,
        semaine,
        faitsMarquants,
        difficultes,
        prochainesEtapes,
        lignes: lignes.map((l) => ({
          projetId: l.projetId || undefined,
          projetLibelle: l.projetLibelle,
          avancement: l.avancement,
          statut: l.statut,
          commentaire: l.commentaire,
          isNewProjet: l.isNewProjet,
        })),
      };

      const url = rapport ? `/api/rapports/${rapport.id}` : "/api/rapports";
      const method = rapport ? "PUT" : "POST";

      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });

      if (res.ok && submit) {
        const data = await res.json();
        const rapportId = data.id ?? rapport?.id;
        if (rapportId) {
          await fetch(`/api/rapports/${rapportId}/soumettre`, {
            method: "POST",
          });
        }
      }

      onSaved();
    } catch {
      // Error handling could be added here
    } finally {
      setSaving(false);
    }
  }

  const statutBadge = rapport?.statut ? (
    <span
      className={cn(
        "inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-medium border",
        rapport.statut === "BROUILLON"
          ? "bg-amber-500/15 text-amber-400 border-amber-500/30"
          : rapport.statut === "SOUMIS"
            ? "bg-cyan-500/15 text-cyan-400 border-cyan-500/30"
            : "bg-emerald-500/15 text-emerald-400 border-emerald-500/30"
      )}
    >
      {rapport.statut}
    </span>
  ) : (
    <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-medium border bg-white/[0.06] text-white/40 border-white/[0.1]">
      NOUVEAU
    </span>
  );

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.2 }}
      className="space-y-5"
    >
      {/* Header */}
      <GlassPanel className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="text-sm font-medium text-white/70">
              Semaine {semaine}
            </span>
            {statutBadge}
          </div>
        </div>
      </GlassPanel>

      {/* Section Projets */}
      <GlassPanel className="p-5">
        <h3 className="text-sm font-semibold text-white/80 mb-4">Projets</h3>
        <div className="space-y-3">
          {lignes.map((ligne, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.03 }}
              className="p-4 rounded-lg bg-white/[0.02] border border-white/[0.06] space-y-3"
            >
              <div className="flex items-center justify-between">
                {ligne.isNewProjet ? (
                  <input
                    type="text"
                    value={ligne.projetLibelle}
                    onChange={(e) =>
                      updateLigne(index, { projetLibelle: e.target.value })
                    }
                    placeholder="Nom du nouveau projet..."
                    className="flex-1 h-8 px-3 rounded-md text-sm bg-white/[0.04] border border-cyan-500/20 text-white/90 placeholder:text-white/25 focus:outline-none focus:border-cyan-500/40 transition-all"
                  />
                ) : (
                  <span className="text-sm font-medium text-white/70">
                    {ligne.projetLibelle}
                  </span>
                )}
                {ligne.isNewProjet && (
                  <button
                    onClick={() => removeLigne(index)}
                    className="p-1 ml-2 rounded text-white/30 hover:text-red-400 hover:bg-red-500/10 transition-all"
                  >
                    <Trash2 size={14} />
                  </button>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                {/* Avancement slider */}
                <div className="space-y-1.5">
                  <label className="block text-xs font-medium text-white/40">
                    Avancement
                  </label>
                  <div className="flex items-center gap-3">
                    <input
                      type="range"
                      min={0}
                      max={100}
                      value={ligne.avancement}
                      onChange={(e) =>
                        updateLigne(index, {
                          avancement: Number(e.target.value),
                        })
                      }
                      className="flex-1 h-1.5 rounded-full appearance-none bg-white/[0.08] accent-cyan-500 cursor-pointer"
                    />
                    <span className="text-xs font-medium text-cyan-400 tabular-nums w-10 text-right">
                      {ligne.avancement}%
                    </span>
                  </div>
                </div>

                {/* Statut */}
                <div className="space-y-1.5">
                  <label className="block text-xs font-medium text-white/40">
                    Statut
                  </label>
                  <select
                    value={ligne.statut}
                    onChange={(e) =>
                      updateLigne(index, { statut: e.target.value })
                    }
                    className="w-full h-8 px-2 rounded-md text-xs appearance-none bg-white/[0.04] border border-white/[0.1] text-white/70 focus:outline-none focus:border-cyan-500/40 transition-all"
                  >
                    {STATUTS_PROJET.map((s) => (
                      <option key={s.value} value={s.value}>
                        {s.label}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Commentaire */}
                <div className="space-y-1.5">
                  <label className="block text-xs font-medium text-white/40">
                    Commentaire
                  </label>
                  <input
                    type="text"
                    value={ligne.commentaire}
                    onChange={(e) =>
                      updateLigne(index, { commentaire: e.target.value })
                    }
                    placeholder="Note..."
                    className="w-full h-8 px-2 rounded-md text-xs bg-white/[0.04] border border-white/[0.1] text-white/90 placeholder:text-white/25 focus:outline-none focus:border-cyan-500/40 transition-all"
                  />
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Add new project button */}
        <button
          onClick={addNewProjet}
          className="flex items-center gap-2 mt-3 px-4 py-2 rounded-lg text-xs font-medium text-cyan-400 bg-cyan-500/10 border border-cyan-500/20 hover:bg-cyan-500/20 transition-all"
        >
          <Plus size={14} />
          Déclarer un nouveau projet
        </button>
      </GlassPanel>

      {/* Section Synthèse */}
      <GlassPanel className="p-5 space-y-4">
        <h3 className="text-sm font-semibold text-white/80">Synthèse</h3>

        <FormField label="Faits marquants">
          <FormTextarea
            value={faitsMarquants}
            onChange={(e) => setFaitsMarquants(e.target.value)}
            placeholder="Points importants de la semaine..."
            rows={3}
          />
        </FormField>

        <FormField label="Difficultés / Blocages">
          <FormTextarea
            value={difficultes}
            onChange={(e) => setDifficultes(e.target.value)}
            placeholder="Problèmes rencontrés..."
            rows={3}
          />
        </FormField>

        <FormField label="Prochaines étapes">
          <FormTextarea
            value={prochainesEtapes}
            onChange={(e) => setProchainesEtapes(e.target.value)}
            placeholder="Actions prévues pour la semaine suivante..."
            rows={3}
          />
        </FormField>
      </GlassPanel>

      {/* Footer actions */}
      <div className="flex items-center justify-end gap-3">
        <button
          onClick={() => handleSave(false)}
          disabled={saving}
          className={cn(
            "flex items-center gap-2 px-5 py-2.5 rounded-lg text-sm font-medium border transition-all duration-200",
            "bg-white/[0.04] text-white/60 border-white/[0.1] hover:bg-white/[0.08] hover:text-white/80",
            saving && "opacity-40 cursor-not-allowed"
          )}
        >
          <Save size={16} />
          Sauvegarder brouillon
        </button>
        <button
          onClick={() => handleSave(true)}
          disabled={saving}
          className={cn(
            "flex items-center gap-2 px-5 py-2.5 rounded-lg text-sm font-medium border transition-all duration-200",
            "bg-cyan-500/20 text-cyan-400 border-cyan-500/30 hover:bg-cyan-500/30 hover:border-cyan-500/40",
            saving && "opacity-40 cursor-not-allowed"
          )}
        >
          <Send size={16} />
          Soumettre
        </button>
      </div>
    </motion.div>
  );
}
