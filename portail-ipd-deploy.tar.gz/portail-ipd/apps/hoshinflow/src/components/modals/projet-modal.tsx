"use client";

import { useState, useEffect } from "react";
import {
  Modal,
  FormField,
  FormInput,
  FormTextarea,
  FormSelect,
  ModalButton,
} from "@/components/ui/modal";
import type { Projet, Statut } from "@/lib/types";

const STATUTS: { value: Statut; label: string }[] = [
  { value: "NON_DEMARRE", label: "Non démarré" },
  { value: "EN_COURS", label: "En cours" },
  { value: "EN_RETARD", label: "En retard" },
  { value: "EN_ATTENTE", label: "En attente" },
  { value: "COMPLET", label: "Complet" },
  { value: "ANNULE", label: "Annulé" },
  { value: "A_RECONDUIRE", label: "À reconduire" },
];

interface Props {
  open: boolean;
  onClose: () => void;
  projet: Projet | null;
  isNew?: boolean;
  onSave: (patch: Partial<Projet>) => void;
  onDelete?: () => void;
}

export function ProjetModal({
  open,
  onClose,
  projet,
  isNew,
  onSave,
  onDelete,
}: Props) {
  const [code, setCode] = useState("");
  const [libelle, setLibelle] = useState("");
  const [responsable, setResponsable] = useState("");
  const [statut, setStatut] = useState<Statut>("NON_DEMARRE");
  const [financeur, setFinanceur] = useState("");
  const [budgetAlloue, setBudgetAlloue] = useState("");
  const [budgetDepense, setBudgetDepense] = useState("");
  const [commentaire, setCommentaire] = useState("");

  useEffect(() => {
    if (open && projet) {
      setCode(projet.code || "");
      setLibelle(projet.libelle || "");
      setResponsable(projet.responsable || "");
      setStatut(projet.statut);
      setFinanceur(projet.financeur || "");
      setBudgetAlloue(
        projet.budgetAlloue !== null ? String(projet.budgetAlloue) : ""
      );
      setBudgetDepense(
        projet.budgetDepense !== null ? String(projet.budgetDepense) : ""
      );
      setCommentaire(projet.commentaire || "");
    }
  }, [open, projet]);

  const handleSave = () => {
    onSave({
      code,
      libelle,
      responsable: responsable || null,
      statut,
      financeur: financeur || null,
      budgetAlloue: budgetAlloue ? Number(budgetAlloue) : null,
      budgetDepense: budgetDepense ? Number(budgetDepense) : null,
      commentaire: commentaire || null,
    });
    onClose();
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={isNew ? "Nouveau Projet" : "Modifier le Projet"}
      subtitle={isNew ? "Création d'un nouveau projet" : projet?.code}
      accentColor="#06b6d4"
      size="lg"
      footer={
        <>
          {!isNew && onDelete && (
            <ModalButton variant="danger" onClick={onDelete}>
              Supprimer
            </ModalButton>
          )}
          <div className="flex-1" />
          <ModalButton variant="secondary" onClick={onClose}>
            Annuler
          </ModalButton>
          <ModalButton variant="primary" onClick={handleSave}>
            {isNew ? "Créer" : "Enregistrer"}
          </ModalButton>
        </>
      }
    >
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <FormField label="Code" required>
          <FormInput
            value={code}
            onChange={(e) => setCode(e.target.value)}
            placeholder="P-XXX"
          />
        </FormField>

        <FormField label="Statut" required>
          <FormSelect
            value={statut}
            onChange={(e) => setStatut(e.target.value as Statut)}
          >
            {STATUTS.map((s) => (
              <option key={s.value} value={s.value}>
                {s.label}
              </option>
            ))}
          </FormSelect>
        </FormField>

        <div className="md:col-span-2">
          <FormField label="Libellé" required>
            <FormTextarea
              value={libelle}
              onChange={(e) => setLibelle(e.target.value)}
              placeholder="Description du projet..."
            />
          </FormField>
        </div>

        <FormField label="Responsable">
          <FormInput
            value={responsable}
            onChange={(e) => setResponsable(e.target.value)}
            placeholder="Nom du responsable"
          />
        </FormField>

        <FormField label="Financeur">
          <FormInput
            value={financeur}
            onChange={(e) => setFinanceur(e.target.value)}
            placeholder="Source de financement"
          />
        </FormField>

        <FormField label="Budget Alloué (FCFA)">
          <FormInput
            type="number"
            value={budgetAlloue}
            onChange={(e) => setBudgetAlloue(e.target.value)}
            placeholder="0"
          />
        </FormField>

        <FormField label="Budget Dépensé (FCFA)">
          <FormInput
            type="number"
            value={budgetDepense}
            onChange={(e) => setBudgetDepense(e.target.value)}
            placeholder="0"
          />
        </FormField>

        <div className="md:col-span-2">
          <FormField label="Commentaire">
            <FormTextarea
              value={commentaire}
              onChange={(e) => setCommentaire(e.target.value)}
              placeholder="Notes ou observations..."
              rows={2}
            />
          </FormField>
        </div>
      </div>
    </Modal>
  );
}
