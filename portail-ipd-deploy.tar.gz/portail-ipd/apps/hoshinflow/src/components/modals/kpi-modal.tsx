"use client";

import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Plus, Trash2 } from "lucide-react";
import {
  Modal,
  FormField,
  FormInput,
  FormSelect,
  ModalButton,
} from "@/components/ui/modal";
import { cn, getTauxColor, calculateKpiTaux } from "@/lib/utils";
import type { KPI, MesureKPI, Trimestre } from "@/lib/types";

const MODES = [
  { value: "SOMME", label: "Somme" },
  { value: "POURCENTAGE", label: "Pourcentage" },
  { value: "MOYENNE", label: "Moyenne" },
  { value: "BINAIRE", label: "Binaire" },
];

const TRIMESTRES: Trimestre[] = ["T1", "T2", "T3", "T4"];

interface Props {
  open: boolean;
  onClose: () => void;
  kpi: KPI | null;
  isNew?: boolean;
  onSave: (patch: Partial<KPI>) => void;
  onSaveMesure: (trimestre: Trimestre, patch: Partial<MesureKPI>) => void;
  onDelete?: () => void;
}

export function KpiModal({
  open,
  onClose,
  kpi,
  isNew,
  onSave,
  onSaveMesure,
  onDelete,
}: Props) {
  const [code, setCode] = useState("");
  const [libelle, setLibelle] = useState("");
  const [modeCalcul, setModeCalcul] = useState("SOMME");
  const [unite, setUnite] = useState("");
  const [mesures, setMesures] = useState<
    { trimestre: Trimestre; cible: string; realise: string }[]
  >([]);

  useEffect(() => {
    if (open && kpi) {
      setCode(kpi.code || "");
      setLibelle(kpi.libelle || "");
      setModeCalcul(kpi.modeCalcul || "SOMME");
      setUnite(kpi.unite || "");
      setMesures(
        TRIMESTRES.map((tri) => {
          const m = kpi.mesures.find((mes) => mes.trimestre === tri);
          return {
            trimestre: tri,
            cible: m?.cible !== null && m?.cible !== undefined ? String(m.cible) : "",
            realise:
              m?.realise !== null && m?.realise !== undefined
                ? String(m.realise)
                : "",
          };
        })
      );
    }
  }, [open, kpi]);

  const handleSave = () => {
    onSave({
      code,
      libelle,
      modeCalcul,
      unite: unite || null,
    });
    // Save each mesure
    for (const mes of mesures) {
      onSaveMesure(mes.trimestre, {
        cible: mes.cible ? Number(mes.cible) : null,
        realise: mes.realise ? Number(mes.realise) : null,
        tauxCompletion:
          mes.cible && mes.realise
            ? Math.round((Number(mes.realise) / Number(mes.cible)) * 100)
            : null,
      });
    }
    onClose();
  };

  const updateMesure = (
    tri: Trimestre,
    field: "cible" | "realise",
    val: string
  ) => {
    setMesures((prev) =>
      prev.map((m) => (m.trimestre === tri ? { ...m, [field]: val } : m))
    );
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={isNew ? "Nouvel Indicateur" : "Modifier l'Indicateur"}
      subtitle={isNew ? "Ajout d'un KPI" : kpi?.code}
      accentColor="#10b981"
      size="lg"
      footer={
        <>
          {!isNew && onDelete && (
            <ModalButton variant="danger" onClick={onDelete}>
              Supprimer
            </ModalButton>
          )}
          <div className="flex-1" />
          <ModalButton variant="secondary" onClick={onClose}>
            Annuler
          </ModalButton>
          <ModalButton variant="primary" onClick={handleSave}>
            {isNew ? "Créer" : "Enregistrer"}
          </ModalButton>
        </>
      }
    >
      <div className="space-y-5">
        {/* KPI info */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FormField label="Code" required>
            <FormInput
              value={code}
              onChange={(e) => setCode(e.target.value)}
              placeholder="KPI-XXX"
            />
          </FormField>

          <FormField label="Mode de calcul">
            <FormSelect
              value={modeCalcul}
              onChange={(e) => setModeCalcul(e.target.value)}
            >
              {MODES.map((m) => (
                <option key={m.value} value={m.value}>
                  {m.label}
                </option>
              ))}
            </FormSelect>
          </FormField>

          <div className="md:col-span-2">
            <FormField label="Libellé" required>
              <FormInput
                value={libelle}
                onChange={(e) => setLibelle(e.target.value)}
                placeholder="Description de l'indicateur..."
              />
            </FormField>
          </div>

          <FormField label="Unité">
            <FormInput
              value={unite}
              onChange={(e) => setUnite(e.target.value)}
              placeholder="%, nb, FCFA..."
            />
          </FormField>
        </div>

        {/* Mesures trimestrielles */}
        <div>
          <h4 className="text-xs font-semibold text-white/60 uppercase tracking-wider mb-3">
            Mesures Trimestrielles
          </h4>
          <div className="grid grid-cols-4 gap-3">
            {mesures.map((mes) => {
              const taux =
                mes.cible && mes.realise
                  ? calculateKpiTaux(Number(mes.realise), Number(mes.cible))
                  : null;
              return (
                <div
                  key={mes.trimestre}
                  className="rounded-lg p-3 bg-white/[0.03] border border-white/[0.08] space-y-2"
                >
                  <p className="text-xs font-medium text-white/60 text-center">
                    {mes.trimestre}
                  </p>

                  <div>
                    <label className="block text-[10px] text-white/30 mb-0.5">
                      Cible
                    </label>
                    <input
                      type="number"
                      value={mes.cible}
                      onChange={(e) =>
                        updateMesure(mes.trimestre, "cible", e.target.value)
                      }
                      placeholder="—"
                      className="w-full h-8 px-2 rounded text-xs bg-white/[0.04] border border-white/[0.1] text-white/80 placeholder:text-white/20 focus:outline-none focus:border-cyan-500/40 transition-all text-center tabular-nums"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] text-white/30 mb-0.5">
                      Réalisé
                    </label>
                    <input
                      type="number"
                      value={mes.realise}
                      onChange={(e) =>
                        updateMesure(mes.trimestre, "realise", e.target.value)
                      }
                      placeholder="—"
                      className="w-full h-8 px-2 rounded text-xs bg-white/[0.04] border border-white/[0.1] text-white/80 placeholder:text-white/20 focus:outline-none focus:border-emerald-500/40 transition-all text-center tabular-nums"
                    />
                  </div>

                  {/* Taux */}
                  {taux !== null && (
                    <div className="text-center">
                      <div className="h-1 rounded-full bg-white/[0.06] overflow-hidden mt-1">
                        <div
                          className="h-full rounded-full transition-all duration-300"
                          style={{
                            width: `${Math.min(taux, 100)}%`,
                            backgroundColor: getTauxColor(taux),
                          }}
                        />
                      </div>
                      <span
                        className="text-[10px] font-bold tabular-nums"
                        style={{ color: getTauxColor(taux) }}
                      >
                        {taux}%
                      </span>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </Modal>
  );
}
