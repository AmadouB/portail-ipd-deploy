"use client";

import { useState, useEffect } from "react";
import {
  Modal,
  FormField,
  FormInput,
  FormTextarea,
  FormSelect,
  ModalButton,
} from "@/components/ui/modal";
import type { StrategieDepartementale, Statut } from "@/lib/types";

const STATUTS: { value: Statut; label: string }[] = [
  { value: "NON_DEMARRE", label: "Non démarré" },
  { value: "EN_COURS", label: "En cours" },
  { value: "EN_RETARD", label: "En retard" },
  { value: "EN_ATTENTE", label: "En attente" },
  { value: "COMPLET", label: "Complet" },
  { value: "ANNULE", label: "Annulé" },
  { value: "A_RECONDUIRE", label: "À reconduire" },
];

interface Props {
  open: boolean;
  onClose: () => void;
  strategie: StrategieDepartementale;
  onSave: (patch: Partial<StrategieDepartementale>) => void;
}

export function StrategieModal({ open, onClose, strategie, onSave }: Props) {
  const [libelle, setLibelle] = useState("");
  const [responsable, setResponsable] = useState("");
  const [statut, setStatut] = useState<Statut>("NON_DEMARRE");

  useEffect(() => {
    if (open) {
      setLibelle(strategie.libelle || "");
      setResponsable(strategie.responsable || "");
      setStatut(strategie.statut);
    }
  }, [open, strategie]);

  const handleSave = () => {
    onSave({
      libelle,
      responsable: responsable || null,
      statut,
    });
    onClose();
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="Modifier la Stratégie"
      subtitle={strategie.code}
      accentColor="#8b5cf6"
      size="md"
      footer={
        <>
          <ModalButton variant="secondary" onClick={onClose}>
            Annuler
          </ModalButton>
          <ModalButton variant="primary" onClick={handleSave}>
            Enregistrer
          </ModalButton>
        </>
      }
    >
      <div className="space-y-4">
        <FormField label="Libellé" required>
          <FormTextarea
            value={libelle}
            onChange={(e) => setLibelle(e.target.value)}
            placeholder="Description de la stratégie..."
            rows={3}
          />
        </FormField>

        <FormField label="Responsable">
          <FormInput
            value={responsable}
            onChange={(e) => setResponsable(e.target.value)}
            placeholder="Nom du responsable"
          />
        </FormField>

        <FormField label="Statut" required>
          <FormSelect
            value={statut}
            onChange={(e) => setStatut(e.target.value as Statut)}
          >
            {STATUTS.map((s) => (
              <option key={s.value} value={s.value}>
                {s.label}
              </option>
            ))}
          </FormSelect>
        </FormField>
      </div>
    </Modal>
  );
}
