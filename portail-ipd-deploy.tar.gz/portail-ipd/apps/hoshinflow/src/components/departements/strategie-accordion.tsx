"use client";

import { useState } from "react";
import Link from "next/link";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronDown, FolderKanban, User, BarChart3 } from "lucide-react";
import { GlassPanel } from "@/components/ui/glass-panel";
import { StatusBadge } from "@/components/ui/status-badge";
import { ProgressRing } from "@/components/ui/progress-ring";
import { cn, getProgressBarColor } from "@/lib/utils";
import type { StrategieDepartementale, Statut } from "@/lib/types";

interface StrategieAccordionProps {
  strategie: StrategieDepartementale;
  index?: number;
}

export function StrategieAccordion({ strategie, index = 0 }: StrategieAccordionProps) {
  const [isOpen, setIsOpen] = useState(false);
  const completion = strategie.tauxCompletion ?? 0;

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay: index * 0.05 }}
    >
      <GlassPanel className="overflow-hidden">
        {/* Header - clickable */}
        <button
          onClick={() => setIsOpen((prev) => !prev)}
          className="w-full flex items-center gap-4 p-4 text-left hover:bg-white/[0.03] transition-colors cursor-pointer"
        >
          {/* Progress */}
          <ProgressRing value={completion} size="sm" />

          {/* Content */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <span className="text-[10px] font-mono font-bold text-white/30 tracking-wider">
                {strategie.code}
              </span>
              <StatusBadge status={strategie.statut as Statut} />
            </div>
            <h4 className="text-sm font-medium text-white/85 truncate">
              {strategie.libelle}
            </h4>
            {strategie.responsable && (
              <p className="text-xs text-white/35 mt-0.5 flex items-center gap-1">
                <User className="h-3 w-3" />
                {strategie.responsable}
              </p>
            )}
          </div>

          {/* Projet count + chevron */}
          <div className="flex items-center gap-3 shrink-0">
            <span className="text-xs text-white/30 flex items-center gap-1">
              <FolderKanban className="h-3.5 w-3.5" />
              {strategie.projets.length}
            </span>
            <motion.div
              animate={{ rotate: isOpen ? 180 : 0 }}
              transition={{ duration: 0.2 }}
            >
              <ChevronDown className="h-4 w-4 text-white/30" />
            </motion.div>
          </div>
        </button>

        {/* Completion bar */}
        <div className="h-0.5 bg-white/[0.04]">
          <div
            className={cn("h-full transition-all duration-500", getProgressBarColor(completion))}
            style={{ width: `${Math.min(completion, 100)}%` }}
          />
        </div>

        {/* Expanded content: projets */}
        <AnimatePresence initial={false}>
          {isOpen && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.3, ease: [0.4, 0, 0.2, 1] }}
              className="overflow-hidden"
            >
              <div className="border-t border-white/[0.05] bg-white/[0.01]">
                {strategie.projets.length === 0 ? (
                  <p className="p-4 text-xs text-white/30 italic">
                    Aucun projet rattaché
                  </p>
                ) : (
                  <div className="divide-y divide-white/[0.04]">
                    {strategie.projets.map((projet) => (
                      <div
                        key={projet.id}
                        className="flex items-center gap-3 px-4 py-3 hover:bg-white/[0.02] transition-colors group"
                      >
                        {/* Projet score dot */}
                        <div
                          className="h-2 w-2 rounded-full shrink-0"
                          style={{
                            backgroundColor:
                              (projet.scorePerformance ?? 0) >= 80
                                ? "#10b981"
                                : (projet.scorePerformance ?? 0) >= 50
                                ? "#06b6d4"
                                : (projet.scorePerformance ?? 0) >= 20
                                ? "#f59e0b"
                                : "#ef4444",
                          }}
                        />

                        {/* Projet info */}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-0.5">
                            <span className="text-[10px] font-mono text-white/25">
                              {projet.code}
                            </span>
                            <StatusBadge status={projet.statut as Statut} />
                          </div>
                          <p className="text-xs text-white/70 truncate">
                            {projet.libelle}
                          </p>
                        </div>

                        {/* Responsable + KPI count */}
                        <div className="shrink-0 text-right">
                          {projet.responsable && (
                            <p className="text-[10px] text-white/30 truncate max-w-[120px]">
                              {projet.responsable}
                            </p>
                          )}
                          <p className="text-[10px] text-white/20 flex items-center justify-end gap-1 mt-0.5">
                            <BarChart3 className="h-2.5 w-2.5" />
                            {projet.kpis.length} KPI{projet.kpis.length > 1 ? "s" : ""}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </GlassPanel>
    </motion.div>
  );
}
