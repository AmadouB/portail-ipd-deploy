"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { Layers, FolderKanban, User } from "lucide-react";
import { GlassPanel } from "@/components/ui/glass-panel";
import { ProgressRing } from "@/components/ui/progress-ring";

interface DeptCardProps {
  code: string;
  nom: string;
  couleur: string;
  directeur: string | null;
  tauxCompletion: number;
  strategiesCount: number;
  projetsCount: number;
  index?: number;
}

export function DeptCard({
  code,
  nom,
  couleur,
  directeur,
  tauxCompletion,
  strategiesCount,
  projetsCount,
  index = 0,
}: DeptCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, delay: index * 0.04, ease: "easeOut" }}
    >
      <Link href={`/departements/${code}`} className="block group">
        <GlassPanel hover className="p-5 h-full">
          <div className="flex items-start gap-4">
            {/* Large code */}
            <div className="shrink-0 flex flex-col items-center gap-2">
              <span
                className="text-2xl font-black font-mono tracking-tight leading-none"
                style={{
                  color: couleur,
                  textShadow: `0 0 20px ${couleur}40`,
                }}
              >
                {code}
              </span>
              <ProgressRing value={tauxCompletion} size="sm" />
            </div>

            {/* Content */}
            <div className="flex-1 min-w-0">
              <h3 className="text-white/90 font-semibold text-sm leading-tight mb-1.5 group-hover:text-white transition-colors line-clamp-2">
                {nom}
              </h3>

              {directeur && (
                <p className="flex items-center gap-1.5 text-xs text-white/40 mb-3">
                  <User className="h-3 w-3" />
                  <span className="truncate">{directeur}</span>
                </p>
              )}

              {/* Stats row */}
              <div className="flex items-center gap-3 text-[11px] text-white/35">
                <span className="flex items-center gap-1">
                  <Layers className="h-3 w-3" style={{ color: couleur }} />
                  {strategiesCount} strat.
                </span>
                <span className="flex items-center gap-1">
                  <FolderKanban className="h-3 w-3" style={{ color: couleur }} />
                  {projetsCount} proj.
                </span>
              </div>
            </div>
          </div>
        </GlassPanel>
      </Link>
    </motion.div>
  );
}
