"use client";

import { useState, useMemo } from "react";
import { motion } from "framer-motion";
import { Search, X } from "lucide-react";
import { DeptCard } from "./dept-card";
import type { Departement } from "@/lib/types";

interface DepartementSearchProps {
  departements: Departement[];
}

export function DepartementSearch({ departements }: DepartementSearchProps) {
  const [query, setQuery] = useState("");

  const filtered = useMemo(() => {
    if (!query.trim()) return departements;
    const q = query.toLowerCase();
    return departements.filter(
      (d) =>
        d.code.toLowerCase().includes(q) ||
        d.nom.toLowerCase().includes(q) ||
        (d.directeur && d.directeur.toLowerCase().includes(q)) ||
        (d.nomCourt && d.nomCourt.toLowerCase().includes(q))
    );
  }, [departements, query]);

  return (
    <div className="space-y-6">
      {/* Search bar */}
      <div className="relative max-w-md">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-white/30" />
        <input
          type="text"
          placeholder="Rechercher un département..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          className="w-full bg-white/[0.04] border border-white/[0.08] rounded-lg pl-10 pr-9 py-2.5 text-sm text-white/90 placeholder:text-white/25 focus:outline-none focus:border-white/[0.15] focus:bg-white/[0.06] transition-all"
        />
        {query && (
          <button
            onClick={() => setQuery("")}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-white/30 hover:text-white/60 transition-colors"
          >
            <X className="h-4 w-4" />
          </button>
        )}
      </div>

      {/* Results count */}
      {query && (
        <motion.p
          className="text-xs text-white/30"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
        >
          {filtered.length} résultat{filtered.length > 1 ? "s" : ""}
        </motion.p>
      )}

      {/* Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {filtered.map((dept, index) => (
          <DeptCard
            key={dept.id}
            code={dept.code}
            nom={dept.nom}
            couleur={dept.couleur}
            directeur={dept.directeur}
            tauxCompletion={dept.tauxCompletion ?? 0}
            strategiesCount={dept.strategies.length}
            projetsCount={dept.totalProjets ?? 0}
            index={index}
          />
        ))}
      </div>

      {filtered.length === 0 && (
        <div className="text-center py-12">
          <p className="text-sm text-white/30">
            Aucun département ne correspond à votre recherche
          </p>
        </div>
      )}
    </div>
  );
}
