#!/bin/sh
set -e

echo "=== Portail IPD - Démarrage ==="
echo "Environnement: ${NODE_ENV:-production}"
echo "Port: ${PORT:-3000}"

# Attendre que PostgreSQL soit prêt (si variable DATABASE_URL)
if [ -n "$DATABASE_URL" ]; then
  echo "Attente de PostgreSQL..."
  i=0
  until node -e "require('pg').Client && new (require('pg').Client)({connectionString: process.env.DATABASE_URL}).connect().then(c=>c.end()).then(()=>process.exit(0)).catch(()=>process.exit(1))" 2>/dev/null; do
    i=$((i+1))
    if [ $i -gt 30 ]; then
      echo "[WARN] PostgreSQL non disponible après 30s — tentative de démarrage quand même"
      break
    fi
    sleep 1
  done

  # Appliquer les migrations
  echo "Application des migrations Prisma..."
  npx prisma migrate deploy 2>&1 && echo "[OK] Migrations appliquées" || echo "[INFO] Pas de migration à appliquer"
fi

echo "=== Démarrage du serveur ==="
exec "$@"
