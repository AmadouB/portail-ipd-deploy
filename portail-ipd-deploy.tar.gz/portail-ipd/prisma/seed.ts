import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

// ─── Users (11 utilisateurs avec hash bcrypt) ───────────────

const USERS = [
  { id: "usr-001", email: "a.sall@pasteur.sn", password: "$2b$10$KAtR1HaVn7WPfsD3w1y65OzlUX3wxIPCLm0WYxezQ/Bj8XkIFPzpG", firstName: "Amadou", lastName: "Sall", role: "admin_general", pole: "tous", department: "Direction Generale", title: "Administrateur General", isActive: true, mfaEnabled: true },
  { id: "usr-002", email: "a.bao@pasteur.sn", password: "$2b$10$KAtR1HaVn7WPfsD3w1y65OzlUX3wxIPCLm0WYxezQ/Bj8XkIFPzpG", firstName: "Amadou", lastName: "Bao", role: "seid", pole: "gouvernance", department: "Cellule SEID", title: "Consultant SEID", isActive: true, mfaEnabled: false },
  { id: "usr-003", email: "f.diagne@pasteur.sn", password: "$2b$10$KAtR1HaVn7WPfsD3w1y65OzlUX3wxIPCLm0WYxezQ/Bj8XkIFPzpG", firstName: "Fatou", lastName: "Diagne", role: "cas", pole: "gouvernance", department: "Cellule d'Appui Strategique", title: "Responsable CAS", isActive: true, mfaEnabled: false },
  { id: "usr-004", email: "n.coumba@pasteur.sn", password: "$2b$10$KAtR1HaVn7WPfsD3w1y65OzlUX3wxIPCLm0WYxezQ/Bj8XkIFPzpG", firstName: "Ndeye Coumba", lastName: "Toure", role: "dir_sante_publique", pole: "metiers", department: "Direction Sante Publique", title: "Directrice Sante Publique", isActive: true, mfaEnabled: true },
  { id: "usr-005", email: "m.ndiaye@pasteur.sn", password: "$2b$10$KAtR1HaVn7WPfsD3w1y65OzlUX3wxIPCLm0WYxezQ/Bj8XkIFPzpG", firstName: "Moussa", lastName: "Ndiaye", role: "dsi", pole: "operations", department: "Direction des Systemes d'Information", title: "Directeur DSI", isActive: true, mfaEnabled: true },
  { id: "usr-006", email: "ibrahima.fall@pasteur.sn", password: "$2b$10$7kqZ5hV.7RlaW27mCWZAO.zeQeWN1TKXo6i0RkUBG3fu46s1Sd2Pm", firstName: "Ibrahima", lastName: "Soce Fall", role: "utilisateur", pole: "tous", department: "Direction Generale", title: "Directeur General", isActive: true, mfaEnabled: true },
  { id: "usr-007", email: "sophie.diallo@pasteur.sn", password: "$2b$10$YBiuLIHbDQQyBrTex412B.je7Yoh1LdG6ZqtaO5QhB8j6hWfYp2Dy", firstName: "Sophie", lastName: "Diallo", role: "admin_general", pole: "tous", department: "Administration et Finance", title: "Chargee de projet", isActive: true, mfaEnabled: false },
  { id: "usr-008", email: "fatoumata.niang@pasteur.sn", password: "$2b$10$UBY1xnTY4XtQmB0/zkqZleSHg8y75XjkcRVJEvOnSB6kPVa1nGsZO", firstName: "Fatoumata", lastName: "Niang", role: "utilisateur", pole: "tous", department: "Capital Humain", title: "Responsable RH", isActive: true, mfaEnabled: false },
  { id: "usr-009", email: "seid@pasteur.sn", password: "$2b$10$xfX1PF/R2OuFUIkxotH74uAEClBGibD9M5.Am97Iz0O.ktKKp0u/S", firstName: "SEID", lastName: "IPD", role: "utilisateur", pole: "tous", department: "Cellule SEID", title: "Operateur SEID", isActive: true, mfaEnabled: false },
  { id: "usr-010", email: "amadou@pasteur.sn", password: "$2b$10$c6TSv5YjeeAo9M7kMalh0.McSOxOgnFX851HVynV63y0/TENyHKCK", firstName: "Amadou", lastName: "Bao", role: "utilisateur", pole: "tous", department: "Direction Generale", title: "Administrateur Systeme", isActive: true, mfaEnabled: true },
  { id: "usr-011", email: "lamine.traore@pasteur.sn", password: "$2b$10$W.kfS6C9ysV5YLa.YaWHv.1hRNnjP0qLa3HNhzOgXTNQOvxe..iFO", firstName: "Lamine", lastName: "Traore", role: "admin_general", pole: "tous", department: "Direction Generale", title: "Administrateur", isActive: true, mfaEnabled: false },
];

// ─── Modules (13 modules) ───────────────────────────────────

const MODULES = [
  { id: "ims", name: "IMS NextGen", description: "Systeme de Management Integre - Tableau de bord qualite, production et conformite IPD", pole: "metiers", icon: "Gauge", route: "/metiers/ims", priority: "P0", type: "react", color: "#8b5cf6", kpiLabel: "Conformite IMS", kpiValue: "94.2%", kpiTrend: "up", enabled: true },
  { id: "suivi", name: "Modules Suivi", description: "Coordination et suivi integre des activites de production, qualite et conformite IMS/UVFJ", pole: "metiers", icon: "ClipboardCheck", route: "/metiers/suivi", priority: "P0", type: "react", color: "#0089D0", kpiLabel: "Avancement global", kpiValue: "87.8%", kpiTrend: "up", enabled: true },
  { id: "cockpit", name: "Cockpit Strategique", description: "Pilotage global, KPIs strategiques et indicateurs de performance institutionnelle", pole: "gouvernance", icon: "Shield", route: "/gouvernance/cockpit", priority: "P0", type: "react", color: "#06b6d4", kpiLabel: "Taux execution", kpiValue: "78%", kpiTrend: "up", enabled: true },
  { id: "seid", name: "SEID - Intelligence", description: "Suivi-Evaluation & Intelligence de Donnees, Command Center et qualite des donnees", pole: "gouvernance", icon: "BarChart3", route: "/gouvernance/seid", priority: "P0", type: "react", color: "#06b6d4", kpiLabel: "Sources actives", kpiValue: "24/28", kpiTrend: "stable", enabled: true },
  { id: "surveillance", name: "Surveillance Epidemiologique", description: "Veille sanitaire, alertes epidemiques et suivi des pathologies en temps reel", pole: "metiers", icon: "Activity", route: "/metiers/surveillance", priority: "P0", type: "react", color: "#10b981", kpiLabel: "Alertes actives", kpiValue: "3", kpiTrend: "up", enabled: true },
  { id: "admin", name: "Administration Portail", description: "Gestion des utilisateurs, droits d'acces, audit et sante systeme", pole: "operations", icon: "Settings", route: "/operations/admin", priority: "P0", type: "react", color: "#f59e0b", kpiLabel: "Utilisateurs actifs", kpiValue: "142", kpiTrend: "up", enabled: true },
  { id: "production", name: "Production Vaccins", description: "Suivi de la chaine de production, lots et conformite OMS/ARP", pole: "metiers", icon: "Factory", route: "/metiers/production", priority: "P1", type: "react", color: "#10b981", kpiLabel: "Lots en cours", kpiValue: "12", kpiTrend: "stable", enabled: false },
  { id: "grant_office", name: "Grant Office", description: "Gestion des subventions, projets de recherche et portefeuille scientifique", pole: "metiers", icon: "BookOpen", route: "/metiers/grants", priority: "P1", type: "react", color: "#10b981", kpiLabel: "Projets actifs", kpiValue: "18", kpiTrend: "up", enabled: false },
  { id: "rh", name: "Ressources Humaines", description: "Gestion des talents, recrutement, formations et evaluations", pole: "operations", icon: "Users", route: "/operations/rh", priority: "P1", type: "react", color: "#f59e0b", kpiLabel: "Effectif total", kpiValue: "487", kpiTrend: "up", enabled: false },
  { id: "finance", name: "Finance & Logistique", description: "Comptabilite, tresorerie, gestion budgetaire et approvisionnement", pole: "operations", icon: "Wallet", route: "/operations/finance", priority: "P1", type: "react", color: "#f59e0b", kpiLabel: "Budget consomme", kpiValue: "62%", kpiTrend: "stable", enabled: false },
  { id: "partenariat", name: "Mobilisation Ressources", description: "Cartographie des partenaires, suivi des engagements et pipeline", pole: "partenariat", icon: "Handshake", route: "/partenariat/ressources", priority: "P2", type: "react", color: "#8b5cf6", kpiLabel: "Partenaires actifs", kpiValue: "34", kpiTrend: "up", enabled: false },
  { id: "communication", name: "Relations Medias", description: "Gestion des evenements, relations presse et veille mediatique", pole: "partenariat", icon: "Megaphone", route: "/partenariat/communication", priority: "P2", type: "html", color: "#8b5cf6", kpiLabel: "Mentions presse", kpiValue: "56", kpiTrend: "up", enabled: false },
];

// ─── Roles RBAC (11 rôles) ──────────────────────────────────

const ROLES: Record<string, { label: string; poles: string[]; modules: Record<string, string[]> }> = {
  admin_general: { label: "Administrateur General", poles: ["tous"], modules: { ims: ["read","write","admin"], suivi: ["read","write","admin"], cockpit: ["read","write","admin"], seid: ["read","write","admin"], surveillance: ["read","write","admin"], admin: ["read","write","admin"], production: ["read","write"], grant_office: ["read","write"], rh: ["read","write"], finance: ["read","write"], partenariat: ["read","write"], communication: ["read","write"] } },
  cas: { label: "Cellule Appui Strategique", poles: ["gouvernance"], modules: { cockpit: ["read"], seid: ["read"] } },
  seid: { label: "SEID - Consultant", poles: ["gouvernance"], modules: { cockpit: ["read"], seid: ["read","write"], surveillance: ["read"] } },
  dsi: { label: "Direction SI", poles: ["operations"], modules: { admin: ["read","write","admin"] } },
  dir_production: { label: "Direction Production", poles: ["metiers"], modules: { cockpit: ["read"], production: ["read","write"] } },
  dir_recherche: { label: "Direction Recherche", poles: ["metiers"], modules: { cockpit: ["read"], grant_office: ["read","write"] } },
  dir_sante_publique: { label: "Direction Sante Publique", poles: ["metiers"], modules: { cockpit: ["read"], surveillance: ["read","write"] } },
  dir_partenariat: { label: "Direction Partenariat", poles: ["partenariat"], modules: { cockpit: ["read"], partenariat: ["read","write"], communication: ["read","write"] } },
  drh: { label: "Direction RH", poles: ["operations"], modules: { rh: ["read","write"] } },
  daf: { label: "Direction Administrative et Financiere", poles: ["operations"], modules: { finance: ["read","write"] } },
  utilisateur: { label: "Utilisateur", poles: ["operations"], modules: {} },
};

// ─── Notifications (7 notifications) ────────────────────────

const NOTIFICATIONS = [
  { id: "n-001", type: "alert", title: "Alerte epidemiologique", message: "Augmentation des cas de dengue dans la region de Dakar (+23% cette semaine)", moduleId: "surveillance", severity: "high", createdAt: "2026-03-15T10:30:00Z", actionUrl: "/metiers/surveillance" },
  { id: "n-002", type: "validation", title: "Rapport trimestriel en attente", message: "Le rapport Q1 2026 du Contrat de Performance necessite votre validation", moduleId: "cockpit", severity: "medium", createdAt: "2026-03-15T09:00:00Z", actionUrl: "/gouvernance/cockpit" },
  { id: "n-003", type: "system", title: "Maintenance programmee", message: "Mise a jour du systeme prevue le 20 mars de 02h00 a 04h00 UTC", severity: "low", createdAt: "2026-03-14T16:00:00Z" },
  { id: "n-004", type: "info", title: "Nouveau module disponible", message: "Le module Grant Office est maintenant accessible depuis votre tableau de bord", moduleId: "grant_office", severity: "low", createdAt: "2026-03-14T11:00:00Z" },
  { id: "n-005", type: "alert", title: "Seuil budgetaire atteint", message: "Le pole Metiers a atteint 85% de son budget annuel alloue", moduleId: "cockpit", severity: "medium", createdAt: "2026-03-14T08:30:00Z", actionUrl: "/gouvernance/cockpit" },
  { id: "n-006", type: "system", title: "Sauvegarde completee", message: "Sauvegarde automatique des donnees completee avec succes", severity: "low", createdAt: "2026-03-13T23:00:00Z" },
  { id: "n-007", type: "validation", title: "Acces en attente d'approbation", message: "3 demandes d'acces au module Surveillance en attente de validation DSI", moduleId: "admin", severity: "medium", createdAt: "2026-03-13T14:00:00Z", actionUrl: "/operations/admin" },
];

// ─── Seed Execution ─────────────────────────────────────────

async function main() {
  console.log("🌱 Seeding database...\n");

  // 1. Users
  console.log("  → Inserting users...");
  for (const u of USERS) {
    await prisma.user.upsert({
      where: { id: u.id },
      update: {},
      create: u,
    });
  }
  console.log(`  ✓ ${USERS.length} users inserted\n`);

  // 2. Modules
  console.log("  → Inserting modules...");
  for (const m of MODULES) {
    await prisma.module.upsert({
      where: { id: m.id },
      update: {},
      create: m,
    });
  }
  console.log(`  ✓ ${MODULES.length} modules inserted\n`);

  // 3. Roles + Poles + Permissions
  console.log("  → Inserting roles and permissions...");
  let permCount = 0;
  for (const [roleId, config] of Object.entries(ROLES)) {
    await prisma.role.upsert({
      where: { id: roleId },
      update: {},
      create: { id: roleId, label: config.label },
    });

    for (const pole of config.poles) {
      await prisma.rolePole.upsert({
        where: { roleId_pole: { roleId, pole } },
        update: {},
        create: { roleId, pole },
      });
    }

    for (const [moduleId, perms] of Object.entries(config.modules)) {
      for (const permission of perms) {
        await prisma.rolePermission.upsert({
          where: { roleId_moduleId_permission: { roleId, moduleId, permission } },
          update: {},
          create: { roleId, moduleId, permission },
        });
        permCount++;
      }
    }
  }
  console.log(`  ✓ ${Object.keys(ROLES).length} roles, ${permCount} permissions inserted\n`);

  // 4. Notifications
  console.log("  → Inserting notifications...");
  for (const n of NOTIFICATIONS) {
    await prisma.notification.upsert({
      where: { id: n.id },
      update: {},
      create: {
        id: n.id,
        type: n.type,
        title: n.title,
        message: n.message,
        moduleId: n.moduleId || null,
        severity: n.severity,
        createdAt: new Date(n.createdAt),
        actionUrl: n.actionUrl || null,
      },
    });

    // Create UserNotification for all users
    for (const u of USERS) {
      await prisma.userNotification.upsert({
        where: { userId_notificationId: { userId: u.id, notificationId: n.id } },
        update: {},
        create: { userId: u.id, notificationId: n.id, read: false },
      });
    }
  }
  console.log(`  ✓ ${NOTIFICATIONS.length} notifications inserted\n`);

  console.log("✅ Database seeded successfully!");
}

main()
  .catch((e) => {
    console.error("❌ Seed failed:", e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
